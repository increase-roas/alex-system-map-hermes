#!/usr/bin/env python3
"""Build or verify the explicit documentation allowlist. No runtime or network actions."""
from pathlib import Path
import hashlib,json,re,stat,sys,zipfile
BASE=Path('/Users/alexlobaito/Documents/ChatGPT/Build/agents')
OUT=Path(__file__).resolve().parent
LOCAL=OUT.parents[1]/'work/agent-build-hub-local-manifest.json'
DATE='2026-10-07'
GROUPS={
'Javar':('Executive assistant / agent operating catalog',['ea/startup/'+n+'.md' for n in ['INDEX','AGENTS','TOOLS','WORKFLOWS']]+['ea/runtime-update/README.md']),
'Ops':('Operational coordination foundation',['team-template/README.md','team-template/ops-candidate/SOUL.md']),
'CSM':('Customer onboarding, health and delivery follow-through',['csm/'+n for n in ['README.md','SOUL.md','binding.template.json','runtime-config.example.json']]),
'Media':('Advertising analysis and creative briefs',['media/'+n for n in ['README.md','SOUL.md','binding.template.json','customer-scope.example.json','read-plugin/README.md']]),
'Sales_Hunter_Setter':('Hunter prospect research and Setter qualification in the existing B2B lane',['hunter/README.md','hunter/SKILL.md']+['setter/'+n for n in ['knowledge-binding.template.json','knowledge-binding.example.json','plugin.yaml']]),
'Finance':('Company-scoped accounting review preparation',['finance/'+n for n in ['README.md','SOUL.md','QUICKBOOKS.md','binding.template.json','requirements-quickbooks.txt']]),
'Javante':('Separate Hermes identity and operating/setup documentation',['javante/setup/'+n+'.md' for n in ['README','INDEX','IDENTITY','SOUL','TOOLS','WORKFLOWS','RECOVERY','ACCEPTANCE']])}
PATTERNS=[r'\b(?:sk-(?:proj-)?|xox[baprs]-|ghp_|github_pat_|AKIA|AIza|eyJ)[A-Za-z0-9_\-\.]{18,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',r'(?i)(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|password|authorization)\s*[=:]\s*[\"\']?([A-Za-z0-9_\-/+=.]{24,})']
EXCLUDED=['credentials or token values','environment files','sessions, logs, histories, databases','customer records or accounting records','serving runtime configuration','mutable USER.md, MEMORY.md, KNOWLEDGE.md','executables and unallowlisted files']
def sha(data):return hashlib.sha256(data).hexdigest()
def scan(data):
 text=data.decode('utf-8')
 return any(re.search(p,text) for p in PATTERNS)
def read_source(rel):
 p=BASE/rel
 if not p.exists():return None,'missing'
 if p.is_symlink() or not stat.S_ISREG(p.stat().st_mode):return None,'nonregular_or_symlink'
 data=p.read_bytes()
 if scan(data):return None,'credential_pattern'
 return data,None

def main():
 verify='--verify' in sys.argv
 manifest={'snapshot_date':DATE,'maintained_source_root':str(BASE),'scope':'Curated documentation snapshots only; not full serving runtimes','live_health':'NOT_CHECKED','packages':[],'exclusions':EXCLUDED,'scan':'All included UTF-8 source content inspected and credential-pattern scanned; template placeholders and references allowed. Pattern scanning is not a live security audit.'}
 for name,(role,allow) in GROUPS.items():
  files=[];omissions=[];payload={}
  for rel in allow:
   data,reason=read_source(rel)
   if reason:omissions.append({'source_file':rel,'reason':reason});continue
   payload['source/'+rel]=data
   files.append({'source_file':rel,'archive_path':'source/'+rel,'bytes':len(data),'sha256':sha(data)})
  entry={'name':name,'role':role,'snapshot_date':DATE,'source_root':str(BASE),'requested_source_files':allow,'source_files':files,'omissions':omissions,'layers':{'included':['role/setup documentation','navigation and operating instructions when allowlisted','nonsecret template/examples when allowlisted'],'excluded':EXCLUDED,'scope':'Documentation only; dependencies referenced by source may be outside this snapshot. Missing linked files are not evidence of deletion or failure.'},'live_health':'NOT_CHECKED','instructions_authority':'Dated source instructions, placeholders, approvals, and acceptance statements are historical documentation; they grant no new authority and were not executed.'}
  readme=f'''# {name} — documentation snapshot\n\nSnapshot date: {DATE}\nRole: {role}\nMaintained source: `{BASE}`\n\nThis is a curated documentation snapshot. The maintained source remains local at the path above. Source files under `source/` are exact original bytes after inspection and credential-pattern scanning. `SNAPSHOT-MANIFEST.json` records their paths, SHA-256 checksums, exclusions, omissions and scope.\n\nThis is not a full serving runtime, installation bundle, current health check, credentials backup or fresh execution authority. Dated instructions, historical approvals/acceptance, placeholder IDs and example configurations are documentation, not new authority or verified present state. No source instructions were executed. All current identities, permissions, bindings, provider data and runtime behavior require separate live verification.\n\nLinked dependencies outside this allowlist are not bundled; relative links may not resolve inside this ZIP. Source recipes may contain historical status statements; this snapshot does not assert live health. No sessions, logs, mutable USER/MEMORY/KNOWLEDGE files, customer records, credentials or copied serving runtime configuration are included. An explicitly allowlisted example JSON is a template, not a serving configuration.\n\nIncluded source files: {len(files)}\nOmissions: {json.dumps(omissions)}\n'''.encode()
  payload['README.md']=readme;payload['SNAPSHOT-MANIFEST.json']=(json.dumps(entry,indent=2)+'\n').encode()
  target=OUT/f'{name}_Documentation_Snapshot_{DATE}.zip'
  if not verify:
   with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for path,data in payload.items():
     info=zipfile.ZipInfo(path,date_time=(2026,10,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
  with zipfile.ZipFile(target) as z:
   assert z.testzip() is None
   assert set(z.namelist())==set(payload)
   assert len(z.namelist())==len(payload)
   for path,data in payload.items():assert z.read(path)==data,(name,path,'byte mismatch')
   assert not any('..' in Path(p).parts or Path(p).is_absolute() for p in z.namelist())
  entry['zip_path']=str(target);entry['zip_bytes']=target.stat().st_size;entry['zip_sha256']=sha(target.read_bytes())
  manifest['packages'].append(entry)
 if verify:
  assert json.loads(LOCAL.read_text())==manifest,'local manifest mismatch'
  assert len(list(OUT.glob('*.zip')))==7,'unexpected ZIP count'
 else:
  LOCAL.write_text(json.dumps(manifest,indent=2)+'\n')
  (OUT/'SHA256SUMS.txt').write_text(''.join(p['zip_sha256']+'  '+Path(p['zip_path']).name+'\n' for p in manifest['packages']))
 print(json.dumps({'verified':verify,'packages':len(manifest['packages']),'source_files':sum(len(p['source_files']) for p in manifest['packages']),'omissions':[o for p in manifest['packages'] for o in p['omissions']],'zip_files':[p['zip_path'] for p in manifest['packages']]},indent=2))
if __name__=='__main__':main()
