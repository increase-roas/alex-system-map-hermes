# Local snapshot verification

[E1] work/agent-build-hub-local-manifest.json
[E2] outputs/agent-build-hub/package_snapshots.py --verify
[E3] check_acceptance.py output below

The archive readback checks CRC integrity, exact allowlist membership (negative check: unexpected members fail), source bytes, SHA256 manifest consistency, safe archive paths, seven ZIPs and current credential-pattern scan. All 34 selected source documents were inspected for role/source/example boundaries. No source instructions were executed. No runtime/provider health was checked. All allowlisted files were available; no omissions. Referenced dependencies beyond the allowlist are not included.

```text
| Check | Result | Detail |
| --- | --- | --- |
| `json:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/work/agent-build-hub-local-manifest.json` | VERIFIED | valid JSON |
| `cmd:python3 /Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/package_snapshots.py --verify` | VERIFIED | exit 0; } |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/SHA256SUMS.txt non-empty` | VERIFIED | 784 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Javar_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 16652 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Ops_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 5556 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/CSM_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 5335 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Media_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 6471 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Sales_Hunter_Setter_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 7790 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Finance_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 7447 bytes |
| `file:/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-build-hub/Javante_Documentation_Snapshot_2026-10-07.zip non-empty` | VERIFIED | 17219 bytes |

```
