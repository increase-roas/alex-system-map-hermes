# Agent Builds & Setup

Grouped October 7, 2026.

[Start Here](https://docs.google.com/document/d/1yYm-VGccTRUTVAtuSkTF9w1kABG9Jha5EyLexfTbOxc/edit)

[Open the shared Drive hub](https://drive.google.com/drive/folders/1_gIjJUQZ9gXbJGctSRNVeDcImlcLu87w)

Location: Company OS / 000 Agent Team SOPs / Agent Builds & Setup

## Folders

- [01 Javar](https://drive.google.com/drive/folders/163WibPA7SUK14PnQz5SKdi8Uj27rb0x_)
- [02 Ops](https://drive.google.com/drive/folders/1Bwsivycz4Xp2rg9AN7hlmVJ6JW8D-nYb)
- [03 Customer Success](https://drive.google.com/drive/folders/1Bs1yXS5x8FU8WwYXvUFL_sGlwSirFcYC)
- [04 Media](https://drive.google.com/drive/folders/1yBDRbbEFHOBKZCkaEGLPdUDy4Q77dyvM)
- [05 Sales - Setter & Hunter](https://drive.google.com/drive/folders/1hD81_y-8rq9MML6eSEBA9eAuJEm8lwem)
- [06 Finance](https://drive.google.com/drive/folders/1cCOAGSdHVlya5vVsVs44BOhNKcq9oTzf)
- [07 Javante](https://drive.google.com/drive/folders/1CLT-jas1qZd33-rNCHsCBpnZZJykauJj)
- [08 Shared Infrastructure & Verification](https://drive.google.com/drive/folders/1N8LetfxdjW_zxRGyn0CYdD14j-XORGJR)

Seven documentation snapshots contain 34 source files. Fourteen shortcuts group existing Drive records while preserving their original file IDs. Each uploaded ZIP passed size and SHA256 checks. These snapshots cover selected build/setup documentation, not complete runtime backups or current health proof.

Also present in the hub: [Jev CRM Sales & Support Analysis Tool](https://drive.google.com/drive/folders/1rNlURO4ZCjTvsEnX82RX5jJMBZFeuMI1). Its contents were outside this setup check.
