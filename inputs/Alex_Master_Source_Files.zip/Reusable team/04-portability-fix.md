# Portability fix — uninstalled version 0.2

The portability adapters are implemented in the draft package. Alex manually creates the operating folder; its first chat invokes setup and becomes Director. After preparation, Alex supplies the mission. That Director then creates and supervises the responsible controllers using the native authorized route. A mission can create a project or work on an existing external repo.

The current Hermes work was already possible because the original Director/controller team supervises external workers from its own existing home. Original-home references are correct for that team. The reuse problem was making a second team's instructions, state and return addresses belong to the second team. Version 0.2 implements that change without modifying the original.

## What changed

| Component | Implemented change |
|---|---|
| Setup entrypoint | Existing empty folder, actual invoking chat as Director; no top-level folder or second Director creation |
| Fresh state | New team UUID, blank ledger, empty permissions and logs; no missions, controllers, approvals, credentials or schedules copied |
| Role edition | 22 pinned source-derived templates; original home/role/handoff paths render to the selected home |
| Controller ownership | Recovery scoped to the team; assignments name the exact local Conductor and actual Director return identity |
| Guard | Home derived from local binding; arbitrary root/state, test mode and host-spoof environment overrides removed; team/Director identity and local graph/authorization paths validated |
| Ledger and graph helpers | Foreign paths, linked backup/lock destinations and mismatched team/Director headers refused |
| Acceptance and lint | Team log stays local even when PROJECT points at an external repo; explicit foreign log paths refused |
| Copied assumptions | Old queue, mission names, schedule cleanup, zip-generator paths and blanket approval assumptions removed or scoped to current authority |
| Partial/repeat setup | Exclusive writes, binding last, incomplete marker on interruption; existing state is inspected, never overwritten |

Sources are mapped in [the source lock](create-independent-team/assets/source-lock.json). Director/Conductor inputs come from the preserved audit baseline. The guard and graph template are separately pinned supplemental inputs; their current original hashes were reverified and exact copies retained in assigned scratch. All original sources were read-only.

## Evidence and limits

Twelve isolated component checks pass: in-memory rendering, first-chat binding, separate homes/return addresses, blank state, foreign ledger/graph/log rejection, moved binding rejection, linked backup/claim parent rejection, incomplete setup rejection, actual guard path resolution and refusal of overrides, actual acceptance preparation with an external PROJECT, and syntax compilation. The guard resolution check creates no claims; the acceptance preparation check writes neither graph nor log. Only inert temporary data under the assigned scratch folder is used.

The setup command itself was not executed. No generated serving home, installed skill, Director/controller chat, native messaging trial, runtime isolation test, scheduler, external service action or adoption was created. Component checks prove these specific functions, not the whole operating team.

A separate static reviewer identified six template/wiring defects; all were fixed and the focused acceptance pass returned PASS. The final source/doc checks and raw component results are in [STATIC_CHECKS.md](STATIC_CHECKS.md) and [component results](verification/component-checks.txt).

Actual native identity discovery, chat creation/delivery/return, effective hooks, permissions and interruption recovery still need the previously proposed isolated runtime trial. Broad filesystem/account restrictions are not provided by these helper checks. Two private guard stores do not arbitrate a shared external target. Those limits do not mean the path/identity fixes remain unimplemented.

## Intended experience after installation/adoption is separately approved

1. Alex creates an empty folder and opens its first chat.
2. He invokes create-independent-team. That existing chat prepares its operating home and becomes Director.
3. He gives the mission afterward.
4. The Director creates the appropriate fresh controller chats and supervises their work from this home. Project code can live elsewhere.

The complete skill and procedure are [here](create-independent-team/SKILL.md). The later trial remains [proposed](03-dependencies-and-trial.md). Nothing was installed or launched by this revision.
