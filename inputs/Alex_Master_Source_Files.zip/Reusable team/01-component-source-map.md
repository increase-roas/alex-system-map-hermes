# Component and source map

Prepared October 3, 2026. This map distinguishes source policy, recorded working evidence and candidate adaptation. Exact per-file fingerprints and repository revisions are in `source-versions.json`; baseline reconciliation has its own receipt. Live-source observations alone are not a frozen system version.

Final reference: published audit baseline `alex-agent-baseline-2026-10-03`; see `BASELINE_RECONCILIATION.md`. Covered core sources match. The standalone guard, graph template and selected Build/Hermes sources are separately identified live-source supplements. A newer live Build source-sync hold reinforces that its files are navigation evidence, not an assumed deployment-ready package.

## The pattern already in use

The current Director's operating state lives in `/Users/alexlobaito/Alex-Director`. Its restored Claude session supervises the existing Conductor and workers using `/Users/alexlobaito/Projects/master-connector-repo` for working evidence. The Hermes mission targets Javar's Orgo home and Javante's Mac mini home; maintained role packages also live in `/Users/alexlobaito/Documents/ChatGPT/Build`. The supervising team is already separate from the objects it works on.

`mission-hermes-agents-skeleton.md` records PROJECT as the master connector repo while its boundary explicitly names both external homes. This supports Alex's requested layout. It does not establish that another independent Director team has been initialized or tested.

| Existing layer | Reuse | What stays out of a fresh team |
|---|---|---|
| Shared core | Current standards, app cards, skill routing and evidence requirements | Global edits, global configuration clones, hidden credential values |
| Director | Outcome freeze, assignment, evidence judgment, graph/ledger continuity | Existing live sessions, mission blocks, approvals, dispatches and pending jobs |
| Conductor/controllers | Route selection, implementation, actual readback, compact native results | Existing controller identities and authority over old targets |
| Workers/targets | Platform-specific methods when the assigned mission needs them | Javar/Javante identity, memory, customer scope, runtime home or credentials |
| Assigned project | Existing source of truth and relevant instructions | Mandatory installation of the entire team into that repo |

## Canonical operating sources

Paths in this table are evidence locations, not destinations to write during setup.

| Component | Source | Reuse decision and limit |
|---|---|---|
| Director policy v2.7 | `/Users/alexlobaito/.agents/skills/alex-director/SKILL.md` | Preserve outcome-level supervision, judge returned evidence, independent ready work, single ledger writer. Adapt original-home references deliberately. |
| Controller policy v2.5 | `/Users/alexlobaito/.agents/skills/alex-workflow-conductor/SKILL.md` and `references/routing.md` | Preserve technical ownership and compact checkpoint/return loop. Bind the supervising identity to the new team. |
| Director role/home | `/Users/alexlobaito/Alex-Director/AGENTS.md` | Scope its one-Director/one-ledger rule per new team; leave original text untouched. |
| Mission data and authority | Director `references/ledger.md`, `mission-graph.md`, `gates.md` | Use current fields/statuses and approval semantics. Old approval records are not grants to a new team. |
| Transport and continuity | Director `references/controllers.md`, `supervision.md`, `handoff.md`, `continuation.md` | Preserve delivery/return checks, idempotent play identity and continuity. Platform capability and present authorization still need proof. |
| Relevant target instruction inspection | Director `references/repo-review.md` | Inspect effective instructions and mission fit once; existence of AGENTS.md does not justify a repo rebuild. |
| Safe local state edits | Director `scripts/ledger_check.py`, `graph_edit.py`, `accept.py`, `graph_lint.py` and migration JSON | Helpers are related dependencies. Ledger path is explicit; acceptance log default follows PROJECT and must be explicitly bound. No helper was run on live state here. |
| Protected writes | `/Users/alexlobaito/Alex-Director/scripts/controller-write-guard.py` | Preserve ownership, generations, deduplication, ordered steps and authoritative readback. Production home is hardcoded; a team-bound adaptation is required before use. |
| Blank graph | `/Users/alexlobaito/Alex-Director/templates/mission-graph-template.md` | Reuse schema, not original destination or example identities. Guard expects a separate `## Node:` marker for a fenced node. |
| Maintained shared rules | `/Users/alexlobaito/.agents/instructions/` | Source of generated AGENTS/config instructions; shared read-only dependency. Do not rebuild into global files. |
| Capability and worker policy | `/Users/alexlobaito/STACK.md`, `/Users/alexlobaito/Documents/One-Shot-Builder/RULES.md` | Relevant load dependencies to bind/read when applicable, not private mission stores to clone. |
| Claude distribution pointers | Director and Conductor `claude-edition.md` | Thin pointers are delivery artifacts, not portable isolated roles; original paths remain dangerous if copied unchanged. |

## Existing setup and workbook sources

| Source | Contribution | Treatment |
|---|---|---|
| `/Users/alexlobaito/Projects/master-connector-repo/work/2026-10-01_setup-playbook/scripts/student_edition.py` | `director_starter` extracts the blank commented ledger block, graph template and empty graphs; `rule_files` builds rule material | Reuse the blank-state extraction idea. Do not run the whole exporter or clone its fixed `~/Alex-Director` and `~/STACK.md` installation directions. |
| Same job's `build_tabs.py` and ordered `tabs/*.json` | Workbook construction and navigation maps | Procedure/source pointers, not a second policy authority. Older rows can conflict with later receipts. |
| Same job's `tabs/director-home.json`, `tabs/hermes-javar.json` | Blank starter/dependencies; platform/setup map | Bounded read; no blanket replay of workbook steps. |
| Same job's `zips/build_zips.py` | Role pointer zip creation | Understand provenance; no zip build or installation performed. |
| `/Users/alexlobaito/Projects/master-connector-repo/work/2026-10-01_director-tab/build_tab.py` and `notes/skills-map.json` | Director/Conductor workbook section | Additional generation dependency beyond setup-playbook. |
| `/Users/alexlobaito/Projects/master-connector-repo/work/2026-10-01_app-decisions/build_decisions.py` | App decisions tab/CSV | Decisions remain scoped to their recorded target and date. |
| `/Users/alexlobaito/.agents/tools/connectors/cards_to_sheet.py` | Tool-card projection into workbook | Cards stay canonical; workbook is generated. |
| `/Users/alexlobaito/Projects/master-connector-repo/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx` | Master workbook | Read-only version fingerprint; its Documents copy is generated. No workbook rebuild or opening was needed for this draft. |

## Javar and Javante are examples of external targets

| Item | Javar | Javante |
|---|---|---|
| Platform recorded in sources | Orgo; unprivileged `javar` service identity | Mac mini; `sashairis` identity |
| Runtime home | `/home/orgo/lil-smoove/home/.hermes` | `/Users/sashairis/.hermes` |
| Maintained source | Build `agents/ea/startup/` and reviewed runtime package | Build `agents/javante/setup/` |
| Additional navigation | `/home/orgo/lil-smoove/home/agent-knowledge` | Within Hermes home |
| Credential mechanism recorded | Protected role loader, dedicated role scope | Broker-backed `secrets.command` and launchd services |
| Limit | Recorded component successes do not mean the full migration/acceptance is complete | Recorded restart/auto-load repair is not model behavior proof; credits were a recorded blocker |

Relevant source: `/Users/alexlobaito/.agents/skills/hermes-team-setup/SKILL.md`. It expressly distinguishes platforms and treats role knowledge as knowledge, not new authorization.

Build's `agents/team-template/materialize.py` validates accepted source hashes and makes independent role files, but requires `mission`, nonempty customers and Slack bindings. Its generated text also includes the existing private war-room ID. It cannot be run unchanged to initialize a mission-free Director/controller team. Its task records are not shared supervisory authority.

`work/2026-10-03_hermes-edition/scripts/build_hermes_edition.py` in the connector repo is a useful example of deriving platform-specific editions from maintained standards. Its recorded manifest identifies `mha-sk1b`, agents-home revision `ad0158c`, 26 sources and separate Javar/Javante outputs. Those packages were built for those roles; installation/full behavior was still a separate gate in the mission record. Do not import this unadopted behavior package as a proven new-team default. Untracked Build packages also mean Git HEAD alone is insufficient to reproduce all inputs.

## Evidence worth retaining as pointers

| Evidence file under the original conversation workspace | What it supports | What it does not support |
|---|---|---|
| `outputs/director-system-handoff-2026-10-03.md` | Alex's intended home-first sequence, current ownership, authority boundaries | New live permission or current health |
| `outputs/restoration-status.md` | Recorded restoration cycle, judgment, useful parallel work, continuation around a blocker | All business missions complete or second-team isolation |
| `work/restoration/full-cycle-proof.json` | Assignment received 06:25:25Z, Conductor report 06:35:49Z, judgment/ledger/readback by 06:38:46Z on Oct 3 | Universal delivery guarantees; its initial acceptance gap is historical |
| `work/restoration/concurrency-proof.json` | Six active background agents plus Conductor observed; later acceptance/follow-up evidence included | Worker count equals business outcomes |
| `outputs/agent-system-improvement-research.md` | Prior research and proposed comparison method | Proven behavior gains in this system |
| Audit baseline and findings, when published | Versioned source evidence and narrower diagnosed gaps | Authorization to apply proposed fixes |

Raw transcripts were not needed. Existing redacted receipts suffice for this mapping. No live Hermes health check or external write was performed.

## Version 0.2 implementation map

The uninstalled candidate now contains `scripts/prepare_team.py` (new empty-home/current-chat initializer), `assets/runtime/team_paths.py` (new path/identity resolver), and 22 templates under `assets/role-templates/`. `assets/source-lock.json` maps every retained source hash, derived template hash and narrow adaptation. Preserved Director/Conductor policy and four helpers come from the published baseline; guard and graph template are the separately pinned supplements described above. The generated home card is a scoped adaptation of the preserved home card, whose source hash is also recorded. Original setup remains read-only.
