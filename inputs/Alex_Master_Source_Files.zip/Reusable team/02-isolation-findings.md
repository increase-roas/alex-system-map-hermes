# Isolation findings

The working layout is reusable. Its current path, identity and access bindings are not automatically portable. The findings below come from source inspection; none is a claim that the candidate has passed runtime isolation.

## Version 0.2 resolution

F01–F04, F09 (generated state), F13 (local role bindings) and F14 have concrete candidate adaptations. F02 now has a local binding-based guard; F03 now defaults and confines acceptance/lint logs to the team home. Foreign paths and supervisor IDs are rejected in component checks. No original source is changed. F05–F07 and real runtime/provider enforcement still require actual environment evidence. See 04-portability-fix.md and assets/source-lock.json under the skill. The table below preserves the source hazards that motivated these changes.

## Three ownership boundaries

Shared standards are maintained once and read by each team. Each team owns its private ledger, graphs, identities, pending work and authorized claims. Each project/provider object stays with its actual owner and is assigned to a team only within a named mission boundary. A shared Composio organization is not shared permission to every login/resource.

For a new team, scope “one Director / one ledger / at most one heartbeat” to TEAM_ID. The original `~/Alex-Director/AGENTS.md` keeps its existing meaning and is not edited. Independent teams do not become a central global Director or gain each other's resources.

## Concrete carryover hazards

| Finding | Evidence/path | Consequence of an ordinary copy | Required candidate treatment |
|---|---|---|---|
| F01 — original ledger and graph root | `~/Alex-Director/AGENTS.md`; Director/Claude pointer; ledger, controllers, mission-graph, gates and handoff references | New role may recover/dispatch old missions or edit the original ledger | Derived team-scoped entrypoints and references; explicit paths; deny original state |
| F02 — guard is deliberately not relocatable | `controller-write-guard.py`, `canonical_home()`/`resolve_paths()` | Production rejects noncanonical script path and caller-selected root/state; using the original points to original claims | Separate reviewed adaptation with team binding; never deploy test mode or spoof HOME to bypass it |
| F03 — acceptance log follows PROJECT | Director `scripts/accept.py`, `prepare()` | A valid graph update can append to original/target `system/run-log.md` | Implemented local default and rejection of foreign log arguments; project delivery logs remain mission-specific |
| F04 — recovery searches old controllers | Director `references/controllers.md` | Title/project match could commandeer an existing team's controller | Recover only registered TEAM_ID owners; detect other-team ownership as conflict |
| F05 — global hook can reinsert original state | `~/.claude/settings.json` loads `~/.agents/tools/guards/chat_guard.py`; `write_handoff()` inserts `~/Alex-Director/...` when transcript mentions Director | A later handoff could silently reconnect a new team to original state | Inspect effective hooks on selected runtime; isolate or deliberately adapt under separate authority; keep original hook untouched |
| F06 — broad host permissions | `~/.codex/config.toml` safely inspected: `approval_policy=never`, `sandbox_mode=danger-full-access`; global Claude hooks present | Folder and prose boundaries cannot prevent another path/tool write | A restricted execution environment and provider scopes must demonstrate denied out-of-scope actions before trial adoption |
| F07 — historic Bypass differs from global config | Restoration reports approved Bypass; current global Claude settings show `defaultMode=acceptEdits` | Copying one observed value does not reproduce effective session permissions | Record actual trial settings/load evidence; never change security settings or generalize old approval |
| F08 — original shared write destinations | master connector STATUS/run-log/lessons/workbook; `~/.agents/instructions`, shared skills/cards, `~/STACK.md`, `~/Documents/One-Shot-Builder`, global app settings | A copied “done means” or generator updates unrelated shared assets | Keep sources read-only; team/project write targets explicitly listed; do not transplant master repo AGENTS as universal team policy |
| F09 — global scheduler/session state | `~/.codex/automations`, Claude session stores, old Director wake scripts, native app records | Duplicate supervisors, wake loops or late results to old chats | No copied automations, queues or sessions; fresh identities later; scoped schedules only on explicit request |
| F10 — shared account default | Shared rules require explicit `--account` or account/user; org `wearenumber1` | Most recently changed login may belong to another agent | No initial external bindings; each later mission records toolkit, login, resource, allowed action and actual scope |
| F11 — distinct homes, same provider resource | Guard resource key uses provider/account/type/target; separate claim roots cannot see one another | Two independent teams can both claim an overlapping external resource | Disjoint resources for initial trial; one current writer for any shared object; no cross-team mutation until enforcement is proved |
| F12 — fixed role bindings in generators | Build `agents/team-template/materialize.py`, student exporter, Hermes edition builder | Copies role/channel/customer/home assumptions, or requires a mission prematurely | Reuse patterns selectively; initialize mission-free; keep original role packages untouched |
| F13 — thin role pointers and shared changes | Director/Conductor Claude editions; shared standards can change during work | Loading a pointer may change effective policy or point at old home despite a “new” folder | Pin source hashes, keep derived bindings inspectable, refresh explicitly; detect baseline drift |
| F14 — template/helper mismatch | Graph template's protected-write comment; guard counts `## Node:` headings | Table row alone is insufficient for a guarded write | Include the node marker when a fenced node is created; preserve existing schema and inspect all helper assumptions |

## Original identities: evidence-only, never seed values

| Existing identity | Value/pointer | Treatment |
|---|---|---|
| Restored Claude Director | `da73c8be-6556-49cb-afdd-3e70c47b417b` | Read-only historical/current-owner evidence; no resume, fork or dispatch |
| Existing Conductor | `9bc6cee2-392b-42df-a7d3-89efd205bd15` | Retained by original team; never inherited |
| Retired Director | `294b676b-77d8-4d64-976e-70a783b96d65` | Historical only; never restart |
| Original native Director desktop pointer | `local_f0e7fee3-ef14-4430-bff8-fa7d8245fe39` | Not a new return address |
| Original Conductor desktop pointer | `local_7e9c4261-f531-40b8-94ed-1468e93f7b29` | Not a new controller identity |
| Existing mission IDs | `mission-connector-consolidation-finish`, `mission-setup-playbook-parity`, `mission-hermes-agents-skeleton` | No copied active blocks, plays, write generations or approvals |
| Javar/Javante runtime and role identities | Platform/home paths in source map | External target examples, never new team defaults |
| Existing private war-room | Hardcoded in Build materializer; exact value stays in source | No default chat/channel binding or messaging authority |

Historical IDs appear only here/source evidence; the blank assets contain none. The first trial should use an inert deny fixture representing the original home, never deliberately attempt a mutation against the real live team just to test a warning.

## Enforcement requirement

For a same-user process with unrestricted filesystem and account access, a new folder is an organizational boundary only. Prompt compliance can reduce mistakes but cannot substantiate prevention. The later trial needs externally enforced write restrictions covering original state, global settings, target escape paths and account/resource scopes. A separate supported runtime/user/container/profile may be appropriate, but the exact mechanism is an implementation dependency, not configured here. Alex owns security changes.

The source guard is a workflow control for calls that use it; its existence does not prove every native tool, shell command or connector routes through it. Test direct and helper-mediated attempted escape through the actual allowed tool surfaces. A denied call stays denied; the test never switches routes to bypass it.

Two private state stores cannot safely arbitrate one shared external object without a common current owner and enforced access. This draft deliberately leaves overlapping real writes unavailable. It adds no new global registry or supervisor. Broader concurrent access is a separate design decision and trial.

## Reproduction changes versus improvements

The new blank binding, fresh identity namespace, scoped home paths and explicit log destination are necessary adaptations for Alex's requested independent instance. They are implemented and component-checked in the uninstalled candidate; independent runtime behavior is not yet proven. Additional audit ideas about judging intent, preserving commitments or changing prompts are not silently integrated into the reproduced role policy. The trial includes those behaviors to measure the unchanged pattern first; later improvement candidates need separate version labels and comparisons.
