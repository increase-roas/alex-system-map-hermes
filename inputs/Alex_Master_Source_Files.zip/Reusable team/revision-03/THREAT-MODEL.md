# Threat model and evidence boundaries

## Protected objects

The original Director's state, sessions/controllers, approvals, resources, credentials, schedules and installed shared setup are read-only source context or inaccessible runtime targets. Version 0.2 and its failed audit remain immutable. New team state, exact external project paths, canonical mock provider resources and synthetic recipients belong to one fixture host/team at a time.

## Adversarial inputs covered

A worker may execute arbitrary Python/shell code within the delivered subprocess boundary; try absolute/relative paths, symbolic/hard links and helper calls; forge environment identity, binding fields, approval contents, hashes and native-like recipient IDs; replay stale controller/play/generation/claims; and race participating helpers. Deterministic harness instrumentation can replace file leaves/parents exactly between validation and write, or terminate a helper at defined write boundaries. Victims are disposable stand-ins, not original files.

## Trusted computing base

The operating system's Seatbelt enforcement, trusted fixture supervisor, immutable selected helper code, Python runtime and supervisor-owned registries are trusted. The supervisor is outside worker restrictions; workers never receive its object, memory, provider credentials or an arbitrary privileged command endpoint. Its fixed helper launcher supplies a context to one child and verifies generated code fingerprints. The default helper hook remains unavailable outside that route.

Host-created synthetic identity is not a real Codex identity attestation. The fixture host is test infrastructure, not a durable deployment service. A caller with unrestricted host execution could run a renderer, change Python or create its own test driver; that host is explicitly unsupported for activation. This package does not promise to defend against root, a compromised OS, or another unrestricted same-user host process altering the trusted boundary.

## Enforced local controls

| Hazard | Implemented control | Proof |
|---|---|---|
| Caller points at foreign helper/state | Host-owned actor/team registry, immutable helper selection; worker filesystem boundary | Integration foreign principal/helper/environment cases |
| Check/write race | Pinned root descriptor; component no-follow opens; actual-file owner/link checks; descriptor-relative atomic replacement | Original interleave, parent/backup interleave, pinned-home and hardlink cases |
| Contaminated ledger accepted | Mandatory existing graph/auth reference validation before success and lock release | Ledger contaminated graph/foreign or missing authorization cases; guard follow-up |
| Matching caller hashes impersonate approval | Strict existing record plus exact trusted approval digest and mission/play/controller/generation/outcome/scope checks | Missing, self-authored, altered, duplicate-key, stale and revoked authority cases |
| Cross-team resource overlap | Single synthetic host resource registry; unchanged canonical key; required lease at grants and terminal operations | Conflicting team claims; normal claim/replay/concurrency |
| Arbitrary file/credential escape | Candidate-owned sandbox on every helper/worker process and its children; scrubbed environment/closed inherited FDs; no network/GUI bridge | Preflight, direct sibling/private/original read denial, direct state and hardlink escape cases |
| Wrong recipient/recovery/schedule | Synthetic host registry validates every event before recording it; native activation denied | send/queue/resume/schedule/recover foreign recipient refusals; allowed synthetic return |
| Shared policy modification | Read-only runtime grants and local proposal instruction | Shared write denial; final operational review |
| Interrupted or competing writes | Stable locks, persistent logical ledger lock, journaled graph/log rollback-before-retry, unresolved claim markers | 8 competing claims, 4 accepts, crash-before/after-append, stale logical lock tests |

## Explicit limits

- **Native activation remains unsupported.** This runner constrains its subprocesses, not native apps/MCP/connectors/browser/computer actions outside them. No original native recipient was used as an attack target; no native delivery or native rejection was observed.
- **Real credentials/provider permissions remain pending.** Mock resources have one canonical namespace and registry. A real adapter must resolve provider aliases, supply one authoritative current owner, and enforce account/resource scopes. Separate hosts cannot each privately declare ownership of the same real object.
- **Supervisor-death recovery is unavailable.** The synthetic registry is in memory. Rebuilding it from worker state is prohibited. A durable native authority service and revalidation at resume/schedule time are prerequisites.
- **Directory-entry visibility remains.** macOS/descriptor startup requires exact ancestor-directory reads. These reveal entry names, not private sibling file contents. There is no claim of zero name disclosure.
- **Separate ledger updates are not one graph/log/ledger transaction.** Acceptance journals graph/log together; later ledger edits are a separate serialized step. A multi-command ledger session relies on the trusted Director host serializing its own edit flow. Worker code cannot edit the ledger.
- **Acceptance is not globally deduplicated.** Guard effect intents/replays are fenced. Four separate acceptance requests generate four serialized records. An interrupted pending acceptance rolls back then retries without leaving a duplicate record.
- Tests are bounded demonstrations, not a proof over every possible OS exploit or native platform. They do not authorize installation/adoption.
