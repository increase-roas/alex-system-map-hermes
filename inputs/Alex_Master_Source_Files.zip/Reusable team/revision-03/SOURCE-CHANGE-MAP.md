# Source and change map

Revision 0.3 derives from the retained, uninstalled version 0.2. The original Director 2.7 / Conductor 2.5 provenance, baseline identity, home-card reference and supplemental guard/template pins remain in `create-independent-team/assets/source-lock.json`. No changing live file was silently repinned. `source-change-map.json` records every old/new file digest; `changes.patch` contains the actual candidate diff.

| Area | Revision change | Reason |
|---|---|---|
| Setup CLI | Refuses unsupported native activation before writing anything; pure renderer retained for fixtures; generated runtime modules bundled | Caller-supplied identity is not authentication; no supported native all-tool adapter |
| team_paths | Trusted context required; strict authority record and mandatory graph/auth validation | F1/F3/F4, duplicate/foreign identity and scope |
| safe_io (new) | Pinned home descriptor, no-follow path walks, opened-file checks, atomic/exclusive operations and stable locks | F2, links, parents, backups/logs/locks/claims |
| Ledger helper | References validated before release; serialized operations, no age-based lock stealing | Contaminated success and interrupted-write safety |
| Graph/accept helpers | Serialized writes, local log, persistent pending acceptance recovery | Race, competing updates and process interruption |
| Graph lint | Scope failure is a CLI refusal; content quality warnings remain advisory | Full regression caught false-success exit on denied foreign read |
| Controller guard | Safe I/O throughout; trusted current auth/actor/lease required at grants and terminal operations; unresolved transitions retained | F4/F5, replay/concurrency and protected effects |
| restricted_runtime (new) | Actual macOS child-process filesystem/IPC/network boundary; clean env, closed FDs; no fallback | F6 within supported subprocess scope; native tools explicitly outside scope |
| Local roles/procedure | Native gate, no direct transport bypass, shared-card fixes become local proposals, recovery explicitly scoped | Conflicting operational instructions |
| Synthetic verification host | Host-owned invented identities, authority digests, resource/project/recipient registry, immutable fixed helpers | Offline contract testing only; no native/provider integration |

The old transform and smaller tests were copied into assigned scratch before inspection. The old transform was not executed: its hardcoded v0.2 destination and live-source reads were unsafe for this repair. The original harness was copied, inspected and run unchanged under its audited outer boundary; the new harness tests the delivered candidate and explicitly maps all 38 old expectations.

Only revision-03 contains candidate edits. Scratch contains tests, isolated fixtures, iteration receipts and a scratch-only YAML dependency used by the skill validator. No global skill, app configuration, credential, original team state or schedule was edited. Preservation evidence checks the original candidate/audit/report bytes and original harness/transform/test scripts exactly.
