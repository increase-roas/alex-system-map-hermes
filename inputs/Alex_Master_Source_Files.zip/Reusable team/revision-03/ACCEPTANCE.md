# Frozen repair acceptance — 2026-10-03

The unchanged prior harness reproduced 38 checks: 31 pass, 7 fail, zero harness errors. All five outer-sandbox preflight checks passed before reproduction. The outer audit sandbox is test protection, never the claimed candidate runtime.

## Required controls

| Requirement | Required evidence |
|---|---|
| First chat / no mission / external project | Empty manual home, trusted synthetic first identity, zero inherited state, later existing and new external targets succeed. Native first-chat authentication separately pending. |
| F1 identity | Runtime authority comes from the supervising host, never CLI/environment/editable binding. Foreign helper fails under actual candidate restriction. Native attestation missing => activation denied. |
| F2 safe files | No-follow descriptor-anchored operations, redirected leaves and parents unchanged, hardlink attacks denied; locks/concurrency/interrupted writes and recovery verified. |
| F3 ledger references | Foreign/nonexistent graph or authorization record blocks verification before success/lock release. |
| F4 authorization | Exact existing strict record binds owner/mission/play/controller/generation/outcome/scope and trusted authority digest; absent/changed/forged content denied. |
| F5 shared resource | One broker-owned fixture resource registry, unchanged canonical resource keys; second team rejected. Real provider credential scoping remains unsupported. |
| F6 all exposed tools | Candidate-owned restricted subprocess establishes and tests own filesystem/network/process boundary; arbitrary shell cannot access sibling state/private credentials/shared writes/unassigned target. Native app tools are not represented as constrained by this subprocess. |
| Shared policy | Local proposal instead of shared card edits; verified deny under runtime. |
| Native transport | Synthetic host recipient registry denies foreign send/resume/queue/schedule; real native activation denied until equivalent externally enforced controls exist. |
| Behavior | Useful authorized work, controller return, replay denial, concurrency, interruption and recovery preserved. |

Retain every original case safety intent. A case may be reported PLATFORM PENDING, never PASS by treating blanket inactivity as success. Positive controls must exercise restricted operations. No live team, real provider, original chat or schedule is exercised. No original/global installation is edited.

## Design choice

Repair local helpers and add an explicit native activation refusal. Exercise them using a bounded synthetic host with the candidate macOS restriction runner, a host-owned identity/authority/resource/recipient registry and fixed helper entrypoints. This is a local executable reference boundary, not an alternative live orchestration service. An app-wide trusted adapter is unavailable in the intended host; do not build around that absence by secretly enabling other routes.
