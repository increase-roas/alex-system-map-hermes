# Platform boundary investigation — 2026-10-03

## Decision

**Current full-access Codex desktop chat is unsupported for activating the requested independent-team isolation guarantee.** This is a supported-surface/evidence conclusion, not a claim that a real foreign native action was denied. No live team, native message, queue, resume, schedule, credential change, installation or security-setting change was attempted.

Codex 0.160.0 does expose real filesystem/network sandbox controls for local commands. They are useful prerequisites, but the official documentation explicitly excludes connectors, MCP, browser/computer actions and service traffic from that command-policy boundary. No exposed supported desktop route found here supplies an immutable current-chat attestation plus team ownership gates for all those tools and native send/resume/queue/scheduling. A helper cannot supply that host control by validating editable local state.

## Evidence classification

| Surface | Observed or documented capability | Limit and status |
|---|---|---|
| Trusted caller | Host-backed APIs such as `list_artifacts({})` operate on this calling chat; the real call succeeded with `{artifacts: []}`. App-server `thread/start` returns a server-issued thread ID. | The result exposed no attestable caller/team identity for the local helper. A host-scoped action is not an exported identity credential. A trusted integration can retain a returned thread ID out of the agent's reach, but that integration is not delivered here. |
| Environment identity | `CODEX_THREAD_ID` and `CODEX_SESSION_ID` are present in command environment. A child process supplied `CODEX_THREAD_ID=synthetic-foreign-thread` returned that value, exit 0. | Proven mutable. Neither environment nor matching JSON is caller authentication. Values were not printed or recorded. |
| Local command sandbox | CLI `codex sandbox --help` supports permission profile selection, readable roots from sandbox state, disabled network, Unix-socket grants and denial logging. Official permission docs specify macOS Seatbelt and refusal of unenforceable policies. | Documented available, not configured by this investigation. The current task permissions explicitly say danger-full-access, network enabled, approvals never. Earlier audit's sandbox denials are evidence for that test process only. |
| All-tool isolation | Official permission docs explicitly scope profiles to local sandboxed commands and enumerate separate connector, MCP, browser/computer, search and cloud controls. | A command sandbox is insufficient across all exposed tools. A tool catalog contains native app tools and connector surfaces as well as shell. No team-wide all-tool boundary is exposed in this session. No runtime denial was tested for those surfaces. |
| App-server authentication | Installed CLI exposes capability-token and signed-bearer WebSocket authentication. Official docs say this authenticates the connection before initialize. `thread/start`/resume/turn requests carry thread IDs. | Connection authentication is not demonstrated per-team thread authorization. `clientInfo.name` identifies a client; caller-supplied metadata is not authorization. Desktop upstream `attestation/generate` is documented for upstream attestation, not a signed current-chat/team capability offered to this helper. |
| Native messages | `send_message_to_thread` requires a caller-supplied threadId and human messaging authorization; create/read/fork/handoff/manage tools accept thread identities. | Tool instructions establish required agent conduct, not a tested recipient ownership ACL. No schema field adds teamId, mission grant or ownership proof. No authorized safe negative native messaging test was available; no message was sent. |
| Resume/queue | `codex queue --help`: required `--thread <THREAD>` with UUID/exact session name. `codex resume --help`: optional session ID/name; `--all` disables cwd filtering. | Cwd filtering is selection, not a security boundary. These help receipts prove exposed targeting routes, not that a foreign target succeeds. No actual queue/resume operation was invoked. |
| Scheduling | Native `automation_update` supports heartbeat/cron and an update/view ID; heartbeat can specify targetThreadId. Official scheduled-task docs say runs use default host sandbox and typically unattended approvals. | No team ownership prerequisite appears in the exposed schema. Same-account automation ownership is not this mission's team ownership. No automation was inspected, created or changed. |
| Credential/provider authority | Official MCP docs offer server/tool allow/deny configuration; service connections enforce their own scopes. Named account selection is a routing mechanism. | A team must not possess shared Composio/op credentials or another team's session sockets. Allowing one common provider host does not isolate accounts/resources. Provider scope or a trusted resource broker must enforce claims, not caller-supplied `--account`. None was installed/tested. |

## Actual read-only receipts

- `codex --version`: **codex-cli 0.160.0**, exit 0. Executable symlink resolves to `/Users/alexlobaito/.local/lib/node_modules/@openai/codex/bin/codex.js`; installed README points to official Codex docs. No local implementation source sufficient to verify undocumented desktop ACLs was found in that package inspection.
- `codex --help`, `codex app-server --help`, `codex sandbox --help`, `codex queue --help`, `codex resume --help`, `codex app-server generate-json-schema --help`: read-only help only. No app server or agent was started. Schema generation was not performed.
- A standard `/Applications/Codex.app/Contents/Info.plist` lookup found no file. Immediate app inventory under `/Applications` and `~/Applications` found no matching installed Codex bundle. Desktop version therefore **not established**; CLI version must not be substituted for it.
- Native `list_artifacts({})`: succeeded, empty current-chat attachments. No unrelated private chat content was read.
- Composio search rejects `--account`: unsupported flag, not an access denial. Corrected discovery used the logged-in CLI project; `search` has no account argument. Every executing tool call named an account.
- Real official docs reader call: `CUSTOM_OPENAI_DOCS_SEARCH_OPENAI_DOCS --account alex@increaseroas.com`, query `Codex app server sandbox thread identity MCP security`: failed with **No active connected accounts were found for that toolkit**. This is a tested route failure, not a platform isolation denial. No login was linked.
- Exa `EXA_GET_CONTENTS_ACTION --account exa_beode-vain` succeeded after schema read. All requested pages returned per-item `status: success`, `source: crawled`. Initial receipts: `log_P5ZCrVhxJheh`, `log_C8EP6DsxRgws`; follow-up `log_a2uhTsRJAMe2`. Public fetched-page JSON exists in Composio's temporary output files:
  - `/var/folders/06/qyc_28_51q39jydzk73486040000gn/T/composio/adhoc_57b491036a2b/EXA_GET_CONTENTS_ACTION_OUTPUT_32feda28.json`
  - `/var/folders/06/qyc_28_51q39jydzk73486040000gn/T/composio/adhoc_e529dad61a98/EXA_GET_CONTENTS_ACTION_OUTPUT_cbc4354b.json`
- No real outside-file write/read-denial probe was needed or attempted by this investigation. The v0.2 audit retains the existing genuine sandbox preflight denials. Do not reclassify absent exposed routes as tested denials.

## Official supporting sources

1. [Permissions](https://developers.openai.com/codex/permissions/) — beta named permission profiles, deny-read rules, runtime workspace roots, macOS Seatbelt; “What profiles control” and “What the network proxy does not control” explicitly establish the command-only scope. Domain rules require an active proxy. Older sandbox_mode settings can supersede default_permissions unless managed profile requirements apply.
2. [Codex App Server](https://developers.openai.com/codex/app-server/) — server-issued thread IDs; start/resume/turn lifecycle; connection auth and initialize capabilities; upstream attestation; all threads in one app-server process share the selected Code Mode host. WebSocket transport is experimental and unsupported for production. This does not document a team-scoped ACL or current-chat attestation export.
3. [Agent approvals & security](https://developers.openai.com/codex/agent-approvals-security/) — local sandbox and approval distinctions, managed requirements, connector side-effect annotations. The legacy `/codex/security/` URL now retrieved Codex Security scanning-product docs, so it is not used for sandbox claims.
4. [MCP](https://developers.openai.com/codex/mcp/) — server enable/disable, enabled_tools/disabled_tools, local/remote process/transport and OAuth/credential configuration. Server scope is separate from shell sandbox.
5. [Scheduled tasks](https://developers.openai.com/codex/app/automations/) — local project/worktree task execution, current-chat schedules, unattended default permissions, CLI absence of Scheduled management UI. A worktree keeps edits separate; it is not stated to isolate all credentials/tools.
6. [Configuration Reference](https://developers.openai.com/codex/config-reference/) — current config keys. No config or security settings were changed.

## Minimal supported-platform contract

Keep the first empty-folder chat/Director and external-target experience as the desired interface. Permit offline candidate setup and isolated fixture testing now. **Native activation must fail closed** until the host can prove the following prerequisites at setup and at every resumed/scheduled session, with no editable assertion substituted for enforcement:

1. A trusted host/launcher retains the server-created chat identity and records team membership outside agent-writable files. It binds each operation to that caller; the caller cannot pick identity by environment/JSON or gain authority by invoking another helper.
2. The runtime contains only this team's operating home, explicitly assigned external target paths, per-team temporary paths and immutable shared standards. Original/private state, credentials, op/Composio auth stores and foreign app-server sockets are inaccessible. Restrictions cover file tools, command tools and all enabled MCP/apps/browser/computer actions. The effective workspace root set must not include broad `~/Documents/Codex` access.
3. Native transport accepts only trusted owned recipients and fresh generation/mission authority; it verifies send, queue, resume, recovery and schedule ownership before dispatch. No direct bypass native tool or CLI targeting route remains exposed to the untrusted runtime. Required scheduling may not be silently omitted to manufacture a passing platform.
4. A single trusted ownership service or provider-side disjoint permissions prevents two teams claiming the same canonical account/resource. Team helpers cannot manufacture a new resource key to evade conflicts. Grants are brokered without putting broad credentials into the agent runtime.
5. Startup demonstrates allowed useful work and denied synthetic foreign identity/path/account/native target through the actual delivered runtime, then rejects unsupported/mismatched host capability. Every resume and scheduler restores the same controls. Unknown or lost enforcement refuses activation.

These are prerequisites, not an implementation proposal for a new global orchestration system. The smallest justified current product behavior is: preserve locally repaired useful helpers and fixtures, expose native activation as unsupported with these exact missing host proofs, and keep a separately authorized inert native trial pending. A managed permission profile can close part of local command access; it alone cannot clear the complete desktop team guarantee.

## Reviewed request hashes
- `06-fix-and-verify-prompt.md`: SHA-256 `60013f1eef8fdc9567ed9d6a5245933478f1f0d31cb7f8b865f2e3b11cd10c43`
- `05-isolation-stress-audit.md`: SHA-256 `86474c31c37c1ea6b5a91dabb5eb53daba9c64962ab25cb2522c742dda71b256`

## Follow-up: minimal macOS runner startup correction

Read-only diagnosis of the candidate restricted_runtime.py and runner-startup-diagnosis.json reproduced original `/usr/bin/true` SIGABRT (-6). Independently adding `/dev`, `/usr`, or `/private/var/db` reads still returned -6. Adding only **`(literal "/")`** to file-read-data exceptions returned exit 0 for `/usr/bin/true` and the current Python 3.14 `print("STARTED")`, retaining original network, mach, process, write denials and the runner's scrubbed environment. A negative `os.listdir("/Users")` probe still returned PermissionError and printed OUTSIDE_DENIED, exit 0.

The correction must be **literal `/`, never subpath `/`**. Root-directory read is required to launch; this experiment establishes the required read without claiming which private dyld implementation causes it.

Anchored helper directory opens additionally require **literal reads for each existing ancestor directory of the assigned read/write roots**. A follow-up profile added only those canonical literal ancestors. The actual Python directory-open probe successfully opened the assigned path ancestors; opening `/Users/alexlobaito/.agents` remained denied. These literals permit reading directory entries at those ancestor directories, so they reveal ancestor directory names; they do not permit reading sibling file contents or descending into a private sibling. If even ancestor-name visibility is forbidden, this local-process model must not be claimed to meet that stricter requirement.

Recommended minimal code correction: include `(literal "/")` and deduplicated `(literal <canonical-ancestor>)` terms in the `require-any` read exception list, retain assigned roots as subpaths, and retain the default denial on all other data reads. Do not broaden to home or /Users subpaths. Re-run the delivered runner's full permitted-work and foreign-file/network tests after applying. No candidate file or security setting was changed by this investigator.

Exact ancestor-open receipt:
```json
{
  "exit": 0,
  "stdout": "[[\"/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work/reusable-team-setup\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/Documents/Codex/2026-10-03\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/Documents/Codex\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/Documents\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito\", \"OPEN_ALLOWED\"], [\"/Users\", \"OPEN_ALLOWED\"], [\"/\", \"OPEN_ALLOWED\"], [\"/Users/alexlobaito/.agents\", \"DENIED\"]]\n",
  "stderr": "",
  "ancestor_literals": [
    "/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work/reusable-team-setup",
    "/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work",
    "/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in",
    "/Users/alexlobaito/Documents/Codex/2026-10-03",
    "/Users/alexlobaito/Documents/Codex",
    "/Users/alexlobaito/Documents",
    "/Users/alexlobaito",
    "/Users",
    "/"
  ]
}
```
