# Generated contents and implemented controls

The pure renderer emits a fresh TEAM_BINDING, AGENTS, empty DIRECTOR_STATE, empty STANDING_AUTHORIZATIONS, local Director/Conductor editions, graphs/mission templates, local logs and lessons, source lock, team_paths, safe_io, restricted_runtime and write-guard helpers. The platform-specific CLAUDE pointer is retained as an inactive rendering option. It is not native support.

Team/Director IDs in files are routing consistency checks. The trusted host authenticates identities; team files do not. Default helpers refuse because no native adapter is installed. The synthetic host injects its own context only into a fixed helper process under the candidate sandbox. Arbitrary worker code has no bookkeeping write access or access to that registry.

## File and concurrency controls

safe_io pins the team-home directory descriptor, walks components using no-follow directory opens and checks actual opened regular files for ownership and a single link. Reads, atomic replacements, exclusive creates, logs, backup files, stable locks and claim history use these operations. Runtime restrictions prevent a worker relocating state outside permitted paths. A fully privileged hostile host is outside the supported threat boundary.

Atomic files use same-directory temporary files, fsync, and descriptor-relative replace/link operations. Exclusive create permits one winner. Stable flock files are not deleted while concurrent processes might reference them. Ledger backup/verify/restore is serialized; the logical write lock persists across commands and is never taken over by age. This lock still assumes the trusted host serializes that Director's multi-command edit session; a worker has no direct ledger write permission.

Graph and acceptance writes share a transaction lock. Acceptance journals both originals before graph/log changes. It reports success after both writes; a pending journal causes recovery before the next acceptance. This does not make separate later ledger updates one atomic operation, or deduplicate all repeated human acceptance requests. Guard intents retain their original replay and unresolved-effect behavior.

## Mandatory references and authority

Ledger verification checks every mission's identity and requires an existing local graph with matching mission, team and Director before releasing its lock. Non-NONE authorization references must be local, existing and valid; a protected-write fence cannot omit authorization. Unsupported references fail before success.

Authorization JSON schema: `independent-team-authorization/v1`, with team_id, director_thread_id, mission_id, next_play_id, controller_thread_id, positive integer controller_generation, outcome_hash and authorization_scope. Duplicate keys/nonfinite JSON are rejected. Contents must match the current mission, scope and exact host-owned approval digest. Guard grants and terminal operations also require the unchanged canonical resource key in the host's resource lease set.

The synthetic host assigns mock resources from one registry, rejects overlaps without changing keys, and refuses real provider accounts. A live adapter must establish one authority for the real resource namespace and provider-scoped credentials; a second private registry is not an acceptable substitute.

## Evidence limits

The delivered macOS subprocess runner restricts all commands it launches, including their children. It does not restrict Codex native tool calls outside that process. Native send/resume/queue/schedules, real credentials, real provider ownership and native chat identity remain unsupported and unproven. See runtime-contract.md. The enclosing verification uses no native API or original-team mutation.
