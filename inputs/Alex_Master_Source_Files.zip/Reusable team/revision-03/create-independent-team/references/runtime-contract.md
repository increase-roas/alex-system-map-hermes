# Runtime contract and supported-platform limits

## Supported proof scope

Only the isolated synthetic macOS subprocess reference host has been exercised. The candidate runner installs Seatbelt restrictions on every command and descendant it launches, clears ambient environment, closes inherited descriptors, denies network, Mach service lookup/registration, signaling and process inspection, and restricts data reads/writes to host-selected paths. Useful external project work remains available.

Literal ancestor-directory reads are needed for macOS startup and anchored descriptor walks. They disclose directory entry names at those ancestors; they do not permit reading private sibling file contents. This edition does not promise zero filesystem-name visibility.

The trusted host remains outside its workers' sandbox. It owns identity, authority, code fingerprints, resource leases and recipients. Only fixed helper commands receive bookkeeping writes; arbitrary code receives assigned project writes only. Helper code, bindings, approval registries and broad credentials must not be worker-writable. For the fixture host these registries are memory owned by the trusted test driver, not files reachable by workers. They are not a durable native service or a cross-machine resource authority.

The fixture launcher supplies context in a supervisor-created fixed helper process. JSON sent from an untrusted worker is not an authentication mechanism. Running that launcher directly outside its host boundary provides no supported identity guarantee. Standalone production helpers refuse context; native activation remains disabled in code.

## Current native platforms

Codex desktop, Claude Code, Claude app and Cursor activation are **unsupported in this revision**. Only Codex's exposed local surface and current official docs were investigated; no claim is made to have tested a negative action on the other platforms. The gate refuses them until each has an actual reviewed adapter. The current Codex chat uses broad host permissions. Codex command profiles do not govern its native apps/connectors/MCP/browser/computer actions. This script cannot retroactively constrain those tools.

Sources: [Codex permissions](https://developers.openai.com/codex/permissions/), [App Server](https://developers.openai.com/codex/app-server/), [MCP configuration](https://developers.openai.com/codex/mcp/), [scheduled tasks](https://developers.openai.com/codex/app/automations/). See the enclosing PLATFORM-EVIDENCE.md for actual calls, source versions and exact limits. No security configuration was changed.

## Mandatory native prerequisites

A supported adapter must establish all of these before setup, every resume and every scheduled turn:

1. Host-authenticated current chat identity and membership, retained outside agent-controlled inputs. The first manually opened chat becomes Director. A title, environment variable, file, argument or matching ID string is insufficient.
2. Enforced restrictions across **every exposed tool**: original/private team state and session/credential stores inaccessible; immutable shared standards readable only as assigned; explicit external project roots writable; broad op/Composio credentials and foreign native/server sockets absent. No direct native or shell bypass around the broker remains exposed.
3. One authoritative owner for each canonical provider/account/resource and each filesystem target, with overlap refusal. Scope aliases must resolve to the same resource; a new key or independent per-team registry cannot erase a conflict. Provider-side scopes or a trusted broker must enforce the account boundary.
4. Native recipient and schedule ownership checked outside editable state before sends, queue, resume, recovery and schedule actions. Recorded original IDs never become valid recipients by being copied into a mission. Fresh generation/mission authority must govern ownership changes.
5. Effective-load and negative proof through those real tools, then the separate inert native trial. Unknown or lost enforcement refuses activation.

There is no supported single setting to toggle in this candidate. A managed command profile alone covers only part of item 2. The remaining requirement is a host-supported adapter or dedicated isolated host that can enforce all five, reviewed and trialed before this skill activates. Security-setting changes remain Alex's; this local repair neither makes them nor supplies an unsafe blanket script. Native trial and adoption require separate authorization.

## Recovery and authority limits

Host registry loss stops work. Never reconstruct grants or recipients merely from local files. The synthetic host has no resume-after-supervisor-death authority recovery and cannot activate from persisted team state. Real recovery must revalidate the protected registry, current approval and native owner without replaying uncertain effects.

Shared learning stays a local proposal. Approval records carry only scope and evidence; no secrets are included. The fixture account is invented and no provider endpoint is contacted. Synthetic transport events prove the local registry's decision, not native delivery or scheduling.
