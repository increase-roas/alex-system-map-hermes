# Preparation and later mission

## Native activation gate

The CLI checks `require_native_activation` before destination preparation. Every native platform currently receives `activation unsupported`. There is no enable switch. The default runtime context also refuses direct helper use. The setup must remain inactive until a reviewed host adapter supplies every condition in runtime-contract.md. Neither Alex nor an agent can complete this by remembering to paste the right ID or by changing a JSON field.

The pure renderer prepares strings for testing; it does not create a chat or authenticate an identity. The separate fixture host materializes those strings under a disposable root with a host-created synthetic identity. It creates no mission, controller, grant, credential or schedule. It writes exclusively, retains an incomplete marker until the binding is written, refuses nonempty/nested homes and validates source hashes. Fixture output is marked `FIXTURE_ONLY_NATIVE_UNSUPPORTED`.

## Intended supported-host experience

1. Alex manually creates an empty operating folder and opens its first chat.
2. That chat invokes setup. The host authenticates its current identity directly and makes it Director; no second Director is created.
3. Fresh state has zero missions, controllers, approvals, account bindings and schedules. No mission is needed to initialize the home.
4. Alex assigns the mission afterward. The Director keeps bookkeeping here and records the actual target in PROJECT. It can work on a new project or an existing external repo. Read and preserve target instructions and current ownership; do not install the team in that repo.
5. The host grants only assigned paths/resources and creates fresh controller identities under this team. Every play names outcome, acceptance, current authority, allowed resource scope and exact local Conductor path.
6. The native adapter must prove delivery, return, acceptance and recovery. A queued event alone is not observed processing. One scoped schedule may be created only on explicit request, through host-enforced ownership.

This sequence is preserved as the contract for the missing native adapter, not represented as observed behavior.

## Local operations

Bookkeeping calls require trusted host context. They reject foreign state and return addresses, use anchored no-follow operations, and keep logs local even when PROJECT is external. Authorizations require an existing strict record tied to current mission/play/controller/generation/outcome/scope and a digest supplied by the trusted authority owner. Self-authored matching ledger hashes are insufficient.

The host must isolate arbitrary worker code from team state, immutable helpers, authority registry, credentials and other teams. Only its fixed privileged helper entrypoints receive local bookkeeping access. Shared cards and standards may be mounted read-only; recurring fixes go into local maintainer proposals.

## Recovery

Do not steal old locks by age. Ledger failure retains the write lock; use the same host-authorized restore path with the active backup. Graph and acceptance operations serialize on a stable lock. An interrupted acceptance leaves a pending journal; the next acceptance restores graph and log together before retry, while independent graph edits refuse to overwrite unresolved acceptance. Interrupted guard transitions remain unresolved and block replay/rotation. Never recover recipients or schedules outside the host's team registry.

A moved home or changed owner needs a separately reviewed transfer. No path override, symbolic link, mutable environment identity or copied approval is a valid transfer. The current native gate does not offer a transfer API.
