---
name: create-independent-team
description: Prepare or inspect a separate Director/controller operating home whose first chat is intended to become Director, with a mission assigned afterward and new or existing external project targets. This uninstalled revision refuses native activation until a trusted host adapter enforces isolation.
metadata:
  version: "0.3-uninstalled-isolation-repair"
---

# Create an independent team

Alex manually creates the empty operating folder and opens its first chat. That existing chat is intended to become Director when a supported host authenticates it. Do not create another Director or require a mission first. Assign the mission afterward; it may target a new project or an existing external repo. Team state remains in the operating home.

**Current status: local candidate, native activation unsupported.** This bundle repairs the local helpers and supplies a restricted macOS subprocess runner. Its isolated synthetic verification is not an installed live team, native identity proof or permission to access real providers. No available native adapter establishes the complete required boundary. `scripts/prepare_team.py` refuses native activation before writing any destination. `runtime_context` refuses standalone helpers. Editable binding fields, environment values and copied fixture receipts cannot enable these routes.

## On invocation

1. Read this home's applicable instructions and [procedure.md](references/procedure.md). Preserve existing state. A different or nonempty folder requires inspection, never overwrite or an automatic replacement home.
2. Apply the supported-platform gate in [runtime-contract.md](references/runtime-contract.md). In this revision, report the missing native adapter and remain inactive. Do not run a renderer as a workaround, copy fixture state into a live home, create/message/resume chats, or schedule anything.
3. A future reviewed adapter must authenticate the actual invoking chat outside model-controlled input, bind the first chat as Director, create fresh empty state, constrain every tool and credential route, and enforce resource and recipient ownership. That adapter must pass the separate native trial before adoption. No manual flag or JSON status grants authority.
4. Keep the Director loop: freeze the later mission's outcome and acceptance, assign fresh controllers, observe processing, receive evidence, judge acceptance, update local graph/ledger and continue ready authorized work. Use the exact local roles from this bundle. Never recover another team's owners by title, ID in a document, or schedule search.

## Local repair and verification

Read [templates.md](references/templates.md) for helper controls. The renderer is pure and uses the retained source lock; it is available to the isolated fixture host for testing only. Source hashes provide provenance, not authorization.

The verification host outside this skill uses invented identities, mock provider scopes and disposable resources. Every executed helper/worker enters the candidate's sandbox before it can act. Its supervisor registry, not team files, owns identity, authorizations, disjoint resources and recipients. This test host contains no native transport or provider client.

Shared skills/cards stay read-only. Write a local proposal in `system/shared-change-proposals/` for the shared maintainer; do not edit canonical cards or rules without Alex's separate explicit authorization and supported enforcement. See the runtime contract for the complete activation requirements and the enclosing revision's evidence and native-trial steps.

Report **written**, **verified in isolated fixtures**, and **observed in native runtime** separately. Native runtime and adoption remain pending. The original Director, installed skills, chats, resources, approvals and schedules are outside this candidate.
