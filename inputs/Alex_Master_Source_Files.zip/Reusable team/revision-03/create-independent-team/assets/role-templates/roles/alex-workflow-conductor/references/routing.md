# Routing: path, skills and coach mode

Read when choosing a route or a skill, or when Alex says he wants to do it himself. Moved from the
conductor's v2.1 SKILL.md; changed: the headings, the stale STACK.md path-order pointer, and the
durable-fix row (now the canonical-home rule).

## Path order and skills
Loop: what stage are we in → what's unknown → which path or skill closes it → apply per mode
authority → what did we learn → what stage now.

**Path order** (what exists: `~/STACK.md` and the tool cards; don't re-audit the account):
1. existing proven API / CLI / MCP / structured integration (Composio first, per the shared rules)
2. existing reliable automation or tool
3. browser / UI (tool card `browser-and-computer`)
4. new tooling only if truly required
Before falling back, reuse settled capability evidence while it's current; otherwise check the
actual commands and how they compose, and compare total time, reliability, manual work and proof.
Use the browser when the structured path is incapable, inaccessible, or materially slower or less
reliable. Alex's explicit tool choice is binding. For an optional tool hint, find out what the tool
is, where it runs and how it's invoked before comparing alternatives.

Load a skill only when it closes the current unknown; never force every installed skill onto a task.
| Condition | Route |
|---|---|
| Observed stall, bug or failed test | `ce-debug` if installed; otherwise isolate the failing layer. `systematic-debugging` only after an observed failure |
| Failure or decision that depends on an external product, API, version or platform limit | Check current official docs before the first fix, by the research route in the Director skill's `references/execution.md`. Skip when local logs already show the cause |
| Implement an existing plan | `ce-work` if installed |
| Verified recurring fix needs durable guidance | Write a team-local fix or local shared-maintainer proposal (Director `references/execution.md` → Durable fixes); shared cards remain read-only |
| Simple factual question | Answer directly |
| Large, messy, cross-client or source-ambiguous work | `mission-intake-and-approval-gate` if available |
| Unfamiliar repository | `plain-english-repo-explainer` if available |
| Doubt that the project/harness is a safe foundation, or Alex asks | `first-principles-project-auditor` if available; else inspect that uncertainty |
| Integration, webhook, CRM or system-of-record decision | `integration-fit-and-source-of-truth` if available |
| Design still unknown | brainstorming, if installed |
| Accepted design or execution plan | Reuse it; no new brainstorming/spec/plan approval cycle |
| Approved multi-step design needs a plan | a planning skill, if installed and useful |
| Feature or behavior change | smallest change; TDD only if installed and tests are the right proof |
| Work needing isolation | a worktree, only if needed and available |
| Any completion claim | current authoritative proof; verify changed or unproven scope against the real system (`verification-before-completion` if useful and installed) |
| Verified branch work complete | finish the branch, if that skill is installed |
Don't invoke `lfg` unless Alex asked to ship a PR.

## Coach mode
**Coach mode** (Alex says he wants to do it himself): pick the same best path you'd execute, but
don't execute. Explain only the current next step in plain English (not the whole procedure unless
he asks), mention useful shortcuts, then wait after each step. Offer once to take over if that
clearly saves effort or risk; switch only on explicit approval. Don't ask which tool to use unless
it's a genuine business preference. Flow status stays `WAITING ON ALEX` unless he asks for several
read-only steps.
