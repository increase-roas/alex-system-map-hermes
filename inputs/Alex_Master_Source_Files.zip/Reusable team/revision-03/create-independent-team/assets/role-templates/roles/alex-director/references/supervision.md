# Native supervision gate

This revision cannot activate native supervision. A future host adapter must enforce team ownership for schedule creation, updates, wakeups, queue and recovery; local IDs are never sufficient. The remaining procedure applies only after that adapter and its trial are verified. Synthetic schedule events in offline tests are not running jobs.

# Supervision scope for this edition

All Director, backstop and controller recovery below is limited to this TEAM_ID. No scheduler is created by setup; recurring supervision needs an explicit later request.

# Supervision: check-ins, wakes and readback

## The check-in
- For ongoing supervision Alex requested: ask the trusted host for only schedules it owns for this TEAM_ID first, then create
  or update **one** scoped backstop heartbeat on the supervising Director chat, the chat Alex
  reads: create it from that chat with `destination=thread`, or name that chat as the target. A
  check-in bound to another chat (an observer) puts its line where Alex doesn't look; move it.
  Cadence: every **25 minutes**, as a **silent** backstop (Alex, 2026-10-02: no timed pings, "ping me
  like u do"). Controller sends are the primary wake (Conductor →
  Report); the backstop catches missed sends and stuck jobs, because a cross-thread send has no delivery receipt
  and can fail (three sends to the Dynamite Director failed on 2026-10-02 with no retry). Both
  cadence keeps every wake inside the 30-minute prompt-cache lifetime (cached input is billed at a
  tenth). A wake costs about the bound chat's whole context in cached input (the Dynamite observer
  read ~407K tokens per wake), so keep the check-in on the Director chat, not a bigger one. Don't
  create one merely because a one-step task exists. Register every active controller chat/task ID
  in its scope, local owners included. Record the actual automation ID and schedule after reading
  it back.
- No per-controller reminders, no duplicate reminders, no reviving unrelated parked missions, and
  no separate fixed deep-audit timer.
- Use the app's automation tool: no daemon, launchd job, cron or shell polling loop, no second
  supervisor or checker agent, and no automatic model switch to simulate a cheaper pass.
- Configured is not observed firing. Delivery depends on the app and host; a busy or offline
  period doesn't prove a controller failed. Don't claim host-independent monitoring or exact
  five-minute delivery.
- Each wake still runs in this chat's full context and model, so it isn't free. That is why an
  unchanged wake must exit fast.
- Pause the reminder when its work is complete or every remaining step needs Alex, after
  reporting that once.

## Pings: only when something happens
Alex, 2026-10-02: "can we turn that shit off? so it pings me like u do". No timed "still working"
pings. Message Alex (`NOTIFY`) only on a real event, in plain words with no IDs, hashes or ledger
shorthand: a controller's result (tell him the moment it arrives, never wait for a check-in), a
failure or blocker, a job that looks stuck (a promised checkpoint overdue, or a finished controller
whose report never arrived: say so and what you did about it), or a decision, permission or
sign-in only he can give. Put that rule in the heartbeat prompt itself. An unchanged check-in ends
with `DONT_NOTIFY` and a short quiet-status message; never an empty reply. Inside your own turns,
keep narrating as you work (one plain line before each long step), so he never has to ask "did it
finish?".

## A wake
1. Reuse the registered scope and earliest unprocessed native turn pointers from mission state.
2. Take one compact batch snapshot of registered chats' status and unseen results (reuse a fresh
   same-cycle snapshot if one exists).
3. **Unchanged** and no promised checkpoint overdue: stay quiet (`DONT_NOTIFY`; Pings). No skill or ledger reread, no transcript
   reading, research, tests, artifacts or subagents.
4. **Material change** (completion, explicit failure or blocker, completed chat with a missing
   result, overdue promised checkpoint): reread `SKILL.md` and home `AGENTS.md`, judge against
   frozen acceptance, leave progressing controllers alone, resume an idle controller that has
   ready work once, and record compact state changes.
5. Five minutes without a message is not a stall and never clears or reassigns work.

## Reconciling a cycle (material wakes)
1. Judge unseen final messages and checkpoints once, then record their processed pointers.
   Don't rescan transcripts or raw logs for ordinary progress.
2. Accept reports that match the assigned outcome, required checks and evidence pointer; update
   graph and ledger. If a result is absent or contradictory, recover that exact native turn or
   action record once, then send one specific correction to the same controller. Never replay an
   uncertain action.
3. Investigate only a specific contradiction, error, missing result or owner-reported failure,
   and send the focused diagnosis to the responsible controller. Don't rerun tests or commission
   a second audit of completed work.
4. For an idle controller with ready work, send one concrete next outcome (naming a Superpowers
   skill only when its trigger applies). Confirm processing by native status or readable acknowledgment.
5. Park only a blocked node and dispatch the next ready authorized outcome in the same cycle.
   Manual entry, owner review or an approval wait never idles independent work. Keep the mission
   `ACTIVE` while any authorized node is ready or progressing; a heartbeat never leaves
   `WAITING_ON_ALEX` on a mission that has `READY` work. A time gate records its unlock time and
   doesn't block independent work.
6. Before yielding, use the fresh snapshot or take one, consume newly finished results, and record
   the heartbeat ID, scope, current owner and next action. Yielding with working controllers and
   an enabled check-in is valid.
7. If exact-turn recovery returns nothing, label it `NOT_PROVEN` and report the readback failure
   instead of redispatching.
8. If an authorized notification is denied, keep the native checkpoint; don't retry through
   another route or ask Alex to relay it. After owner Q&A, consume new results and continue
   independent work. Don't suggest unrelated projects or send repetitive no-ready alerts.

## Serializing your own reviews
A wake requests a refresh; it doesn't interrupt a coherent decision in progress. Finish and save
the current decision first. Handle Alex's stop, correction or authority revocation, and urgent
safety failures, at the next safe boundary. Coalesce repeated ticks and unchanged status into one
pending review with no backlog replay. Never coalesce away distinct owner instructions,
rejections, approvals, failures or inbound contact responses. Fetching a cursor isn't judging it:
keep the earliest unprocessed turn pointer until its judgment is recorded.

If several changed missions can't be judged in one pass, keep compact pending pointers keyed by
controller and current generation/assignment in their existing mission state (`REMAINING`,
`NEXT_PLAY` and checkpoint pointers usually suffice; add a minimal pending field only when needed,
and clear it when empty). No separate queue, database or tick log. Never delete mission state,
accepted checkpoints, approvals or action records to clear a signal. After an interruption, resume
pending pointers before any broad rescan. Reconcile a stale generation or assignment read-only, and
discard an obsolete wake only after preserving any unfinished outcome; never replay an uncertain
side effect. Order: urgent boundaries, then work-unblocking items, then oldest. Review each
controller at most once per pass.

## Readback order
1. Native `read_thread` / task readback.
2. Other native turn or agent-message surfaces the client exposes.
3. If a completed turn shows no assistant items, bounded recovery may inspect that exact turn's
   records; internal databases and rollout files are diagnostic fallbacks only.
4. Still unproven: label `NOT_PROVEN`. Never infer failure, archive or replace a thread from an
   empty projection alone.

## Other teams and historical schedules

Other teams and historical global schedules are outside this binding. Do not pause, revive, migrate or adopt them. Recover only schedules explicitly registered for this TEAM_ID.
