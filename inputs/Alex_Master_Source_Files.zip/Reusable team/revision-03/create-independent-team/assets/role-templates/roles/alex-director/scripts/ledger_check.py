#!/usr/bin/env python3
"""Mechanical write safety for @@TEAM_HOME@@/DIRECTOR_STATE.md.

  ledger_check.py backup LEDGER [--by NAME]
      Takes the write lock (LEDGER.lock) and copies LEDGER to LEDGER.bak.
      Run immediately before any write, then read the ledger fresh and edit.
      If another writer holds the lock, it fails: don't edit, retry on the next wake.
  ledger_check.py verify LEDGER --mode append --mission "Exact name"
  ledger_check.py verify LEDGER --mode edit   --mission "Exact name"
  ledger_check.py verify LEDGER --mode merge  --mission "Surviving name" --absorbed N
      Compares LEDGER against LEDGER.bak. On OK it releases the lock.
      On FAIL it exits 1 and keeps the lock: run restore.
      Team/mission graph and existing authorization references are mandatory checks.
      After an OK it prints optional graph staleness warnings.
  ledger_check.py restore LEDGER
      Copies LEDGER.bak back over LEDGER and releases the lock. Refused when no lock
      is held, because the .bak would then be from an older write cycle.

A mission block runs from its "## Mission: <name>" heading to the next "#" or "##"
heading (or the end of the file). Headings inside HTML comments or fenced code are
ignored. Trailing blank lines at the end of a block don't count as a change.
Locks are never stolen by age. Interrupted writes require explicit restore/reconciliation.
"""
import difflib, os, re, shutil, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).absolute().parents[3] / "scripts"))
import team_paths as scope
import safe_io as io


FIELDS = ["MISSION_ID", "OWNER_OUTCOME", "ACCEPTANCE", "PRIORITY", "PROJECT", "CONTROLLER",
          "MISSION_GRAPH", "ACCEPTED_CHECKPOINT", "REMAINING", "NEXT_PLAY", "NEXT_PLAY_ID",
          "LAST_DISPATCH", "LAST_RECEIPT", "LAST_RECONCILED_AT", "OWNER_BOUNDARY", "STATUS"]
LOCK_TTL_S = 600
MISSION = re.compile(r"^## Mission: (.+?)\s*$")
HEADING = re.compile(r"^#{1,2}\s+\S")
STATUS_LINE = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*|`)?STATUS(?:\*\*|`)?\s*:", re.M)
F = r"(?:\*\*|`)?\s*:\s*(?:\*\*|`)?\s*"  # field separator tolerant of bold/code marks


def _blank(m):
    return re.sub(r"[^\n]", " ", m.group(0))


def blocks(text):
    clean = re.sub(r"<!--.*?-->", _blank, text, flags=re.S)
    clean = re.sub(r"^(`{3,}|~{3,})[^\n]*\n.*?^\1[ \t]*$", _blank, clean, flags=re.S | re.M)
    lines, raw = clean.split("\n"), text.split("\n")
    out, i = [], 0
    while i < len(lines):
        m = MISSION.match(lines[i])
        if not m:
            i += 1
            continue
        j = i + 1
        while j < len(lines) and not HEADING.match(lines[j]):
            j += 1
        out.append((m.group(1), "\n".join(raw[i:j]).rstrip()))
        i = j
    return out


def fail(msg, code=1):
    print("FAIL:", msg)
    sys.exit(code)


def take_lock(ledger,by):
    # No timed lock stealing. Interrupted writes require explicit restore.
    try: io.atomic_write(ledger+'.lock',by+' at '+time.strftime('%Y-%m-%dT%H:%M:%S'),exclusive=True)
    except FileExistsError: fail('ledger has an unresolved write; restore or reconcile before editing')


def release_lock(ledger):
    io.unlink(ledger+'.lock')


def lint_graph(block):
    """Print the mission graph's staleness warnings. Read-only; never changes verify's result."""
    m = re.search(r"MISSION_GRAPH(?:\*\*|`)?[ \t]*:[ \t]*(?:\*\*|`)?[ \t]*([^\n`*]+)", block)
    if not m or not os.path.isfile(os.path.expanduser(m.group(1))):
        return
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import graph_lint
        p = re.search(r"(?m)^[ \t]*(?:[-*][ \t]*)?(?:\*\*|`)?PROJECT(?:\*\*|`)?[ \t]*:[ \t]*(?:\*\*|`)?[ \t]*(~?/[^\s`*]+)", block)
        warns = graph_lint.lint(m.group(1), project=os.path.expanduser(p.group(1)) if p else None)
    except Exception as e:
        print(f"WARN: graph lint skipped ({type(e).__name__}: {e})")
        return
    if warns:
        print(f"Graph lint for {m.group(1)} (warnings only; nothing blocked):")
        print("\n".join(warns))


def run():
    a = sys.argv[1:]
    if len(a) < 2:
        print(__doc__)
        sys.exit(2)
    cmd, ledger = a[0], a[1]
    try:
        home, binding = scope.bound_home(__file__)
        scope.require_role(home,binding,"director")
        ledger = str(scope.ledger_path(home, ledger))
    except (scope.ScopeError, OSError) as exc:
        fail(str(exc))
    opt = lambda k: a[a.index(k) + 1] if k in a and a.index(k) + 1 < len(a) else None
    if cmd == "backup":
        take_lock(ledger, opt("--by") or "unknown")
        io.copy(ledger,ledger+".bak")
        print("lock taken; backup written:", ledger + ".bak", "- now read the ledger fresh and edit")
        return
    if cmd == "restore":
        if not os.path.exists(ledger + ".lock"):
            fail("no active backup lock: the .bak may be stale and restoring it would erase other writes. Don't restore; report this.")
        io.copy(ledger+".bak",ledger)
        release_lock(ledger)
        print("restored from", ledger + ".bak", "; lock released")
        return
    if cmd != "verify":
        print(__doc__)
        sys.exit(2)
    if not os.path.exists(ledger + ".lock"):
        fail("no write lock: run backup before editing (the .bak may belong to another write)")
    mode, name, absorbed = opt("--mode"), opt("--mission"), int(opt("--absorbed") or 0)
    if mode not in ("append", "edit", "merge") or not name:
        fail("need --mode append|edit|merge and --mission", 2)
    before = blocks(io.read_text(ledger+".bak"))
    after = blocks(io.read_text(ledger))
    try:
        for _, body in after:
            scope.validate_references(home,binding,body)
    except scope.ScopeError as exc:
        fail(str(exc))
    names = [n for n, _ in after]
    dups = sorted({n for n in names if names.count(n) > 1})
    if dups:
        fail(f"duplicate live mission headings: {dups}")
    b, af = dict(before), dict(after)
    if name not in af:
        fail(f"target mission '{name}' not found after write")
    expected = {"append": len(before) + 1, "edit": len(before), "merge": len(before) - absorbed}[mode]
    if len(after) != expected:
        fail(f"mission count {len(after)}; expected {expected} for {mode}")
    if mode == "append":
        if name in b:
            fail("appended mission already existed before the write")
        if names[-1] != name:
            fail("appended mission is not the last live mission")
    for n, body in before:
        if n == name or (mode == "merge" and n not in af):
            continue
        if af.get(n) != body:
            fail(f"unrelated mission '{n}' changed (must stay byte-identical)")
    tb = af[name]
    if not STATUS_LINE.search(tb) and (mode == "append" or STATUS_LINE.search(b.get(name, ""))):
        fail(f"target mission '{name}' has no STATUS line")
    if mode == "merge":
        m = re.search(r"MERGED_MISSION_IDS[^:\n]*:\s*(.+)", tb)
        if not m:
            fail("surviving block lacks MERGED_MISSION_IDS")
        listed = {t for t in re.split(r"[\s,;`*\[\]()]+", m.group(1)) if t}
        for n, body in before:
            if n in af:
                continue
            mid = re.search(r"MISSION_ID" + F + r"([^\s`*]+)", body)
            key = mid.group(1) if mid else n
            if key not in listed:
                fail(f"absorbed mission '{n}' ({key}) not named in MERGED_MISSION_IDS")
    if re.search(r"STATUS" + F + r"MISSION_COMPLETE", tb) and not re.search(r"NEXT_PLAY_ID" + F + r"NONE", tb):
        fail("MISSION_COMPLETE requires NEXT_PLAY_ID: NONE")
    missing = [f for f in FIELDS if not re.search(rf"\b{f}\b", tb)]
    if missing:
        print("WARN: target block missing fields:", ", ".join(missing))
    diff = list(difflib.unified_diff(b.get(name, "").splitlines(), tb.splitlines(),
                                     "before", "after", lineterm="", n=0))
    print("Target block diff (confirm it is exactly the intended change):")
    print("\n".join(diff) if diff else "(no change)")
    release_lock(ledger)
    print(f"OK: {mode} of '{name}' verified; {len(after)} live missions; others unchanged; lock released")
    lint_graph(tb)


def main():
    try:
        home,binding=scope.bound_home(__file__)
        scope.require_role(home,binding,'director')
        with io.locked(home/'system'/'.ledger-transaction.lock'): run()
    except (OSError,ValueError) as exc:
        fail(str(exc))


if __name__ == "__main__":
    main()
