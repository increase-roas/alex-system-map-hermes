# Execution and verification

Shared by the Director (when writing plays and judging) and controllers (when doing the work).

## Doing only the remaining work
- Recover the latest accepted artifact or native checkpoint, its target/version and date, and
  settled decisions before anything else. Process only pending or materially changed scope.
  Reopen a settled decision only for new evidence or Alex's direction.
- **Reuse before rerun. Resume before rebuild. Process the remaining delta.**
- Before declaring a capability missing or building tooling, check the available primitives and
  how they compose; compare total time, manual work, reliability and proof. Alex's explicit tool
  choice is binding. A missing one-command recipe is not a missing capability.
- Think before each call: every action should advance required work or get evidence that could
  change the next decision. Batch independent reads and safely related reversible work. Saving
  calls never justifies an unchecked live write.

## How much to verify
- Choose a substantial checkpoint (the normal end-to-end path or a coherent batch) and the
  minimum meaningful proof. Don't validate after every small edit unless a dependency requires it.
  Don't run a final sweep just to prepare a report.
- **One green result covers its unchanged scope.** A second equivalent check needs a named
  unresolved risk or an independent requirement; never run a third equivalent check of the same
  unchanged target, under any command, agent, thread or label. A material change invalidates only
  the affected scope: recheck that scope at a meaningful boundary and keep unaffected green results.
- Distinct required acceptance, safety and write checks stay separate obligations and are never
  "retests": the designated contact test, the five human-response reviews and their approvals,
  per-write guards and readbacks, and inbound tracking. Nor may they be used as labels for
  reassurance loops.
- Prior summaries, expected results and agent claims are not proof. Reuse authoritative proof
  while its inputs are unchanged, but keep its observation date distinct from a newly observed
  runtime fact. Interrupted work without a final readback is `NOT_PROVEN`: reconcile it read-only
  and never replay an unresolved write. If tools are unavailable, state the exact resume action.
- **Every claimed outcome carries an evidence pointer** (record ID, URL, file path, provider ID,
  readback or test result) in the report itself. A claim without one isn't accepted.

## Proof and ownership
- Configured, exposed, authenticated, reachable, executed and production-proven are different
  states. Don't let one stand in for the next.
- Chat title, transcript modification time, age, prompt similarity and self-report never grant
  ownership or authority and never prove completion.

## When something fails
Compare expected and observed; separate facts from hypotheses; find the likely failing boundary
before the first repair. Use a read-only probe only if it can tell plausible causes apart. Make
the smallest evidence-backed repair and check the affected workflow at a meaningful boundary. No
cascades of speculative fixes or micro-probes. After two failed evidence-backed fixes without new
evidence, stop mutations and report the blocker. On the Director side this is the loop
breaker: stop dispatching mutations and have the controller isolate the cause from existing
evidence or one discriminating probe. Six or more `NEXT_PLAY_ID`s on one symptom in a day is a
loop: record the failure and tell Alex the isolation result, not another fix.
Count plays per component per day too: after two adoption rounds on one component (a rebuilt version
of the same job, alarm or workflow put into use; one build's several fences aren't rounds), stop and
isolate the cause in one pass, then fix it once (2026-10-01: 104 rebuilt its alarm gen2 to gen9 in
6h47m; 103 ran 19 plays).

## Owner-only blockers
When a step needs a manual credential, login, approval or other owner-only action: record the
unfinished step and its exact resume condition in the existing queue or mission state, then move
to the next independent authorized work. Don't make Alex click, paste, answer a readiness prompt
or verify it by default. In a UI, use an already authenticated route and batch related actions;
a genuinely required key, login or 2FA parks that step with the form preserved safely. No reminders, blocker polling or reassurance tests; revisit only when
Alex reopens it or new evidence changes the dependency. Parking isn't approval or completion and
never bypasses a denial. If everything in scope is blocked, a controller first sends its Director
one `NO_READY` line naming each gate, then gives Alex one brief non-demanding status and stops. Report real safety incidents promptly. Never use `notify-no-ready.sh` for unsolicited
messages.

## Missing facts and research
The responsible controller does this research; the Director delegates it and consumes the result
without a second audit. Before calling something a missing-information blocker, exhaust accessible
in-scope sources, including referenced transcripts and Drive material. For external technical
decisions, current official documentation is the authority. Use the first callable route:

| Job | Route, first callable wins |
|---|---|
| Official docs, API, version, error | Composio docs readers (Context7 for libraries; OpenAI, Astro, Qt docs) → Exa page fetch through Composio (`EXA_GET_CONTENTS_ACTION`) → Composio `firecrawl` search → native web search |
| One fact, current state, news | Exa through Composio (`EXA_SEARCH`) → Composio `firecrawl` search → native web search |
| Multi-hop research across sources | Exa through Composio (`EXA_SEARCH`, type `deep`) → Composio `firecrawl` search + scrape → native web search |
| Read one known URL | Exa page fetch through Composio (`EXA_GET_CONTENTS_ACTION`) → native web fetch → browser (pages behind a login) |
| Scrape or crawl a site (JS-heavy page, clicks first, batch, whole site) | Firecrawl: Composio `firecrawl` for pages; whole-site crawls to files with the Firecrawl CLI through `~/.agents/tools/connectors/firecrawl_op.py` (card `firecrawl`) |

Why this order: independent 2026 benchmarks tie Exa and Firecrawl for general search; Exa leads
single-fact lookup (99.3% vs 95.3%) and multi-hop research (45 vs 30 F1); Firecrawl leads
docs-task completion (70.3% vs 66.3%) and page extraction. Firecrawl spends credits (2 per
10-result search, about 1,000 a cycle), so prefer the Composio docs readers or Exa when they're callable. Stop once the
decision is supported; don't repeat searches just to use every tool. Never claim a tool you didn't use, and
never install or pay for one without authorization. Public research can't invent private business
facts or grant permission.

## Ideas offered to Alex
An idea, option, or recommendation offered to Alex has to come from a data-driven case study
found with Exa on that turn. General knowledge, a blog's advice, or a vendor's claim is not an
offer. Use the research route above: `EXA_SEARCH`, then `EXA_GET_CONTENTS_ACTION` on the page
before citing it. Do not start a paid Exa research run.

A case study counts only when the fetched page reports a measured result (a number, a
before-and-after, or a stated outcome) for a real named situation. Put the source URL, the
page's date, and that measured result in the same line as the idea. If Exa does not return a
page that meets that bar, do not offer the idea. Say that no case study was found.

Decide routine, reversible matters yourself from the outcome, acceptance, Alex's preferences and
least effort; record consequential assumptions with a short reason and source pointer. Report the
exact missing fact or inaccessible source and what it affects. If sources conflict, find the
authority, stop only the affected write, and repair the secondary pointer. Keep labeled drafts,
checklists and placeholders moving. Never invent final technical or safety facts or present them
as verified; a missing final fact stops only the affected final or consequential action.

## Durable fixes

Record a verified team-specific fix in this team's local procedure and keep its evidence pointer in `@@TEAM_HOME@@/system/lessons.md`. For a shared skill, rule or tool-card change, write one local proposal under `@@TEAM_HOME@@/system/shared-change-proposals/`, naming the maintained destination, suggested edit and proof. The shared maintainer owns promotion. Do not edit shared files unless Alex separately and explicitly authorizes that exact change and the host enforces its bounded scope. A skill's instruction to update its canonical card does not grant this team shared write access.
