#!/usr/bin/env python3
"""Close one accepted result in one command: the node's graph cells and its run-log line, both or neither.

  accept.py --graph GRAPH --node ID --status STATUS --evidence TEXT --receipt TEXT --next TEXT
            --job TEXT --result TEXT [--corrections TEXT] [--run-log PATH]

Sets STATUS, LAST_RECEIPT, NEXT_ACTION and UPDATED_AT (UTC, now), adds TEXT to EVIDENCE after "; ", then appends
  YYYY-MM-DD | job | result (graph MISSION/NODE -> STATUS at UPDATED_AT) | corrections
to the run-log (default <TEAM_HOME>/system/run-log.md, independent of PROJECT; corrections default "none").
STATUS starts with READY, BLOCKED, ACTIVE, READY_FOR_OWNER, VERIFIED, FAILED or WAITING_ON_ALEX. No value may hold
" | " or a line break. A durable pending journal stores both originals before writing the graph and log; an
interrupted call restores both before its next retry. A failed append restores both. A graph without LAST_RECEIPT and UPDATED_AT columns is refused: run the migration in
migrations/ with graph_edit.py first. Other cell edits: graph_edit.py. Staleness check: graph_lint.py.
"""
import argparse, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).absolute().parents[3] / "scripts"))
import team_paths as scope
import safe_io as io

from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import graph_edit as ge  # noqa: E402

STATUSES = ("READY", "BLOCKED", "ACTIVE", "READY_FOR_OWNER", "VERIFIED", "FAILED", "WAITING_ON_ALEX")
MIGRATION = "migrations/2026-10-02_add-receipt-columns.json"


def prepare(a):
    """Everything is checked and built in memory before any write. Raises ge.Refused."""
    home, binding = scope.bound_home(__file__)
    scope.require_role(home,binding,"director")
    path = str(scope.graph_path(home, a.graph))
    before = io.read_text(path)
    scope.check_text_identity(binding, before)
    t = ge.Table(before)
    for col in ("STATUS", "EVIDENCE", "LAST_RECEIPT", "NEXT_ACTION", "UPDATED_AT"):
        if col not in t.cols:
            raise ge.Refused(f"the graph has no {col} column; run {MIGRATION} with graph_edit.py first")
    status = ge.check_cell("STATUS", a.status)
    word = status.split()[0] if status else ""
    if word not in STATUSES:
        raise ge.Refused(f"STATUS {status!r} must start with one of {', '.join(STATUSES)}")
    i = t.find(a.node)
    c = t.cells(i)
    stamp = ge.now_stamp()
    evidence = ge.check_cell("EVIDENCE", a.evidence)
    k = t.col("EVIDENCE")
    c[k] = evidence if c[k] in ("", "-") else c[k] + "; " + evidence
    c[t.col("STATUS")] = status
    c[t.col("LAST_RECEIPT")] = ge.check_cell("LAST_RECEIPT", a.receipt)
    c[t.col("NEXT_ACTION")] = ge.check_cell("NEXT_ACTION", a.next)
    c[t.col("UPDATED_AT")] = stamp
    t.put(i, c)
    t.stamp_file(stamp)
    job, result, corrections = (ge.check_cell(n, v) for n, v in
                                (("job", a.job), ("result", a.result), ("corrections", a.corrections)))
    if not job or not result:
        raise ge.Refused("--job and --result can't be empty")
    run_log = str(scope.log_path(home, a.run_log))
    if not os.path.isfile(run_log):
        raise ge.Refused(f"run-log not found: {run_log}")
    mission = ge.header_value(t.lines, "MISSION_ID") or os.path.splitext(os.path.basename(path))[0]
    line = (f"{datetime.now().strftime('%Y-%m-%d')} | {job} | {result} (graph {mission}/{a.node} -> {word} at {stamp})"
            f" | {corrections or 'none'}")
    return path, before, t.text(), run_log, line


def run():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for name in ("--graph", "--node", "--status", "--evidence", "--receipt", "--next", "--job", "--result"):
        ap.add_argument(name, required=True)
    ap.add_argument("--corrections", default="none")
    ap.add_argument("--run-log")
    a = ap.parse_args()
    try:
        path, before, after, run_log, line = prepare(a)
    except (ge.Refused, OSError, scope.ScopeError) as e:
        print(f"REFUSED: {e}. Nothing written.")
        sys.exit(1)
    home,binding=scope.bound_home(__file__)
    journal=home/'system'/'.accept-pending.json'
    old_log=io.read_text(run_log)
    pending={'schema':'accept-transaction/v1','team_id':binding['team_id'],'graph':path,'before':before,'run_log':run_log,'log_before':old_log}
    io.atomic_write(journal,__import__('json').dumps(pending),exclusive=True)
    ge.backup(path)
    ge.write_atomic(path, after)
    try:
        io.append(run_log,line)
    except (OSError,ValueError) as e:
        ge.write_atomic(path, before)
        io.atomic_write(run_log,old_log)
        io.unlink(journal)
        print(f"FAILED: run-log append failed ({e}); the graph is back as it was. Nothing written.")
        sys.exit(1)
    io.unlink(journal)
    print(f"OK: {a.node} updated in {path} (backup {path}.bak)")
    print(f"run-log {run_log} +1 line: {line}")


def recover(home,binding):
    journal=home/'system'/'.accept-pending.json'
    if not io.exists(journal): return
    pending=scope.strict_json(io.read_text(journal))
    keys={'schema','team_id','graph','before','run_log','log_before'}
    if not isinstance(pending,dict) or set(pending)!=keys or pending['schema']!='accept-transaction/v1' or pending['team_id']!=binding['team_id']:
        raise scope.ScopeError('invalid interrupted acceptance transaction')
    graph=scope.graph_path(home,pending['graph'])
    log=scope.log_path(home,pending['run_log'])
    scope.check_text_identity(binding,pending['before'])
    io.atomic_write(graph,pending['before'])
    io.atomic_write(log,pending['log_before'])
    io.unlink(journal)
    print('Recovered interrupted acceptance; graph and log restored before retry.')


def main():
    try:
        home,binding=scope.bound_home(__file__)
        scope.require_role(home,binding,'director')
        with io.locked(home/'system'/'.graph-transaction.lock'):
            recover(home,binding)
            run()
    except (OSError,ValueError) as exc:
        print('REFUSED:',exc); sys.exit(1)


if __name__ == "__main__":
    main()
