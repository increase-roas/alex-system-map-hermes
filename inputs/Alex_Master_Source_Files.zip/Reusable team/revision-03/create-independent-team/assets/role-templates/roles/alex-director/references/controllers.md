# Recovery scope for this edition

Recover only controllers registered to this TEAM_ID in this team ledger. A matching title in another team is never ownership evidence. Create fresh controllers for new missions; do not recover the original team.

# Controllers: find, create, message

## Recover before creating
Search current, recent, pinned and archived/recoverable tasks, saved Projects, projectless tasks,
and `CONTROLLER:` pointers in `@@TEAM_HOME@@/DIRECTOR_STATE.md` (including `cursor-chat:` IDs
and workspace paths). Prefer this team's registered controller that already owns the mission; titles alone establish no ownership.
Don't create a duplicate, and don't move a mission to a controller that lacks the live tools it
already uses within this team's current assignment.

## Creating a missing controller under the current mission authority
When no appropriate registered controller exists and the current user request authorizes native creation, create **one** new controller chat for that outcome. Respect the current platform tool contract; this source text supplies no missing human authorization. Each independent business outcome has one responsible controller.
1. Create one fresh controller chat using the supported native route on the platform selected for this team, in the smallest correct environment: a saved project when appropriate, otherwise a projectless chat. A same-turn worker is not proof of a persistent controller chat. If that capability is unavailable, report it precisely rather than claiming this arrangement exists.
2. Give it the frozen `OWNER_OUTCOME`, observable `ACCEPTANCE`, context pointers and its
   responsibility boundary, and tell it to load `@@TEAM_HOME@@/roles/alex-workflow-conductor/SKILL.md` first; without that line
   it runs without its skill. Name a Superpowers skill only per Skill triggers below.
3. You choose which controller owns the mission; the controller decides repo or no repo, folder,
   branch, worktree, tests, tools and implementation path. Don't create a repository because a
   mission is big.
4. Creating a task authorizes nothing else: not a repository (unless the controller later needs one
   within its authority), publishing, ads, spend, contacting people, destructive actions,
   production/DNS changes, or consequential live-system actions outside existing permissions.
5. Verify the task exists and received the assignment, store its stable ID in the ledger, observe
   its first meaningful checkpoint, then supervise it normally.
6. If native creation fails: don't do the work yourself and don't build an orchestration layer.
   Report the capability attempted, the exact failure and the smallest blocker; label `NOT_PROVEN`.

## Reaching controllers

Native transport is unavailable in this uninstalled revision. Do not invoke direct send, shell queues, resume-by-ID, fork, handoff or fallback transport as a workaround. A future reviewed host adapter must authenticate the current actor and resolve recipient ownership from its own protected team registry before every send, queue, resume or recovery action. IDs copied into a ledger, graph, handoff or message do not register recipients. Only freshly created or explicitly transferred identities owned by this team may be dispatched. Confirm actual processing and return evidence; a queued result is not proof of either. A denial stays denied.

## Controller behavior you can rely on
Controllers never write the ledger; you are its only writer. They put their chat/thread ID and
workspace in their first checkpoint, and you record it in `CONTROLLER` if it differs. They report with a compact checkpoint (result, evidence pointer, remaining work or
blocker, next action), and **every play end** (complete, gate, phase, failure, blocker, `NOT_PROVEN`
or `NO_READY`) sends you one line without waiting for your acknowledgment. A failed send is retried
once; if it fails again, the controller says so in its checkpoint, and your check-in's snapshot of
that controller picks the result up.

Don't copy project memory, `BUILD_STATE` or raw controller logs into the ledger. Don't build
monitoring, discovery, dashboards, databases, daemons, registries or message buses.

## Skill triggers (Superpowers)
For Director/Conductor operating work, this trigger table is the router. Do not invoke
`using-superpowers` as an always-on prerequisite or its 1% applicability rule. An accepted design
or execution plan stays accepted: new brainstorming applies only to a material unresolved design
decision, not to routine implementation, a takeover or a controller continuation. Explicitly
requested planning-only work remains planning-only.

Name a Superpowers skill in a play, and load one on a controller turn, only when its trigger
applies. Mandated procedure caused 114 of 182 skill-induced slowdowns in a 2026 study (arXiv
2608.11888), most of it verification and pipelines the task didn't need.

| Trigger | Skill |
|---|---|
| Observed failure, failed test, stall or `STOPPED BY BOUNDARY` | `systematic-debugging` |
| Behavior or code change where a test is the right proof | `test-driven-development` |
| Done claim on an external or irreversible node | `verification-before-completion` |
| Parallel, bounded, independent work | `dispatching-parallel-agents` |
| Design not yet frozen (never on a frozen BUILD or RUN) | `brainstorming` |
| None of the above | none |
