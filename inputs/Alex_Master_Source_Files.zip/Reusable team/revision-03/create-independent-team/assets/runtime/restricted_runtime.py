"""Enforced local subprocess boundary; never a sandbox for native desktop tools.

The caller is a trusted host, outside its workers. Its allowed paths and command
must not come from worker input. Native activation has no adapter in this edition.
"""
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


class UnsupportedRuntime(RuntimeError):
    pass


def require_native_activation(platform_name):
    raise UnsupportedRuntime(
        f'{platform_name}: activation unsupported; requires host-authenticated current-chat '
        'identity, isolation of EVERY tool/credential route, an authoritative resource '
        'owner registry and native recipient/resume/queue/schedule enforcement. '
        'No native adapter is included. Local JSON, environment values and fixture '
        'receipts cannot enable activation.')


def _path(path):
    p = Path(path).absolute()
    if not p.exists() or p != p.resolve():
        raise ValueError('runtime paths must exist and be canonical, without links')
    if '\n' in str(p) or '\x00' in str(p):
        raise ValueError('invalid runtime path')
    return p


def profile(read_roots, write_roots):
    if platform.system() != 'Darwin':
        raise UnsupportedRuntime('Only the verified macOS subprocess adapter is available')
    reads = [_path(p) for p in read_roots]
    writes = [_path(p) for p in write_roots]
    # Interpreter/system libraries only, not the user's HOME, keychain, app data,
    # network, GUI bridges, process inspection or inherited credential environment.
    system = ['/System', '/usr/lib', '/usr/share', '/usr/bin', '/bin', '/sbin',
              str(Path(sys.base_prefix).resolve())]
    reads += [Path(p) for p in system if Path(p).exists()]
    ancestors = sorted({p for root in reads+writes for p in root.parents}, key=str)
    directory_entries = ' '.join('(literal '+json.dumps(str(p))+')' for p in ancestors)
    def rules(paths):
        return ' '.join('(subpath '+json.dumps(str(p))+')' if p.is_dir()
                        else '(literal '+json.dumps(str(p))+')' for p in paths)
    return '\n'.join([
        '(version 1)', '(allow default)', '(deny network*)',
        '(deny mach-lookup)', '(deny mach-register)', '(deny process-info*)',
        '(deny signal)',
        '(deny file-read-data (require-not (require-any '+rules(reads+writes)+' '+directory_entries+
        ' (literal "/dev/null") (literal "/dev/urandom") (literal "/dev/random"))))',
        '(deny file-write* (require-not (require-any '+rules(writes)+
        ' (literal "/dev/null"))))',
    ])


def run(argv, *, cwd, read_roots, write_roots, input_text=None, timeout=20):
    """No ambient environment, inherited FDs, shell expansion or fallback route."""
    cwd = _path(cwd)
    policy = profile(read_roots, write_roots)
    env = {'PATH':'/usr/bin:/bin', 'LANG':'en_US.UTF-8',
           'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONNOUSERSITE':'1'}
    command = ['/usr/bin/sandbox-exec', '-p', policy, *map(str, argv)]
    result = subprocess.run(command, cwd=cwd, env=env, close_fds=True,
                            input=input_text, text=True, capture_output=True,
                            timeout=timeout)
    return {'exit':result.returncode, 'stdout':result.stdout,
            'stderr':result.stderr, 'policy':policy, 'argv':list(map(str,argv))}
