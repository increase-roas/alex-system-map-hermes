"""Descriptor-relative bookkeeping I/O; never follows a symlink component."""
import os
import stat
import uuid
import fcntl
from pathlib import Path
from contextlib import contextmanager

_BOUND_ROOT = None
_BOUND_FD = None


def absolute(path):
    p = Path(path).expanduser().absolute()
    if '..' in p.parts:
        raise ValueError('parent traversal refused')
    return p


@contextmanager
def directory(path, create=False):
    p = absolute(path)
    if _BOUND_ROOT is not None and (p == _BOUND_ROOT or _BOUND_ROOT in p.parents):
        fd=os.dup(_BOUND_FD)
        parts=p.relative_to(_BOUND_ROOT).parts
    else:
        fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
        parts=p.parts[1:]
    try:
        for part in parts:
            if create:
                try: os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError: pass
            nxt = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        if os.fstat(fd).st_uid != os.getuid():
            raise ValueError('directory owner mismatch')
        yield fd
    finally:
        os.close(fd)


def checked(fd):
    s = os.fstat(fd)
    if not stat.S_ISREG(s.st_mode) or s.st_nlink != 1 or s.st_uid != os.getuid():
        raise ValueError('untrusted file at operation')
    return fd


@contextmanager
def file(path, flags=os.O_RDONLY, mode=0o600):
    p = absolute(path)
    with directory(p.parent) as parent:
        fd = os.open(p.name, flags | os.O_NOFOLLOW | os.O_NONBLOCK, mode, dir_fd=parent)
        try:
            checked(fd)
            yield fd
        finally: os.close(fd)


def read_bytes(path):
    with file(path) as fd:
        chunks=[]
        while True:
            b=os.read(fd, 65536)
            if not b: return b''.join(chunks)
            chunks.append(b)


def read_text(path): return read_bytes(path).decode('utf-8')


def write_all(fd, data):
    view=memoryview(data)
    while view:
        n=os.write(fd,view)
        if not n: raise OSError('short write')
        view=view[n:]


def atomic_write(path, data, exclusive=False):
    if isinstance(data,str): data=data.encode('utf-8')
    p=absolute(path)
    with directory(p.parent) as parent:
        # Reject existing poison even though replace itself does not follow it.
        try:
            fd=os.open(p.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=parent)
        except FileNotFoundError: pass
        else:
            try: checked(fd)
            finally: os.close(fd)
        tmp='.'+p.name+'.'+uuid.uuid4().hex
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=parent)
        try:
            write_all(fd,data); os.fsync(fd)
        finally: os.close(fd)
        try:
            if exclusive:
                os.link(tmp,p.name,src_dir_fd=parent,dst_dir_fd=parent,follow_symlinks=False)
            else: os.replace(tmp,p.name,src_dir_fd=parent,dst_dir_fd=parent)
            os.fsync(parent)
        finally:
            try: os.unlink(tmp,dir_fd=parent)
            except FileNotFoundError: pass


def copy(source,target): atomic_write(target,read_bytes(source))


def append(path,text):
    with file(path,os.O_RDWR|os.O_APPEND) as fd:
        fcntl.flock(fd,fcntl.LOCK_EX)
        size=os.fstat(fd).st_size
        tail=os.pread(fd,1,size-1) if size else b'\n'
        write_all(fd,('' if tail==b'\n' else '\n').encode()+text.encode()+b'\n')
        os.fsync(fd)


def exists(path):
    p=absolute(path)
    try:
        with directory(p.parent) as parent: os.stat(p.name,dir_fd=parent,follow_symlinks=False)
        return True
    except FileNotFoundError: return False


def mkdir(path,parents=False,exist_ok=False):
    p=absolute(path)
    with directory(p.parent,create=parents) as parent:
        try: os.mkdir(p.name,0o700,dir_fd=parent)
        except FileExistsError:
            if not exist_ok: raise
    with directory(p): pass


def unlink(path,dir_only=False):
    p=absolute(path)
    with directory(p.parent) as parent:
        if dir_only: os.rmdir(p.name,dir_fd=parent)
        else: os.unlink(p.name,dir_fd=parent)
        os.fsync(parent)


def move(source,target):
    # Used under a transaction lock. Copy+unlink keeps interruption fail-closed.
    copy(source,target)
    unlink(source)


def listdir(path):
    with directory(path) as fd: return [absolute(path)/n for n in os.listdir(fd)]


def lock_fd(path):
    p=absolute(path)
    with directory(p.parent) as parent:
        fd=os.open(p.name,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=parent)
        try: checked(fd); fcntl.flock(fd,fcntl.LOCK_EX)
        except BaseException: os.close(fd); raise
        return fd


@contextmanager
def locked(path):
    fd=lock_fd(path)
    try: yield
    finally: os.close(fd)


def bind_root(path):
    """Pin one validated helper home for this process, retaining its directory inode."""
    global _BOUND_ROOT,_BOUND_FD
    p=absolute(path)
    if _BOUND_ROOT is not None:
        if p!=_BOUND_ROOT: raise ValueError('process already bound to another home')
        return
    with directory(p) as fd: pinned=os.dup(fd)
    _BOUND_ROOT=p
    _BOUND_FD=pinned


def directory_exists(path):
    try:
        with directory(path): pass
        return True
    except FileNotFoundError: return False
