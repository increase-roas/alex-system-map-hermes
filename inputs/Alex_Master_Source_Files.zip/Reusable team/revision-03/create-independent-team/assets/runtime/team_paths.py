"""Team-owned bookkeeping paths. A routing boundary, not an OS sandbox."""
import json
import os
from pathlib import Path
import re
import stat
import hashlib
import unicodedata
import safe_io as io


class ScopeError(ValueError):
    pass


def clean_path(value):
    p = Path(value).expanduser().absolute()
    if p != p.resolve():
        raise ScopeError(f"noncanonical or linked path: {p}")
    for part in (p, *p.parents):
        if part.is_symlink():
            raise ScopeError(f"linked path: {part}")
    return p


def private_file(path):
    p = clean_path(path)
    if io.exists(p):
        with io.file(p): pass
    return p


def bound_home(script_path):
    script = clean_path(script_path)
    if script.parent.name != 'scripts':
        raise ScopeError('helper must live in the team scripts directory')
    if script.parent.parent.name == 'alex-director' and script.parents[2].name == 'roles':
        home = script.parents[3]
    else:
        home = script.parents[1]
    if not home.is_dir() or home.stat().st_uid != os.getuid():
        raise ScopeError('team home is unavailable or belongs to another user')
    if (home / '.setup-in-progress').exists():
        raise ScopeError('team setup is incomplete; inspect the partial output before use')
    io.bind_root(home)
    bp = private_file(home / 'TEAM_BINDING.json')
    try:
        binding = strict_json(io.read_text(bp))
    except (OSError, ValueError) as exc:
        raise ScopeError(f'team binding unavailable: {exc}') from exc
    if binding.get('schema') != 'independent-team-binding/v1':
        raise ScopeError('unknown team binding schema')
    if binding.get('team_home') != str(home):
        raise ScopeError('binding belongs to a different home; explicit relocation is required')
    if not re.fullmatch(r'team-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', binding.get('team_id', '')):
        raise ScopeError('missing or invalid fresh team identity')
    ident = binding.get('director_identity') or {}
    if any(not isinstance(ident.get(k), str) or not ident[k].strip() for k in ('platform', 'thread_id', 'host_id')):
        raise ScopeError('first-chat Director identity is missing')
    context = runtime_context(home, binding)
    if context.get("team_id") != binding["team_id"] or context.get("role") not in ("director", "controller") or not context.get("thread_id"):
        raise ScopeError("trusted runtime principal is unavailable")
    return home, binding


def ledger_path(home, supplied):
    p = private_file(supplied)
    if p != clean_path(home) / 'DIRECTOR_STATE.md':
        raise ScopeError('ledger belongs outside this team')
    for suffix in ('.bak', '.lock'):
        private_file(str(p) + suffix)
    return p


def graph_path(home, supplied):
    p = private_file(supplied)
    if p.parent != clean_path(home) / 'mission-graphs' or p.suffix != '.md':
        raise ScopeError('graph belongs outside this team')
    private_file(str(p) + '.bak')
    return p


def log_path(home, supplied=None, name='run-log.md'):
    expected = clean_path(home) / 'system' / name
    p = private_file(supplied if supplied is not None else expected)
    if p != expected:
        raise ScopeError('bookkeeping log belongs outside this team')
    return p


def claims_path(home):
    p = clean_path(Path(home) / '.runtime' / 'controller-write-claims')
    for d in (p.parent,p):
        if io.exists(d):
            with io.directory(d): pass
    return p


def authorization_path(home, supplied):
    p = private_file(supplied)
    if p.parent != clean_path(home) / 'mission-graphs' or p.suffix != '.json':
        raise ScopeError('authorization record belongs outside this team')
    return p


def check_mission_identity(binding, fields):
    if fields.get('TEAM_ID') != binding['team_id']:
        raise ScopeError('mission belongs to another team or has no TEAM_ID')
    if fields.get('SUPERVISING_DIRECTOR_THREAD_ID') != binding['director_identity']['thread_id']:
        raise ScopeError('mission return address is not this team Director')


def check_text_identity(binding, text):
    fields = {}
    for key in ('TEAM_ID', 'SUPERVISING_DIRECTOR_THREAD_ID'):
        hits = re.findall(r'^' + key + r':\s*([^\n]+)$', text, re.M)
        if len(hits) != 1:
            raise ScopeError(f'exactly one {key} field required')
        fields[key] = hits[0].strip()
    check_mission_identity(binding, fields)


def runtime_context(home, binding):
    raise ScopeError('trusted launcher required; native activation unsupported')


def require_role(home, binding, role):
    c = runtime_context(home, binding)
    if c.get('role') != role or c.get('team_id') != binding['team_id']:
        raise ScopeError('runtime role mismatch')
    if role == 'director' and c.get('thread_id') != binding['director_identity']['thread_id']:
        raise ScopeError('Director principal mismatch')
    return c


def strict_json(raw):
    def pairs(items):
        out = {}
        for k,v in items:
            if k in out: raise ScopeError('duplicate JSON key')
            out[k] = v
        return out
    def constant(value): raise ScopeError('nonfinite JSON value')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def canonical_hash(value):
    def norm(v):
        if isinstance(v,str): return unicodedata.normalize('NFC',v)
        if isinstance(v,list): return [norm(x) for x in v]
        if isinstance(v,dict): return {unicodedata.normalize('NFC',k):norm(x) for k,x in v.items()}
        return v
    return hashlib.sha256(json.dumps(norm(value),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


def text_fields(text):
    fields = {}
    for k,v in re.findall(r'^([A-Z][A-Z0-9_]*):[ \t]*(.*?)[ \t]*$',text,re.M):
        if k in fields: raise ScopeError('duplicate mission field: '+k)
        fields[k] = v
    return fields


def validate_authorization(home,binding,fields,expected_scope=None):
    ref=authorization_path(home,fields.get('AUTHORIZATION_REF',''))
    raw=io.read_bytes(ref)
    c=runtime_context(home,binding)
    if c.get('team_id') != binding['team_id'] or c.get('authorizations',{}).get(str(ref)) != hashlib.sha256(raw).hexdigest():
        raise ScopeError('authorization lacks trusted current approval or was altered')
    record=strict_json(raw.decode('utf-8'))
    keys={'schema','team_id','director_thread_id','mission_id','next_play_id','controller_thread_id','controller_generation','outcome_hash','authorization_scope'}
    if not isinstance(record,dict) or set(record)!=keys or record['schema']!='independent-team-authorization/v1':
        raise ScopeError('invalid authorization record schema')
    expected={'team_id':binding['team_id'],'director_thread_id':binding['director_identity']['thread_id'],
      'mission_id':fields.get('MISSION_ID'),'next_play_id':fields.get('NEXT_PLAY_ID'),
      'controller_thread_id':fields.get('CONTROLLER_THREAD_ID'),'outcome_hash':fields.get('NEXT_PLAY_OUTCOME_HASH')}
    if any(record[k]!=v or not isinstance(v,str) or not v for k,v in expected.items()):
        raise ScopeError('authorization mission/play/owner identity mismatch')
    generation=record['controller_generation']
    if isinstance(generation,bool) or not isinstance(generation,int) or generation<1 or str(generation)!=fields.get('CONTROLLER_GENERATION'):
        raise ScopeError('authorization generation mismatch')
    if not isinstance(record['authorization_scope'],dict) or not record['authorization_scope']:
        raise ScopeError('authorization scope missing')
    if canonical_hash(record['authorization_scope'])!=fields.get('AUTHORIZATION_SCOPE_HASH'):
        raise ScopeError('authorization scope mismatch')
    if expected_scope is not None and record['authorization_scope']!=expected_scope:
        raise ScopeError('requested scope differs from approved scope')
    if c.get('role')=='controller' and c.get('thread_id') != record['controller_thread_id']:
        raise ScopeError('controller principal mismatch')
    if c.get('role')=='director' and c.get('thread_id') != record['director_thread_id']:
        raise ScopeError('Director principal mismatch')
    return record


def validate_references(home,binding,body):
    fields=text_fields(body)
    check_mission_identity(binding,fields)
    mid=fields.get('MISSION_ID')
    if not mid: raise ScopeError('missing mission identity')
    graph=graph_path(home,fields.get('MISSION_GRAPH',''))
    graph_text=io.read_text(graph)
    check_text_identity(binding,graph_text)
    if single_field(graph_text,'MISSION_ID')!=mid:
        raise ScopeError('graph mission identity mismatch')
    ref=fields.get('AUTHORIZATION_REF')
    if ref and ref!='NONE': validate_authorization(home,binding,fields)
    elif fields.get('STATUS')=='ACTIVE' and fields.get('AUTHORIZATION_SCOPE_HASH') not in (None,'','NONE'):
        raise ScopeError('protected active mission requires authorization')
    return fields


def single_field(text,key):
    hits=re.findall(r'^'+re.escape(key)+r':[ \t]*([^\n]*)$',text,re.M)
    if len(hits)!=1: raise ScopeError('exactly one '+key+' field required')
    return hits[0].strip()
