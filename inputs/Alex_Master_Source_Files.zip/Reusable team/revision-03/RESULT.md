# Revision 0.3 — local repairs verified; native activation remains unsupported

The separate, uninstalled revision is implemented and passes the complete local verification run. **The full native Director/controller isolation guarantee is not fixed or cleared for use on the current desktop host.** The candidate refuses native activation because the host does not expose the complete required trusted-identity and all-tool boundary. No live team was launched or installed.

Alex's intended experience remains the contract: manually create an empty operating folder; its first chat invokes setup and becomes Director; assign the mission afterward; work on either a new project or an existing external repo. A supported native adapter must preserve this sequence. The team must not be installed inside the target repo.

## What was repaired

- Descriptor-anchored file operations protect logs, graphs, backups, locks and claim history against substituted symbolic/hard links and parent paths at use time.
- Ledger verification now refuses foreign, missing or mismatched graph/authorization references before success or lock release.
- Authorization requires an existing strict record, current trusted approval digest, matching mission/play/controller/generation/outcome/scope and a host-owned resource lease. Matching caller-supplied hashes alone cannot grant access.
- Local concurrency and recovery preserve unresolved work: stable locks, no lock stealing by age, journaled graph/log recovery, fenced claim replay and unresolved claim transitions.
- The candidate's actual macOS subprocess runner restricts every worker/helper command it launches, while permitted external-project work succeeds. The synthetic host owns identities, disjoint resources/projects and recipients outside workers.
- Shared-card changes become local maintainer proposals. Native queue/resume/send/recovery/schedule fallbacks are unavailable until a host adapter enforces ownership.
- Two false-success lint paths were found and repaired during the loop, including one found by the independent reviewer. Scope and identity refusal now produce a nonzero CLI result.

## Verified evidence

| Check | Result |
|---|---|
| Original v0.2 reproduction, unchanged harness | 38 cases: 31 pass, 7 fail, 0 errors — exact prior audit result |
| Final integration through candidate runtime | 89 pass, 0 fail, 0 errors |
| Deterministic race/crash/concurrency suite | 7 pass, 0 fail |
| Focused low-level I/O groups | 7 pass, 0 fail |
| Independent reviewer host checks | 27 pass, including the reproduced-and-fixed identity-header lint defect |
| Independent repeated I/O groups | 7 pass |
| Skill frontmatter validator | Pass; scratch-only dependency, no global installation |
| Original candidate/audit preservation | 30 candidate files, 7 audit evidence files and 13 reports byte-identical; original transform/test/harness scripts unchanged |

The suites overlap, so their counts are shown separately. All 38 original safety expectations remain mapped in [CASE-MATRIX.md](verification/CASE-MATRIX.md). Native refusal tests prove the gate refuses; they do not prove native identity, transport or all-tool isolation. Synthetic provider/transport events are not live service observations.

The original Director, its chats/controllers, live state, resources, approvals, credentials, schedules and installed setup received no writes or native operations from this task. The preservation hashes apply to the retained candidate/audit artifacts; they are not a snapshot assertion about unrelated ongoing live-team activity.

## Remaining requirement

The current Codex desktop surface cannot give this skill a trusted current-chat identity plus enforced per-team access across every native tool, connector, credential route and send/resume/queue/schedule operation. Codex command restrictions cover local commands; they do not automatically constrain those other surfaces. A script or editable identity field cannot supply that missing host authority.

A reviewed host-supported adapter or isolated host must authenticate the first chat outside agent-controlled input, restrict every exposed tool and credential route, maintain authoritative resource ownership, and enforce recipient/schedule ownership on every action and resumed turn. Then it must pass a separately authorized inert native trial. [NATIVE-TRIAL-STEPS.md](NATIVE-TRIAL-STEPS.md) gives the exact requirements and trial sequence. No single supported setting was found that completes this; no security setting was changed.

There is no manual disable/cleanup task for Alex to remember. Native setup and standalone helpers refuse by default. Do not remove that gate or copy fixture state into a live team.

Status: **written and verified in isolated fixtures; native runtime unobserved and unsupported; adoption pending.**

## Deliverables

- [Uninstalled skill](create-independent-team/SKILL.md)
- [Source/change map](SOURCE-CHANGE-MAP.md), [per-file hashes](source-change-map.json), [actual patch](changes.patch)
- [Threat model](THREAT-MODEL.md) and [platform evidence](PLATFORM-EVIDENCE.md)
- [Complete case matrix](verification/CASE-MATRIX.md) and [reproduction instructions](verification/RUN.md)
- [Independent review](INDEPENDENT-REVIEW.md)
- [Remaining native requirements](NATIVE-TRIAL-STEPS.md)
