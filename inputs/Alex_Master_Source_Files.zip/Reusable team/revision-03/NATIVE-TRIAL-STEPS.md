# Exact remaining native prerequisite and trial

**Nothing is installed or running. Native setup intentionally refuses now.** No manual cleanup or remembered disable step is needed. The original team and all its settings stay untouched.

The remaining requirement is a **host-supported trusted adapter** that can enforce this team's boundary across all tools. The current full-access desktop chat cannot supply that boundary, and a command sandbox alone is insufficient. There is no supported single checkbox, identity string or permission-profile snippet that completes this candidate. Do not remove the refusal gate merely because isolated tests pass.

## Required adapter behavior before another native trial

1. Bind the first manually opened chat using host-authenticated identity. Keep actor/team membership and current generation outside agent-writable state. Preserve the same first chat as Director; do not require a mission at setup.
2. Restrict all tool surfaces and credential routes. Only this team's state, assigned external project roots and reviewed read-only standards may be accessible. Native file tools, connectors/MCP, browser/computer tools and CLI/native queue/resume routes must obey the same authority; otherwise do not expose them to the team. Never mount broad Documents/Codex or shared credential/session stores.
3. Use one protected owner registry or provider-enforced disjoint permissions for canonical resources/accounts. Resolve aliases to the same object. Refuse overlapping filesystem roots and provider objects. Credentials remain outside workers and scoped at the provider/broker.
4. Enforce team recipient and schedule ownership before every send, queue, resume, recovery and scheduled wake. Original IDs in local state must produce a denial before any native dispatch. Lost registry/context stops activation instead of reconstructing authority from team files.
5. Keep helper code and authority data immutable to workers. Serialize a Director's multi-command ledger edit cycle; supply current authorization digests/leases and actor identity only through the trusted route. Verify protections on every start/resume/wake.

These requirements need platform capability/integration, not Alex relaying files or making routine implementation choices. Security settings remain owner-controlled. If a candidate platform cannot enforce one of them, mark it unsupported; do not route around it.

## Separately authorized inert native trial, after that adapter exists

1. Preserve this reviewed revision and record the adapter/code/settings fingerprints. Grant only new disposable resources, never original-team access.
2. Alex manually creates a fresh empty operating folder and opens its first chat. Invoke setup there. Observe host-authenticated identity and zero missions/controllers/grants/schedules.
3. Assign an existing external-repo fixture as the first mission. Keep its instructions and team state separate. Create one fresh controller; observe actual processing and return to the same Director.
4. Prove a useful permitted edit and acceptance, rejection of an unsupported completion, and continuation of independent authorized work while a dependent item is parked.
5. Interrupt and resume once. Retain current decisions, bounded approval, unfinished commitment and unresolved-effect fence; do not repeat a completed effect or revive canceled work.
6. Assign a second new-project mission afterward. Create the project only then at its external assigned path; no team installation in the target repo.
7. Through each exposed native tool surface, test synthetic foreign paths/credentials/recipients, replaced links, stale authority and competing resource claims. Original-team identities/files are evidence-only, never live negative-test recipients or write targets.
8. If recurring supervision is separately requested, prove one team-owned schedule, wake, ownership denial and recovery. Otherwise record native scheduling proof pending; do not create a recurring job solely for convenience.
9. Compare expected/observed native IDs, effects, refusal receipts and retained checkpoints. Queue acceptance is not delivery. Any escape, duplicate effect, unsupported success or owner relay fails the trial.
10. Stop only trial-owned identities/resources after uncertain effects are reconciled. Preserve evidence. Adoption is a later explicit decision; a passing local or native trial does not itself install this bundle globally.

Until then, the result is **written and verified in isolated fixtures**, not observed as a live native team. The native gate enforces this status; it does not depend on Alex remembering not to launch it.
