# Restricted native team candidate

This additive candidate leaves version 0.2, its failed audit, the 81 frozen revision-03 files and all installed/original team material unchanged. Nothing is installed and no live team is adopted.

The initial supported host is a trusted local Python parent controlling the Mac's shipped Codex app-server through private stdio, with a preconfigured loopback Responses relay. It is a separate host, not a plugin that secures ordinary Codex desktop chats. The actual tested bundled engine is 0.159.0-alpha.12.1. The current test relay is deterministic and has no provider credentials. No paid/live-model request is part of verification.

## Owner experience retained

1. Manually create an empty operating folder outside the target project.
2. The protected host opens its first native chat in that folder. That existing chat invokes `setup_team` and becomes Director, with no mission or inherited permissions.
3. Assign the mission afterward through trusted operator input. It names an existing external project or explicitly creates a new external project, and freezes expected local file results.
4. Director requests a fresh controller. The host provides its real native identity, local role, project instructions and task. The controller performs the guarded local edit and returns observed evidence to Director.
5. Director accepts the result through the preserved local graph/log helper. The original team is never a fallback recipient or source of authority.

The host is currently a library with a reproducible test harness, not an installed interactive chat frontend. A frontend must preserve the operator/model distinction and use one protected registry for all its teams. `assign_mission`, Registry methods and constructor arguments are trusted host APIs, never model-callable functions. `NativeHost(..., registry=existing_registry)` enrolls another operating folder under the same protected authority. It reserves every private/native/temp root and refuses overlapping project ownership. Starting separate registries does not establish cross-host coordination and is outside the supported deployment contract.

## Enforced scope

The native engine has no direct shell, filesystem editor, browser, computer, connector, MCP, native messaging, subagent or automation route. It can call only registered broker operations (the built-in input request is unavailable in this mode). Native source identities come from matching private thread/turn events. Model arguments cannot select an identity, home or grant.

The worker uses the existing OS sandbox, plus denial of process creation. It can read its own derived team instructions and assigned project, and write only that project. Network, credential/native/private registry reads, own team state writes and child processes are denied. Denying child processes prevents a background writer from surviving the command's guard. This initial proof supports one Python program per authorized play, not general shell builds, network services or external provider work.

A protected shared registry pins homes/projects, current native membership, controller generations, approvals and canonical resource ownership. Exact authorization bytes must match protected authority. Guard acquisition, native command, exact file readback and guard completion form one broker operation. Uncertain work retains its guard and refuses retry. Completed work returns the prior receipt without re-executing model code. Ordinary worker code cannot invoke privileged bookkeeping or import the protected adapter.

The protected helper entry loads preserved sources and strips only their writable-directory import-path additions. File operations retain the prior descriptor-relative no-follow controls. Generated source hashes are checked before helper invocation. Ledger validation and foreign references are not bypassed.

## Recovery and limits

The native engine must complete a turn before a resumable rollout exists. A new parent instance reopens intact protected state, verifies native membership and resumes the same actual Director; controllers resume only after an owned-recipient check. Missing/corrupt authority and uncertain enrollment/delivery must refuse recovery rather than create a replacement Director. Checksums detect corruption, not an unrestricted same-UID owner attack; the enforced model/native worker boundary is mandatory.

Uncertain effects, failed ledger transactions and unconfirmed deliveries require a trusted operator to inspect actual evidence and reconcile. This candidate supplies no unsafe automatic retry or state reconstruction. It currently reserves a project to one mission and offers no release/reassignment API. Schedules, external providers and unrestricted process execution are explicitly unsupported. These are bounded-host limits, not claims that the general Director product is ready.

The ordinary desktop first-chat integration and a real-model behavioral trial remain unproven. No owner security setting has been changed. A real-model trial needs an explicitly authorized model/relay route and a suitable foreground operator interface; it must keep this exact broker and OS boundary. A standard desktop chat cannot be counted as that interface merely because it reads this skill.

## Verification

Tests use real bundled native threads and actual OS decisions with scripted local model output. Registry-only tests label identities synthetic. Broker integration proves first-chat setup, later mission, fresh controllers, existing and new external projects, preserved project instructions, useful work, native return/acceptance, host restart, conflicting teams, forged/revoked authority, foreign recipients, uncertain replay and direct escape denials. See verification/ for exact current receipts and hashes. Prior 25-case native probe and 103-case frozen offline regression retain their own separate scope.
