# Lessons retained with this isolated candidate

- A successful native startup needs the narrow ordinary UID/name lookup service on this Mac. General preferences/keychain/Mach access is not needed; the actual native startup regression proves the chosen exception.
- Every privileged parent file open must receive the same link/inode attention as helper operations. Protecting model commands alone does not protect a parent that follows a poisoned log path.
- Do not approve an unexercised registry schema as compatible with an existing guard. Native integration found the required action field and now proves an actual approved acquire/complete sequence.
- Persist all host root identities and unresolved delivery markers. Restart must not select new private roots or silently discard uncertainty.
- A denial-only test is insufficient: each boundary suite also proves permitted local work, actual readback and successful return through the native engine.
