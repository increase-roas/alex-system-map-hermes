# Current acceptance matrix

| Requirement | Implementation and observed proof |
|---|---|
| Existing first chat becomes Director, mission later | Actual-native workflow keeps first identity; setup has zero missions/grants/controllers; later operator assignment drives fresh native controller. |
| New or existing external project | Both actual-native scenarios pass; existing root instructions unchanged; team files stay outside target. |
| Trusted current actor and owned recipients | Private native thread/turn callback; registry-only lookup; forged model actor rejected; actual foreign team recipient refused before transport. |
| Useful authorized work and return | Existing guard acquire, real sandboxed file edit, exact host readback, guard complete, native queue/delivery, old graph/log acceptance. |
| Files, credentials and all exposed routes | 11 integrated worker refusals with positive write; exact restricted native client catalogue/hidden-command probes; earlier 25-check native component evidence; no installed credentials. |
| Current authority and shared resources | 22 registry tests plus native altered/revoked approval, changed generated source, two native teams and conflicting project/private-root assignments. |
| Replay/interruption/recovery | Completed replay has no new effect; failed command's partial file stays fenced across new supervisor; same Director/controller IDs resume; absent registry and replaced roots refuse. |
| Durable delivery uncertainty | Faults immediately before and after a real native delivery completion preserve the marker and queued later message; new supervisor and further pump refuse without reconciliation. |
| Race/link/concurrency helpers | Frozen 89 integration + 7 fault + 7 I/O regression rerun unchanged; 7 new parent-I/O regressions and 5 helper tests include link targets and import poisoning; registry conflicts serialize. |
| Independent review | Two reproduced material broker findings fixed; five focused acceptance checks pass; no remaining material finding in this standalone scripted-host scope. |
| Live/model/UI adoption | PENDING: no interactive frontend, ordinary desktop bridge or real-model team trial is claimed. |
