"""Fixed private-stdin subprocess entry; only a protected trusted parent may invoke.

Context is supplied by the parent's registry; stdin is not model authentication.
Caller must sandbox read adapter/package/home and write home only, and verify its
render manifest before invocation. No project-supplied code is imported.
"""
import ast
import contextlib
import hashlib
import io as textio
import json
from pathlib import Path
import sys
import types

P=Path(__file__).resolve().parents[2]/'create-independent-team'
RUNTIME=P/'assets/runtime'
SOURCES=P/'assets/role-templates'

def fixed_module(name,path,filename=None):
    module=types.ModuleType(name)
    module.__file__=str(filename or path)
    sys.modules[name]=module
    tree=ast.parse(path.read_bytes(),filename=module.__file__)
    class ProtectedImports(ast.NodeTransformer):
        def visit_Expr(self,node):
            # Old standalone helpers add writable rendered directories to sys.path.
            # Their dependencies are loaded from protected originals instead.
            call=node.value
            if isinstance(call,ast.Call) and ast.unparse(call.func)=='sys.path.insert':
                return None
            return self.generic_visit(node)
    tree=ProtectedImports().visit(tree)
    exec(compile(tree,module.__file__,'exec'),module.__dict__)
    return module

io=fixed_module('safe_io',RUNTIME/'safe_io.py')
scope=fixed_module('team_paths',RUNTIME/'team_paths.py')


def relative(home,value):
    if not isinstance(value,str) or not value:raise ValueError('nonempty relative path required')
    path=Path(value)
    if path.is_absolute() or '..' in path.parts or path==Path('.'):
        raise ValueError('relative path escapes home')
    return home/path


def checked_context(context):
    if not isinstance(context,dict):raise ValueError('trusted context required')
    for key in ('team_id','team_home','role','thread_id','director_thread_id'):
        if not isinstance(context.get(key),str) or not context[key]:raise ValueError('incomplete trusted context')
    if context['role'] not in ('director','controller'):raise ValueError('unknown trusted role')
    if not isinstance(context.get('authorizations'),dict) or not isinstance(context.get('resource_leases'),list):raise ValueError('missing trusted grants')
    home=scope.clean_path(context['team_home'])
    io.bind_root(home)
    def runtime_context(bound_home,binding):
        if (Path(bound_home)!=home or binding.get('team_home')!=str(home) or binding.get('team_id')!=context['team_id'] or
            binding.get('director_identity',{}).get('thread_id')!=context['director_thread_id'] or
            (context['role']=='director' and context['thread_id']!=context['director_thread_id'])):
            raise scope.ScopeError('trusted context does not match bound team/Director')
        return context
    scope.runtime_context=runtime_context
    return home


def modules(home):
    """Load protected originals, giving old scope code its rendered home location."""
    director=SOURCES/'roles/alex-director/scripts'
    rendered=home/'roles/alex-director/scripts'
    fixed_module('graph_edit',director/'graph_edit.py',rendered/'graph_edit.py')
    fixed_module('graph_lint',director/'graph_lint.py',rendered/'graph_lint.py')
    ledger=fixed_module('ledger_check',director/'ledger_check.py',rendered/'ledger_check.py')
    accept=fixed_module('fixed_accept',director/'accept.py',rendered/'accept.py')
    guard=fixed_module('fixed_guard',SOURCES/'scripts/controller-write-guard.py',home/'scripts/controller-write-guard.py')
    # Old helpers insert their rendered locations; they must never become imports.
    sys.path[:]=[p for p in sys.path if not p or not (Path(p)==home or home in Path(p).parents)]
    return ledger,accept,guard


def invoke(module,args):
    saved=sys.argv
    sys.argv=[module.__file__,*args]
    try:
        module.main()
    except SystemExit as exc:
        if exc.code not in (None,0):raise RuntimeError('fixed helper failed with exit '+str(exc.code)) from None
    finally:sys.argv=saved


def execute(request):
    if not isinstance(request,dict) or set(request)!={'context','operation','data'}:raise ValueError('invalid private request shape')
    context=request['context'];home=checked_context(context)
    operation=request['operation'];data=request['data']
    if not isinstance(data,dict):raise ValueError('operation data required')
    if operation=='prepare':
        if context['role']!='director' or context['thread_id']!=context['director_thread_id']:raise ValueError('prepare requires Director')
        files=data['files']
        if not isinstance(files,dict) or any(not isinstance(v,str) for v in files.values()):raise ValueError('rendered text files required')
        paths={relative(home,k):v for k,v in files.items()}
        binding=scope.strict_json(files['TEAM_BINDING.json'])
        scope.runtime_context(home,binding)
        if io.listdir(home):raise ValueError('prepare requires an empty home')
        for name in ('mission-graphs','system','.runtime'):io.mkdir(home/name,exist_ok=True)
        for path,text in paths.items():
            io.mkdir(path.parent,parents=True,exist_ok=True)
            io.atomic_write(path,text,exclusive=True)
        return {'operation':operation,'files':len(paths)}
    ledger,accept,guard=modules(home)
    bound,binding=scope.bound_home(home/'scripts/controller-write-guard.py')
    if operation in ('mission','accept'):scope.require_role(bound,binding,'director')
    if operation=='mission':
        graph=relative(home,data['graph']);auth=relative(home,data['authorization_ref'])
        if graph.parent!=home/'mission-graphs' or graph.suffix!='.md' or auth.parent!=home/'mission-graphs' or auth.suffix!='.json':raise ValueError('mission graph/authorization paths invalid')
        raw=data['authorization_text']
        if not isinstance(raw,str) or context['authorizations'].get(str(auth))!=hashlib.sha256(raw.encode()).hexdigest():raise ValueError('authorization bytes are not current registry approval')
        state=home/'DIRECTOR_STATE.md'
        invoke(ledger,['backup',str(state),'--by',context['thread_id']])
        # From here, every failure deliberately retains the old ledger write lock.
        io.atomic_write(graph,data['graph_text'],exclusive=True)
        io.atomic_write(auth,raw,exclusive=True)
        io.atomic_write(state,data['ledger_text'])
        invoke(ledger,['verify',str(state),'--mode','append','--mission',data['mission_id']])
    elif operation=='accept':
        graph=relative(home,data['graph'])
        invoke(accept,['--graph',str(graph),'--node',data['node'],'--evidence',data['evidence'],'--receipt',data['receipt'],'--job',data['job'],'--status','VERIFIED','--next','NONE','--result','accepted'])
    elif operation=='helper':
        if data.get('name')!='guard' or not isinstance(data.get('args'),list) or any(not isinstance(v,str) for v in data['args']):raise ValueError('unknown fixed helper or invalid arguments')
        invoke(guard,data['args'])
    else:raise ValueError('unknown fixed operation')
    return {'operation':operation}


def main():
    output=textio.StringIO();errors=textio.StringIO();code=0;result={}
    with contextlib.redirect_stdout(output),contextlib.redirect_stderr(errors):
        try:result=execute(scope.strict_json(sys.stdin.read()))
        except Exception as exc:
            code=1;errors.write(type(exc).__name__+': '+str(exc)+'\n')
    print(json.dumps({'exit':code,'stdout':output.getvalue(),'stderr':errors.getvalue(),**result}))
    return code

if __name__=='__main__':raise SystemExit(main())
