"""Synthetic parent context, real OS sandbox; no native model or account."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

A=Path(__file__).resolve().parents[1]
P=A.parent/'create-independent-team'
spec=importlib.util.spec_from_file_location('restricted_runtime',P/'assets/runtime/restricted_runtime.py')
rt=importlib.util.module_from_spec(spec);spec.loader.exec_module(rt)
ENTRY=A/'broker/helper_entry.py'

class HelperEntryTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(ENTRY.exists(),'fixed helper entry missing')
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name).resolve();self.home=self.root/'home';self.home.mkdir()
        self.team='team-11111111-1111-4111-8111-111111111111'
        self.context={'team_id':self.team,'team_home':str(self.home),'role':'director','thread_id':'native-director','director_thread_id':'native-director','authorizations':{},'resource_leases':[]}
    def tearDown(self):
        if hasattr(self,'tmp'):self.tmp.cleanup()
    def call(self,operation,data,context=None):
        result=rt.run([sys.executable,'-I','-S',str(ENTRY)],cwd=self.home,read_roots=[A,P,self.home],write_roots=[self.home],input_text=json.dumps({'context':context or self.context,'operation':operation,'data':data}))
        if result['stdout']:
            result['reply']=json.loads(result['stdout'])
        return result
    def prepare(self):
        binding={'schema':'independent-team-binding/v1','team_id':self.team,'team_home':str(self.home),'director_identity':{'platform':'native-test','thread_id':'native-director','host_id':'synthetic-host'}}
        return self.call('prepare',{'files':{'TEAM_BINDING.json':json.dumps(binding),'DIRECTOR_STATE.md':'# Director state\n','system/run-log.md':'# Run log\n'}})
    def mission(self):
        scope={'provider':'local-filesystem','account':'uid:synthetic','resource_type':'project','resource':'synthetic-external'}
        record={'schema':'independent-team-authorization/v1','team_id':self.team,'director_thread_id':'native-director','mission_id':'m1','next_play_id':'p1','controller_thread_id':'native-controller','controller_generation':1,'outcome_hash':'outcome-hash','authorization_scope':scope}
        raw=json.dumps(record)
        self.context['authorizations'][str(self.home/'mission-graphs/m1.json')]=hashlib.sha256(raw.encode()).hexdigest()
        scope_hash=hashlib.sha256(json.dumps(scope,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
        graph=f'MISSION_ID: m1\nTEAM_ID: {self.team}\nSUPERVISING_DIRECTOR_THREAD_ID: native-director\n\n| NODE_ID | STATUS | EVIDENCE | LAST_RECEIPT | NEXT_ACTION | UPDATED_AT |\n| --- | --- | --- | --- | --- | --- |\n| N1 | ACTIVE | - | - | act | - |\n'
        ledger=f'# Director state\n\n## Mission: m1\nMISSION_ID: m1\nTEAM_ID: {self.team}\nSUPERVISING_DIRECTOR_THREAD_ID: native-director\nMISSION_GRAPH: {self.home}/mission-graphs/m1.md\nAUTHORIZATION_REF: {self.home}/mission-graphs/m1.json\nNEXT_PLAY_ID: p1\nCONTROLLER_THREAD_ID: native-controller\nCONTROLLER_GENERATION: 1\nNEXT_PLAY_OUTCOME_HASH: outcome-hash\nAUTHORIZATION_SCOPE_HASH: {scope_hash}\nSTATUS: ACTIVE\n'
        return self.call('mission',{'mission_id':'m1','graph':'mission-graphs/m1.md','graph_text':graph,'ledger_text':ledger,'authorization_ref':'mission-graphs/m1.json','authorization_text':raw})
    def test_fixed_prepare_mission_accept_and_guard_under_real_sandbox(self):
        self.assertEqual(self.prepare()['exit'],0)
        for name in ('mission-graphs','system','.runtime'):self.assertTrue((self.home/name).is_dir())
        mission=self.mission();self.assertEqual(mission['exit'],0,mission)
        self.assertFalse((self.home/'DIRECTOR_STATE.md.lock').exists())
        accepted=self.call('accept',{'graph':'mission-graphs/m1.md','node':'N1','evidence':'seen','receipt':'test-receipt','job':'job1'})
        self.assertEqual(accepted['exit'],0,accepted)
        self.assertIn('VERIFIED',(self.home/'mission-graphs/m1.md').read_text())
        guard=self.call('helper',{'name':'guard','args':['audit']})
        self.assertEqual(guard['exit'],0,guard)
    def test_forged_context_and_unknown_helper_are_denied(self):
        self.assertEqual(self.prepare()['exit'],0)
        forged=dict(self.context,thread_id='forged-director')
        result=self.call('mission',{'mission_id':'x'},forged)
        self.assertNotEqual(result['exit'],0)
        self.assertEqual((self.home/'DIRECTOR_STATE.md').read_text(),'# Director state\n')
        self.assertNotEqual(self.call('helper',{'name':'shell','args':['echo','escape']})['exit'],0)
    def test_prepare_symlink_and_nonempty_home_denied(self):
        target=self.root/'foreign';target.mkdir();(target/'canary').write_text('UNCHANGED')
        (self.home/'system').symlink_to(target,target_is_directory=True)
        result=self.call('prepare',{'files':{'system/canary':'ESCAPE'}})
        self.assertNotEqual(result['exit'],0)
        self.assertEqual((target/'canary').read_text(),'UNCHANGED')
    def test_generated_home_cannot_poison_fixed_helper_imports(self):
        self.assertEqual(self.prepare()['exit'],0)
        scripts=self.home/'scripts';scripts.mkdir()
        (scripts/'datetime.py').write_text('from pathlib import Path;Path("POISON_EXECUTED").write_text("ESCAPE");raise RuntimeError("poisoned import")')
        result=self.mission()
        self.assertEqual(result['exit'],0,result)
        self.assertFalse((self.home/'POISON_EXECUTED').exists())

    def test_state_symlink_denial_preserves_transaction_lock(self):
        self.assertEqual(self.prepare()['exit'],0)
        target=self.root/'foreign';target.write_text('UNCHANGED')
        (self.home/'mission-graphs/m1.md').symlink_to(target)
        result=self.mission()
        self.assertNotEqual(result['exit'],0)
        self.assertEqual(target.read_text(),'UNCHANGED')
        self.assertTrue((self.home/'DIRECTOR_STATE.md.lock').exists())

if __name__=='__main__':unittest.main()
