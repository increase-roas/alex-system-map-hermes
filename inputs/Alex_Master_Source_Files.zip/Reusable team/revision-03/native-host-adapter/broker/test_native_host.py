"""Actual native-engine workflow. Local scripted provider, no live-model claim."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

A=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(A),str(A/'client')]
from test_native_client import Relay
try:
 from broker.native_host import NativeHost
except ImportError:
 NativeHost=None

SCRATCH=Path('/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work/reusable-team-setup/repair-isolation/host-layer/integration-tests')
SCRATCH.mkdir(exist_ok=True)

class WorkflowTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(NativeHost,'integration implementation missing')
  self.root=Path(tempfile.mkdtemp(dir=SCRATCH)).resolve()
  self.relay=Relay();self.hosts=[]
  for name in ('home','authority','private','state','tmp','project'):(self.root/name).mkdir(mode=0o700)
 def tearDown(self):
  for h in self.hosts:h.stop()
  self.relay.close()
 def make(self,recover=False):
  h=NativeHost(home=self.root/'home',registry_root=self.root/'authority',private_root=self.root/'private',native_state=self.root/'state',native_temp=self.root/'tmp',relay_url=self.relay.url,model='isolated-team-test',recover=recover)
  self.hosts.append(h);return h
 def native_call(self,h,actor,name,args,case):
  self.relay.call(name,args,case);p=h.turn(actor,case)
  outputs=[i['output'] for r in self.relay.requests for i in r['body'].get('input',[]) if i.get('call_id')=='call_'+case and i['type']=='function_call_output']
  self.assertTrue(outputs,case+' has no matching native output')
  return json.loads(outputs[-1]),p
 def setup(self):
  h=self.make();first=h.first_chat()
  self.assertEqual(list((self.root/'home').iterdir()),[])
  out,_=self.native_call(h,first,'setup_team',{},'setup')
  self.assertTrue(out['ok'],out);self.assertEqual(h.director,first)
  self.assertEqual(h.state['missions'],{})
  return h,first
 def mission(self,h,first,mid='m1',project=None):
  project=project or self.root/'project'
  h.assign_mission(mid,project=project,expected_files={'result.txt':'useful result'},description='Produce the exact local result')
  out,_=self.native_call(h,first,'dispatch_mission',{'mission_id':mid},'dispatch_'+mid)
  self.assertTrue(out['ok'],out)
  h.run_pending();c=h.state['missions'][mid]['controller']
  self.assertNotEqual(c,first);return c
 def test_existing_project_first_chat_mission_return_and_recovery(self):
  marker=self.root/'project'/'AGENTS.md';marker.write_text('Preserve existing project instructions.\n');baseline=marker.read_bytes()
  h,d=self.setup();c=self.mission(h,d)
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('useful result')"},'work')
  self.assertTrue(out['ok'],out);self.assertEqual((self.root/'project'/'result.txt').read_text(),'useful result');self.assertEqual(marker.read_bytes(),baseline)
  replay,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('REPLAYED')"},'replay')
  self.assertTrue(replay['ok']);self.assertEqual(replay['status'],'replay_completed');self.assertEqual((self.root/'project'/'result.txt').read_text(),'useful result')
  returned,_=self.native_call(h,c,'return_result',{},'return');self.assertTrue(returned['ok'],returned)
  self.relay.call('accept_result',{'mission_id':'m1'},'accept');h.run_pending()
  self.assertEqual(h.state['missions']['m1']['status'],'accepted')
  self.assertIn('VERIFIED',(self.root/'home'/'mission-graphs'/'m1.md').read_text())
  self.assertIn('accepted',(self.root/'home'/'system'/'run-log.md').read_text())
  oldpid=h.client.pid;h.stop();restored=self.make(recover=True);self.assertEqual(restored.director,d);self.assertNotEqual(restored.client.pid,oldpid)
  result=restored.turn(d,'same Director after supervisor replacement');self.assertEqual(result['threadId'],d)
  denied,_=self.native_call(restored,d,'message_actor',{'recipient':'foreign-original','operation':'resume','text':'bad'},'foreign')
  self.assertFalse(denied['ok']);self.assertFalse(any(r['authorization'] for r in self.relay.requests))
  (self.root/'observations.json').write_text(json.dumps({'native_director':d,'native_controller':c,'events':h.events+restored.events,'result':'PASS'},indent=2))


 def test_native_hostile_worker_and_identity_boundaries(self):
  h,d=self.setup();c=self.mission(h,d)
  canary=self.root/'private'/'dummy-private';canary.write_text('unchanged')
  ledger=self.root/'home'/'DIRECTOR_STATE.md';before=ledger.read_bytes()
  out,_=self.native_call(h,d,'project_python',{'code':"raise Exception('Director must not run this')"},'director-worker')
  self.assertFalse(out['ok'])
  out,_=self.native_call(h,c,'project_python',{'code':'pass','actor':d},'forged-actor');self.assertFalse(out['ok'])
  out,_=self.native_call(h,c,'message_actor',{'recipient':d,'operation':'schedule','text':'recur'},'schedule');self.assertFalse(out['ok'])
  code="""import json,os,socket,subprocess,sys
from pathlib import Path
out={}
def denied(key,fn):
 try:fn();out[key]=False
 except PermissionError:out[key]=True
"""
  attacks={
   'private_read':f"Path({str(canary)!r}).read_text()",
   'private_write':f"Path({str(canary)!r}).write_text('bad')",
   'registry_read':f"Path({str(self.root/'authority'/'authority.sqlite3')!r}).read_bytes()",
   'native_read':f"Path({str(self.root/'state'/'config.toml')!r}).read_bytes()",
   'own_ledger_write':f"Path({str(ledger)!r}).write_text('bad')",
   'shared_code_write':f"Path({str(A/'broker'/'native_host.py')!r}).write_text('bad')",
   'native_host_import':f"Path({str(A/'broker'/'helper_entry.py')!r}).read_bytes()",
   'foreign_hardlink':f"os.link({str(canary)!r},'foreign.alias')",
   'fork':"os.fork()",
   'subprocess':"subprocess.run(['/bin/sh','-c','true'])",
   'network':f"socket.create_connection(('127.0.0.1',{self.relay.server.server_address[1]}))",
  }
  for k,expression in attacks.items():code+=f"denied({k!r},lambda:{expression})\n"
  code+="Path('result.txt').write_text('useful result');print(json.dumps(out))"
  out,_=self.native_call(h,c,'project_python',{'code':code},'boundaries');self.assertTrue(out['ok'],out)
  denied=json.loads(out['stdout']);self.assertEqual(set(denied),set(attacks));self.assertTrue(all(denied.values()),denied)
  self.assertEqual(canary.read_text(),'unchanged');self.assertEqual(ledger.read_bytes(),before)
  self.assertFalse((self.root/'project'/'foreign.alias').exists())
  (self.root/'observations.json').write_text(json.dumps({'native_director':d,'native_controller':c,'denials':denied,'events':h.events},indent=2))

 def test_uncertain_effect_survives_supervisor_recovery_and_refuses_retry(self):
  h,d=self.setup();c=self.mission(h,d)
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('partial');raise SystemExit(7)"},'interrupt')
  self.assertFalse(out['ok']);self.assertEqual(h.state['missions']['m1']['status'],'uncertain')
  h.stop();h=self.make(recover=True)
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('BAD RETRY')"},'uncertain-retry')
  self.assertFalse(out['ok']);self.assertIn('reconcile_active',out['reason']);self.assertEqual((self.root/'project'/'result.txt').read_text(),'partial')
  returned,_=self.native_call(h,c,'return_result',{},'uncertain-return');self.assertFalse(returned['ok'])
  (self.root/'observations.json').write_text(json.dumps({'events':h.events,'uncertain_effect_preserved':True},indent=2))

 def test_missing_authority_and_changed_helper_fail_before_effect(self):
  h,d=self.setup();c=self.mission(h,d)
  auth=Path(h.state['missions']['m1']['authorization_ref']);original=auth.read_bytes();auth.write_bytes(original+b' ')
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('bad')"},'altered-approval');self.assertFalse(out['ok']);self.assertFalse((self.root/'project'/'result.txt').exists())
  auth.write_bytes(original)
  helper=self.root/'home'/'scripts'/'controller-write-guard.py';raw=helper.read_bytes();helper.write_bytes(raw+b'\n# owner drift\n')
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('bad')"},'altered-helper');self.assertFalse(out['ok']);self.assertFalse((self.root/'project'/'result.txt').exists())
  helper.write_bytes(raw);h.registry.revoke_authorization(str(auth))
  out,_=self.native_call(h,c,'project_python',{'code':'pass'},'revoked-approval');self.assertFalse(out['ok'])
  h.stop();db=self.root/'authority'/'authority.sqlite3';db.rename(db.with_suffix('.retained'))
  with self.assertRaises((ValueError,OSError)):self.make(recover=True)
  self.assertFalse(db.exists());self.assertIsNone(h.client.pid)

 def test_new_external_project_and_shared_registry_ownership(self):
  h,d=self.setup();target=self.root/'new-project';self.assertFalse(target.exists())
  h.assign_mission('new',project=target,expected_files={'result.txt':'useful result'},description='Create new project',create_project=True)
  out,_=self.native_call(h,d,'dispatch_mission',{'mission_id':'new'},'dispatch-new');self.assertTrue(out['ok']);h.run_pending();c=h.state['missions']['new']['controller']
  out,_=self.native_call(h,c,'project_python',{'code':"from pathlib import Path;Path('result.txt').write_text('useful result')"},'new-work');self.assertTrue(out['ok'],out)
  for n in ('home2','private2','state2','tmp2'):(self.root/n).mkdir(mode=0o700)
  other=NativeHost(home=self.root/'home2',registry_root=self.root/'authority',private_root=self.root/'private2',native_state=self.root/'state2',native_temp=self.root/'tmp2',relay_url=self.relay.url,model='isolated-team-test',registry=h.registry)
  self.hosts.append(other);d2=other.first_chat();out,_=self.native_call(other,d2,'setup_team',{},'setup2');self.assertTrue(out['ok'],out)
  with self.assertRaises(ValueError):other.assign_mission('conflict',project=target,expected_files={'result.txt':'stolen'},description='conflict')
  out,_=self.native_call(other,d2,'message_actor',{'recipient':d,'operation':'send','text':'foreign'},'foreign-native-recipient');self.assertFalse(out['ok']);self.assertEqual(other.state['queue'],[])
  with self.assertRaises(ValueError):h.assign_mission('reserved',project=self.root/'state2',expected_files={'result.txt':'bad'},description='reserved')
  self.assertEqual((target/'result.txt').read_text(),'useful result')
  (self.root/'observations.json').write_text(json.dumps({'team_one_director':d,'team_two_director':d2,'events':h.events+other.events},indent=2))


 def test_recovery_refuses_replaced_native_root_before_launch(self):
  h,d=self.setup();h.stop()
  state=self.root/'state';state.rename(self.root/'retained-state');state.mkdir(mode=0o700)
  with self.assertRaisesRegex(ValueError,'roots missing, moved or replaced'):self.make(recover=True)
  self.assertEqual(list(state.iterdir()),[])
  self.assertTrue((self.root/'retained-state'/'config.toml').exists())

 def test_unconfirmed_delivery_survives_both_native_failure_positions(self):
  h,d=self.setup()
  for after_delivery in (False,True):
   pending={'kind':'message','sender':d,'target':d,'text':'unconfirmed '+str(after_delivery)}
   later={'kind':'message','sender':d,'target':d,'text':'later must not erase uncertainty'}
   h.state['queue']=[pending,later];h._save();real_turn=h.client.turn
   def interrupted(*args,**kwargs):
    if after_delivery:real_turn(*args,**kwargs)
    raise RuntimeError('injected interruption around native delivery completion')
   with patch.object(h.client,'turn',side_effect=interrupted):
    with self.assertRaises(RuntimeError):h.run_pending()
   with self.assertRaisesRegex(ValueError,'unconfirmed delivery'):h.run_pending()
   persisted=json.loads((self.root/'private'/'host.json').read_text())
   self.assertEqual(persisted['pending_delivery'],pending);self.assertEqual(persisted['queue'],[later])
   h.stop()
   with self.assertRaisesRegex(ValueError,'unconfirmed delivery'):self.make(recover=True)
   # Trusted test fixture reconciles only to exercise the independent second fault position.
   persisted.pop('pending_delivery');persisted['queue']=[]
   raw=(json.dumps(persisted,sort_keys=True,indent=2)+'\n').encode()
   (self.root/'private'/'host.json').write_bytes(raw);(self.root/'private'/'host.sha256').write_text(hashlib.sha256(raw).hexdigest())
   h=self.make(recover=True)

if __name__=='__main__':unittest.main()
