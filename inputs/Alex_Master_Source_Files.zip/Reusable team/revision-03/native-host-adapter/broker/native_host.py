"""Protected parent broker for a bounded, uninstalled local native team host.

This module is infrastructure, never a CLI/tool available to models. All model
calls arrive through NativeClient's matched private native thread/turn events.
"""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import uuid
from datetime import datetime, timezone

A=Path(__file__).resolve().parents[1]
P=A.parent/'create-independent-team'
sys.path[:0]=[str(A),str(P/'assets/runtime'),str(P/'scripts')]
from authority.registry import Registry, AuthorityError
from client.native_client import NativeClient
import restricted_runtime
import safe_io as io
from prepare_team import render_team, check_destination


def digest(value):
 return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def text(value):
 if not isinstance(value,str) or not value or '\x00' in value:raise ValueError('nonempty text required')
 return value

def name(value):
 if not isinstance(value,str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}',value):raise ValueError('simple mission identifier required')
 return value

def relpath(value):
 p=Path(text(value))
 if p.is_absolute() or '..' in p.parts or str(p)!=value or value=='.':raise ValueError('canonical relative file required')
 return p

def schema(properties):
 return {'type':'object','properties':properties,'required':list(properties),'additionalProperties':False}

TOOL_SCHEMAS={
 'setup_team':schema({}),
 'dispatch_mission':schema({'mission_id':{'type':'string'}}),
 'project_python':schema({'code':{'type':'string'}}),
 'return_result':schema({}),
 'accept_result':schema({'mission_id':{'type':'string'}}),
 'message_actor':schema({'recipient':{'type':'string'},'operation':{'type':'string'},'text':{'type':'string'}}),
}
TOOLS=[{'name':k,'description':{'setup_team':'Bind this already-created first chat as Director with no mission.','dispatch_mission':'Create a fresh controller for an operator-assigned mission.','project_python':'Run one fenced Python program in the assigned project. No network or child processes.','return_result':'Queue verified result evidence to this controller’s own Director.','accept_result':'Accept host-verified local evidence for a completed mission.','message_actor':'Send, queue or resume only an active owned team chat; schedules unavailable.'}[k],'inputSchema':s} for k,s in TOOL_SCHEMAS.items()]
INSTRUCTIONS='''You are running in the uninstalled restricted native team host. Use only its registered tools. The existing first chat invokes setup_team and becomes Director, initially without a mission. Operator assignments arrive later. Directors dispatch_mission and judge host-returned evidence with accept_result. Controllers use project_python for a bounded local program and return_result for actual evidence delivery. Never manufacture identity, grants or recipients. The host enforces authority; files and model arguments do not grant it. Read the local derived role supplied in subsequent messages. This host currently supports local files, one guarded command per play, no subprocesses/network/schedules. All tool errors require correction or explicit reconciliation, never bypass. Work on assigned external projects, keep team state in its separate home.'''

class NativeHost:
 def __init__(self,*,home,registry_root,private_root,native_state,native_temp,relay_url,model,recover=False,registry=None):
  self.home=restricted_runtime._path(home);self.private=restricted_runtime._path(private_root)
  self.native_state=restricted_runtime._path(native_state);self.native_temp=restricted_runtime._path(native_temp)
  self.registry_root=restricted_runtime._path(registry_root)
  self.events=[];self.client=None;self._lock=None
  for p in (self.private,self.registry_root):
   s=p.stat()
   if s.st_uid!=os.getuid() or s.st_mode&0o077:raise ValueError('owner-only private directories required')
  root_names={'home':self.home,'private':self.private,'registry':self.registry_root,'native_state':self.native_state,'native_temp':self.native_temp}
  roots=list(root_names.values())
  bindings={k:{'path':str(p),'dev':p.stat().st_dev,'ino':p.stat().st_ino} for k,p in root_names.items()}
  if any(a==b or a in b.parents or b in a.parents for i,a in enumerate(roots) for b in roots[i+1:]):raise ValueError('separate host roots required')
  with io.directory(self.private) as fd:
   lock=os.open('host.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=fd)
   try:io.checked(lock);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BaseException:os.close(lock);raise RuntimeError('host private state already owned or unsafe')
   self._lock=lock
  try:
   if recover:
    if registry is not None:raise ValueError('recover opens durable registry itself')
    self.registry=Registry.open(self.registry_root)
    raw=io.read_bytes(self.private/'host.json')
    if hashlib.sha256(raw).hexdigest()!=io.read_text(self.private/'host.sha256'):raise ValueError('host state damaged or interrupted')
    self.state=json.loads(raw)
    if self.state.get('root_bindings')!=bindings:raise ValueError('durable host roots missing, moved or replaced')
    if self.state['home']!=str(self.home):raise ValueError('host home mismatch')
    if self.state.get('pending_delivery') is not None:raise ValueError('unconfirmed delivery requires explicit reconciliation before recovery')
    self.registry.reserve_host_roots([self.private,self.native_state,self.native_temp])
    ctx=self.registry.context(self.state['director'])
    if ctx['team_id']!=self.state['team_id'] or ctx['team_home']!=str(self.home):raise ValueError('durable team mismatch')
    if self.state['phase']!='ready' or any(m['status']=='creating' for m in self.state['missions'].values()):raise ValueError('incomplete native enrollment requires reconciliation')
    ids=[self.state['director']]
    for m in self.state['missions'].values():
     if m.get('controller'):
      self.registry.recipient_check(self.state['director'],m['controller'],'recover');ids.append(m['controller'])
   else:
    check_destination(self.home)
    if (self.private/'host.json').exists():raise ValueError('existing host state requires explicit recovery')
    self.registry=registry if registry is not None else Registry.create(self.registry_root,native_data_roots=[self.private,self.native_state,self.native_temp])
    if registry is not None and self.registry.root!=self.registry_root:raise ValueError('supplied shared registry differs from declared root')
    if registry is not None:self.registry.reserve_host_roots([self.private,self.native_state,self.native_temp])
    self.state={'schema':'restricted-native-host/v1','home':str(self.home),'root_bindings':bindings,'phase':'empty','director':None,'team_id':None,'missions':{},'queue':[],'manifest':{}}
    ids=[]
   self.client=NativeClient(state_dir=self.native_state,temp_dir=self.native_temp,operating_home=self.home,relay_url=relay_url,model=model,dynamic_tools=TOOLS,tool_handler=self._handle,restorable_thread_ids=ids)
   self.client.initialize()
   self._loaded=set()
   if recover:
    # Resume the Director now; controllers resume lazily only after registry checks.
    self.client.resume(self.director);self._loaded.add(self.director)
   else:self._save()
  except BaseException:self.stop();raise

 @property
 def director(self):return self.state['director']

 def _save(self):
  raw=(json.dumps(self.state,sort_keys=True,indent=2)+'\n').encode()
  io.atomic_write(self.private/'host.json',raw)
  io.atomic_write(self.private/'host.sha256',hashlib.sha256(raw).hexdigest())

 def first_chat(self):
  if self.state['phase']!='empty':raise ValueError('first chat already created')
  result=self.client.start_thread(base_instructions=INSTRUCTIONS)
  self.state['director']=result['thread']['id'];self._loaded.add(self.director);self.state['phase']='intake';self._save()
  return self.director

 def _check_sources(self):
  # Model/native/worker processes cannot edit these generated files. Detect owner drift too.
  for relative,expected in self.state['manifest'].items():
   if hashlib.sha256(io.read_bytes(self.home/relative)).hexdigest()!=expected:raise ValueError('generated helper or role code changed')

 def _entry(self,actor,operation,data):
  ctx=self.registry.context(actor)
  if ctx['team_home']!=str(self.home) or ctx['team_id']!=self.state['team_id']:raise ValueError('foreign host actor')
  if operation!='prepare':self._check_sources()
  result=restricted_runtime.run([sys.executable,'-I','-S',A/'broker/helper_entry.py'],cwd=self.home,read_roots=[A,P,self.home],write_roots=[self.home],input_text=json.dumps({'context':ctx,'operation':operation,'data':data}),timeout=30)
  self.events.append({'kind':'fixed_helper','actor':actor,'operation':operation,'exit':result['exit'],'stdout':result['stdout'],'stderr':result['stderr']})
  if result['exit']!=0:raise ValueError('fixed helper refused: '+result['stdout'][-2500:]+result['stderr'][-1500:])
  parsed=json.loads(result['stdout'])
  if parsed['exit']!=0:raise ValueError('fixed helper command refused: '+json.dumps(parsed))
  return parsed

 def _setup(self,actor):
  if actor!=self.director or self.state['phase']!='intake':raise ValueError('only this first intake chat may set up once')
  check_destination(self.home)
  tid='team-'+str(uuid.uuid4());self.registry.register_team(tid,self.home,actor)
  self.state['team_id']=tid;self.state['phase']='preparing';self._save()
  files=render_team(self.home,platform='codex',director_id=actor,host_id=socket.gethostname(),team_id=tid)
  binding=json.loads(files['TEAM_BINDING.json']);binding['setup_status']='RESTRICTED_NATIVE_CANDIDATE';binding['runtime_observation']='Native identity and scoped broker active; live-model adoption not proven.'
  files['TEAM_BINDING.json']=json.dumps(binding,indent=2)+'\n'
  files['AGENTS.md']='# Restricted native candidate\n\n'+INSTRUCTIONS+'\n\nTEAM_ID: '+tid+'\nDIRECTOR_THREAD_ID: '+actor+'\nTEAM_HOME: '+str(self.home)+'\n\nThe copied role editions remain local. Only this protected host can provide helper authority. Editing bindings cannot activate ordinary desktop tools. Shared tool changes must be recorded as local proposals for the maintainer.\n'
  self.state['manifest']={k:hashlib.sha256(v.encode()).hexdigest() for k,v in files.items() if k.startswith(('roles/','scripts/','setup/')) or k in ('AGENTS.md','TEAM_BINDING.json')}
  self._entry(actor,'prepare',{'files':files})
  self.state['phase']='ready';self._save()
  return {'director':actor,'team_id':tid,'missions':0,'role_instructions':files['roles/alex-director/SKILL.md']}

 def assign_mission(self,mission_id,*,project,expected_files,description,create_project=False):
  """Trusted operator input only; not registered as a model-callable tool."""
  if self.state['phase']!='ready':raise ValueError('setup must finish before mission')
  mid=name(mission_id)
  if mid in self.state['missions']:raise ValueError('mission exists; explicit reconciliation required')
  if not isinstance(expected_files,dict) or not expected_files:raise ValueError('observable expected files required')
  for path,content in expected_files.items():relpath(path);text(content)
  text(description)
  if '\n' in description or '|' in description:raise ValueError('single line description required')
  project=Path(project).absolute()
  if create_project:
   if project.exists():raise ValueError('new project already exists')
   with io.directory(project.parent) as fd:os.mkdir(project.name,0o700,dir_fd=fd)
  self.registry.assign_project(self.state['team_id'],project,mid)
  self.state['missions'][mid]={'project':str(project),'description':description,'expected_files':expected_files,'status':'assigned','generation':1,'controller':None}
  self._save()

 def _mission_for(self,actor):
  ctx=self.registry.context(actor)
  if ctx['role']!='controller':raise ValueError('controller required')
  matches=[(k,m) for k,m in self.state['missions'].items() if m.get('controller')==actor]
  if len(matches)!=1:raise ValueError('current controller mission missing')
  return matches[0]

 def _dispatch(self,mid):
  m=self.state['missions'][mid]
  if m['status']!='dispatch_queued':raise ValueError('dispatch state is not pending')
  m['status']='creating';self._save()
  result=self.client.start_thread(base_instructions=INSTRUCTIONS,developer_instructions='You are the fresh controller for '+mid+'. Return only to the bound Director. Local role:\n'+io.read_text(self.home/'roles/alex-workflow-conductor/SKILL.md'))
  actor=result['thread']['id'];self._loaded.add(actor);m['controller']=actor
  self.registry.register_controller(self.state['team_id'],actor,mid,m['generation'])
  scope={'provider':'local-filesystem','action':'update','account':'uid:'+str(os.getuid()),'resource_type':'project','resource':m['project']}
  outcome={'expected_files':m['expected_files']};ref=self.home/'mission-graphs'/(mid+'-authorization.json');graph=self.home/'mission-graphs'/(mid+'.md')
  auth={'schema':'independent-team-authorization/v1','team_id':self.state['team_id'],'director_thread_id':self.director,'mission_id':mid,'next_play_id':mid+'-play-1','controller_thread_id':actor,'controller_generation':m['generation'],'outcome_hash':digest(outcome),'authorization_scope':scope}
  raw=self.registry.approve(self.state['team_id'],ref,auth)
  m.update(scope=scope,outcome=outcome,authorization_ref=str(ref),play_id=auth['next_play_id'],graph=str(graph))
  fields={'TEAM_ID':self.state['team_id'],'MISSION_ID':mid,'OWNER_OUTCOME':m['description'],'ACCEPTANCE':'Exact host readback of expected files','PRIORITY':'normal','PROJECT':m['project'],'CONTROLLER':actor,'SUPERVISING_DIRECTOR_THREAD_ID':self.director,'MISSION_GRAPH':str(graph),'ACCEPTED_CHECKPOINT':'NONE','REMAINING':m['description'],'NEXT_PLAY':m['description'],'NEXT_PLAY_ID':m['play_id'],'LAST_DISPATCH':'NONE','LAST_RECEIPT':'NONE','LAST_RECONCILED_AT':'NONE','OWNER_BOUNDARY':'local files only','STATUS':'ACTIVE','CONTROLLER_THREAD_ID':actor,'CONTROLLER_GENERATION':str(m['generation']),'CONTROLLER_HOST_ID':socket.gethostname(),'NEXT_PLAY_OUTCOME_HASH':digest(outcome),'AUTHORIZATION_REF':str(ref),'AUTHORIZATION_SCOPE_HASH':digest(scope)}
  ledger=io.read_text(self.home/'DIRECTOR_STATE.md')+'\n## Mission: '+mid+'\n'+''.join(k+': '+v+'\n' for k,v in fields.items())
  updated=datetime.now(timezone.utc).isoformat()
  graph_text=f"TEAM_ID: {self.state['team_id']}\nSUPERVISING_DIRECTOR_THREAD_ID: {self.director}\nMISSION_ID: {mid}\nPROJECT: {m['project']}\n\n| NODE_ID | REQUIRED | STATUS | DEPENDS_ON | CONTROLLER | ACCEPTANCE | EVIDENCE | LAST_RECEIPT | NEXT_ACTION | UPDATED_AT | OWNER_FACING |\n|---|---|---|---|---|---|---|---|---|---|---|\n| n1 | yes | ACTIVE | NONE | {actor} | exact local readback | - | - | work | {updated} | no |\n\n## Node: n1\nUPDATED_AT: {updated}\n"
  self._entry(self.director,'mission',{'mission_id':mid,'graph':str(graph.relative_to(self.home)),'graph_text':graph_text,'ledger_text':ledger,'authorization_ref':str(ref.relative_to(self.home)),'authorization_text':raw.decode()})
  m['status']='active';self._save()
  # Complete a real native delivery turn, persisting this controller before recovery.
  self.registry.recipient_check(self.director,actor,'send')
  self.client.turn(actor,'Authorized mission '+mid+': '+m['description']+'\nProject: '+m['project']+'\nExpected files: '+json.dumps(m['expected_files'])+'\nUse project_python, then return_result. Existing project instructions:\n'+self._project_instructions(m))
  self.events.append({'kind':'native_delivery','sender':self.director,'recipient':actor,'mission_id':mid,'status':'delivered'})

 def _project_instructions(self,m):
  p=Path(m['project'])/'AGENTS.md'
  return io.read_text(p)[:32000] if io.exists(p) else '(No project-root AGENTS.md)'

 def _guard(self,actor,args):
  result=self._entry(actor,'helper',{'name':'guard','args':list(map(str,args))})
  return json.loads(result['stdout'].splitlines()[-1])

 def _work(self,actor,code):
  mid,m=self._mission_for(actor);text(code)
  if m['status'] not in ('active','completed','accepted','uncertain'):raise ValueError('mission not available for work')
  if io.exists(self.home/'DIRECTOR_STATE.md.lock'):raise ValueError('ledger transaction incomplete')
  raw=io.read_bytes(m['authorization_ref']);self.registry.check_authorization(actor,m['authorization_ref'],raw)
  if m['project'] not in self.registry.assigned_projects(actor):raise ValueError('project not assigned')
  args=['acquire','--mission-id',mid,'--node-id','n1','--next-play-id',m['play_id'],'--controller-thread-id',actor,'--controller-generation',m['generation'],'--provider','local-filesystem','--action','update','--account','uid:'+str(os.getuid()),'--resource-type','project','--resource-target',m['project'],'--outcome-json',json.dumps(m['outcome']),'--authorization-ref',m['authorization_ref'],'--authorization-scope-json',json.dumps(m['scope'])]
  claim=self._guard(actor,args)
  if claim['status']=='replay_completed':return {'status':'replay_completed','readback':claim['readback']}
  if claim['status']!='granted':raise ValueError('guard did not grant execution')
  m['status']='uncertain';self._save()
  # No fork prevents a background descendant from outliving the write fence.
  policy=restricted_runtime.profile([self.home,Path(m['project'])],[Path(m['project'])])+'\n(deny process-fork)\n'
  env={'PATH':'/usr/bin:/bin','LANG':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
  run=subprocess.run(['/usr/bin/sandbox-exec','-p',policy,sys.executable,'-I','-S','-c',code],cwd=m['project'],env=env,close_fds=True,text=True,capture_output=True,timeout=20)
  result={'exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
  self.events.append({'kind':'project_worker','actor':actor,'mission_id':mid,**result})
  if run.returncode!=0:raise ValueError('project effect unresolved; reconcile before retry: '+run.stderr[-1200:])
  self.registry.check_authorization(actor,m['authorization_ref'],io.read_bytes(m['authorization_ref']))
  self.registry.assigned_projects(actor)
  readback={'target_id':m['project'],'files':{}}
  for relative,expected in m['expected_files'].items():
   raw=io.read_bytes(Path(m['project'])/relpath(relative))
   if raw!=expected.encode():raise ValueError('readback differs from frozen expected outcome; reconcile before retry')
   readback['files'][relative]=hashlib.sha256(raw).hexdigest()
  completed=self._guard(actor,['complete','--resource-key',claim['resource_key'],'--write-intent-id',claim['write_intent_id'],'--target-id',m['project'],'--readback-json',json.dumps(readback)])
  if completed['status'] not in ('completed','replay_completed'):raise ValueError('guard completion missing')
  m.update(status='completed',readback=readback,receipt=claim['write_intent_id']);self._save()
  return {'status':'completed','readback':readback,**result}

 def _handle(self,call):
  try:
   args=call.arguments
   if call.tool not in TOOL_SCHEMAS or not isinstance(args,dict) or set(args)!=set(TOOL_SCHEMAS[call.tool]['properties']):raise ValueError('unsupported operation or supplied identity/extra arguments')
   if any(not isinstance(v,str) for v in args.values()):raise ValueError('tool string arguments required')
   actor=call.thread_id
   if call.tool=='setup_team':value=self._setup(actor)
   else:
    ctx=self.registry.context(actor)
    if ctx['team_id']!=self.state['team_id'] or ctx['team_home']!=str(self.home):raise ValueError('foreign host actor')
    if self.state['phase']!='ready':raise ValueError('setup incomplete')
    if call.tool=='dispatch_mission':
     if ctx['role']!='director':raise ValueError('Director required')
     mid=name(args['mission_id']);m=self.state['missions'][mid]
     if m['status']!='assigned':raise ValueError('mission already dispatched or not assigned')
     m['status']='dispatch_queued';self.state['queue'].append({'kind':'dispatch','mission_id':mid,'sender':actor});self._save();value={'queued':'dispatch','mission_id':mid}
    elif call.tool=='project_python':value=self._work(actor,args['code'])
    elif call.tool=='return_result':
     mid,m=self._mission_for(actor)
     if m['status']!='completed':raise ValueError('completed verified result required')
     self.registry.recipient_check(actor,self.director,'queue')
     self.state['queue'].append({'kind':'message','sender':actor,'target':self.director,'text':'Verified local result for '+mid+': '+json.dumps(m['readback'])+'. Judge with accept_result.'});self._save();value={'queued':'return','delivered':False}
    elif call.tool=='accept_result':
     if ctx['role']!='director':raise ValueError('Director required')
     mid=name(args['mission_id']);m=self.state['missions'][mid]
     if m['status']!='completed':raise ValueError('host-verified completed result required')
     self._entry(actor,'accept',{'graph':str(Path(m['graph']).relative_to(self.home)),'node':'n1','evidence':json.dumps(m['readback'],sort_keys=True),'receipt':m['receipt'],'job':mid})
     m['status']='accepted';self._save();value={'status':'accepted','mission_id':mid}
    else:
     check=self.registry.recipient_check(actor,args['recipient'],args['operation'])
     if args['operation']=='resume':self.state['queue'].append({'kind':'resume','sender':actor,'target':args['recipient']})
     elif args['operation'] in ('send','queue'):self.state['queue'].append({'kind':'message','sender':actor,'target':args['recipient'],'text':args['text']})
     else:raise ValueError('unsupported transport')
     self._save();value={'queued':args['operation'],'delivered':False}
   body={'ok':True,**value}
  except Exception as e:body={'ok':False,'reason':str(e)}
  self.events.append({'kind':'native_tool','thread_id':call.thread_id,'turn_id':call.turn_id,'call_id':call.call_id,'tool':call.tool,'result':body})
  return {'contentItems':[{'type':'inputText','text':json.dumps(body)}],'success':body['ok']}

 def turn(self,actor,prompt):
  if self.state['phase'] in ('intake','preparing'):
   if actor!=self.director:raise ValueError('foreign intake actor')
  else:
   self.registry.recipient_check(self.director,actor,'send')
  self._ensure_loaded(actor)
  return self.client.turn(actor,prompt)

 def _ensure_loaded(self,actor):
  if actor not in self._loaded:
   self.registry.recipient_check(self.director,actor,'resume')
   self.client.resume(actor);self._loaded.add(actor)

 def run_pending(self,limit=8):
  """Explicit foreground pump; no daemon, schedule or hidden ongoing service."""
  if self.state.get('pending_delivery') is not None:raise ValueError('unconfirmed delivery requires explicit reconciliation')
  count=0
  while self.state['queue'] and count<limit:
   item=self.state['queue'][0]
   # Persist consumption first: crash is lost/unconfirmed delivery, never auto replay.
   self.state['queue']=self.state['queue'][1:];self.state['pending_delivery']=item;self._save()
   if item['kind']=='dispatch':
    self.registry.context(item['sender']);self._dispatch(item['mission_id'])
   else:
    op='resume' if item['kind']=='resume' else 'send'
    self.registry.recipient_check(item['sender'],item['target'],op)
    if op=='resume':self.client.resume(item['target'])
    else:
     self._ensure_loaded(item['target']);self.client.turn(item['target'],item['text'])
    self.events.append({'kind':'native_delivery','sender':item['sender'],'recipient':item['target'],'operation':op,'status':'delivered'})
   self.state.pop('pending_delivery',None);self._save();count+=1
  return count

 def stop(self):
  if self.client:self.client.stop()
  if self._lock is not None:os.close(self._lock);self._lock=None
