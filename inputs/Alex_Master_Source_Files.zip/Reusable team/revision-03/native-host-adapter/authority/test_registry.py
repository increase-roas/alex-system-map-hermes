import sys, pathlib, tempfile, unittest, hashlib, json, sqlite3, os, concurrent.futures
BASE=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'native-host-adapter/authority'))
try:
 from registry import Registry, AuthorityError
except ImportError:
 Registry=None
 AuthorityError=RuntimeError
class AuthorityTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.root=pathlib.Path(self.tmp.name).resolve(); self.private=self.root/'private'; self.private.mkdir(mode=0o700)
  self.home=self.root/'team'; self.home.mkdir(); self.project=self.root/'project'; self.project.mkdir()
  self.assertIsNotNone(Registry,'protected registry implementation absent')
  self.r=Registry.create(self.private)
 def tearDown(self): self.tmp.cleanup()
 def team(self): self.r.register_team('team-a',self.home,'native-director-a')
 def controller(self): self.r.register_controller('team-a','native-controller-a','mission-a',1)
 def record(self):
  return dict(schema='independent-team-authorization/v1',team_id='team-a',director_thread_id='native-director-a',mission_id='mission-a',next_play_id='play-a',controller_thread_id='native-controller-a',controller_generation=1,outcome_hash='a'*64,authorization_scope=dict(action='update',provider='local-filesystem',account='uid:'+str(os.getuid()),resource_type='project',resource=str(self.project)))
 def approve(self):
  self.r.assign_project('team-a',self.project,'mission-a'); ref=self.home/'mission-graphs'/'a.authorization.json'; return ref,self.r.approve('team-a',ref,self.record())
 def test_empty_startup_has_no_implicit_grants(self):
  self.team(); c=self.r.context('native-director-a'); self.assertEqual(c['authorizations'],{}); self.assertEqual(c['resource_leases'],[]); self.assertEqual(self.r.assigned_projects('native-director-a'),[])
 def test_later_mission_assignment_approval_and_reopen(self):
  self.team(); self.controller(); ref,raw=self.approve(); r=Registry.open(self.private)
  self.assertEqual(r.context('native-controller-a')['role'],'controller'); self.assertEqual(r.assigned_projects('native-controller-a'),[str(self.project)])
  self.assertEqual(r.context('native-controller-a')['authorizations'][str(ref)],hashlib.sha256(raw).hexdigest()); r.check_authorization('native-controller-a',ref,raw)
 def test_unregistered_forged_actor_denied(self):
  self.team()
  with self.assertRaises(AuthorityError): self.r.context('native-forged')
 def test_native_identity_cannot_be_reused(self):
  self.team()
  with self.assertRaises(AuthorityError): self.r.register_controller('team-a','native-director-a','mission-a',1)
 def test_controller_projects_are_mission_scoped(self):
  self.team(); self.controller(); self.r.assign_project('team-a',self.project,'mission-b'); self.assertEqual(self.r.assigned_projects('native-controller-a'),[])
 def test_recipient_foreign_revoked_and_schedule_denied(self):
  self.team(); self.controller(); other=self.root/'other';other.mkdir(); self.r.register_team('team-b',other,'native-director-b')
  self.r.recipient_check('native-director-a','native-controller-a','send')
  for target,op in [('native-director-b','send'),('unknown','send'),('native-controller-a','schedule')]:
   with self.assertRaises(AuthorityError):self.r.recipient_check('native-director-a',target,op)
  self.r.revoke_actor('native-controller-a')
  with self.assertRaises(AuthorityError):self.r.recipient_check('native-director-a','native-controller-a','send')
 def test_missing_altered_and_revoked_authorization_denied(self):
  self.team();self.controller();ref,raw=self.approve()
  with self.assertRaises(AuthorityError):self.r.check_authorization('native-controller-a',ref,raw+b' ')
  with self.assertRaises(AuthorityError):self.r.check_authorization('native-controller-a',ref.with_name('missing'),raw)
  self.r.revoke_authorization(ref)
  with self.assertRaises(AuthorityError):self.r.check_authorization('native-controller-a',ref,raw)
  self.assertEqual(self.r.context('native-controller-a')['authorizations'],{})
 def test_generation_supersedes_old_controller(self):
  self.team();self.controller();ref,raw=self.approve();self.r.register_controller('team-a','native-controller-new','mission-a',2)
  with self.assertRaises(AuthorityError):self.r.context('native-controller-a')
  self.assertEqual(self.r.context('native-controller-new')['authorizations'],{})
 def test_overlapping_and_reserved_roots_denied(self):
  self.team(); other=self.root/'other';other.mkdir();self.r.register_team('team-b',other,'native-director-b'); self.r.assign_project('team-a',self.project,'mission-a'); child=self.project/'child';child.mkdir()
  for path in [child,self.home,self.root,self.private]:
   with self.assertRaises(AuthorityError):self.r.assign_project('team-b',path,'mission-b')
 def test_symlink_root_rejected(self):
  self.team();link=self.root/'link';link.symlink_to(self.project,target_is_directory=True)
  with self.assertRaises(AuthorityError):self.r.assign_project('team-a',link,'mission-a')
 def test_missing_and_tampered_registry_fail_closed(self):
  self.team();db=self.private/'authority.sqlite3';data=db.read_bytes();db.write_bytes(data+b'tamper')
  with self.assertRaises(AuthorityError):Registry.open(self.private)
  db.unlink()
  with self.assertRaises(AuthorityError):Registry.open(self.private)
  with self.assertRaises(AuthorityError):self.r.context('native-director-a')
 def test_hardlinked_database_rejected(self):
  self.team();os.link(self.private/'authority.sqlite3',self.root/'db-copy')
  with self.assertRaises(AuthorityError):Registry.open(self.private)
 def test_unsupported_provider_refuses_real_access(self):
  self.team();self.controller();self.r.assign_project('team-a',self.project,'mission-a');record=self.record();record['authorization_scope']['provider']='google'
  with self.assertRaises(AuthorityError):self.r.approve('team-a',self.home/'mission-graphs'/'a.json',record)
 def test_concurrent_conflicting_project_claim_has_one_winner(self):
  self.team(); other=self.root/'other';other.mkdir();self.r.register_team('team-b',other,'native-director-b')
  def claim(t):
   try:Registry.open(self.private).assign_project(t,self.project,'mission');return True
   except AuthorityError:return False
  with concurrent.futures.ThreadPoolExecutor(2) as ex:self.assertEqual(sum(ex.map(claim,['team-a','team-b'])),1)
 def test_missing_project_is_authority_error(self):
  self.team()
  with self.assertRaises(AuthorityError):self.r.assign_project('team-a',self.root/'missing','mission-a')
 def test_director_revocation_closes_team(self):
  self.team();self.controller();self.approve();self.r.revoke_actor('native-director-a')
  with self.assertRaises(AuthorityError):self.r.context('native-controller-a')
  with self.assertRaises(AuthorityError):self.r.register_controller('team-a','fresh','mission-a',2)
 def test_native_data_root_assignment_refused(self):
  native=self.root/'native-data';native.mkdir();p=self.root/'private-second';p.mkdir(mode=0o700)
  r=Registry.create(p,native_data_roots=[native]);r.register_team('team-a',self.home,'native-director-a')
  with self.assertRaises(AuthorityError):r.assign_project('team-a',native,'mission-a')
 def test_home_and_project_replacement_fail_closed(self):
  self.team();self.controller();self.r.assign_project('team-a',self.project,'mission-a');self.project.rename(self.root/'project-old');self.project.mkdir()
  with self.assertRaises(AuthorityError):self.r.assigned_projects('native-controller-a')
  self.home.rename(self.root/'home-old');self.home.mkdir()
  with self.assertRaises(AuthorityError):self.r.context('native-director-a')
 def test_invalid_schema_rejected_even_with_matching_seal(self):
  self.team();db=self.private/'authority.sqlite3';c=sqlite3.connect(db);c.execute('DROP TABLE leases');c.commit();c.close()
  (self.private/'registry.sha256').write_text(hashlib.sha256(db.read_bytes()).hexdigest())
  with self.assertRaises(AuthorityError):Registry.open(self.private)
 def test_new_shared_host_roots_are_reserved_and_cannot_overlap_projects(self):
  self.team();self.r.assign_project('team-a',self.project,'mission-a');new=self.root/'second-host';new.mkdir()
  self.r.reserve_host_roots([new]);self.r.reserve_host_roots([new])
  with self.assertRaises(AuthorityError):self.r.assign_project('team-a',new,'mission-b')
  with self.assertRaises(AuthorityError):self.r.reserve_host_roots([self.project])
 def test_unsupported_local_action_denied(self):
  self.team();self.controller();self.r.assign_project('team-a',self.project,'mission-a');record=self.record();record['authorization_scope']['action']='delete'
  with self.assertRaises(AuthorityError):self.r.approve('team-a',self.home/'mission-graphs'/'a.json',record)
 def test_worker_cannot_access_registry_but_assigned_project_works(self):
  self.team();self.controller();self.approve(); canary=self.private/'canary';canary.write_text('host-private')
  sys.path.insert(0,str(BASE/'create-independent-team/assets/runtime'));import restricted_runtime
  code='''from pathlib import Path
import json
private=Path(%r)
project=Path(%r)
blocked=[]
for p in [private/'authority.sqlite3',private/'canary']:
 for op in ['read','write']:
  try:
   p.read_bytes() if op=='read' else p.write_text('tampered')
   blocked.append(False)
  except PermissionError:blocked.append(True)
(project/'proof').write_text('works')
print(json.dumps(blocked))
'''%(str(self.private),str(self.project))
  result=restricted_runtime.run([sys.executable,'-I','-S','-c',code],cwd=self.home,read_roots=[self.home],write_roots=[self.project])
  self.assertEqual(result['exit'],0,result['stderr']);self.assertEqual(json.loads(result['stdout']),[True]*4);self.assertEqual((self.project/'proof').read_text(),'works');self.assertEqual(canary.read_text(),'host-private');self.r.context('native-controller-a')
if __name__=='__main__':unittest.main()
