# Protected parent authority registry

This is an uninstalled local library. It opens no socket, exposes no command-line endpoint, creates no schedules and contacts no provider. The native client/broker owns one Registry object outside every model worker. The public Python methods are **trusted parent integration calls**, not a worker tool API. An actor string is only a lookup key after the parent has authenticated its real native event source; calling `context('some-id')` does not authenticate a caller. Synthetic unit IDs below prove lookup policy, not native identity authentication.

The parent must supply an OS sandbox that excludes the private registry root, native chat data, credentials and all other tool routes from every worker. File ownership and 0700/0600 permissions alone cannot protect against an unrestricted process with the same UID. The SQLite checksum seal detects accidental/corrupt/interrupted changes; it is not a defense against an unrestricted same-UID attacker rewriting both database and seal. The real restricted-runtime canary test demonstrates the required filesystem exclusion only for that subprocess route. The parent must prove its actual native engine uses that boundary.

## API contract

`Registry.create(private_root, native_data_roots=())` initializes an existing canonical, owner-only, empty directory. Explicit trusted installation action only. `Registry.open(private_root)` recovers an existing registry and refuses missing files, altered checksums, schema drift, failed integrity/FK checks, wrong owners/permissions, links and live database inode replacement. Never call `create` as a fallback to failed recovery; never reconstruct membership/approvals from worker-readable bindings. Missing durable authority stops the host.

`reserve_host_roots(paths)` adds canonical private/native/temp directories for each further client to the same registry and refuses overlaps with existing team/project roots. All teams on one trusted host must share this single registry; per-team registries cannot prove cross-team ownership exclusion. Registry creation and this reservation remain trusted parent-only operations.

`register_team(team_id, team_home, director_id)` takes the first Director ID from a trusted native creation response, and an existing canonical manually empty home. It pins the home device/inode and creates no controller, mission, project, authorization or lease. The separate parent renderer writes setup files after registration. Homes cannot overlap existing homes, assigned projects, private registry or supplied native data roots.

`register_controller(team_id, native_id, mission_id, generation)` takes a fresh native creation response from the trusted parent. IDs are globally unique and never reusable after revocation. Generation is a positive integer strictly greater than the prior generation for that team/mission. A newer generation revokes old controller membership and current approvals while retaining history. This method performs no native thread creation and must never be exposed to a worker.

`assign_project(team_id, path, mission_id)` is a trusted operator assignment after setup. The parent may explicitly create the project first; the registry only accepts existing canonical directories with no symlink component and pins device/inode. It refuses overlap with any team home, registry/native-data roots or another team's project. It conservatively reserves overlapping roots exclusively to one mission even within the same team. Claims remain durable through revocation; there is no automatic reassignment/release path in this bounded version.

`assigned_projects(actor)` returns sorted pinned canonical path strings for active registered actors. The Director receives the team's assigned roots for read-only use; a controller receives only its bound mission's roots. The broker must additionally require current authorization plus guard claim/state before any worker write. This query grants no write permission by itself.

`approve(team_id, ref, record)` is available only to the trusted human/operator host action. It validates team, Director, active controller, mission, generation, next play, outcome hash and scope; stores the approved exact record bytes/digest and a canonical resource lease; and returns `bytes`. The parent writes these exact bytes at `ref`, under that team's `mission-graphs` directory. It never writes authorization into a worker-writable folder by itself. Each reference is immutable and used once; use a fresh reference for every approval. A new approval deactivates earlier approvals for that mission without deleting them. Failed writing after approval leaves an unusable missing record and cannot create authority from worker data.

The record schema is the existing `independent-team-authorization/v1` helper contract. The only scope supported is exactly:

```json
{"action":"update","provider":"local-filesystem","account":"uid:<actual host uid>","resource_type":"project","resource":"<canonical project path assigned to this controller mission>"}
```

No external account/provider, composite scope, schedule or invented mock capability is accepted. The canonical resource key uses the existing `controller-resource-key/v1` digest shape, Unicode NFC normalization, casefolded provider/resource type, account and target. It has no team salt. Conflicting grants serialize under a private lock and SQLite transaction; durable unique claims permit one owner. Project overlap conflicts are also checked inside that transaction.

`context(actor)` returns `team_id`, `team_home`, `role`, `thread_id`, `director_thread_id`, `authorizations` (absolute reference → exact SHA256 digest) and `resource_leases` (canonical key list). Controllers see only active approvals for their own identity/current generation and leases within their assigned mission roots. Director sees the team's current approvals. Context is host-provided subprocess input, never accepted from worker arguments or environment.

`check_authorization(actor, ref, raw)` requires the current context-approved digest of the exact bytes. Missing, altered, revoked, superseded or wrong-controller records fail closed. The existing helper additionally validates mission/play/outcome/scope hashes against ledger state; parent broker owns its pending-claim/completed/uncertain fences.

`recipient_check(actor, target, operation)` accepts only owned, active registered same-team actors for `send`, `queue`, `resume`, `recover`. Parent must invoke the native route with this checked target only. Unknown/foreign/revoked recipients have no arbitrary-native-target fallback. All schedules/recurrence and unknown operations are explicitly refused; no scheduling is created.

`revoke_actor(actor)` retains membership rows but makes the actor and its approvals inactive. Revoking the Director closes the entire team and its approvals; new controllers/projects/approvals are then refused. `revoke_authorization(ref)` deactivates but preserves the historical digest/record. No destructive history deletion or reactivation API exists.

All operations raise `AuthorityError` for rejection. Database commits followed by interrupted seal writes deliberately cause fail-closed recovery rather than reconstructing authority. Multi-step native thread creation plus registration must be coordinated by the parent; unregistered partially-created threads acquire no authority.

## Observed test receipts

Behavioral suite: 22 tests passed on macOS on 2026-10-03. Tests first failed because the implementation was absent; later regression tests exposed missing-path exception handling and Director revocation before those were repaired. Tests use isolated temporary folders and synthetic IDs only. See `authority-tests/receipt.txt` in the task's scratch host-layer folder for the recorded fresh run. The worker canary test calls the existing production `restricted_runtime.run`, denies reading/writing both SQLite registry and canary, and successfully writes its assigned external project. No live model/provider/native team was started by these tests.
