"""Trusted parent-only authority. No CLI, service, worker registration or identity resolver.

Native identity authentication is the caller's event-bound responsibility. Permissions
alone do not exclude same-uid workers: caller MUST sandbox every worker/tool route.
"""
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import stat
import unicodedata

class AuthorityError(ValueError):
    pass

SCHEMA = [
 'CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)',
 'CREATE TABLE teams (id TEXT PRIMARY KEY, home TEXT UNIQUE NOT NULL, dev INTEGER NOT NULL, ino INTEGER NOT NULL, director TEXT UNIQUE NOT NULL)',
 'CREATE TABLE actors (id TEXT PRIMARY KEY, team TEXT NOT NULL REFERENCES teams(id), role TEXT NOT NULL CHECK(role IN (\'director\',\'controller\')), mission TEXT, generation INTEGER, active INTEGER NOT NULL CHECK(active IN (0,1)))',
 'CREATE TABLE projects (path TEXT PRIMARY KEY, team TEXT NOT NULL REFERENCES teams(id), mission TEXT NOT NULL, dev INTEGER NOT NULL, ino INTEGER NOT NULL)',
 'CREATE TABLE approvals (ref TEXT PRIMARY KEY, team TEXT NOT NULL REFERENCES teams(id), controller TEXT NOT NULL REFERENCES actors(id), mission TEXT NOT NULL, generation INTEGER NOT NULL, digest TEXT NOT NULL, record TEXT NOT NULL, active INTEGER NOT NULL CHECK(active IN (0,1)))',
 'CREATE TABLE leases (key TEXT PRIMARY KEY, team TEXT NOT NULL REFERENCES teams(id), resource TEXT NOT NULL)'
]

def _canonical(path):
    p=Path(path).absolute()
    try:
        valid=p == p.resolve(strict=True) and p.is_dir()
    except OSError as e:
        raise AuthorityError('existing canonical directory required') from e
    if not valid:
        raise AuthorityError('existing canonical directory without symlinks required')
    return p

def _overlap(a,b):
    return a==b or a in b.parents or b in a.parents

def _word(value):
    if not isinstance(value,str) or not value.strip() or '\x00' in value:
        raise AuthorityError('nonempty native identity/mission/team required')
    return value

def _key(scope):
    norm=lambda s:unicodedata.normalize('NFC',s)
    payload={'schema':'controller-resource-key/v1','provider':norm(scope['provider']).casefold(),
             'account':norm(scope['account']),'resource_type':norm(scope['resource_type']).casefold(),'target':norm(scope['resource'])}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

class Registry:
    """Pass only context/results to workers; never pass this object or its path as authority."""
    @classmethod
    def create(cls,private_root,*,native_data_roots=()):
        root=_canonical(private_root)
        cls._protected(root,directory=True)
        if any(root.iterdir()):raise AuthorityError('new protected registry root must be empty')
        reserved=[str(_canonical(p)) for p in native_data_roots]
        for name in ('authority.sqlite3','registry.lock','registry.sha256'):
            fd=os.open(root/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);os.close(fd)
        conn=sqlite3.connect(root/'authority.sqlite3')
        try:
            conn.execute('PRAGMA foreign_keys=ON')
            for sql in SCHEMA:conn.execute(sql)
            conn.execute('PRAGMA user_version=1')
            conn.execute('INSERT INTO meta VALUES (?,?)',('native_data_roots',json.dumps(reserved)))
            conn.commit()
        finally:conn.close()
        cls._seal(root)
        return cls.open(root)

    @classmethod
    def open(cls,private_root):
        obj=cls.__new__(cls);obj.root=_canonical(private_root);cls._protected(obj.root,directory=True)
        obj.db=obj.root/'authority.sqlite3'
        cls._protected(obj.db);s=obj.db.stat();obj.identity=(s.st_dev,s.st_ino)
        with obj._transaction():pass
        return obj

    @staticmethod
    def _protected(path,*,directory=False):
        try:s=path.lstat()
        except OSError as e:raise AuthorityError('protected registry missing') from e
        if s.st_uid != os.getuid() or s.st_mode & 0o077 or stat.S_ISLNK(s.st_mode):
            raise AuthorityError('registry owner, links or permissions invalid')
        if directory:
            if not stat.S_ISDIR(s.st_mode):raise AuthorityError('registry directory required')
        elif not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:
            raise AuthorityError('protected regular file without hardlinks required')

    @staticmethod
    def _seal(root):
        raw=hashlib.sha256((root/'authority.sqlite3').read_bytes()).hexdigest().encode()
        fd=os.open(root/'registry.sha256',os.O_WRONLY|os.O_TRUNC|os.O_NOFOLLOW)
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())

    @contextlib.contextmanager
    def _transaction(self):
        self._protected(self.root,directory=True);self._protected(self.root/'registry.lock')
        fd=os.open(self.root/'registry.lock',os.O_RDWR|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            conn=None
            try:
                self._protected(self.db);self._protected(self.root/'registry.sha256')
                s=self.db.stat()
                if (s.st_dev,s.st_ino)!=self.identity:raise AuthorityError('durable registry replaced')
                digest=hashlib.sha256(self.db.read_bytes()).hexdigest()
                if (self.root/'registry.sha256').read_text()!=digest:raise AuthorityError('durable registry altered or interrupted')
                conn=sqlite3.connect('file:'+str(self.db)+'?mode=rw',uri=True);conn.row_factory=sqlite3.Row
                conn.execute('PRAGMA foreign_keys=ON');conn.execute('BEGIN IMMEDIATE')
                if conn.execute('PRAGMA user_version').fetchone()[0]!=1 or conn.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or conn.execute('PRAGMA foreign_key_check').fetchall():
                    raise AuthorityError('durable registry invalid')
                actual={r[0]:r[1] for r in conn.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")}
                expected={sql.split()[2]:sql for sql in SCHEMA}
                if actual!=expected:raise AuthorityError('registry schema mismatch')
                self.reserved=[self.root]+[_canonical(p) for p in json.loads(conn.execute("SELECT value FROM meta WHERE key='native_data_roots'").fetchone()[0])]
                yield conn
                conn.commit();self._seal(self.root)
            except (OSError,sqlite3.Error,TypeError,KeyError,json.JSONDecodeError) as e:
                if conn:conn.rollback()
                raise AuthorityError('durable registry unavailable or invalid') from e
            except BaseException:
                if conn:conn.rollback()
                raise
            finally:
                if conn:conn.close()

    def _team(self,c,tid):
        t=c.execute('SELECT * FROM teams WHERE id=?',(_word(tid),)).fetchone()
        if not t:raise AuthorityError('unknown team')
        director=c.execute('SELECT active FROM actors WHERE id=?',(t['director'],)).fetchone()
        if not director or not director[0]:raise AuthorityError('team Director revoked or missing')
        p=_canonical(t['home']);s=p.stat()
        if (s.st_dev,s.st_ino)!=(t['dev'],t['ino']):raise AuthorityError('team home replaced')
        return t

    def _actor(self,c,actor):
        row=c.execute('SELECT * FROM actors WHERE id=?',(_word(actor),)).fetchone()
        if not row or not row['active']:raise AuthorityError('unregistered or revoked native actor')
        self._team(c,row['team']);return row

    def reserve_host_roots(self,paths):
        """Trusted parent adds each client's private/native/temp roots to shared authority."""
        roots=[_canonical(p) for p in paths]
        with self._transaction() as c:
            for p in roots:
                for row in c.execute('SELECT home FROM teams'):
                    if _overlap(p,Path(row[0])):raise AuthorityError('host root overlaps team')
                for row in c.execute('SELECT path FROM projects'):
                    if _overlap(p,Path(row[0])):raise AuthorityError('host root overlaps assigned project')
            old=json.loads(c.execute("SELECT value FROM meta WHERE key='native_data_roots'").fetchone()[0])
            combined=sorted(set(old)|{str(p) for p in roots})
            c.execute("UPDATE meta SET value=? WHERE key='native_data_roots'",(json.dumps(combined),))

    def register_team(self,team_id,team_home,director_id):
        home=_canonical(team_home);_word(team_id);_word(director_id)
        if any(home.iterdir()):raise AuthorityError('manually created empty team home required')
        with self._transaction() as c:
            if any(_overlap(home,p) for p in self.reserved):raise AuthorityError('reserved host root overlap')
            for row in c.execute('SELECT home FROM teams'):
                if _overlap(home,Path(row[0])):raise AuthorityError('team root overlap')
            for row in c.execute('SELECT path FROM projects'):
                if _overlap(home,Path(row[0])):raise AuthorityError('existing project overlap')
            if c.execute('SELECT 1 FROM actors WHERE id=?',(director_id,)).fetchone():raise AuthorityError('native identity already registered')
            s=home.stat();c.execute('INSERT INTO teams VALUES (?,?,?,?,?)',(team_id,str(home),s.st_dev,s.st_ino,director_id))
            c.execute('INSERT INTO actors VALUES (?,?,?,NULL,NULL,1)',(director_id,team_id,'director'))

    def register_controller(self,team_id,native_id,mission_id,generation):
        _word(native_id);_word(mission_id)
        if type(generation) is not int or generation<1:raise AuthorityError('positive generation required')
        with self._transaction() as c:
            self._team(c,team_id)
            if c.execute('SELECT 1 FROM actors WHERE id=?',(native_id,)).fetchone():raise AuthorityError('native identity reuse forbidden')
            old=c.execute('SELECT MAX(generation) FROM actors WHERE team=? AND mission=?',(team_id,mission_id)).fetchone()[0]
            if old is not None and generation<=old:raise AuthorityError('generation must advance')
            c.execute('UPDATE actors SET active=0 WHERE team=? AND mission=?',(team_id,mission_id))
            c.execute('UPDATE approvals SET active=0 WHERE team=? AND mission=?',(team_id,mission_id))
            c.execute('INSERT INTO actors VALUES (?,?,?,?,?,1)',(native_id,team_id,'controller',mission_id,generation))

    def assign_project(self,team_id,path,mission_id):
        p=_canonical(path);_word(mission_id)
        with self._transaction() as c:
            self._team(c,team_id)
            if any(_overlap(p,x) for x in self.reserved):raise AuthorityError('reserved host root overlap')
            for row in c.execute('SELECT home FROM teams'):
                if _overlap(p,Path(row[0])):raise AuthorityError('team home overlap')
            for row in c.execute('SELECT * FROM projects'):
                if _overlap(p,Path(row['path'])) and (row['team']!=team_id or row['mission']!=mission_id):raise AuthorityError('project ownership conflict')
            s=p.stat();c.execute('INSERT OR IGNORE INTO projects VALUES (?,?,?,?,?)',(str(p),team_id,mission_id,s.st_dev,s.st_ino))

    def _projects(self,c,actor):
        query='SELECT * FROM projects WHERE team=?';args=[actor['team']]
        if actor['role']=='controller':query+=' AND mission=?';args.append(actor['mission'])
        result=[]
        for row in c.execute(query,args):
            p=_canonical(row['path']);s=p.stat()
            if (s.st_dev,s.st_ino)!=(row['dev'],row['ino']):raise AuthorityError('assigned project replaced')
            result.append(str(p))
        return sorted(result)

    def assigned_projects(self,actor):
        with self._transaction() as c:return self._projects(c,self._actor(c,actor))

    def approve(self,team_id,ref,record):
        """Trusted HUMAN/operator event only. Returns bytes parent must write at ref."""
        with self._transaction() as c:
            t=self._team(c,team_id);ref=Path(ref).absolute()
            if ref.parent!=Path(t['home'])/'mission-graphs' or ref!=ref.resolve() or ref.name in ('','.'):
                raise AuthorityError('authorization reference outside team mission graph')
            keys={'schema','team_id','director_thread_id','mission_id','next_play_id','controller_thread_id','controller_generation','outcome_hash','authorization_scope'}
            if not isinstance(record,dict) or set(record)!=keys or record['schema']!='independent-team-authorization/v1':raise AuthorityError('authorization schema invalid')
            a=self._actor(c,record['controller_thread_id'])
            if a['role']!='controller' or a['team']!=team_id or record['team_id']!=team_id or record['director_thread_id']!=t['director'] or record['mission_id']!=a['mission'] or type(record['controller_generation']) is not int or record['controller_generation']!=a['generation']:
                raise AuthorityError('approval identity/generation mismatch')
            _word(record['next_play_id'])
            if not isinstance(record['outcome_hash'],str) or len(record['outcome_hash'])!=64 or any(x not in '0123456789abcdef' for x in record['outcome_hash']):raise AuthorityError('outcome digest invalid')
            scope=record['authorization_scope']
            if not isinstance(scope,dict) or set(scope)!={'action','provider','account','resource_type','resource'} or scope['action']!='update' or scope['provider']!='local-filesystem' or scope['account']!='uid:'+str(os.getuid()) or scope['resource_type']!='project':raise AuthorityError('provider/account capability unsupported')
            p=_canonical(scope['resource'])
            if str(p)!=scope['resource'] or str(p) not in self._projects(c,a):raise AuthorityError('project not assigned to controller mission')
            key=_key(scope);old=c.execute('SELECT team FROM leases WHERE key=?',(key,)).fetchone()
            if old and old[0]!=team_id:raise AuthorityError('canonical resource ownership conflict')
            raw=(json.dumps(record,sort_keys=True,ensure_ascii=False)+'\n').encode();digest=hashlib.sha256(raw).hexdigest()
            c.execute('INSERT OR IGNORE INTO leases VALUES (?,?,?)',(key,team_id,str(p)))
            c.execute('UPDATE approvals SET active=0 WHERE team=? AND mission=?',(team_id,a['mission']))
            # Keep historical approvals: each immutable reference is used only once.
            c.execute('INSERT INTO approvals VALUES (?,?,?,?,?,?,?,1)',(str(ref),team_id,a['id'],a['mission'],a['generation'],digest,raw.decode()))
            return raw

    def context(self,actor):
        with self._transaction() as c:
            a=self._actor(c,actor);t=self._team(c,a['team'])
            approvals=c.execute('SELECT * FROM approvals WHERE team=? AND active=1',(a['team'],)).fetchall()
            if a['role']=='controller':approvals=[r for r in approvals if r['controller']==actor and r['generation']==a['generation']]
            leases=c.execute('SELECT key,resource FROM leases WHERE team=?',(a['team'],)).fetchall();projects=self._projects(c,a)
            return dict(team_id=a['team'],team_home=t['home'],role=a['role'],thread_id=actor,director_thread_id=t['director'],authorizations={r['ref']:r['digest'] for r in approvals},resource_leases=sorted(r['key'] for r in leases if a['role']=='director' or r['resource'] in projects))

    def check_authorization(self,actor,ref,raw):
        if not isinstance(raw,bytes):raise AuthorityError('exact approved bytes required')
        expected=self.context(actor)['authorizations'].get(str(Path(ref).absolute()))
        if expected is None or expected!=hashlib.sha256(raw).hexdigest():raise AuthorityError('approval missing, revoked, superseded or altered')
        return True

    def recipient_check(self,actor,target,operation):
        if operation not in ('send','queue','resume','recover'):raise AuthorityError('unsupported transport or schedule operation')
        with self._transaction() as c:
            a=self._actor(c,actor);b=self._actor(c,target)
            if a['team']!=b['team']:raise AuthorityError('foreign recipient')
            return dict(team_id=a['team'],actor=actor,target=target,operation=operation)

    def revoke_actor(self,actor):
        with self._transaction() as c:
            a=self._actor(c,actor)
            if a['role']=='director':
                c.execute('UPDATE actors SET active=0 WHERE team=?',(a['team'],))
                c.execute('UPDATE approvals SET active=0 WHERE team=?',(a['team'],))
            else:
                c.execute('UPDATE actors SET active=0 WHERE id=?',(actor,))
                c.execute('UPDATE approvals SET active=0 WHERE controller=?',(actor,))

    def revoke_authorization(self,ref):
        with self._transaction() as c:
            row=c.execute('SELECT 1 FROM approvals WHERE ref=?',(str(Path(ref).absolute()),)).fetchone()
            if not row:raise AuthorityError('unknown approval')
            c.execute('UPDATE approvals SET active=0 WHERE ref=?',(str(Path(ref).absolute()),))
