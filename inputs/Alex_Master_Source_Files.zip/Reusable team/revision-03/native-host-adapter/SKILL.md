---
name: create-independent-team-restricted
description: Prepare the manually created operating folder from its existing first chat, only inside the reviewed restricted native host. Bind that chat as Director and wait for a later mission.
---

Use the host's `setup_team` tool with no identity, path or grant arguments. Its trusted native event identifies this existing first chat. It creates no second Director, mission, controller, external resource grant or schedule.

If that tool is absent, stop setup: this candidate has no ordinary desktop, Claude, Cursor or other host adapter. Do not invoke Python entrypoints or edit a binding to imitate native authority. The earlier bundle's refusal gate remains intentionally unchanged.

After setup, read the returned local Director role instructions. Wait for Alex's mission through the protected host's operator input. The first supported proof is local file work in an assigned external project. A Director requests `dispatch_mission` only for that existing operator assignment. The host creates the fresh native controller and delivers its local role and task.

Controllers use `project_python` for one authorized local program, then `return_result`. The host enforces the current approval, exact external project, write guard, one-process/no-network boundary and actual expected-file readback. A completed request replays its receipt without another write. An interrupted or uncertain request refuses replay until explicit reconciliation; do not obtain a new identity or play to bypass it.

A queued return is not delivery. The protected host foreground pump must observe successful native completion before marking delivery. Director judges returned evidence using `accept_result`; it updates the local graph and log through the preserved helper. Foreign, revoked and unknown recipients refuse; schedules are unavailable.

This is an uninstalled native candidate tested with scripted model responses. It is not a live-model/team adoption clearance. See README.md for supported scope, reproduction, remaining trials and recovery limits.
