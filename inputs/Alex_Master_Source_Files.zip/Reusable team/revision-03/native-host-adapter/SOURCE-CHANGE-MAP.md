# Additive native host source map

The original 81-file revision manifest is unchanged; the underlying version-0.2/audit remains untouched. Existing renderer, templates, guard, safe I/O, ledger, graph and acceptance helpers come from the frozen create-independent-team package. Their refusal to run as an untrusted native CLI remains intact.

| New component | Source relationship and purpose |
|---|---|
| client/native_client.py | Production extraction from the separately retained native probe: real private app-server identities, tool callback routing, exact completion, root restrictions and single owner. Later review fixed descriptor-relative launch files, root pins and turn-start failure shutdown. |
| authority/registry.py | New protected shared SQLite authority: membership, pinned resources, exact approvals, current generations and recipient checks. Scope vocabulary includes the guard's required action: update. |
| broker/helper_entry.py | Fixed protected source loader for preserved helpers. Removes their writable-directory import-path insertions; actual file operations and mandatory ledger/authorization checks remain the reviewed originals. |
| broker/native_host.py | Connects actual native events to empty first-chat setup, later operator mission, fresh controller, old guard, scoped one-process Python, readback, native return and old acceptance. Durable root binding and unconfirmed-delivery refusal were repaired after independent reproductions. |
| SKILL.md | Separate restricted-host invocation instructions. Not installed. Setup refuses when the authentic setup_team capability is absent. |
| verification/ | Repeatable aggregate tests, receipts, native observations and independent review. A copy of authority tests changes only BASE to package-relative path; assertions retained. |

Generated homes derive all role/helper files from the frozen source lock. Generated AGENTS.md and TEAM_BINDING.json receive honest restricted-native-candidate wording and host operations; these are recorded in the per-home protected manifest. This does not change the original package or enable an ordinary desktop chat by editing local JSON.
