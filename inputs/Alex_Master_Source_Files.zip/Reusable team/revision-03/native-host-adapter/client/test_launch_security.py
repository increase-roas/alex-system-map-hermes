"""Focused parent-I/O regressions. No provider/native launch for poison-path tests."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from native_client import NativeClient

SCRATCH=Path('/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/work/reusable-team-setup/repair-isolation/host-layer/authority-tests/client-review')
SCRATCH.mkdir(parents=True,exist_ok=True)
class LaunchSecurityTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=SCRATCH);self.root=Path(self.tmp.name).resolve()
  for n in ('state','temp','home'):(self.root/n).mkdir(mode=0o700)
  self.client=NativeClient(state_dir=self.root/'state',temp_dir=self.root/'temp',operating_home=self.root/'home',relay_url='http://127.0.0.1:12345/v1',model='isolated')
 def tearDown(self):self.client.stop();self.tmp.cleanup()
 def launch_without_native(self):
  # Suppress only actual process launch, retaining all real parent path operations.
  with patch('native_client.subprocess.Popen',side_effect=RuntimeError('no process in poison-path test')):
   try:self.client._launch()
   except (ValueError,OSError,RuntimeError):pass
 def test_config_symlink_and_hardlink_do_not_truncate_foreign_file(self):
  for link in ('symlink','hardlink'):
   with self.subTest(link=link):
    victim=self.root/('foreign-'+link);victim.write_text('outside-canary');leaf=self.root/'state'/'config.toml'
    if link=='symlink':leaf.symlink_to(victim)
    else:os.link(victim,leaf)
    self.launch_without_native()
    try:self.assertEqual(victim.read_text(),'outside-canary')
    finally:leaf.unlink();self.client.stop()
 def test_stderr_symlink_and_hardlink_refused_before_parent_write(self):
  for link in ('symlink','hardlink'):
   with self.subTest(link=link):
    victim=self.root/('stderr-'+link);victim.write_text('outside-canary');leaf=self.root/'state'/'native-stderr.txt'
    if link=='symlink':leaf.symlink_to(victim)
    else:os.link(victim,leaf)
    self.launch_without_native()
    if self.client._stderr:self.client._stderr.write('PARENT_LOG');self.client._stderr.flush()
    try:self.assertEqual(victim.read_text(),'outside-canary')
    finally:leaf.unlink();self.client.stop()
 def test_hardlinked_lock_not_accepted(self):
  victim=self.root/'foreign-lock';victim.write_text('lock');os.link(victim,self.root/'state'/'.native-host.lock')
  self.launch_without_native();self.assertIsNone(self.client._lock_fd)
 def test_replaced_state_symlink_causes_no_outside_config_write(self):
  self.root.joinpath('state').rename(self.root/'old-state');victim=self.root/'replacement';victim.mkdir();(victim/'config.toml').write_text('outside-canary');(self.root/'state').symlink_to(victim,target_is_directory=True)
  self.launch_without_native();self.assertEqual((victim/'config.toml').read_text(),'outside-canary');self.assertFalse((victim/'.native-host.lock').exists())
 def test_replaced_temp_or_home_inode_refused_before_any_launch_write(self):
  for name in ('temp','home'):
   with self.subTest(name=name):
    original=self.root/name;original.rename(self.root/(name+'-old'));original.mkdir(mode=0o700)
    self.launch_without_native()
    try:self.assertFalse((self.root/'state'/'config.toml').exists())
    finally:
     self.client.stop();(self.root/'state'/'config.toml').unlink(missing_ok=True)
     original.rmdir();self.root.joinpath(name+'-old').rename(original)
 def test_turn_start_timeout_stops_real_process(self):
  # Inject only the protocol timeout; the observed process/lifecycle is real.
  proc=subprocess.Popen([sys.executable,'-I','-S','-c','import time;time.sleep(30)'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  self.client._proc=proc;self.client._stderr=open(self.root/'stderr','w');self.client._threads.add('bound-test-thread')
  with patch.object(self.client,'_request',side_effect=TimeoutError('start response withheld')):
   with self.assertRaises(TimeoutError):self.client.turn('bound-test-thread','hello')
  self.assertIsNone(self.client.pid);self.assertIsNotNone(proc.poll())
 def test_world_writable_state_rejected(self):
  os.chmod(self.root/'state',0o777)
  self.launch_without_native();self.assertFalse((self.root/'state'/'config.toml').exists())
if __name__=='__main__':unittest.main()
