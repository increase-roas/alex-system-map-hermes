# Focused security repair receipt — 2026-10-03

Reviewed client/native_client.py against DESIGN.md and the client API contract. All concrete retained defects were reproduced in isolated scratch folders; no original state or provider was used.

Before repair, the seven new regression tests produced ten failing subcases. Config symlink and hardlink targets changed an outside canary; stderr symlink and hardlink targets received parent log writes; a hardlinked state lock was accepted; replacing state with a symlink wrote outside config; replacing temp/home inodes was accepted; group/world-writable state was accepted; turn/start timeout left a real child process running. The red receipt is in the scratch authority-tests/client-review/red-receipt.txt.

Repairs: per-client pinned root identities with descriptor-relative revalidation; checked no-follow/nonblocking regular leaf descriptors with owner/single-link/mode requirements; descriptor-relative atomic config replacement; checked append log; stable remembered lock inode; turn/start inside the existing fail-stop handler. Preserved safe_io directory/checked/write_all helpers were loaded without changing their global bind state.

Fresh verification command: python3 -m unittest discover -v from this client directory.

Observed output: Ran 14 tests in 3.156s; OK. Seven poison-path/lifecycle regressions passed, and seven existing native engine tests passed, including callback identity, unexpected-route denial, owned resume, true stop/restart, first/second lock owners, restored native thread and hostile missing builtin.

Coverage limit: the poison-path tests prevent actual native launch while exercising actual parent I/O. The lifecycle timeout is injected at the private protocol seam and observes a real process. Existing native tests provide real app-server coverage separately. Recovery across a supervisor crash and unrestricted same-UID directory-race resistance are not claimed; OS exclusion of model/worker routes remains required.
