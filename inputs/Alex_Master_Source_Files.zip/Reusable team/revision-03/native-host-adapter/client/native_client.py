"""Trusted-parent-only native stdio client. No desktop identity bridge or provider.

One synchronous caller owns lifecycle; handlers must not reenter this client.
Tool authority/argument validation belongs to the protected caller's handler.
"""
from dataclasses import dataclass
from collections import deque
import fcntl
import os
import importlib.util
import json
from pathlib import Path
import queue
import re
import subprocess
import threading
import time
import stat
import uuid
from contextlib import ExitStack
from urllib.parse import urlsplit

BINARY = Path('/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex')
RUNTIME = Path(__file__).resolve().parents[2]/'create-independent-team/assets/runtime/restricted_runtime.py'
_spec = importlib.util.spec_from_file_location('_native_client_boundary',RUNTIME)
_boundary = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_boundary)
_io_spec=importlib.util.spec_from_file_location('_native_parent_io',RUNTIME.with_name('safe_io.py'))
_io=importlib.util.module_from_spec(_io_spec)
_io_spec.loader.exec_module(_io)

@dataclass(frozen=True)
class ToolCall:
    thread_id: str
    turn_id: str
    call_id: str
    tool: str
    arguments: object

class NativeClient:
    def __init__(self, *, state_dir, temp_dir, operating_home, relay_url, model,
                 dynamic_tools=(), tool_handler=None, timeout=30, restorable_thread_ids=()):
        url = urlsplit(relay_url)
        if (url.scheme!='http' or url.hostname!='127.0.0.1' or not url.port or
            url.username or url.password or url.path!='/v1' or url.query or url.fragment or
            relay_url!=f'http://127.0.0.1:{url.port}/v1'):
            raise ValueError('relay must be exact http://127.0.0.1:PORT/v1')
        self.state = _boundary._path(state_dir)
        self.temp = _boundary._path(temp_dir)
        self.home = _boundary._path(operating_home)
        paths = [self.state,self.temp,self.home]
        if any(not p.is_dir() for p in paths) or any(a==b or a in b.parents or b in a.parents for i,a in enumerate(paths) for b in paths[i+1:]):
            raise ValueError('state, temp and operating home must be separate directories')
        if not isinstance(model,str) or not model: raise ValueError('model required')
        self.model,self.relay_url,self.port = model,relay_url,url.port
        self.tools = json.loads(json.dumps(list(dynamic_tools)))
        self.names = {t['name'] for t in self.tools}
        if len(self.names)!=len(self.tools) or any(not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}',n) for n in self.names):
            raise ValueError('dynamic tool names must be unique plain names')
        self._root_identities={}
        for p in paths:
            with _io.directory(p) as fd:
                s=os.fstat(fd);self._root_identities[p]=(s.st_dev,s.st_ino)
                if p in (self.state,self.temp) and s.st_mode & 0o022:raise ValueError('private native roots must not be group/world writable')
        self._lock_identity=None
        self.handler,self.timeout = tool_handler,timeout
        self.events=[]
        self._proc=None;self._reader=None;self._stderr=None
        # This grant comes only from the protected parent's intact registry.
        # It does not authenticate a model, actor argument or desktop chat.
        restored=set(restorable_thread_ids)
        if any(not isinstance(t,str) or not t for t in restored):
            raise ValueError('restorable thread IDs must be nonempty strings')
        self._serial=0;self._threads=restored;self._active=None;self._lock_fd=None
        self._responses={};self._backlog=[];self._incoming=queue.Queue()

    @property
    def pid(self): return self._proc.pid if self._proc and self._proc.poll() is None else None

    def _root_fd(self,stack,path):
        if _boundary._path(path)!=path:raise ValueError('native root no longer canonical')
        fd=stack.enter_context(_io.directory(path));s=os.fstat(fd)
        if (s.st_dev,s.st_ino)!=self._root_identities[path]:raise ValueError('native root replaced')
        if path in (self.state,self.temp) and s.st_mode & 0o022:raise ValueError('native private root became writable by another user')
        return fd

    def _leaf_fd(self,parent,name,flags):
        fd=os.open(name,flags|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,0o600,dir_fd=parent)
        try:
            _io.checked(fd)
            if os.fstat(fd).st_mode & 0o022:raise ValueError('native private file is group/world writable')
            return fd
        except BaseException:os.close(fd);raise

    def _launch(self):
        # Revalidate all pinned roots before privileged state I/O. No bind_root global.
        with ExitStack() as stack:
            parent=self._root_fd(stack,self.state)
            self._root_fd(stack,self.temp);self._root_fd(stack,self.home)
            fd=self._leaf_fd(parent,'.native-host.lock',os.O_CREAT|os.O_RDWR)
            try:
                s=os.fstat(fd);identity=(s.st_dev,s.st_ino)
                if self._lock_identity is not None and identity!=self._lock_identity:raise ValueError('native lock inode replaced')
                fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                os.close(fd);raise RuntimeError('native state already has a live host owner') from None
            except BaseException:os.close(fd);raise
            self._lock_identity=identity;self._lock_fd=fd
            # Reject every poisoned existing leaf before config mutation.
            for name in ('config.toml','native-stderr.txt'):
                try:checked=self._leaf_fd(parent,name,os.O_RDONLY)
                except FileNotFoundError:continue
                os.close(checked)
            self._launch_locked(parent)

    def _launch_locked(self,parent):
        disabled = ['apps','plugins','remote_plugin','browser_use','browser_use_external','computer_use','in_app_browser','image_generation','multi_agent','code_mode','code_mode_host','shell_tool','unified_exec','view_image','shell_snapshot','hooks','skill_search','skill_mcp_dependency_install','enable_request_compression','daemon_auto_start','in_app_local_automation','sleep_tool','goals']
        config = '\n'.join(['model = '+json.dumps(self.model),'model_provider = "trusted_local"','web_search = "disabled"','project_doc_max_bytes = 0','cli_auth_credentials_store = "file"','mcp_oauth_credentials_store = "file"','[model_providers.trusted_local]','name = "Trusted local relay"','base_url = '+json.dumps(self.relay_url),'wire_api = "responses"','requires_openai_auth = false','request_max_retries = 0','stream_max_retries = 0','[features]',*[f'{f} = false' for f in disabled],'[analytics]','enabled = false','[feedback]','enabled = false','[apps._default]','enabled = false'])+'\n'
        temporary='.config.toml.'+uuid.uuid4().hex
        fd=self._leaf_fd(parent,temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL)
        try:
            _io.write_all(fd,config.encode());os.fsync(fd)
        finally:os.close(fd)
        try:
            os.replace(temporary,'config.toml',src_dir_fd=parent,dst_dir_fd=parent);os.fsync(parent)
        finally:
            try:os.unlink(temporary,dir_fd=parent)
            except FileNotFoundError:pass
        policy = _boundary.profile([BINARY.parent,BINARY.parent.parent/'Info.plist',BINARY.parents[3]/'codex-package.json',Path('/private/etc/passwd'),self.home],[self.state,self.temp])
        policy = policy.replace('(deny network*)',f'(deny network* (require-not (remote ip "localhost:{self.port}")))').replace('(deny process-info*)','(deny process-info* (require-not (target self)))').replace('(deny mach-lookup)','(deny mach-lookup (require-not (global-name "com.apple.system.opendirectoryd.libinfo")))')
        env = {'PATH':'/usr/bin:/bin','LANG':'en_US.UTF-8','HOME':str(self.state),'CODEX_HOME':str(self.state),'TMPDIR':str(self.temp)}
        stderr_fd=self._leaf_fd(parent,'native-stderr.txt',os.O_WRONLY|os.O_CREAT|os.O_APPEND)
        self._stderr = os.fdopen(stderr_fd,'a')
        self._incoming=queue.Queue();self._responses={};self._backlog=[]
        self._proc = subprocess.Popen(['/usr/bin/sandbox-exec','-p',policy,str(BINARY),'app-server','--stdio'],cwd=self.home,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self._stderr,text=True,bufsize=1,close_fds=True)
        proc,incoming = self._proc,self._incoming
        def read():
            for line in proc.stdout:
                try: incoming.put(json.loads(line))
                except json.JSONDecodeError: incoming.put({'_invalid_stdout':True})
            incoming.put({'_closed':True})
        self._reader=threading.Thread(target=read,daemon=True);self._reader.start()

    def _send(self,message):
        if self.pid is None: raise RuntimeError('native server is not running')
        self._proc.stdin.write(json.dumps(message)+'\n');self._proc.stdin.flush()

    def _next(self,deadline):
        remaining=deadline-time.monotonic()
        if remaining<=0: raise TimeoutError('native response deadline exceeded')
        try: event=self._incoming.get(timeout=remaining)
        except queue.Empty: raise TimeoutError('native response deadline exceeded') from None
        self.events.append(event)
        if event.get('_closed') or event.get('_invalid_stdout'): raise RuntimeError('native stdio closed or malformed')
        return event

    def _deny(self,event):
        self._send({'id':event['id'],'error':{'code':-32601,'message':'Host denied unsupported native request'}})

    def _callback(self,event):
        p=event.get('params',{})
        if (not isinstance(p,dict) or not isinstance(p.get('callId'),str) or not p.get('callId') or event['method']!='item/tool/call' or self._active!=(p.get('threadId'),p.get('turnId')) or p.get('tool') not in self.names or self.handler is None):
            self._deny(event);return
        call=ToolCall(p['threadId'],p['turnId'],p['callId'],p['tool'],p.get('arguments'))
        try:
            result=self.handler(call)
            if not isinstance(result,dict) or not isinstance(result.get('success'),bool) or not isinstance(result.get('contentItems'),list): raise ValueError('invalid host tool reply')
            self._send({'id':event['id'],'result':result})
        except Exception:
            self._send({'id':event['id'],'result':{'contentItems':[{'type':'inputText','text':'HOST_TOOL_DENIED'}],'success':False}})

    def _route(self,event,defer_callbacks=False):
        if 'id' in event and 'method' in event:
            if defer_callbacks: self._backlog.append(event)
            else: self._callback(event)
        elif 'id' in event and ('result' in event or 'error' in event): self._responses[event['id']]=event
        else: self._backlog.append(event)

    def _request(self,method,params,defer_callbacks=False):
        self._serial+=1; serial=self._serial
        self._send({'id':serial,'method':method,'params':params})
        deadline=time.monotonic()+self.timeout
        while serial not in self._responses: self._route(self._next(deadline),defer_callbacks)
        response=self._responses.pop(serial)
        if 'error' in response: raise RuntimeError('native request failed: '+json.dumps(response['error']))
        return response['result']

    def initialize(self):
        if self.pid is not None: raise RuntimeError('already initialized')
        try:
            self._launch()
            result=self._request('initialize',{'clientInfo':{'name':'restricted_native_host','version':'0.1'},'capabilities':{'experimentalApi':True}})
            self._send({'method':'initialized'});return result
        except BaseException: self.stop();raise

    def start_thread(self, *, base_instructions='', developer_instructions=''):
        result=self._request('thread/start',{'cwd':str(self.home),'model':self.model,'modelProvider':'trusted_local','ephemeral':False,'environments':[],'dynamicTools':self.tools,'baseInstructions':base_instructions,'developerInstructions':developer_instructions,'config':{'project_doc_max_bytes':0,'web_search':'disabled'}})
        self._threads.add(result['thread']['id']);return result

    def resume(self,thread_id):
        # Only created or explicitly parent-granted threads may resume.
        if thread_id not in self._threads: raise ValueError('thread is not bound to this host client')
        result=self._request('thread/resume',{'threadId':thread_id,'cwd':str(self.home),'model':self.model,'modelProvider':'trusted_local'})
        if result['thread']['id']!=thread_id: raise RuntimeError('native resume identity mismatch')
        return result

    def turn(self,thread_id,text):
        if thread_id not in self._threads or self._active is not None: raise ValueError('unbound thread or active turn')
        pending=deque()
        try:
            begun=self._request('turn/start',{'threadId':thread_id,'input':[{'type':'text','text':text,'text_elements':[]}],'environments':[]},defer_callbacks=True)
            self._active=(thread_id,begun['turn']['id'])
            deadline=time.monotonic()+self.timeout
            pending=deque(self._backlog);self._backlog=[]
            while True:
                event=pending.popleft() if pending else self._next(deadline)
                if 'id' in event and 'method' in event: self._callback(event)
                elif event.get('method')=='turn/completed' and (event.get('params',{}).get('threadId'),event.get('params',{}).get('turn',{}).get('id'))==self._active:
                    p=event['params']
                    if p['turn'].get('status')!='completed' or p['turn'].get('error') is not None: raise RuntimeError('native turn failed')
                    return p
                elif 'id' in event and ('result' in event or 'error' in event): self._responses[event['id']]=event
                # Notifications remain available in events, including unrelated completions.
        except BaseException:
            self.stop();raise
        finally:
            self._backlog.extend(pending);self._active=None

    def stop(self):
        if self._proc is None:
            if self._stderr: self._stderr.close();self._stderr=None
            if self._lock_fd is not None:
                os.close(self._lock_fd);self._lock_fd=None
            return
        proc=self._proc
        if proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: proc.kill();proc.wait(timeout=5)
        if self._reader: self._reader.join(timeout=2)
        proc.stdin.close();proc.stdout.close()
        self._stderr.close();self._proc=None;self._reader=None;self._stderr=None;self._active=None
        if self._lock_fd is not None:
            os.close(self._lock_fd);self._lock_fd=None
