# Isolation stress audit — version 0.2 is not cleared for use

The audit completed with **38 fixture checks: 31 passed, 7 failed safety expectations, and 0 harness errors**. The seven failed expectations include two documented limitations, two missing enforcement boundaries, two validation defects and one deterministic file-redirection race. They are not seven undisclosed implementation bugs.

This audit supersedes any inference that the earlier 12 component checks proved complete independence. Those checks covered ordinary path/identity routing only. The package remains uninstalled. No live Director/controller chat was launched or messaged.

## What happened to the actual original team

No original-team state was changed. Tests ran in an OS sandbox that allowed writes only inside the assigned stress-fixture directory, denied reads of private home data outside the fixture/package, and denied network connections. Preflight confirmed permitted fixture read/write, refused access to the original Director instruction file, refused read/write of an outside sentinel, and refused a network connection. No real original-file write was attempted.

The original-team stand-ins inside the sandbox were invented data. Some stand-ins changed in the deliberately adversarial cases below; those changes are the evidence of the gaps. All 30 reviewed skill source/template files remained byte-identical. The test sandbox protects this audit only; it is not installed as protection for future team chats.

The first restrictive sandbox profile prevented even a minimal executable from starting. A revised profile allowed ordinary runtime startup while retaining the protected-data, outside-write and network denials. It passed preflight before any candidate setup/helper command ran. This environmental correction is separate from the product UI notice about unavailable response content.

## Failed safety expectations

| Finding | Observed fixture result | Meaning and required correction |
|---|---|---|
| F1 — chat ownership is not authenticated | Setup accepted an invented original-Director ID supplied by the caller. A process in one fake team's folder successfully invoked the other fake team's helper and edited its graph. | The helper binds to the script and editable JSON, not the actual invoking chat. Current native identity must be established by a trusted launcher/transport, and the runtime must be prevented from reaching other team homes/helpers. Adding another user-editable ID field alone is insufficient. |
| F2 — a checked path can change before the write | A controlled interleaving replaced the accepted log path with a link after validation. The unmodified acceptance code appended to the fake-original log. | Checks and file opens are separate. Use safe, anchored file operations that reject link substitution at the point of use; rechecking alone does not remove the race. This fixture used test instrumentation at the function boundary, not a native chat or a probability measurement of real races. |
| F3 — ledger verification accepts a foreign graph pointer | A local mission's MISSION_GRAPH was changed to another fake team's graph. Verification returned OK, released its lock and left the foreign pointer in place; only a subsequent warning rejected it. | Validate all team-owned graph/authorization references as mandatory checks before accepting the ledger change or releasing its write lock. The guard subsequently rejected this graph, so this case establishes accepted contamination, not a direct foreign graph write. |
| F4 — the guard does not require an existing authorization record | A claim was granted when AUTHORIZATION_REF named a nonexistent local file, provided caller-supplied scope matched ledger hashes. | Require the authorization record to exist, read and validate its contents, and tie permission to the trusted current mission/owner. Matching self-supplied hashes is not proof of real authorization. |
| F5 — separate teams can claim the same external resource | Two fake teams both received granted for the identical mock provider/account/resource. | This was already documented. Keep resources disjoint or introduce one authoritative ownership/enforcement route before allowing shared targets. No provider was contacted. |
| F6 — ordinary tools retain same-user filesystem access | A direct file operation from one fake team's working directory changed a sibling fake team's log without invoking any helper. | This was already documented. Folder naming and helper checks do not limit arbitrary shell/file tools. Actual per-team filesystem and credential restrictions are required for the requested prevention guarantee. |

F1 represents two failed cases; the other rows represent one each, totaling seven. These checks test stronger safety expectations than the candidate currently implements.

## Operational instruction findings

An independent read-only review found a direct policy conflict: the setup calls shared tool cards read-only, but the inherited execution/routing procedures say to record a recurring app/route fix in its canonical tool card. A future controller could thereby alter instructions used by the original team. Route those fixes to a local proposal for the shared maintainer, and remove the conflicting write instruction.

Native send, queue, resume and schedule operations have prose ownership limits but no recipient/automation ownership adapter in this package. An incorrect existing chat ID in local state is not mechanically stopped at the native send. No native message or schedule action was tested or sent. These are unproven enforcement surfaces, not claims that any real original chat was contacted.

The supervision file's opening and closing scope rules do restrict recovery to this TEAM_ID. Its broad instruction to inspect existing automations is therefore an ambiguity to tighten, not sufficient evidence by itself that another team's schedule would be changed. The review does not promote that ambiguity to a confirmed schedule mutation.

## Protections observed working

Ordinary calls to the correct local helper rejected foreign ledger/graph/log paths, pre-existing symbolic and hard links, linked backups/locks, wrong team and Director headers, stale play/controller/generation/account values, moved bindings and root/test-mode overrides. Repeated initialization refused overwrite, nested-team setup refused, and new state had distinct team IDs and empty grants.

Valid local graph edits worked in a home containing spaces. An external PROJECT did not redirect the acceptance log. Unresolved replay and rotation were refused; completed replay returned prior fixture evidence. Eight simultaneous claims in one team granted exactly once. The ordinary refusal cases left their fake-original sentinels unchanged.

## Decision and scope

**Do not install or adopt version 0.2 as proof that it cannot interfere with the original Director.** The ordinary routing is substantially improved, but the stronger isolation guarantee is not met.

Required work is concrete: fix mandatory reference/authorization validation and safe writes; reconcile shared-card instructions; establish trusted native chat/recipient ownership; and give each operating team an enforced resource boundary. Then rerun these fixture cases and conduct a separately authorized native delivery/recovery trial using inert targets. The current audit neither installs those restrictions nor changes the original team's security/settings.

The code under review was deliberately preserved so the failures remain attributable to version 0.2. This is a completed audit with failed safety expectations, not an unfinished test run. Native chat behavior, provider permission enforcement and hostile arbitrary-code resistance were not proven.

Evidence: [case results](verification/stress-audit/stress-results.json), [command receipts](verification/stress-audit/command-receipts.json), [sandbox preflight](verification/stress-audit/preflight-result.json), [reviewed source hashes](verification/stress-audit/candidate-before.json). The reproducible harness remains in the assigned scratch folder under work/reusable-team-setup/stress-audit/stress_test.py.
