# Version 0.2 verification — passed with stated limits

The initial version 0.1 was a specification-only draft. Version 0.2 implements the portability changes requested afterward. Previous documents are retained in assigned scratch under v01-document-archive; this receipt describes the new candidate.

## Component checks

Twelve isolated component checks passed. Raw results: [component-checks.txt](verification/component-checks.txt). The initial eight tests failed because the portable implementation files did not exist, then passed after implementation. Four focused wiring/syntax/incomplete-state checks were added and passed.

| Covered behavior | Observed result |
|---|---|
| First invoking chat becomes Director | Rendered binding contains supplied fresh native fixture identity |
| Team home first, mission later | Rendered ledger has zero mission blocks; no controller, approval or schedule inherited |
| Two independent homes | Distinct home paths and Director return addresses; rendering creates neither home |
| Binding-based guard resolver | Actual resolver chooses its own binding despite HOME/test-mode environment lure; override refused; no claims created |
| Foreign identity/path rejection | Other Director, ledger, graph and log paths refused |
| Moved/partial/linked state | Mismatched home, incomplete marker, linked backup and linked claim parent refused |
| Acceptance with external PROJECT | Actual prepare function chooses team log; explicit foreign log refused; graph and log bytes unchanged |
| Generated Python syntax | All rendered Python compiled in memory |

These are component/unit checks, not the prohibited native runtime trial. Only minimal inert fixture files were created under assigned scratch. The initializer CLI was never invoked, no complete generated home was written, and no guard acquire/write action or acceptance commit ran.

## Source and document checks

All 13 bounded document checks passed, including all 24 implementation/template hash pins, blank-state checks, known-format secret screening, original-ID exclusion and document links. Machine receipt: [document-checks.json](verification/document-checks.json). The source lock lists 22 retained derived templates plus two newly authored implementation files.

Selected preserved source bytes were checked against the published baseline manifest before generation. The two supplemental original guard/template hashes were reverified and exact inputs retained in assigned scratch. All original sources remain read-only. The earlier full 435-file baseline check is documented in BASELINE_RECONCILIATION.md; it is not represented as a new runtime observation.

The general skill-creator YAML validator was unavailable because PyYAML was absent. No dependency was installed. The simple four-line frontmatter was inspected with explicit naming, scalar and indentation checks; this is not a claim that the general validator ran.

## Independent review

A read-only implementation review identified six defects in role selection, inherited authority, queue assumptions, shell quoting/migration examples, host instructions and guard invocation. They were corrected in the reproducible source transformation. The focused acceptance pass returned PASS. No agent initialized or exercised a serving team.

## What remains unproven

Actual native identity discovery, controller creation, assignment delivery, return delivery, judgment, interruption recovery, effective hooks and enforced runtime/account isolation remain for the proposed later trial. Separate guard stores cannot arbitrate a shared external target. Local routing checks do not restrict arbitrary shell/tool access.

No skill installation, setup command, new live Director/controller team, native runtime test, original-source mutation, external action, schedule or adoption occurred. The package is an uninstalled implementation candidate, with the stated component checks observed passing.
