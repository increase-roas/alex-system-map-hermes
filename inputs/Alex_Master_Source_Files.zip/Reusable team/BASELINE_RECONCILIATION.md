# Baseline reconciliation receipt

**Status: reconciled to the published audit baseline for covered sources, with explicit supplemental-input gaps.** The draft is ready for document review, not for a runtime trial or installation. No input was relayed by Alex; this chat read the audit publication directly.

## Version consumed

- Baseline ID: `alex-agent-baseline-2026-10-03`.
- Manifest: `/Users/alexlobaito/Documents/Codex/2026-10-03/can-you-read-this-chat-in/outputs/system-baseline-audit/baseline/manifest.json`.
- Manifest SHA-256: `7da3dfa2b7c0ac427629dbe1c271746f0284845eac79ee1836632b627ed8696c`.
- Ready marker: same audit output folder, `BASELINE_READY.md`, published `2026-10-03T09:51:28.554817+00:00`.
- Source capture: October 3, 2026, 05:34:44–05:34:46 EDT (`09:34:44.662994–09:34:46.135660Z`). The manifest describes two later template artifact repairs whose originals still matched that capture.
- Scope: 427 selected source artifacts (418 exact, 9 transformed), 7 support artifacts and the manifest. Configuration structures and redacted/extracted evidence are not executable originals.

The ready-marker manifest digest matched. This chat independently recomputed all 434 artifact hashes listed in the manifest, then all 435 files in the baseline checksum inventory, including the manifest: zero mismatches. This is file integrity, not proof of current runtime behavior, secret completeness or semantic consistency across all records.

## Comparison with the provisional draft

The draft's 67 source observations comprise 64 source fingerprints plus three audit reports read during publication. `baseline-reconciliation.json` records every comparison:

| Comparison | Count | Disposition |
|---|---:|---|
| Same original-source hash in published baseline | 52 | Covered source version reconciled; preserved transformation still governs usable content |
| Different original-source hash | 1 | Hermes mission graph; bounded semantic difference reviewed below |
| Not in baseline's source-file inventory | 14 | Explicit supplemental/reference inputs listed below; not silently treated as frozen |

The core Director 2.7 / Conductor 2.5 sources, related policy references and ledger/acceptance helper source observations match the covered baseline. Matching a source hash does not make sanitized config structure a replacement config or prove the actor loaded it.

### Changed Hermes mission record

The preserved graph's original hash is `f824194f01fee860798f428128a78409292c9a97517106412368a00b6b0a0e0a`; the draft's later live observation was `7b8c7b064a188e4951b2e0b598954addeb8b7257f8cba9780ea444df04fa1402`. The preserved, conservatively redacted copy has hash `1abb2f2c842088831b6e3bc9acea6656da21396fcee7aa3d03c4648a4e43fa10`.

The same external PROJECT and supervising Director appear in both. The edition remains built/uninstalled and READY_FOR_OWNER. The later live `javar-operating-standard` next action clarifies the built mandatory-checkpoint edition and remaining matching pointer updates. A later `build-sync` node is WAITING_ON_ALEX: Build's deployment-source role needs reconciliation before further deployment from it. A Cloudflare row differs because the audit redacted a bearer-pattern phrase; this is a preservation transformation, not a behavior change.

The draft therefore retains the frozen baseline's topology and recorded behavior, labels later source work as a live supplement, and does not import its newer pending tasks. Build is a source-navigation example, not a deployable truth assumed current. No setup generator or deployment is run. Javar's maintained core remains reported unloaded at capture; Javante's earlier role-load defect was repaired. Neither fact proves the new full core edition was installed.

### Inputs outside the baseline inventory

| Supplemental group | Count | Limit and later dependency |
|---|---:|---|
| This setup task brief | 1 | Current request authority; naturally separate from the source-system snapshot |
| Director-home standalone guard and graph template | 2 | Critical adaptation inputs, inspected and hashed live but absent from audit's retained corpus. Version 0.2 reverified both selected source hashes and includes derived guard/template bytes in its source-locked bundle. They remain explicitly supplemental, outside the audit corpus. |
| Hermes edition builder and its manifest | 2 | Existing platform-adaptation example only. Actively changing live work; not a new-team dependency to run or an adopted edition. |
| Build team materializer/README, accepted-baseline manifest, EA startup INDEX/AGENTS/TOOLS | 6 | Relevant pattern and role navigation; live-source supplements, not frozen serving packages. Only needed if a later mission actually uses those role sources. |
| Published audit baseline guide, findings and proposed-corrections reports | 3 | Review artifacts outside the baseline file inventory; read as analysis/proposals, not operating policy |

Every exact path and observed hash is in `source-versions.json`. The supplementary guard and graph-template fingerprints are, respectively, `d55f79744983d4aedb2d5c6e44113a918433ba1b5b19bcdbf990d3e6038d5bbe` and `3cc7ff8243a50c1aef9a7a3d5c4f9b3d3546b89a0dfdee83813483238dc9661e`. These pins identify the source inputs. Version 0.2 retains their derived template bytes and template hashes; the original live files remain read-only.

## Live drift deliberately kept separate

`source-drift-check.json` records a later read-only comparison in this task. Four files changed after initial fingerprinting: setup-playbook notes, the Hermes edition builder and manifest, and the master workbook. Earlier helper reads also saw older Hermes builder/manifest versions. Those changes belong to the existing live owners; this chat did not write them.

The reproduction reference is the published baseline, not a mixture of those later versions. Future operational work must still reconcile current decisions and ownership; the preserved baseline never authorizes replaying old missions. The original restore scope excludes credentials, active sessions, broad scheduling state and full installed platforms, so it cannot recreate an authenticated running team alone.

## What was and was not adopted

The audit's existing-rule examples, handoff truncation proposals, acceptance idempotency proposals and Hermes delivery corrections remain proposals or separately owned live work. The draft includes tests for the requested behaviors, without silently rewriting the maintained policies to claim those gaps solved.

Necessary replication adaptations are explicit: fresh state, new ownership/identity bindings, per-team paths, explicit acceptance-log destination, effective-load checks and isolation prerequisites. Version 0.2 implements the local bindings and helpers, retains source/template hashes, and passes isolated component checks. It does not establish independent native team behavior. Before a trial, establish actual runtime restrictions and prove permitted native delivery/return. No missing input needs Alex to act as a file courier.
