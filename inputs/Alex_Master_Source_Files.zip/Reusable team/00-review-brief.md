# Independent team setup — uninstalled implementation candidate

> **Later stress-audit verdict: NOT CLEARED FOR USE.** Version 0.2 passed its earlier component checks but failed 7 of 38 stronger fixture safety expectations. Read [05-isolation-stress-audit.md](05-isolation-stress-audit.md) before considering installation. The original team was not changed.

Prepared October 3, 2026 for Alex. **The review package is written; no team has been installed, launched, tested at runtime or adopted.** See `BASELINE_RECONCILIATION.md` for the exact preserved source version and remaining gaps, and `STATIC_CHECKS.md` for the completed document checks.

The package has been reconciled to audit baseline `alex-agent-baseline-2026-10-03`, manifest `7da3dfa2b7c0ac427629dbe1c271746f0284845eac79ee1836632b627ed8696c`. All 435 baseline files passed the independent checksum check. Supplementary source gaps remain explicitly listed; this is not a runnable backup.

The proposed sequence matches the existing arrangement: Alex makes an empty folder, and its first chat invokes setup and becomes Director, with no mission or target. Later assign an outcome that either creates a new project or works on an existing project from outside it. Each team has its own Director, ledger and controller ownership. The target repo does not need to house the operating setup.

## What is ready to review

| Deliverable | File |
|---|---|
| Uninstalled skill draft | [create-independent-team/SKILL.md](create-independent-team/SKILL.md) |
| Setup and later mission-binding procedure | [procedure.md](create-independent-team/references/procedure.md) |
| Ownership and template specifications | [templates.md](create-independent-team/references/templates.md) |
| Empty binding and ledger templates | [binding](create-independent-team/assets/team-binding.blank.json), [ledger](create-independent-team/assets/director-state.blank.md) |
| Existing pattern, reusable components and evidence | [01-component-source-map.md](01-component-source-map.md) |
| Isolation findings and copy hazards | [02-isolation-findings.md](02-isolation-findings.md) |
| Dependencies and smallest later trial | [03-dependencies-and-trial.md](03-dependencies-and-trial.md) |
| Exact source fingerprints and baseline comparison | [source-versions.json](source-versions.json), [BASELINE_RECONCILIATION.md](BASELINE_RECONCILIATION.md) |
| Portable implementation and verification | [04-portability-fix.md](04-portability-fix.md) |
| Static acceptance evidence | [STATIC_CHECKS.md](STATIC_CHECKS.md) |

## The consequential findings

1. **The external-home pattern already exists.** The current team supervises Javar on Orgo and Javante on the Mac mini from its existing operating/work homes. Historical receipts show assignment, return, Director judgment, saved state and useful independent progress. Independent replication remains unproved.
2. **The identified copy bindings are now adapted in the candidate.** The first chat becomes Director. Local role paths, scoped recovery, ledger/graph/authorization checks, local acceptance logs and a binding-based guard are implemented. Twelve component checks pass. Global hooks and actual platform behavior remain a later runtime concern.
3. **Separate folders do not prove isolation.** The current host has broad tool/filesystem access. The later trial needs actual denied out-of-scope writes against inert fixtures and restricted account/resource access. Two private guards also cannot arbitrate one shared external resource by themselves.
4. **Fresh state means genuinely empty state.** The draft includes no live team, mission, controller, approval, claim, customer, credential or schedule. Shared standards stay maintained once; per-team derived bindings must identify their source versions.
5. **Audit improvements remain proposals.** This draft preserves the working role split and behavior. Necessary path/identity adaptations are explicit. It does not silently install the audit's proposed reliability changes or the still-uninstalled Hermes editions.

## What comes later

The manual-folder / first-chat correction is implemented in version 0.2. Read **04-portability-fix.md** for the concrete changes and evidence. Before the later runtime trial, establish actual restrictions on original state/unassigned resources and prove native delivery/return. Installation, a serving team and the trial have not been performed.

The smallest meaningful trial is one fresh team with two harmless missions: modify a disposable existing project from outside it, then create a new one after assignment. Observe delivery, returned evidence, judgment, independent work around a blocker, interruption/resume and denied escapes. No permanent reviewer, global registry or recurring monitor is proposed.

**Status:** prepared as a review artifact; component verification documented separately; independent-team behavior and isolation not proven. The requested stop boundary remains in place. Nothing requires Alex to relay audit files or remember to disable a job—no job was created.
