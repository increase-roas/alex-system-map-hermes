# Director state — blank template

No missions assigned. This file is an uninstalled template, not an active ledger.

The future team-specific Director owns this ledger. After initialization its actual identity and home are recorded in TEAM_BINDING.json. A mission is added only after Alex supplies that mission. Existing team missions, session identities, approvals and accepted checkpoints are not imported.
