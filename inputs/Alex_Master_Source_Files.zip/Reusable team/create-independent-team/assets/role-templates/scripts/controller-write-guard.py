#!/usr/bin/env python3
"""Fail-closed, same-host write claims for sanctioned controller mutations.

An authorization_scope names one write (top-level provider, action, account, resource_type, resource) or,
with "steps", an ordered list of them, each with a "max" write count: one fence for an owner ask's bounded
sequence. Step N is granted only after steps 1..N-1 completed in order under the same fence; a failed or
unresolved step stops the sequence until the Director writes a new fence (references/gates.md)."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import socket
import sys
import tempfile
import time
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EXIT_ACTIVE = 3
EXIT_DENIED = 4
EXIT_POISONED = 5
SAFE_KEY = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
STEP_FIELDS = ("provider", "action", "account", "resource_type", "resource")


import team_paths as scope


def emit(status: str, **fields: Any) -> None:
    print(json.dumps({"status": status, **fields}, ensure_ascii=False, separators=(",", ":"), sort_keys=True))


def stop(code: int, status: str, reason: str, **fields: Any) -> "NoReturn":
    emit(status, reason=reason, **fields)
    raise SystemExit(code)


def normalize(value: Any) -> Any:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        return {unicodedata.normalize("NFC", str(key)): normalize(item) for key, item in value.items()}
    return value


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(normalize(value), ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def parse_json(raw: str, label: str) -> Any:
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        stop(EXIT_DENIED, "denied", f"malformed_{label}", detail=str(exc))


def load_missions(state_path: Path) -> dict[str, list[dict[str, str]]]:
    try:
        text = state_path.read_text(encoding="utf-8")
    except OSError as exc:
        stop(EXIT_DENIED, "denied", "director_state_unreadable", detail=str(exc))

    blocks = re.split(r"(?m)(?=^## Mission: )", text)
    missions: dict[str, list[dict[str, str]]] = {}
    for block in blocks:
        fields = dict(re.findall(r"(?m)^([A-Z][A-Z0-9_]*):[ \t]*(.*?)[ \t]*$", block))  # [ \t]: an empty field stays empty instead of swallowing the next line
        mission_id = fields.get("MISSION_ID")
        if mission_id:
            missions.setdefault(mission_id, []).append(fields)
    return missions


def mission_fields(state_path: Path, mission_id: str) -> dict[str, str]:
    matches = load_missions(state_path).get(mission_id, [])
    if len(matches) != 1:
        stop(EXIT_DENIED, "denied", "mission_identity_ambiguous", matches=len(matches))
    try:
        home, binding = scope.bound_home(__file__)
        scope.check_mission_identity(binding, matches[0])
        auth_ref = matches[0].get("AUTHORIZATION_REF")
        if auth_ref and auth_ref != "NONE":
            scope.authorization_path(home, auth_ref)
    except scope.ScopeError as exc:
        stop(EXIT_DENIED, "denied", "team_identity_mismatch", detail=str(exc))
    return matches[0]


def current_host_id() -> str:
    return socket.gethostname()


def canonical_home() -> Path:
    try:
        return scope.bound_home(__file__)[0]
    except (scope.ScopeError, OSError) as exc:
        stop(EXIT_DENIED, "denied", "invalid_team_binding", detail=str(exc))


def resolve_paths(args: argparse.Namespace, *, create_root: bool = True) -> tuple[Path, Path]:
    home = canonical_home()
    if args.state or args.root:
        stop(EXIT_DENIED, "denied", "caller_selected_runtime_path")
    try:
        state = scope.ledger_path(home, home / "DIRECTOR_STATE.md")
        root_input = scope.claims_path(home)
        scope.private_file(root_input.parent / (root_input.name + ".steps.lock"))
    except (scope.ScopeError, OSError) as exc:
        stop(EXIT_DENIED, "denied", "invalid_team_path", detail=str(exc))

    if root_input.is_symlink():
        stop(EXIT_DENIED, "denied", "claim_root_symlink")
    try:
        if not root_input.exists() and not create_root:
            return state, root_input
        if create_root:
            root_input.mkdir(parents=True, exist_ok=True, mode=0o700)
        root = root_input.resolve(strict=True)
        if root.is_symlink() or root.stat().st_uid != os.getuid():
            stop(EXIT_DENIED, "denied", "claim_root_untrusted")
        if create_root:
            root.chmod(0o700)
    except OSError as exc:
        stop(EXIT_DENIED, "denied", "claim_root_unavailable", detail=str(exc))
    return state, root


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    tmp = Path(tmp_name)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(canonical_bytes(payload))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        dir_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        if tmp.exists():
            tmp.unlink()


def atomic_json_create(path: Path, payload: dict[str, Any]) -> bool:
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    tmp = Path(tmp_name)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(canonical_bytes(payload))
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(tmp, path)
        except FileExistsError:
            return False
        dir_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
        return True
    finally:
        if tmp.exists():
            tmp.unlink()


def read_json(path: Path) -> dict[str, Any]:
    if path.is_symlink():
        stop(EXIT_POISONED, "poisoned", "claim_metadata_untrusted")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        stop(EXIT_POISONED, "poisoned", "claim_metadata_unreadable", detail=str(exc))
    if not isinstance(value, dict):
        stop(EXIT_POISONED, "poisoned", "claim_metadata_invalid")
    return value


def receipt_is_valid(receipt: dict[str, Any], resource_key: str, write_intent_id: str) -> bool:
    schema = receipt.get("schema")
    base_valid = (
        schema in ("controller-write-receipt/v1", "controller-write-receipt/v2")
        and receipt.get("status") == "completed"
        and receipt.get("resource_key") == resource_key
        and receipt.get("write_intent_id") == write_intent_id
        and isinstance(receipt.get("target_id"), str)
        and bool(receipt["target_id"].strip())
        and isinstance(receipt.get("readback"), dict)
        and bool(receipt["readback"])
    )
    if not base_valid:
        return False
    if schema == "controller-write-receipt/v1":
        return True
    return receipt["readback"].get("target_id") == receipt["target_id"]


def failure_is_valid(receipt: dict[str, Any], resource_key: str, write_intent_id: str) -> bool:
    return (
        receipt.get("schema") == "controller-write-failure/v1"
        and receipt.get("status") == "failed"
        and receipt.get("resource_key") == resource_key
        and receipt.get("write_intent_id") == write_intent_id
        and isinstance(receipt.get("reason"), str)
        and bool(receipt["reason"].strip())
        and isinstance(receipt.get("evidence"), dict)
        and bool(receipt["evidence"])
    )


def validate_fence(args: argparse.Namespace, fields: dict[str, str], outcome_hash: str, scope_hash: str) -> None:
    checks = (
        ("STATUS", "ACTIVE", "mission_not_active"),
        ("CONTROLLER_THREAD_ID", args.controller_thread_id, "controller_thread_mismatch"),
        ("CONTROLLER_GENERATION", str(args.controller_generation), "controller_generation_mismatch"),
        ("CONTROLLER_HOST_ID", current_host_id(), "controller_host_mismatch"),
        ("NEXT_PLAY_ID", args.next_play_id, "next_play_mismatch"),
        ("NEXT_PLAY_OUTCOME_HASH", outcome_hash, "next_play_outcome_mismatch"),
        ("AUTHORIZATION_REF", args.authorization_ref, "authorization_ref_mismatch"),
        ("AUTHORIZATION_SCOPE_HASH", scope_hash, "authorization_scope_mismatch"),
    )
    for key, actual, reason in checks:
        if fields.get(key) != actual:
            stop(EXIT_DENIED, "denied", reason)


def validate_authorization_scope(args: argparse.Namespace, scope: Any) -> None:
    if not isinstance(scope, dict):
        stop(EXIT_DENIED, "denied", "authorization_scope_not_object")
    expected = {
        "provider": normalize(args.provider).casefold(),
        "action": normalize(args.action).casefold(),
        "account": normalize(args.account),
        "resource_type": normalize(args.resource_type).casefold(),
        "resource": normalize(args.resource_target),
    }
    for key, value in expected.items():
        actual = scope.get(key)
        if key in ("provider", "action", "resource_type") and isinstance(actual, str):
            actual = normalize(actual).casefold()
        else:
            actual = normalize(actual)
        if actual != value:
            stop(EXIT_DENIED, "denied", f"authorization_scope_{key}_mismatch")


def authorization_steps(args: argparse.Namespace, scope: Any) -> list[dict[str, Any]] | None:
    """The scope's ordered steps, or None for a single-write scope (which keeps its exact old checks)."""
    if not isinstance(scope, dict):
        stop(EXIT_DENIED, "denied", "authorization_scope_not_object")
    if "steps" not in scope:
        if args.step is not None or args.step_write is not None:
            stop(EXIT_DENIED, "denied", "authorization_scope_has_no_steps")
        return None
    steps = scope["steps"]
    if not isinstance(steps, list) or not steps:
        stop(EXIT_DENIED, "denied", "authorization_scope_steps_invalid")
    if any(key in scope for key in STEP_FIELDS):
        stop(EXIT_DENIED, "denied", "authorization_scope_mixed_format")
    for number, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            stop(EXIT_DENIED, "denied", "authorization_scope_step_invalid", step=number, field="step")
        for key in STEP_FIELDS:
            value = step.get(key)
            if not isinstance(value, str) or not value.strip():
                stop(EXIT_DENIED, "denied", "authorization_scope_step_invalid", step=number, field=key)
        limit = step.get("max")
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            stop(EXIT_DENIED, "denied", "authorization_scope_step_invalid", step=number, field="max")
    return steps


def write_identity(provider: str, action: str, account: str, resource_type: str, resource: str) -> dict[str, str]:
    return {
        "provider": normalize(provider).casefold(),
        "action": normalize(action).casefold(),
        "account": normalize(account),
        "resource_type": normalize(resource_type).casefold(),
        "resource": normalize(resource),
    }


def locate_step(args: argparse.Namespace, steps: list[dict[str, Any]]) -> int:
    """The 1-based step these exact CLI arguments name (--step picks one when two steps are identical)."""
    if args.step_write is not None and args.step_write < 1:
        stop(EXIT_DENIED, "denied", "step_write_invalid")
    wanted = write_identity(args.provider, args.action, args.account, args.resource_type, args.resource_target)
    if args.step is not None:
        if not 1 <= args.step <= len(steps):
            stop(EXIT_DENIED, "denied", "step_out_of_range", step=args.step, steps=len(steps))
        have = write_identity(*(steps[args.step - 1][key] for key in STEP_FIELDS))
        for key in STEP_FIELDS:
            if have[key] != wanted[key]:
                stop(EXIT_DENIED, "denied", f"authorization_scope_{key}_mismatch", step=args.step)
        return args.step
    matches = [number for number, step in enumerate(steps, 1) if write_identity(*(step[key] for key in STEP_FIELDS)) == wanted]
    if not matches:
        stop(EXIT_DENIED, "denied", "authorization_scope_step_mismatch")
    if len(matches) > 1:
        stop(EXIT_DENIED, "denied", "step_ambiguous", matching_steps=matches)
    return matches[0]


def resource_key_for(provider: str, account: str, resource_type: str, target: str) -> str:
    return digest({
        "schema": "controller-resource-key/v1",
        "provider": normalize(provider).casefold(),
        "account": normalize(account),
        "resource_type": normalize(resource_type).casefold(),
        "target": normalize(target),
    })


def step_resource_key(step: dict[str, Any]) -> str:
    return resource_key_for(step["provider"], step["account"], step["resource_type"], step["resource"])


def step_intent_id(args: argparse.Namespace, steps: list[dict[str, Any]], number: int, write: int, outcome_hash: str, scope_hash: str) -> str:
    """One deterministic intent per (fence, step, write); the node is recorded in the claim, not keyed."""
    step = steps[number - 1]
    return digest({
        "schema": "controller-write-intent/v2",
        "mission_id": args.mission_id,
        "next_play_id": args.next_play_id,
        "step": number,
        "step_write": write,
        "action": normalize(step["action"]).casefold(),
        "resource_key": step_resource_key(step),
        "outcome_hash": outcome_hash,
        "authorization_scope_hash": scope_hash,
    })


def step_fields(record: dict[str, Any]) -> dict[str, Any]:
    return {key: record[key] for key in ("step", "steps", "step_write") if key in record}


def validate_acquire_args(args: argparse.Namespace, outcome: Any) -> None:
    for name in (
        "mission_id",
        "node_id",
        "next_play_id",
        "controller_thread_id",
        "provider",
        "action",
        "account",
        "resource_type",
        "resource_target",
        "authorization_ref",
    ):
        value = getattr(args, name)
        if not isinstance(value, str) or not value.strip():
            stop(EXIT_DENIED, "denied", f"{name}_missing")
    if args.controller_generation <= 0:
        stop(EXIT_DENIED, "denied", "controller_generation_invalid")
    if not isinstance(outcome, dict) or not outcome:
        stop(EXIT_DENIED, "denied", "outcome_missing")


def node_validation_error(fields: dict[str, str], node_id: str) -> str | None:
    graph_value = fields.get("MISSION_GRAPH", "")
    if not graph_value:
        return "mission_graph_missing"
    try:
        resolved = scope.graph_path(canonical_home(), graph_value)
        graph_text = resolved.read_text(encoding="utf-8")
        _, binding = scope.bound_home(__file__)
        scope.check_text_identity(binding, graph_text)
    except (OSError, scope.ScopeError):
        return "mission_graph_untrusted"
    matches = re.findall(rf"(?m)^## Node:\s*{re.escape(node_id)}\s*$", graph_text)
    if len(matches) != 1:
        return "mission_node_ambiguous"
    return None


def validate_node(fields: dict[str, str], node_id: str) -> None:
    if reason := node_validation_error(fields, node_id):
        stop(EXIT_DENIED, "denied", reason)


def validate_claim_fence(state: Path, claim: dict[str, Any]) -> None:
    if claim.get("controller_host_id") != current_host_id():
        stop(EXIT_DENIED, "denied", "controller_host_mismatch")
    fields = mission_fields(state, str(claim.get("mission_id", "")))
    checks = (
        ("STATUS", "ACTIVE", "mission_not_active"),
        ("CONTROLLER_THREAD_ID", str(claim.get("controller_thread_id", "")), "controller_thread_mismatch"),
        ("CONTROLLER_GENERATION", str(claim.get("controller_generation", "")), "controller_generation_mismatch"),
        ("CONTROLLER_HOST_ID", str(claim.get("controller_host_id", "")), "controller_host_mismatch"),
        ("NEXT_PLAY_ID", str(claim.get("next_play_id", "")), "next_play_mismatch"),
        ("NEXT_PLAY_OUTCOME_HASH", str(claim.get("outcome_hash", "")), "next_play_outcome_mismatch"),
        ("AUTHORIZATION_REF", str(claim.get("authorization_ref", "")), "authorization_ref_mismatch"),
        ("AUTHORIZATION_SCOPE_HASH", str(claim.get("authorization_scope_hash", "")), "authorization_scope_mismatch"),
    )
    for field, expected, reason in checks:
        if fields.get(field) != expected:
            stop(EXIT_DENIED, "denied", reason)
    validate_node(fields, str(claim.get("node_id", "")))


def claim_paths(root: Path, resource_key: str) -> tuple[Path, Path, Path]:
    if not SAFE_KEY.fullmatch(resource_key):
        stop(EXIT_DENIED, "denied", "malformed_resource_key")
    claim_dir = root / resource_key
    if claim_dir.is_symlink():
        stop(EXIT_DENIED, "denied", "claim_entry_symlink")
    if claim_dir.exists() and (not claim_dir.is_dir() or claim_dir.stat().st_uid != os.getuid()):
        stop(EXIT_DENIED, "denied", "claim_entry_untrusted")
    return claim_dir, claim_dir / "claim.json", claim_dir / "receipt.json"


def deny_if_historical_intent(claim_dir: Path, write_intent_id: str) -> None:
    history_root = claim_dir / "history"
    if history_root.is_symlink():
        stop(EXIT_POISONED, "poisoned", "claim_history_untrusted")
    history = history_root / write_intent_id
    if history.is_symlink():
        stop(EXIT_POISONED, "poisoned", "claim_history_untrusted")
    if history.is_dir():
        stop(EXIT_DENIED, "denied", "stale_historical_intent", write_intent_id=write_intent_id, resource_key=claim_dir.name)


def install_new_attempt(claim_dir: Path, claim: dict[str, Any]) -> None:
    transition = claim_dir / ".transition"
    try:
        transition.mkdir(mode=0o700)
    except FileExistsError:
        stop(EXIT_ACTIVE, "reconcile_active", "resource_transition_unresolved", resource_key=claim["resource_key"])
    try:
        current_path = claim_dir / "claim.json"
        terminal_path = claim_dir / "receipt.json"
        current = read_json(current_path)
        terminal = read_json(terminal_path)
        old_intent = str(current.get("write_intent_id", ""))
        resource_key = str(current.get("resource_key", ""))
        if old_intent == claim["write_intent_id"]:
            if failure_is_valid(terminal, resource_key, old_intent):
                stop(EXIT_DENIED, "replay_failed", "prior_attempt_failed", resource_key=claim["resource_key"], write_intent_id=old_intent)
            if receipt_is_valid(terminal, resource_key, old_intent):
                stop(EXIT_DENIED, "denied", "stale_historical_intent", resource_key=claim["resource_key"], write_intent_id=old_intent)
        if failure_is_valid(terminal, resource_key, old_intent):
            archived_name = "failure.json"
        elif receipt_is_valid(terminal, resource_key, old_intent):
            archived_name = "receipt.json"
        else:
            stop(EXIT_POISONED, "poisoned", "failure_receipt_invalid")

        history_root = claim_dir / "history"
        if history_root.is_symlink():
            stop(EXIT_POISONED, "poisoned", "claim_history_untrusted")
        history_root.mkdir(mode=0o700, exist_ok=True)
        history_root.chmod(0o700)
        history = history_root / old_intent
        history.mkdir(parents=True, mode=0o700)
        history.chmod(0o700)
        os.replace(current_path, history / "claim.json")
        os.replace(terminal_path, history / archived_name)
        atomic_json(current_path, claim)
    finally:
        try:
            transition.rmdir()
        except OSError:
            pass


def write_state(root: Path, resource_key: str, write_intent_id: str) -> tuple[str, dict[str, Any]]:
    """Where one write intent stands on its resource: absent, active, completed, failed or unresolved."""
    claim_dir, claim_path, receipt_path = claim_paths(root, resource_key)
    if not claim_dir.exists():
        return "absent", {}
    transition = claim_dir / ".transition"
    if transition.exists() or transition.is_symlink():
        return "unresolved", {}
    history_root = claim_dir / "history"
    history = history_root / write_intent_id
    if history_root.is_symlink() or history.is_symlink():
        stop(EXIT_POISONED, "poisoned", "claim_history_untrusted")
    if history.is_dir():
        for name, is_valid, state in (("receipt.json", receipt_is_valid, "completed"), ("failure.json", failure_is_valid, "failed")):
            path = history / name
            if path.exists() or path.is_symlink():
                record = read_json(path)
                if is_valid(record, resource_key, write_intent_id):
                    return state, record
        stop(EXIT_POISONED, "poisoned", "claim_history_invalid", resource_key=resource_key)
    claim = read_json(claim_path)
    if claim.get("write_intent_id") != write_intent_id:
        return "absent", {}
    if receipt_path.exists() or receipt_path.is_symlink():
        record = read_json(receipt_path)
        if receipt_is_valid(record, resource_key, write_intent_id):
            return "completed", record
        if failure_is_valid(record, resource_key, write_intent_id):
            return "failed", record
        stop(EXIT_POISONED, "poisoned", "terminal_receipt_invalid", resource_key=resource_key)
    return "active", claim


def new_claim(args: argparse.Namespace, resource_key: str, write_intent_id: str, outcome_hash: str, scope_hash: str, **step: Any) -> dict[str, Any]:
    return {
        "status": "active",
        "schema": "controller-write-claim/v1",
        "mission_id": args.mission_id,
        "node_id": args.node_id,
        "next_play_id": args.next_play_id,
        "controller_thread_id": args.controller_thread_id,
        "controller_generation": args.controller_generation,
        "controller_host_id": current_host_id(),
        "action": normalize(args.action).casefold(),
        "resource_key": resource_key,
        "write_intent_id": write_intent_id,
        "outcome_hash": outcome_hash,
        "authorization_ref": args.authorization_ref,
        "authorization_scope_hash": scope_hash,
        **step,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def take_claim(root: Path, resource_key: str, write_intent_id: str, claim: dict[str, Any], **where: Any) -> None:
    """Grant, replay or refuse one write intent on its resource (one current claim per resource)."""
    claim_dir, claim_path, receipt_path = claim_paths(root, resource_key)
    try:
        claim_dir.mkdir(mode=0o700)
        created = True
    except FileExistsError:
        created = False
    except OSError as exc:
        stop(EXIT_DENIED, "denied", "claim_acquire_failed", detail=str(exc))

    if not created:
        deny_if_historical_intent(claim_dir, write_intent_id)
        if receipt_path.exists():
            receipt = read_json(receipt_path)
            if receipt_is_valid(receipt, resource_key, write_intent_id):
                emit("replay_completed", resource_key=resource_key, write_intent_id=write_intent_id, target_id=receipt.get("target_id"), readback=receipt.get("readback"), **where)
                return
            current = read_json(claim_path)
            old_intent = str(current.get("write_intent_id", ""))
            if failure_is_valid(receipt, resource_key, old_intent):
                if old_intent == write_intent_id:
                    stop(EXIT_DENIED, "replay_failed", "prior_attempt_failed", resource_key=resource_key, write_intent_id=write_intent_id, **where)
                install_new_attempt(claim_dir, claim)
                emit("granted", resource_key=resource_key, write_intent_id=write_intent_id, **where)
                return
            if receipt_is_valid(receipt, resource_key, old_intent):
                install_new_attempt(claim_dir, claim)
                emit("granted", resource_key=resource_key, write_intent_id=write_intent_id, **where)
                return
            stop(EXIT_POISONED, "poisoned", "terminal_receipt_invalid", resource_key=resource_key, **where)
        current = read_json(claim_path)
        if current.get("write_intent_id") == write_intent_id:
            stop(EXIT_ACTIVE, "reconcile_active", "intent_unresolved", resource_key=resource_key, write_intent_id=write_intent_id, **where)
        stop(EXIT_DENIED, "denied", "resource_claim_conflict", resource_key=resource_key, **where)

    try:
        atomic_json(claim_path, claim)
    except BaseException:
        # The directory intentionally remains as a poisoned, fail-closed claim.
        raise
    emit("granted", resource_key=resource_key, write_intent_id=write_intent_id, **where)


def step_lock(root: Path) -> int:
    """Serialize step acquires: two calls under one fence must not both pass the order checks before either
    claims. flock is released when the process exits, so a crash leaves no stale lock; the file sits beside
    the claim root, never inside it, so audit and can-rotate never see it."""
    lock_path = root.parent / f"{root.name}.steps.lock"
    try:
        fd = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    except OSError as exc:
        stop(EXIT_DENIED, "denied", "step_lock_unavailable", detail=str(exc))
    if os.fstat(fd).st_uid != os.getuid():
        os.close(fd)
        stop(EXIT_DENIED, "denied", "step_lock_untrusted")
    wait = 10.0
    deadline = time.monotonic() + wait
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return fd
        except BlockingIOError:
            if time.monotonic() >= deadline:
                os.close(fd)
                stop(EXIT_ACTIVE, "reconcile_active", "step_lock_busy")
            time.sleep(0.05)


def acquire_step(args: argparse.Namespace, root: Path, steps: list[dict[str, Any]], number: int, outcome_hash: str, scope_hash: str) -> None:
    """Grant write `--step-write` of step `number` only after every earlier step completed under this fence."""
    lock = step_lock(root)
    try:
        grant_step(args, root, steps, number, outcome_hash, scope_hash)
    finally:
        os.close(lock)


def grant_step(args: argparse.Namespace, root: Path, steps: list[dict[str, Any]], number: int, outcome_hash: str, scope_hash: str) -> None:
    step = steps[number - 1]
    write = 1 if args.step_write is None else args.step_write
    where = {"step": number, "steps": len(steps), "step_write": write, "step_max": step["max"]}
    if write > step["max"]:
        stop(EXIT_DENIED, "denied", "step_max_reached", **where)
    resource_key = step_resource_key(step)
    write_intent_id = step_intent_id(args, steps, number, write, outcome_hash, scope_hash)

    # This exact write: a completed one replays its evidence; a failed or unresolved one never re-runs.
    state, record = write_state(root, resource_key, write_intent_id)
    if state == "completed":
        emit("replay_completed", resource_key=resource_key, write_intent_id=write_intent_id, target_id=record.get("target_id"), readback=record.get("readback"), **where)
        return
    if state == "failed":
        stop(EXIT_DENIED, "replay_failed", "prior_attempt_failed", resource_key=resource_key, write_intent_id=write_intent_id, sequence_stopped=True, **where)
    if state == "active":
        stop(EXIT_ACTIVE, "reconcile_active", "intent_unresolved", resource_key=resource_key, write_intent_id=write_intent_id, **where)
    if state == "unresolved":
        stop(EXIT_ACTIVE, "reconcile_active", "resource_transition_unresolved", resource_key=resource_key, **where)

    # Every earlier step, and this step's earlier writes, completed in order under this fence.
    for earlier in range(1, number + 1):
        earlier_key = step_resource_key(steps[earlier - 1])
        last = steps[earlier - 1]["max"] if earlier < number else write - 1
        completed = 0
        for ordinal in range(1, last + 1):
            earlier_intent = step_intent_id(args, steps, earlier, ordinal, outcome_hash, scope_hash)
            earlier_state, _ = write_state(root, earlier_key, earlier_intent)
            if earlier_state == "completed":
                completed += 1
                continue
            if earlier_state == "failed":
                stop(EXIT_DENIED, "denied", "prior_step_failed", failed_step=earlier, failed_write=ordinal, resource_key=earlier_key, write_intent_id=earlier_intent, sequence_stopped=True, **where)
            if earlier_state in ("active", "unresolved"):
                stop(EXIT_ACTIVE, "reconcile_active", "prior_step_unresolved", unresolved_step=earlier, unresolved_write=ordinal, resource_key=earlier_key, write_intent_id=earlier_intent, **where)
            break  # absent: writes are granted in order, so no later one exists
        if earlier < number and completed == 0:
            stop(EXIT_DENIED, "denied", "step_out_of_order", waiting_on_step=earlier, **where)
        if earlier == number and completed < write - 1:
            stop(EXIT_DENIED, "denied", "step_write_out_of_order", waiting_on_write=completed + 1, **where)

    # A later step that has started closes this one.
    for later in range(number + 1, len(steps) + 1):
        later_state, _ = write_state(root, step_resource_key(steps[later - 1]), step_intent_id(args, steps, later, 1, outcome_hash, scope_hash))
        if later_state != "absent":
            stop(EXIT_DENIED, "denied", "step_closed", later_step=later, **where)

    claim = new_claim(args, resource_key, write_intent_id, outcome_hash, scope_hash, step=number, steps=len(steps), step_write=write)
    take_claim(root, resource_key, write_intent_id, claim, **where)


def acquire(args: argparse.Namespace) -> None:
    state, root = resolve_paths(args)
    outcome = parse_json(args.outcome_json, "outcome_json")
    scope = parse_json(args.authorization_scope_json, "authorization_scope_json")
    validate_acquire_args(args, outcome)
    steps = authorization_steps(args, scope)
    number = 0
    if steps is None:
        validate_authorization_scope(args, scope)
    else:
        number = locate_step(args, steps)
    outcome_hash = digest(outcome)
    scope_hash = digest(scope)
    fields = mission_fields(state, args.mission_id)
    validate_fence(args, fields, outcome_hash, scope_hash)
    validate_node(fields, args.node_id)
    if steps is not None:
        acquire_step(args, root, steps, number, outcome_hash, scope_hash)
        return

    resource_key = resource_key_for(args.provider, args.account, args.resource_type, args.resource_target)
    intent_payload = {
        "schema": "controller-write-intent/v1",
        "mission_id": args.mission_id,
        "node_id": args.node_id,
        "next_play_id": args.next_play_id,
        "action": normalize(args.action).casefold(),
        "resource_key": resource_key,
        "outcome_hash": outcome_hash,
        "authorization_scope_hash": scope_hash,
    }
    write_intent_id = digest(intent_payload)
    take_claim(root, resource_key, write_intent_id, new_claim(args, resource_key, write_intent_id, outcome_hash, scope_hash))


def complete(args: argparse.Namespace) -> None:
    state, root = resolve_paths(args)
    claim_dir, claim_path, receipt_path = claim_paths(root, args.resource_key)
    if not claim_dir.is_dir():
        stop(EXIT_DENIED, "denied", "claim_missing")
    if receipt_path.exists():
        receipt = read_json(receipt_path)
        if receipt_is_valid(receipt, args.resource_key, args.write_intent_id):
            emit("replay_completed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, target_id=receipt.get("target_id"), readback=receipt.get("readback"), **step_fields(receipt))
            return
        if failure_is_valid(receipt, args.resource_key, args.write_intent_id):
            stop(EXIT_DENIED, "replay_failed", "prior_attempt_failed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, **step_fields(receipt))
        stop(EXIT_POISONED, "poisoned", "terminal_receipt_invalid")
    claim = read_json(claim_path)
    if claim.get("write_intent_id") != args.write_intent_id or claim.get("status") != "active":
        stop(EXIT_DENIED, "denied", "claim_intent_mismatch")
    validate_claim_fence(state, claim)
    if not args.target_id.strip():
        stop(EXIT_DENIED, "denied", "target_id_missing")
    readback = parse_json(args.readback_json, "readback_json")
    if not isinstance(readback, dict) or not readback:
        stop(EXIT_DENIED, "denied", "readback_evidence_missing")
    if readback.get("target_id") != args.target_id:
        stop(EXIT_DENIED, "denied", "readback_target_mismatch")
    step = step_fields(claim)  # a step's receipt records which step and write it completed
    receipt = {
        "status": "completed",
        "schema": "controller-write-receipt/v2",
        "resource_key": args.resource_key,
        "write_intent_id": args.write_intent_id,
        "target_id": args.target_id,
        "readback": normalize(readback),
        **step,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    if atomic_json_create(receipt_path, receipt):
        if step:
            step["sequence_complete"] = step.get("step") == step.get("steps")
        emit("completed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, target_id=args.target_id, **step)
        return
    existing = read_json(receipt_path)
    if receipt_is_valid(existing, args.resource_key, args.write_intent_id):
        emit("replay_completed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, target_id=existing.get("target_id"), readback=existing.get("readback"), **step_fields(existing))
        return
    stop(EXIT_DENIED, "denied", "completed_resource_conflict", resource_key=args.resource_key)


def fail_attempt(args: argparse.Namespace) -> None:
    state, root = resolve_paths(args)
    claim_dir, claim_path, receipt_path = claim_paths(root, args.resource_key)
    if not claim_dir.is_dir():
        stop(EXIT_DENIED, "denied", "claim_missing")
    if receipt_path.exists():
        terminal = read_json(receipt_path)
        if failure_is_valid(terminal, args.resource_key, args.write_intent_id):
            emit("replay_failed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, reason=terminal.get("reason"), evidence=terminal.get("evidence"), **step_fields(terminal))
            return
        if receipt_is_valid(terminal, args.resource_key, args.write_intent_id):
            stop(EXIT_DENIED, "denied", "attempt_already_completed")
        stop(EXIT_POISONED, "poisoned", "terminal_receipt_invalid")
    claim = read_json(claim_path)
    if claim.get("write_intent_id") != args.write_intent_id or claim.get("status") != "active":
        stop(EXIT_DENIED, "denied", "claim_intent_mismatch")
    validate_claim_fence(state, claim)
    if not args.reason.strip():
        stop(EXIT_DENIED, "denied", "failure_reason_missing")
    evidence = parse_json(args.evidence_json, "evidence_json")
    if not isinstance(evidence, dict) or not evidence:
        stop(EXIT_DENIED, "denied", "failure_evidence_missing")
    step = step_fields(claim)  # a failed step stops its sequence: later steps are refused until a new fence
    failure = {
        "status": "failed",
        "schema": "controller-write-failure/v1",
        "resource_key": args.resource_key,
        "write_intent_id": args.write_intent_id,
        "reason": args.reason,
        "evidence": normalize(evidence),
        **step,
        "failed_at": datetime.now(timezone.utc).isoformat(),
    }
    if atomic_json_create(receipt_path, failure):
        if step:
            step["sequence_stopped"] = True
        emit("failed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, reason=args.reason, **step)
        return
    existing = read_json(receipt_path)
    if failure_is_valid(existing, args.resource_key, args.write_intent_id):
        emit("replay_failed", resource_key=args.resource_key, write_intent_id=args.write_intent_id, reason=existing.get("reason"), evidence=existing.get("evidence"), **step_fields(existing))
        return
    stop(EXIT_POISONED, "poisoned", "failure_receipt_invalid")


def inspect(args: argparse.Namespace) -> None:
    _, root = resolve_paths(args)
    claim_dir, claim_path, receipt_path = claim_paths(root, args.resource_key)
    if not claim_dir.is_dir():
        stop(EXIT_DENIED, "denied", "claim_missing")
    if receipt_path.exists():
        receipt = read_json(receipt_path)
        if receipt_is_valid(receipt, args.resource_key, str(receipt.get("write_intent_id", ""))):
            emit("completed", resource_key=args.resource_key, write_intent_id=receipt.get("write_intent_id"), target_id=receipt.get("target_id"), **step_fields(receipt))
            return
        if failure_is_valid(receipt, args.resource_key, str(receipt.get("write_intent_id", ""))):
            emit("failed", resource_key=args.resource_key, write_intent_id=receipt.get("write_intent_id"), reason=receipt.get("reason"), **step_fields(receipt))
            return
        stop(EXIT_POISONED, "poisoned", "receipt_invalid")
    claim = read_json(claim_path)
    emit("active", resource_key=args.resource_key, write_intent_id=claim.get("write_intent_id"), controller_generation=claim.get("controller_generation"), **step_fields(claim))


def can_rotate(args: argparse.Namespace) -> None:
    _, root = resolve_paths(args, create_root=False)
    if not root.exists():
        emit("rotatable", mission_id=args.mission_id, controller_generation=args.controller_generation)
        return
    for entry in root.iterdir():
        if entry.is_symlink() or not entry.is_dir() or entry.stat().st_uid != os.getuid():
            stop(EXIT_POISONED, "poisoned", "claim_entry_untrusted")
        transition_path = entry / ".transition"
        if transition_path.exists() or transition_path.is_symlink():
            stop(EXIT_POISONED, "poisoned", "claim_transition_unresolved", resource_key=entry.name)
        claim_path = entry / "claim.json"
        claim = read_json(claim_path)
        if claim.get("schema") != "controller-write-claim/v1" or claim.get("status") != "active":
            stop(EXIT_POISONED, "poisoned", "claim_metadata_invalid", resource_key=entry.name)
        resource_key = str(claim.get("resource_key", ""))
        if resource_key != entry.name:
            stop(EXIT_POISONED, "poisoned", "resource_key_path_mismatch", resource_key=entry.name)
        _, _, receipt_path = claim_paths(root, resource_key)
        if receipt_path.is_symlink():
            stop(EXIT_POISONED, "poisoned", "receipt_untrusted", resource_key=entry.name)
        if claim.get("mission_id") != args.mission_id or claim.get("controller_generation") != args.controller_generation:
            continue
        intent = str(claim.get("write_intent_id", ""))
        if receipt_path.exists():
            terminal = read_json(receipt_path)
            if receipt_is_valid(terminal, resource_key, intent) or failure_is_valid(terminal, resource_key, intent):
                continue
        stop(EXIT_ACTIVE, "rotation_blocked", "claim_unresolved", resource_key=entry.name, write_intent_id=intent)
    emit("rotatable", mission_id=args.mission_id, controller_generation=args.controller_generation)


def audit(args: argparse.Namespace) -> None:
    state, root = resolve_paths(args, create_root=False)
    missions = load_missions(state)
    for mission_id in missions:
        mission_fields(state, mission_id)
    errors: list[dict[str, str]] = []
    seen_resources: set[str] = set()
    active = 0
    completed = 0

    if not root.exists():
        emit("pass", active=0, completed=0, errors=[])
        return

    for entry in sorted(root.iterdir(), key=lambda item: item.name):
        if entry.is_symlink() or not entry.is_dir():
            errors.append({"claim": entry.name, "reason": "claim_entry_untrusted"})
            continue
        claim_path = entry / "claim.json"
        receipt_path = entry / "receipt.json"
        transition_path = entry / ".transition"
        if transition_path.exists() or transition_path.is_symlink():
            errors.append({"claim": entry.name, "reason": "claim_transition_unresolved"})
            continue
        if claim_path.is_symlink():
            errors.append({"claim": entry.name, "reason": "claim_metadata_untrusted"})
            continue
        try:
            claim = json.loads(claim_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            errors.append({"claim": entry.name, "reason": "claim_metadata_unreadable"})
            continue
        if not isinstance(claim, dict) or claim.get("schema") != "controller-write-claim/v1" or claim.get("status") != "active":
            errors.append({"claim": entry.name, "reason": "claim_metadata_invalid"})
            continue
        resource_key = str(claim.get("resource_key", ""))
        if resource_key in seen_resources:
            errors.append({"claim": entry.name, "reason": "duplicate_resource_claim"})
        seen_resources.add(resource_key)
        if resource_key != entry.name:
            errors.append({"claim": entry.name, "reason": "resource_key_path_mismatch"})

        if receipt_path.is_symlink():
            errors.append({"claim": entry.name, "reason": "receipt_untrusted"})
            continue
        if receipt_path.exists():
            try:
                receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                errors.append({"claim": entry.name, "reason": "receipt_unreadable"})
                continue
            intent = str(claim.get("write_intent_id", ""))
            if not isinstance(receipt, dict) or not (receipt_is_valid(receipt, resource_key, intent) or failure_is_valid(receipt, resource_key, intent)):
                errors.append({"claim": entry.name, "reason": "receipt_claim_mismatch"})
            else:
                completed += 1
            continue

        active += 1
        matches = missions.get(str(claim.get("mission_id", "")), [])
        if len(matches) != 1:
            errors.append({"claim": entry.name, "reason": "mission_identity_ambiguous"})
            continue
        fields = matches[0]
        checks = (
            ("STATUS", "ACTIVE", "mission_not_active"),
            ("CONTROLLER_THREAD_ID", str(claim.get("controller_thread_id", "")), "controller_thread_mismatch"),
            ("CONTROLLER_GENERATION", str(claim.get("controller_generation", "")), "controller_generation_mismatch"),
            ("CONTROLLER_HOST_ID", str(claim.get("controller_host_id", "")), "controller_host_mismatch"),
            ("NEXT_PLAY_ID", str(claim.get("next_play_id", "")), "next_play_mismatch"),
            ("NEXT_PLAY_OUTCOME_HASH", str(claim.get("outcome_hash", "")), "next_play_outcome_mismatch"),
            ("AUTHORIZATION_REF", str(claim.get("authorization_ref", "")), "authorization_ref_mismatch"),
            ("AUTHORIZATION_SCOPE_HASH", str(claim.get("authorization_scope_hash", "")), "authorization_scope_mismatch"),
        )
        for field, expected, reason in checks:
            if fields.get(field) != expected:
                errors.append({"claim": entry.name, "reason": reason})
        if reason := node_validation_error(fields, str(claim.get("node_id", ""))):
            errors.append({"claim": entry.name, "reason": reason})

    if errors:
        emit("fail", active=active, completed=completed, errors=errors)
        raise SystemExit(1)
    emit("pass", active=active, completed=completed, errors=[])


def parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--state")
    common.add_argument("--root")
    root = argparse.ArgumentParser(description=__doc__)
    sub = root.add_subparsers(dest="command", required=True)

    acquire_parser = sub.add_parser("acquire", parents=[common])
    for name in ("mission-id", "node-id", "next-play-id", "controller-thread-id", "provider", "action", "account", "resource-type", "resource-target", "outcome-json", "authorization-ref", "authorization-scope-json"):
        acquire_parser.add_argument(f"--{name}", required=True)
    acquire_parser.add_argument("--controller-generation", required=True, type=int)
    acquire_parser.add_argument("--step", type=int, help="multi-step scope: the 1-based step these arguments name; needed only when two steps are identical")
    acquire_parser.add_argument("--step-write", type=int, help="multi-step scope: the step's K-th write, up to its max (default 1); the same K replays, never rewrites")
    acquire_parser.set_defaults(handler=acquire)

    complete_parser = sub.add_parser("complete", parents=[common])
    for name in ("resource-key", "write-intent-id", "target-id", "readback-json"):
        complete_parser.add_argument(f"--{name}", required=True)
    complete_parser.set_defaults(handler=complete)

    fail_parser = sub.add_parser("fail", parents=[common])
    for name in ("resource-key", "write-intent-id", "reason", "evidence-json"):
        fail_parser.add_argument(f"--{name}", required=True)
    fail_parser.set_defaults(handler=fail_attempt)

    inspect_parser = sub.add_parser("inspect", parents=[common])
    inspect_parser.add_argument("--resource-key", required=True)
    inspect_parser.set_defaults(handler=inspect)

    audit_parser = sub.add_parser("audit", parents=[common])
    audit_parser.set_defaults(handler=audit)

    rotate_parser = sub.add_parser("can-rotate", parents=[common])
    rotate_parser.add_argument("--mission-id", required=True)
    rotate_parser.add_argument("--controller-generation", required=True, type=int)
    rotate_parser.set_defaults(handler=can_rotate)
    return root


def main() -> None:
    args = parser().parse_args()
    args.handler(args)


if __name__ == "__main__":
    main()
