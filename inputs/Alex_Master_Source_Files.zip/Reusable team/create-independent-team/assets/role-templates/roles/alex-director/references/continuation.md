# Planning, takeover and goal continuation

Shared: the Director dispatches by it; controllers follow it through the conductor's pointer. This
procedure lives here only; don't copy it into project task lists.

## Planning, then execution
- A planning-only request stays read-only. When Alex requests planning followed by execution,
  planning is a stage of that request: accept the plan against the existing outcome, then issue
  the next authorized assignment in the same cycle. No new owner approval; no ready work left
  unassigned.
- An accepted design or execution plan is reused: no new brainstorming, spec or plan approval cycle.
- A Director-issued read-only play stays read-only until the Director replaces it with a concrete
  execution play; issuing that play is the Director's job, not Alex's. A controller reports that
  dependency to the Director once, not as missing Alex approval, then does other authorized
  independent work. Execute doesn't mean activate.

## Takeover
After a Director takeover, dispatch nonconflicting work as soon as supervision is transferred.
Keep current owners for shared resources until their individual transfers pass. An unresolved
timer, Sheet range or provider claim blocks only work using that resource; it never blocks an
isolated candidate build or other already-authorized independent work.

## Assignments
Every assignment specifies its outcome, source pointers, acceptance, allowed resources and actual
stop/resume conditions. Use this team's graph dependencies and any task queue explicitly named by the current mission to choose the
next ready outcome; reconcile stale fields from accepted checkpoints before treating an old
aggregate `BLOCKED` status as a reason to stop. Reuse this team's settled decisions and approvals recorded from Alex's current authority within their unchanged scope. Never inherit another team's approvals. Alex's current instructions override older approval conventions.

## Goal lifecycle (Codex goals and similar)
Inspect the actual goal and the available lifecycle tools before using a goal as the execution
loop. Tool names vary by surface: native `update_goal`, or `codex_goals.stop_goal` exposed as
`mcp__codex_apps__codex_goals_stop_goal`; never infer their absence from the missing unnamespaced
name `stop_goal`. Complete only the actual goal whose acceptance is met; a local phase never
completes a broader mission. Mark a goal blocked only after the same genuine blocker recurs for
three consecutive goal turns with no independent progress available; never complete a whole
mission to silence a waiting assignment. If lifecycle tools are genuinely unavailable, record that
TOOL failure once with the inspected inventory and request supported goal control from the
supervising owner. Empty or repeated waiting turns aren't progress: after that one report, don't
repeat discovery or status calls; wait for a real assignment or a changed dependency. No database
edits, substitute polling loop or denial bypass.
