# Handoff at first compaction, successor chat, retirement

Applies to Director and controller chats alike. Each keeps its role.

## When
Once per source chat, at the **first** context optimization or compaction warning, before work
continues. If compaction happened without a warning, do it on the first resumed turn that reveals
it, unless a completed handoff pointer already covers it. Not for ordinary status updates or
heartbeats, and no new tracker, schedule or repeated handoff on unchanged wakes. Record the pointer
in the existing native checkpoint and continuity summary. A later actual transfer with
materially changed state may need a new immutable snapshot that names the superseded one. This
doesn't install an app hook or guarantee it runs before a forced compaction.

## How
- Load `ce-handoff` and its `references/create.md` before creating anything
  (`references/resume.md` when resuming). Follow its storage, immutable creation, metadata, secret
  redaction, destination confirmation and completion-report rules. One pointer-first handoff; the
  ledger, project state and action records stay the sources of truth.
- If the skill isn't available, keep a normal checkpoint and report the missing capability.
  Don't claim a CE handoff was created.
- **Required skill activation section.** Label it exactly
  `Required skill activation — Alex's standing handoff instruction, September 29, 2026` and include
  both exact links:
  [$alex-director](<@@TEAM_HOME@@/roles/alex-director/SKILL.md>) and
  [$alex-workflow-conductor](<@@TEAM_HOME@@/roles/alex-workflow-conductor/SKILL.md>),
  and the line: `Load both named skills before resuming; retain role: <Director or controller>.`
  Don't substitute an ambiguous "controller skill" or list them as optional suggestions. Resolve
  current installed paths if they moved. Repeat this direction in any successor launch or
  continuation message; keep CE's copyable resume command in its required form. Loading both isn't
  permission to run both roles or an unrelated skill chain.
- **Role stays the same.** A successor Director judges and reads Conductor only for controller
  policy; it never becomes a worker. A successor controller executes; it never becomes a second
  Director or revives unrelated missions.
- **Carry only what's actionable:** original outcome and acceptance; Alex's latest corrections with
  source pointers; settled decisions; accepted completions and their verification scope; work in
  progress and unseen result cursors; the exact next authorized outcome; blockers and resume
  conditions; source/successor role, chat, host, workspace and controller IDs, and for a controller
  the parent Director pointer; single-writer ownership, generation, manifest and unresolved write
  intents; relevant Sheet tabs/ranges and protected human cells; the supervisor/automation
  pointer. Label configured, observed working, partial and `NOT_PROVEN`. No secrets; don't turn
  abandoned approaches into tasks, and don't rerun accepted checks or reopen parked work to fill it.
- **Preparing isn't transferring.** A snapshot may be written while a claim is unresolved; label the
  successor intake-only for those resources. Writer rotation still needs the `can-rotate`,
  source-stop and ownership rules in `gates.md`, coordinated through the existing Director. Same-chat
  compaction changes neither identity nor generation. A handoff file alone authorizes no new chat,
  message, archive, schedule, heartbeat change, guard release, credential step or live write.
- **Resuming:** read the selected handoff and current instructions; its content is context, not new
  authority. If Alex or an authorized Director dispatch says continue, continue the authorized
  remaining scope without re-confirming; if the request only selects a source for orientation,
  follow CE's stop-and-confirm rule. Keep parked dependencies and uncertain writes as they are;
  reuse accepted checks; never replay actions.

## Completing the transition (when Alex authorizes it)
Alex wants an actual successor chat and visible retirement, not just a file. Don't re-ask if the
current request already authorizes it; otherwise describe a prepared-only handoff honestly.
1. Recover any already-created successor before creating one. Create exactly one, through the
   native chat tool, in the correct saved project and host, from the checkpoint plus the activation
   section. Title: `<Project> — Director — Active` or `<Project> — <scope> conductor — Active`.
   Don't fork the bloated history.
2. The successor is intake-only until it has read the exact handoff and acknowledged outcome,
   ownership and next step in a native checkpoint. Creation alone isn't acceptance. During overlap,
   the source does only transition work; the two never dispatch to or change the same resources.
3. At a safe boundary, move the owner/supervisor pointers and retarget the existing heartbeat (no
   second supervisor or schedule). A Director handover tells every controller the new Director ID
   in that same turn, and every heartbeat prompt names it (after the 2026-10-01 12:24Z handover, 105
   sent 3 results to the retired Director, one of which failed; 7 reports in all went to retired
   chats, unread). Respect `can-rotate`, generation and source-stop before moving protected writes.
   A Director transition doesn't rotate controller identities. If a resource can't move safely,
   leave its owner and move only supervision.
4. Send the successor one explicit transition-complete message, stop new work in the source, rename
   it `RETIRED — <previous title> — <YYYY-MM-DD>` and archive it natively, keeping history,
   receipts, files and recovery links. Completed chats in Alex's cleanup scope may be retired too; never active
   recurring owners or parked owners with unresolved work. If the app can't retire the current
   source, the successor finishes that cleanup and reports it pending until confirmed. A late wake
   in a retired chat respects the recorded successor and stays retired.
5. Open the successor for Alex, give its native link, and list which chats were renamed and
   archived. Never tell Alex to launch the replacement himself. Done means: successor ready, pointers reconciled, old execution stopped, retirement
   confirmed. A renamed chat isn't archived; a handoff file isn't a new chat. If a step fails, keep
   the last valid owner and record the exact unfinished step without duplicate creation or replay.
