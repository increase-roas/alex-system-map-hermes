# Gates: approvals, contact, spend and protected writes

Shared by the Director and every controller. Reading this file doesn't activate the Director role.
The contact and spend gate applies to every conductor task. The approvals table and standing
authorization apply to Director-assigned missions. A standalone conductor task (no Director
mission) also keeps the contact and spend gate, the protected-path rows and the
production/DNS/infrastructure and destructive-deletion rows, approved by Alex in its own thread;
other actions it may take within the scope of the task Alex gave it.

## What needs Alex, and what doesn't
| Boundary | Who approves | Where |
|---|---|---|
| Spend | Alex, separately, for an exact test cost or a bounded budget | Recorded with its source ID and cap |
| Real-person contact | Alex, through the contact gate below | Mission graph / checkpoint |
| Production, DNS, infrastructure changes; destructive deletion | Alex, in the executing controller's thread | That thread |
| Owner-only protected writes: `~/.zshrc`, LaunchAgents, `/etc` | Alex, in the executing controller's thread | That thread |
| Widening a frozen outcome; global skill or config edits; destructive moves; platform or security permissions | Alex, only if the authority isn't already granted (never re-ask an existing grant) | Mission graph (`WAITING_ON_ALEX` on the affected node only) |
| `~/.codex` config and `AGENTS.md` edits Alex asks for in the executing thread | Already approved by that ask; not a Level 3 change and not `STOPPED BY BOUNDARY` | That thread |
| Everything else: credential reads, token requests, read-only queries, test entities, dry runs, in-workspace config, DEV/staging secret or config replacement, one-shot proofs | Alex's current mission scope and applicable instructions; any standing grant must be recorded in `@@TEAM_HOME@@/STANDING_AUTHORIZATIONS.md` | Dispatch authorized work immediately; setup creates no standing grant |

- When a current standing grant exists: write the bounded action (target, max count, stop condition, no retry) into
  `NEXT_PLAY`, send it as owner-approved, record the grant in mission state. Don't set
  `WAITING_ON_ALEX` for it. If a controller questions it, cite the grant and its source once.
- Alex's current explicit direction beats older blanket grants. No grant bypasses the contact
  test, the five-response review or the spend gate.
- Approved boundaries persist. Re-ask only when the target, mutation maximums or risk class
  changes, or the approval expired. A route change inside an approved boundary is judged, not
  escalated.
- Record each real approval's durable source ID and scope. The Director may deliver it; the
  executing controller verifies source and scope once. Inference, a relay phrase or an old
  blanket grant never creates contact or spend authority.
- A sandbox or protected-execution reject of one command parks that play and node only, never the
  whole mission. Dispatch any other `READY` node the same cycle.
- `WAITING_ON_ALEX` is only for a real approval, access only Alex holds, or an unresolved material
  business decision. A client or third-party wait is `WAITING_ON_CLIENT`, named in the boundary.

## Real-person contact gate
Phases: `PREP → TEST_PASSED → PILOT → FULL_AUTO`, or `PAUSED`. Record the phase and approval
pointers in the mission graph or checkpoint; contact events live in the CRM or the project's
action store. No second ledger or prose receipts.
1. **Until `PILOT`:** no real-person contact by any channel (email, SMS, call, DM, form, invite)
   except the test to the identity or endpoint Alex designated. The designation authorizes only
   that test. Preparing and simulating may proceed reversibly.
2. **`TEST_PASSED`** means the controller reported a passing designated test, not that Alex
   accepted it. Present the test result and the proposed rollout scope in one review. One
   explicit approval can accept both; record it before entering `PILOT`.
3. **`PILOT`:** at most five **unique** real people within the approved workflow, audience,
   channel, content and action scope. For each keep recipient ID, outbound/provider ID, send
   time, delivery state, the actual inbound response or `PENDING`, the proposed next action, and
   the approval reference. Use guarded, deduplicated writes. Never enroll a sixth to get a reply.
   Pending replies are `WAITING_ON_CLIENT`.
4. **Reviews:** Alex reviews each actual human response and approves the proposed handling before
   it runs. One concise bundle and one approval can cover all five if it names each. Auto-replies,
   bounces, opt-outs, agent self-reports, silence and test contacts don't count. Honor opt-outs;
   never follow up to qualify them.
5. **`FULL_AUTO`** starts automatically, with no new "go", once all five reviews and handling
   approvals are recorded. Keep reply ingestion, outcome tracking and budget accounting.
6. **Stop** the affected outbound automation on a tracking or readback failure, an unexpected
   recipient, scope drift, or Alex's rejection or pause. Keep state, report it, continue unrelated
   work. A changed audience, channel, material content, action scope or budget needs a new scoped
   approval.

**Spend** is forbidden without Alex's separate explicit approval of the exact test cost or a
bounded budget. Test, rollout and `FULL_AUTO` approvals never imply spend. Record each cost
against its cap.

## Protected writes (Director-assigned missions)
Before dispatching any controller-managed shared or live mutation, the Director writes and reads
back in the active mission block: `CONTROLLER_THREAD_ID`, increasing `CONTROLLER_GENERATION`,
`CONTROLLER_HOST_ID`, `NEXT_PLAY_ID`, `NEXT_PLAY_OUTCOME_HASH`, `AUTHORIZATION_REF`,
`AUTHORIZATION_SCOPE_HASH`. Identity never replaces permission for the exact account, action,
resource and consequence.

**Owner-asked work, one fence.** When Alex's own message asks for a specific change, write one
authorization for the bounded sequence that delivers it (for example clone ≤1, draft update ≤1,
validate, publish ≤1, old trigger off ≤1), each step guarded and read back, stopping at the first
mismatch or uncertain write. A create that sends nothing, spends nothing and changes no existing
record (an empty pipeline, a draft) runs in the same play as its discovery; its authorization may
bound the body (name, location, count, zero workflow, card and message writes) instead of freezing
it. Separate fences only where a step needs Alex's own approval (table above). 2026-10-02: a
2-minute pipeline create took a prep play and a fence hop (20 minutes); routing took three fences
without going live.

**One fence, several steps.** That authorization lists the steps in order in its
`authorization_scope`: `"steps": [{"provider", "action", "account", "resource_type", "resource",
"max"}, ...]`, five strings plus `max` (1 or more, the writes that step may make), with any per-step
limits beside them (they count in the scope hash). Such a scope has no top-level provider, action,
account, resource_type or resource; a scope without `steps` works as before. Name a resource that
doesn't exist yet the way the play does (`<location>/<new name>`), the same in every step that
touches it. The guard grants step N only after steps 1..N-1 completed in order under this same fence
(same `NEXT_PLAY_ID`, outcome hash and scope hash), names the step it is waiting on when asked early,
refuses a write past N's `max`, and closes N's unused writes once N+1 starts. Each step completes with
its own target readback. An unresolved step holds the next one until the controller reconciles it
under this same fence (`complete` on exactly one match, otherwise `fail`). A failed step stops the
sequence: later steps are refused until the Director writes a new fence, after every claim of the
old one is closed. A new fence starts at its own step 1, so it lists only the steps still to do; a
step it repeats runs again.

The controller also verifies TEAM_ID and SUPERVISING_DIRECTOR_THREAD_ID against TEAM_BINDING.json.
The controller first reads those seven fields, then runs
`python3 "@@TEAM_HOME@@/scripts/controller-write-guard.py"` before the write, passing
the exact action with `--action`; the guard must match it to `authorization_scope.action` (with
`steps`, that step's five values; add `--step N` only when two steps are identical, and
`--step-write K` for a step's K-th write, where the same K replays and never rewrites) and
derives the resource key and write intent. A ledger entry or a send is not execution.

Filling the seven fields (the guard compares each one with the mission block): `CONTROLLER_HOST_ID`
is `socket.gethostname()` on the host actually running the guard (no environment override).
`AUTHORIZATION_REF` is the path of the play's `<id>-authorization.json` beside the mission graph;
its `outcome` and `authorization_scope` objects reach the controller there, and it passes them as
JSON text in `--outcome-json` and `--authorization-scope-json`. `NEXT_PLAY_OUTCOME_HASH` and
`AUTHORIZATION_SCOPE_HASH` are the guard's own `digest()` of those two objects: sha256 of their
canonical JSON (NFC text, sorted keys, separators `,` and `:`, UTF-8). A field with no value reads
`NONE`, never blank (`ledger.md`); the guard keeps an empty field empty since alex-director 7d945fb.
- Completed replay returns prior target evidence. An `ACTIVE` or unresolved replay is
  non-mutating reconciliation; don't mint a replacement intent for the same mutation.
- No writer rotation or ownership handoff while the generation has an `ACTIVE` or unresolved
  claim. First require a passing guard `can-rotate` for that mission and generation (a prose
  assertion is not proof), stop the source, reconcile target state, and stay blocked without retry
  if uniqueness can't be proven. An intake-only continuity snapshot transfers nothing.
- A failed attempt closes only through the guard's immutable `fail` receipt (reason + evidence).
  The same intent stays denied; only a new Director play and outcome can reopen the resource, and
  the prior failure evidence is kept.
- Keep a generation only when the native handoff proves the same thread moved and the source
  stopped; otherwise rotate after that proof.
- Same-host only: remote or unverified claim namespaces fail closed. Parallel live-system workers
  stay read-only; code writers need isolated worktrees and disjoint file ownership.
- No native idempotency on the target: declare an immutable match predicate first. Zero matches
  may create once; one match must reconcile; multiple, ambiguous or unsupported matches fail
  closed. If the mutation was accepted but the response or readback was lost, keep the claim
  unresolved, stop, look up the target, and stay blocked unless exactly one match proves it.
- Credentials come only from 1Password runtime injection, never into claim files or receipts.
- Completion readback is an evidence object whose top-level `target_id` equals `--target-id`,
  provider evidence beside it. The generated completion record must keep `RESOURCE_KEY`,
  `WRITE_INTENT_ID`, `TARGET_ID` and `TARGET_READBACK`; without all four the mutation isn't done.

**Standalone conductor tasks** (no Director mission) still need exact-target authorization,
deduplication and authoritative readback; don't open a Director mission just to satisfy this.

## External actions in general
Verify target and authority first; read the system of record back afterward. Acceptance is not
completion. Before any loop, bulk send, webhook replay, scheduler or retry loop: confirm exact
target, maximum count, deduplication, stop condition and approval phase. Within that scope,
prefer one canary write, read it back, then repeat. Read IDs back by API before writing them
anywhere (phone numbers, calendar IDs, location IDs): a location's profile phone isn't a
purchased line.

**Client folders:** a client-folder write is one-shot. "Promote" copies once into the client
folder; an owner rejection re-closes it. Rebuilds and edits stay in the working folder until Alex
says "promote" again. Never edit a file already in the client folder.
