# Recovery scope for this edition

Recover only controllers registered to this TEAM_ID in this team ledger. A matching title in another team is never ownership evidence. Create fresh controllers for new missions; do not recover the original team.

# Controllers: find, create, message

## Recover before creating
Search current, recent, pinned and archived/recoverable tasks, saved Projects, projectless tasks,
and `CONTROLLER:` pointers in `@@TEAM_HOME@@/DIRECTOR_STATE.md` (including `cursor-chat:` IDs
and workspace paths). Prefer this team's registered controller that already owns the mission; titles alone establish no ownership.
Don't create a duplicate, and don't move a mission to a controller that lacks the live tools it
already uses within this team's current assignment.

## Creating a missing controller under the current mission authority
When no appropriate registered controller exists and the current user request authorizes native creation, create **one** new controller chat for that outcome. Respect the current platform tool contract; this source text supplies no missing human authorization. Each independent business outcome has one responsible controller.
1. Create one fresh controller chat using the supported native route on the platform selected for this team, in the smallest correct environment: a saved project when appropriate, otherwise a projectless chat. A same-turn worker is not proof of a persistent controller chat. If that capability is unavailable, report it precisely rather than claiming this arrangement exists.
2. Give it the frozen `OWNER_OUTCOME`, observable `ACCEPTANCE`, context pointers and its
   responsibility boundary, and tell it to load `@@TEAM_HOME@@/roles/alex-workflow-conductor/SKILL.md` first; without that line
   it runs without its skill. Name a Superpowers skill only per Skill triggers below.
3. You choose which controller owns the mission; the controller decides repo or no repo, folder,
   branch, worktree, tests, tools and implementation path. Don't create a repository because a
   mission is big.
4. Creating a task authorizes nothing else: not a repository (unless the controller later needs one
   within its authority), publishing, ads, spend, contacting people, destructive actions,
   production/DNS changes, or consequential live-system actions outside existing permissions.
5. Verify the task exists and received the assignment, store its stable ID in the ledger, observe
   its first meaningful checkpoint, then supervise it normally.
6. If native creation fails: don't do the work yourself and don't build an orchestration layer.
   Report the capability attempted, the exact failure and the smallest blocker; label `NOT_PROVEN`.

## Reaching controllers (never through Alex)

Use only the native routes currently available and authorized on this platform. Historical transport observations below are source evidence, not a new-instance guarantee. A denied creation/send stays denied; do not switch to a queue or shell route to bypass it. Confirm current tool requirements before any send.
- **Cursor** controllers in a shared workspace accept direct agent messages (Task resume by chat
  ID). Cross-workspace delivery is slow but works. If Task resume fails with parent-mismatch, resume
  the reported parent once, transport-only, so it resumes the controller. Never execute the
  assignment in the transport chat. Never re-root or "move" a live controller chat: in Cursor
  that forks it into two live copies, so open chats in the right folder from the start. If a
  fork happened, decide by which copy committed state, then stop the other.
- **Codex** threads:
  - Deliver every play with the app's native `send_message_to_thread`. It reaches cloud and local
    chats (verified 2026-10-01) and starts a turn even on an idle chat (2026-10-01/02: direct-send
    round trips to 102 took 1.0-1.9 minutes, against a 7-21 minute median through the queue).
  - A chat in the middle of another play gets the next one after that play's end line; only Alex's
    live ask (below) or a correction the running play needs goes in now.
  - `codex queue --thread <thread-id> --message "<text>"` is the fallback only (a shell, or a chat
    without that tool). It reaches only chats stored on this Mac (cloud chats fail with "no rollout
    found") and only while the app holds the thread; a message queued to an idle thread can sit
    unsent until the thread is opened in the app (open Codex bug openai/codex#23100; 10 queued plays
    sat 1,130 minutes, one for 16.2 hours). Re-check these after Codex updates.
  - After sending a play, confirm its turn started within 2 minutes, by native status or
    acknowledgment (a send has no delivery receipt). If it hasn't, open the thread in the ChatGPT app
    instead of asking Alex to click Steer; `codex exec resume` fails with "active writer" then.
  - If a send returns "Cannot steer … active turn already ended", send once more
    (openai/codex#38609: an idle target should start a new turn).
- **Alex's live ask goes first.** `codex queue` holds a message until the target's running turn
  ends and has no steer option (2026-10-02: Alex's paid Meta ask waited 12m10s behind a read-only
  check that had started 80 seconds earlier). For a play carrying Alex's own new ask, if the owner
  is mid-turn, send it with `send_message_to_thread` (it reaches the running turn) and say
  "checkpoint your current step, then take this now"; if your inventory lacks that tool, give the
  read-only part to an idle controller and keep only the guarded write with the owner. Never write
  "finish current, then". Keep 15-minute heartbeats off a chat that owns live writes.
- **Claude Code** sessions on this Mac message each other with SendMessage (find the session with
  ListAgents). That stays on this machine and does not go through a server. From a shell,
  `claude -p --resume <session-id>` never queues or waits. If another process holds that session
  (a live `pid` for its `sessionId` in `~/.claude/sessions/*.json`; Desktop chats are listed
  there too), it starts a second, headless copy of the chat under the same ID, which edits files
  and sends messages the open chat doesn't know about (seen 2026-10-01 19:32:31 to 19:40:42Z,
  master-connector-repo `work/2026-10-01_setup-playbook/notes/card-index-rca.md`; resume has no
  lock: anthropics/claude-code#69364, #75761). `--fork-session` only gives that copy its own ID;
  it is still a second writer. So prefer SendMessage from a Claude session, and resume only a
  chat no process holds. A Claude session reaches a ChatGPT or Codex chat with `codex queue`
  above; for a turn that must start now, or one already running, it queues the text to an idle
  local Codex controller, which forwards it with `send_message_to_thread`, transport only
  (2026-10-02/03: three relays reached the Director in 18-57 seconds). A Codex or Cursor session
  reaches a Claude chat with `claude -p --resume` under the same check; if the chat is held, use the
  mission graph header below. An idle Claude chat starts a turn only when a message arrives, so a
  chat holding only gated items sits idle until you send work. On each material wake, check each
  one's session status: not running, with work left and no `STANDBY`, is idle, not quiet.
- Otherwise, write to the mission graph header, which controllers re-read before every external
  write.
- If an existing controller can't be reached or resumed, label it `NOT_PROVEN` and stop; a prompt
  for Alex to copy is not success.

## Controller behavior you can rely on
Controllers never write the ledger; you are its only writer. They put their chat/thread ID and
workspace in their first checkpoint, and you record it in `CONTROLLER` if it differs. They report with a compact checkpoint (result, evidence pointer, remaining work or
blocker, next action), and **every play end** (complete, gate, phase, failure, blocker, `NOT_PROVEN`
or `NO_READY`) sends you one line without waiting for your acknowledgment. A failed send is retried
once; if it fails again, the controller says so in its checkpoint, and your check-in's snapshot of
that controller picks the result up.

Don't copy project memory, `BUILD_STATE` or raw controller logs into the ledger. Don't build
monitoring, discovery, dashboards, databases, daemons, registries or message buses.

## Skill triggers (Superpowers)
For Director/Conductor operating work, this trigger table is the router. Do not invoke
`using-superpowers` as an always-on prerequisite or its 1% applicability rule. An accepted design
or execution plan stays accepted: new brainstorming applies only to a material unresolved design
decision, not to routine implementation, a takeover or a controller continuation. Explicitly
requested planning-only work remains planning-only.

Name a Superpowers skill in a play, and load one on a controller turn, only when its trigger
applies. Mandated procedure caused 114 of 182 skill-induced slowdowns in a 2026 study (arXiv
2608.11888), most of it verification and pipelines the task didn't need.

| Trigger | Skill |
|---|---|
| Observed failure, failed test, stall or `STOPPED BY BOUNDARY` | `systematic-debugging` |
| Behavior or code change where a test is the right proof | `test-driven-development` |
| Done claim on an external or irreversible node | `verification-before-completion` |
| Parallel, bounded, independent work | `dispatching-parallel-agents` |
| Design not yet frozen (never on a frozen BUILD or RUN) | `brainstorming` |
| None of the above | none |
