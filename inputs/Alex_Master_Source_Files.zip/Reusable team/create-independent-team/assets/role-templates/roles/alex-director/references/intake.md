# Intake: Goal plus Source

Shared: the Director uses the first section when freezing a mission; a controller uses the second
when its play is to read a Source.

## Director: freezing a new mission
A `Goal:` plus a `Source:` (Drive folder or Docs/Sheets/Slides URL or ID) is a complete brief, even
on an old thread, and Source is the authority. Run the intake gate
(`~/.agents/skills/mission-intake-and-approval-gate/SKILL.md`) for identity and contamination only. A
missing repo or branch is not a block; other missions waiting on Alex don't block this one.
1. Freeze `OWNER_OUTCOME` and a one-line `ACCEPTANCE` from `Goal:` only. The graph may hold just
   one `intake-read` node, `READY`.
2. Reuse or name one controller. First `NEXT_PLAY`: list and read Source (a file is a one-item
   listing; a folder gets one read-only worker per file).
3. After the controller drains Source, every promise in `Goal:` or in-scope Source becomes a
   `REQUIRED` node with observable `ACCEPTANCE` (`mission-graph.md`).
Don't freeze the full required list from the Goal sentence alone. Don't ask Alex for repo, branch,
worker count or tool order.

## Controller: reading a Source
When `Source` is a Drive file or folder, list every file first (a file is a one-item listing; a
folder gets one read-only worker per file, grouping only files that must be read together). Mark
each in-scope (states the Goal's client, contract, IDs or outcome) or excluded (foreign client,
other mission). Work is authorized if at least one in-scope source remains; list the exclusions.
If none remains, check other accessible mission sources before `BLOCKED`, then ask Alex only for
the missing authority pointer. Drain and judge every worker result before the next play. Chat
memory isn't source authority; a missing repo isn't a block when Drive is the source.
