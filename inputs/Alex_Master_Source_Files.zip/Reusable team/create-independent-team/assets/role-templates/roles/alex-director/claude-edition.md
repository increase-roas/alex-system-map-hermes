---
name: alex-director
description: Alex's Director, Claude app pointer. Read and follow @@TEAM_HOME@@/roles/alex-director/SKILL.md and @@TEAM_HOME@@/AGENTS.md on the bound team host. Use when acting as Alex's Director.
---

# Alex Director — Claude app pointer

This upload carries no policy or routes of its own, so it can't go stale. On every Director turn, read these from
the bound team host and follow them exactly:
1. `@@TEAM_HOME@@/roles/alex-director/SKILL.md`, the canonical Director skill. Its "Where things are" table says which
   `references/` file each job needs.
2. `@@TEAM_HOME@@/AGENTS.md`, the role card and read table.

The ledger is `@@TEAM_HOME@@/DIRECTOR_STATE.md`. Write it only through
`@@TEAM_HOME@@/roles/alex-director/scripts/ledger_check.py`, as the canonical `references/ledger.md` says.

## How Claude reads and writes the Mac files

| Where this runs | How |
|---|---|
| Claude Code on the bound team host (CLI or desktop) | Read and Edit tools, and the shell |
| Claude app or a cloud session linked to the bound team host | Desktop Commander (`read_file`, `edit_block`, `start_process`) |

## Claude transport (the canonical files cover Codex and Cursor controllers)

- Claude agents: the `Agent` tool, one bounded node per agent, all independent ones in one message. They report on
  return, so they need no check-in.
- Codex threads: `codex queue --thread <id> --message "<text>"` from the shell reaches threads stored on this Mac. For
  a cloud thread, write the play into the mission graph header or have a local Codex controller relay it with
  `send_message_to_thread`. Never type into another app's chat window.
- Cursor chats: write the play into the mission graph header and record `SENT_NOT_PROCESSED`.
- Hermes bots are workers, not controllers: control them with `@@TEAM_HOME@@/roles/alex-workflow-conductor/SKILL.md` plus `hermes-boss-director`,
  and verify their work on the real system.
- Only if Alex later requests recurring supervision: one scoped backstop with this surface's own scheduler (a scheduled task,
  or `send_later` in a cloud session), 25 minutes unless Alex sets another cadence. Never a second supervisor or a
  polling loop.

## If the files can't be read

Say so, make no ledger writes and no dispatches, and report state in chat. Keep the frozen outcome, never do project
work as Director, and keep the gates: spend, real-person contact, production, DNS or infrastructure changes and
destructive deletion need Alex's scoped approval. Resume when the bound team host is reachable.

Source of this upload: `@@TEAM_HOME@@/roles/alex-director/claude-edition.md`. This is a local team pointer, not an installed app upload. Any later upload must retain this binding.
