# Mission graph

One durable graph per mission: one compact Markdown file per `MISSION_ID` under
`@@TEAM_HOME@@/`. The ledger stores only `MISSION_GRAPH: <pointer>`. No database, dashboard,
service, registry, repository or separate graph supervisor. Alex states the outcome; you build
and keep the graph without asking him to list tasks, dependencies, tools, Git steps or handoffs.

## Acceptance checklist
The checklist is the graph's `REQUIRED` nodes plus one top-level acceptance node. No second
checklist system.
- Freeze `OWNER_OUTCOME` and one-line `ACCEPTANCE` at intake; expand `REQUIRED` nodes only
  after Source is drained.
- Every promise in `Goal:` or in-scope Source maps to a stable node with observable
  `ACCEPTANCE`, evidence requirement, status and, where it applies, `OWNER_FACING`.
- After that freeze, don't silently delete, weaken or widen required items. A controller may
  clarify the outcome but never silently narrow or replace it.
- If Alex gives a Google Sheet or other checklist, it stays the source authority: turn unclear
  items into verifiable nodes and keep a pointer or row mapping. Don't create a new Sheet unless
  Alex asks.

## What you derive
Required workstreams and stable node IDs; which nodes the owner outcome requires; explicit
dependency IDs; one verifiable acceptance per node; the top-level acceptance node; initial status
and owner boundary; and the responsible controller for each independent business outcome.

## Implied work (adding nodes)
A node is **implied** only when current, traceable evidence requires it for the frozen outcome:
the frozen outcome or acceptance already requires it (a call-ready site implies its leftover
pages; customer service that takes tickets implies form fields); an in-scope Source file lists it
(a Sheet row, a requirements delta, an SOP to-do for the same outcome); or an unsuperseded
accepted checkpoint or legacy evidence pointer in this mission named it as remaining work. Trace
it to that evidence before marking it `READY`. Don't file page-build, form-field or other
leftover work as `WAITING_ON_ALEX` just because it wasn't in the first graph.
- Adding an implied node is graph completion; derive its status normally.
- Adding a node that **widens** the frozen outcome is an acceptance change: mark it
  `WAITING_ON_ALEX` with the proposed acceptance as `BOUNDARY`.
- If traceability is unclear, reconcile sources and accepted checkpoints read-only and research
  external facts (`execution.md`). Uncertainty alone neither authorizes work nor requires Alex.
  Ask Alex only for an unresolved material business-scope or source-authority decision, and mark
  only that node `WAITING_ON_ALEX`.

## Node fields
`NODE_ID`, `REQUIRED`, `STATUS`, `DEPENDS_ON`, `CONTROLLER`, `ACCEPTANCE`, `EVIDENCE`,
`LAST_RECEIPT`, `NEXT_ACTION`, `UPDATED_AT`, and `OWNER_FACING` for things Alex reads or sees.
A table graph without `LAST_RECEIPT` and `UPDATED_AT` columns gets them from
`scripts/migrations/2026-10-02_add-receipt-columns.json`, run with `scripts/graph_edit.py`.

## Status and how to derive it
Allowed: `READY | BLOCKED | ACTIVE | READY_FOR_OWNER | VERIFIED | FAILED | WAITING_ON_ALEX`.
1. `VERIFIED`: a controller checkpoint reports the required acceptance checks with an evidence
   pointer matching `ACCEPTANCE`. A bare completed-chat status can't set it. Don't repeat the
   controller's checks.
2. `READY`: every dependency `VERIFIED`, no owner boundary, not executing.
3. `BLOCKED`: a dependency isn't `VERIFIED`; name those node IDs.
4. `ACTIVE`: native processing status or a readable acknowledgment of the current assignment.
5. `FAILED`: keep the failure evidence; never unlocks downstream nodes.
6. `WAITING_ON_ALEX`: an exact authentication (sign-in), permission or consequence boundary. Not
   retried automatically. An owner review is `READY_FOR_OWNER`, not this.
7. After any node becomes `VERIFIED`, recompute every dependent; eligible ones become `READY`
   without Alex.
8. The mission is `MISSION_COMPLETE` only when every required node and the top-level
   acceptance node are `VERIFIED`.

You own completeness, dependencies, cross-mission priority and final acceptance. Controllers may
propose graph corrections but execute only `READY` nodes, choosing Git, repos, tools, skills,
workers, order and safe parallelism themselves. GitHub applies only to code nodes; it is never
the agency-wide source of truth.

## Owner-facing nodes
Write acceptance as what Alex will see next to the reference he named, not a count the agent can
satisfy alone. Open the references Alex named and check what their links actually open.
- Future routine deliverables with objective criteria or an approved reference/template, and no
  frozen review requirement: a matching controller verification report may set `VERIFIED`.
  Deliver the exact link with no acknowledgment gate.
- When Alex asked to review it, acceptance requires review, or material taste or business
  judgment is unresolved: the controller sets `READY_FOR_OWNER`, you surface the exact link, and
  only Alex's explicit approval sets `VERIFIED`. Silence is never approval.
- On rejection: set `ACTIVE` and append Alex's rejection to `ACCEPTANCE` before rebuilding.
- This never bypasses test, rollout, first-five contact or spend approvals. Authorized
  `FULL_AUTO` sends follow their own gate without per-send review.

## Maintenance
After accepting any checkpoint, update in the same cycle: `STATUS`, `EVIDENCE`, `LAST_RECEIPT`
(native turn pointer or legacy file), `NEXT_ACTION`, `UPDATED_AT`; then recompute dependents.
Do it with `scripts/accept.py`: those cells plus the run-log line, in one command, both or neither.
Other graph edits go through `scripts/graph_edit.py` (backup, atomic write; refuses " | " in a cell).
`scripts/graph_lint.py` flags stale nodes, read-only, warnings only; `ledger_check.py verify` prints it.
A ledger update without the matching graph update is an incomplete cycle.

## Choosing what to dispatch
Collect `READY` nodes across active graphs in Alex's current scope; exclude parked and unrelated
missions. Order by mission priority, owner-impact urgency, critical-path unlock value, then age.
Rotate across missions so one graph can't take every slot. Run independent compatible nodes at
the same time when capacity and safety allow.
