# Ledger: `@@TEAM_HOME@@/DIRECTOR_STATE.md`

Compact mission state and recovery pointers only. Provider IDs, readbacks, write-guard records,
contact responses and approval history stay in their own action stores; ordinary progress stays in
native chat checkpoints. Never copy project narrative, memory or raw logs here.

## Fields in every live mission block
A block runs from its `## Mission:` heading to the next `#` or `##` heading, so every field is
inside the safety check wherever it sits. Keep mission blocks together; put any non-mission notes
under their own `##` heading.
- A field with no value reads `NONE`, never blank: the scripts read a field line by line.
- `TEAM_ID`: @@TEAM_ID@@
- `MISSION_ID`: stable unique ID
- `OWNER_OUTCOME`, `ACCEPTANCE`, `PRIORITY`, `PROJECT`, `CONTROLLER`
- `SUPERVISING_DIRECTOR_THREAD_ID`: the Director chat a controller reports each play end to
  (conductor Report); always @@DIRECTOR_ID@@ in this team
- `MISSION_GRAPH`: pointer to the mission graph file
- `ACCEPTED_CHECKPOINT`: compact gate/phase plus evidence pointers, never narrative
- `REMAINING` and `NEXT_PLAY`
- `NEXT_PLAY_ID`: idempotency key for the current play
- `LAST_DISPATCH`: play ID, UTC time, and `SENT_NOT_PROCESSED` or verified processing status
- `LAST_RECEIPT`: pointer to the latest accepted native turn/checkpoint (or legacy receipt file);
  no new receipt files or IDs are needed
- `LAST_RECONCILED_AT`: UTC time of the last full mission judgment (every non-heartbeat turn that
  reconciles a mission updates it)
- `OWNER_BOUNDARY`: `NONE`, or node IDs each with its exact sentence (never a mission-wide ban)
- `STATUS`: `ACTIVE` | `WAITING_ON_ALEX` | `WAITING_ON_CLIENT` | `MISSION_COMPLETE`.
  `WAITING_ON_ALEX` means only Alex can clear a permission, sign-in or consequence boundary; a
  mission whose only open items are owner reviews (`READY_FOR_OWNER`) stays `ACTIVE`.
  `WAITING_ON_CLIENT` names the client or third
  party in `OWNER_BOUNDARY`. `MISSION_COMPLETE` requires `NEXT_PLAY_ID: NONE` and a `NEXT_PLAY`
  naming no remaining work.
- Protected-write fields when a live mutation is dispatched (see `gates.md`).
- A minimal pending-review field only when needed to keep an unprocessed turn (see
  `supervision.md`); clear it when empty.

## Writing safely (use the script; don't free-hand)
1. `python3 "@@TEAM_HOME@@/roles/alex-director/scripts/ledger_check.py" backup "@@TEAM_HOME@@/DIRECTOR_STATE.md" --by <your role>`
   takes the write lock and the backup. If it says the ledger is locked, another writer is mid-edit:
   don't edit, and retry on the next wake. Read the ledger fresh after this step, never before.
2. Edit only the target `## Mission: <exact name>` block. Never match or replace a field value
   that can appear in other missions (especially `STATUS`), and never replace-all. To add a
   mission, check the heading doesn't already exist as a live heading, then append the whole block
   at the end of the file. Never anchor an insertion to `STATUS`, `CONTROLLER`, `NEXT_PLAY` or any
   other field, and never use a mid-file patch whose context could match an earlier mission.
3. `python3 "@@TEAM_HOME@@/roles/alex-director/scripts/ledger_check.py" verify "@@TEAM_HOME@@/DIRECTOR_STATE.md"
   --mode append|edit --mission "<exact name>"`. It checks unique headings, the mission count,
   append position, and that every other mission is byte-identical, then prints the target
   block's diff. Read that diff and confirm it contains exactly the intended change; the script
   can't judge intent. An OK releases the lock.
4. On `FAIL`: run `restore` (it also releases the lock), report the exact failure, and stop. If
   `restore` refuses because no lock is held, don't copy the `.bak` by hand: it is from an older
   write cycle. Report and stop. Never rebuild the ledger from
   memory. Don't rewrite the whole ledger except by restoring.

**Merges** (owner-approved only): keep a durable copy of the full pre-merge ledger first; the
surviving block lists every absorbed `MISSION_ID` in `MERGED_MISSION_IDS`; verify with
`--mode merge --absorbed <N>` (it checks each absorbed ID is listed).

**Schema migrations** (owner-approved only) may rewrite every live block once when required fields
change. Require an exact before-file hash, a durable full copy, the `.bak`, an expected mission-ID
manifest, and a validator that fails on the old ledger and passes on the new one. Move project
evidence behind durable pointers before replacing narrative fields; lose none.
