# Mission graph: <short name>
<!--
Blank mission graph. Copy it to @@TEAM_HOME@@/mission-graphs/<MISSION_ID>.md, replace every <...>, put that path in the
ledger block's MISSION_GRAPH field (DIRECTOR_STATE.md), and delete this comment in the copy. What each field and status
means: @@TEAM_HOME@@/roles/alex-director/references/mission-graph.md.
-->
TEAM_ID: @@TEAM_ID@@
SUPERVISING_DIRECTOR_THREAD_ID: @@DIRECTOR_ID@@
MISSION_ID: <mission-id>
OWNER_OUTCOME: <the outcome the owner stated, one sentence; frozen at intake>
ACCEPTANCE: <one line: what the owner will see when it is met; frozen at intake>
SOURCE: <where it came from: chat or file, date, and the owner's exact words>
PROJECT: <absolute project path; job folder; where evidence goes>
CONTROLLER: <controller chat or thread ID and workspace>
ALLOWED / BOUNDARIES: <what controllers may do without asking; what waits for the owner (references/gates.md)>
OWNER RULES: <owner, date; never drop>: (1) <rule> (2) <rule>

| NODE_ID | REQUIRED | STATUS | DEPENDS_ON | CONTROLLER | ACCEPTANCE | EVIDENCE | LAST_RECEIPT | NEXT_ACTION | UPDATED_AT | OWNER_FACING |
|---|---|---|---|---|---|---|---|---|---|---|
| <node-id> | <yes, or yes (implied: <evidence pointer>)> | <READY / BLOCKED / ACTIVE / READY_FOR_OWNER / VERIFIED / FAILED / WAITING_ON_ALEX> | <node IDs, or -> | <controller ID> | <one observable check> | <evidence pointer, or -> | <turn pointer or receipt file, or -> | <next action, or -> | <YYYY-MM-DDTHH:MMZ> | <yes / no> |
| top-acceptance | yes | BLOCKED | <every required node ID> | <controller ID> | <the ACCEPTANCE line above, as the owner will see it> | - | - | - | <YYYY-MM-DDTHH:MMZ> | <yes / no> |

UPDATED_AT: <YYYY-MM-DDTHH:MMZ>

<!-- Protected writes (scripts/controller-write-guard.py): add exactly one line "## Node: <NODE_ID>" below this comment
for each node that gets a write fence, e.g. "## Node: javar-desktop-route". The guard counts these lines, not the table rows. -->
