"""Team-owned bookkeeping paths. A routing boundary, not an OS sandbox."""
import json
import os
from pathlib import Path
import re
import stat


class ScopeError(ValueError):
    pass


def clean_path(value):
    p = Path(value).expanduser().absolute()
    if p != p.resolve():
        raise ScopeError(f"noncanonical or linked path: {p}")
    for part in (p, *p.parents):
        if part.is_symlink():
            raise ScopeError(f"linked path: {part}")
    return p


def private_file(path):
    p = clean_path(path)
    if p.exists():
        s = p.stat()
        if not stat.S_ISREG(s.st_mode) or s.st_nlink != 1 or s.st_uid != os.getuid():
            raise ScopeError(f"untrusted bookkeeping file: {p}")
    return p


def bound_home(script_path):
    script = clean_path(script_path)
    if script.parent.name != 'scripts':
        raise ScopeError('helper must live in the team scripts directory')
    if script.parent.parent.name == 'alex-director' and script.parents[2].name == 'roles':
        home = script.parents[3]
    else:
        home = script.parents[1]
    if not home.is_dir() or home.stat().st_uid != os.getuid():
        raise ScopeError('team home is unavailable or belongs to another user')
    if (home / '.setup-in-progress').exists():
        raise ScopeError('team setup is incomplete; inspect the partial output before use')
    bp = private_file(home / 'TEAM_BINDING.json')
    try:
        binding = json.loads(bp.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise ScopeError(f'team binding unavailable: {exc}') from exc
    if binding.get('schema') != 'independent-team-binding/v1':
        raise ScopeError('unknown team binding schema')
    if binding.get('team_home') != str(home):
        raise ScopeError('binding belongs to a different home; explicit relocation is required')
    if not re.fullmatch(r'team-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', binding.get('team_id', '')):
        raise ScopeError('missing or invalid fresh team identity')
    ident = binding.get('director_identity') or {}
    if any(not isinstance(ident.get(k), str) or not ident[k].strip() for k in ('platform', 'thread_id', 'host_id')):
        raise ScopeError('first-chat Director identity is missing')
    return home, binding


def ledger_path(home, supplied):
    p = private_file(supplied)
    if p != clean_path(home) / 'DIRECTOR_STATE.md':
        raise ScopeError('ledger belongs outside this team')
    for suffix in ('.bak', '.lock'):
        private_file(str(p) + suffix)
    return p


def graph_path(home, supplied):
    p = private_file(supplied)
    if p.parent != clean_path(home) / 'mission-graphs' or p.suffix != '.md':
        raise ScopeError('graph belongs outside this team')
    private_file(str(p) + '.bak')
    return p


def log_path(home, supplied=None, name='run-log.md'):
    expected = clean_path(home) / 'system' / name
    p = private_file(supplied if supplied is not None else expected)
    if p != expected:
        raise ScopeError('bookkeeping log belongs outside this team')
    return p


def claims_path(home):
    p = clean_path(Path(home) / '.runtime' / 'controller-write-claims')
    for d in (p.parent, p):
        if d.exists() and (not d.is_dir() or d.stat().st_uid != os.getuid()):
            raise ScopeError('untrusted claims directory')
    return p


def authorization_path(home, supplied):
    p = private_file(supplied)
    if p.parent != clean_path(home) / 'mission-graphs' or p.suffix != '.json':
        raise ScopeError('authorization record belongs outside this team')
    return p


def check_mission_identity(binding, fields):
    if fields.get('TEAM_ID') != binding['team_id']:
        raise ScopeError('mission belongs to another team or has no TEAM_ID')
    if fields.get('SUPERVISING_DIRECTOR_THREAD_ID') != binding['director_identity']['thread_id']:
        raise ScopeError('mission return address is not this team Director')


def check_text_identity(binding, text):
    fields = {}
    for key in ('TEAM_ID', 'SUPERVISING_DIRECTOR_THREAD_ID'):
        hits = re.findall(r'^' + key + r':\s*([^\n]+)$', text, re.M)
        if len(hits) != 1:
            raise ScopeError(f'exactly one {key} field required')
        fields[key] = hits[0].strip()
    check_mission_identity(binding, fields)
