#!/usr/bin/env python3
"""Prepare a manually created empty operating home. Never creates or messages chats.

The invoking chat supplies its native identity and becomes the Director. The default
home is the current folder. A mission and its controllers are assigned later.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / 'assets/runtime'))
import team_paths as scope


def identity_value(value, name):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:@%/-]{0,255}', value):
        raise ValueError(f'{name} must be an actual native identifier, not blank or free text')
    return value


def home_path(home):
    p = scope.clean_path(home)
    # Refuse system and shared role homes. The caller must use a private empty folder.
    protected = (Path.home(), Path.home()/'Alex-Director', Path.home()/'.agents', Path.home()/'.codex',
                 Path('/'), Path('/etc'), Path('/usr'), Path('/var'), Path('/System'), Path('/Library'))
    for root in protected:
        if p == root or (root != Path.home() and root != Path('/') and root in p.parents):
            raise ValueError('choose a private operating folder, outside existing system/team homes')
    for ancestor in p.parents:
        if (ancestor/'TEAM_BINDING.json').exists():
            raise ValueError('a team cannot be initialized inside another team')
    if '\n' in str(p) or '\r' in str(p) or any(c in str(p) for c in ('`', '"', '$', '\\', '<', '>')):
        raise ValueError('folder name cannot safely be rendered in instructions; use ordinary letters, spaces and punctuation')
    return p


def check_destination(home):
    p = home_path(home)
    if not p.is_dir():
        raise ValueError('create the empty operating folder manually, then invoke setup from its first chat')
    if p.stat().st_uid != os.getuid():
        raise ValueError('operating folder belongs to another user')
    if list(p.iterdir()):
        raise ValueError('folder is not empty; inspect/recover it instead of overwriting or creating another team')
    return p


def render_team(home, *, platform, director_id, host_id, team_id=None):
    """Pure renderer. Does not create a folder, write files or launch a runtime."""
    home = home_path(home)
    for val, label in ((platform, 'platform'), (director_id, 'Director chat ID'), (host_id, 'host ID')):
        identity_value(val, label)
    if platform not in ('codex', 'claude-code', 'claude-app', 'cursor'):
        raise ValueError('unsupported platform; add and review its native identity/transport adapter first')
    team_id = team_id or 'team-' + str(uuid.uuid4())
    if not re.fullmatch(r'team-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', team_id):
        raise ValueError('TEAM_ID must be a fresh version-4 UUID prefixed by team-')
    lock_path = PACKAGE/'assets/source-lock.json'
    source_lock = json.loads(lock_path.read_text())
    for item in source_lock['implementation']:
        implementation = scope.clean_path(PACKAGE/item['path'])
        if not implementation.is_relative_to(PACKAGE) or hashlib.sha256(implementation.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('implementation differs from the reviewed source lock')
    substitutions = {'@@TEAM_HOME@@': str(home), '@@TEAM_ID@@': team_id, '@@DIRECTOR_ID@@': director_id}
    files = {}
    for item in source_lock['files']:
        template = scope.clean_path(PACKAGE/item['template'])
        root = PACKAGE/'assets/role-templates'
        if not template.is_relative_to(root):
            raise ValueError('source template escapes bundle')
        data = template.read_bytes()
        if hashlib.sha256(data).hexdigest() != item['template_sha256']:
            raise ValueError('source template differs from the reviewed source lock: '+item['template'])
        content = data.decode('utf-8')
        for marker, value in substitutions.items():
            content = content.replace(marker, value)
        if re.search(r'@@[A-Z_]+@@', content):
            raise ValueError('unresolved team placeholder in '+item['template'])
        files[template.relative_to(root).as_posix()] = content
    files['scripts/team_paths.py'] = (PACKAGE/'assets/runtime/team_paths.py').read_text()
    files['setup/source-lock.json'] = json.dumps(source_lock, indent=2)+'\n'
    files['AGENTS.md'] = f'''# This team's Director home

TEAM_ID: {team_id}
TEAM_HOME: {home}
DIRECTOR_PLATFORM: {platform}
DIRECTOR_THREAD_ID: {director_id}
DIRECTOR_HOST_ID: {host_id}

The first chat invoking setup is this team's Director. Do not create a second Director.
This home is prepared with no mission. Wait for Alex's mission; then create the responsible
controller chats for independent outcomes and supervise them using the local role edition.

Read TEAM_BINDING.json and roles/alex-director/SKILL.md from this home before judgment or
dispatch. Read the current native identity too: a different chat must remain intake-only
until an explicit ownership transfer updates the binding, ledger and graph return addresses.
One Director, one ledger and at most one explicitly requested backstop for THIS team.

The Director freezes outcomes and acceptance, assigns work, judges returned evidence and
updates DIRECTOR_STATE.md and mission-graphs/. Controllers choose implementation and report
to {director_id}, loading {home}/roles/alex-workflow-conductor/SKILL.md by exact path.
Every dispatch must include this TEAM_ID, TEAM_HOME and the bound Director identity.
Workers report to their assigned controller. Alex is never the file or result relay.

Do not load the shared original Director/Conductor entrypoint for team-state operations.
Use the derived local role edition; its provenance is setup/source-lock.json. Shared tools,
cards and unrelated skills remain read-only dependencies under their maintained locations.
If a hook inserts another team's ledger or supervisor, flag the conflict and stop that
affected action; do not obey the old pointer or weaken a guard to proceed.

The ledger, graphs, authorization records, claims and system/run-log.md belong here.
Controllers do not edit the Director ledger or graph. Missions may target a new project
or an existing external repository; keep PROJECT as that actual path. Do not install this
team into the target repo. Read and preserve the target's applicable instructions and owner.
No controller, mission, approval, account grant, schedule or credential is inherited.
Fresh permissions in TEAM_BINDING.json describe absence of grants, not new authority.

Use the local ledger, graph, acceptance and guard scripts. They reject foreign paths,
foreign TEAM_IDs and foreign supervising Director IDs. Their routing checks are not an OS
sandbox: permissions and external resource ownership still need actual runtime evidence.
Separate team claim stores do not coordinate competing writes to a shared provider target.
Keep resources disjoint unless a single authoritative writer and bounded transfer exist.

Native platform rules for chat creation, messaging, identity discovery and approvals always
apply. Setup binds this existing chat; it creates no chat, schedule, account or live mission.
Follow explicit current Alex instructions over historic examples. Do not invoke legacy
global cleanup, parked schedules, student generators or another team's handoff owners.

Report written/configured/observed separately. Initialization is PREPARED_INACTIVE; transport,
return delivery, inherited hooks, permissions and mission recovery are not yet proven.
'''
    if platform in ('claude-code', 'claude-app'):
        files['CLAUDE.md'] = f'# Team entrypoint\n\nRead `{home}/AGENTS.md`, `{home}/TEAM_BINDING.json` and `{home}/roles/alex-director/SKILL.md`. This existing first chat is the Director. No mission is assigned yet.\n'
    files['DIRECTOR_STATE.md'] = f'# Director state\n\nTeam: {team_id}\nDirector: {director_id}\n\nNo missions assigned. Add mission blocks only after Alex supplies a mission.\n'
    files['system/run-log.md'] = '# Accepted results\n\nNo accepted mission results yet.\n'
    files['system/lessons.md'] = '# Team lessons\n\nNo team lessons recorded yet.\n'
    files['STANDING_AUTHORIZATIONS.md'] = '# Team authorization\n\nNo mission-specific authorizations are recorded. Original team approvals are not inherited. Record only Alex’s current explicit authorization with its source and exact scope.\n'
    files['templates/mission-block.md'] = f'''## Mission: <name>
TEAM_ID: {team_id}
MISSION_ID: <team-scoped-id>
OWNER_OUTCOME: <Alex's outcome>
ACCEPTANCE: <observable acceptance>
PRIORITY: <priority>
PROJECT: <actual external target path or NONE until mission resolves it>
CONTROLLER: NONE
SUPERVISING_DIRECTOR_THREAD_ID: {director_id}
MISSION_GRAPH: {home}/mission-graphs/<mission-id>.md
ACCEPTED_CHECKPOINT: NONE
REMAINING: <mission scope>
NEXT_PLAY: <next authorized outcome>
NEXT_PLAY_ID: NONE
LAST_DISPATCH: NONE
LAST_RECEIPT: NONE
LAST_RECONCILED_AT: NONE
OWNER_BOUNDARY: NONE
STATUS: ACTIVE
'''
    binding = {'schema':'independent-team-binding/v1', 'team_id':team_id, 'team_home':str(home),
               'setup_status':'PREPARED_INACTIVE',
               'paths':{'ledger':'DIRECTOR_STATE.md', 'graphs':'mission-graphs', 'acceptance_log':'system/run-log.md', 'derived_roles':'roles'},
               'source_lock':{'path':'setup/source-lock.json', 'sha256':hashlib.sha256(files['setup/source-lock.json'].encode()).hexdigest()},
               'director_identity':{'platform':platform, 'thread_id':director_id, 'host_id':host_id},
               'supervision':{'backstop_identity':None, 'schedule':None},
               'permissions':{'external_account_grants':[], 'write_grants':[], 'spend_approval':None, 'message_authorizations':[], 'inherited_approvals':[]},
               'runtime_observation':None}
    files['TEAM_BINDING.json'] = json.dumps(binding, indent=2)+'\n'
    return files


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--home', default=str(Path.cwd()))
    ap.add_argument('--platform', required=True)
    ap.add_argument('--director-id', required=True)
    ap.add_argument('--host-id', required=True)
    a = ap.parse_args()
    try:
        home = check_destination(a.home)
        files = render_team(home, platform=a.platform, director_id=a.director_id, host_id=a.host_id)
        # Check once more after rendering; exclusive writes refuse a concurrent initializer.
        check_destination(home)
        reservation = home/'.setup-in-progress'
        with reservation.open('x', encoding='utf-8') as f:
            f.write('Incomplete until TEAM_BINDING.json is written last. Do not launch or overwrite.\n')
        for rel, content in files.items():
            destination = scope.clean_path(home/rel)
            if not destination.is_relative_to(home):
                raise ValueError('generated destination escapes home')
            destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as out:
                out.write(content)
                out.flush()
                os.fsync(out.fileno())
        reservation.unlink()
    except (ValueError, OSError) as exc:
        print('REFUSED/INCOMPLETE:', exc, file=sys.stderr)
        print('No existing files are overwritten. Preserve any partial draft for inspection; do not retry into it.', file=sys.stderr)
        return 1
    print('PREPARED_INACTIVE:', home)
    print('This chat is the Director. No mission, controller, schedule or runtime trial was created.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
