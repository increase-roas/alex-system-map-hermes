# Implemented templates and ownership

The generator renders these resources into the existing empty folder Alex selected. This authoring task has not run its setup command. `render_team()` can be checked in memory.

```text
TEAM_HOME/
  TEAM_BINDING.json                 fresh team ID + invoking Director; written last
  AGENTS.md                        local role map; first chat is Director
  CLAUDE.md                        local pointer on Claude platforms
  DIRECTOR_STATE.md                zero missions
  STANDING_AUTHORIZATIONS.md       zero imported grants
  roles/alex-director/             derived policy, references and helpers
  roles/alex-workflow-conductor/   derived controller policy
  scripts/team_paths.py            binding and bookkeeping path validation
  scripts/controller-write-guard.py team-bound derived guard
  templates/mission-block.md       example, not an active mission
  templates/mission-graph-template.md
  system/run-log.md                no accepted results
  system/lessons.md                no prior lessons
  setup/source-lock.json           provenance and hashes; not authority
```

Mission graphs, authorization JSON, work artifacts and runtime claims arise only when later assigned work needs them. Preparation creates no controller, recurring job, account grant, credential, history clone or customer record. A `.setup-in-progress` marker remains after an interrupted setup; helpers refuse that home until explicitly repaired.

## Binding and state

The authoritative schema is `independent-team-binding/v1`. TEAM_ID is a fresh version-4 UUID prefixed `team-`; TEAM_HOME is canonical and absolute. Director identity is the actual invoking platform/chat/host. Native identity must be discovered before writing; a supplied string is not independent proof of the current chat.

Setup status starts PREPARED_INACTIVE. Runtime observation, backstop and schedule remain null; permissions lists start empty. Source-lock names retained baseline-derived templates and two pinned supplemental inputs. Original paths in provenance are read-only evidence, never runtime destinations.

The `.blank` assets illustrate null-identity schemas; the generator fills identity and emits role files. Never manually copy a blank binding into a live home. The ledger initially has zero mission blocks. Later missions add TEAM_ID and SUPERVISING_DIRECTOR_THREAD_ID matching the binding, plus the fields in `templates/mission-block.md`. Protected-write fields are created for the actual assignment. No old missions, play IDs, controllers, approvals or receipts are reused.

The graph retains NODE_ID, REQUIRED, STATUS, DEPENDS_ON, CONTROLLER, ACCEPTANCE, EVIDENCE, LAST_RECEIPT, NEXT_ACTION, UPDATED_AT and OWNER_FACING. Its header adds the same team/Director identity. PROJECT names the actual target and does not choose bookkeeping paths. A fenced node also requires exactly one `## Node: <NODE_ID>` marker.

Node statuses remain READY, BLOCKED, ACTIVE, READY_FOR_OWNER, VERIFIED, FAILED and WAITING_ON_ALEX. Mission statuses remain ACTIVE, WAITING_ON_ALEX, WAITING_ON_CLIENT and MISSION_COMPLETE. Retain canceled/superseded dispositions and decision sources within the existing schema; do not label them VERIFIED.

## Implemented helper boundaries

- Ledger backup/restore/verify accepts only this team's exact ledger, rejecting foreign or linked backup/lock files. Verification checks each mission's team and Director identity.
- Graph edit and acceptance accept only markdown graphs directly beneath this home's mission-graphs directory, with matching identity headers and safe backup paths.
- Acceptance and lint use this team's system/run-log.md. An external PROJECT cannot redirect it; an explicit foreign log argument is rejected.
- The guard resolves home from its script position and binding. It rejects moved bindings, arbitrary state/root overrides, linked claim parents and foreign mission/authorization/graph paths. It uses the actual executing hostname. Old test-mode and host environment overrides are absent.
- Resource-key construction, ordered steps, bounded counts, replay behavior, immutable terminal receipts and rotation semantics remain from the pinned guard. This is a control for participating calls, not an OS sandbox or a cross-team shared-resource lock.

The acceptance helper retains graph-write followed by log-append, with attempted graph rollback on append failure. This change does not claim crash-safe transactions or implement the audit's separate idempotency proposal. Ledger updating remains a separate operation.

## One fact, one owner

| Fact | Home / owner |
|---|---|
| Maintained standards and cards | Shared maintainer; team reads reviewed edition |
| Team identity and provenance | Binding and source-lock |
| Mission outcome, next play, controller owner | This team's Director ledger |
| Dependencies, acceptance, decisions, commitments | This team's graph |
| Implementation and business facts | Actual assigned project/source of truth |
| Progress and evidence | Native controller checkpoint; Director stores pointer/judgment |
| Action history and readbacks | Actual action store plus required local claims |
| Secrets | Approved 1Password/Composio route; none included |
| Later requested schedule | Native scheduler; one scoped owner pointer |

Initial trials use disjoint inert targets. Overlapping real provider writes require one authoritative current owner and enforced scope; private guards alone do not coordinate them.
