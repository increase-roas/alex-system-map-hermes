# Setup procedure — portable implementation candidate

The code and derived role edition are included. This authoring task stops at the uninstalled candidate: no setup command, installation, live team, native trial, runtime configuration or adoption has been executed.

## 1. First chat invokes the team

Alex manually creates an empty operating folder and opens its first chat. Invoking this setup skill makes that existing chat the Director. No separate Director creation, project selection or mission is necessary. Later, a mission creates its responsible controller chats.

Read effective instructions and discover the actual current chat/platform/host through supported native context and tools. Never infer an ID from a title or reuse the original team's IDs. Record the actual native host identity in the binding. The protected-write controller host field, added later, is the actual hostname of the process running the guard; it is distinct from a native app host ID.

The generator defaults to the current working folder and requires platform, Director ID and host ID. Resolve its location from the skill itself. Equivalent invocation shape (replace placeholders from observed native context, quote arguments):

```text
python3 "<skill-directory>/scripts/prepare_team.py" --platform "<platform>" --director-id "<this-chat-id>" --host-id "<this-native-host-id>"
```

It requires an existing empty folder and refuses overwrite, missing homes, linked/noncanonical paths, system/shared locations and nesting under an existing TEAM_BINDING. It does not create the top-level folder or use a fallback location. It validates the source lock, renders scoped roles/helpers, then writes files exclusively, with the binding last. A partial preparation retains its marker and is unusable until inspected and repaired.

For repeat invocation, inspect the existing binding and resume that home. Do not rerun the initializer or produce a second identity. A different chat remains intake-only until a real transfer updates the Director identity and all mission/graph return addresses.

## 2. Read the prepared state

Read TEAM_BINDING.json, AGENTS.md and local roles/alex-director/SKILL.md. Confirm this invoking chat is the recorded Director and the ledger contains zero missions. Controllers, approvals, claims, accounts, runtime observations and schedules must be absent/empty. Examples live in templates, never as active mission rows. No credential or session history is copied.

The preparation status is PREPARED_INACTIVE: the Director is ready to receive its mission; controller delivery and runtime behavior are not yet observed. Do not require Alex to remember to remove a heartbeat or switch off anything; initialization creates none.

## 3. What the portable edition changes

Twenty-two templates derive from the preserved Director/Conductor sources and two pinned supplements (guard and graph template). assets/source-lock.json maps each input hash, output hash and adaptation. It also hashes the new generator/path resolver. Bundle preparation no longer needs access to original live files.

Original state and role pointers resolve to this home. Recovery is limited to this TEAM_ID. Every dispatch includes the exact local Conductor entrypoint. Handoff activation links stay local. Old schedule cleanup and original zip-generator references are removed. Original mission names are removed from the optional migration note. Blanket copied approvals are replaced with the current mission's authority and explicitly recorded grants.

Ledger/graph/log helpers validate team paths and identity. Acceptance and lint use the local acceptance log even for an external PROJECT. The guard uses the local binding, rejects caller-selected root/state and test-mode bypasses, and keeps the original resource-key, replay, ordered-write and rotation semantics. See templates.md for precise limits.

This edition does not silently adopt audit reliability proposals. Accepted graph/log writes are still not a single crash-safe transaction with ledger updating. Shared cards, unrelated skills, tool routes and platform capabilities remain external read-only dependencies.

## 4. Assign a mission afterward

When Alex supplies an outcome, the same Director freezes it and observable acceptance. Create a bounded graph from the local template, then a ledger block with this TEAM_ID and supervising Director ID. Do not create a fictitious setup mission.

For an existing project, resolve its actual location and owner. Read effective ancestor/root/nested instructions for the assigned paths and the minimum current README/status/checkpoint needed. Record exact allowed paths/resources, account/login if needed, current owner, applicable instruction versions and acceptance. Existing teams retain ownership; overlapping writes need a bounded transfer or one agreed executor. Do not run repo-conform, retrofit the repo, rewrite its instructions or install the whole team there merely to assign it.

For a new project, use the location and outcome in the mission. Its controller creates the project structure needed for that result. A Git repo, remote, deployment, customer or paid service is not a team initialization prerequisite.

Mission commitments stay in this team's graph/ledger. Implementation facts and artifacts stay at the actual project/source of truth. PROJECT remains the external target path; it never selects the team acceptance log.

## 5. Create controllers and operate the loop

Use the selected platform's supported native route to create fresh mission controllers. Follow its direct human creation/messaging authorization requirements; a copied standing instruction cannot override them. Record actual controller identity, host and workspace in the mission; never select another team's controller by name, fork old sessions or resume original IDs.

Every assignment carries TEAM_ID, MISSION_ID, NEXT_PLAY_ID, frozen outcome, acceptance, allowed resources, stop/resume condition, exact team-scoped Conductor path and supervising Director identity. The Director defines outcome/authority; the controller chooses execution. Observe native processing or an acknowledgment; queued is not delivered. Do not duplicate an in-progress play.

The controller returns a native checkpoint and authorized completion notification. The Director judges evidence against acceptance, updates graph/log and ledger through local helpers, then assigns ready authorized work. A blocker parks its dependent work. Missing delivery is NOT_PROVEN; Alex is never the file or result relay.

## 6. Recovery, permissions and proof

After interruption, preserve accepted evidence, unfinished commitments, current decisions/approval sources, pending result cursor, owner/generation and uncertain writes. Resume that owner where possible. Same-chat compaction does not change identity or generation. A transfer requires source-stop evidence and resolved claims before rotation; a snapshot alone is not authority. Keep canceled/superseded history without reviving it or marking it VERIFIED.

The local path checks are not host or provider restrictions. Before claiming independent runtime isolation, inspect actual loaded instructions/hooks, permissions, native transport and account scope. A hook that injects an original pointer is a conflict requiring supported isolation or authorized adaptation; the original hook is not modified here. A missing environment fact must be read directly where possible, not relayed by Alex.

Any future runtime trial follows the enclosing dependencies-and-trial document, uses inert disjoint fixtures and remains separate from live adoption. Record prepared, component-checked, runtime-observed and adopted separately. No automatic recurring job or trial follows this artifact.
