---
name: create-independent-team
description: Initialize Alex's independent Director/controller team in an existing empty operating folder. The invoking chat becomes Director; assign its mission afterward, targeting a new project or an existing external repo. Also use to inspect or resume this team's setup.
metadata:
  version: "0.2-uninstalled-candidate"
---

# Create an independent team

Alex creates the folder and opens its first chat. That chat invokes this skill and becomes the team's Director. Do not create another folder or another Director chat. No mission or target repo is needed to initialize the team. Controllers are created for the outcomes of a later mission.

This package contains the portable implementation candidate. It is uninstalled; its authoring task has not initialized a team or run the native runtime trial. A future explicit setup invocation authorizes preparation under this procedure. Reading this draft is not a setup request.

## Initialize from the first chat

1. Read applicable workspace instructions. Confirm the current folder is the empty operating home Alex selected. If TEAM_BINDING.json or existing files are present, inspect/recover rather than overwrite. No automatic alternative folder.
2. Discover this chat's actual native identity, platform and host from available native context/tools. The invoking chat is the Director. Never use an example, another team's chat ID, a title match or a fabricated identifier. If native identity cannot be read, report that precise missing capability; do not launch another chat to work around it.
3. Read [procedure.md](references/procedure.md) and [templates.md](references/templates.md). The generator verifies the bundled source-lock hashes. No access to live original source files is required to prepare the candidate.
4. Run the bundled `scripts/prepare_team.py` with Python 3.10+, using the current folder as working directory and the actual `--platform`, `--director-id`, and `--host-id`. Resolve the script relative to this skill. Quote every path and identity argument. It writes only the existing empty home and writes the binding last. It does not install global skills, create chats, schedule work or create a target project.
5. Read back this home's binding, AGENTS.md and local `roles/alex-director/SKILL.md`. Confirm this chat's identity matches and state contains zero missions, controllers, approvals, claims, accounts and jobs. Say the Director home is prepared and awaiting its mission. Do not demand the mission as a setup prerequisite.

The helper rejects nonempty or missing folders, system/shared homes, homes nested inside another registered team, linked paths and mismatched source hashes. A partial preparation remains visibly incomplete; preserve it for inspection. Do not erase it or bypass the refusal.

## Assign the mission afterward

Once Alex gives the outcome, retain this chat as Director. Read its bound local Director role; freeze outcome and observable acceptance. Create mission state from the local templates, and create responsible controller chats through the native authorized route. Every assignment carries TEAM_ID, TEAM_HOME, the exact local Conductor path and actual supervising Director identity.

The mission may create a new project or use an existing repo from the external operating home. Keep the real target in PROJECT. Read its instructions and current ownership. The ledger, graphs, approvals, guard claims and acceptance log stay in the team home. Do not install the whole team into the target repo or rewrite its rules merely to attach a mission.

Use the native platform's creation and messaging rules. Where a tool requires direct human authorization, verify the current user request provides it; a historic role instruction cannot substitute. A queued message is not observed processing. The later trial must establish delivery, return, judgment and recovery on the selected platform before claiming those behaviors proven.

## Bindings and ownership

- Shared standards: read-only capability cards and unrelated skills. Included Director/Conductor editions derive from pinned sources; refresh deliberately from reviewed versions.
- Team state: one TEAM_ID, one Director and one ledger. Recover only controllers registered in this team's missions. The Director alone edits its ledger/graphs; controllers return native evidence/checkpoints.
- Project/resources: exact paths, account/login, operation and owner named by the mission. No inherited approvals, credentials, customer records or schedules. Ongoing supervision needs an explicit request and at most one backstop for this team.

Use exact local role paths, not the globally installed original Director/Conductor by name. The bundled guard derives its home from its adjacent binding. Arbitrary root/state overrides and the old test-mode escape are refused. Ledger/graph/log helpers reject foreign paths and team/Director mismatches. Acceptance logs stay local even when PROJECT points elsewhere.

These checks prevent identified helper misrouting; they are not a filesystem or account sandbox. Effective hooks, native messaging, provider scopes and restrictions remain environment-specific. If a hook reinserts an old team pointer, preserve the valid binding and report the conflict; do not follow the old pointer or weaken protection. Separate team claim stores do not coordinate overlapping writes to the same provider object.

Preserve the working loop: recover accepted checkpoint → assign ready work → observe processing → receive evidence → judge acceptance → update graph and ledger → continue ready authorized work. Park only dependent work. Never replay uncertain effects or adopt unrelated audit improvements during setup.

## Resume and report

Re-read TEAM_BINDING.json and the native checkpoint. The same chat resumes the same team. A different chat stays intake-only until explicit transfer reconciles the binding and supervising pointers; never silently create another owner. A moved home needs deliberate reviewed rebinding, not an override or symlink.

Report preparation, component checks and observed runtime behavior separately. The enclosed trial remains proposed; no installation, new live team, runtime trial or adoption was performed while producing this package.
