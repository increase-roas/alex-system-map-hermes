# Decision brief

The current working setup has been preserved as a checked, private baseline for the reusable-setup chat. Keep the existing Director and its successful division of work. The evidence supports targeted checks at acceptance, instruction delivery and handoff; it does not justify a broad rewrite.

- **Completion claims:** a historical multi-project “done” claim exceeded the file evidence. The current rule already requires matching proof. Test scope matching and add only a narrow example if needed.
- **Intent compliance:** Javar produced a technically correct answer after bypassing the assigned tool's valid denial. The record shows both an instruction-load gap and a credential/environment gap; their separate causal contribution is uncertain. Existing Hermes work owns the correction. Do not count the answer as success or duplicate that work.
- **Remembered promises:** the Business Profile draft was missing before the interruption and stayed missing through recovery. It has since been delivered for owner review. Retain commitments in existing mission nodes and distinguish drafting from sending; do not replay the completed draft.
- **What works:** useful parallel results, scoped blockers, remembered approvals, acceptance of saved proof and automatic follow-up are documented. The runtime plan includes these as controls, not optional niceties.

The preservation check covered 427 selected sources. Both workbook copies match, and all 7,750 expected cells across 17 JSON-built tabs match the captured source inputs. The baseline includes current uncommitted content, source hashes, configuration structure, relevant mission evidence and exclusions. Two mission records changed between early reads and capture and were reconciled before publication; the accepted capture interval itself was stable.

**Written:** findings, minimal proposals and the separate runtime plan. **Checked from files:** capture consistency, workbook projection parity, instruction-source parity and artifact integrity. **Historically seen working:** the restoration's Director/controller cycle and useful parallel follow-through. **Still unproven:** reliability improvements, exact current loaded context on each host, safe interruption recovery and reusable-team runtime behavior.

No live corrections, candidate edits, behavioral trials, installs, external writes or adoption occurred. No test agent was launched; bounded read-only audit helpers assisted this investigation. Credentials and raw chats are excluded. This is a local reference baseline, not a runnable machine backup or public release.

Read BASELINE_READY.md for the manifest pin and consumption contract. The detailed outputs are 01-baseline-and-restore.md, 02-findings.md, 03-smallest-proposed-corrections.md and 04-runtime-test-plan.md. Stop here until later work is separately authorized; the setup chat can consume the published baseline directly without Alex relaying it.
