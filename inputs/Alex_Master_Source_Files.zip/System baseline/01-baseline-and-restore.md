# Preserved baseline and restore limits

Status: checked document/source baseline; no reliability candidate, behavior trial, installation or live adoption. Captured October 3, 2026, 05:34:44–05:34:46 EDT (2026-10-03T09:34:44.662994+00:00 to 2026-10-03T09:34:46.135660+00:00). Publication is complete only when BASELINE_READY.md is present with a matching manifest digest.

## What is preserved

The baseline contains 427 selected source artifacts. `baseline/manifest.json` maps every original absolute path to its preserved relative path, original SHA-256, captured SHA-256, size, modification time, mode, resolved symlink target, capture time, purpose and any transformation. Its Git metadata retains branch, commit and dirty-file status. Current uncommitted bytes are captured, not replaced with HEAD versions.

- Master workbook and its generated Documents copy, both 547,267 bytes with SHA-256 `50a1aba7404f6561e3556b3724b09ae2f117d0069902a5b62f66b514577df3eb`.
- Workbook projection generators, ordered tab JSON, corrections, direct validation corpus, Director-tab/app-decisions/card generators and their directly inspected inputs. Top-level skill files are inputs to the card index; their presence is not a whole-system skill audit.
- Six canonical instruction sources, instruction builder, generated Claude/Codex rules and style, Director 2.7 and Conductor 2.5 policy/reference/script trees and relevant mirrors.
- Four configuration files as sanitized structure, plus selected secret-screened hook files and implementations. String values are omitted unless on the explicit safe list. These structure documents are not executable replacement configurations.
- The three assigned mission graphs and ONLY their corresponding ledger blocks, relevant run-log lines from 245 onward, relevant lessons from 240 onward, project status, restoration ownership handoff, failure diagnoses and supplied restoration evidence. Extracts retain original source hashes; line-prefixed extracts preserve source locators. They are historical evidence, never replacement operating records.
- Safe session metadata: timestamps, model names and selected instruction/mission Read invocations. No message bodies, hidden reasoning, tool results or raw JSONL are preserved.

The live owners remain the existing Claude Director and its controllers. No mission status was updated by this audit. Business missions remain incomplete where their canonical records say so. A second team must create its own operating home and state before taking a mission; this baseline grants no ownership of the original team's accounts, sessions or resources.

## Consistency checks and limits

All 427 sources existed. The accepted capture and second full fingerprint pass had no changed content/metadata, and the three repositories' heads and dirty-file status stayed equal. No retry was needed inside that 1.47-second capture interval. This is bounded source consistency, not an atomic filesystem snapshot or proof that all files describe the same semantic state.

Earlier evidence discovery was not frozen: the run-log and Hermes graph changed between helper reads and capture. The evidence report was reconciled to the preserved versions. In particular the 09:34Z checkpoint draft is built and dry-run checked but remains uninstalled; Javar's maintained core skills remain reported unloaded. Javante's earlier configuration-list defect was repaired, and a later precheck misread that repaired list. These distinctions are preserved.

The master and Documents workbook bytes match. An independent, read-only value comparison of the 17 ordered JSON tab projections checked 7,750 expected cells with zero mismatches and no extra populated cells. The workbook has 36 sheets. This check did not regenerate or save it and says nothing about the formatting, every legacy tab's original creation, all derived transformations or behavior of a live agent. Relevant historical batch notes remain evidence with their original dates.

Read-only formula comparison found generated global instructions equal to their current sources and the two role mirrors equal to canonical bytes. Invocation metadata provides evidence that sessions requested role/state files; it does not prove exact returned bytes, complete loaded context or obedience. Global Claude configuration says acceptEdits; historical Director Bypass is a separate observed session setting. Global Codex selects Astra/xhigh; the observed Director metadata names Opus 5.5. Do not flatten these into a single tested configuration.

The session metadata has its own observation time before the capture interval. Active transcripts were not copied or treated as a stable part of that interval. The immutable snapshot can become historically stale immediately; later operational decisions must use current canonical records.

## Secret handling and exclusions

Credential stores and environment-file contents were never opened for capture. No raw transcript, live session database, browser profile, cookie store, app-private storage, socket, OS privacy configuration or external account export is included. Four potentially secret-bearing settings files were parsed only to preserve structure and allowlisted behavior settings. Other text and workbook XML were screened for known credential formats, private keys, bearer/assignment patterns and key-like prefixes. High-entropy review found two ordinary Google Sheet document identifiers. Two text artifacts received conservative bearer-pattern redaction; their transformed hashes differ from their original hashes and are labeled. No scanner can establish that every conceivable secret format is absent; this remains private, local material, not a public distribution bundle.

The direct capture scope does not include the full student-edition vendored tree, private repositories, installed runtimes, every skill's supporting files, legacy workbook authoring inputs, every incidental workbook citation, other teams' mission blocks or full external service state. The student build's secret/external dependencies are references only. No student publish/build hook, key lookup, workbook generator, restore command, scheduled task or live tool call was executed. The full live scheduling configuration is deliberately outside the restore scope; no enabled schedule is transferred. Role policy and historical schedule references are preserved as documentation, not active jobs.

## Later secure restore, if separately authorized

1. Verify manifest and checksums before use. Keep this baseline immutable; create a new version for later captures.
2. Choose a restore destination and reconcile affected owners/resources. Stop or transfer affected writers through supported procedures before any replacement. Preserve newer accepted work; never paste these old blocks over the current full ledger.
3. Restore selected safe source files only into the intended isolated home or a specifically approved repair scope. Re-create path bindings and role identity deliberately. Captured symlink targets identify original ownership and must not be reused as writable links by another team.
4. Re-provision authentication through the canonical 1Password and Composio routes with the intended role/account scope. The manifest has no usable secrets. Original settings paths are references for authorized secure review, not files to overwrite from the structure documents. No approval, key scope or customer-contact authority transfers with a copied role.
5. Re-establish the actual host, installed model/runtime and plugin versions, pointer upload where required, hook trust and supported session transport. Local capture does not contain an authenticated running Director. Avoid resuming an active desktop session headlessly and creating a second writer.
6. Reconcile canonical commitment states and uncertain prior side effects read-only before selecting work. Reuse valid unchanged proof and separate ready work from real gates. Restore/replication is only configured until the separately approved isolated runtime checks establish behavior.

Dependencies on Alex remain explicit: protected security/access changes, genuine spending/contact/production gates, unavailable sign-ins and any live adoption need their applicable authorization. There is no step Alex must remember to relay for this audit's publication; the setup chat can read the shared ready marker directly.

## How the setup chat consumes this

Start with BASELINE_READY.md, verify its manifest digest, then read the manifest and this guide. `baseline/dependency-map.md` explains the source graph. Use files under `baseline/files/` and the manifest transformations, not a new live read silently substituted into the preserved version. Drafts previously prepared from live source should be reconciled to this version. Prepare reuse without editing the baseline or treating unfinished work as complete. This does not authorize installation, trial agents, broader access or another live Director.
