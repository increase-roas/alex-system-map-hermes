# Tool incidents

<!-- Append only, newest at the bottom. One row per incident. tool-card and any task that
     hits a tool failure add a row here. weekly-tuneup looks for incidents that repeat. -->

Log a row when a tool errors, returns junk, picks the wrong target, costs more than expected,
or when Claude picked the wrong tool. A fix that recurs moves into the tool's card, then
into a routing row in `CLAUDE.md` (with approval), then into an app setting.

| Date | Tool (full name) | What failed | Why | Fix | Card updated? |
|---|---|---|---|---|---|
| 2026-10-01 | weekly-tuneup `tuneup.py refresh` (Composio API /api/v3/connected_accounts?limit=100) | response cut off mid-download (IncompleteRead), 3 times at 08:12 and 2 times at 16:12 | likely the sandbox network proxy dropping a ~55 KB chunked reply; not proven | none yet; candidate L-007 (smaller pages + retry) | no |
| 2026-10-02 | weekly-tuneup `tuneup.py refresh` (Composio API) | 3 more cut-offs at 00:12 (8 in 3 runs). Try 3 passed the accounts page, then was cut off on `/api/v3.1/tools?toolkit_slug=…&limit=200` (53,235 of 69,423 bytes) | any reply over ~30 KB can be cut in the scheduled sandbox, not only the accounts page; cause still not proven | none yet; L-007 widened: retry inside `api()` and catch `IncompleteRead` per toolkit (proposal 2026-10-01, 00:12 update, P3) | no |
| 2026-10-02 | weekly-tuneup `tuneup.py refresh` (Composio API /api/v3/connected_accounts?limit=100) | 3 more cut-offs at 08:12 (11 in 4 runs): 27,752, 22,492 and 37,551 of 57,669 bytes read; never got past the accounts page | same as above; cause still not proven (not retried outside the sandbox: an unattended run may not stop for approval) | none yet; waits on Alex running refresh once in his own terminal (proposal 2026-10-01, Needs Alex 3) | no |
| 2026-10-02 | weekly-tuneup `tuneup.py refresh` (Composio API) | 3 more cut-offs at 16:12 (14 in 5 runs): connected_accounts?limit=100 cut at 50,938 and 27,752 bytes; one try passed it and was cut on `/api/v3.1/tools?toolkit_slug=…&limit=200` at 42,943 bytes | same as above; cause still not proven | none yet; still waits on Alex running refresh once in his own terminal (proposal 2026-10-01, Needs Alex 3) | no |
| 2026-10-02 | weekly-tuneup `tuneup.py refresh` (Composio API) | **cause proven** ~16:50 with Alex present: the same command outside the sandbox completed first try (12 toolkits, 157 tools, 0 added, 0 removed); inside it, 5-row and 25-row pages were cut too, and retries 1 s or 8-24 s apart failed on the same URL | the scheduled session's sandbox network proxy cuts Composio replies; not the script, not page size | run that one script outside the sandbox (sandbox `excludedCommands`; proposal 2026-10-01 P5) | no (card for the tune-up script: n/a) |
| 2026-10-03 | weekly-tuneup `tuneup.py refresh` (Composio API /api/v3/connected_accounts?limit=100) | 1 cut-off inside the sandbox at 00:12 (IncompleteRead) | same proven cause: the scheduled session's sandbox network | retried once with the sandbox off in the unattended run: no prompt, complete first try (12 toolkits, 157 tools, 0 added, 0 removed). P5 would make it the default | no (n/a) |
