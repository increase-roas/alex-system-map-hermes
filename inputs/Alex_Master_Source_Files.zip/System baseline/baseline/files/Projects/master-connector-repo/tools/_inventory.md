# Tool inventory

<!-- The baseline for drift checks. tool-card updates a row after each run; weekly-tuneup
     compares the connected tools against this table. One row per tool family. -->

The first three rows are filled: exa from its Composio tool list (2026-10-01), the others from
the blueprint research (2026-09-29). Tool names and counts can differ in your app, so re-run
`tool-card` for each family and replace the date.

| Tool family | Prefix | Source | Tool count | Risky tools + tier | Setting | Last verified |
|---|---|---|---|---|---|---|
| exa | `EXA_` (Composio toolkit `exa`) | Composio | 20 (Composio v3.1 API list) | `EXA_CREATE_AGENT_RUN`, `EXA_CREATE_RESEARCH`, `EXA_CREATE_WEBSET` T1, paid | search, answer and contents run freely; paid runs follow the project's Spend approval line | 2026-10-01 (EXA_SEARCH answered through Composio) |
| firecrawl | `FIRECRAWL_` (Composio toolkit `firecrawl`, login `firecrawl_che-aday`) + CLI through `~/.agents/tools/connectors/firecrawl_op.py` | Composio + CLI | 30 (Composio v3.1 API list; `FIRECRAWL_DEEP_RESEARCH` deprecated) | `FIRECRAWL_CRAWL_DELETE` T3 (cancels a crawl); cancels T2; scrape, batch, crawl, map, search, extract, agent T1 (use credits); proxy: monitor create (recurring credits), monitor delete T3 | free plan, no pay-as-you-go: upgrades and credit purchases are spend; monitors only when Alex asked | 2026-10-01 (FIRECRAWL_SCRAPE log_FiOIg1JFbxaJ; CLI crawl 3 pages) |
| web-search | built-in | built-in | 2 (web search, web fetch) | none | on | 2026-09-29 (research; re-verify) |
| browser-and-computer | varies | browser / computer use | [run tool-card] | form submits T4; purchases prohibited by Chrome | Chrome: Manual or Auto; computer use: per-app grants | [YYYY-MM-DD] |
| [crm] | [prefix] | [source] | [count] | [like `send_message` T4, `bulk_delete_contacts` T3, `create_invoice` T5] | [settings] | [YYYY-MM-DD] |
| [drive] | [prefix] | [source] | [count] | [risky tools] | [settings] | [YYYY-MM-DD] |
| [email] | [prefix] | [source] | [count] | [like send T4] | [settings] | [YYYY-MM-DD] |

## How to read this
- Tool count: the number of tools the family exposes now. A change means drift.
- Risky tools: every T3, T4 and T5 tool by name, with its tier (see `tools/README.md`).
- Setting: what the owner set in the app for those tools (`setup/02-app-settings.md`).
- Last verified: the date of the last `tool-card` run. Over 60 days old means verify first.
