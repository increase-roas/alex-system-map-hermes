---
route: in the shared card ~/.agents/tools/cards/composio.md, which every AI reads; edit it there (this file is only a pointer)
---
