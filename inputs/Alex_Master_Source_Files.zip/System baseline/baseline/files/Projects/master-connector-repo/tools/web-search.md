---
route: in the shared card ~/.agents/tools/cards/web-search.md, which every AI reads; edit it there (this file is only a pointer)
---
