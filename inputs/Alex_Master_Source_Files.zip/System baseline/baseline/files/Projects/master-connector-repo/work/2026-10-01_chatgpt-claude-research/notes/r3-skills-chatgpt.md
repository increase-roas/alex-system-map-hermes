# R3: Skills in ChatGPT vs Codex, and whether Alex's skills reach ChatGPT

Research node r3, 2026-10-01. Read-only (conductor RESEARCH/AUDIT). Nothing was installed, changed or sent.
Routes: Composio OpenAI Docs reader (`CUSTOM_OPENAI_DOCS_SEARCH/FETCH`), Composio Exa (`EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`), and local reads: `~/.codex/config.toml` (secret lines filtered out), folder listings, `codex debug prompt-input` (this repo, CLI 0.150.1), `codex plugin list`, the skills catalog Codex injected into the latest desktop session, Codex session logs and caches.
Proof labels: **SEEN** = read back live today · **FILE** = on disk · **DOC** = official OpenAI doc · **3P** = third-party · **NOT_PROVEN**.

## 1. Verdict

1. **No. Alex's own skills don't reach ChatGPT on the web or the phone.** They live in `~/.agents/skills`, a local folder. Only Codex reads it: the CLI, plus Codex and locally run Work inside the ChatGPT desktop app. (FILE, SEEN, DOC)
2. **ChatGPT's cloud holds none of his skills.** All 5 of his "Created by me" plugins have `skills: []`. No workspace skill was found, but the Skills tab itself wasn't checked. (SEEN; NOT_PROVEN for the Skills tab)
3. **The skills were never set up in ChatGPT.** Everything was built for Codex and Claude Code on the Mac. Uploaded copies went to the Claude app; this Claude session lists `anthropic-skills:alex-workflow-conductor`, `…integration-fit-and-source-of-truth` and others. ChatGPT got no equivalent.
4. **The local set isn't optimized either.** The desktop catalog has 102 skills, and 7 of them load twice. Every description is cut to 150 characters, so the "Use when…" trigger text is lost. 65 of the 84 unique enabled skills were never opened by Codex in September or October.
5. **The fix has three parts:**
   - Put 4 cloud-safe skills into ChatGPT. Use the Skills tab if his account has one; otherwise use one skills-only plugin made with `@plugin-creator`.
   - Cut the local catalog to the 20–30 skills he actually uses, with the trigger first in each description.
   - Prove every skill loads with a canary test (section 7).

## 2. How skills work on each surface

There are three separate ways a skill can reach ChatGPT. Moving a skill from one to another carries nothing over; the Skill controls doc says these are separate paths. (DOC)

| Distribution model | Reaches | Controlled by |
|---|---|---|
| ChatGPT workspace Skill (Plugins → **Skills** tab) | Web, desktop and phone (cloud) | ChatGPT skill permissions |
| Local filesystem skill (`SKILL.md` folders) | Desktop app (Codex, and Work running locally), Codex CLI, IDE extension | Files on disk plus `~/.codex/config.toml` |
| Plugin that bundles skills | Chat and Work on web, desktop and phone; Codex in the desktop app; Codex CLI. Not the IDE extension | Plugin install state |

| Surface | Where its skills come from | How a skill gets there | How it picks one | Limits that matter | Plan |
|---|---|---|---|---|---|
| **ChatGPT web** (Chat and Work, cloud) | Workspace or personal Skills, plus skills inside installed plugins | **Skills tab:** Create with chat, Create with editor, Upload from your computer, or install a shared skill. ChatGPT scans each upload and marks it Available, Needs Review or Blocked. **Plugins:** install one, or build your own with `@plugin-creator` | It sees name and description first and loads `SKILL.md` when the request matches. `@` picks one explicitly | ChatGPT publishes no upload limits. The API limits are 50 MB per zip, 500 files and 25 MB per file. Spec: name ≤64 characters (lowercase and hyphens, must match the folder), description ≤1,024 | **Skills tab:** Business, Enterprise, Healthcare, Edu. Plus and Pro aren't listed (help center, Sept 2026). **Plugins:** directory on all plans; installing depends on plan and workspace |
| **ChatGPT phone** | Same cloud sources as web: plugins available to the account, in Chat or Work | Install on web or desktop; the phone uses what the account has | Same as web | Plugins marked "Desktop only" (local MCP apps) don't run on the phone | Same as web |
| **ChatGPT desktop, Chat** | Cloud, same as web. The docs don't say local folder skills apply here; treat as no (inference) | Same as web | Same as web | – | Same as web |
| **ChatGPT desktop, Codex or Work running locally** | Local folders: `~/.agents/skills`, repo `.agents/skills`, `/etc/codex/skills`, and the bundled `~/.codex/skills/.system`. Plus plugin skills from `~/.codex/plugins/cache/…`. The newer runtime can also list cloud ("orchestrator") skills through a `skills.list` tool (SEEN in session instructions) | Put a folder with `SKILL.md` in a scanned location, or install a plugin. Local-only plugins come from a personal marketplace, `~/.agents/plugins/marketplace.json` | A catalog of name, description and path goes into the prompt. Picked with `$name`, the Skills picker, or implicitly by description | The catalog gets at most 2% of the context window, or 8,000 characters when the window is unknown. Codex shortens descriptions first, then drops skills with a warning. `skills.max_context_tokens` is capped at 10,000 | All Codex plans. Alex's Codex traffic is on **Pro** (1,142 logged requests carry plan "pro") |
| **Codex CLI** | Same local folders, plus plugins installed with `/plugins` | Same. `$skill-installer` writes to `$CODEX_HOME/skills`, which is `~/.codex/skills` | `$name`, `/skills`, or implicit | Same | Same |
| **IDE extension** | Local folders only; plugins aren't supported | – | `$name`, `/skills` | Same | Same |

How ChatGPT decides to load a skill:
- **Progressive disclosure.** It reads metadata first, loads the full `SKILL.md` only when it picks the skill, and opens references or scripts only when needed. (DOC)
- **Implicit matching runs on `description`.** OpenAI's guide says to front-load the key use case and trigger words, so the skill still matches when the description is shortened. (DOC)
- **Explicit-only skills.** `agents/openai.yaml` with `policy.allow_implicit_invocation: false` makes a skill load only when named; `$skill` still works. (DOC)
- **Desktop vs web don't share skills.** A September 2026 hands-on guide found that skills installed in the desktop app don't appear on the web version; uploading again was needed. (3P)

**Codex mechanics, in short (DOC):**
- **Format.** A folder holds `SKILL.md` with `name` and `description`. Optional parts: `scripts/`, `references/`, `assets/`, and `agents/openai.yaml` (display name, icon, invocation policy, MCP dependencies).
- **Where it looks.** It scans `.agents/skills` from the current folder up to the repo root, then `$HOME/.agents/skills`, `/etc/codex/skills`, and the bundled system skills. It follows symlinks.
- **Same-name skills.** Two skills with the same name are not merged; both are listed.
- **Plugin skills.** They load from the plugin cache as `plugin:skill`. A new session is needed after installing.
- **Off-switch.** Add `[[skills.config]]` with `path` and `enabled = false` in `~/.codex/config.toml`, then restart.
- **Nested folders count too.** Codex also scans nested folders (SEEN: template copies inside `repo-conform/assets` are listed as skills).

## 3. What Alex has vs what's needed

| Item | What's there (evidence) | What's needed |
|---|---|---|
| Local skill home | `~/.agents/skills`: 122 skill folders, 129 `SKILL.md`. Of those, 7 are template copies in `repo-conform/assets/universal-skills/` (FILE) | Each skill loaded once |
| Codex catalog, desktop app | 102 entries in the catalog injected into desktop session `01a0f898` (app Codex 0.159.2, 2026-10-01T17:52Z): 91 from `~/.agents/skills` (84 unique + 7 duplicates), 4 system, 7 plugin skills (1Password, the Composio app, plugin-management, Sites ×4). The catalog is 21,613 characters, and **every description is cut to ≤150 characters** (SEEN) | ≤30 entries, each listed once, triggers intact |
| Codex catalog, CLI | `codex debug prompt-input` in this repo: 96 entries, the same 7 names twice, descriptions cut to ≤166 characters (SEEN) | Same |
| Off-switches | 93 `[[skills.config]]` entries; **46 point at files that don't exist**. 7 aim at the old `repo-conform/assets/skeleton/skills/…` paths, so the real copies in `assets/universal-skills/` still load. 39 aim at old plugin-cache versions (FILE) | 7 entries pointed at `assets/universal-skills/<name>/SKILL.md`; dead entries removed |
| Descriptions | Of the 91 enabled, 87 are longer than 150 characters (median 323, max 892). Only 16 of 84 start with the trigger (FILE) | Trigger first, key words in the first 150 characters |
| Use | Codex opened only **19 of 84** at least once in Sep–Oct (405 session files). Top three: alex-director (76 sessions), alex-workflow-conductor (59), meta-ads-cli (17). Claude Code adds about 6 more (SEEN) | Enable what's used |
| Spec | `stitch-extract-design-md` has `name: stitch::extract-design-md`, which breaks the name rule and doesn't match its folder. 9 skills (4 enabled, 5 disabled) have extra top-level keys (`version`, `slug`, `tools`, …). Two enabled bodies run past the 500-line guidance: talking-head-recut (1,215 lines) and wrangler (917). 35 enabled bodies are over 150 lines (FILE) | Fixed name; extra keys moved under `metadata`; long bodies split into `references/` |
| ChatGPT cloud | Remote catalog cache fetched 2026-10-01T16:33Z: 5 USER-scope private plugins (three Ref docs apps, Increase ROAS — Meta Ads, Increase ROAS — GoHighLevel), **all with `skills: []`**. Skills tab not checked (SEEN / NOT_PROVEN) | 4–5 cloud-safe skills |
| Plugin skills in Codex | Between 12:22 and 12:47 local today, `config.toml` went from 20 plugin entries to 1. Only `composio@composio` remains (installed, disabled). Superpowers, compound-engineering and documents/pdf/spreadsheets are now "not installed" (`codex plugin list`). The personal `ghl-builder` cache is empty. These included some of the most-opened skills: build-ghl-systems (37 sessions), ce-work (18), ce-plan and ce-debug (14 each), using-superpowers (15) (FILE, SEEN) | Confirm the removal was intended. The conductor and director still route to `ce-*` "if installed" |
| Personal marketplace | `~/.agents/plugins/marketplace.json` lists `ghl-builder`, and `~/plugins/ghl-builder` exists with the `build-ghl-systems` skill but is not installed. (Correction: `live-codex.md` says the folder is missing; the path resolves from home.) (FILE, SEEN) | Keep or retire. The app index now routes GHL builds through Composio `ghl-command-builder` |
| Other homes | `transcript-to-workflow-opportunity-mapper` exists only in `~/.claude/skills`, so Codex can't see it. integration-fit, plain-english-repo-explainer and first-principles-speed-analyzer have drifted twins in `~/.claude/skills` (different sizes). `$skill-installer` would create a third home in `~/.codex/skills` (FILE) | One home: `~/.agents/skills` |

## 4. What's wrong, most important first

1. **ChatGPT web and phone see nothing of Alex's.** No cloud skill and no skills plugin exists, so ChatGPT chat follows none of his procedures.
2. **Trigger text is cut in Codex.** Descriptions say what the skill does first and when to use it last, and the catalog is over budget. So the "Use when…" clause is what gets dropped. Examples from the desktop catalog:
   - verify-before-done loses "to be called done, sent to anyone, or published".
   - alex-workflow-conductor loses the end of its own name in its use-only-when-named rule.
   - integration-fit loses all of its triggers.
3. **Too many active skills.** Up to 102 sit in the catalog, while research says 2–3 per task work best (SkillsBench: one skill +18.0 pp, 2–3 skills +19.0 pp, 4 or more +10.1 pp). Skill benefits also fade when agents must choose from a large pool (Skills in the Wild).
4. **7 skills load twice, and 46 off-switches are dead.** The off-switch paths weren't updated when the templates moved from `skeleton/skills` to `universal-skills`.
5. **The plugin skill set changed today without a record in this research.** Check with the consolidation chat that dropping superpowers, compound-engineering and ghl-builder was intended.
6. **The two key procedures are tied to the repo.** verify-before-done and research-with-sources hard-code `work/<job>/`, `knowledge/`, `checks.md` and subagents, so they can't run as-is in cloud chat. research-with-sources also still names the old `mcp__Exa__agent_run` route.
7. **Too much mandatory procedure.** 14 descriptions use mandatory wording; hyperframes, for example, opens with "Mandatory entry point". SkillsBench traced its losing tasks to skills that imposed a heavyweight pipeline with no fallback. verify-before-done's own text says the same about excess verification.

## 5. The optimized set

### 5a. ChatGPT cloud (web, phone, desktop Chat and Work): 4 skills, 5 at most

| Skill | Why it belongs | Ready? | Change before uploading |
|---|---|---|---|
| verify-before-done | Used in Codex (5 sessions) and Claude (2); it's the check Alex wants everywhere | No | Make it surface-aware: "If a repo job folder exists, write `checks.md`; otherwise put the check table in the reply." Keep one source file, not a cloud fork. Trigger first |
| research-with-sources | Core research procedure | No | Same surface-aware rule. In chat, drop the subagent and fan-out step and the old Exa tool name. Trigger first |
| integration-fit-and-source-of-truth | Used in Codex and Claude; no local paths; already in the Claude app | Yes | Trigger-first description. Use the `~/.agents/skills` copy; the Claude twin has drifted |
| transcript-to-workflow-opportunity-mapper | Works from the phone: paste a transcript. Already in the Claude app | Almost | Move it into `~/.agents/skills` first; it currently lives only in `~/.claude/skills` |
| Optional: mission-intake-and-approval-gate | Already in the Claude app; no local paths | Yes | Trigger first |

**Keep out of ChatGPT cloud** (they depend on the Mac):
- **Controller skills:** alex-director and alex-workflow-conductor. They route Codex threads, use computer use, and read Director files on disk. An explicit-only cloud copy with its references bundled is possible later.
- **CLI skills:** composio-cli. On the web, the installed Composio plugin carries its own `composio` skill. Also meta-ads-cli, meta-paused-campaign-builder, and the Cloudflare and wrangler skills.
- **Repo-file and subagent skills:** repo-conform, capture-lessons, intake-triage, tool-card, weekly-tuneup and fan-out.
- **Local media and Mac apps:** export-imessage-thread and the hyperframes and video skills, which need local render tools.
- **Tone:** talk-with-alex belongs in ChatGPT Personalization, not in a skill.

### 5b. Local (Codex and the desktop app): 30 enabled at most

- **What to keep on.** The 19 skills Codex opened in Sep–Oct, the 4 cloud skills, and the few rare-but-needed ones Alex names. Switch the rest off for Codex with `[[skills.config]]`. That needs no file moves, and Claude Code is unaffected.
- **Why 30.** This is an estimate: the desktop catalog spent about 21,600 characters on 102 entries. The same budget over 30 entries leaves roughly 700 characters each, so today's descriptions (median 323) would fit whole.
- **Descriptions.** Rewrite each one as "Use when … . Does …", with the key words in the first 150 characters.
- **Off-switches.** Point the 7 template off-switches at `repo-conform/assets/universal-skills/<name>/SKILL.md` and remove the 46 dead paths.
- **Approvals and backups.** Edits to shared skills need Alex's yes (AGENTS.md rule 5). The config fix falls under his standing yes for dead config. Back up to `~/Backups` first.

### 5c. Install steps for ChatGPT

**Step 0 (one minute; Alex, or a screen read with his OK).** On chatgpt.com, signed into the account his phone uses, open **Plugins**.
- Is there a **Skills** tab? Yes → Route A. No → Route B.
- Also note which workspace he's in: "Personal" (Pro) or "Increase Roas".

**Route A: Skills tab**
1. Make one zip per skill, with the folder at the zip root (`verify-before-done.zip` → `verify-before-done/SKILL.md`). The repo's `.agents/skills/README.md` documents an `audit.py --zips` builder with this layout for the Claude app. ChatGPT's zip rules aren't published; third-party guides use the same layout.
2. Plugins → Skills → **Create** → **Upload from your computer**. Wait for the scan, then **Install**.
3. Start a new chat and run section 7.

**Route B: no Skills tab (Pro)**
1. Install **Plugin Creator** from the plugin directory if it's missing.
2. In a new chat: `@plugin-creator Create a skills-only plugin named "Increase ROAS Core" with these 4 skills and no apps`, and attach the 4 folders as a zip.
3. Review it and finish. It appears under Plugins → Personal → **Created by me**; install it if asked.
4. Start new chats on the web and on the phone, and run section 7.
5. Afterwards, the plugin also syncs into Codex on the desktop. Run `codex debug prompt-input --disable network_proxy` and check that no skill now appears twice (the plugin copy plus the `~/.agents/skills` copy). If one does, switch one copy off.

**Updates:** edit the source in `~/.agents/skills`, then re-upload (Route A) or ask `@plugin-creator` to update the plugin with the new files (Route B). Bump the canary each time.

## 6. How many to keep active

- **ChatGPT cloud:** 4–5 always installed. Narrow skills that don't overlap keep each task at 2–3 skills.
- **Codex:** 30 or fewer enabled, so no description gets cut, plus explicit-only (`allow_implicit_invocation: false`) for big, rarely used skills.
- **Skill bodies:** under 500 lines and about 5,000 tokens each, with detail in `references/`. Instructions should be conditional ("when sending or publishing…"), not run on every task.

## 7. Proof test: did a skill load?

**Canary.** Add one line at the end of each cloud `SKILL.md` body: `When you use this skill, end your reply with [skill:verify-before-done 2026-10-01]`. The line sits only in the body, not the description. Seeing it in a reply proves the full file loaded, not just the metadata.

| # | Surface | Prompt | Pass when |
|---|---|---|---|
| T1 | Web | Plugins → Skills tab (or the plugin's details); then type `@verify` in the composer | The skill is listed |
| T2 | Web | New chat: `@verify-before-done` plus a 3-line brief and draft | The canary appears (explicit load) |
| T3 | Web | New chat, no `@`: "Before I send this to the client, check it against the brief" plus text | The canary appears (implicit trigger) |
| T4 | Web | New chat: "Write a haiku about Mondays" | **No** canary (no false trigger) |
| T5 | Phone (iOS) | Repeat T3; if `@` is available, T2 too | The canary appears |
| T6 | Codex, desktop app or CLI | `codex debug prompt-input --disable network_proxy`, then `$verify-before-done` in a session | Listed **once**, the catalog text still contains "Use when", and the canary appears |

Extra evidence:
- In Codex, the session log (`~/.codex/sessions/…jsonl`) records the `SKILL.md` read.
- Newer desktop runtimes announce the first use of a skill in the commentary.
- On a Business workspace, the admin Skills page shows Invocations (30d) per skill.

For a stricter trigger check, agentskills.io suggests about 20 prompts, half that should trigger and half that shouldn't.

Record each result as date | surface | prompt | canary Y/N in the job's `checks.md`.

## 8. NOT_PROVEN and what settles it

| Item | What settles it |
|---|---|
| Whether his ChatGPT account(s) show a Skills tab, and whether "Increase Roas" is a Business workspace | Step 0 above |
| Which account or workspace his phone uses | The profile menu on the phone |
| Plugin Creator on his Pro account | Type `@plugin-creator` in a web chat |
| Whether removing superpowers, compound-engineering and ghl-builder was intended | Ask the consolidation chat; backup at `~/.codex/config.toml.bak-before-after-20261001` |
| Today's desktop Skills-page count. 134 was seen 16:00–16:25Z, before the config rewrite | Desktop → Skills (host Local) |
| Phone or web steering a Mac-run Work task with local skills ("Local computer access with Work Cloud") | DOC for workspaces. Needs desktop app 26.929+; his app is 26.928.31416. Not tested |

## 9. Sources

Fetched 2026-10-01 unless a date is given.

**OpenAI documentation and announcements**
- Build skills (surfaces, progressive disclosure, Codex catalog budget, locations, `[[skills.config]]`, `openai.yaml`): https://learn.chatgpt.com/docs/build-skills. Key line: "Standalone skills are available in the ChatGPT desktop app, Codex CLI, and IDE extension."
- Skills & Plugins overview (`@` in ChatGPT, `$` in Codex): https://learn.chatgpt.com/docs/skills-and-plugins
- Skill controls (the three distribution models are separate): https://learn.chatgpt.com/docs/enterprise/skills
- Plugins (web, desktop and phone; Desktop only; new chat after install): https://learn.chatgpt.com/docs/plugins
- Customization (progressive disclosure, global vs repo skills): https://learn.chatgpt.com/docs/customization/overview
- Config reference (`skills.max_context_tokens` ≤10,000; `skills.config`): https://learn.chatgpt.com/docs/config-file/config-reference
- Best practices (one job per skill, trigger phrases in the description, personal skills in `$HOME/.agents/skills`): https://learn.chatgpt.com/guides/best-practices
- Build plugins in ChatGPT (Plugin Creator, `@` menu shows plugins and skills): https://learn.chatgpt.com/docs/build-plugins
- Projects (sync and local access): https://learn.chatgpt.com/docs/projects
- Local computer access for Work Cloud: https://learn.chatgpt.com/docs/enterprise/cloud-local-access
- Record & Replay (makes a skill from a demonstration): https://learn.chatgpt.com/docs/extend/record-and-replay
- Changelog, "Agent skills in Codex", 2025-12-19: https://learn.chatgpt.com/docs/changelog#month-2025-12
- Skills in ChatGPT, help center (Skills tab, upload scan, admin permissions): https://help.openai.com/en/articles/20001066-skills-in-chatgpt
- Plugins in ChatGPT and Codex, help center, updated about 2026-09-29: https://help.openai.com/en/articles/20001256. Key line: "Personal Skills are generally available to ChatGPT Business, Enterprise, Healthcare, and Edu users."
- Skills concept and building skills for plugins: https://developers.openai.com/plugins/concepts/skills and https://developers.openai.com/plugins/build/skills
- Package your plugin (personal marketplace, plugin-creator): https://developers.openai.com/plugins/build/plugins
- API skills limits (50 MB zip, 500 files, 25 MB per file): https://developers.openai.com/api/docs/guides/tools-skills
- OpenAI Academy, "Using skills", 2026-04-10: https://openai.com/academy/skills/
- OpenAI for Business, skills beta for Business, Enterprise, Edu, Teachers and Healthcare, 2026-03-06: https://www.linkedin.com/posts/openai-for-business_today-were-introducing-skills-in-beta-for-activity-7435743335107084288-yHR9

**Agent Skills standard**
- Specification (name ≤64 characters and must match the folder; description ≤1,024): https://agentskills.io/specification
- Best practices (under 500 lines and 5,000 tokens; defaults, not menus; gotchas): https://agentskills.io/skill-creation/best-practices
- Optimizing descriptions (imperative "Use this skill when…", about 20 trigger evals): https://agentskills.io/skill-creation/optimizing-descriptions

**Research**
- SkillsBench, Feb 2026: https://arxiv.org/abs/2602.12670. Findings: 2–3 skills per task are best; comprehensive skills gave +0.7 pp; self-written skills scored −11.3 pp on Codex with GPT-5.5.
- How Well Do Agentic Skills Work in the Wild, Apr 2026: https://arxiv.org/html/2604.04323. Finding: gains fade as the skill pool grows.

**Third-party**
- Nathan Onn, 2026-09-03 (3P): https://www.nathanonn.com/install-skills-chatgpt-work-web/. Desktop-installed skills don't appear on the web; web upload path.
- Feature request "Bring native ChatGPT Skills to Plus and Pro", date not shown (3P): https://community.openai.com/t/bring-native-chatgpt-skills-to-plus-and-pro/1401449

**Local evidence (paths)**
- Config: `~/.codex/config.toml` (current, plus `.bak-before-after-20261001`).
- Desktop session catalog: `~/.codex/sessions/2026/10/01/rollout-2026-10-01T13-52-41-01a0f898-….jsonl`.
- ChatGPT account plugins: `~/.codex/cache/remote_plugin_catalog/804718aa734b7671.json`.
- Plan header: `~/.codex/logs_2.sqlite` (`x-codex-plan-type`).
- Earlier live-state notes: `work/2026-10-01_setup-playbook/notes/live-chatgpt.md` and `live-codex.md`.
