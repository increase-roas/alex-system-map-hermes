# R5 + R6: vocabulary, one source of truth, drift, and what to restore in Codex

Node `vocab-and-drift`, play `spp-p7b` (mission-setup-playbook-parity). Mode: RESEARCH/AUDIT, read-only; nothing was changed in any config, skill or workbook. Written 2026-10-01.
Routes: Exa through the Composio CLI only (`EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`, `EXA_ANSWER`; 92 calls: four read-only research helpers plus one test, under a cent to a few cents each, no agent/research/Websets runs); no Ref, no web fetch. Local reads: Codex rollouts (names and timestamps only), `config.toml` and its three backups (names only, parsed with `tomllib`), a copy of `~/.codex/logs_2.sqlite` (targets and counts only), skills, cards, automations, the workbook notes. No `.env` file or pipe was opened; no key was printed.
Quotes: one verbatim quote in this file (the MCP tool definition, section 1f); everything else is paraphrased with the page and section named.
Times: Z = UTC. The config edits ran 12:22–12:47 local = 16:22–16:47Z.

## 0. Answers

1. **R5, Alex's sentence "tools are what the connector can do": QUALIFIED.** Right for connectors: a tool is one action the AI can call, and a connector's tools are its actions. But connectors also offer data and prompts, and many tools need no connector (built-ins). The deeper problem today was vocabulary: the connector rule ("exactly two connectors") was applied to Codex built-ins and skill packs, which are a different kind of thing (section 1g).
2. **R6, the three proposed steps.** (1) One expected-state list: **SUPPORTED**, as one list in total with a reason and a "depends on" column per row. (2) Remove only marked duplicates, backup first: **SUPPORTED with qualifiers**: add a dependency check, disable before delete, keep the backup outside the change, re-check after a delay. (3) A daily drift check: **QUALIFIED**: check right after every change and at the existing 8-hour tune-up; alert only, never auto-fix or auto-delete.
3. **How other people do it.** Three layers: a catalog (where plugins may come from), a declared on-list per app, and an optional lock. Composio already does this for connectors and 1Password for keys. For Alex: one list file in `~/.agents`, compared by the existing `check.py`, reported by the existing tune-up (section 5).
4. **R6b, restore list.** RESTORE 7 plugins: superpowers, compound-engineering (trimmed to the 6 skills the role skills name), Messages (send tool off), and the browser/computer set (unified-computer-use, browser, chrome, computer-use). LEAVE OFF 11 plugins, the 4 `codex_app` approve lines and all 5 MCP servers (Orgo moves to its proven CLI route). Each call is based on what depends on the item (section 6).
5. **Already broken today:** two ACTIVE Codex automations lost a tool. `track-payzer-support-reply` lost Messages at 18:02:51Z; `dynamite-internal-event-freshness` lost the ChatGPT Jobber app at 16:17:04Z (cause NOT_PROVEN).

## 1. R5 glossary: the words as the vendors use them today

Read 2026-10-01 through Exa (Composio CLI), 20 calls; cached page text in the session scratchpad `r5/` (not in the repo). Most vendor pages carry no date; the MCP spec is version 2026-07-28, the current one. Definitions are paraphrased; the "Where" column names the page section.

### 1a. The MCP spec (the shared base)

| Term | Plain definition | Who uses the word | Example in Alex's setup | Where (URL, date) |
|---|---|---|---|---|
| host | The AI app the person uses. It opens the connections, runs one client per server and asks for consent | MCP spec | Claude Code, Claude Desktop, Codex inside the ChatGPT app | Architecture: Host. modelcontextprotocol.io/specification/2026-07-28/architecture (spec 2026-07-28) |
| client | The link inside the host to exactly one server. The spec's overview calls clients "connectors", the opposite of vendor usage | MCP spec | Codex's link to `1password-mcp` | Overview list. modelcontextprotocol.io/specification/2026-07-28 |
| server | A program or online service that offers tools, resources and prompts; local or remote | MCP spec | `1password-mcp` (local), Composio's hosted MCP, `orgo-mcp-server`, the Codex app's `cua_repl` | Architecture: Servers (same page) |
| tool | A named action a server offers, which the model itself decides to call (model-controlled); it has a name and an input schema | MCP spec | `COMPOSIO_SEARCH_TOOLS`, `orgo_execute_bash`, `read_messages`, `send_message_to_thread` | Server features overview and control table. modelcontextprotocol.io/specification/2026-07-28/server |
| resource | Data the app chooses to attach as context (application-controlled), such as file contents | MCP spec | 1Password MCP resources (Codex read them twice in Sept) | Control table (same page) |
| prompt | A ready-made template the user picks on purpose, such as a slash command (user-controlled) | MCP spec | none in use found | Control table (same page) |
| extension | An optional add-on both sides must support: Tasks, Skills over MCP, MCP Apps (screens inside the chat) | MCP spec | none in use | Overview: Extensions (spec 2026-07-28) |

### 1b. OpenAI (ChatGPT and Codex)

| Term | Plain definition | Who uses the word | Example in Alex's setup | Where (URL, date) |
|---|---|---|---|---|
| app (ChatGPT) | A link from ChatGPT to an outside service, built on MCP. Called "connector" until 2025-12-18 | ChatGPT, Codex | The ChatGPT Composio app `asdk_app_6a585035…`; the old Google Drive entry `connector_5f3c…` in Codex `[apps]` | help.openai.com/en/articles/11487775 (FAQ, undated); release notes entry 2025-12-18 (help.openai.com/en/articles/6825453) |
| connector (OpenAI developer docs) | The part of a plugin that links to a service; it runs on an MCP server and exposes tools. Same thing the Help Center calls an app | OpenAI developer docs | The app inside the Composio plugin v1.0.1 | developers.openai.com/codex/plugins (undated) |
| plugin (ChatGPT and Codex, 2026) | An installable bundle for a workflow: skills, apps/connectors, MCP servers, hooks, browser extensions, task templates. One Plugin Directory for ChatGPT and Codex since July 2026 | ChatGPT, Codex | Composio plugin v1.0.1 (app + skill); superpowers (skills only); messages (one MCP server); browser (skills, docs, hooks) | developers.openai.com/codex/plugins; release notes entry 2026-07-14 |
| plugin (ChatGPT 2023, retired) | The old beta add-ons, deprecated; unrelated to today's plugins | ChatGPT (2023–2024) | none | release notes entry 2023-03-23 |
| Apps SDK | OpenAI's kit for building an app's MCP server and in-chat screens; finished apps are published as plugins | ChatGPT developers | Alex's private "created by me" apps (Increase ROAS — Meta Ads, GoHighLevel) | developers.openai.com/apps-sdk (undated) |
| MCP server (Codex) | A tool source added as `[mcp_servers.<name>]` in `~/.codex/config.toml`, by `codex mcp add`, or by a plugin | Codex | Now `1password` and `node_repl`; `orgo` and 4 others removed today | developers.openai.com/codex/mcp (undated) |
| marketplace (Codex) | The catalog a plugin installs from | Codex | `openai-bundled`, `openai-primary-runtime` (kept); `compound-engineering-plugin` (removed today) | developers.openai.com/codex/plugins |
| skill (Codex) | A folder with SKILL.md (plus scripts and references) that teaches one repeatable job. Codex loads only name, description and path until it picks the skill; it reads `.agents/skills`, `~/.agents/skills`, `/etc/codex/skills` and its bundled skills | Codex, ChatGPT | `alex-workflow-conductor` in `~/.agents/skills`; plugin skills such as `superpowers:systematic-debugging` | developers.openai.com/codex/skills (undated) |
| built-in tool | An ability OpenAI runs or that ships inside Codex, not from a plugin or MCP server: web search, image generation, code interpreter; in Codex its own web search, shell, patching | OpenAI API, Codex | Codex `web_search = "live"`; `exec` (23,835 calls Sept–Oct), `apply_patch` | developers.openai.com/api/docs/guides/tools; developers.openai.com/codex/web-search (undated) |
| approval mode (Codex) | A per-app or per-tool setting for whether a call needs a person's OK: `auto` (default; asks for risky or unlabeled tools), `prompt`, `writes`, `approve` (never asks) | Codex | Composio app `default_tools_approval_mode = "approve"`; the 4 removed `codex_app` lines. Under Alex's `approval_policy = "never"` + full access every call is approved anyway | developers.openai.com/codex/config-reference; section 4b |
| feature switch (Codex `[features]`) | An on/off switch for a built-in ability, such as computer use, browser use or the in-app browser; admins can pin it | Codex | `computer_use = true` is still on while the browser/computer runtime `cua_repl` is disabled | developers.openai.com/codex/enterprise/managed-configuration |

### 1c. Anthropic (Claude app, Claude Desktop, Claude Code, API)

| Term | Plain definition | Who uses the word | Example in Alex's setup | Where (URL, date) |
|---|---|---|---|---|
| connector (Claude app) | A link from Claude to an outside service; a custom connector is the web address of a remote MCP server, reached from Anthropic's cloud | Claude app (web, Desktop, mobile, Cowork) | The claude.ai Composio connector (kept as fallback) | support.claude.com/en/articles/11175166 (undated) |
| plugin (Claude app, Cowork) | A package for a role or team: skills, connectors, sub-agents, commands, hooks; saved to the Claude account and synced to Claude Code; hooks and sub-agents don't run in chat | Claude app, Cowork, Desktop | The 15 claude.ai plugins found by R4 | support.claude.com/en/articles/13837440 (undated) |
| plugin (Claude Code) | A folder with `.claude-plugin/plugin.json` that adds skills, sub-agents, hooks, MCP and LSP servers, monitors and default settings; skills run as `/plugin:skill` | Claude Code | `composio@composio` 0.2.4, the only entry in `~/.claude/settings.json` `enabledPlugins` | code.claude.com/docs/en/plugins (undated) |
| desktop extension (.mcpb, was .dxt) | A one-click file that installs a local MCP server into Claude Desktop (Settings > Extensions); renamed from .dxt on 2025-09-11 | Claude Desktop | none installed | anthropic.com/engineering/desktop-extensions (2025-06-26, updated 2025-09-11) |
| MCP server (Claude Code) | Claude Code's word for a tool source: servers by scope (local, project, user), plus plugin servers and claude.ai connectors | Claude Code | user-scope `playwright` in `~/.claude.json` | code.claude.com/docs/en/mcp (undated) |
| tool / client tool (Claude API) | Something Claude asks to run in your own app, including Anthropic-defined ones such as bash, text editor and computer use | Claude API, Claude Code | Claude Code's Bash, Read, Edit | platform.claude.com/docs/en/agents-and-tools/tool-use/overview (undated) |
| server tool (Claude API) | A tool Anthropic runs for you: web search, web fetch, code execution, tool search | Claude API | Claude's web search | same page |
| skill (Agent Skills) | A SKILL.md folder Claude loads in stages (progressive disclosure); open standard shared with Codex. Claude Code reads `~/.claude/skills` and project `.claude/skills`; Cowork uses the account's skills | Claude app, Claude Code, API | `~/.claude/skills/*` links into `~/.agents/skills` | platform.claude.com/docs/en/agents-and-tools/agent-skills/overview; code.claude.com/docs/en/skills (undated) |

### 1d. Composio

| Term | Plain definition | Who uses the word | Example in Alex's setup | Where (URL, date) |
|---|---|---|---|---|
| toolkit | Composio's set of actions for one service (old docs: "app") | Composio | `exa`, `metaads`, `googleads`, `custom_ir_notes` | docs.composio.dev/docs/glossary (undated) |
| tool | One action in one service, with a slug (old docs: "action"); plus meta tools that belong to no app | Composio | `EXA_SEARCH`, `CUSTOM_IR_NOTES_GET_APP_RULES`; meta tools `COMPOSIO_SEARCH_TOOLS`, `COMPOSIO_MULTI_EXECUTE_TOOL` | same page |
| auth config | The sign-in recipe for a toolkit: method (OAuth2, API key, bearer, basic), scopes, app credentials (old docs: "integration") | Composio | Meta Ads uses an API-key auth config (system-user token), not OAuth | same page |
| connected account | One user's signed-in link to a toolkit, IDs start with `ca_` (old docs: "connection") | Composio | the `exa` login `exa_beode-vain` | docs.composio.dev/reference/v3/api-reference/connected-accounts (undated) |
| session (formerly tool router) | A per-user setup tying toolkits, auth configs and accounts together, exposing meta tools and one MCP URL | Composio | what the ChatGPT Composio app and the claude.ai connector expose (9 meta tools in Codex) | docs.composio.dev/docs/how-composio-works (undated) |
| MCP server (Composio, legacy) | The older one-server-per-toolkit setup with a fixed tool list, being replaced by sessions | Composio | none | docs.composio.dev/docs/migration-guide/mcp-servers-to-sessions (June 2026) |

### 1e. Same word, different meaning

- **plugin:** four things. OpenAI's 2026 plugin (shared by ChatGPT and Codex), the retired 2023 ChatGPT plugin, the Claude Code plugin, and the Claude app/Cowork plugin (same family as Claude Code's, synced to it). Both vendors use a file called `plugin.json` in different folders; one plugin does not install on both.
- **app vs connector:** ChatGPT said "connector" until 2025-12-18, then "app", and since July 2026 apps ship inside plugins; OpenAI's developer docs still say "connector". Anthropic says "connector" for remote MCP in the Claude app, "desktop extension" for local MCP in Claude Desktop, "MCP server" in Claude Code. The MCP spec uses "connector" for the client inside the host.
- **tool:** MCP: one function a server offers. Composio: one action slug, plus meta tools. OpenAI API: anything in the `tools` list (built-ins, your functions, remote MCP). Claude API: client tools you run vs server tools Anthropic runs.
- **skill:** one format everywhere (SKILL.md, the open Agent Skills standard); each app reads different folders.

### 1f. Alex's sentence "tools are what the connector can do": QUALIFIED

The MCP spec defines tools as "Executable functions that allow models to perform actions or retrieve information" (Server features overview, spec 2026-07-28) and marks them model-controlled. So the core is right: a connector's tools are the actions it lets the AI take. Four qualifiers:
1. A connector can also offer resources (data) and prompts (templates), which are not tools.
2. Many tools belong to no connector: built-ins such as web search, the shell, Claude's server tools, and Composio's meta tools.
3. Strictly, the spec calls the client "connector"; vendors use the word for the server-side integration. Alex's sentence follows vendor usage.
4. A listed tool can still be blocked by the account's permissions or the app's approval settings.

Plain wording for the workbook: *A tool is one action an AI can call. A connector's tools are what that connector lets the AI do; the AI app also has built-in tools that need no connector.*

### 1g. What this means for Alex's "one home" logic

| Kind | What it is | One home | Why it can't be the same home |
|---|---|---|---|
| Connector | A route to an outside service | Composio (toolkits, auth configs, connected accounts), reached in each app through its Composio plugin, app or connector | – |
| Key | A secret a route needs | 1Password (service account for scripts) | – |
| Skill | A written procedure | `~/.agents/skills` (Codex reads it; Claude links it); vendor skill packs come from each app's own marketplace | Skills are files the AI reads, not routes |
| Built-in or app plugin | Something the AI app does on this Mac or inside itself: browser, computer use, Messages, thread tools | Each app's expected-state list (section 5) | Composio can't drive the Mac or the app's own threads; these exist only inside each app |

Today's cleanup applied the connector rule ("exactly two connectors: 1Password and Composio") to the fourth kind. App decisions R11 listed 16 Codex built-ins under "no working Composio route … then remove the rest", while All connections R51–R66 said "stays local". The vocabulary gap is the root of that contradiction.

## 2. R6 evidence: one source of truth and drift

26 Exa calls (13 searches, 13 page reads), read 2026-10-01; page text cached in the session scratchpad `r6/` (not in the repo). Verdict column: how the row bears on the three proposed steps. **S1** one expected-state list per AI app; **S2** cleanups remove only what the list marks as a duplicate, backup first; **S3** a daily drift check.

| # | Claim (paraphrased) | Number | Source | Date | Verdict |
|---|---|---|---|---|---|
| E1 | Google SRE: most outages come from changes to a live system; the fixes are progressive rollouts, fast and accurate detection, and safe rollback, done by automation | about 70% | sre.google/sre-book/introduction | SRE book 2016 (page undated) | SUPPORTS S2, S3; QUALIFIES S2 (a backup is not a rollback plus detection) |
| E2 | DORA 2024 clusters: change fail rate | Elite 5%, High 20%, Medium 10%, Low 40% | dora.dev 2024 Accelerate State of DevOps report (performance levels table) | Oct 2024 | SUPPORTS S3 (changes fail often) |
| E3 | DORA 2024: failed-deployment recovery; elite vs low | elite under 1 hour, low 1 week to 1 month; 2,293x faster recovery, 8x lower fail rate | same report | Oct 2024 | SUPPORTS S2 (a fast way back) |
| E4 | DORA 2025 (no clusters): change fail rate spread across about 5,000 respondents | 16.6% under 4%; 65.1% between 4% and 32%; 18.4% above 32% | services.google.com 2025 State of AI-assisted Software Development (fig. 14) | 2025 | SUPPORTS S3 |
| E5 | DORA 2025: recovery time | 21.3% under 1 hour; 56.5% within a day | same (fig. 13) | 2025 | SUPPORTS S2 |
| E6 | DORA: keep infrastructure and app configuration in version control so current and past state can be looked up | – | dora.dev/capabilities/version-control | undated | SUPPORTS S1 |
| E7 | Uptime Institute 2025: share of operators with a human-error outage in 3 years, and the share of those caused by procedures not followed or flawed | about 40%; 85% | uptimeinstitute.com press release, annual outage analysis 2025 | 2025-05-06 | SUPPORTS S2 (a written rule that is followed) |
| E8 | Uptime 2025: operators who say better management or processes would have prevented their latest outage | 80% (n=97) | Uptime annual outage analysis 2025 PDF | 2025 | SUPPORTS S1, S2 |
| E9 | Firefly 2026 survey (vendor): drift tied to multiple costly incidents; out-of-band production changes several times a week; no drift process | 35%; 48%; 1 in 5 | firefly.ai blog, 2026 research | 2026-08-31 | SUPPORTS S3 |
| E10 | Firefly 2025 (vendor): teams that monitor drift continuously | under one third | firefly.ai/state-of-iac-2025 | 2025 | SUPPORTS S3 |
| E11 | CrowdStrike, July 2024: a content configuration update; reverted in 78 minutes; 8.5 million Windows devices hit; about 99% of sensors back only after 10 days | 78 min; 8.5M; 10 days | crowdstrike.com preliminary PIR and RCA; blogs.microsoft.com | 2024-07-20 to Aug 2024 | QUALIFIES S2 (a fast revert is not a fast recovery) |
| E12 | Google Cloud, 12 June 2025: a policy row with blank fields replicated worldwide in seconds; the failing path was never exercised in rollout and had no flag | about 7.5 hours | status.cloud.google.com incident ow5i3PPK96RduMcb1SsW | 2025-06-13 | SUPPORTS S1 (validate the declared data); QUALIFIES S3 (check before applying, not only after) |
| E13 | Cloudflare, 18 Nov 2025: a database permissions change doubled a feature file past its limit; fixed by pushing the earlier known-good file | about 3 h 10 min (core) | blog.cloudflare.com/18-november-2025-outage | 2025-11-18 | SUPPORTS S2 (keep a known-good copy) |
| E14 | Azure Front Door, 29 Oct 2025: a bad config passed staged checks because the crash came about 5 minutes later; the last-known-good snapshot had already absorbed it. A 9 Oct incident bypassed protection during a manual cleanup | about 8 h 24 min | azure.status.microsoft, tracking YKYN-BWZ | 2025-10-29 | QUALIFIES S2 (the backup must predate the change; wait before calling a replacement proven) |
| E15 | AWS us-east-1, Oct 2025: an automated cleanup deleted the active DNS plan after a stale freshness check | about 14.5 hours end to end | aws.amazon.com/message/101925 | Oct 2025 | SUPPORTS S2 (cleanup on a stale view is the danger) |
| E16 | Replit, July 2025: an agent deleted production records; a backup gave a one-click restore | 1,206 + 1,196 records | thestack.technology report | 2025-07-21 | SUPPORTS S2 |
| E17 | DataTalks.Club, Feb 2026: Claude Code with Terraform, working from a state file left on an old laptop, ran a duplicate cleanup and `terraform destroy`, which also deleted the snapshots | 2.5 years of data; about 24 h to restore | alexeyondata.substack.com | 2026-03-06 | SUPPORTS S2 strongly; QUALIFIES (backups outside the blast radius) |
| E18 | OpenGitOps v1.0.0 principles: declarative, versioned and immutable, pulled automatically, continuously reconciled | 4 | opengitops.dev | undated | SUPPORTS S1; QUALIFIES S3 (continuous, not daily) |
| E19 | Kubernetes controllers loop forever, moving actual state toward the declared spec | continuous | kubernetes.io/docs/concepts/architecture/controller | undated | QUALIFIES S3 |
| E20 | Argo CD polls Git about every 3 minutes; auto-sync, self-heal and pruning are opt-in; pruning is off by default | 3 min | argo-cd.readthedocs.io (FAQ, auto-sync) | undated | SUPPORTS S2 (deleting is opt-in) |
| E21 | Flux reconciles on an interval (minimum 60 s); it prunes only objects it applied itself | ≥60 s | fluxcd.io kustomizations docs | undated | SUPPORTS S2 |
| E22 | HCP Terraform health checks: alert only (warning and notification; a person decides); about every 24 hours per the tutorial (an older doc said 4 hours) | ~24 h | developer.hashicorp.com/terraform/tutorials/cloud/drift-detection | undated | SUPPORTS S3 (daily alert-only is a mainstream default) |
| E23 | Pulumi Cloud drift detection runs on a cron schedule (examples daily); auto-fix is an optional toggle | daily (examples) | pulumi.com/docs/pulumi-cloud/deployments/drift | 2026-05-12 | SUPPORTS S3 |
| E24 | PowerShell DSC checks every 15 min and by default only logs; Puppet re-applies every 30 min | 15 / 30 min | learn.microsoft.com DSC metaconfig; help.puppet.com | undated | QUALIFIES S3 |
| E25 | Ansible check mode reports what would change without changing it; chezmoi `verify` exits 0 on match, 1 on drift | – | docs.ansible.com check mode; chezmoi.io verify | undated | SUPPORTS S3 (a pass/fail check fits a schedule; same shape as `check.py`) |
| E26 | Claude Code managed settings: one managed source, highest precedence, can't be overridden; `allowedMcpServers` / `deniedMcpServers` (deny wins) | – | code.claude.com/docs/en/settings | live docs | SUPPORTS S1 (vendors ship one enforced list) |
| E27 | Codex `requirements.toml` (admin): its MCP allowlist disables, does not delete, any server not listed | – | developers.openai.com/codex/config-reference | live docs | SUPPORTS S1, S2 (disable before delete) |
| E28 | Agent instruction files grow 226% over their life (247,694 instructions in 1,867 repos); when each entry's reason was recorded, 99.3% of the excess could be removed (lab setting) | +226%; 99.3% | arxiv.org/abs/2608.11095 | 2026-08-11 | QUALIFIES S1 (each row needs its reason) |
| E29 | AI agent config files are set and forget | 73.8% never changed after the first commit (441 repos) | arxiv.org/abs/2608.25241 | 2026-08-26 | SUPPORTS S3 |

### Local evidence from today (SEEN on this Mac, 2026-10-01)

| # | Claim | Number | Source | Date | Bears on |
|---|---|---|---|---|---|
| L1 | Two tabs of the same workbook disagreed about the same 16 Codex items: All connections R51–R66 "stays local", App decisions R11 "no working Composio route … remove the rest". The cleanup followed R11 | 16 items, 2 lists | notes/expected-state.csv (rows 51–66); replication-gap-export/08-app-decisions.txt (R11, R12) | 2026-10-01 | Step 1: one list, not two |
| L2 | Removing the Messages plugin entry broke an ACTIVE automation | edit 16:22–16:47Z; Messages calls OK at 16:3x, 17:0x, 17:3x; "is not a function" at 18:02:51Z; automation `track-payzer-support-reply`, every 30 min | Codex rollout of thread 01a0ca9d (names and timestamps only) | 2026-10-01 | Steps 2 and 3 |
| L3 | A ChatGPT-side app removal broke another ACTIVE automation's Jobber reads | last good Jobber call 15:32:27Z; tool missing 16:17:04Z; `dynamite-internal-event-freshness`, every 15 min | Codex rollout of thread 01a0f57b | 2026-10-01 | Steps 2 and 3 (cause NOT_PROVEN) |
| L4 | Dead entries go unnoticed without a check: Codex's `computer-use` MCP failed at every start | 21 startup failures, 189 times left out of the tool list, Sept 30–Oct 1 | `~/.codex/logs_2.sqlite` (copy), targets `codex_mcp::*` | 2026-09-30 to 10-01 | Step 3 |
| L5 | Skill off-switches pointing at missing files | 32 (live-codex.md) to 46 (R3) of 93 | notes/live-codex.md §7; chatgpt-claude-research/notes/r3-skills-chatgpt.md §3 | 2026-10-01 | Step 3 |
| L6 | A keep-list already exists for skills and names the plugin skills the role skills need | 23 names, incl. 6 superpowers + 6 compound-engineering skills | `~/.agents/tools/skill-hygiene/policy.txt` | 2026-10-01 | Step 1 (reuse it) and step 2 (it should have blocked the removal) |
| L7 | The parts for a check already run: `check.py` (read-only, exit 1 on problems), the tune-up every 8 hours, `~/.agents` in git with a post-commit hook | 5 checks today | `~/.agents/tools/unify/check.py`; weekly-tuneup skill (step 7, "Tool drift"); `~/.agents/tools/unify/hooks/post-commit` | 2026-10-01 | Design: extend, don't add |
| L8 | The Codex app reloads config inside running threads, so an edit can break a job hours later, not at once | Messages kept working ~75 min after the edit, then failed | L2 timeline | 2026-10-01 | Step 3: check after change and again later |

## 3. The three proposed steps: what the evidence says

**Step 1, one expected-state list per AI app: SUPPORTED, with two qualifiers.**
- Every reconcile tool compares live state with one declared, versioned source (E6, E18–E23), and both vendors ship one enforced list for exactly this (E26, E27).
- Qualifier 1: one list in total, with an `app` column, not one per app or per tab. Today two tabs disagreed about the same 16 items and the cleanup followed the other one (L1). The workbook should be generated from the list, the way the post-commit hook already builds the tool-cards tab (L7).
- Qualifier 2: each row records why it is there and what depends on it. Entries without reasons are what grows and becomes unsafe to delete (E28); `policy.txt` already records "role skills depend on them" for 23 skills (L6).

**Step 2, cleanups remove only what the list marks as a duplicate, backup first: SUPPORTED, but a backup alone is not enough.**
- Mature tools treat deletion as the dangerous step: opt-in, limited to what they own, disable before delete (E20, E21, E27). Cleanups acting on a stale or wrong view caused real outages (E14, E15, E17), and agent cleanups did too (E16, E17).
- Qualifiers from the evidence and today: (a) the list names the replacement for each "duplicate" and the replacement is proven first; (b) a dependency check runs before removal, because both of today's breaks were items with live dependents (L2, L3); (c) disable before delete where the app allows it (E27); (d) the backup lives outside what the change can touch and predates it (E14, E17); (e) a re-check after a delay, because breaks show up minutes to hours later (E14: 5 minutes; L8: about 75 minutes).

**Step 3, a daily drift check: QUALIFIED.**
- A daily, alert-only check is a mainstream default (E22, E23) and most teams check too rarely (E9, E10). So daily is better than today's nothing.
- But the riskiest moment is right after a change (E1). Today the Messages break surfaced about 75 minutes after the edit window closed (16:47Z to 18:02Z), and the Jobber break mid-afternoon (L2, L3); a daily check would have found both up to a day late. The check must also run on every change. Alex already has a tune-up every 8 hours (L7), which is more often than daily and needs no new scheduled job.
- Alert, don't auto-fix. Tools that auto-correct re-apply declared values but never delete on their own (E20, E21, E24). Alex changes his setup on purpose; an auto-revert would have fought today's intended removals.

## 4. How other people govern plugins, built-ins and skills from one place (Alex's question)

24 Exa calls (about $0.16), read 2026-10-01; page text cached in the session scratchpad `r6g/`. Most vendor pages are undated or show only "updated N days ago".

### 4a. What the vendors offer

| # | Product | Feature (exact setting or admin page) | What it controls | What it does (paraphrased) | Source | Plan needed |
|---|---|---|---|---|---|---|
| G1 | Claude Code | Settings precedence: managed > CLI > local > project > user; only one managed source applies | everything | Managed settings can't be overridden; permission rules merge across scopes | code.claude.com/docs/en/settings | any (file) or Team/Enterprise (server-managed) |
| G2 | Claude Code | `enabledPlugins` `{"plugin@marketplace": true/false}` | plugins | Declared on/off per scope; a managed entry forces the value | same | any |
| G3 | Claude Code | `extraKnownMarketplaces`; `strictKnownMarketplaces` (managed only; `[]` = lockdown); `blockedMarketplaces` | plugin catalogs | Allowlist of where plugins may come from, checked before download | same; code.claude.com/docs/en/plugin-marketplaces | any (managed file) |
| G4 | Claude Code | `strictPluginOnlyCustomization` (managed only) | skills, agents, hooks, MCP | Only plugin and managed sources load; user and project sources are blocked | code.claude.com/docs/en/settings | any (managed file) |
| G5 | Claude Code | `allowedMcpServers`, `deniedMcpServers` (deny wins), `allowManagedMcpServersOnly`, `managed-mcp.json` | MCP servers, claude.ai connectors | MCP allowlist; unset = open, `[]` = none; invalid values fail closed | same | any (managed file) |
| G6 | Claude Code | `skillOverrides`, `disableBundledSkills`, `skillListingBudgetFraction` (default 1% of context) | skills, built-ins | Hide or turn off single skills, cap the skill list | same | any |
| G7 | Claude Code | `marketplace.json` `version` / `ref` / `sha` / `defaultEnabled` | plugins | Pin a plugin to a version or commit; ship installed but off | code.claude.com/docs/en/plugin-marketplaces | any |
| G8 | Claude Team/Enterprise | Organization settings > Connectors; tool permissions Always allow / Needs approval / Blocked | connectors, approvals | Org turns a connector on before members can use it; per-tool policy users can't override | support.claude.com/en/articles/11176164 | Team/Enterprise |
| G9 | Claude Team/Enterprise | Organization settings > Skills (provisioned skills) | skills | Admin-provided skills on for every member | support.claude.com/en/articles/13119606 | Team/Enterprise |
| G10 | Claude Desktop | Organization settings > Connectors > Desktop: extension allowlist | desktop extensions | Only listed extensions install; enabling it removes others | support.claude.com/en/articles/12592343 (2026-03-16) | Team/Enterprise |
| G11 | Codex | `requirements.toml` (cloud-managed, MDM, or `/etc/codex/requirements.toml`) | approvals, sandbox, MCP, apps, plugins, features, hooks | Admin-enforced; users can't override; first source found wins | developers.openai.com/codex/enterprise/managed-configuration | any (file) or Business/Enterprise (cloud) |
| G12 | Codex | Requirements `[mcp_servers.<name>] identity`; `[plugins.<id>.mcp_servers.<srv>] identity`; `[marketplaces] restrict_to_allowed_sources` | MCP servers, plugin servers, plugin catalogs | A server runs only if its name and identity match; unlisted plugin servers are off; plugin installs limited to listed sources | developers.openai.com/codex/config-reference | any (file) |
| G13 | Codex | Requirements `[apps.<id>] enabled = false`, per-tool `approval_mode`; `[features]` pins (plugins, apps, browser_use, in_app_browser, computer_use, hooks) | apps, built-ins, approvals | Turn off an app, pin a tool's approval, pin built-ins on or off | same | any (file) |
| G14 | Codex | `managed_config.toml` | defaults | Starting values re-applied at every launch; users can change them in a session | developers.openai.com/codex/enterprise/managed-configuration | any (file) |
| G15 | Codex / ChatGPT desktop | `marketplace.json` with `policy.installation` AVAILABLE / INSTALLED_BY_DEFAULT / NOT_AVAILABLE; reads repo, personal (`~/.agents/plugins/marketplace.json`) and Claude-style marketplaces | plugins | One catalog format for both vendors' marketplace files | developers.openai.com/plugins/build/plugins | any |
| G16 | ChatGPT Business/Enterprise | Admin > Plugins: installation policy Available / Installed per role; GitHub marketplace import with daily sync | plugins (with their apps and skills) | Workspace-wide on-list; the GitHub import pulls every valid plugin, so the repo must be the gate | help.openai.com/en/articles/11509118; /20001256; /20001504 | Business/Enterprise |
| G17 | ChatGPT | App actions (enable all / only new read actions / disable new) and permissions (always ask … allow all) | connector actions, approvals | What an app may do, and when ChatGPT asks first | help.openai.com/en/articles/11509118 | Business/Enterprise |
| G18 | ChatGPT Enterprise/Edu | Custom roles; skills permissions | apps, plugins, skills per role | Per-role access to apps and skills | help.openai.com/en/articles/11750701; /20001066 | Enterprise/Edu |
| G19 | Docker | MCP Toolkit + MCP Gateway: catalogs → profiles → clients | MCP servers per client | One proxy holds config and credentials; each client gets a profile (its server set) | docs.docker.com/ai/mcp-catalog-and-toolkit/mcp-gateway | – |
| G20 | MCP project | Official MCP Registry (preview) | discovery only | Public server metadata; doesn't limit tools | modelcontextprotocol.io/registry/about | – |
| G21 | Composio | Sessions (tool router) with `toolkits.enabled` / `toolkits.disabled` | toolkits and tools per session | One MCP URL per user; an enabled list blocks every other toolkit; with no list the whole catalog is discoverable | docs.composio.dev/docs/sessions-via-mcp | – |
| G22 | Cloudflare, GitHub, Microsoft, Kong | MCP server portals with Access policies; Copilot MCP registry allowlist; API Center MCP inventory; AI Gateway per-tool access | MCP servers and tools | Gateways and allowlists in front of MCP servers (Microsoft and Kong from search highlights only) | developers.cloudflare.com/cloudflare-one/access-controls/ai-controls/mcp-portals; docs.github.com …/copilot/concepts/mcp-management | – |
| G23 | Research | SWE-Skills-Bench: 39 of 49 skills gave no gain (average +1.2%), up to 451% token overhead, 3 made results worse. "Signal or Noise?": web-dev skills cut pass rates 1.3–4.2% and raised token cost 72–394% | skills | Installed skills are not free | arxiv.org/html/2603.15401v1; arxiv.org/abs/2608.23067 (2026-08-24) | – |
| G24 | Practitioners | "Agent config as code": one `.agents/` folder or chezmoi dotfiles repo generates each app's config files | skills, MCP, rules | Same pattern as Alex's `~/.agents`; no outcome numbers published | github.com/latentevals/agent-setup; dev.to/dotwee (chezmoi write-up) | – |

### 4b. Codex specifics that change the restore table

- **Turning a plugin on.** `[plugins."<plugin>@<marketplace>"] enabled = true/false` in `config.toml`; `false` turns it off without uninstalling. Plugin-bundled MCP servers are tuned under `[plugins."x@y".mcp_servers.<srv>]` with `enabled`, `enabled_tools`, `disabled_tools`, `default_tools_approval_mode` and per-tool `approval_mode` (developers.openai.com/codex/mcp; config reference).
- **No entry = off?** The local bundled catalog marks all 11 bundled plugins AVAILABLE, none INSTALLED_BY_DEFAULT, and cached Codex source loads only plugins with a config entry. SEEN today: Messages disappeared after its entry was removed, but `codex_app` (codex-app-tools) kept working with no entry. So the docs and code are not the whole story; treat "no entry = off" as true for Messages and false for codex-app-tools until RCA spp-p5a settles it.
- **Approval modes.** `auto` (default: asks only for tools labeled risky or unlabeled), `prompt` (asks every call), `writes` (new July 2026: reads run, everything else asks), `approve` (never asks). Precedence: per tool, then server or app default, then `auto`.
- **Under `approval_policy = "never"` with full access (Alex's Codex setting).** Per cached Codex code, every MCP and app tool prompt resolves as approved, even `prompt`. So per-tool approval lines neither help nor protect in this setup: the 4 removed `approve` lines were redundant (matches the SEEN 18h results), and the only real guard on a risky tool is `disabled_tools` or not installing it. Not tested on 0.159.2; the code read predates `writes`.

### 4c. How other people do it, scaled to a one-person business

1. **Three layers, kept apart.** A catalog (where plugins may come from: a git marketplace with pinned versions), a declared on-list per app (`enabledPlugins`, `[plugins.*]`, the ChatGPT workspace install policy), and optionally a lock that refuses anything else (managed settings, `requirements.toml`). Composio plays the same three roles for connectors (toolkits, the enabled list, the session), and 1Password for keys.
2. **Connectors through one gateway, allowlisted per app.** Docker, Cloudflare, Kong and Composio sessions all centralise routes and limit tools per client. Alex already has this: Composio is the gateway; per-app limits belong in the Composio session (`toolkits.enabled`), not in each AI app.
3. **Keep the on-list short.** Tool and skill counts have measured costs (section 7, G23). Teams switch off what they don't use (Claude `skillOverrides` / `disableBundledSkills`, Codex `[[skills.config]]` and `[features]` pins).
4. **Check it as code.** Practitioners generate each app's config from one folder and diff live state against it (G24, E25). Alex has the folder (`~/.agents`) and the diff tool (`check.py`); what's missing is the list and the compare.
5. **Locks are optional and cost a step.** The admin consoles need team plans (Claude Team/Enterprise, ChatGPT Business/Enterprise). On one Mac the file locks work on any plan (`/Library/Application Support/ClaudeCode/managed-settings.json`, `/etc/codex/requirements.toml`) but need admin rights to write, and they would also block Alex's own quick changes. Recommendation: list + check first; add a lock only if agents keep re-adding removed items.

## 5. The smallest design that works for Alex

| Question | Answer | Built from what already exists |
|---|---|---|
| Where the list lives | One file, `~/.agents/expected-apps.csv`, in the `~/.agents` git repo (versioned, backed up to the mini). Columns: app, kind (connector / plugin / built-in / MCP server / skill pack / approval), name, state (on / off / remove), why, depends-on, replacement, decided (date, who). The workbook's All connections and AI apps rows are generated from it; nobody edits them by hand | `~/.agents` repo and its post-commit hook, which already rebuilds the tool-cards tab |
| What it covers | Per app: Codex (`config.toml` plugins, MCP servers, apps, marketplaces, skill off-switches), Claude Code (`settings.json` `enabledPlugins`, MCP servers by scope), Claude Desktop config, and the ChatGPT and claude.ai items that only a screen read can see. Connectors stay in Composio, keys in 1Password, skills in `~/.agents/skills`: the list points to those homes, it doesn't copy them | the four homes in 1g |
| Who checks | `~/.agents/tools/unify/check.py` gets one more section: read each live config, compare it with the list, and for every item that is off or marked remove, search skills, instruction files, tool cards and `~/.codex/automations` for its name. It also reads the last 8 hours of Codex rollouts for "is not a function" or unknown-tool errors (the signal behind L2 and L3) | `check.py` (read-only, exit 1 on problems) |
| When | (1) By the agent making any change, right after it and again at the next run, as part of `verify-before-done`. (2) At every tune-up (already every 8 hours) | the tune-up's step 7, "Tool drift"; `verify-before-done` |
| What alerts | `check.py` prints FIX lines; the tune-up puts them at the top of its owner proposal. A lost tool in an ACTIVE automation goes first. No auto-fix and no auto-delete | the tune-up proposal (it never sends; no new recurring job or outside message) |
| How a cleanup runs | Mark the row `remove` with the reason and the proven replacement → dependency check clean (or change the dependent first) → back up to `~/Backups` → disable before delete where the app allows → remove → `check.py` → re-check at the next tune-up | the standing yes for proven duplicates (AGENTS.md rule 1) |
| What Alex does | Decides rows (on, off, remove) in plain words; reads the tune-up proposal. Nothing else to remember | – |

Smallest first step (one play, after the Director assigns it): write the list with today's rows (sections 6 and the workbook's All connections tab), then add the compare and dependency sections to `check.py`. Status: designed only; nothing here is built or configured.

## 6. R6b: restore table for the items removed from `~/.codex/config.toml` (12:22–12:47 local, 16:22–16:47Z)

**Method.** Python scan of Alex's own Codex rollouts: 390 regular `.jsonl` files under `~/.codex/sessions/2026/09` and `/10` (166 main sessions, 224 subagent sessions; rollouts exist on 17 days, Sept 4 to Oct 1; 3.1 GB). Only names were counted: MCP calls from `McpToolCall` items (server, tool, plugin id, status), skill loads from shell reads of a `SKILL.md` plus `<skill>` injections, and browser/desktop targets from the API names inside `cua_repl` calls (`createBrowserTab('chrome'|'iab')`, `getApp`). No message, file or tool content was copied. Script and raw counts: scratchpad `scan.py`, `scan-results.json`, `perday.json` (not in the repo). `~/.codex/archived_sessions` (15 files since Sept 1) was not scanned. Before/after state: `config.toml.bak-before-after-20261001` (12:22, 20 plugins, 7 MCP servers, 4 approve lines) vs `config.toml` (written 14:06 and again 14:29 local, by another writer; both times 0 plugins, MCP `1password`, `node_repl`, `cua_repl` with `enabled = false`, marketplaces `openai-bundled` and `openai-primary-runtime` only).

**What the removal actually changed (SEEN).**
- Skills: the catalog Codex injects went from 156 entries (session 01a0f779, 12:40Z) to 102 (session 01a0f898, 17:53Z). Superpowers, compound-engineering, documents, pdf, spreadsheets and data-analytics skills are gone (so are the account-managed google-drive, notion, cloudflare, write-like-me and Exa skills, which were never `[plugins]` entries).
- The catalog is a fixed budget: about 22,200 characters both times (22,196 vs 22,165). Removing 54 entries saved no tokens; it gave the 91 entries from `~/.agents/skills` 64% more room (11,646 → 19,148 characters of description).
- Messages: the ACTIVE automation `track-payzer-support-reply` (every 30 min) read Messages at 16:3x, 17:0x and 17:3x Z after the edit; at 18:02:51Z its call failed with "is not a function" (tool gone). Its next two runs used shell commands instead; what they read was not checked.
- codex_app tools still work without the plugin entry and without the 4 approve lines: after 18:00Z, `send_message_to_thread` 8 of 9 OK, `read_thread` 12 of 14 OK; `automation_update` 5 of 7 OK at 17h. Why `codex-app-tools` keeps working with no entry is NOT_PROVEN (section 4b).
- `cua_repl` (browser and computer-use runtime): 608 calls on Oct 1 before the edit, 0 after; it is now disabled outright.
- Related, not on this list: in the ACTIVE automation `dynamite-internal-event-freshness` (every 15 min) the ChatGPT Jobber app tool went missing at 16:17:04Z (last good call 15:32:27Z). Cause NOT_PROVEN; most likely the ChatGPT-side app removals.

| Item | Sept–Oct uses (Codex rollouts) | What depends on it | Recommendation | Why |
|---|---|---|---|---|
| superpowers@openai-curated | 338 skill loads in 19 sessions (17 main) on 9 days; 108 of them on Oct 1. using-superpowers 134, systematic-debugging 115, verification-before-completion 51, test-driven-development 27 | `~/.agents/tools/skill-hygiene/policy.txt` keeps 6 of its skills on "because Alex's role skills and AGENTS.md depend on them"; Director `references/controllers.md` trigger table names 5; conductor rule 1 | **RESTORE** (skills only, the same 6 on) | Named dependents in the Director and conductor; none of the 6 exists in `~/.agents/skills`. Adds 0 tools and about 850 catalog characters |
| compound-engineering@compound-engineering-plugin | 170 loads in 53 sessions (26 main) on 13 days; 3 on Oct 1. ce-work 40, ce-plan 27, ce-debug 26, ce-code-review 20, lfg 16 | Conductor route table (`ce-debug`, `ce-work`, `ce-compound` "if installed", `lfg`); Director `references/handoff.md` loads `compound-engineering:ce-handoff`; policy.txt keeps 6; STACK.md line 33 | **RESTORE, trimmed** to the 6 policy skills (ce-debug, ce-work, ce-compound, ce-plan, ce-handoff, lfg) with `[[skills.config]]` off-switches for the rest; re-add its marketplace | Real dependents, but it used 27 catalog entries (3,663–4,151 characters, 17–19% of the budget). Trimming keeps the dependents and returns most of the room |
| messages@openai-bundled | 3,682 calls in 4 sessions; 3,669 of them (99.6%) from the thread of automation `track-payzer-support-reply`; 0.2% failed | ACTIVE automation `track-payzer-support-reply` (30 min); broke at 18:02:51Z | **RESTORE**, or retire that automation on purpose | The only removed item with a live job that broke. Restore it with `disabled_tools = ["send_message"]` on the plugin's `messages` server (documented, untested): under `never` + full access an approval line would not stop a send (section 4b). Codex sent 3 texts through it in Sept |
| unified-computer-use@openai-bundled (`cua_repl`) | 6,452 calls in 72 sessions (41 main) on 14 days; 608 on Oct 1; 6.2% failed | The engine for browser, chrome and computer-use below; ACTIVE automations `dynamite-internal-freshness-alerts` (315 calls Oct 1) and `dynamite-48h-follow-up-detection` (68) used it | **RESTORE** with the three below, and remove the `[mcp_servers.cua_repl] enabled = false` override | The shared card `browser-and-computer.md` names a Codex route for all 3 browser/computer jobs. Adds 2 tools (`js`, `js_reset`) |
| browser@openai-bundled | In-app browser named in 21 calls (12 sessions); browser-tab calls with no browser named: 1,762 (59 sessions) | Card: Codex "public page → its bundled browser"; workbook All connections R51 | **RESTORE** (with the runtime) | Same as above; skills/docs/hooks only, no extra tools |
| chrome@openai-bundled | Chrome named in 70 calls (15 sessions, 6 days, last Sept 29) | Card: Codex "page behind Alex's login → its bundled browser on Chrome"; R52 | **RESTORE** (with the runtime) | Same |
| computer-use@openai-bundled | Desktop-app control 379 calls (30 sessions, 20 main, 10 days, last Oct 1) | Card: Codex "desktop app → Computer Use"; R57 | **RESTORE** (with the runtime) | Same. If Alex wants Codex to have no browser or computer use, change the card's Codex column and R51/R52/R56/R57/R66 first, then leave all four off |
| documents@openai-primary-runtime | 1 load (Sept 19, a subagent) | none found | **LEAVE OFF** | No dependent; Alex's own skills cover documents |
| spreadsheets@openai-primary-runtime | 7 loads (5 sessions, last Sept 29) | none found | **LEAVE OFF** | Duplicates `xlsx` and `excel-generator` in `~/.agents/skills` (one home for skills) |
| pdf@openai-primary-runtime | 4 loads (4 sessions, last Sept 21) | none found | **LEAVE OFF** | Duplicates `typst-pdf-maker` in `~/.agents/skills` |
| presentations@openai-primary-runtime | 0 (was already off) | none | **LEAVE OFF** | Removing an `enabled = false` line; the 17:53Z catalog shows it stays off |
| data-analytics@openai-curated | 4 loads (2 sessions, Sept 29; from the account's remote copy while the local entry was off) | none | **LEAVE OFF** | No dependent; gone from the 17:53Z catalog |
| finances@openai-curated | 0 (was off) | none | **LEAVE OFF** | – |
| sales@openai-curated | 0 (was off) | none | **LEAVE OFF** | – |
| visualize@openai-bundled | 0 (was off) | none | **LEAVE OFF** | – |
| code-review@openai-bundled | 0 calls (its server showed "disabled" in `codex mcp list`) | none | **LEAVE OFF** | – |
| template-creator@openai-primary-runtime | 0 | none | **LEAVE OFF** | – |
| openai-developers@openai-curated | 0 (was off) | `frontend-app-builder` uses it only "when available" | **LEAVE OFF** | Soft, optional reference |
| approve line `send_message_to_thread` | 511 calls (24 sessions); 15 errors, none about approval | Conductor and Director message Codex threads with the tool (not the line) | **LEAVE OFF** | The tool still works without the line (8 of 9 OK after 18:00Z). Under `approval_policy = "never"` with full access, Codex approves every MCP/app call anyway (section 4b), so the line did nothing; re-add only if that policy changes |
| approve line `create_thread` | 12 calls (8 sessions) | Director creates controllers natively | **LEAVE OFF** | Same reasoning |
| approve line `handoff_thread` | 0 | none | **LEAVE OFF** | Never used |
| approve line `automation_update` | 84 calls (14 sessions) | automations | **LEAVE OFF** | 5 of 7 OK at 17h without the line |
| MCP `orgo` | 3,331 calls, all in Sept (37 sessions, 18 main, 12 days, last session Sept 30); bash 2,184, python 904, upload 118, screenshot 23, clicks/keys/typing 19; 3.0% failed | Javar/Hermes work on Orgo boxes (`hermes-team-setup`, `javar-add-tool`, STACK.md); workbook R210 "UNDECIDED (Alex)", App decisions R46 "remove" | **LEAVE OFF**; the route is the Orgo CLI through `~/.agents/tools/connectors/orgo_op.py` | The CLI route is proven (18:12Z: `computers list`, `computers bash`) and covers bash/python/list, about 94% of past calls. The MCP would add 53 tools. Restore it through `~/.orgo/run-mcp-server.sh` (now key-free) only for screen, click or upload jobs |
| MCP `hermes-docs` | 3 calls (1 session, Sept 22) | STACK.md line 87 says Codex reads Hermes docs through it | **LEAVE OFF**; fix that STACK.md line | Workbook R87 already targets removal |
| MCP `meta-ads-docs` | 1 call, failed (Sept 23) | none | **LEAVE OFF** | Workbook R88 targets removal; rule: docs go through Composio docs readers |
| MCP `composio-docs` | 0 | none | **LEAVE OFF** | Workbook R86 targets removal |
| MCP `computer-use` (SkyComputerUseClient) | 0 calls; startup failed 21 times (Sept 30: 2, Oct 1: 19, "No such file or directory": relative path); left out of the tool list 189 times | none (duplicate of the plugin) | **LEAVE OFF** | Dead entry; the plugin route covers the job |

**Totals:** RESTORE 7 plugins (superpowers, compound-engineering trimmed to 6 skills, messages, and the 4-plugin browser/computer set). LEAVE OFF 11 plugins, the 4 approve lines and all 5 MCP servers. The restore set adds about 6 tools (2 `cua_repl`, 4 Messages with `send_message` off) and 12 catalog entries; the left-off Orgo MCP alone would have added 53 tools.

## 7. How many tools and skills an agent should carry (evidence behind the restore table)

21 Exa calls, read 2026-10-01. Numbers are as the pages state them; "derived" marks arithmetic done here.

| # | Claim | Number | Source (section) | Date | Type |
|---|---|---|---|---|---|
| T1 | OpenAI: keep the functions loaded at the start of a turn small | fewer than 20 (soft guidance) | developers.openai.com/api/docs/guides/function-calling (best practices) | undated | vendor guidance |
| T2 | OpenAI tool search: groups of fewer than 10 functions per namespace; deferral hides schemas, names stay | <10 per namespace | developers.openai.com/api/docs/guides/tools-tool-search | undated | vendor guidance |
| T3 | GPT-5.4 with tool search on 250 MCP Atlas tasks, all 36 MCP servers on | 47% fewer tokens, same accuracy | openai.com/index/introducing-gpt-5-4 (tool search paragraph) | 2026-03-05 | vendor test |
| T4 | Codex skills list: name, description, path only; capped at about 2% of the context window (8,000 characters if the window is unknown); descriptions are cut first, then skills dropped with a warning | 2% | developers.openai.com/codex/skills; openai/codex issue #19679 (source constant `SKILL_METADATA_CONTEXT_WINDOW_PERCENT = 2`); PR #18298 | 2026-04 | product limit |
| T5 | A Codex user log: 119 skills, budget 5,440 tokens, 103 descriptions cut. Matches Alex's ~22.2k-character list at both 156 and 102 skills | 5,440 tokens | openai/codex issue #24299 | 2026-05-24 | practitioner report |
| T6 | Codex MCP: no tool cap documented; per-server `enabled_tools` / `disabled_tools` | – | developers.openai.com/codex/mcp (config) | undated | product doc |
| T7 | Codex defers MCP tools behind tool search only at 100+ tools, unless `tool_search_always_defer_mcp_tools` is set (not checked against 0.159.x) | 100 | openai/codex PR #18097 | merged 2026-04-17 | source code |
| T8 | Anthropic: picking the right tool gets worse past 30–50 tools; use tool search from 10 tools or 10k tokens of definitions; it cuts definition tokens by over 85% | 30–50; 10; >85% | platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | undated | vendor guidance |
| T9 | Anthropic: 58 tools from 5 MCP servers ≈ 55K tokens before any work; with tool search, MCP-eval accuracy Opus 4 49% → 74%, Opus 4.5 79.5% → 88.1% | 55K; +25 and +8.6 points | anthropic.com/engineering/advanced-tool-use | 2025-11-24 | vendor test |
| T10 | Agent Skills: about 100 tokens of metadata per skill at startup; body loads only when used | ~100 tokens/skill | platform.claude.com/docs/en/agents-and-tools/agent-skills/overview (levels table) | undated | vendor guidance |
| T11 | Claude Code: MCP tool search on by default; CLI tools use less context than MCP servers; disable unused servers | 10% threshold | code.claude.com/docs/en/mcp; code.claude.com/docs/en/costs | undated | vendor guidance |
| T12 | RAG-MCP: only the relevant tool vs all tools | accuracy 43.13% vs 13.62%; >90% success under 30 tools, mixed 31–70, mostly failing past ~100 | arxiv.org/abs/2505.03275 | 2025-05-06 | preprint |
| T13 | Less is More (Llama 3.1 8B on a small device) | 46 tools fail, 19 succeed; up to 70% less time | arxiv.org/abs/2411.15399 | 2024-11-23 | preprint |
| T14 | LongFuncEval: catalog grown from 8K to 120K tokens | accuracy down 7.59–85.58% | arxiv.org/abs/2505.10570 | 2025 | preprint |
| T15 | MCP-Universe: unrelated servers added (7 servers, 94 tools) | one score halved (22.22% → 11.11%) | arxiv.org/abs/2508.14704 | 2025-08 | preprint |
| T16 | MCPVerse: most models drop as tools grow; Claude 4 Sonnet held steady (62.36 vs 62.28) | – | arxiv.org/abs/2508.16260 | 2025-08 | preprint (counter-evidence) |
| T17 | GitHub Copilot cut 40 built-in tools to 13 core tools | +2–5 points success; faster | github.blog "smarter with fewer tools" | 2025-11-19 | vendor test |
| T18 | VS Code Copilot hard cap per request | 128 tools | code.visualstudio.com/docs/copilot/chat/chat-tools | undated | product limit |
| T19 | LangChain: one agent given more domains | gpt-4o calendar tasks fell to 2% at 7 domains | langchain.com/blog/react-agent-benchmarking | 2025-02-10 | practitioner test |
| T20 | "Agent Skills Can Be Harmful": 307 skill-induced failures (125 functional, 182 efficiency regressions); excessive procedure 114 of 182 (62.6%); context overhead 46 | as stated | arxiv.org/abs/2608.11888 | 2026-08-12 | preprint |
| T21 | derived from T9 and T10: one up-front MCP tool ≈ 600–1,900 tokens vs one skill entry ≈ 100 tokens | ~10x | derived | – | derived |

**What it means for Codex.**
- Skill-only plugins cost almost no tokens in Codex: the list is a fixed budget (T4, T5; local 22,196 vs 22,165 characters). Their real cost is shorter descriptions for every other skill, so restore only skills with a named dependent and keep the count near the 30 that R3 recommended.
- MCP tools cost context every turn (T9, T21) and, below Codex's 100-tool deferral point (T7), load in full. Accuracy falls as tools are added in most studies (T12–T15, T17, T19), with one counter-example (T16). Keep always-loaded tools at about 20 (T1) and well under 30–50 (T8). That is why the Orgo MCP (53 tools) stays off while the CLI covers the job (T11 makes the same point for Claude Code).
- Excessive procedure in skills is itself a measured cost (T20). Alex's Director skill cites this paper with slightly wrong labels: it says "mandated procedure" and "slowdowns"; the paper says "excessive procedure" and "efficiency regressions" (tokens and time both up, one at least doubled). Wording fix for the Director's owner: "Excessive procedure caused 114 of 182 skill-induced efficiency regressions."

## 8. Findings for other nodes (not acted on here)

| # | Finding | Evidence | Owner / next |
|---|---|---|---|
| F1 | Two ACTIVE automations lost a tool today: `track-payzer-support-reply` (Messages, 18:02:51Z) and `dynamite-internal-event-freshness` (ChatGPT Jobber app, 16:17:04Z). Neither failed loudly | section 6, L2, L3 | Director: decide restore vs retire for the first; Conductor: check the Jobber route for the second |
| F2 | The workbook holds two lists for the same items: All connections R51–R72 (keep / leave off) vs App decisions R11, R12, R46 (remove). After Alex's decision, both should be regenerated from one list; R210 (Orgo) can be closed as "CLI route" | L1; notes/expected-state.csv; replication-gap-export/08-app-decisions.txt | playbook-tabs (spp-p5c) |
| F3 | The "two-connector rule" (SOP R4) should say it covers connectors only; built-ins, app plugins and skill packs are listed per app | section 1g | playbook-tabs |
| F4 | Director skill `references/controllers.md` cites arXiv 2608.11888 with the wrong labels ("mandated procedure", "slowdowns"). The paper: excessive procedure caused 114 of 182 efficiency regressions (tokens and time both up, one at least doubled) | T20 | propose in `system/lessons.md` (control file; owner approval) |
| F5 | `~/Alex-Director/STACK.md` line 87 still says Codex reads Hermes docs through `hermes-docs`, which is gone | section 6 | Director |
| F6 | Codex `[features] computer_use = true` is on while `[mcp_servers.cua_repl]` is set `enabled = false`: the switch says on, the runtime is off | `config.toml` (names only) | RCA spp-p5a / restore play |
| F7 | `codex-app-tools` keeps working with no `[plugins]` entry while Messages stopped; the vendor catalog says neither is installed by default | section 4b | RCA spp-p5a |
| F8 | Under `approval_policy = "never"` with full access, Codex approves every MCP and app call, so every `approval_mode` line in Alex's Codex config (including the Composio app's `approve`) changes nothing; only `disabled_tools` or not installing guards a risky tool | section 4b (cached Codex code, untested on 0.159.2) | live-tests (spp-p5b) |
| F9 | `using-superpowers` accounts for 134 of the 338 superpowers skill loads in Codex, although the Director's rule says not to load it on every task | section 6 | Alex decides whether to keep it on; policy.txt lists it |

## 9. NOT_PROVEN and what would settle it

| Item | What would settle it |
|---|---|
| Whether a bundled plugin with no `[plugins]` entry loads (codex-app-tools did, Messages didn't) | RCA spp-p5a, or a new Codex session's tool list after a test entry change |
| The exact moment the running threads picked up the plugin removal (between 17:33Z and 18:02Z) | RCA spp-p5a |
| `disabled_tools` on a plugin-bundled server (for Messages `send_message`) on Codex 0.159.2 | One test session after the restore: `send_message` absent, `read_messages` present |
| Approval behaviour under `never` + full access on 0.159.2 (code read predates the July `writes` change) | live-tests spp-p5b |
| Whether the Orgo CLI covers uploads, screenshots and clicks (160 of 3,331 past MCP calls) | `orgo_op.py orgo --help` and one upload test on a test computer |
| What caused the Jobber tool loss at 16:17Z | The Conductor's ChatGPT app change log |
| Whether Alex's "Increase Roas" ChatGPT workspace is Business (admin plugin controls) | Alex, or the ChatGPT admin page |
| Rollouts in `~/.codex/archived_sessions` (15 files since Sept 1) | Not scanned by instruction; counts above may be slightly low |
| HCP Terraform's current drift cadence (24 h vs 4 h in two docs); Cursor's current tool cap; Spacelift/env0 drift numbers | Not needed for the decisions here |

## 10. Sources and evidence pointers

- Local data (session scratchpad `/private/tmp/claude-501/-Users-alexlobaito-Projects-master-connector-repo/294b676b-77d8-4d64-976e-70a783b96d65/scratchpad/`, not in the repo; rerun the scripts to regenerate): `scan.py` → `scan-results.json` (390 rollouts), `perday.py` → `perday.json`, `catalog.py` (skills catalog per session), `fails2.py`, `missing.py`, `deps.py` → `deps.json`. Config versions: `~/.codex/config.toml.bak-before-after-20261001` (12:22), `-docs` (12:47), `-rewrite` (12:56), `config.toml` (14:06; rewritten 14:29 with the same plugin and MCP names).
- Web pages: cached text in the same scratchpad, folders `r5/`, `r6/`, `r6g/`, `r6b/`, each file starting with its URL. All read 2026-10-01.
- Main URLs: modelcontextprotocol.io/specification/2026-07-28 (overview, /architecture, /server, /server/tools); developers.openai.com/codex/plugins, /codex/skills, /codex/mcp, /codex/config-reference, /codex/enterprise/managed-configuration, /plugins/build/plugins, /api/docs/guides/function-calling, /api/docs/guides/tools-tool-search; help.openai.com articles 6825453 (release notes), 11487775, 11509118, 20001256, 20001504, 11750701, 20001066, 12584461; support.claude.com articles 11175166, 13837440, 11176164, 13119606, 12592343; code.claude.com/docs/en/plugins, /settings, /plugin-marketplaces, /mcp, /skills, /costs; platform.claude.com/docs/en/agents-and-tools/tool-use/overview, /tool-search-tool, /agent-skills/overview; anthropic.com/engineering/advanced-tool-use (2025-11-24), /desktop-extensions; docs.composio.dev/docs/glossary, /how-composio-works, /sessions-via-mcp, /migration-guide/mcp-servers-to-sessions; sre.google/sre-book/introduction; dora.dev 2024 report and capabilities/version-control; 2025 DORA report PDF (services.google.com); uptimeinstitute.com 2025 outage analysis; firefly.ai 2025 and 2026 reports; crowdstrike.com PIR and RCA; status.cloud.google.com incident ow5i3PPK96RduMcb1SsW; blog.cloudflare.com/18-november-2025-outage; azure.status.microsoft YKYN-BWZ; aws.amazon.com/message/101925; opengitops.dev; kubernetes.io controllers; argo-cd.readthedocs.io; fluxcd.io; developer.hashicorp.com drift-detection tutorial; pulumi.com drift docs; docs.ansible.com check mode; chezmoi.io verify; docs.docker.com MCP gateway; arXiv 2505.03275, 2411.15399, 2505.10570, 2508.14704, 2508.16260, 2608.11888, 2608.11095, 2608.25241, 2603.15401, 2608.23067; github.blog fewer-tools post (2025-11-19); code.visualstudio.com chat tools; langchain.com react-agent benchmarking (2025-02-10); openai/codex issues 19679 and 24299, PRs 18298 and 18097.
