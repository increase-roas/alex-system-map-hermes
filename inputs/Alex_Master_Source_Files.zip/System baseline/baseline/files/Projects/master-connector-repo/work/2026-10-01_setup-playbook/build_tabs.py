#!/usr/bin/env python3
"""Build the playbook tabs of the connectors workbook from tabs/*.json. Every row carries its source.

  python3 build_tabs.py check                      # validate tabs/*.json; print every claim still without a source
  python3 build_tabs.py templates                  # regenerate tabs/templates.json from the template files
  python3 build_tabs.py splittest                  # regenerate "split_test" in work/2026-10-01_director-tab/notes/skills-map.json
  python3 build_tabs.py decisions                  # regenerate tabs/decisions.json from notes/decision-evidence.csv
  python3 build_tabs.py dry-run                    # build into a copy in $TMPDIR, compare with the master, write the report
  python3 build_tabs.py apply --workbook-free      # only after the Director's "workbook free": back up, build, copy

The tabs are projections of the JSON files: edit the JSON (or the files it names), never the sheet. A glossary tab slots in
after "Rebuild from zero" as soon as tabs/glossary.json exists (same JSON shape). corrections.json holds guarded cell edits,
appended rows, fill_rows (a new row written into an empty row inside a table, styled like a template row, refused
if that row is no longer empty) and insert_rows (a new table row inserted before a named row, which moves the rows below
down by one; refused unless that row still starts with its anchor text; skipped once its marker is in the tab) for
existing tabs.

Tab JSON: {"tab", "insert_after", "standalone" (optional: placed after insert_after, not after the previous tab),
"expected_warnings" (optional: {warning text: why it is expected}; those warnings are counted, not listed),
"intro", "widths", "sections": [{"title", "header", "rows"} or {"title",
"verbatim_from", "rows": [[line no, text], ...]}], "unsourced": [...]}. The last header column is "source", unless the
section names its source column with "source_col" (the Tests tab: "evidence path"). A source is
items joined by " ; ": a path (repo-relative or ~/...) plus an optional locator (§n, Ln, Ln–Lm, row <csv id>, L-00n,
"quoted text", docstring), "workbook <Tab> R<n>[–R<m>]", "<repo> <sha>", or "<url> (read YYYY-MM-DD)" where the URL
already appears in the research notes. A verbatim section's rows must equal its file line for line.

Safety (Director STOP-RULE 2026-10-01): sources are checked with lstat only; a path named *.env or .env* is refused and
never opened; only regular files are read. The secret scan prints the rule and the row, never the matched text.
Excel limits (support.microsoft.com, read 2026-10-01): sheet names 31 characters, none of / \\ ? * : [ ], no
apostrophe at either end, not "History"; a cell holds 32,767 characters and 253 line feeds. openpyxl drops shapes it
can't read, so the dry run compares every cell of every existing tab before anything is applied.
"""
import argparse, copy, csv, datetime, glob, hashlib, importlib.util, json, os, re, shutil, stat, statistics, subprocess, sys, tempfile

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

H = os.path.expanduser("~")
JOB = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(JOB))
TABS = f"{JOB}/tabs"
BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"
COPY = f"{H}/Documents/connectors-2026-09-30.xlsx"
DIRECTOR_TAB = f"{REPO}/work/2026-10-01_director-tab"
KIT = f"{H}/Alex-Director-splittest-kit"
ORDER = ["rebuild-from-zero.json", "glossary.json", "templates.json", "student-kit.json", "hermes-javar.json", "do-dont.json",
         "composio-1password.json", "onepassword-catalog.json", "skills-where.json", "decisions.json", "tests.json",
         "composio-routes.json", "ai-app-settings.json", "tailscale-policy.json", "ghl-rebuild.json", "tune-up.json",
         "director-home.json"]  # glossary.json: slot for the vocabulary research (r5-r6), built once it exists
DECISIONS_CSV = f"{JOB}/notes/decision-evidence.csv"
CORRECTIONS = f"{TABS}/corrections.json"
REPORT = f"{JOB}/notes/playbook-tabs-dryrun.md"
RESEARCH = sorted(glob.glob(f"{REPO}/work/2026-10-01_chatgpt-claude-research/notes/*.md")) + [
    f"{JOB}/notes/playbook-tabs.md", f"{JOB}/notes/decision-evidence.csv", f"{JOB}/notes/parity-diff-addendum.csv",
    f"{JOB}/notes/r5-r6-vocabulary-drift.md", f"{JOB}/notes/sources-17.md", f"{JOB}/notes/skill-size-rca.md",
    f"{JOB}/notes/skill-size-rca-vendor-guidance.md", f"{JOB}/notes/student-edition.md", f"{JOB}/notes/macos-app-data-prompt.md",
    f"{JOB}/notes/composio-1password-removal.md", f"{JOB}/notes/app-rules-redesign.md", f"{JOB}/notes/onepassword-vault-scope.md",
    f"{JOB}/notes/modal-connector.md", f"{JOB}/notes/huggingface-connector.md", f"{JOB}/notes/ir-notes-lookup-fix.md",
    f"{JOB}/notes/tool-card-v14.md", f"{JOB}/notes/housekeeping-final-a.md", f"{JOB}/notes/housekeeping-final-b.md",
    f"{JOB}/notes/spp-c17-chatgpt-write-approval.md", f"{JOB}/notes/c4d-code-fixes.md", f"{JOB}/notes/firecrawl-op-title.md",
    f"{JOB}/notes/spp-c18-partner-composio-access.md", f"{REPO}/work/2026-10-03_partner-robot/design.md"
    ] + sorted(glob.glob(f"{JOB}/notes/gap-facts*.md")) + sorted(glob.glob(f"{JOB}/notes/app-rules-research-*.csv"))
GIT = {"agents-home": f"{H}/.agents", "ghl-command-universal": f"{H}/Development/ghl-command-universal",
       "increase-roas-oauth-gateway": f"{H}/Development/increase-roas-oauth-gateway-hotfix",
       "master-connector-repo": REPO, "alex-director": f"{H}/Alex-Director"}
SKELETON = f"{H}/.agents/skills/repo-conform/assets/skeleton"
TEMPLATES = [  # (title, file under the skeleton, where it goes, limit, limit source)
    ("AGENTS.md: the project map", "AGENTS.md", "<project>/AGENTS.md",
     "Target 100 lines / 8,000 characters; cap 150 / 12,000", "workbook Limits R4"),
    ("CLAUDE.md: one line that imports the map", "CLAUDE.md", "<project>/CLAUDE.md",
     "Exactly the line @AGENTS.md (10 lines / 1,000 characters at most)", "workbook Limits R5"),
    ("STATUS.md: this week's state", "STATUS.md", "<project>/STATUS.md", "60 lines / 5,000 characters", "workbook Limits R6"),
    ("Tool card template", "tools/_card-template.md", "<project>/tools/<tool>.md (project-only tools)",
     "60 lines / 5,000 characters per tool family", "workbook Limits R8"),
    ("brief.md: the job brief", "work/_template/brief.md", "<project>/work/YYYY-MM-DD_job-name/brief.md",
     "Fill it before the job starts", "~/.agents/skills/repo-conform/assets/skeleton/AGENTS.md \"Start every task\""),
    ("checks.md: the proof a job is done", "work/_template/checks.md", "<project>/work/YYYY-MM-DD_job-name/checks.md",
     "Filled by verify-before-done", "~/.agents/skills/repo-conform/assets/skeleton/AGENTS.md \"Done means\""),
    ("notes/README.md: one file per helper", "work/_template/notes/README.md", "<project>/work/YYYY-MM-DD_job-name/notes/README.md",
     "Each helper writes only its own file", "~/.agents/skills/repo-conform/assets/skeleton/AGENTS.md \"Parallel agents\""),
    ("Project skills README: the rules for every skill", ".agents/skills/README.md", "<project>/.agents/skills/README.md",
     "Skill description 200 characters; SKILL.md target 60 lines / 5,000 characters", "workbook Limits R9 ; workbook Limits R12"),
]
TITLE = PatternFill("solid", fgColor="1F3864")
HEAD = PatternFill("solid", fgColor="D9E1F2")
TONE = {"PASS with gaps": "FFF2CC", "CLOSED": "E2EFDA", "DO": "E2EFDA", "SUPPORTED": "E2EFDA", "PARTLY": "FFF2CC", "QUALIFIED": "FFF2CC",
        "OPEN": "FCE4D6", "DON'T": "FCE4D6", "NOT_PROVEN": "FCE4D6", "CONTRADICTED": "FCE4D6", "NO EVIDENCE FOUND": "FCE4D6",
        "PROOF PENDING": "FFF2CC", "DEFERRED": "FFF2CC", "DONE": "E2EFDA",
        "PASS": "E2EFDA", "PENDING": "FFF2CC", "FAIL": "FCE4D6", "NOT TESTED": "FCE4D6", "FILLED": "FFF2CC"}
SECRET = [("1Password token", r"\bops_[A-Za-z0-9_-]{20,}"), ("OpenAI/Anthropic key", r"\bsk-[A-Za-z0-9_-]{16,}"),
          ("GitHub token", r"\b(?:ghp|gho|ghs|ghu)_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}"),
          ("Slack token", r"\bxox[abprs]-[A-Za-z0-9-]{10,}"), ("Google API key", r"\bAIza[0-9A-Za-z_-]{30,}"),
          ("AWS key", r"\bAKIA[0-9A-Z]{16}\b"), ("private key", r"-----BEGIN [A-Z ]*PRIVATE KEY"),
          ("JWT", r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\."), ("GHL private integration", r"\bpit-[0-9a-f]{8}-"),
          ("password or token assignment", r"(?i)\b(?:password|secret|token|api[_-]?key)\s*[:=]\s*['\"][^'\"\s]{12,}['\"]")]
OWN = {"increaseroas", "increase roas", "increaseroas account", "increaseroas master"}
EXCEL_BAD = set('/\\?*:[]')


def flat(v):
    return "" if v is None else str(v)


def rel(p):
    return p.replace(REPO + "/", "").replace(H, "~")


# ---------------------------------------------------------------- loading
def load_tabs():
    out = []
    for name in ORDER:
        p = f"{TABS}/{name}"
        if os.path.exists(p):
            out.append((name, json.load(open(p, encoding="utf-8"))))
    return out


# ---------------------------------------------------------------- source checks
PROTECTED = (f"{H}/Library/Containers", f"{H}/Library/Group Containers")


def protected(p):
    """Director STOP-RULE 2026-10-02: never read, list, grep, hash or copy anything under these folders (macOS asks Alex
    each time a command-line agent touches another app's private data)."""
    a = os.path.normpath(os.path.abspath(p))
    return any(a == x or a.startswith(x + "/") for x in PROTECTED)


def safe_path(raw):
    """Resolve a cited path without opening it. Returns (abs_path, kind) or (None, reason)."""
    p = os.path.expanduser(raw) if raw.startswith("~") else raw if raw.startswith("/") else os.path.join(REPO, raw)
    if protected(p):
        return None, "refused: another app's private folder (STOP-RULE, never touched)"
    base = os.path.basename(p.rstrip("/"))
    if base.endswith(".env") or base.startswith(".env"):
        return None, "refused: .env path (STOP-RULE)"
    try:
        st = os.lstat(p)
    except (FileNotFoundError, NotADirectoryError):
        return None, "missing"
    if stat.S_ISLNK(st.st_mode):
        if protected(os.path.join(os.path.dirname(p), os.readlink(p))):
            return None, "refused: a link into another app's private folder (STOP-RULE, never touched)"
        try:
            st = os.stat(p)
        except FileNotFoundError:
            return None, "broken link"
    if stat.S_ISREG(st.st_mode):
        return p, "file"
    if stat.S_ISDIR(st.st_mode):
        return p, "dir"
    return None, "not a regular file (refused, never opened)"


def read_text(p):
    return open(p, encoding="utf-8", errors="replace").read()


class Book:
    def __init__(self, path, new_tabs):
        wb = openpyxl.load_workbook(path, read_only=True)
        self.rows = {ws.title: ws.max_row for ws in wb.worksheets}
        wb.close()
        self.new = new_tabs


def check_locator(path, kind, loc, problems):
    if kind != "file" or not loc:
        return
    text = None
    for q in re.findall(r'"([^"]+)"', loc):
        text = text or read_text(path)
        if q.lower() not in text.lower():
            problems.append(f"quoted text not found in {rel(path)}: {q!r}")
    bare = re.sub(r'"[^"]*"', " ", loc)
    bare = re.sub(r"\([^)]*\)", " ", bare)
    rows_cited = re.findall(r"\brow ([A-Z]+\d+(?:-[A-Z]+\d+)?)\b", bare)
    bare_lines = re.sub(r"\brow [A-Z]+\d+(?:-[A-Z]+\d+)?\b", " ", bare)
    for a, b in re.findall(r"(?<![\w-])L(\d+)(?:[–-]L?(\d+))?(?![\w-])", bare_lines):
        text = text or read_text(path)
        n = text.count("\n") + (0 if text.endswith("\n") else 1)
        if int(b or a) > n:
            problems.append(f"{rel(path)} has {n} lines, cited L{b or a}")
    for sec in re.findall(r"§(\d+)", bare):
        text = text or read_text(path)
        if not re.search(rf"(?m)^#+\s*(?:§)?{sec}[.\s:)]", text):
            problems.append(f"{rel(path)} has no heading numbered {sec}")
    for rid in rows_cited:
        if path.endswith(".csv"):
            ids = {r[0] for r in csv.reader(open(path, encoding="utf-8")) if r}
            if rid not in ids:
                problems.append(f"{rel(path)} has no row {rid}")
    for lid in re.findall(r"\b(L-\d{3})\b", loc):
        text = text or read_text(path)
        if f"### {lid}" not in text:
            problems.append(f"{rel(path)} has no lesson {lid}")
    if "docstring" in bare and path.endswith(".py"):
        import ast
        if not ast.get_docstring(ast.parse(read_text(path))):
            problems.append(f"{rel(path)} has no docstring")


def norm_url(u):
    u = re.sub(r"^https?://", "", u.strip().rstrip(".,;)")).replace("www.", "")
    return u.rstrip("/")


_CORPUS = None


def corpus(book_path):
    global _CORPUS
    if _CORPUS is None:
        parts = [read_text(p) for p in RESEARCH if os.path.isfile(p)]
        wb = openpyxl.load_workbook(book_path, read_only=True)
        if "Evidence" in wb.sheetnames:
            for row in wb["Evidence"].iter_rows(values_only=True):
                parts.append(" ".join(flat(v) for v in row))
        wb.close()
        _CORPUS = re.sub(r"https?://", "", "\n".join(parts)).replace("www.", "")
    return _CORPUS


def check_source(src, book, book_path):
    problems = []
    if not flat(src).strip():
        return ["empty source"]
    for item in [s.strip() for s in re.split(r"\s;\s", flat(src)) if s.strip()]:
        url = re.search(r"https?://\S+", item)
        if url:
            if not re.search(r"\b\d{4}-\d{2}(?:-\d{2})?\b", item):  # a read date, or a publication month
                problems.append(f"URL without a read date: {item[:80]}")
            if norm_url(url.group(0)) not in corpus(book_path):
                problems.append(f"URL not in the research notes: {url.group(0)[:90]}")
            continue
        m = re.match(r"^workbook (.+?) R(\d+)(?:[–-]R?(\d+))?\b", item)
        if m:
            tab, last = m.group(1), int(m.group(3) or m.group(2))
            if tab in book.new:
                continue
            if tab not in book.rows:
                problems.append(f"no workbook tab {tab!r}")
            elif last > book.rows[tab]:
                problems.append(f"{tab} has {book.rows[tab]} rows, cited R{last}")
            continue
        m = re.match(r"^([a-z-]+) ([0-9a-f]{7,40})$", item)
        if m and m.group(1) in GIT:
            ok = subprocess.run(["git", "-C", GIT[m.group(1)], "cat-file", "-e", m.group(2) + "^{commit}"],
                                capture_output=True).returncode == 0
            if not ok:
                problems.append(f"commit not found: {item}")
            continue
        words = item.split(" ")
        found = None
        for k in range(len(words), 0, -1):
            cand = " ".join(words[:k])
            if not re.match(r"^(~/|/|[A-Za-z0-9_.-]+/|[A-Z][A-Za-z0-9_-]*\.(md|csv|json|py|txt|sh)$)", cand):
                continue
            path, kind = safe_path(cand)
            if path:
                found = (path, kind, " ".join(words[k:]))
                break
            if kind.startswith("refused") or kind.startswith("not a regular"):
                problems.append(f"{kind}: {cand}")
                found = ("", "", "")
                break
        if not found:
            problems.append(f"unrecognized or missing source: {item[:100]}")
        elif found[0]:
            check_locator(*found, problems)
    return problems


def client_names():
    names = set()
    p = f"{REPO}/knowledge/clients.md"
    for line in read_text(p).splitlines():
        if not line.startswith("|") or line.startswith("|---") or line.startswith("| Name") or line.startswith("| Company"):
            continue
        first = line.strip("|").split("|")[0]
        for n in re.split(r"[(),]", first):
            n = re.sub(r"\*", "", n).strip()
            if len(n) >= 5 and n.lower() not in OWN:
                names.add(n)
    return names


def scan_text(label, text, names, problems, warnings):
    for rule, rx in SECRET:
        if re.search(rx, text):
            problems.append(f"{label}: looks like a secret ({rule}); text not shown")
    for n in names:
        if re.search(r"(?<![A-Za-z])" + re.escape(n) + r"(?![A-Za-z])", text, re.I):
            problems.append(f"{label}: client name from knowledge/clients.md")
    for e in re.findall(r"[\w.+-]+@[\w-]+\.[\w.]+", text):
        if e.lower() not in {"alex@increaseroas.com"} and not e.lower().startswith("noreply@"):
            problems.append(f"{label}: email other than alex@increaseroas.com")
    if re.search(r"\bact_\d{6,}", text):
        problems.append(f"{label}: Meta ad account id")
    for tok in re.findall(r"\b[A-Za-z0-9]{20}\b", text):
        if re.search(r"[a-z]", tok) and re.search(r"[A-Z]", tok) and re.search(r"\d", tok):
            problems.append(f"{label}: looks like a GHL location id")
    if re.search(r"\b[a-z0-9]{26}\b", text) and len(re.findall(r"\d", " ".join(re.findall(r"\b[a-z0-9]{26}\b", text)))) >= 3:
        warnings.append(f"{label}: looks like a 1Password item id")
    if re.search(r"\(\d{3}\)\s?\d{3}-\d{4}|\+1\d{10}\b", text):
        problems.append(f"{label}: phone number")


def check_sheet_name(name):
    bad = []
    if not name or len(name) > 31:
        bad.append("longer than 31 characters")
    if EXCEL_BAD & set(name):
        bad.append(f"has {''.join(sorted(EXCEL_BAD & set(name)))}")
    if name.startswith("'") or name.endswith("'") or name.lower() == "history":
        bad.append("apostrophe at an end, or History")
    return bad


def cmd_check(book_path=BOOK, quiet=False):
    tabs = load_tabs()
    names = client_names()
    book = Book(book_path, {t["tab"] for _, t in tabs})
    problems, warnings, unsourced, counts, expected = [], [], [], [], []
    for fname, t in tabs:
        for b in check_sheet_name(t["tab"]):
            problems.append(f"{fname}: sheet name {t['tab']!r} {b}")
        if t.get("insert_after") not in book.rows and t.get("insert_after") not in book.new:
            problems.append(f"{fname}: insert_after {t.get('insert_after')!r} is not a tab")
        scan_text(f"{fname} intro", t.get("intro", ""), names, problems, warnings)
        n = 0
        for si, s in enumerate(t["sections"], 1):
            if s.get("verbatim_from"):
                path, kind = safe_path(s["verbatim_from"])
                if not path or kind != "file":
                    problems.append(f"{fname} §{si}: verbatim source {kind}")
                    continue
                lines = read_text(path).split("\n")
                if lines and lines[-1] == "":
                    lines = lines[:-1]
                if [r[1] for r in s["rows"]] != lines:
                    problems.append(f"{fname} §{si}: rows differ from {rel(path)} (run: build_tabs.py templates)")
                scan_text(f"{fname} §{si}", "\n".join(lines), names, problems, warnings)
                n += len(s["rows"])
                continue
            if s.get("listing"):
                if s["rows"] != listing_rows(s["listing"]):
                    problems.append(f"{fname} §{si}: listing differs from the folders now (run: build_tabs.py templates)")
                for p in check_source(s.get("source"), book, book_path):
                    problems.append(f"{fname} §{si} source: {p}")
                n += len(s["rows"])
                continue
            hdr = s["header"]
            sc = hdr.index(s["source_col"]) if s.get("source_col") in hdr else len(hdr) - 1
            if s.get("source_col") and s["source_col"] not in hdr:
                problems.append(f"{fname} §{si}: source_col {s['source_col']!r} is not a header")
            elif not s.get("source_col") and hdr[-1] != "source":
                problems.append(f"{fname} §{si}: last header is {hdr[-1]!r}, not 'source'")
            for ri, row in enumerate(s["rows"], 1):
                label = f"{fname} §{si} row {ri}"
                if len(row) != len(hdr):
                    problems.append(f"{label}: {len(row)} cells for {len(hdr)} columns")
                for v in row:
                    if len(flat(v)) > 32767 or flat(v).count("\n") > 253:
                        problems.append(f"{label}: cell over Excel's limit")
                scan_text(label, " ".join(flat(v) for i, v in enumerate(row) if i != sc), names, problems, warnings)
                for p in check_source(row[sc] if len(row) > sc else "", book, book_path):
                    problems.append(f"{label}: {p}")
                n += 1
        if fname == "decisions.json" and os.path.exists(DECISIONS_CSV) and t["sections"] != decisions_doc()["sections"]:
            problems.append("decisions.json differs from notes/decision-evidence.csv (run: build_tabs.py decisions)")
        counts.append((t["tab"], len(t["sections"]), n))
        unsourced += [(t["tab"], u) for u in t.get("unsourced", [])]
        for rule in t.get("expected_warnings", {}):
            mine = [w for w in warnings if w.startswith(f"{fname} ") and w.endswith(f": {rule}")]
            expected.extend(mine)
            warnings[:] = [w for w in warnings if w not in mine]
    st = json.load(open(f"{DIRECTOR_TAB}/notes/skills-map.json", encoding="utf-8")).get("split_test", {})
    for part in ("summary", "scenarios", "how"):
        for i, row in enumerate(st.get(part, []), 1):
            for p in check_source(row[-1], book, book_path):
                problems.append(f"skills-map.json split_test {part} row {i}: {p}")
    if os.path.exists(CORRECTIONS):
        cj = json.load(open(CORRECTIONS, encoding="utf-8"))
        for i, e in enumerate(cj["edits"], 1):
            for p in check_source(e.get("source"), book, book_path):
                problems.append(f"corrections.json edit {i}: {p}")
            scan_text(f"corrections.json edit {i}", flat(e.get("new")) + flat(e.get("append")) + flat((e.get("replace") or ["", ""])[1]),
                      names, problems, warnings)
        for i, a in enumerate(cj.get("append_rows", []), 1):
            for p in check_source(a.get("source"), book, book_path):
                problems.append(f"corrections.json append {i}: {p}")
            scan_text(f"corrections.json append {i}", " ".join(flat(v) for v in a["row"]), names, problems, warnings)
        for i, a in enumerate(cj.get("insert_rows", []), 1):
            for p in check_source(a.get("source"), book, book_path):
                problems.append(f"corrections.json insert {i}: {p}")
            if a["tab"] not in book.rows or a["before"] > book.rows[a["tab"]] + 1 or a["style_from"] > book.rows[a["tab"]]:
                problems.append(f"corrections.json insert {i}: row {a['before']} or template row {a['style_from']} is outside {a['tab']}")
            if not any(a["marker"] in flat(v) for v in a["cells"]):
                problems.append(f"corrections.json insert {i}: marker not in the new cells")
            scan_text(f"corrections.json insert {i}", " ".join(flat(v) for v in a["cells"]), names, problems, warnings)
        for i, a in enumerate(cj.get("fill_rows", []), 1):
            for p in check_source(a.get("source"), book, book_path):
                problems.append(f"corrections.json fill {i}: {p}")
            if a["tab"] not in book.rows or a["row"] > book.rows[a["tab"]] or a["style_from"] > book.rows[a["tab"]]:
                problems.append(f"corrections.json fill {i}: row {a['row']} or template row {a['style_from']} is outside {a['tab']}")
            if not any(a["marker"] in flat(v) for v in a["cells"]):
                problems.append(f"corrections.json fill {i}: marker not in the new cells")
            scan_text(f"corrections.json fill {i}", " ".join(flat(v) for v in a["cells"]), names, problems, warnings)
    if not quiet:
        for tab, ns, n in counts:
            print(f"{tab}: {ns} sections, {n} rows")
        print(f"\nPROBLEMS ({len(problems)})" + "".join(f"\n- {p}" for p in problems))
        print(f"\nWARNINGS ({len(warnings)})" + "".join(f"\n- {w}" for w in warnings))
        if expected:
            by = {}
            for w in expected:
                key = (w.split(" ")[0], w.rsplit(": ", 1)[1])
                by[key] = by.get(key, 0) + 1
            print(f"\nEXPECTED WARNINGS ({len(expected)}), named in each tab's expected_warnings with the reason:" +
                  "".join(f"\n- {f}: {n} x {rule}" for (f, rule), n in sorted(by.items())))
        print(f"\nCLAIMS WITH NO SOURCE YET ({len(unsourced)}), for the Director to research:" +
              "".join(f"\n- [{t}] {u}" for t, u in unsourced))
    return problems, warnings, unsourced, counts


# ---------------------------------------------------------------- generators
def tree(root, skip=()):
    out = []
    for dirpath, dirs, files in os.walk(root):
        shown = sorted(d for d in dirs if d != "__pycache__")
        dirs[:] = [d for d in shown if d not in skip]
        depth = os.path.relpath(dirpath, root).count(os.sep) + (0 if dirpath == root else 1)
        if dirpath != root:
            out.append("    " * (depth - 1) + os.path.basename(dirpath) + "/")
        for f in sorted(files):
            if f.endswith(".env") or f.startswith(".env") or f == ".DS_Store":
                continue
            if not stat.S_ISREG(os.lstat(os.path.join(dirpath, f)).st_mode):
                continue
            out.append("    " * depth + f)
        for d in shown:
            if d in skip:
                out.append("    " * depth + d + "/  (contents not shown)")
    return out


DEC_COLS = [("id", "id"), ("verdict", "verdict"), ("priority", "priority"), ("decision", "decision"),
            ("what the evidence suggests instead", "evidence_suggests_instead"), ("best evidence", "best_evidence"),
            ("why it was decided", "why_decided"), ("evidence type", "evidence_type"), ("source title", "source_title"),
            ("other sources", "other_sources"), ("note", "note"), ("found in", "found_in"), ("group", "group")]


def decisions_doc():
    rows = list(csv.DictReader(open(DECISIONS_CSV, encoding="utf-8")))
    src_csv = rel(DECISIONS_CSV)

    def row(r):
        date = r["source_date"].strip()
        url = r["source_url"].strip()
        first = (f"{url} {date}" if "(" in date else f"{url} ({date})") if url else ""
        local = list(dict.fromkeys(re.findall(r'(?:work|~/Alex-Director)/[^\s;,()"]+\.(?:md|csv)(?: L\d+(?:[–-]L\d+)?| "[^"]+")?', r["other_sources"])  # local notes it names, with a line or quoted locator
                                   + re.findall(r"\b(?:" + "|".join(GIT) + r") [0-9a-f]{7,40}\b", r["other_sources"])))  # and commits
        return [r[k] for _, k in DEC_COLS] + [" ; ".join(x for x in (first, *local, f"{src_csv} row {r['id']}") if x)]

    hdr = [h for h, _ in DEC_COLS] + ["source"]
    act = [r for r in rows if r["verdict"] == "CONTRADICTED"] + [r for r in rows if r["verdict"] == "NO EVIDENCE FOUND"]
    pending = [r for r in rows if r["verdict"] in ("PROOF PENDING", "DEFERRED")]
    sections = [{"title": "1. Act on these first: the evidence contradicts the decision, or found nothing for it",
                 "header": hdr, "rows": [row(r) for r in act]}]
    if pending:
        sections.append({"title": "2. Decided, not done yet: PROOF PENDING or DEFERRED (see \"what the evidence suggests instead\")",
                         "header": hdr, "rows": [row(r) for r in pending]})
    done = [r for r in rows if r["verdict"] == "DONE"]
    if done:
        sections.append({"title": f"{len(sections) + 1}. Done: the decision, or the alternative the evidence suggested, is in place and proven (see \"note\")",
                         "header": hdr, "rows": [row(r) for r in done]})
    n = len(sections)
    sections += [{"title": f"{n + 1}. Supported with a condition (QUALIFIED): read \"what the evidence suggests instead\"",
                  "header": hdr, "rows": [row(r) for r in rows if r["verdict"] == "QUALIFIED"]},
                 {"title": f"{n + 2}. Supported by the evidence (SUPPORTED)", "header": hdr,
                  "rows": [row(r) for r in rows if r["verdict"] == "SUPPORTED"]}]
    known = ("CONTRADICTED", "NO EVIDENCE FOUND", "QUALIFIED", "SUPPORTED", "PROOF PENDING", "DEFERRED", "DONE")
    other = [r["id"] for r in rows if r["verdict"] not in known]
    if other:
        sections.append({"title": f"{len(sections) + 1}. Other verdicts", "header": hdr,
                         "rows": [row(r) for r in rows if r["id"] in other]})
    return {"tab": "Decisions and why", "insert_after": "Skills, where they live",
            "intro": ("Each setup decision made on 2026-10-01 (Alex's 28 decisions plus the later ones), the best evidence for "
                      "or against it, and where that evidence comes from. Verdicts: SUPPORTED (the evidence backs it), "
                      "QUALIFIED (it holds with a condition: read \"what the evidence suggests instead\"), CONTRADICTED (the "
                      "evidence points the other way), NO EVIDENCE FOUND, PROOF PENDING (decided, not proven yet), DEFERRED (decided, waiting on purpose) and DONE (in place and proven; the note says what was done). The rows that need action come first. Loaded from "
                      f"{src_csv} (the Director's research) by work/2026-10-01_setup-playbook/build_tabs.py decisions; edit the "
                      "CSV, never this tab."),
            "widths": [9, 17, 8, 44, 48, 48, 34, 14, 30, 36, 20, 30, 10, 40], "sections": sections, "unsourced": []}


def cmd_decisions():
    doc = decisions_doc()
    json.dump(doc, open(f"{TABS}/decisions.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("decisions.json: " + ", ".join(f"{s['title'].split(':')[0]} {len(s['rows'])} rows" for s in doc["sections"]))


def listing_rows(kind):
    if kind == "project":
        lines = tree(SKELETON)
    else:
        lines = ["<skill-name>/                 folder name = the skill's name (lowercase, hyphens, 64 characters or fewer)",
                 "    SKILL.md                  settings block (name, description of 200 characters or fewer) + the steps",
                 "    references/               optional: detail opened only when SKILL.md points to it (one level deep)",
                 "    scripts/                  optional: code the steps run",
                 "    assets/                   optional: templates or files the steps copy", "",
                 "Example: ~/.agents/skills/fan-out/"] + ["    " + l for l in tree(f"{H}/.agents/skills/fan-out")] + [
                 "", "Example: ~/.agents/skills/repo-conform/ (the two assets/ folders are shown without their contents)"] + [
                 "    " + l for l in tree(f"{H}/.agents/skills/repo-conform", skip=("skeleton", "universal-skills"))]
    return [[i, l] for i, l in enumerate(lines, 1)]


def cmd_templates():
    sk = rel(SKELETON)
    what = {"AGENTS.md": "The one copy of the project's rules: what the project is, where things go, which skill for which job, the tools table with the Composio route per app, the rules that don't bend and the Spend approval line.",
            "CLAUDE.md": "One line, @AGENTS.md, so Claude Code loads the same rules Codex and Cursor read directly.",
            "STATUS.md": "Current focus, work in progress, what waits on the owner, blockers and the last five things done. Read first, updated last.",
            "tools/_card-template.md": "One page per tool: the one route, account, risk tier, approval setting, key tools, quirks and fixes. Never keys.",
            "work/_template/brief.md": "Goal, audience, \"done means\" lines anyone can check, the facts allowed, approvals needed and open questions.",
            "work/_template/checks.md": "The table of checks against the brief, one negative check, what couldn't be checked and the verdict.",
            "work/_template/notes/README.md": "Why each helper agent writes only its own notes file, and what a notes file holds.",
            ".agents/skills/README.md": "Who reads which skills folder, when a project skill earns a place, the rules for every skill and the Claude app upload steps."}
    rows = []
    for title, f, where, limit, lsrc in TEMPLATES:
        rows.append([title, what[f], where, limit, f"{sk}/{f} ; {lsrc}"])
    rows.append(["Global tool card (every project)",
                 "The cards every AI shares live in ~/.agents/tools/cards/<app>.md. Their settings block (frontmatter) has route, logins, aliases, index (at most 70 characters, the hosted description's cut; it feeds the hosted notes tool's description, while the always-loaded App rules block names every card), tasks and updated. The body follows the card template: Before the first call (route, never, ask Alex first), How to call, Facts, Failure and fix.",
                 "~/.agents/tools/cards/<app>.md, then commit ~/.agents", "60 lines / 5,000 characters",
                 "work/2026-10-01_setup-playbook/candidates/app-rules/card-template.md L1–L8 ; work/2026-10-01_setup-playbook/candidates/app-rules/card-template.md L33–L36 ; ~/.agents/tools/connectors/cards_to_sheet.py docstring ; workbook Limits R8"])
    rows.append(["Project folder layout", "Every file the blueprint creates, as a tree (section 2).", "<project>/",
                 "Names: lowercase, hyphens, ISO date first, 50 characters or fewer",
                 f"{sk} ; {sk}/AGENTS.md \"Where things go\""])
    rows.append(["Skill folder layout", "How one skill is laid out, with two real examples (section 3).", "~/.agents/skills/<name>/ or <project>/.agents/skills/<name>/",
                 "Name 64 characters, same as the folder; references/ one level deep, 300 lines / 25,000 characters each",
                 "~/.agents/skills/repo-conform/assets/skeleton/.agents/skills/README.md \"Rules for every skill\" ; workbook Limits R10 ; workbook Limits R11"])
    sections = [{"title": "1. What each template is", "header": ["template", "what it is", "where it goes", "limit", "source"], "rows": rows}]
    sections.append({"title": f"2. Project folder layout (from {sk})", "header": ["#", "file or folder"], "listing": "project",
                     "source": f"{sk} ; {sk}/AGENTS.md \"Where things go\"", "rows": listing_rows("project")})
    sections.append({"title": "3. Skill folder layout (the rules are in section 11; two real examples follow the pattern)",
                     "header": ["#", "file or folder"], "listing": "skills",
                     "source": f"{sk}/.agents/skills/README.md \"Rules for every skill\" ; ~/.agents/skills/fan-out ; ~/.agents/skills/repo-conform",
                     "rows": listing_rows("skills")})
    for i, (title, f, where, _, _) in enumerate(TEMPLATES, 4):
        p = f"{SKELETON}/{f}"
        lines = read_text(p).split("\n")
        if lines and lines[-1] == "":
            lines = lines[:-1]
        sections.append({"title": f"{i}. {title}: copy column B into {where}", "verbatim_from": f"{sk}/{f}",
                         "header": ["line", "text (copy this column)"], "rows": [[n, l] for n, l in enumerate(lines, 1)]})
    doc = {"tab": "Templates", "insert_after": "Rebuild from zero",
           "intro": ("The files a student copies to start a project the way Alex's are built: the AGENTS.md map and its one-line "
                     "CLAUDE.md, STATUS.md, the tool card, the job brief and checks, and the folder layouts for a project and a "
                     "skill. Sections 4 onward are the files line by line from the repo-conform blueprint "
                     f"({sk}); select column B of a section and paste it into the file. Replace every [bracketed placeholder]; "
                     "there is no client data here. Built by work/2026-10-01_setup-playbook/build_tabs.py from tabs/templates.json "
                     "(regenerate with build_tabs.py templates); never edit this tab by hand."),
           "widths": [30, 100, 40, 34, 46], "sections": sections, "unsourced": []}
    old = f"{TABS}/templates.json"
    if os.path.exists(old):  # sections marked "extra" (e.g. the chat-app blocks, G17) come from other sources: keep them
        sections += [s for s in json.load(open(old, encoding="utf-8"))["sections"] if s.get("extra")]
    json.dump(doc, open(f"{TABS}/templates.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"templates.json: {len(sections)} sections, {sum(len(s['rows']) for s in sections)} rows")


def cmd_splittest():
    runs = []
    for f, rcol in (("results.csv", "pass_"), ("results2.csv", "result")):
        for r in csv.DictReader(open(f"{KIT}/{f}", encoding="utf-8")):
            runs.append({"id": r["id"], "round": r["id"].split("-")[0], "arm": r["arm"], "s": int(r["scenario"][1:]),
                         "result": r[rcol], "auto": r["auto"], "total": int(r["total"]), "uncached": int(r["uncached"]),
                         "file": f})
    md = read_text(f"{KIT}/SPLIT-TEST.md")
    scen = {}
    for line in md.splitlines():
        m = re.match(r"^\| ([1-8]) \| (.+?) \| (.+?) \| (.+?) \| (.+?) \|$", line)
        if m:
            scen[int(m.group(1))] = [re.sub(r"`", "", g) for g in m.groups()[1:]]
    rule = re.search(r"\*\*Rule:\*\* (.+?)(?:\n\n)", md, re.S).group(1).replace("\n", " ")
    rule = rule.replace("(bottom of this file)", "(steps at the bottom of SPLIT-TEST.md)")
    src_runs = "~/Alex-Director-splittest-kit/results.csv ; ~/Alex-Director-splittest-kit/results2.csv"
    src_md = "~/Alex-Director-splittest-kit/SPLIT-TEST.md"
    arm_name = {"new": "v2 (new)", "old": "old (before v2)"}
    summary = []
    for arm in ("new", "old"):
        a = [r for r in runs if r["arm"] == arm]
        c = {k: sum(1 for r in a if r["result"] == k) for k in ("PASS", "FAIL", "UNVERIFIABLE")}
        maj = sum(1 for s in range(1, 9) if sum(1 for r in a if r["s"] == s and r["result"] == "PASS") >= 2)
        fails = ", ".join(sorted(r["id"] for r in a if r["result"] == "FAIL")) or "none"
        summary.append([arm_name[arm], f"{len(a)} runs: {c['PASS']} pass, {c['FAIL']} fail, {c['UNVERIFIABLE']} could not be scored",
                        f"{maj} of 8", f"{statistics.median(r['total'] for r in a):,.0f}",
                        f"{statistics.median(r['uncached'] for r in a):,.0f}", f"failed runs: {fails}", src_runs])
    per = []
    for s in range(1, 9):
        cell = {}
        for arm in ("old", "new"):
            rs = sorted((r for r in runs if r["arm"] == arm and r["s"] == s), key=lambda r: r["round"])
            cell[arm] = ", ".join(r["result"].replace("UNVERIFIABLE", "not scored") for r in rs)
            cell[arm + "_tok"] = statistics.median(r["total"] for r in rs)
        situation, change, auto, manual = scen[s]
        per.append([str(s), situation, change, cell["old"], cell["new"],
                    f"{cell['old_tok']:,.0f} → {cell['new_tok']:,.0f} ({(cell['new_tok'] / cell['old_tok'] - 1) * 100:+.0f}%)",
                    f"{src_md} ; {src_runs}"])
    passed = {arm: sum(1 for s in range(1, 9) if sum(1 for r in runs if r["arm"] == arm and r["s"] == s
                                                     and r["result"] == "PASS") >= 2) for arm in ("new", "old")}
    med = {arm: statistics.median(r["total"] for r in runs if r["arm"] == arm) for arm in ("new", "old")}
    worse = [f"{s} ({(t2 / t1 - 1) * 100:+.0f}%)" for s, t1, t2 in
             [(s, statistics.median(r["total"] for r in runs if r["arm"] == "old" and r["s"] == s),
               statistics.median(r["total"] for r in runs if r["arm"] == "new" and r["s"] == s)) for s in range(1, 9)]
             if t2 > t1]
    verdict = (f"Adopt v2. It passed {passed['new']} of 8 situations (2 of 3 runs or more) against old's {passed['old']} of 8, "
               f"and its median tokens per run were {med['new']:,.0f} against {med['old']:,.0f} "
               f"({(med['new'] / med['old'] - 1) * 100:+.0f}%). v2 used more tokens on situation "
               + (", ".join(worse) if worse else "none") + "."
               if passed["new"] >= passed["old"] and med["new"] < med["old"] else "Do not adopt: the rule is not met.")
    how = [["The rule written before the test", rule, src_md],
           ["What the numbers say", verdict, src_runs],
           ["How a run was scored", "A run passes only if both the automatic checks and every manual box pass. Three runs per arm per scenario; all 8 scenarios on one arm, then the other, three rounds.", src_md],
           ["Tokens per run", "total = input tokens (cached included) + output tokens for the turn; uncached = input - cached + output. Read from the turn's usage line in each run's log.", f"{src_md} ; ~/Alex-Director-splittest-kit/summ.py ; work/2026-10-01_setup-playbook/notes/playbook-tabs.md §6"],
           ["Where it ran", "A throwaway copy (~/Alex-Director-splittest) with two fake missions, Alpha and Bravo; the real ledger was never touched. Results were logged 2026-09-30.", f"{src_md} ; work/2026-10-01_setup-playbook/notes/playbook-tabs.md §6"],
           ["Read it honestly", "Three runs per cell is small: one run's gap on one scenario is noise; a gap across several scenarios, or one arm failing all three, is signal. Some automatic checks were overridden after reading the reply (PASS*), as noted in results2.csv.", f"{src_md} ; {src_runs}"],
           ["Rerun it", "~/Alex-Director-splittest-kit/kit.sh setup, then use old|new, start N, check N, log, report; always finish with kit.sh use new.", src_md]]
    m_path = f"{DIRECTOR_TAB}/notes/skills-map.json"
    text = read_text(m_path)
    json.loads(text)
    block = {"summary": summary, "scenarios": per, "how": how,
             "generated_by": "work/2026-10-01_setup-playbook/build_tabs.py splittest"}
    cut = text.find(',\n  "split_test":')  # the block is always the last key; the hand-formatted rest stays byte-identical
    base = text[:cut] if cut >= 0 else text.rstrip()[:-1].rstrip()
    new = base + ',\n  "split_test": ' + json.dumps(block, ensure_ascii=False, indent=1).replace("\n", "\n  ") + "\n}\n"
    assert json.loads(new)["split_test"] == block
    tmp = m_path + ".tmp"
    open(tmp, "w", encoding="utf-8").write(new)
    os.replace(tmp, m_path)
    for row in summary:
        print(" | ".join(row[:6]))
    print(verdict)


# ---------------------------------------------------------------- building
def style_title(ws, r, ncol, text):
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
    c = ws.cell(r, 1, text)
    c.font, c.fill = Font(bold=True, color="FFFFFF", size=12), TITLE
    c.alignment = Alignment(wrap_text=True, vertical="top")


def put(ws, r, c, v, src=False):
    cell = ws.cell(r, c)
    cell.value = v
    if isinstance(v, str) and v.startswith("="):
        cell.data_type = "s"  # never a formula
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    if src:
        cell.font = Font(size=9, color="595959")
    elif isinstance(v, str):
        tone = next((k for k in TONE if v == k or v.startswith(k + " ") or v.startswith(k + ":") or v.startswith(k + " (")), None)
        if tone:
            cell.fill = PatternFill("solid", fgColor=TONE[tone])
    return cell


def build_tab(wb, t, prev):
    name = t["tab"]
    old_index = wb.sheetnames.index(name) if name in wb.sheetnames else None
    if old_index is not None:
        del wb[name]
    after = prev or t["insert_after"]
    index = old_index if old_index is not None else wb.sheetnames.index(after) + 1
    ws = wb.create_sheet(name, index=index)
    widths = t["widths"]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ncol = len(widths)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    c = ws.cell(1, 1, t["intro"])
    c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[1].height = 80
    r = 3
    for s in t["sections"]:
        src = s.get("source") or s.get("verbatim_from")
        style_title(ws, r, ncol, s["title"] + (f"   [source: {src}]" if src else ""))
        r += 1
        for i, h in enumerate(s["header"], 1):
            hc = ws.cell(r, i, h)
            hc.font, hc.fill = Font(bold=True), HEAD
            hc.alignment = Alignment(wrap_text=True, vertical="top")
        r += 1
        verbatim = bool(s.get("verbatim_from") or s.get("listing"))
        sc = s["header"].index(s["source_col"]) + 1 if s.get("source_col") else len(s["header"])
        for row in s["rows"]:
            for i, v in enumerate(row, 1):
                cell = put(ws, r, i, v, src=(not verbatim and i == sc))
                if verbatim and i == 2:
                    cell.font = Font(name="Menlo", size=10)
            r += 1
        r += 1
    ws.freeze_panes = "A2"
    return ws, r - 1


def apply_corrections(wb, log):
    if not os.path.exists(CORRECTIONS):
        return 0
    n = 0
    edits = json.load(open(CORRECTIONS, encoding="utf-8"))["edits"]

    def is_done(e, old):
        return (old == e["new"] if "new" in e else
                (e["replace"][1] in old and (e["replace"][0] not in old or e["replace"][0] in e["replace"][1])) if "replace" in e else
                e["append"].strip() in old)

    for k, e in enumerate(edits):
        ws = wb[e["tab"]]
        col = openpyxl.utils.column_index_from_string(e["col"])
        where = f"{e['tab']} R{e['row']} {e['col']}"
        hrow = int(e.get("header_row", 1))
        if e.get("header") is not None and flat(ws.cell(hrow, col).value) != e["header"]:
            log.append(f"SKIP {where}: header is {flat(ws.cell(hrow, col).value)!r}, expected {e['header']!r}")
            continue
        old = flat(ws.cell(e["row"], col).value)
        if is_done(e, old):
            log.append(f"same {where}: already applied")
            continue
        later = [x for x in edits[k + 1:] if (x["tab"], x["row"], x["col"]) == (e["tab"], e["row"], e["col"])]
        if any(is_done(x, old) for x in later):
            log.append(f"same {where}: superseded by a later edit that is already applied")
            continue
        if e.get("expect") is not None and e["expect"] not in old:
            log.append(f"SKIP {where}: cell changed since the correction was written (expected text not found); kept as is")
            continue
        if "replace" in e:
            frm, to = e["replace"]
            if old.count(frm) != 1:
                log.append(f"SKIP {where}: the text to replace appears {old.count(frm)} times; kept as is")
                continue
            new = old.replace(frm, to)
        elif "append" in e:
            if e["append"].strip() in old:
                log.append(f"same {where}: already has the appended text")
                continue
            new = (old + " " + e["append"]).strip()
        else:
            new = e["new"]
        if old == new:
            log.append(f"same {where}")
            continue
        ws.cell(e["row"], col).value = new
        n += 1
        log.append(f"EDIT {where}: {old[:70]!r} -> {new[:70]!r}")
    for a in json.load(open(CORRECTIONS, encoding="utf-8")).get("append_rows", []):
        ws = wb[a["tab"]]
        if any(a["marker"] in flat(c.value) for row in ws.iter_rows() for c in row):
            log.append(f"same {a['tab']}: a row with {a['marker']!r} is already there")
            continue
        r, last = ws.max_row + 1, ws.max_row
        for i, v in enumerate(a["row"], 1):
            cell = ws.cell(r, i, v)
            tmpl = ws.cell(last, i)
            if tmpl.has_style:
                cell.font, cell.alignment = copy.copy(tmpl.font), copy.copy(tmpl.alignment)
        n += 1
        log.append(f"APPEND {a['tab']} R{r}: {flat(a['row'][1])[:70]!r}")
    for a in json.load(open(CORRECTIONS, encoding="utf-8")).get("fill_rows", []):
        ws, r, t = wb[a["tab"]], a["row"], a["style_from"]
        cur = [flat(ws.cell(r, i).value) for i in range(1, max(ws.max_column, len(a["cells"])) + 1)]
        if any(a["marker"] in v for v in cur):
            log.append(f"same {a['tab']} R{r}: already filled")
            continue
        if any(v.strip() for v in cur):
            log.append(f"SKIP {a['tab']} R{r}: the row is no longer empty; kept as is")
            continue
        for i, v in enumerate(a["cells"], 1):
            cell, tmpl = ws.cell(r, i, v), ws.cell(t, i)
            if tmpl.has_style:
                cell.font, cell.alignment = copy.copy(tmpl.font), copy.copy(tmpl.alignment)
                cell.fill, cell.border = copy.copy(tmpl.fill), copy.copy(tmpl.border)
        if ws.row_dimensions[t].height:
            ws.row_dimensions[r].height = ws.row_dimensions[t].height
        n += 1
        log.append(f"FILL {a['tab']} R{r}: {flat(a['cells'][0])[:70]!r}")
    for a in json.load(open(CORRECTIONS, encoding="utf-8")).get("insert_rows", []):
        ws, b, t = wb[a["tab"]], a["before"], a["style_from"]
        if any(a["marker"] in flat(c.value) for row in ws.iter_rows() for c in row):
            log.append(f"same {a['tab']}: a row with {a['marker']!r} is already there")
            continue
        if flat(ws.cell(b, openpyxl.utils.column_index_from_string(a["anchor_col"])).value) != a["anchor"]:
            log.append(f"SKIP {a['tab']} insert before R{b}: that row no longer starts with {a['anchor']!r}; nothing inserted")
            continue
        if ws.merged_cells.ranges:
            log.append(f"SKIP {a['tab']} insert before R{b}: the tab has merged cells; nothing inserted")
            continue
        heights = {r: ws.row_dimensions[r].height for r in range(b, ws.max_row + 1)}
        ws.insert_rows(b)
        for r, h in heights.items():
            ws.row_dimensions[r + 1].height = h
        ws.row_dimensions[b].height = ws.row_dimensions[t].height
        for i, v in enumerate(a["cells"], 1):
            cell, tmpl = ws.cell(b, i, v), ws.cell(t, i)
            if tmpl.has_style:
                cell.font, cell.alignment = copy.copy(tmpl.font), copy.copy(tmpl.alignment)
                cell.fill, cell.border = copy.copy(tmpl.fill), copy.copy(tmpl.border)
        n += 1
        log.append(f"INSERT {a['tab']} R{b}: {flat(a['cells'][0])[:70]!r} (rows below moved down by one)")
    return n


def load_build_tab():
    spec = importlib.util.spec_from_file_location("build_tab", f"{DIRECTOR_TAB}/build_tab.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run_build_decisions(book_path, out_csv):
    """Regenerate App decisions with work/2026-10-01_app-decisions/build_decisions.py, unchanged except for three lines
    swapped in memory: which workbook, where its CSV twin goes, and no copy to ~/Documents (build_tabs.py copies)."""
    path = f"{REPO}/work/2026-10-01_app-decisions/build_decisions.py"
    src = read_text(path)
    for a, b in [('BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"', f"BOOK = {book_path!r}"),
                 ('OUT = f"{REPO}/work/2026-10-01_app-decisions/app-decisions.csv"', f"OUT = {out_csv!r}"),
                 ('if os.path.isdir(os.path.expanduser("~/Documents")):', "if False:  # build_tabs.py copies to ~/Documents")]:
        if src.count(a) != 1:
            sys.exit(f"Refused: build_decisions.py changed ({a[:50]}...); update run_build_decisions first.")
        src = src.replace(a, b)
    exec(compile(src, path, "exec"), {"__name__": "__main__", "__file__": path})


def build_all(book_path, decisions_csv):
    log = []
    wb = openpyxl.load_workbook(book_path)
    log.append(f"corrections applied: {apply_corrections(wb, log)}")
    n = load_build_tab().build_sheet(wb)
    log.append(f"Director + Conductor rebuilt: {n} rows")
    prev = None
    for fname, t in load_tabs():
        ws, rows = build_tab(wb, t, None if t.get("standalone") else prev)  # a standalone tab sits after its own insert_after
        if not t.get("standalone"):
            prev = t["tab"]
        log.append(f"{t['tab']}: {rows} rows (from tabs/{fname})")
    wb.save(book_path)
    run_build_decisions(book_path, decisions_csv)
    log.append(f"App decisions regenerated by build_decisions.py (CSV twin: {rel(decisions_csv)})")
    spec = importlib.util.spec_from_file_location("cards_to_sheet", f"{H}/.agents/tools/connectors/cards_to_sheet.py")
    cts = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cts)
    log.append(f"Tool cards regenerated by cards_to_sheet.py: {cts.build(book_path)} cards")
    return log


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def grid(ws):
    return {(c.row, c.column): c.value for row in ws.iter_rows() for c in row if c.value is not None}


def compare(master, built):
    a, b = openpyxl.load_workbook(master), openpyxl.load_workbook(built)
    lines, edits = [], {}
    appended = {}
    if os.path.exists(CORRECTIONS):
        cj = json.load(open(CORRECTIONS, encoding="utf-8"))
        for e in cj["edits"]:
            edits.setdefault(e["tab"], set()).add((e["row"], openpyxl.utils.column_index_from_string(e["col"])))
        for x in cj.get("append_rows", []):
            appended[x["tab"]] = appended.get(x["tab"], 0) + 1
        for x in cj.get("fill_rows", []):
            edits.setdefault(x["tab"], set()).update((x["row"], i) for i in range(1, len(x["cells"]) + 1))
        inserts = {}
        for x in cj.get("insert_rows", []):
            inserts.setdefault(x["tab"], []).append(x)
    else:
        inserts = {}
    built = {t["tab"] for _, t in load_tabs()}
    for name in a.sheetnames:
        if name in built and name in b.sheetnames:
            ga, gb = grid(a[name]), grid(b[name])
            n = sum(1 for k in set(ga) | set(gb) if ga.get(k) != gb.get(k))
            lines.append(f"- {name}: rebuilt from tabs/*.json; {n} cells differ from the master")
            continue
        if name not in b.sheetnames:
            lines.append(f"- MISSING after build: {name}")
            continue
        ga, gb = grid(a[name]), grid(b[name])
        if name == "Tool cards":
            ga, gb = grid(a[name]), grid(b[name])
            d = sorted(c.coordinate for c in b[name]._cells.values() if ga.get((c.row, c.column)) != c.value and c.value is not None)
            lines.append(f"- {name}: regenerated by cards_to_sheet.py; cells changed: {', '.join(d) or 'none'}")
            continue
        if name == "App decisions":
            diff = sorted({k[0] for k in set(ga) | set(gb) if ga.get(k) != gb.get(k)})
            apps = [flat(b[name].cell(r, 1).value) or flat(a[name].cell(r, 1).value) for r in diff if r > 3]
            lines.append(f"- {name}: regenerated by build_decisions.py; {len(diff)} rows differ"
                         + (f" ({', '.join(apps[:12])})" if apps else ""))
            continue
        if name == "Director + Conductor":
            same = sum(1 for k, v in ga.items() if gb.get(k) == v)
            extra = max(r for r, _ in gb) - max(r for r, _ in ga)
            lines.append(f"- {name}: {same} of {len(ga)} old cells unchanged; {extra} rows added (split test)")
            continue
        inserted = []
        for x in inserts.get(name, []):
            if not any(x["marker"] in flat(v) for v in ga.values()) and any(x["marker"] in flat(v) for v in gb.values()):
                bb = x["before"]
                gb = {(r if r < bb else r - 1, c): v for (r, c), v in gb.items() if r != bb}
                inserted.append(bb)
        diff = [k for k in set(ga) | set(gb) if ga.get(k) != gb.get(k)]
        old_max = a[name].max_row
        new_rows = sorted({r for r, _ in diff if r > old_max})
        unexpected = [k for k in diff if k not in edits.get(name, set()) and not (k[0] > old_max and len(new_rows) <= appended.get(name, 0))]
        meta = []
        if sorted(map(str, a[name].merged_cells.ranges)) != sorted(map(str, b[name].merged_cells.ranges)):
            meta.append("merged cells differ")
        if a[name].freeze_panes != b[name].freeze_panes:
            meta.append("freeze panes differ")
        lines.append(f"- {name}: {len(diff) - len(unexpected) - sum(1 for k in diff if k[0] > old_max)} corrected cells, "
                     f"{len(new_rows)} appended rows, " + (f"{len(inserted)} inserted row(s) before R{inserted}, " if inserted else "")
                     + f"{len(unexpected)} other changes"
                     + (f" {sorted(unexpected)[:6]}" if unexpected else "") + (f"; {', '.join(meta)}" if meta else ""))
    added = [n for n in b.sheetnames if n not in a.sheetnames]
    return lines, added, b.sheetnames


def cmd_dry_run():
    problems, warnings, unsourced, counts = cmd_check(quiet=True)
    before = sha(BOOK)
    tmpdir = tempfile.mkdtemp(prefix="playbook-dryrun-", dir=os.environ.get("TMPDIR"))
    copy = f"{tmpdir}/connectors-2026-09-30.xlsx"
    shutil.copy2(BOOK, copy)
    log = build_all(copy, f"{tmpdir}/app-decisions.csv")
    lines, added, order = compare(BOOK, copy)
    after = sha(BOOK)
    wb = openpyxl.load_workbook(copy)
    peek = []
    for name in added + ["Director + Conductor"]:
        ws = wb[name]
        titles = [flat(ws.cell(r, 1).value) for r in range(1, ws.max_row + 1)
                  if ws.cell(r, 1).fill is not None and ws.cell(r, 1).fill.fgColor.rgb in ("001F3864", "FF1F3864")]
        peek.append(f"- **{name}**: {ws.max_row} rows; sections: " + " · ".join(t.split(":")[0][:60] for t in titles))
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%MZ")
    rep = [f"# Dry run of build_tabs.py ({now})", "",
           f"- Copy built: `{copy}`",
           f"- Master untouched: sha256 before {before[:12]}…, after {after[:12]}… ({'same' if before == after else 'CHANGED'})",
           f"- Source check: {len(problems)} problems, {len(warnings)} warnings, {len(unsourced)} claims still without a source",
           "", "## Build log", *[f"- {l}" for l in log], "", "## New tabs, in order", *peek,
           "", "## Sheet order after the build", " · ".join(order), "",
           "## Existing tabs compared cell by cell with the master", *lines, "",
           "## Claims with no source yet (for the Director)", *[f"- [{t}] {u}" for t, u in unsourced]]
    if problems:
        rep += ["", "## Source-check problems", *[f"- {p}" for p in problems]]
    open(REPORT, "w", encoding="utf-8").write("\n".join(rep) + "\n")
    print("\n".join(rep))


def cmd_apply(args):
    if not args.workbook_free:
        sys.exit("Refused: run apply only after the Director sends 'workbook free' (add --workbook-free).")
    problems = cmd_check(quiet=True)[0]
    if problems:
        sys.exit(f"Refused: {len(problems)} source-check problems; run build_tabs.py check.")
    before = sha(BOOK)
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
    bak = f"{H}/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_{stamp}.xlsx"
    os.makedirs(os.path.dirname(bak), exist_ok=True)
    shutil.copy2(BOOK, bak)
    work = f"{tempfile.mkdtemp(prefix='playbook-apply-', dir=os.environ.get('TMPDIR'))}/book.xlsx"
    shutil.copy2(BOOK, work)
    log = build_all(work, f"{REPO}/work/2026-10-01_app-decisions/app-decisions.csv")
    if sha(BOOK) != before:
        sys.exit("Refused: the master changed while building (another writer, e.g. the cards hook). Run apply again.")
    shutil.copy2(work, BOOK)
    shutil.copy2(BOOK, COPY)
    print("\n".join(log))
    print(f"backup {bak}\nsaved  {BOOK}\ncopied {COPY} (sha256 {'match' if sha(BOOK) == sha(COPY) else 'DIFFER'})")
    for step in ("build", "check"):  # spp-p32a hook: needs op, so apply runs outside the Claude Code sandbox
        r = subprocess.run([sys.executable, f"{JOB}/scripts/student_edition.py", step], capture_output=True, text=True)
        print(f"student edition {step}: " + ((r.stdout.strip().splitlines() or [r.stderr.strip() or "(no output)"])[-1]))
        if r.returncode != 0:
            sys.exit(f"Apply saved the workbook, but the student edition {step} failed (exit {r.returncode}); the previous "
                     "edition is kept. Fix the findings, then run student_edition.py build again.")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("command", choices=["check", "templates", "splittest", "decisions", "dry-run", "apply"])
    ap.add_argument("--workbook-free", action="store_true", help="the Director sent 'workbook free'")
    a = ap.parse_args()
    if a.command == "check":
        sys.exit(1 if cmd_check()[0] else 0)
    {"templates": cmd_templates, "splittest": cmd_splittest, "decisions": cmd_decisions,
     "dry-run": cmd_dry_run}.get(a.command, lambda: cmd_apply(a))()


if __name__ == "__main__":
    main()
