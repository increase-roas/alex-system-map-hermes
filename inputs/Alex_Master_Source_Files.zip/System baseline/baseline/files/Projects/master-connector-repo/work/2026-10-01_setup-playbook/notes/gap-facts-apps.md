# Gap facts for the app routes (play spp-p20c): G07, G13, G14

Mission `mission-setup-playbook-parity`, node `playbook-tabs` (closing the rebuild gaps). Claude Code subagent of session 294b676b (workspace `~/Projects/master-connector-repo`), conductor v2.3 loaded first. Date 2026-10-01, about 20:58–21:35Z.

- **Input:** `notes/replication-retest-prelim.md`, gap rows G07 (Google robot), G13 (GHL CRM gateway) and G14 (GHL builder).
- **Output:** `tabs/gap-facts/G07.json`, `G13.json` and `G14.json`, shaped like spp-p20a's files (`title`, `header`, `rows`, last column `source`), plus this summary.
- **Who wrote what:** one read-only helper read HighLevel's official developer docs through Exa (§5, rows marked "helper"). The lead did everything else: the live reads, the code reads, the three gap files, and spot-checks of the helper's high-impact claims (§6).
- **Read-only throughout.** No Google, GHL, Cloudflare, Composio or hub setting was changed. No `.env` file or pipe was opened. No secret value was printed or saved.

## 1. What each file closes

| Gap | File | Target tab | Rows | Status |
|---|---|---|---|---|
| G07 | `tabs/gap-facts/G07.json` | Rebuild from zero (Phase 5: new scope and API tables, delegation steps) | 39 + 21 + 8 + 4 + 7 | Done. All 39 delegated scopes and 17 APIs proven live today. The project's full enabled-API list stays NOT_PROVEN and isn't needed (§7). |
| G13 | `tabs/gap-facts/G13.json` | GoHighLevel (gateway section) | 10 + 13 + 5 + 7 + 4 | Done. The Marketplace app, Worker settings, D1 schema, install and gateway key are all sourced. Five gateway secrets have no 1Password copy (§7). |
| G14 | `tabs/gap-facts/G14.json` | GoHighLevel (builder section) | 9 + 5 + 7 + 5 + 4 | Done. The hub copy matches git byte for byte. The exact command used to register the two Private Integration keys on 2026-09-30 is NOT_PROVEN (§7). |

## 2. G07 live checks: the Google robot

**Where the 39 scopes come from.** `work/2026-10-01_google-robot/dwd-scopes.txt` is one comma-separated line with 39 distinct scopes. This session (294b676b) wrote it at 10:19:09Z and put it on the clipboard. Alex pasted it into the Admin console (run-log L72: "owner added 39 DWD scopes"). The prelim's "never exported" means the workbook export didn't include it. The file itself is in this repo (commit f7fac6a).

**Check 1. Token requests on the hub, 21:13:15–21:13:18Z.** Run through `orgo_op.py orgo computers bash` to My OpenClaw (6fbffd8c-65b1-4f2e-993e-f283532109bf), with the script on stdin. It follows the same pattern as the hub's own `ga4-act-as-alex.sh` L5–L13: the service account acts as alex@ and the token is thrown away. Only `ok` or Google's error code was printed.

| Request | Result |
|---|---|
| A. All 39 scopes from dwd-scopes.txt in one token request | ok |
| B. analytics.manage.users alone (the one scope no hub route requests) | ok |
| C. Control: drive plus cloud-platform (cloud-platform is not delegated) | error: unauthorized_client |
| D. Control: drive alone | ok |

So every one of the 39 is delegated to client 112417209265494842557. C shows Google refuses the whole token request if even one scope in it isn't delegated. That is why removing a scope breaks every call whose token asks for it.

**Check 2. One read per API family through Composio, 21:08:27–21:10:19Z.** Each call ran as alex@ with `composio execute`, and only the status and Google's error reason were printed. Script: `api_probe_20c.py` in this session's scratchpad. An accidental second run of the same script (21:10:41–21:12:36Z) gave the same results.

| Family (route) | Composio tool | logId | Result | What it proves |
|---|---|---|---|---|
| gmail (robot) | CUSTOM_GOOGLE_ROBOT_GOOGLE_API | log_kvGlC783sHOi | success | Gmail API on; the 3 gmail scopes are delegated |
| drive (robot) | same | log_Lb-P8G9cNn72 | success | Drive API on |
| docs (robot) | same | log_sxeiqjj9rcbO | 404 NOT_FOUND on a made-up ID | Docs API on (a disabled API answers SERVICE_DISABLED); documents + drive delegated |
| sheets (robot) | same | log_9I0viPqbFfsR | 404 NOT_FOUND | Sheets API on |
| slides (robot) | same | log_HbCsWQ1WKKfC | 404 NOT_FOUND | Slides API on |
| forms (robot) | same | log_FmFoGncTS5-m | 404 NOT_FOUND | Forms API on; forms.body + forms.responses.readonly delegated |
| calendar (robot) | same | log_snokTQJn1AiQ | success | Calendar API on |
| people (robot) | same | log_jc35okn94bWE; then log_DbEBlG62j58j and log_urWS-tLTTa7y | people/me: 403 PERMISSION_DENIED ("The caller does not have permission", not a disabled-API error); contactGroups: success; listDirectoryPeople: success | People API on; contacts + directory.readonly delegated |
| tasks (robot) | same | log_R1GgJtlUaxTP | success | Tasks API on |
| directory (robot) | same | log_txC-rOc3w_Vo | success | Admin SDK API on; the 8 admin.directory scopes delegated |
| reports (robot) | same | log_BW3RJXyQwn-u | success | Admin SDK reports; both admin.reports scopes delegated |
| licensing (robot) | same | log_ceO7L7vSaGVO | success | Enterprise License Manager API on |
| groupssettings (robot) | same | log_ygt03QO03aN4 | success (a real group's settings; address not printed) | Groups Settings API on |
| ga4 route | CUSTOM_GA4_ADMIN_LIST_ACCOUNTS | log_yYXyvly7gDrr | success | Analytics Admin API on; the route's 6 scopes delegated |
| ga4 route | CUSTOM_GA4_ADMIN_GET_METADATA (property 0) | log_tI1O0WvFir54 | success | Analytics Data API on |
| ga4 route | CUSTOM_GA4_ADMIN_GOOGLE_API_REQUEST, Search Console sites | log_8ptdT3FuJQFE | 200 | Search Console API on |
| ga4 route | same, Data Manager requestStatus:retrieve | log__zcSK2A_SsOn | 400 INVALID_ARGUMENT | Data Manager API on |
| ga4 route | same, Business Profile accounts | log_YEJ8JCwO1Neo | 403 SERVICE_DISABLED | Business Profile APIs are OFF in the project (the token itself was accepted) |
| gtm route | CUSTOM_GOOGLE_TAG_MANAGER_GTM_ACCOUNT list | log_CCAjfJ_YQ1Rm | success | Tag Manager API on; the route's 7 scopes delegated |

**Which route asks for which scopes** (read from code; the ga4 base list was read on the hub at 21:07Z):
- The robot asks per family. `server.py` L25–L41 groups 25 scopes into 13 families, so one missing scope only breaks its own family.
- The ga4-admin route asks for 6 in one token. The installed `google_analytics_mcp` config lists analytics.edit and analytics.readonly, and `ga4-admin-run.py` L11–L15 adds webmasters, datamanager, business.manage and analytics.manage.users.readonly.
- The gtm route asks for 7 tagmanager scopes (`gtm.sh` L3).
- Together that is 38 scopes. The 39th, analytics.manage.users, is delegated (check 1 B) but no route asks for it.

**The hub runs the same robot code as the mirror.** The sha256[:16] of `/opt/mcp-hub/google-robot/server.py` on the hub is e73ad553109774c0, equal to `~/.agents/tools/connectors/google_robot/server.py`.

**Which APIs are on, and the record of turning them on:**
- 3 from the August 2026 setup record: Analytics Admin, Tag Manager and Analytics Data (sources-17.md S03, 1Password item zg3w36r2h7tx7jtdkt4fc2ubna).
- Search Console and Data Manager, turned on by Alex on 2026-10-01 (run-log L60).
- 12 Workspace APIs, turned on at 10:14:33–10:15:43Z by this session through the Cloud console's enable flow for project increaseroas-tagging (session transcript; run-log L72 "12 APIs enabled"): gmail, drive, docs, sheets, slides, forms, calendar-json, people, tasks, admin, groupssettings and licensing (all `.googleapis.com`). The robot itself couldn't do it: its Service Usage batchGet got 403 at 10:14:26Z.
- All 17 answered today (check 2).
- Known OFF: Business Profile (check 2), Cloud Resource Manager and IAM (`fix-k01-w20.md` L68–L69).
- Can't be listed: Service Usage refuses the robot (403 AUTH_PERMISSION_DENIED, `fix-k01-w20.md` L67).

## 3. G13 reads: the GHL CRM gateway

**Code** (`~/Development/increase-roas-oauth-gateway-hotfix`, commit b464b6d):
- **Sign-in start** (worker.mjs L345–L362). Sends the agency admin to `https://marketplace.gohighlevel.com/oauth/chooselocation` with client_id, the redirect URL `<worker>/oauth/callback`, response_type code, user_type Company, the 175 scopes and a state value.
- **Callback** (L363–L392). Trades the code at `services.leadconnectorhq.com/oauth/token` with user_type Company, stores the agency tokens encrypted in D1, and answers `{"status": "authorized", ...}`.
- **Sub-account tokens** come from `/oauth/location-token` (L276). The sub-account list comes from `/oauth/installed-locations` with the app ID (L299–L322).
- **Allowed company.** Tokens and webhooks from any other company are refused (L163–L166; GHL_ALLOWED_COMPANY_ID in wrangler.toml L6).
- **Token encryption key.** Must be exactly 32 bytes, base64url (L75–L79).
- **Gateway key.** `/mcp` accepts only GHL_MCP_INTERNAL_API_KEY, at least 16 characters (`lib/mcp-auth.mjs` L101–L113). `/api/*` accepts it or INTERNAL_API_KEY (L115–L126).
- **App ID** is hard-coded as GHL_APP_ID (`lib/gateway-core.mjs` L2). The 175 scopes are at L32–L208.

**Cloudflare, read through Composio `CUSTOM_CLOUDFLARE_API_EXECUTE` at 21:15:23Z (log_bJvHzxQRWsBE; GET calls plus one SELECT on sqlite_master; names and types only):**
- **Gateway Worker secrets (6):** GHL_CLIENT_ID, GHL_CLIENT_SECRET, GHL_MCP_INTERNAL_API_KEY, INTERNAL_API_KEY, SLACK_BOT_TOKEN, TOKEN_ENCRYPTION_KEY.
- **Plain variables:** GHL_ALLOWED_COMPANY_ID, SLACK_CHANNEL_ID.
- **Other bindings:** DB (D1) and SELF (service). Compatibility date 2026-08-13.
- **D1 `increase-roas-ghl-oauth-gateway-db`:** 3 tables (agency_authorizations, location_authorizations, oauth_states) and 2 indexes. The exact CREATE statements are in G13.json §3. No schema file exists in git: a grep for CREATE TABLE in the repo finds none.

**The Marketplace app:**
- **Workspace.** It is defined in `~/Development/increase-roas-marketplace-app`, a HighLevel Marketplace CLI workspace that is **not a git repository**.
- **`ghl-app.json`:**
  - app "Increase ROAS Agent Gateway", live version 5.0.0, private;
  - user types Company and Location, white-label friendly, agency bulk install on;
  - 175 allowed scopes, exactly equal to the gateway's requested set (compared about 21:17Z, 0 differences each way);
  - 2 redirect URLs (the gateway callback, the default, plus Composio's auth-app URL);
  - 2 client keys (the default, and one named composio_hermes);
  - free billing.
- **`src/webhooks/ghl-webhooks.json`.** The webhook URL is `<worker>/webhooks/ghl`, with 68 subscribed events.
- **CLI.** `@gohighlevel/marketplace-cli` 1.0.0 is installed at `~/.local/bin/ghl` (`ghl --version`).
- **Not opened:** the CLI's secret ledger and the gateway folder's `.dev.vars` (mode 0600, git-ignored). Only `.ghl/state.json`'s key names were read.

**1Password:** The Connectors vault holds only the gateway key for this route ("GHL OAuth CRM (ghl-oauth-crm) — gateway key", 3yxpnoxi2xd7o76whc6onu522a; G06.json §1). It has no item for the client ID and secret, the token encryption key, INTERNAL_API_KEY or the Slack bot token.

## 4. G14 reads: the GHL builder

**Hub read, 21:06:57–21:07:00Z** (`orgo_op.py orgo computers bash`, script on stdin). It printed names, modes, sizes, counts, states and sha256[:16] only.
- **`/opt/ghl-command-universal`:**
  - server.py, test_origin.py, package.json, package-lock.json, origin-key (0600, 43 bytes), sessions/ (7 sessions), tunnel/ (cloudflared plus token, 0600) and catalog-raw.json;
  - its README is an older copy (rebuild-sources.md §(b)).
- **Equal to git `6fcc3b4` by hash:** server.py e9323b2d5f3f91e7, test_origin.py 9b559bbc60ca93b8, package.json 2ab879d8ecbc7eaa, package-lock.json e669083fa6f87762, and both Supervisor files (ir-ghl-command-universal.conf 89472dc678140201, ir-ghl-command-tunnel.conf 65a157bf97803326).
- **Versions:** @elitedcs/ghl-mcp 3.88.2, node v22.23.2, Python 3.12.3. cloudflared 2026.9.3 matches the README's sha256 (77e26d8d…3fac2).
- **Programs:** ir-ghl-command-universal and ir-ghl-command-tunnel are RUNNING. mcp-hub-google-robot-javante is STOPPED (G22).
- **Listener:** 127.0.0.1:8789, python3.
- **No key, no entry:** without the origin key, /health and GET /mcp both answer 401. The public hostname `https://ghl-command-origin.increaseroas.com/health` also answers 401, so the tunnel is up and the key is required.
- **`/opt/increase-roas-mcp/ghl-config`:** .ghl-tokens.json (registry with 49 location entries, plus a second section with 2 entries), credentials.json and device.json, all 0600.
  - credentials.json field names: license_key, email, verified_at, ghl_api_key, ghl_location_id, ghl_user_id, device_id, plus one long field name the script masked.
  - device.json field names: device_id, created_at.

**Cloudflare, same read as §3 (log_bJvHzxQRWsBE):**
- **Builder Worker:** secrets CONNECTION_PASSWORD_SHA256 and ORIGIN_KEY; variables AUTH_EPOCH and ORIGIN_URL; KV binding OAUTH_KV, titled "ghl-command-universal-oauth"; compatibility date 2026-08-27 with nodejs_compat.
- **Tunnel 9b09467d-9c1c-4f4c-9b00-021ad8239f20:** named "ghl-command-universal-openclaw", status healthy, 4 connections, config_src cloudflare (remotely managed), created 2026-09-29.
  - Ingress: ghl-command-origin.increaseroas.com to http://127.0.0.1:8789, with an http_status:404 fallback.
  - DNS: proxied CNAME to `<tunnel id>.cfargotunnel.com`.

**How Private Integration keys get registered:**
- **The two ways the package documents.** The `register_location` tool, and the headless CLI `cli register-location --location-id --api-key --name` with GHL_MCP_CONFIG_DIR. Sources: the package README L216–L264 and the CLI usage text in `dist/index.js` L40923–L40957 (local npx copy of 3.88.2, the hub's version).
- **The CLI's own note** says to seed while GHL Command is stopped, or restart it afterwards.
- **The builder excludes these tools on purpose.** Its public catalog drops register_location, register_agency_key and setup_ghl_mcp by policy (`origin/catalog-audit.json` excluded/policy), so registration can't go through Composio.
- **Session copies need updating too.** Each session copies the registry when it is created (`origin/server.py` L98–L103). The access guide says to update the registry and every live session copy after adding an account (`ghl-command-access.md` L36).

## 5. Research log

Every URL below was read on 2026-10-01 (read 2026-10-01) through Exa via Composio (`EXA_SEARCH` / `EXA_GET_CONTENTS_ACTION`, script `exa20c.py` in this session's scratchpad), except the one row read through the Composio docs reader Context7. The builder accepts a URL only when it appears in a research note, so these lines are that record.

| URL | read | logId | used for |
|---|---|---|---|
| https://knowledge.workspace.google.com/admin/apps/control-api-access-with-domain-wide-delegation | read 2026-10-01 | log_DizWn09z9-dT, log_ug7SDBgTTk6o | Delegation steps: super admin, client ID, Add new, Authorize, View details, up to 24 hours, multi-party approval |
| https://developers.google.com/identity/protocols/oauth2/service-account | read 2026-10-01 | log_ug7SDBgTTk6o | Create the service account and key; delegation steps; the `sub` claim / with_subject; a delegated request without permission is an error |
| https://knowledge.workspace.google.com/admin/apps/domain-wide-delegation-best-practices | read 2026-10-01 | log_ug7SDBgTTk6o | Google's practices: narrow scopes, dedicated project, avoid keys (signJwt), restrict project access |
| https://developers.google.com/workspace/guides/enable-apis | read 2026-10-01 | log_ug7SDBgTTk6o | APIs must be on in the calling project; console Library or `gcloud services enable` |
| https://developers.google.com/my-business/content/prereqs | read 2026-10-01 (search text) | log_7ZaodhYn7HlP | Business Profile APIs: request access through Google's form, then enable after approval |
| https://developers.google.com/my-business/content/basic-setup | read 2026-10-01 (search text) | log_7ZaodhYn7HlP | Eight Business Profile APIs to enable after approval |
| https://marketplace.gohighlevel.com/docs/oauth/CreateDeveloperAccount/ | read 2026-10-01 (helper) | log_s1OvtIJ1OoyY | Developer account sign-up; first signer is the only Owner |
| https://help.gohighlevel.com/support/solutions/articles/155000000136-how-to-get-started-with-the-developer-s-marketplace | read 2026-10-01 (helper) | log_fzc-njbytwTA, log_Oj6PUcm5rLL9 | Agency admins get an auto-created developer account (Sell on Marketplace) |
| https://marketplace.gohighlevel.com/docs/oauth/CreateMarketplaceApp | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y | Create app fields; Auth: scopes, redirect URL; client secret shown once (spot-checked §6) |
| https://marketplace.gohighlevel.com/docs/Authorization/OAuth2.0/ | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y, log_fzc-njbytwTA | Private vs Public; install link; token lifetimes (86399 s; refresh token up to a year or until used) |
| https://help.gohighlevel.com/support/solutions/articles/155000002141-marketplace-app-distribution-type | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y | A private app installs in up to 5 agencies (spot-checked §6) |
| https://marketplace.gohighlevel.com/docs/oauth/AppDistribution/ | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y | Target user can't be changed once set; Who can install; bulk install; agency-level scopes need Agency Only (spot-checked §6) |
| https://marketplace.gohighlevel.com/docs/Authorization/TargetUserSubAccount | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y | Agency install of a sub-account app returns a Company token; mint Location tokens from it |
| https://marketplace.gohighlevel.com/docs/Authorization/Scopes | read 2026-10-01 (helper) | log_hzfuV5_JRi-Q | oauth.write for location tokens, oauth.readonly for installed locations (spot-checked §6) |
| https://marketplace.gohighlevel.com/docs/sdk/marketplace-cli/ | read 2026-10-01 (helper) | log_hzfuV5_JRi-Q | `npm install -g @gohighlevel/marketplace-cli`, Node 20.12+, `ghl login`; scope changes need a major version; white-label apps can't use HighLevel-branded redirect URLs; private publish goes live at once |
| https://marketplace.gohighlevel.com/docs/oauth/HowToUpdateYourAPP/ | read 2026-10-01 (helper) | log_kEDfkyktyZcc | Private apps go live without review; major updates need each installer to accept |
| https://marketplace.gohighlevel.com/docs/ghl/oauth/get-access-token | read 2026-10-01 (helper) | log_Bq4qDJLEsP2Y | Token exchange body: client_id, client_secret, grant_type, code, user_type, redirect_uri |
| https://github.com/GoHighLevel/marketplace-cli | read 2026-10-01 (helper) | log_hzfuV5_JRi-Q | The CLI is HighLevel's own; private apps go live immediately |
| https://developers.cloudflare.com/workers/configuration/secrets/ | read 2026-10-01 | log_bjC3Ek4uBoqc, log_NyPlt9NkMnD1 | `wrangler secret put <KEY>` deploys a new version; secret values can't be seen again; `.dev.vars` is for local development only |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/get-started/create-remote-tunnel-api/ | read 2026-10-01 | log_mrXG2QbdsXKK, log_NyPlt9NkMnD1 | Create a remotely managed tunnel (POST cfd_tunnel, config_src cloudflare), set ingress with a catch-all 404, add a DNS record; healthy = 4 connections |
| https://developers.cloudflare.com/d1/wrangler-commands/ | read 2026-10-01 | log_-4hmbUtt1xUH, log_NyPlt9NkMnD1 | `wrangler d1 create`; `wrangler d1 execute` with --command or --file |
| https://developers.cloudflare.com/kv/reference/kv-commands/ | read 2026-10-01 | log_NyPlt9NkMnD1 | `wrangler kv namespace create` |
| https://developers.cloudflare.com/workers/wrangler/commands/workers/ | read 2026-10-01 | log_IiKsA5SlAMuY | Checked for piped-secret wording; none on this page (the docs reader found it, next row) |
| https://github.com/cloudflare/workers-sdk/blob/main/packages/turbo-r2-archive/README.md | read 2026-10-01 (Composio docs reader `CUSTOM_CONTEXT7_QUERY_DOCS`, library /cloudflare/workers-sdk) | log_gBQ5nXwZUgu1, log_01MZqLhbLx5D | Cloudflare's own repo pipes a value into `wrangler secret put` (echo VALUE piped in), so a secret can come from 1Password on stdin without typing |
| https://www.npmjs.com/package/@elitedcs/ghl-mcp | read 2026-10-01 | log_GbazIIKpOfc8 | GHL Command licence ($97/mo, up to 3 machines); setup_ghl_mcp's four fields; Private Integration steps |

URLs already logged by spp-p20a in `notes/gap-facts.md` §2 and cited again here: https://www.1password.dev/cli/item-create (command arguments are visible to other processes) and the Cloudflare remote-tunnel-permissions page (a remotely managed tunnel runs on its token alone; GET …/token returns it).

The helper's full list (15 Exa calls, including pages read but not used) came back in its report. Its raw JSON is in the scratchpad as `spp-p20c/g13-*.json`. Those files hold HighLevel's public sample client IDs, so they stay out of the repo.

## 6. Checks

**Spot-checks of the helper's claims.** Each was grepped in the saved page texts, in the lead's own run:
- client secret shown once (CreateMarketplaceApp: "Once you click OK, it will not be shown");
- a private app's 5-agency cap (help article 155000002141, "Private App Install Limits");
- Target user can't be modified once set (AppDistribution);
- private apps go live immediately on publish (HowToUpdateYourAPP, CLI README);
- the CLI install command and Node 20.12 (CLI docs and its GitHub README);
- oauth.write and oauth.readonly (Scopes page);
- token lifetimes (OAuth2.0 page).

All found.

**Builder validation and secret scans.** Results are in §8; they were run after the files were written.

**verify-before-done (normal stakes: internal source files, no tool writes):**

| Check | How | Result |
|---|---|---|
| Done means: one file per gap with rows and a source on every row | 3 files; builder validation (§8) | Met |
| G07: full scope list, enabled APIs, delegation steps from Google's docs | G07.json §1–§4 against dwd-scopes.txt, the hub token check, the Composio probes and the two Google pages | Met. The project's full enabled list (Google's defaults) is NOT_PROVEN and not needed |
| G13: app (developer account, scopes, redirect URL, where client credentials go), Worker settings and secrets, agency install, gateway key | G13.json §1–§4 against the code, the Cloudflare read and the helper's docs | Met |
| G14: origin deploy onto the hub; licence; Worker secrets; how keys are registered | G14.json §1–§4 against the hub read, the repo, the package README and the Cloudflare read | Met. The command used on 2026-09-30 is NOT_PROVEN |
| Counts recomputed from source | 39 scopes (file), 38 requested by routes (code), 17 APIs (probes), 175 scopes (code = app manifest), 6 secrets + 2 variables (Cloudflare), 3 tables + 2 indexes (D1), 49 registry entries, 7 sessions (hub) | Match |
| Negative checks | Control token request C fails as expected; Business Profile probe returns SERVICE_DISABLED; no RESEARCH line means URL failures (§8) | Pass |
| Couldn't check | The Admin console's live scope list (security setting, not read); the project's full enabled-API list; what `.dev.vars` holds (not opened) | Listed in §7 |

## 7. NOT_PROVEN, and findings for the Director

**NOT_PROVEN**
1. **Extra scopes beyond the 39.** All 39 in dwd-scopes.txt are delegated (§2 check 1). Whether the Admin console holds more than these 39 wasn't read; it is a security page. Extra scopes wouldn't break a rebuild.
2. **The project's full enabled-API list.** Service Usage refuses the robot, and Cloud Resource Manager and IAM are off. A rebuild needs only the 17 APIs proven on in §2. Any others are Google's project defaults.
3. **The exact command that registered the two Private Integration keys on 2026-09-30** (the CLI, the tool, or a seeded registry).
4. **HighLevel install details** (helper):
   - whether the developer account costs anything;
   - the exact chooselocation parameter names in HighLevel's docs (our Worker's are in its code);
   - whether the install URL's scopes must equal or be a subset of the app's;
   - an exact forbidden-word list for redirect URLs;
   - whether existing installs pick up new scopes without reinstalling;
   - whether an agency's plan limits private-app installs.
5. **Whether another 1Password vault holds the five gateway Worker secrets.** Robots only see Connectors.

**Findings (not acted on; each belongs to another lane or needs Alex)**
- **No backup for five gateway Worker secrets.** GHL_CLIENT_ID, GHL_CLIENT_SECRET, TOKEN_ENCRYPTION_KEY, INTERNAL_API_KEY and SLACK_BOT_TOKEN exist only as Worker secrets, which Cloudflare never shows again. HighLevel shows a client secret only once. If the Worker is lost:
  - the app needs a new client key;
  - the agency must sign in again at /oauth/start (stored tokens can't be decrypted without the old key);
  - every /api caller needs a new INTERNAL_API_KEY.
- **The Marketplace CLI workspace isn't in git.** `~/Development/increase-roas-marketplace-app` is the app's only local definition (manifest, webhooks, CLI state). A newcomer can't clone it. A partner with developer-portal access can rebuild it with `ghl app pull <appId>`.
- **The gateway folder has a `.dev.vars` file** (151 bytes, mode 0600, git-ignored). Cloudflare uses that file for local development secrets. It wasn't opened. If it holds live values, they belong in 1Password, and the local copy is a cleanup candidate under the standing yes, once the 1Password copy is proven.
- **A local copy of the builder's connection password exists on the Mac.** It is `~/.config/ghl-command-universal/connection-password` (33 bytes, mode 0600; listed, not opened), which the access guide calls the "local fallback" (`ghl-command-access.md` L42). The password's home is 1Password item yxvess6diezoy7lgrnhqrmct5i. Removing the copy falls under the standing yes once the item is proven equal by hash, after a backup to ~/Backups. This play didn't touch it.
- **The Marketplace app has a second redirect URL and client key** ("composio_hermes", Composio's auth-app URL). They serve a Composio-managed HighLevel login. Who uses it belongs to G24 (Hermes/Javar), not to a gateway rebuild.
- **Our setup differs from Google's best-practice list in three ways:**
  - the robot uses a JSON key (Google suggests signJwt instead);
  - its project also hosts other tagging work;
  - it holds 39 scopes, 1 of them (analytics.manage.users) unused.

  These are facts, not a recommendation. Changing any of them is a security decision for Alex.
- **Business Profile APIs are off.** The ga4-admin route offers Business Profile calls, but the APIs are off in the project, so those calls fail with SERVICE_DISABLED. Google's documented path is an access request first.

## 8. How the builder uses these files, and the validation run

1. **Placement.** Each file's `target_tab` says where its rows go.
   - G07's §4 and G13/G14's last sections carry replacement cells for `tabs/rebuild-from-zero.json` by step label and column.
   - They leave the "how you know it worked" cells that G23 already moved.
2. **RESEARCH.** `build_tabs.py` already includes `notes/gap-facts*.md` in RESEARCH (L55), so the URLs here pass its URL check.
3. **Run the check:** `python3 build_tabs.py check`, then the dry run.

**Validation output.** This is spp-p20a's `validate_gap_facts.py` (build_tabs.py's own `check_source`, `scan_text` and Excel limits, plus two secret scans):

Final run at 21:31Z, from the job folder, with spp-p20a's validator copied to `spp-p20c/validate_20c.py` and given a file filter:

```
this play's files (G07, G13, G14 + notes/gap-facts-apps.md):
files: 3 rows per file: {'G07.json': 79, 'G13.json': 39, 'G14.json': 30}
PROBLEMS (0)
WARNINGS (4): {'looks like a 1Password item id': 4}
SECRET SHAPES (0)
VAULT SECRET VALUES FOUND (0)

all 24 gap files (other plays' files included, read-only):
PROBLEMS (0)   WARNINGS (47, all 'looks like a 1Password item id')   SECRET SHAPES (0)   VAULT SECRET VALUES FOUND (0)
```

- **The warnings are expected.** G14 must name the origin-key, licence and connection-password items.
- **Negative check 1: the URL rule.** Rerunning without this file in RESEARCH gives 45 "URL not in the research notes" failures and nothing else. So the check bites, and this file's research log is what makes those URLs pass.
- **Negative check 2: names and IDs.** The builder's client-name list, any email other than alex@, and location-ID shapes find 0 in the three gap files and in this note.
- **Mid-run note.** An earlier all-files run, about 10 minutes before, showed problems only in G19, G20 and G24. Those are another play's files, written while its notes file didn't exist yet. The final run above shows 0, and nothing of theirs was changed.
