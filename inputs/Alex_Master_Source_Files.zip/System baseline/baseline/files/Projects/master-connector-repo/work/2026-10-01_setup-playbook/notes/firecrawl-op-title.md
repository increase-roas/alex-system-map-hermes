# firecrawl_op.py finds its 1Password item by title (play spp-p43a)

LOCK (spp-p43a, 2026-10-02T03:01Z): `~/.agents/tools/connectors/firecrawl_op.py` (edit) and `~/.agents/tools/connectors/test_firecrawl_op.py` (new). Nothing else in `~/.agents`: not `op_items.py`, not `tools/cards/firecrawl.md`, not the tool-card skill.
RELEASED (spp-p43a, 2026-10-02T03:18:46Z): both paths committed as `~/.agents` 10b9aa9 (tree clean, not pushed).

Mission `mission-setup-playbook-parity`, node `replication-retest` (fresh-vault N01 follow-up; finding from spp-p42a, notes/tool-card-v14.md item 4). Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first; DIRECTOR_STATE.md not written. Start: `~/.agents` 3a970c2, tools/connectors clean; firecrawl_op.py sha256 de90640fc4a9...

Stage: TECHNICAL BUILD | Route: test-driven-development (Director trigger: code change, test is the proof) | Gap: PERMISSION (macOS prompt, §5) | Next: live case + `--status` when §5 clears
Checkpoint: 10b9aa9 committed, fake-vault tests green | Settled: op_items.py title lookup with today's ID as fallback (spp-p33a), no OP_BIOMETRIC_UNLOCK_ENABLED (decision 5) | Interrupted: none (every hung `op` was stopped before it listed or read anything)

## 1. Result

| What | Status | Evidence |
|---|---|---|
| Item found by exact title in vault Connectors | VERIFIED (fake vault) | test_firecrawl_op.py: a vault whose "Firecrawl API key" has a fresh ID; the wrapper reads `op://Connectors/<fresh id>/credential`, the key reaches only the CLI, the robot token does not |
| Today's ID kept as the fallback | VERIFIED (fake vault) | vault without that title: the read goes to `op://Connectors/uuopqngw4ikpdmpvgnclx3eive/credential` |
| Refusals kept | VERIFIED | 16 cases (spp-p30a's 14 + `--api-key <key>` + a leading `firecrawl`): each exits "not run.", 0 Keychain reads, 0 `op` calls, no exec, the key never in the message; the refusal code is untouched in the diff |
| Live case: the real vault gives today's ID | VERIFIED 2026-10-02T17:40:05Z (§5) | every `op` call from Claude Code hangs since 23:01 local (§5) |
| One `firecrawl_op.py --status` | VERIFIED 2026-10-02T17:40:05Z (§5) | same blocker; not run |

## 2. Change (`~/.agents` 10b9aa9: 2 files, +207 -4; not pushed)
- firecrawl_op.py: `from op_items import VAULT, item_id`; `TITLE, ITEM = "Firecrawl API key", "uuopqngw4ikpdmpvgnclx3eive"`; `read_key()` reads `op://Connectors/<item_id(TITLE, ITEM)>/credential` (vault by name, not ID r6z62bjyy3c5ipilbgs4lyakwi, as in orgo_op.py); one docstring line. sha256 de90640fc4a9 -> bcfff5b82a4b.
- test_firecrawl_op.py (new, sha256 9a344762d3ad): 6 tests. A fake `op` on PATH serves the vault, the Keychain read is stubbed, exec is captured. The live case runs only with `FIRECRAWL_OP_LIVE=1` (outside the sandbox); a stand-in answers `op read`, so the test never reads the key.

## 3. Research (owner rule 5; Exa through Composio, 2026-10-02 ~03:00Z, $0.014)
- log_Tk9zeaCKtKzY: developer.1password.com/docs/cli/reference says IDs are the most stable reference and change only when an item moves vault, so look the title up, then read by ID. developer.1password.com/docs/cli/reference/management-commands/item covers `op item list` and get by name or ID. These are the same sources spp-p33a used (notes/fresh-vault-fixes.md §3).
- log_A4zqEzWs1ZEK: docs.firecrawl.dev/sdks/cli and the github.com/firecrawl/cli README say `--status` shows version, auth, concurrency and credits, with sample output "Authenticated via FIRECRAWL_API_KEY". In the installed CLI (firecrawl-cli 1.25.1, dist/commands/status.js L37 and L55), `--status` makes only two GETs (`/v2/team/queue-status`, `/v2/team/credit-usage`), so it spends no credits (credits go to scrape, crawl, map and search: docs.firecrawl.dev/billing.md, notes/firecrawl-connector.md L19).

## 4. Tests
- RED, before the change: 4 of 5 default tests failed for the expected reason (today's code read `op://r6z62bjyy3c5ipilbgs4lyakwi/uuopqngw4ikpdmpvgnclx3eive/credential`). The refusal test passes before and after by design, because it pins kept behaviour. Live case RED: its only `op` call was that fixed read, with no title lookup (the stand-in answered it).
- GREEN: 5 of 5 with 1 skipped (live), on Python 3.14.6 and /usr/bin/python3 3.9. All 12 agents-home test files pass: firecrawl 6, fresh-vault 28, modal 8, ir-notes 9, health 19, guards 27 + 5, ledger ALL PASS, ranking 5 + 6, scrapling PASS, meta manifest 4.

## 5. Live proof: PASSED 2026-10-02T17:40:05Z (the `op` blocker below is resolved)
This supersedes the two NOT_PROVEN rows in §1 and the header's Gap and Next: the live case and `--status` are now VERIFIED live.
- Run by a Claude Code subagent of session 294b676b (conductor v2.3), outside the sandbox, after the Director found `op` answering again (`op vault list` with the Keychain connectors-sync robot, under 20 s).
- Every `op` call ran under a 30 s hard timeout. A PATH shim in the session scratchpad (never installed) wrapped /opt/homebrew/bin/op: Perl forks, keeps the alarm in the parent, stops the child with TERM and then KILL, and interrupts the caller so nothing loops.
- The plain `perl -e 'alarm 30; exec @ARGV'` would not have stopped `op`. `op` is a Go binary, and Go catches SIGALRM and ignores it. Test, 2026-10-02: alarm 2 stopped C `/bin/sleep 8` at 2 s (rc 142), but Go `rclone obscure -` on an open pipe ran its full 8 s (rc 0). The fork wrapper stopped the same Go program at 2 s (rc 124).

| Check | Result | Evidence |
|---|---|---|
| `FIRECRAWL_OP_LIVE=1 python3 test_firecrawl_op.py`, 17:40:01-03Z | 6 of 6 OK, live case included | `test_the_real_vault_gives_todays_item ... ok`: the real `op item list` ran, and the stand-in's log was exactly `item list --vault Connectors --format json`, then `read op://Connectors/uuopqngw4ikpdmpvgnclx3eive/credential`. The stand-in answered the read, so the test never read the key. |
| Found by exact title, not by the fallback | VERIFIED | Read-only check with the wrapper's own `op_items.list_items` and `pick` (item summaries only, no value read): vault Connectors has 35 items, exactly 1 titled "Firecrawl API key", and it is uuopqngw4ikpdmpvgnclx3eive, so `pick()` takes the title path. |
| `./firecrawl_op.py --status`, 17:40:05Z | "Authenticated via FIRECRAWL_API_KEY" | firecrawl cli v1.25.1; Concurrency 0/2 jobs; Credits 885 / 1,000 (89% left this cycle); no local .firecrawl cache. It makes two read-only GETs (§3) and spends 0 credits. The key was never printed. |
| `op` calls | 4, all exit 0, longest 0.47 s, 0 timeouts | Shim log: item list (test), item list + read (`--status`), item list (title check). |

Blocker history (resolved; kept as evidence):
- Symptom: `op item list --vault Connectors --format json` with the robot token hangs inside and outside the sandbox, with stdin from /dev/null, and with or without `OP_BIOMETRIC_UNLOCK_ENABLED=false`; `op --version` returns at once. `sample` shows one thread in `__open` the whole time, and lsof shows only fds 0-2, so no network yet. DNS for my.1password.com resolves in 0.01 s, HTTPS returns 200 in 0.11 s, and there are no proxy variables.
- Cause, from the TCC log (read with /usr/bin/log; no container opened): App Data request msgID 29471.238 from `/usr/bin/find` (responsible process Claude Code, pid 87955) at 23:01:26.804 has no result. Just before it, about 20 `op` App Data requests (23:01:08-24, another agent) were answered in under a second from the cached Don't Allow (authValue 0, authReason 2). Since then, `op` calls log only their silent Full Disk Access preflight and never reach their App Data request, so Claude Code's App Data checks are queued behind the open one. Probable but NOT_PROVEN (no screenshot taken): a "would like to access data from other apps" prompt is waiting on screen.
- Hung finds, all from other agents' Bash calls and all still waiting at 23:18:52; none were killed:
  - PID 48767, 23:01:25: `find /Users/alexlobaito -maxdepth 4 -type d ( -name agents-home -o -name master-connector-repo ...`
  - PID 49349, 23:01:57: `find /Users/alexlobaito -maxdepth 4 -iname *duke*.md`
  - PID 51378, 23:05:43: `find "/Users/alexlobaito/Library/Group Containers" -iname *openai* -o -iname *chatgpt*` (breaks decision 1, notes/macos-app-data-prompt.md)
  - PID 51910, 23:07:15: `find /Users/alexlobaito -name Lead_Followup*.md`
  - PID 52402, 23:07:39: `find /Users/alexlobaito -name Lead_Followup_Playbook_Merged.md`
- Resume when the request is answered (Alex's standing answer is Don't Allow) or the hung finds end. Then run, outside the sandbox: `cd ~/.agents/tools/connectors && FIRECRAWL_OP_LIVE=1 python3 test_firecrawl_op.py && ./firecrawl_op.py --status`. Expected: 6 of 6 OK, then "Authenticated via FIRECRAWL_API_KEY".

## 6. Side effects
- Only `~/.agents` 10b9aa9, snapshot system/snapshots/2026-10-01_2301_spp-p43a/, the 23:01 CHANGELOG entry, this note and the run-log and workbook-updates lines. No 1Password write, no Firecrawl call, no key read: every real `op` call hung before listing, and the 5 hung calls were stopped, with no process left. Composio: 2 EXA_SEARCH calls.

## 7. Findings for the Director
1. While §5 lasts, every `op` user blocks: orgo_op, modal_op, firecrawl_op, push_key_to_composio, gcloud_robot, sync_notes, and the post-commit hook on card commits.
2. Stale text in a control file (not edited, rule 5): `~/.agents/skills/tool-card/references/cli-wrapper.md` L43 and its repo-conform mirror still say "firecrawl_op.py (~/.agents 4b1e016; still reads a fixed item ID)". Proposed: "firecrawl_op.py (~/.agents 4b1e016; item by title since 10b9aa9)".
