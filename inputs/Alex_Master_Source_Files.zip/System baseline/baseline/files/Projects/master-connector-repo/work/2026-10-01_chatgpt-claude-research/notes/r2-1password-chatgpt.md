# 1Password for Alex's ChatGPT: the strongest safe setup on every surface

Job: `work/2026-10-01_chatgpt-claude-research`, note r2. Read-only research, 2026-10-01.
Nothing was installed, signed in, changed or sent. No `op` command was run, and no key value was read or printed.
Method: Exa through Composio (about 16 searches and 20 page reads, roughly $0.15, estimated), plus local files.
Reused, not repeated: `work/2026-10-01_master-sop/notes/onepassword-newest.md` (same-day research on 1Password's 2026
features: rate limits, service-account rules, CLI changes). This note adds the ChatGPT-specific facts.
Proof labels: **DOC** = official page read 2026-10-01 · **FILE** = on disk on this Mac · **SEEN** = live output today ·
**2ND** = secondary source · **NOT_PROVEN** = not checkable from here.

## Verdict in plain words

1. **Yes, the 1Password plugin in ChatGPT's plugin directory is the official one, and it's the only official 1Password
   integration for ChatGPT. Keep it, but it isn't the powerful one.** It only manages 1Password *Environments*, a
   separate developer feature. It can't see the Connectors vault where your keys live, and it never returns a secret.
   It runs only in the ChatGPT desktop app on the Mac and in Codex. On the web and the phone it does nothing. (DOC, FILE)
2. **The directory listing itself is "skills-only".** It installs instructions; the actual tools come from the
   1Password desktop app's local MCP server, which you turn on in 1Password and point Codex at. That's already
   configured in `~/.codex/config.toml`. (DOC: plugin repo README; FILE)
3. **There's no official 1Password app for ChatGPT on the web, the phone or in agent mode.** 1Password's MCP server is
   local only. Its "AI signs in without seeing the password" feature exists for Claude and Browserbase, not ChatGPT.
   A 1Password employee confirmed this on 2026-08-27 and filed a feature request. (DOC)
4. **The strongest safe way to move a key from 1Password into Composio is the route you already run.** You put the key
   into its 1Password item. A script on the Mac reads it with the read-only robot login and sends it to Composio
   without printing it. ChatGPT runs that script through Codex on the Mac, either at the desk or from the phone through
   Codex Remote. It was proven on 2026-10-01 with the Foreplay key. (FILE, run log)
5. **Any route that lets ChatGPT read a vault item directly puts the raw key in the chat.** That covers Composio's own
   1Password toolkit and community MCP servers. It breaks your "keys never in chat" rule, so it isn't a stronger
   option; it's ruled out. (DOC)
6. **Agent mode in 2026 means ChatGPT Work's cloud browser, Work Cloud and dots.** These handle website logins through
   ChatGPT's own secure sign-in form. The model never sees the password, and on iPhone 1Password can fill that form.
   That works for logins, not API keys. (DOC)

## Comparison table

| # | Option | Surfaces where it works | What the AI can do | Does a secret reach the model? | Sign-in and limits | Fit: 1Password → Composio without the AI seeing the key |
|---|---|---|---|---|---|---|
| 1 | **1Password plugin in the ChatGPT plugin directory** (same package as the 1Password Codex plugin; v0.2.0 installed) | ChatGPT desktop app on the Mac (Work and Codex chats, "Local" host) and Codex CLI. Not web or phone: OpenAI says a saved plugin's local tools don't reach web or mobile | Nothing by itself; the directory version is skills-only. Its tools come from row 2 | No | Same as row 2 | None on its own |
| 2 | **1Password Environments MCP server** (`1password-mcp`, runs inside the 1Password desktop app) | Mac and Linux; only local (stdio) clients. 1Password: "Remote-only MCP clients aren't currently supported." So no web, phone or cloud | Create, list and rename Environments; list variable **names**; add or update variables; create and list mounted .env files. It can't see vault items | **Never on reads**: the server won't return values even if asked. **Yes on writes** if the AI types the value into `append_variables` | The 1Password app asks to approve each client connection and each Environment; approval lasts until 1Password locks. Turn on under Settings > Labs > MCP Server, then Developer > Integrate with MCP clients. An owner or admin must turn on the Environments policy; Enterprise admins can switch the local MCP server off | Poor: it can't read or push your vault keys |
| 3 | **Environments + mounted .env file** | Mac and Linux desktop app for mounts; reads elsewhere through the CLI beta or SDKs; not iOS or Android | Programs read the mounted file on demand; the agent should never open it | No, unless the agent opens the file | Desktop app must be unlocked. Service accounts can only **read** Environments | Possible, but every key would then live in two places (vault and Environment). Not now |
| 4 | **`op` CLI with desktop-app sign-in** (Touch ID; SDKs got the same prompt in Feb 2026) | Mac shell: Codex in the ChatGPT app, Codex CLI. From the phone only if someone approves at the Mac | Everything your own account can do: read and write any item in any vault | Only if a command prints it (`op read`, `op item get --reveal`). `op run` masks secrets in output by default | Touch ID, Apple Watch or Mac password for each new terminal session; the session lasts 10 minutes and refreshes on use. The prompt appears on the Mac | Good for the **save** step (key into its item, you approve). Too broad to leave unattended |
| 5 | **Service accounts + op:// references** (`op run` or non-printing scripts). Yours: `connectors-sync` (read-only) and `connectors-sync-rw` (read-write) on the Connectors vault | Any machine with `op` and the token: the Mac (Keychain) and the Orgo hub. ChatGPT reaches it wherever it has a shell on that machine: desktop app (Local host), Codex CLI, the phone through Codex Remote, and dots with local computer access. Not web chat, cloud browser or Codex Cloud | Read (RO) or write (RW) items in the Connectors vault only. The push script sends a key to Composio and prints only the connection ID | No, as long as the script never prints it; `push_key_to_composio.py` doesn't | No human prompt, which is both the power and the risk. Scope is fixed at creation; no Private vault access; hourly and daily rate limits by plan (earlier note, rows 1–2) | **Best.** Proven 2026-10-01 (Foreplay → Composio `custom_foreplay`; test call passed; `system/run-log.md` line 92) |
| 6 | **1Password browser extension in ChatGPT's desktop built-in browser** (or your real Chrome through the ChatGPT browser extension) | ChatGPT desktop app (Mac, Windows). Chrome, Edge, Brave, Opera and Vivaldi through the ChatGPT extension | ChatGPT waits while **you** fill a login. An OpenAI engineer reportedly said the agent can't operate extensions itself (2ND) | No, but the agent sees the page after you sign in | Normal extension unlock. 1Password's advisory: turn off auto sign-in to 1Password.com, require confirmation before filling, use a short lock time while an AI drives the browser | None for API keys (logins only) |
| 7 | **ChatGPT's secure sign-in form + a password manager** (Work cloud browser, Work Cloud, dots) | Web and phone, plus dots. OpenAI: on iOS a supported password manager can fill the form | Pauses and asks you to sign in, then continues in that session | No. OpenAI says the credentials go straight to the remote browser, aren't visible to the model and aren't stored. This doesn't cover passwords pasted in chat or passed through a plugin | Sessions persist until they expire (clear them in Settings > Cloud browser > Browser data). The cloud browser doesn't use your extensions or saved passwords | None for API keys (logins only) |
| 8 | **1Password Agentic Autofill / "1Password for Claude"** | Browserbase Director (early access) and Claude only | Not available in ChatGPT | — | — | Not available for ChatGPT |
| 9 | **Composio's own 1Password toolkit (`_1password`)**: not made by 1Password; listed because it's the only route that would reach ChatGPT web and phone | Every ChatGPT surface, through the Composio app | List vaults and items; **Get Item returns "all fields and secrets"**; create, update and delete (deletes are permanent) | **Yes** | API key, meaning a service-account token stored in Composio (toolkit version 20260715_00) | **Breaks the rule. Don't connect it.** Not connected today (SEEN: `composio search` shows no connected `_1password` login) |
| 10 | Other official 1Password MCP servers (Device Trust MCP, 2026-05-14; SaaS Manager/Trelica MCP) | Varies | Admin and device data, not secrets | — | — | Not relevant |
| 11 | OpenAI's own secret stores (Codex Cloud network secrets and personal vault; Agents API vaults). Not 1Password | Codex Cloud tasks, which can be started from desktop, web or phone | Programs get a placeholder, and a proxy swaps in the real value for allowed HTTPS hosts | No for network secrets; yes for plain environment variables | You paste the value into OpenAI | It creates a second home for the key. Skip it for this flow |

1Password Connect and Unified Access / Credential Broker aren't needed here (earlier note, rows 8 and 13–14).

## By surface: what 1Password can do in each

| Surface | 1Password route | Can it move a key into Composio without the AI seeing it? |
|---|---|---|
| ChatGPT desktop app on the Mac (Work and Codex chats) | Plugin + MCP (Environments only); `op` and the push script through the shell; 1Password extension in the built-in browser for logins | **Yes**, through the push script |
| Codex CLI (Mac terminal) | Same as the desktop app, minus the built-in browser (OpenAI: Browser isn't available in Codex CLI) | **Yes** |
| ChatGPT web | No 1Password tools. Cloud-browser logins use the secure form; you fill it yourself | **No** (unless the hub route under "Later" is built) |
| ChatGPT on the phone | No 1Password tools in chat. 1Password fills the secure sign-in form through iOS AutoFill. Codex Remote can drive the Mac | **Yes, through Codex Remote**, if the Mac is awake, online and running the ChatGPT app |
| Agent mode (Work cloud browser, Work Cloud, dots) | Secure sign-in form + password manager. Dots can use your plugins and, with local computer access, run commands on the Mac | Only through the Mac (dots local access is NOT_PROVEN on Pro) |
| Codex Cloud | No 1Password. OpenAI network secrets instead | **No**; not recommended |

## Recommended setup for ChatGPT

**One setup:** 1Password stays the only home for keys, and ChatGPT never reads a key. On the Mac, ChatGPT runs the push
script. Everywhere else, you put the key into 1Password yourself, and ChatGPT pushes it through the Mac.

Steps in order:
1. Keep the 1Password plugin in the ChatGPT desktop app (already installed: SEEN in `setup-playbook/notes/live-chatgpt.md`
   §2). Keep `[mcp_servers.1password] command = "1password-mcp"` in `~/.codex/config.toml` (already there: FILE). Don't
   add a second 1Password plugin or any community 1Password MCP server.
2. In 1Password for Mac, turn on Settings > Labs > MCP Server > "Enable local MCP server", then under Settings > Developer
   turn on "Integrate with MCP clients" and "Integrate with 1Password CLI". Whether these are on now is NOT_PROVEN. This is
   needed only if you want the plugin to manage Environments.
3. Test the plugin once from a ChatGPT desktop chat with "List my 1Password Environments" and approve the prompt in
   1Password. Expect an empty or short list, because your keys are vault items, not Environments.
4. Keep the Connectors vault as the only home for keys. Don't copy keys into Environments, Codex Cloud secrets or
   OpenAI vaults.
5. **Key flow at the Mac (unchanged):** you copy the key. ChatGPT (Codex or Work on the Local host) checks only its
   length, saves it to its item with `op item edit` (you approve with Touch ID), clears the clipboard, runs
   `~/.agents/tools/connectors/push_key_to_composio.py --item <id> --toolkit <slug>`, then runs one read-only Composio
   tool to prove it. Never `op read` in a chat shell; use the script, or `op run`, which masks output.
6. **Key flow from the phone:** paste the key into its pre-made "paste here" item in the 1Password phone app yourself.
   Then, in the ChatGPT app, use Codex Remote to reach the Mac and ask it to run the push script. The push uses the
   read-only robot login, so it needs no Touch ID. The Mac must be awake, online and running the ChatGPT app.
7. **Website logins in agent mode** (Work cloud browser, dots): use ChatGPT's secure sign-in form, and let 1Password fill
   it on the iPhone. Never paste a password into the chat.
8. If you add the 1Password extension to ChatGPT's built-in browser, set it up the way 1Password's own advisory says:
   Settings > Security > turn off "Automatically sign in to 1Password in the browser", turn on confirmation before filling
   logins, and use a short lock time.
9. Don't connect Composio's `_1password` toolkit.

**What has to stay Mac-only**
- The 1Password MCP server and the plugin's tools (local stdio inside the desktop app).
- Touch ID approvals for `op` desktop sign-in. So when an agent saves a key, you have to be at the Mac to approve.
- The read-only robot token in the Mac Keychain and the push script. The Orgo hub holds the same token, so this could
  move off the Mac later.
- Reading a copied key from the clipboard (`pbpaste`).
- Mounted .env files.
- The 1Password extension in ChatGPT's built-in browser (a desktop app feature).

**What works away from the Mac:** secure sign-in in the cloud browser and dots, with 1Password filling it on the iPhone,
and starting the push from the phone through Codex Remote while the Mac is on.

**Later, if you want it (not built; needs your go):** a hub route on `mcp.increaseroas.com` that runs the same push
script against a fixed allowlist of item → toolkit pairs, exposed through Composio. ChatGPT web, the phone and dots
could then push a key without the Mac, and still never see it.

## Risks
1. **The Keychain robot token has no human gate.** Any agent with a shell on the Mac can use it to read the whole
   Connectors vault, and Codex runs with Full access and `approval_policy = never` (FILE: `live-codex.md` §2). A
   prompt-injected agent could print a key. Option for you to decide (untested; check the Codex rules syntax first): a
   rule in `~/.codex/rules/default.rules` that stops the agent from running `op read` or
   `security find-generic-password -w` itself, so only the scripts use them.
2. **MCP writes expose values.** If the AI types a key into `append_variables`, the key passes through the model. Only
   add a value that's already visible in the chat, or add it yourself in the 1Password app.
3. **An unlocked extension plus an agent-driven browser is a risk.** 1Password's advisory (2026-01-30) says prompt
   injection can trigger autofill on matching sites, or open the web vault through an unlocked extension. Step 8 covers
   this.
4. **OpenAI's sign-in protection has limits.** It doesn't cover passwords pasted in chat or returned by a plugin.
5. **Approvals happen on the Mac.** From the phone, anything that needs Touch ID (the MCP connection, `op` desktop
   sign-in) stalls until you're at the Mac. Step 6 avoids that, but it depends on you remembering to save the key in the
   phone app first.
6. **Where the read-write robot token lives is unresolved.** The 2026-10-01 Foreplay run says it isn't in the Mac
   Keychain (run log line 92), while line 65 says Mac Keychain + Orgo. Until that's settled, agent-driven saves need
   your Touch ID.
7. **Plan and policies are unknown.** Teams or Business, the Environments policy and the MCP setting decide rate limits
   and whether the plugin works at all.
8. **Composio holds a copy of every pushed key.** Composio disclosed a breach on 2026-05-21; your logins were all created
   after it. 1Password stays the source, and the rotation drill is in the Master SOP.
9. **Two doc conflicts.** 1Password's docs say the Codex MCP setup supports Mac and Linux; the plugin README says
   macOS, Windows and Linux. The docs put the MCP switch under Settings > Labs; the README says Settings > Developer. The
   Mac is covered either way.
10. **Atlas is gone.** It stopped working on 2026-08-09, so any plan built on Atlas or 1Password's Atlas support is dead.

## NOT_PROVEN, and what would prove it
| Item | What would prove it |
|---|---|
| Whether the 1Password app has the local MCP server on and Codex approved | You check 1Password > Settings > Labs and Developer, or one "List my 1Password Environments" call from ChatGPT desktop |
| Whether any Environments exist | The same call |
| How the 1Password listing looks in ChatGPT on the web ("Desktop only" or skills-only) | Open Plugins in ChatGPT web and read the 1Password listing |
| Whether the read-write robot token is in the Mac Keychain | Keychain metadata lookup without `-w` (no secret read) |
| Whether dots on a Pro plan can run commands on the Mac | OpenAI's consumer dots help page (only the Enterprise admin page was read), or one test |
| Your 1Password plan type | 1Password.com billing page |

## Sources (all read 2026-10-01)
OpenAI
- Plugins in ChatGPT and Codex: https://help.openai.com/en/articles/20001256-plugins-in-chatgpt-and-codex (updated about
  2026-09-29). The App directory became the Plugin directory on 2026-07-09. Local MCP apps run on ChatGPT Desktop; saving
  them "does not make those tools available on web or mobile."
- Using the built-in browser in the ChatGPT desktop app: https://help.openai.com/en/articles/20001277-using-the-built-in-browser-in-the-chatgpt-desktop-app
  (updated about 2026-09-30). Its own browser state; supports sign-in, autofill, password management and extensions.
- Using cloud browser in ChatGPT: https://help.openai.com/en/articles/20001280-using-cloud-browser-in-chatgpt (updated
  2026-09). Credentials are "not visible to the model"; it doesn't use your extensions or saved passwords.
- ChatGPT Learn, Browser: https://learn.chatgpt.com/docs/browser (undated). On iOS a supported password manager can fill
  the secure form; Browser isn't in Codex CLI.
- ChatGPT Learn, Work local security: https://learn.chatgpt.com/docs/enterprise/chatgpt-work-local-security (undated).
- Dots privacy, security and safety FAQs: https://help.openai.com/en/articles/20001529-dots-privacy-security-and-safety-faqs
  (2026-09-30).
- Manage dots in ChatGPT workspaces: https://help.openai.com/en/articles/20001554-manage-dots-in-chatgpt-workspaces
  (2026-10-01). Includes the "Use password manager" control and local computer access.
- ChatGPT release notes: https://help.openai.com/en/articles/6825453-chatgpt-release-notes. Entries used: 2026-06-04
  (Codex in the mobile app), 2026-06-25 (Codex Remote GA), 2026-07-13 (Retiring Atlas), 2026-08-25 (Work browser
  supports password managers), 2026-09-03 (site tools; browser extension in more browsers).
- Using Codex Cloud: https://help.openai.com/en/articles/20001545-using-codex-cloud (2026-09-30), and ChatGPT Learn,
  Cloud environments: https://learn.chatgpt.com/docs/environments/cloud-environments (undated; network secrets).
- OpenAI customer story, 1Password and Codex: https://openai.com/index/1password/ (2026-09-08). "secret references keep
  plaintext credentials out of model context."

1Password
- Environments MCP Server: https://www.1password.dev/environments/mcp-codex-server (undated): "Remote-only MCP clients
  aren't currently supported."
- Environments: https://www.1password.dev/environments (undated). Not available on iOS or Android; an admin turns on the
  policy.
- Secure secrets for AI agents and tools: https://www.1password.dev/get-started/secure-ai-access (undated).
- Agentic Autofill (early access, Browserbase Director): https://www.1password.dev/agentic-autofill (undated).
- `op run` reference (masking on by default, `--no-masking` turns it off): https://www.1password.dev/cli/reference/commands/run (undated).
- CLI app integration security (10-minute session per terminal): https://www.1password.dev/cli/app-integration-security (undated).
- 1Password Codex plugin repo: https://github.com/1Password/1password-codex-plugin (created 2026-05-20): "a skills-only
  listing installs the skill but does not configure the MCP server".
- Community answer from a 1Password employee: https://www.1password.community/1password-at-home-31/using-1password-inside-of-the-chatgpt-desktop-app-25397
  (2026-08-27): "There isn't a way to directly integrate 1Password with the ChatGPT app."
- Security advisory on AI-assisted browsing: https://1password.com/blog/security-advisory-for-ai-assisted-browsing-with-the-1password-browser (2026-01-30).
- Universal sign-in: https://1password.com/blog/introducing-universal-sign-in (2026-09-02). Agent-driven sign-in is
  described for Claude only.
- 1Password for Claude press release: https://1password.com/press/2026/july/1password-for-claude (2026-07-15).
- Trusted access layer for Codex: https://1password.com/blog/1password-trusted-access-layer-for-openai-codex (2026-05-20).
- Device Trust MCP Server: https://1password.com/blog/device-trust-mcp-server-natural-language-queries-for-your-entire-fleet (2026-05-14).

Composio
- 1Password toolkit: https://docs.composio.dev/toolkits/_1password (version 20260715_00). Get Item returns
  "all fields and secrets."

Secondary (2ND)
- Lookonchain news brief: https://lookonchain.com/feeds/73181 (2026-09-19). Chrome extensions in ChatGPT's built-in
  browser, demoed with 1Password; an OpenAI engineer reportedly said agents can't operate extensions. Not confirmed by an
  OpenAI page beyond "supports ... extensions".

Local evidence (FILE / SEEN)
- `~/.codex/plugins/cache/openai-curated-remote/1password/0.2.0/.codex-plugin/plugin.json` and
  `skills/1password-environments/SKILL.md`: "Manage Developer Environments"; no `.mcp.json` in the cached copy.
- `~/.codex/config.toml`: `[mcp_servers]` holds `1password`, `cua_repl` and `node_repl`; the `1password` entry is only
  `command = "1password-mcp"`, with no env block (structure read; no values printed).
- `work/2026-10-01_setup-playbook/notes/live-chatgpt.md` §2, §6 and `live-codex.md` §2, §8 (installed plugin, Full
  access, `op` desktop sign-in, Keychain robot token).
- `~/.agents/tools/connectors/push_key_to_composio.py` (reads with `op read` into a variable, prints only the connection ID).
- `system/run-log.md` lines 65 and 92; `system/handoff/2026-10-01_connectors-handoff.md` lines 19–21 (the key flow).
- `composio search "get 1password item secret" --toolkits _1password` → `connected_toolkits: []` (SEEN 2026-10-01).
