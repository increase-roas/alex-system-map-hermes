# IR-notes lookup fix (play spp-p41a)

LOCK (spp-p41a, 02:34Z to 02:49Z, RELEASED): `~/.agents/tools/connectors/ir_notes/server.py` (edit) and `~/.agents/tools/connectors/ir_notes/test_server.py` (new). Also ran `sync_notes.py --server` (idempotent; uploads the current cards and server.py to the hub). Nothing else in `~/.agents`: not `instructions/shared.md` (Modal/Hugging Face plays hold it), not `tools/cards/`.

Mission `mission-setup-playbook-parity`, node `app-rules-redesign` (follow-up bug). Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first. 2026-10-02 02:33–02:49Z (2026-10-01 22:33–22:49 local). Start: `~/.agents` a8d07ff, tree clean.

## Result

| What | Evidence |
|---|---|
| Live: `app=google-ads` returns the Google Ads card; all 15 hub card names return their own card | Composio CLI `CUSTOM_IR_NOTES_GET_APP_RULES --account ca_zTNUL9d6xZDl`, 02:46:54Z: 15/15 byte-identical to `~/.agents/tools/cards/<name>.md`; `adwords` and `googleads` → google-ads; `ghl-command-builder` → ghl; `facebook` → "Closest: meta-ads" (`transcripts/spp-p41a/live-after-0246Z.txt`) |
| Fix | `~/.agents` 017d71b (server.py + test_server.py only; post-commit hook skipped; not pushed) |
| Hub | `sync_notes.py --server` 02:44:33Z: 15 cards, restarted, cards: 15, Composio refresh 200 |
| Test | `test_server.py`, 9 tests: 11 failures on the snapshot's server.py, 0 on 017d71b (re-run with the 16th card, huggingface, too). The other agents-home suites: 82/82 pass |

## Root cause

- The lookup (written in 7646c06; 7f35eeb's server.py edit didn't touch it) gave each card every slug its text mentions (`custom_*`, `googleads`, `google_analytics`, `ghl-*`), then returned the first card in file order whose names held the query.
- 7f35eeb rewrote composio.md. Its new `logins:` line names `googleads`, and composio sorts before google-ads, so `app=google-ads` (normalized `googleads`) hit composio. Today's patch triggered it through the card text, not through its server.py change.
- Same mechanism, found by the test: `web-search` → exa (exa's alias "web search", added in 2713b89), and `ghl-command-builder` → ga4 (ga4.md mentions it).
- Live before, 02:32Z: `google-ads` and `googleads` → composio; `web-search` → exa; `ghl-command-builder` → ga4; `adwords` and `modal` correct (`transcripts/spp-p41a/live-before-0232Z.txt`).

## The fix

1. The exact card name (file name) wins.
2. Next come names the card declares: title, aliases, and the toolkit slugs in its own `route:` line. `custom_` slugs also count without the prefix, so `ghl-oauth-crm` reaches ghl. A mention anywhere else in a card claims nothing.
3. If two or more cards declare the name: "Several apps match …; ask for one by name". File order never decides.
4. If there's no exact or declared match: "No card is named X. Closest: …". That only suggests names and never returns a card. If nothing is close, the old no-card message.

`load()` now also closes each card file, so the tests run with no warnings.

Research (owner rule 5): 2 Exa searches via Composio, `exa_beode-vain`, $0.014.
- Python's argparse accepts an abbreviated option only when it's unambiguous, and `allow_abbrev` switches that off: https://docs.python.org/3/library/argparse.html
- Git names the similar command for a typo "but it still refuses to do it" (help.autocorrect): https://git-scm.com/book/be/v2/Customizing-Git-Git-Configuration

## Other names, old vs new (190 names probed)

14 changed:
- **4 wrong picks fixed:** google-ads, googleads, web-search/websearch, ghl-command-builder.
- **Guesses are now suggestions:**
  - `facebook` (was meta-ads, now "Closest: meta-ads")
  - `hubspot crm` (was ghl)
  - `context7 docs` (was google-workspace)
  - `ads`
- **5 slugs that only appear in a card's body now get a suggestion naming the right card:** `custom_firecrawl_mcp`, `custom_google_tag_manager`, `custom_htl_google_tracking`, `ghl-mcp`, `ghl-oauth-gateway`. That costs one extra call. Adding them to that card's aliases would make them direct.

"web search" is declared by two cards: it's exa's alias and web-search's own name. Rule 1 gives the web-search card, which sends readers to Exa first.

## Add-on (Director): index cut 70 → 100, not applied

- The template allows up to 100 characters (`candidates/app-rules/card-template.md` L5), but 12 of the 16 index lines are longer than that (101 to 204 chars).
- With 16 cards, a 278-char head, a 1,900-char cap and a 1,650-char body budget (the rest is left for alias words):

  | Width | Chars | Fits? |
  |---|---|---|
  | 100 | 2,016 | no, 116 over the cap |
  | 90 | 1,888 | under the cap, but over the budget, with no room for alias words |
  | 70 (now) | 1,609 | yes |

- The served description is 1,891 chars and lists all 16 card names.
- A 17th card at width 70 makes about 1,695 chars, which is over 1,650, so `describe()` drops to width 50.

## How it ran

Order: lock line → Exa → snapshot `system/snapshots/2026-10-01_2234_spp-p41a/` → CHANGELOG → test (red: 11 failures) → fix (green: 9/9) → suites → commit → sync → live proof → workbook-updates + run-log.
- **Commit:** ran inside the sandbox with the hook off (`git -c core.hooksPath=/dev/null`). The hook would also run `build_instructions.py apply` (CLAUDE.md and AGENTS.md from the held shared.md) and `cards_to_sheet.py` (the workbook).
- **Sync:** only the sync needs `op`. It failed TLS inside the sandbox (x509 OSStatus -26276; nothing reached the hub), then ran outside it.

## Not done or not proven

- **huggingface.md isn't on the hub.** The Hugging Face play wrote it (uncommitted) at 02:46Z, after this sync. Its local lookup passes; the hub has 15 cards until that play syncs.
- **Chat apps not re-run.** I didn't call the hosted tool again from the Claude app or ChatGPT. They use the same hosted server.
- **Not pushed or committed:** agents-home isn't pushed, and this play's repo files are uncommitted, like the other plays' lines in run-log.md and workbook-updates.md.
