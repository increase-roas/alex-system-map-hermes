# spp-c4d code fixes: N05, N06, N02 (play spp-p44a)

LOCK (spp-p44a, 2026-10-02T03:03Z to 03:16Z, RELEASED): in `~/.agents`: `tools/unify/git_setup.sh` (edit), `tools/unify/test_git_setup.py` (new), `tools/connectors/hub/rebuild_hub.py` (edit), `tools/connectors/gcloud_robot.py` (docstring only), `tools/connectors/test_fresh_vault.py` (new tests added). Read only: `tools/connectors/hub/install_hub.sh`. Not touched: `firecrawl_op.py` and its test (spp-p43a holds them), cards, instructions, skills, the live hub (no `--computer` run). Commits name only these paths; no push.

Mission `mission-setup-playbook-parity`, node `replication-retest`. Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first. 2026-10-02 03:01–03:16Z (2026-10-01 23:01–23:16 local). Start: `~/.agents` 3a970c2 (spp-p43a's uncommitted firecrawl files left alone). Input: notes/replication-retest-final-2.md §4.

## Result

| Gap | Fix (`~/.agents` 4fe35e6, not pushed) | Proof |
|---|---|---|
| N05 | git_setup.sh L39–L41: `\b` in front of both sk- patterns | Fresh clone of 3a970c2: exit 1 (`skills/ce-work/references/non-code-execution.md:10`). Fresh clone of 4fe35e6, run as a newcomer runs it: exit 0, with that line still in the tree. Planted fake key: exit 1, only `tools/planted-fake.env:1`, key not in the output, no commit. Key removed: exit 0. Student-edition copy (no history): before, exit 1 and no commit; after, exit 0 and first commit a18bc0c (2,394 files) |
| N06 | rebuild_hub.py: `--exit-node` or `EXIT_NODE` → `EXIT_NODE=<v> bash /tmp/hub-rebuild/hub/install_hub.sh` on the hub. Unset sends the old line, so install_hub.sh L24's default stays. A value that isn't an IP or name stops before any secret is read | Dry runs (contact nothing): no choice → `exit node sashas-mac-mini.tailde26a1.ts.net`; `EXIT_NODE=100.64.0.9` → that node in the Mac plan and the hub's step 11; flag plus env → the flag's node; `x; touch /tmp/p` → exit 1, nothing ran. Payload with outside calls faked: `EXIT_NODE=100.64.0.9 bash /tmp/hub-rebuild/hub/install_hub.sh --force`. Live hub not contacted |
| N02 | gcloud_robot.py docstring (its `--help`): the example is `storage objects describe gs://cloud-samples-data/vision/label/wakeupcat.jpg`; iam roles describe, services list and projects list are named as 403 for this robot | `--help` prints the line. That exact call exits 0 as the robot: fix-k01-w20.md (17:15Z and 17:30Z, `vision/label/wakeupcat.jpg 64892 cloud-samples-data`) and fresh-vault-fixes.md L18 (after 79626ca, the wrapper's last code change). Not re-run live: docstring-only change |
| Tests | Written first | test_git_setup.py (new): 1 of 2 red on the old script (`1 != 0`), then 2/2. test_fresh_vault.py +5: 4 red (N02 `iam roles describe roles/viewer`; N06 SystemExit not raised, `--exit-node` rc 2, `'sashas-mac-mini…' != '100.64.0.9'`), then 28/28, 0 warnings. Guards that pass before and after: planted keys caught, default exit node kept. All 9 agents-home suites pass; the 2 touched pass on python3 3.14 and /usr/bin/python3 3.9.6 |

## Research (owner rule 5): Exa via Composio `exa_beode-vain`, 5 calls, $0.019

- gitleaks builds its token rules as `\b(` + key + `)(?:[\x60'"\s;]|\\[nr]|$)` (secretPrefixUnique, GenerateUniqueTokenRegex): https://raw.githubusercontent.com/gitleaks/gitleaks/master/cmd/generate/config/utils/generate.go (log_QXxOkuWsbJ2u). Its Anthropic rules start `\b(sk-ant-`: https://github.com/gitleaks/gitleaks/blob/master/config/gitleaks.toml (log_jcw8CxFfcAY8).
- `\b` under `grep -E`: GNU grep says it "matches the empty string at the edge of a word" (https://manpages.ubuntu.com/manpages/noble/man1/grep.1.html, log_5DsALXmvR3_z). macOS re_format(7) lists `\b` only for enhanced REs, so I tested /usr/bin/grep (BSD grep 2.6.0-FreeBSD) directly. The old pattern hit the phrase plus 3 key shapes; the new one hits only the 3 keys (after `=`, at line start, in quotes).
- Tailscale `--exit-node=<ip|name>` takes "a Tailscale IP or machine name", also `auto:any` (https://tailscale.com/docs/reference/tailscale-cli/up, log_Dxt1ecTVvNvS). tailscaled also takes a stable node ID. Hence the check `[A-Za-z0-9][A-Za-z0-9.:_-]*`.
- `shlex.quote`: "can safely be used as one token in a shell command line" (https://docs.python.org/3/library/shlex.html, log_M7N3PRWL69Qi).

## Decisions

- **Leading `\b` only, not gitleaks' end terminator.** The scan is a broad stop for any provider's sk- key, and the terminator would miss a key followed by `,`, `)` or `&`. A trailing `\b` would do nothing, because the character class already takes every word character. The other patterns are unchanged; the full tree has no hits from them (fresh clone exit 0).
- **rebuild_hub.py doesn't copy the default.** install_hub.sh L24 stays its one home, and an unset exit node sends the old command unchanged.
- **Docstring.** The services list example also returned 403 for the robot (fix-k01-w20.md table), so it moved with the IAM one into the "don't judge by" line.
- **Also in rebuild_hub.py:** secrets_table() now closes install_hub.sh (the suite's one ResourceWarning).

## How it ran

Order: lock line → Exa → snapshot `system/snapshots/2026-10-01_2305_spp-p44a/` → CHANGELOG → before runs → tests (red) → fixes (green) → all suites → commit → fresh-clone and student-copy runs in $TMPDIR → dry runs → workbook-updates + run-log.
- **Commit:** 4fe35e6, 5 paths, `core.hooksPath=/dev/null`, inside the sandbox (no `op` needed).
- **Hooks in the $TMPDIR runs:** turned off through `GIT_CONFIG_*` env wherever a commit could happen. The clean fresh clone ran exactly as a newcomer runs it; it made no commit, so no hook ran.

## Not done or not proven

- **Not pushed.** Partners clone agents-home from GitHub, so they get these fixes after the Director's push.
- **Student edition not rebuilt.** student_edition.py takes `git archive HEAD` of ~/.agents, so its next build carries 4fe35e6 (builder; queued in workbook-updates).
- **Workbook rows** (3.1, 3.4, 5.1, 8.2, All connections R150, section 19) are queued for the builder, not applied.
- **N06 on a real hub:** not run (the play said not to change the live hub). Proven by dry runs and the faked payload only.
- **GNU grep:** `\b` is documented there but wasn't run here (no GNU grep on this Mac). git_setup.sh runs on Macs.
