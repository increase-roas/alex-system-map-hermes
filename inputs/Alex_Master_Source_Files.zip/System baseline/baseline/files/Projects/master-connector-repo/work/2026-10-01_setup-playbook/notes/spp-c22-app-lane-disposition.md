# spp-c22: the app lane, one disposition per claim (Conductor, 2026-10-03 02:34 EDT)

Conductor v2.5, chat 9bc6cee2-392b-42df-a7d3-89efd205bd15, workspace ~/Projects/master-connector-repo. Read-only.
Supervising Director: da73c8be-6556-49cb-afdd-3e70c47b417b (ledger DIRECTOR_STATE.md L586, L711).

**Counts: 26 claims, each with one disposition: 15 HOLDS · 3 READY agent work · 3 OWNER steps · 5 NOT_PROVEN** (corrected 2026-10-03: row 4 moved from NOT_PROVEN to HOLDS).
- Action lists: 7 READY items (R1–R7, §5) and 4 OWNER click paths (O1–O4, §6).
- One change on Alex's security switch: ChatGPT's Composio permission reads "Allow all tools", and the records don't show why.

## How I know nothing changed
- **Every action was a read:**
  - a workbook export to the scratchpad (openpyxl, read-only);
  - names-only reads of `~/Library/Application Support/Claude/claude_desktop_config.json` and the Claude app's synced skills folders;
  - the read-only tools ListPlugins and session_connectors_status;
  - one REST `GET /api/v3.1/tools/CUSTOM_IR_NOTES_GET_APP_RULES`;
  - two Exa reads (docs only).
- **Never opened or used:** ChatGPT, the Claude app UI, Codex, Composio logins, ~/.codex files (one config section was read), or any window of Alex's.
- **Before/after:**
  - master workbook sha256 `c372e737f11ada88…` before and after this file;
  - ~/.codex/config.toml last written 10-03 01:57, before this play;
  - claude_desktop_config.json: correction (Director, 2026-10-03): it was last written at 06:25:52Z (02:25:52 EDT), 27 seconds after the play arrived, not before it. This play didn't write it: my only access was a names-only read. `mcpServers` is still empty, so no disposition changes.
- **The only write:** this file.

## 1. Report b §11 row 1 (L05, L07, V05, W13, the ghl-oauth-crm row)
| # | Claim | Disposition | Pointer |
|---|---|---|---|
| 1 | **L05**: ChatGPT keeps only Composio and no direct app duplicates a card route | **HOLDS** | The claims audit read ChatGPT in one new Chrome tab (2026-10-03 00:15–00:57 EDT): "Settings > Plugins lists exactly Composio, Finances, Superpowers" and "None of them [Descript, Exa, GHL app, GitHub, Gmail, Meta Ads] listed" (verify-codex-chatgpt-cursor.csv rows "ChatGPT plugins: only Composio, Finances, Superpowers" and "ChatGPT connectors other than Composio removed", both HOLDS). AI apps r14 names exactly Composio plus the kept Finances and Superpowers, with the why (workbook export 2026-10-03, L2187). The 10-01 Apps-list screenshot is in conductor-ui-lane.md L6. |
| 2 | **L07**: ChatGPT's Composio plugin is bound to alex@ | **HOLDS** (last proven 2026-10-01) | conductor-ui-lane.md L11–L12: installed and connected as alex@, a Foreplay read and a Google Doc create-then-trash. spp-c17: the test draft 1a0fa833026e9703 landed in alex@'s mailbox (run-log L161). The audit (10-03) found the plugin still installed but didn't re-read the account. A re-read is folded into READY #R4. |
| 3 | **V05, ChatGPT half**: the always-loaded instructions are saved | **HOLDS** | Audit row "ChatGPT custom instructions (new version) pasted": "Present (1,336 chars): Composio-only routing, app-rules line via CUSTOM_IR_NOTES_GET_APP_RULES, 'No 1Password connector here'" (read 10-03). |
| 4 | **V05, claude.ai half**: the claude.ai instructions are saved and read back | **HOLDS** (proven 2026-10-01 20:50Z) | notes/app-batch.md row 7 (L31) and its 20:50Z update (L180–L185). Alex clicked Save (owner statement relayed by the Director), then a read-only fresh load of Settings > Account showed 1,246 characters, sha256 first 32 `1fa79bcd2a1c80aebd3ec6de89a679f1` = V05 block 1. The parity graph's parity-fix-owner node keeps that spp-p15a receipt. Only a fresh current-state look stays open (R7). Correction 2026-10-03 (Director): my first search missed this record. Don't ask Alex to save it again without contrary evidence. |
| 5 | **W13**: Claude app inventory, AI apps r9 = 7 | **READY agent work** (r9 is out by one) | Live readbacks 2026-10-03: ListPlugins shows **desktop-commander, pdf-viewer and cowork-plugin-management**, all enabled. session_connectors_status: Composio connected (11 tools), visualize connected (2), Claude Docs disabled for this session, plus the two plugin servers. r9 names 2 plugins and not cowork-plugin-management. Work in #R1. |
| 6 | The local ghl-oauth-crm server is gone from the Claude app | **HOLDS** | claude_desktop_config.json `mcpServers` = [] (saved by the app 10-03 02:25, after the restart). session_connectors_status lists no ghl-oauth-crm. |
| 7 | The stale ghl-oauth-crm row is gone from Claude → Settings → Connectors | **NOT_PROVEN** | The config source is empty (row 6) and the app restarted after the 20:46 crash, so the row should have cleared, but nobody has looked. Settled by: one look at Claude → Settings → Connectors → "Yours" (Alex's glance, or a read-only computer-use screenshot once he says the Claude window is free). |

## 2. ChatGPT's Composio permission reads "Allow all tools" (verify-codex-chatgpt-cursor.md CHANGED row 1)
| # | Claim | Disposition | Pointer |
|---|---|---|---|
| 8 | The permission is "Always ask" (spp-c17, Alex's yes, kept) | **OWNER step** | Exact click: ChatGPT → Settings → Plugins → Composio → Permission → **Always ask** (the same path Alex used 10-01; spp-c17 note L50 and L66). Leave the account-wide Default as it is ("Allow read-only tools"). About 30 seconds. |
| 9 | The cause of the change | **NOT_PROVEN** | What the records show:<br>(1) spp-c17 set "Always ask" and read it back after a reload on 10-01 (spp-c17 note L66; run-log L161 "setting kept");<br>(2) Codex's config has the same Composio app set to auto-approve: `[apps.asdk_app_6a58503580c08191b78cc5bdaf4eba6e] default_tools_approval_mode = "approve"` (~/.codex/config.toml L181–L182, read 10-03; file written 10-03 01:57). That line was already there on 10-01 (cursor-audits-review.md A14; master-sop verifier CP B15), before spp-c17's readback, so it didn't flip ChatGPT at once;<br>(3) no record of any manual or agent change.<br>The audit's candidate, "the Codex app pushes it on restart", stays inference. Settled by READY #R4. |

## 3. Claude app items from verify-claude.md
| # | Claim | Disposition | Pointer |
|---|---|---|---|
| 10 | The 6 unused uploads are switched off (not loading) | **HOLDS** | None of event-fair-campaign, sales-call-review, sales-data-review, sales-script-optimizer, sales-team-management or skill-hygiene is among the account's 24 synced skills (skills-plugin b9a4d135…/9128974b…/skills) or this session's 23 listed skills. All 6 are backed up as .skill files in ~/Backups/claude-skills-2026-10-01/claude-ai-uploads-d4/ (names read 10-03). |
| 11 | SK40-D4: off vs removed | **OWNER step** (decision) | Either "off is enough", which closes SK40-D4, or a permanent delete: Claude app → Customize → Skills → each of the 6 → Delete. The path is per verify-claude.md L17817 and wasn't re-checked in the UI. |
| 12 | The desktop built-ins schedule, setup-claude, explain-usage and docs are still on | **HOLDS** | This session's skill list (2026-10-03) shows anthropic-skills:schedule, :setup-claude, :explain-usage and :docs, and the account's synced folder has them too. setup-cowork is in the folder but not in the session list, which matches verify-claude.md L17944. |
| 13 | Switch off the duplicate "schedule" (optional) | **OWNER step** (optional) | Claude app → Customize → Skills → schedule → off (per verify-claude.md L17944). Alex's choice; nothing depends on it. |
| 14 | hermes-boss-director and native-fix-research in the Claude app are stale | **HOLDS** | App copies dated 09-29 10:07 and 09-29 06:43. Their SKILL.md sha256s are `7c2858d64521…` and `99f5c16ec602…`; the current zips (work/2026-10-01_setup-playbook/zips/) are `32aecdf4f6b1…` and `396e9ebe55ca…`, so they differ. No re-upload now (the Director: they wait on the Hermes refresh). Work in #R5, then OWNER #O4. |

## 4. Other lines in those reports that name the lane
| # | Claim (report line) | Disposition | Pointer |
|---|---|---|---|
| 15 | 1Password for the Claude app, workbook status (verify-claude L29669) | **HOLDS** | AI apps r9 names 1Password for Claude. spp-c21's keep verdict rests on 1Password's and Anthropic's docs (notes/spp-c21-claude-app-connectors.md §2). |
| 16 | AI apps r10 shows the Claude Desktop config retired (spp-c21 block) | **HOLDS** | The workbook export of 10-03 (L2183) carries the applied text: "RETIRED 2026-10-02 … mcpServers empty". |
| 17 | "ChatGPT gets the same card list as the Claude app" (verify-codex CAN'T CHECK) | **HOLDS** | `GET /api/v3.1/tools/CUSTOM_IR_NOTES_GET_APP_RULES` (2026-10-03, read-only): a 200 whose description is 1,891 characters and names all 16 cards (browser-and-computer, cloudflare, composio, exa, firecrawl, ga4, ghl, github, google-ads, google-workspace, huggingface, meta-ads, modal, quickbooks, slack, web-search). Both apps' instructions point at this one hosted tool. The same read settles report b §11's "hosted app-rules description (Limits R20: 1,891 characters)". |
| 18 | ChatGPT cloud skills made by Alex (3) (verify-codex) | **HOLDS** | Audit Skills-page read 10-03: Fulfill Hot Tub Launch, Hot Tub Scene Variator, Local Meta Ad Creative System. |
| 19 | ChatGPT browser tests passed: spp-c16 T1, T2, T4 (verify-codex) | **HOLDS** | conductor-ui-lane.md L50; transcripts/chatgpt-web/2026-10-01_chatgpt-web-parity-test.md. |
| 20 | The ChatGPT "Always ask" test was done (verify-codex) | **HOLDS** | notes/spp-c17-chatgpt-write-approval.md "Result after Alex's yes" (FAIL on the 2-card rule); run-log L161. |
| 21 | ChatGPT phone tests passed (verify-codex) | **HOLDS** | Phone tests logged 10-01 19:05 (audit row, past event). |
| 22 | ChatGPT flags "Fulfill Hot Tub Launch" as blocked (verify-codex CAN'T CHECK) | **NOT_PROVEN** | The flag came from my 10-01 export, and the skill page shows no marker. Settled by: ChatGPT → Skills → Fulfill Hot Tub Launch → "Try in chat" with a harmless prompt, once Alex says his ChatGPT window is free. A chat run is not a pure read, so this waits for that go. |
| 23 | "Agent opened ChatGPT Settings; nothing changed" (verify-codex L14934) | **NOT_PROVEN** | A past UI session with no before/after record. No access can prove it now; today's state is covered by rows 1, 3 and 8. |
| 24 | Claude Docs stays on (AI apps r9) | **NOT_PROVEN** | session_connectors_status shows Claude Docs **disabled** for this session. That may be a per-session toggle, not the account state. Settled by: one look at claude.ai → Settings → Connectors. |
| 25 | To do r4 still says the Claude app's Shopify connector is broken (verify-claude L12442) | **READY agent work** | Not in report b §6, so it's #R3. To do R20, Plan R15 and Composio R82 are already in §6 (report b L356–L360). |
| 26 | 9 old Desktop config .bak copies, 2 of which list google-workspace-admin (verify-claude L25232) | **READY agent work** | #R2. |

**Already in report b's §6 builder queue (pointer only, not counted):** AI apps r11 count cell (report b L296); To do R42 C, Claude Desktop duplicates (L292); To do R20 C and Plan R15 C, Shopify (L356–L357); Composio R82 J (L358–L360).

## 5. READY agent work (listed, not started)
| # | What | Where | Acceptance |
|---|---|---|---|
| R1 | Change r9's count from 7 to 8 by naming **cowork-plugin-management** (Anthropic's Cowork plugin manager: no app connector, no keys), if the Director keeps it. If not, it becomes an owner step to disable it. Also regenerate the Claude app connectors tab from today's ListPlugins and session_connectors_status (W13's original fix). | Workbook AI apps r9 and the Claude app connectors tab (builder) | r9 names every enabled plugin and connector in the 2026-10-03 readbacks, and a fresh ListPlugins matches it. |
| R2 | Move the 9 `claude_desktop_config*.bak` files from ~/Library/Application Support/Claude to ~/Backups/claude-desktop-config-baks-2026-10-03/ (standing yes on dead local copies). Don't read their values. | MacBook (builder) | 0 .bak files left in that folder, 9 in the backup folder (names-only listing). |
| R3 | To do r4, cell 3: "The Claude app's Shopify connector is broken (auth error), so Composio will be the only route" becomes "The Claude app's Shopify connector went with the Small Business plugin on 2026-10-01 (Claude app connectors R57, R84), so Composio will be the only route". | Workbook To do r4 (builder) | Export shows the new sentence and no other To do row plans that removal. |
| R4 | After Alex's click (#O1), run the cause test:<br>(1) read ChatGPT → Settings → Plugins → Composio → Permission (one new Chrome tab, read-only), and in the same visit confirm which account the plugin shows (closes L07's re-read);<br>(2) restart the Codex app;<br>(3) read the same setting again. | Claude in Chrome, once Alex says Chrome is free; the Codex restart only with Alex's go if it would close his active chat | Record both reads.<br>- A flip back to "Allow all tools" after the restart points at the Codex `approve` line, but one before/after can't prove it caused the flip.<br>- If nothing changes, that doesn't rule the line out for good.<br>- Any app restart that would close Alex's active chat stays gated.<br>Either result goes to the Director as evidence, not proof. |
| R5 | Rebuild the hermes-boss-director and native-fix-research zips after javar-desktop-route (the Hermes refresh). | work/2026-10-01_setup-playbook/zips/ (builder) | New zips' SKILL.md sha256 differ from the app copies above; then OWNER #O4. |
| R6 | Restore the G01 member-test script. The crash wiped this chat's /private/tmp scratchpad, including c20_member_test.py and its helper. Rewrite it from notes/spp-c20-member-test.md §3 as one self-contained file in work/2026-10-01_setup-playbook/scripts/ (no secrets) so a reboot can't lose it again. | This Conductor, under spp-c20's authorization, after this report | Dry run prints the baselines (46 / 0 / 0 or current), and `prep` and the sign-in link are generated last. |
| R7 | (From row 4) A fresh current-state look at the claude.ai instructions (Settings > Account) through Claude in Chrome. This is the only open part of V05, since the 2026-10-01 readback HOLDS. | Claude in Chrome, once Alex says Chrome is free | The field's sha256 still equals V05 block 1 (`1fa79bcd…`), or the differences are listed. |

## 6. OWNER steps (Alex's exact clicks)
| # | Click path | Why |
|---|---|---|
| O1 | ChatGPT → Settings → Plugins → Composio → Permission → **Always ask** | Restores spp-c17's setting. It's his security switch, and nobody else changes it. |
| O2 | Either say "off is enough" for the 6 old uploads, or Claude app → Customize → Skills → each of the 6 → Delete (permanent; backups exist in ~/Backups/claude-skills-2026-10-01/claude-ai-uploads-d4/) | Closes SK40-D4. |
| O3 | (optional) Claude app → Customize → Skills → schedule → off | It's a duplicate of the schedule skill. |
| O4 | (after R5) Claude app → Settings → Capabilities → Skills → upload the 2 rebuilt zips (path per verify-claude.md L29945) | Replaces the stale 09-29 copies. |
