# Verify: director-repo-files group

Checked 2026-10-03 and finished at 00:53 EDT, read-only. Input: `group-director-repo-files.csv`, 185 rows from chat 294b676b.
The 185 rows collapse to 151 things. Full table: `verify-director-repo-files.csv`.

| Verdict | Things |
|---|---|
| HOLDS | 134 |
| CHANGED | 7 (1 drifted after the claim, 6 intended later changes) |
| NEVER TRUE | 4 |
| PROMISED-OPEN | 6 |
| CAN'T CHECK | 0 (parts I couldn't re-run are named in the CSV cause column) |

Times are EDT unless marked Z (UTC). The crash was 20:46. The ledger was last saved 20:14.

## NEVER TRUE

1. **"Each client project's main file now has a `Spend approval:` line"** (line 8458, Oct 1).
   - Now: only the master repo's AGENTS.md and the repo-conform skeleton template have the line.
   - These projects don't have it, and their git history never did: lone-star-spas, higgsfield-hot-tub-store, htl-client-dashboard, dynamite-lighting, Company-Ops/htl, sales-b2b-agent and prime-drive-analyzer.
   - What protects Alex today: the global rule still says "if unset, ask and remind Alex".
   - Fix: add the skeleton's `**Spend approval:** [not set]` line to each client project's AGENTS.md (repo-conform per project), then Alex fills in the amounts.
   - Owner: builder (agent) adds the lines. Alex sets the values.

2. **"Your rule for Manny and Anthony is now written into their setup"** (line 26081).
   - The rule: their AIs never get Alex's powerful logins.
   - Now it exists only in draft notes (`work/2026-10-01_setup-playbook/notes/spp-c20-member-test.md` §7) and in mission-graph text.
   - The workbook's partner route still says a partner "gets the same setup as Alex ... your own login in each one". There are no reduced-power rows.
   - Fix: apply §7 to the workbook's partner rows (Rebuild r6/r12/r433, Templates r487, Decisions) now. Only the variant (a)/(b) detail needs to wait for Manny's member test.
   - Owner: Conductor/builder. No Alex step is needed, because it's his rule.

3. **"All of this is now accurate in the mission files"** (line 29185, the 8-item summary of where things stood before the crash).
   - Never true for 3 of the 8 items:
     - Network: the Tailscale lockdown and the Kanwal share
     - Google: franky and the Google Ads approvals
     - The Dynamite Meta token
   - Those 3 are in no mission graph, only in STATUS.md items 0g, 4, 7 and 8.
   - The ledger hasn't been saved since 20:14. Its Setup playbook block still says NEXT_PLAY_ID spp-p20a, an Oct 1 play.
   - Cause: the summary came from STATUS and the run-log. Those 3 items never had mission nodes, and the crash froze the ledger.
   - Fix: either add nodes (or one pointer node to STATUS items 0g/4/7/8) to the parity graph, or stop calling STATUS items "mission files". Then reconcile the ledger's Setup playbook and Hermes blocks through `ledger_check.py` (backup, edit, verify).
   - Owner: Director.

4. **Alex rule: "keep the decisions log in the cloud"** (line 29242).
   - Nothing was built, and the rule isn't written anywhere: STATUS, lessons and the Director skill have nothing.
   - The research note `work/2026-10-02_system-audit/notes/decision-log.md` (23:25) is untracked, so even it isn't in the cloud.
   - Fix: commit the research note. Then the Director gives Alex the one sourced recommendation it promised, and on his yes builds the log in a private repo.
   - Owner: Director. The build decision is Alex's.

## CHANGED

1. **Mission graphs "fixed and on GitHub, zero stale lines"** (line 29022, 22:47). This one drifted after the claim; it wasn't intended.
   - Lint still shows 0 warnings.
   - GitHub (alex-director b98dd0a) is behind the live files. Three accept.py updates are only on the Mac:
     - 02:55Z: update-fanout-guard set to BLOCKED
     - 03:04Z and 03:43Z: parity-fix-agent, now VERIFIED
     - also parity-recheck set to ACTIVE, and the javar-desktop-route row
   - Cause: the 23:36 commit gate left ~/Alex-Director uncommitted ("ledger_check verify FAIL: no write lock", run-log b8fec8f).
   - Fix: reconcile the Dynamite lane's ledger edits, then commit and push ~/Alex-Director. That covers the ledger, 3 graphs and 10 untracked authorization files, 14 entries in all. It is the same step as the open ledger push below.
   - Owner: Director (builder under the conductor).

2. **Director intake-gate path "points to ~/.codex/skills, which doesn't exist"** (line 14557).
   - Now: fixed. intake.md points to `~/.agents/skills/mission-intake-and-approval-gate`.
   - Cause: intended fix, agents-home e8f2539, Oct 1 14:21.
   - Fix: none.

3. **"Slim Director/Conductor at 88 lines instead of 188"** (line 17674).
   - Now 101 and 89 lines (7,504 and 6,615 chars), still under the 12,000-char cap.
   - Cause: intended versions 2.5, 2.6 and 2.7.
   - Fix: none. The workbook's version cells were already updated to 2.7 (7eca3bf).

4. **"9 Claude-only skill folders now in ~/.agents/skills"** (line 16737).
   - Now 8 of 9.
   - Cause: html-video-production was retired 13 minutes later (6a9fa95), on purpose.
   - Fix: none.

5. **`work/2026-10-01_ai-survival/prompt.md` saved** (line 9116).
   - Moved 2 minutes later to `_archive/2026-10-01_ai-survival-prompt/prompt.md`, same content (6860840, intended).
   - Fix: none.

6. **AGENTS.md Meta routing row "points to the Meta card"** (line 8812).
   - The per-row card pointer was dropped in 5cbe9ab (Oct 1 14:01).
   - The section line "Read the tool's card (`~/.agents/tools/cards/<name>.md`)" now covers it. This was intended.
   - Fix: none.

7. **STATUS.md "swap the 4 allow rules" item at the top** (line 4154).
   - Removed in f498e9a (Oct 1 10:31) when the dead GHL rules were cut. This was intended.
   - Fix: none.

## Still open (PROMISED-OPEN)

- **Director ledger push to GitHub** (line 29536). Last commit was f32d03a, 16:29 Oct 2. The working copy is +187 lines and was last saved at 20:14.
- **Lesson "the cause on record is the crash"** (line 29866). It waits for Alex's OK, which hasn't come.
- **Big-brother style made owner-agnostic for partners** (line 23882). claude-style.md still opens "You are Alex's big brother", and so does the student edition.
- **Rewrite of hermes-team-setup and javar-add-tool** (line 24385). The node hermes-skills-verdict is BLOCKED until the Hermes fixes are proven, then it needs Alex's yes.
- **Missions A and B (Orgo one route, shared brain off the Mac)** (line 13122). Both are PLANNED and held by Alex (his call).

## Holds, but with a gap or a step that depends on Alex

- **hermes-boss-director and native-fix-research.** The Mac copies are fixed. The Claude app still has the 2026-09-29 versions, which send vendor docs to Ref (synced manifest). This depends on Alex: he has to re-upload the zips.
- **Codex Director.** The playbook 2.5 and 2.6 rules and event-only pings are written. The Codex Director never proved it reloaded them. At 03:55Z it answered "none" for its Voice section.
- **Old Director copies.** They're still in `~/Alex-Director-wake/skills` and in `~/.codex/worktrees/20ef` and `ee39`. The Sept 4 copies still send the intake gate to `~/.codex/skills`. The standing yes covers backing them up to ~/Backups and removing them. Owner: agent.
- **1Password timeouts.** L-010 is only a candidate lesson. `op_items.py` and `orgo_op.py` call op with no timeout, and L-010's target card (1Password) doesn't exist. Owner: builder, via a tune-up proposal.
- **Guard gap L-012.** Cloudflare code-mode deletes are still ungated. composio_guard.py hasn't changed since a8959c7.
- **STATUS.md item 6 is stale.** It still offers GTM options, though the ga4 card settles the question: build only in "Increase Roas (Official)".
- **Repo AGENTS.md line 63** still calls `connectors-sync` read-only. The scripts' own notes say the Keychain token is the read-write robot.
- **graph_lint is wired into ledger saves**, but there has been no ledger save since 20:14, so it has never run on one.

## How it was checked (all read-only)

- **Git history.** I used git log and show in ~/.agents, ~/Alex-Director and master-connector-repo. `git ls-remote` showed every origin head equal to local (a28cacd, b98dd0a, b8fec8f).
- **Student edition.** The GitHub head is 080a290, the same as the local clone, built 03:13Z from agents-home a28cacd, alex-director b98dd0a and master b088839.
  - Its guard is byte-identical to the live one.
  - A scan found 0 of 40 client names and 0 real key shapes. The 39 "EAA" hits are base64 font data.
- **Tests and lint.** I re-ran graph_lint.py, test_graph_tools.py, test_ledger_check.py, test_fresh_vault.py and check.py. All passed. The tests ran on temp copies only, and the ~/.agents tree stayed clean.
- **Hosted cards.** Composio `CUSTOM_IR_NOTES_GET_APP_RULES` for 9 cards: the hosted text is identical to the local cards.
- **Repo privacy.** Unauthenticated GitHub API calls return 404 for the 4 private repos and nicks-stack-smooveagent.
- **Tune-up schedule.** Read with `list_scheduled_tasks`: every 8 hours.
- **Not re-run:** the vault comparison for the 23 key-lookalikes (needs 1Password), Codex start-up errors, the trigger and Codex tests, and the live SpyFu call (it spends credit).
