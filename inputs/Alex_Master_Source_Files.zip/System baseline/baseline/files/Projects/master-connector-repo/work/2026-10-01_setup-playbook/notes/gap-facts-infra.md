# Gap facts, infrastructure (play spp-p20b): G04, G08, G09, G10, G11

Mission `mission-setup-playbook-parity`, node `playbook-tabs` (closing the rebuild gaps). Claude Code subagent of session 294b676b (workspace `~/Projects/master-connector-repo`), conductor v2.3 loaded first. Date 2026-10-01, about 20:55–21:45Z.

- **Input:** `notes/replication-retest-prelim.md`, gap rows G04, G08, G09, G10 and G11.
- **Output:** `tabs/gap-facts/G04.json`, `G08.json`, `G09.json`, `G10.json` and `G11.json` in spp-p20a's shape (`title`, `header`, `rows`, last column `source`), plus this summary. The files were written by one generator script in this session's scratchpad (`infra/make_gap_files.py`).
- **Read-only everywhere.** Nothing was created, changed or deleted in any account or on any computer. The Tailscale policy was read in Alex's signed-in admin console through Claude in Chrome (the logged-in route in CLAUDE.md), in a tab this play opened and then closed, with no click on the page.

## 1. What each file closes

| Gap | Type | File | Target tab | Rows | Status |
|---|---|---|---|---|---|
| G04 | missing content | `tabs/gap-facts/G04.json` | Rebuild from zero, new 2.0 and 2.1 | 11 + 4 + 4 | Done. Every version read on this Mac; every install page read. |
| G08 | missing content | `tabs/gap-facts/G08.json` | Rebuild from zero 5.1, 7.4, 7.5; Composio + 1Password right way | 6 + 6 + 7 + 7 | Done. The Cloudflare token is proven to be an account-owned token; the Meta token's 22 permissions are read; the Google no-disk route is documented but not run (it would create a key). |
| G09 | missing content | `tabs/gap-facts/G09.json` | Tailscale; Rebuild from zero 6.1–6.5 | 6 + 1 + 9 | Done. **The policy text was read** and checked against the netmaps of this Mac and the hub. |
| G10 | missing content | `tabs/gap-facts/G10.json` | Rebuild from zero 1.3, new 8.0a (next to G22's 8.0), 8.2 | 10 + 4 | Done. Size, image, template and auto-stop read from Orgo. |
| G11 | missing content | `tabs/gap-facts/G11.json` | Rebuild from zero, new 8.0b–8.0e (next to G22's 8.0), 7.5, 10.3 | 4 + 4 + 5 + 4 | Done. 4 tunnels and 5 tunnel hostnames read; creation steps sourced. |

## 2. Research log

Every URL below was read on 2026-10-01 (read 2026-10-01). The builder accepts a URL only when it appears in a research note, so these lines are that record. Exa calls went through Composio (`EXA_GET_CONTENTS_ACTION`, `EXA_SEARCH`); the vendor-docs readers were Composio's Cloudflare docs tool (`CUSTOM_CLOUDFLARE_API_DOCS`) and OpenAI Docs (`CUSTOM_OPENAI_DOCS_FETCH_OPENAI_DOC`).

| URL | read | route and log | used for |
|---|---|---|---|
| https://brew.sh/ | read 2026-10-01 | Exa contents log_oOtJ2u55vyU5 | Install command; Homebrew supports macOS Sequoia 15 and newer |
| https://nodejs.org/en/download | read 2026-10-01 | Exa contents log_eOp3LJLxI66b (live crawl; the cached copy was wrong) | LTS v24.21.0, Current v26.10.0 |
| https://www.python.org/downloads/macos/ | read 2026-10-01 | Exa contents log_oOtJ2u55vyU5 | Latest Python 3.14.8 (2026-09-30), macOS installer |
| https://git-scm.com/install/mac | read 2026-10-01 | Exa contents log_eOp3LJLxI66b | git through `xcode-select --install` or `brew install git` |
| https://1password.com/downloads/mac | read 2026-10-01 | Exa contents log_oOtJ2u55vyU5 | 1Password for Mac download; needs macOS 12 or newer |
| https://developer.1password.com/docs/cli/get-started/ | read 2026-10-01 | Exa contents log_oOtJ2u55vyU5 | `brew install 1password-cli`; Settings > Developer > Integrate with 1Password CLI; Touch ID |
| https://claude.com/download | read 2026-10-01 | Exa contents log_1ztv0ihS8zdH | Claude desktop download |
| https://chatgpt.com/download | read 2026-10-01 | Exa contents log_1ztv0ihS8zdH | ChatGPT desktop app includes ChatGPT Work and Codex; Codex app users update to ChatGPT |
| https://code.claude.com/docs/en/setup | read 2026-10-01 | Exa contents log_1ztv0ihS8zdH | Native install `curl -fsSL https://claude.ai/install.sh \| bash`; launcher in ~/.local/bin; Homebrew cask |
| https://developers.openai.com/codex/cli | read 2026-10-01 | OpenAI Docs reader `CUSTOM_OPENAI_DOCS_FETCH_OPENAI_DOC` log_AzvF_q2ss7QQ | Standalone installer, npm and Homebrew installs; Sign in with ChatGPT |
| https://docs.composio.dev/docs/cli | read 2026-10-01 | Exa search log_akdZE7ndyeK3 | `curl -fsSL https://composio.dev/install \| sh`, `COMPOSIO_INSTALL_PLUGINS` (default 0 on this page), `COMPOSIO_INSTALL_SHELL`, ~/.local/bin entry point |
| https://tailscale.com/download/mac | read 2026-10-01 | Exa contents log_eOp3LJLxI66b | Tailscale's Mac download page (thin page; details from kb/1065) |
| https://tailscale.com/kb/1065/macos-variants | read 2026-10-01 | Exa contents log_eOp3LJLxI66b | Standalone variant recommended; never both variants; Standalone can't be a Tailscale SSH server |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/downloads/ | read 2026-10-01 | Exa contents log_1ztv0ihS8zdH | `brew install cloudflared` on macOS |
| https://developers.cloudflare.com/fundamentals/api/get-started/account-owned-tokens/ | read 2026-10-01 | Exa contents log_z8XJc4g-WSjj | Who may create account tokens; dashboard path; `cfat_` prefix; compatibility matrix |
| https://developers.cloudflare.com/fundamentals/api/get-started/create-token/ | read 2026-10-01 | Exa contents log_z8XJc4g-WSjj | Custom token steps; Edit = full CRUDL; IP filter and TTL fields; secret shown once |
| https://developers.cloudflare.com/r2/api/tokens/ | read 2026-10-01 | Exa contents log_z8XJc4g-WSjj | S3 keys from a token: Access Key ID = token id, Secret = SHA-256 of the token value |
| https://developers.cloudflare.com/agents/model-context-protocol/cloudflare/servers-for-cloudflare/ | read 2026-10-01 | Cloudflare docs tool log_E-7f9SVcWfLQ | The API MCP server takes a Bearer API token; user and account tokens both supported |
| https://cloud.google.com/iam/docs/keys-create-delete | read 2026-10-01 | Exa contents log_7S9g5vWzN0_a | Service Account Key Admin role; enable the IAM API; console download; REST returns base64 privateKeyData |
| https://cloud.google.com/sdk/gcloud/reference/iam/service-accounts/keys/create | read 2026-10-01 | Exa contents log_7S9g5vWzN0_a | OUTPUT-FILE is a path checked for write permission (stdout isn't documented) |
| https://cloud.google.com/resource-manager/docs/secure-by-default-organizations | read 2026-10-01 | Exa contents log_7S9g5vWzN0_a | Organizations from 2024-05-03 enforce `iam.managed.disableServiceAccountKeyCreation` |
| https://developer.1password.com/docs/cli/reference/management-commands/document/ | read 2026-10-01 | Exa contents log_7S9g5vWzN0_a | `op document create -` and `op document edit <item> -` read the file from standard input |
| https://developers.facebook.com/docs/business-management-apis/system-users/ | read 2026-10-01 | Exa contents log_1ZWNfH9tGiD9 | System users represent servers making API calls; Business Manager is the easiest way to create one |
| https://developers.facebook.com/docs/business-management-apis/system-users/install-apps-and-generate-tokens/ | read 2026-10-01 | Exa contents log_1ZWNfH9tGiD9 | Never-expiring vs 60-day tokens; some businesses must use expiring tokens; app needs Ads Management API standard access; supported scopes |
| https://en-gb.facebook.com/business/help/503306463479099 | read 2026-10-01 | Exa search log_GljszEjHD0bv | Business Suite steps: Settings > Users > System users > Add > assign assets > Generate new token |
| https://tailscale.com/kb/1068/tags | read 2026-10-01 | Exa contents log_j753J2_OIIIE | A tag must be defined in tagOwners before it is applied; who may define tags |
| https://tailscale.com/kb/1085/auth-keys | read 2026-10-01 | Exa contents log_j753J2_OIIIE | Key expiry 1–90 days (90 max); Reusable, Tags, Pre-approved; tagged devices have key expiry off |
| https://tailscale.com/kb/1103/exit-nodes | read 2026-10-01 | Exa contents log_j753J2_OIIIE | macOS: Exit node > Run exit node; Admin approves in Machines > Edit route settings; macOS exit node must not sleep |
| https://tailscale.com/kb/1193/tailscale-ssh | read 2026-10-01 | Exa contents log_j753J2_OIIIE | SSH rule syntax; default check rule; tagged sources can't use check; shields-up blocks incoming Tailscale SSH; broadest policy example |
| https://tailscale.com/kb/1324/grants | read 2026-10-01 | Exa contents log_j753J2_OIIIE | Grants syntax; `ip` capabilities |
| https://tailscale.com/kb/1337/policy-syntax | read 2026-10-01 | Exa contents log_j753J2_OIIIE | autogroup:admin and autogroup:member; nodeAttrs; autoApprovers for exit nodes |
| https://docs.orgo.ai/api-reference/computers/create | read 2026-10-01 | Exa search log_MY5phgmUUvLU | Name unique per workspace; only linux; RAM, CPU and disk (default 8 GB) capped by plan |
| https://docs.orgo.ai/guides/cli | read 2026-10-01 | Exa search log_MY5phgmUUvLU | `orgo computers create` flags; install script brings Node if missing; disk grows only |
| https://docs.orgo.ai/guides/auto-stop | read 2026-10-01 | Exa search log_MY5phgmUUvLU | Auto-stop is off by default on all plans; 0 keeps a computer on |
| https://docs.orgo.ai/api-reference/computers/auto-stop | read 2026-10-01 | Exa search log_MY5phgmUUvLU | GET and PATCH /computers/{id}/auto-stop |
| https://docs.orgo.ai/quickstart | read 2026-10-01 | Exa search log_MY5phgmUUvLU | Workspaces group computers; API key from orgo.ai/workspaces |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/get-started/create-remote-tunnel/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | Dashboard: Networking > Tunnels > Create a tunnel; Routes > Add route > Published application |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/get-started/create-remote-tunnel-api/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | API token needs Account Cloudflare Tunnel Edit and Zone DNS Edit; create, configure, CNAME; a healthy tunnel has four connections |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/do-more-with-tunnels/local-management/create-local-tunnel/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | `cloudflared tunnel login`, `create`, `route dns`, config.yml, `run` |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/do-more-with-tunnels/local-management/tunnel-permissions/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | cert.pem is account-wide and needed to manage tunnels; the credentials file is needed to run one |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/remote-tunnel-permissions/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | A remotely-managed tunnel needs only its token to run; the token endpoint needs a Write-level permission |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/cloudflared-parameters/run-parameters/ | read 2026-10-01 | Exa contents log_jtw4xb6DiipI | `--token-file` is for remotely-managed tunnels and needs cloudflared 2025.4.0 or later |
| https://developers.cloudflare.com/api/resources/zero_trust/subresources/tunnels/subresources/cloudflared/methods/create/ | read 2026-10-01 | Exa contents log_GMHP8Xv-F8G- | `config_src` is "local" (YAML on the origin) or "cloudflare" |
| https://developers.cloudflare.com/tunnel/features/locally-managed-tunnels/ | read 2026-10-01 | Cloudflare docs tool log_5gcovdHthquM | Cloudflare recommends remotely-managed tunnels for most uses |

Not used as a source, because a reader can't open it without Alex's login: the admin console page `console.tailscale.com/admin/acls/file` (§3).

**Live reads** (UTC on 2026-10-01; scripts in this session's scratchpad `infra/`; times approximate):

| Time | What | Route | Result |
|---|---|---|---|
| ~20:50Z | Versions on this Mac | `--version` commands and each app's Info.plist | §7 |
| ~20:58Z | Orgo computers | `orgo_op.py orgo computers list --json` through an allowlist sanitizer, outside the Claude Code sandbox (op fails TLS inside it) | 7 computers; the hub's row in §6 |
| ~20:59Z | Orgo settings | same command, non-secret fields only | `always_on` true on all 7 |
| ~21:00Z | Cloudflare tunnels, their configurations, tunnel DNS records, token verify | Composio `CUSTOM_CLOUDFLARE_API_EXECUTE`, GET calls only, log_8jGliRvTviC5 | §4 |
| ~21:01Z | This Mac's Tailscale netmap | `tailscale debug netmap`, outside the sandbox (the CLI can't load its preferences inside it), summarized without logins or keys | §3 |
| ~21:03Z | The hub's Tailscale netmap | `orgo_op.py orgo computers bash <hub> -c 'tailscale --socket=/var/run/tailscale/tailscaled.sock debug netmap'` | §3 |
| ~21:04Z | The tailnet policy file | Claude in Chrome: `console.tailscale.com/admin/acls/file` (JSON editor), page text plus one screenshot; tab closed after | §3 |
| ~21:06Z | Meta token permissions | `composio proxy https://graph.facebook.com/v23.0/me/permissions --toolkit metaads --account ca_7i7CdMbStKc9` (GET), names and status only | §5 |
| ~21:10Z | The hub's auto-stop setting | GET `https://www.orgo.ai/api/computers/<hub>/auto-stop` through `orgo_op.py` | 0, configurable |
| ~21:16Z | Three 1Password note fields | `op item get` with the Keychain robot, outside the sandbox; only the STRING fields `permissions` and `used by` (Cloudflare item) and `type` and `reaches` (Meta item) were printed, emails masked | §4, §5 |

## 3. G09: the tailnet policy, read and checked

**Method.**
1. The netmaps of this Mac and the hub (`tailscale debug netmap`) went through a script that maps addresses to device names and tags and masks every login except alex@. No key, endpoint or login was kept.
2. The policy file was read in the admin console's JSON editor through the page text (lines 1–17, line 17 empty). One screenshot confirmed the layout. A copy is in the scratchpad (`infra/tailscale_policy_2026-10-01.json`; it parses as JSON) and in G09.json §2.

**The file as saved (16 lines):**

```
{
    "grants": [{"src": ["*"], "dst": ["*"], "ip": ["*"]}],
    "ssh": [{
        "action": "accept",
        "src":    ["autogroup:admin", "tag:server"],
        "dst":    ["tag:server"],
        "users":  ["root", "autogroup:nonroot"]
    }, {
        "action": "check",
        "src":    ["autogroup:member"],
        "dst":    ["autogroup:self"],
        "users":  ["autogroup:nonroot", "root"]
    }],
    "nodeAttrs": [{"target": ["autogroup:member"], "attr": ["funnel"]}],
    "tagOwners": {"tag:server": ["autogroup:admin"]}
}
```

**What the netmaps show (they agree with every line):**
- **Tailnet.** `increaseroas.com`, MagicDNS on with suffix `tailde26a1.ts.net`, Tailnet Lock off.
- **Access.** Both netmaps carry one packet-filter rule: every tailnet address (100.64.0.0/10 less Tailscale's reserved ranges, plus fd7a:115c:a1e0::/48) to every port over TCP, UDP, ICMP and ICMPv6. That is the allow-all grant, and the cause of the open exposure issue (Tailscale tab R15).
- **SSH into the hub.** One accept rule. Allowed sources: the 7 tag:server computers plus alexs-macbook-pro, iphone172 and sashas-mac-mini. Users: root, and any other user under the same name. That is the accept rule, so the Mac mini's owner holds the Admin role.
- **SSH into this Mac.** A check rule (hold and delegate) for its owner's own 2 devices, which is Tailscale's default rule. A time-limited accept left by a recent check sign-in had expired at 19:15Z.
- **Funnel.** This Mac (owner, admin) carries the funnel capability and its ports; the tagged hub doesn't. That is the nodeAttrs line.
- **Devices.** 7 carry tag:server, all with key expiry off. The Mac mini's allowed routes include 0.0.0.0/0 and ::/0, so it is an approved exit node. It also carries a `suggest-exit-node` capability that no policy line sets; the cause wasn't checked.

**Answers to G09.** tagOwners: `tag:server` owned by `autogroup:admin`. SSH: accept from admins and tag:server into tag:server, as root or any user. Exit-node approval: by hand in Machines, because the file has no autoApprovers. Access rules: the allow-all grant; narrowing it is Alex's open decision (To do R2). Tailscale's SSH page says shields-up blocks incoming Tailscale SSH, so the hub (`--ssh --shields-up`) refuses SSH by design.

## 4. G11 and G08 (Cloudflare): tunnels, hostnames and the token

**Method.** One EXECUTE through `custom_cloudflare_api`, GET calls only: the tunnel list (deleted ones excluded), the configuration of each remotely-managed tunnel, every zone's CNAME records that end in `.cfargotunnel.com`, and both token-verify endpoints. The call returned names, IDs, status, connection counts, ingress rules and record names. No token or secret was asked for; the token endpoint wasn't called.

**Tunnels (4, all healthy, 4 connections each):**

| Name | ID | Managed | Hostnames | Created | cloudflared |
|---|---|---|---|---|---|
| mcp-hub | cd93a127-ac04-407c-8686-c3be371f3559 | locally (`config_src` local) | mcp.increaseroas.com (CNAME created 2026-09-30 11:30:25Z) | 2026-09-30 11:30:23Z | 2026.9.3 |
| ghl-command-universal-openclaw | 9b09467d-9c1c-4f4c-9b00-021ad8239f20 | remotely (config version 1) | ghl-command-origin.increaseroas.com to http://127.0.0.1:8789 (CNAME 2026-09-29 10:27:55Z, with a comment) | 2026-09-29 10:27:07Z | 2026.9.3 |
| Javar EA Tunnel | 0900d6d0-02d4-4d82-ab5f-fcfb632bc043 | remotely (config version 4) | two increaseroas.ai hostnames to ports 8644 and 9119 | 2026-08-13 | 2026.7.3 |
| htl-hermes-canary-orgo | ebfa4bab-cd3a-4b51-9508-3b65613164f0 | remotely | one webhook canary path on another zone | 2026-08-25 | 2026.8.2 |

The last two belong to the Hermes/Javar agents, outside this mission (G24). The canary's hostname is left out here on purpose: it sits on a zone named for a business.

**The token.** The account-token verify endpoint answered `active`, with no `expires_on` and no `not_before`. The user-token verify endpoint answered "Invalid API Token". So the item holds an **account-owned** token. The item's own `permissions` note (read ~21:16Z) says: "Account token: Read & Write on every group (all zones + entire account), no expiry, no IP filter (2026-10-01)". Its `used by` note names the Composio custom Cloudflare connector for every AI.

**Does the installer make the tunnel?** No. `rebuild_hub.py` asks Cloudflare for the token of a fixed `TUNNEL_ID` (L64–L80) and writes the credentials file; `install_hub.sh` only checks that the file exists (L97–L100) and runs `cloudflared` with `cf/config.yml`.

**cert.pem.** Cloudflare's page on locally-managed tunnel permissions says `cert.pem` is account-wide and needed to manage tunnels (create, route, delete, list); the credentials file is what runs a tunnel. Its page on remotely-managed tunnels says those need only the token to run.

## 5. G08 (Google and Meta): the robot key and the system-user token

**Google.** No live call: making a key is a write. What the sources give:
- Google's key page: the Service Account Key Admin role, the IAM API turned on first, the console download, and a REST method that returns the key as base64 `privateKeyData`.
- The gcloud reference: OUTPUT-FILE is a path checked for write permission, and writing to standard output isn't documented. That is why the no-disk route uses the REST method.
- The secure-by-default page: organizations created on or after 2024-05-03 enforce `iam.managed.disableServiceAccountKeyCreation`.
- 1Password's `document` command: `create -` and `edit <item> -` read the file from standard input.
- The IAM API in increaseroas-tagging was off on 2026-10-01 (`notes/fix-k01-w20.md` L69).

**Meta.**
- **Permissions.** GET `/me/permissions` through `composio proxy`, names and status only: 22 granted, none declined or expired.
- **Item notes.** `type` says "SYSTEM_USER, never expires (debug_token 2026-09-30)". The `reaches` note names client ad accounts. It was printed to this play's terminal while reading the item and copied nowhere.
- **Meta's pages.** The system users overview. Install apps and generate tokens: never-expiring vs 60-day tokens, some businesses must use expiring tokens, the app needs Ads Management API standard access, and the supported scopes. Business Help 503306463479099: the Business Suite steps.

**Tailscale auth key item dates** (spp-p20a's catalog, metadata only): created 11:25:01Z, filled 11:50:09Z on 2026-10-01.

## 6. G10: the Orgo hub computer

Read through `orgo_op.py` (`computers list --json`, then the auto-stop GET). Only allowlisted fields were printed; URLs, VNC details, addresses and proxy fields were dropped.

| Field | My OpenClaw (the hub) |
|---|---|
| id | 6fbffd8c-65b1-4f2e-993e-f283532109bf |
| workspace | IR 1 |
| os, root image | linux, rootfs v0.1.1 (update available); the hub itself reports Ubuntu 24.04.4 LTS (`hub/VERSIONS.json`) |
| cpu, ram, disk | 1 core, 8 GB, 40 GB |
| resolution, gpu | 1280x720x24, none |
| template terminal | openclaw |
| always_on, auto-stop | true; `auto_stop_minutes` 0, `configurable` true |
| status, created | running, 2026-09-05 01:20Z |
| other fields | provider metal (qemu), ssh_enabled false, egress_mode residential, residential proxy off |

The other 6 computers (EA, B2B Sales Agent, computer-7121, Max, Media, Ops Coordinator) are the Hermes/Javar agents' machines. All 7 are always on.

The local `orgo computers create --help` matches Orgo's CLI guide: `--name`, `--ram` (4 to 64), `--cpu` (0.5 to 16), `--disk`, `--os` (linux by default), `--gpu`, `--region`, `--resolution`, `--snapshot`, `--template`, `--workspace`. It has no auto-stop flag; Orgo's docs say auto-stop is off by default.

## 7. G04: versions on this Mac

Read ~20:50Z with each tool's `--version` and each app's `Info.plist` (`CFBundleShortVersionString`); paths resolved with `realpath`.

| Tool | Path (real path) | Version | How it got here |
|---|---|---|---|
| macOS | — | 26.6.2 (25G83), arm64 | — |
| Command Line Tools | /Library/Developer/CommandLineTools | 26.6 | Apple |
| git | /usr/bin/git | 2.50.1 (Apple Git-155) | Command Line Tools |
| Homebrew | /opt/homebrew/bin/brew | 7.0.6 | brew.sh installer |
| python3 | /opt/homebrew/bin/python3 (Homebrew's Python 3.14 formula) | 3.14.6 | Homebrew; Apple's /usr/bin/python3 is 3.9.6 |
| openpyxl | ~/Library/Python/3.14 | 3.1.5 | per-user install |
| node, npm (first on PATH) | ~/.local/bin/node (~/.hermes/node/bin/node) | v26.7.0, npm 11.19.0 | bundled with Hermes |
| node (second) | /usr/local/bin/node | v24.14.0 | nodejs.org installer (file dated 2026-02-23) |
| npm global prefix | ~/.local | — | npm config |
| op | /opt/homebrew/bin/op | 2.39.0 | Homebrew cask 1password-cli |
| claude | ~/.local/bin/claude (~/.local/share/claude/versions/2.1.287) | 2.1.287 | native installer |
| codex | ~/.local/bin/codex (~/.local/lib/node_modules/@openai/codex) | codex-cli 0.150.1 | npm |
| composio | ~/.local/bin/composio (~/.composio/composio) | 0.4.2 | composio.dev installer |
| gh | /opt/homebrew/bin/gh | 2.92.0 | Homebrew |
| orgo | ~/.local/bin/orgo (runs ~/.orgo/node) | 2.0.5 | orgo.ai installer |
| tailscale | /usr/local/bin/tailscale (wrapper for the app's CLI) | 1.102.4 | Standalone app (io.tailscale.ipn.macsys) |
| cloudflared | — | not installed | — |
| herdr, mco, pipx | ~/.local/bin, ~/.local/bin, /opt/homebrew/bin | 0.9.1, 0.11.0, 1.15.0 | install script, npm, Homebrew; pipx has no apps (~/.local/pipx/venvs empty) |
| cursor-agent, hermes | ~/.local/bin | — | Cursor and Hermes (outside the mission) |
| 1Password app | /Applications/1Password.app | 8.12.36 | direct download (no App Store receipt) |
| Claude app | /Applications/Claude.app | 2.16120.0 (minimum macOS 13.0 in its Info.plist) | direct download |
| ChatGPT app | /Applications/ChatGPT.app (bundle com.openai.codex) | 26.928.31416 (build 12553; minimum macOS 13.0 in its Info.plist) | direct download |
| Tailscale app | /Applications/Tailscale.app | 1.102.4 | Standalone package |

`pipx list` was tried once. It hit the sandbox while trying to delete its own old log files and was not run again; the empty venvs folder answers the question.

## 8. Checks

All results below were observed at 21:28:50Z on 2026-10-01 with spp-p20a's validator (`validate_gap_facts.py` in this session's scratchpad). It imports `build_tabs.py`'s own `check_source`, `scan_text` and Excel cell limits and extends `RESEARCH` with `notes/gap-facts*.md`, the same way spp-p20a ran it.

- **Builder validation, all 22 gap files then present (92 of the rows are this play's).**
  - **First run:** 2 problems, both in G04 §1 row 3. The Homebrew formula names `python@3.13` and `python@3.14` match the email rule. The cell was reworded.
  - **Second and final run:** 0 problems.
  - **Warnings (43):** all "looks like a 1Password item id". 3 are this play's (G08 names the robot key's document ID twice, G09 the Tailscale key's item ID once). That is expected, as in spp-p20a.
- **Secret scans** over every gap file and every `notes/gap-facts*.md`:
  - the builder's 10 secret-shape rules: 0 hits;
  - every token against the sha256[:16] of every concealed vault value and document (spp-p20a's catalog): 0 hits.
- **Negative check 1: the URL rule.** The same check on this play's five files without the extra `RESEARCH` line gives 70 problems, all "URL not in the research notes" (37 distinct URLs). With the line it gives 0, so the rule really bites.
- **Negative check 2: client names.** The builder's 43 client names, matched over the five files and this note: 0 hits.

**verify-before-done (normal stakes: internal source files; nothing written to any tool):**

| Check | How | Result |
|---|---|---|
| Done means: one file per gap with the rows a newcomer needs and a source on every row | 5 files, 92 rows, last column `source` in all 15 sections; builder validation | Met |
| G04: version on this Mac and official install page for each prerequisite | §7 read with `--version` and Info.plist; 15 install pages read and cited (§2) | Met. Also: op, composio, claude and codex commands; cloudflared not needed on the Mac |
| G08: console steps and permissions for the three keys, never values | Cloudflare token type proven by the two verify calls; 22 Meta permissions read; Google steps from 2 Google pages and 1Password's document page (the gcloud reference was also read, to rule out writing the key to standard output) | Met. The Google no-disk pipe is documented, not run |
| G09: policy text through an allowed read-only route | Claude in Chrome page text and a screenshot; both netmaps agree line by line (§3) | Met: the policy was readable, so NOT_PROVEN shrinks to whitespace, device approval and key expiry |
| G10: command or dashboard path, size, image, name | `orgo computers list --json`, the auto-stop GET, Orgo's CLI, API and auto-stop docs | Met for the CLI. The dashboard path is NOT_PROVEN |
| G11: creation steps, route names, cert.pem cited | the Cloudflare GET read (§4), 8 Cloudflare pages | Met |
| Counts recomputed from the source | 22 permissions (API list); 4 tunnels and 5 tunnel hostnames (API); 7 Orgo computers (list); 7 tag:server devices (netmap: 6 peers plus the hub); policy 16 lines (page text); 92 rows and 43 distinct URLs (validator script) | Match |
| Workbook citations | 16 Rebuild rows re-pointed after the 21:14:13Z save; every cited row in 6 tabs read back against its claim | Match |
| Citations to files | the builder's checks on every path, line range, § heading and quoted text | Pass |
| Records written to a tool | none: read-only play | — |
| Couldn't check | see §9, NOT_PROVEN | Listed |

## 9. NOT_PROVEN, and findings for the Director

**NOT_PROVEN**
1. Three routes that would create something were documented, not run: the no-disk Google key pipe, the API creation of a locally-managed tunnel followed by rebuild_hub.py's token step, and any Orgo create.
2. How Alex's mcp-hub tunnel was made. It is inferred (`config_src` local, a CNAME 2 seconds later, a cert.pem on the hub), not recorded.
3. The indentation of the saved policy file (the content is exact); whether Device approval is on; the saved auth key's chosen expiry; that SSH into the hub is refused (from the docs, not tested); the Mac mini's `suggest-exit-node` capability.
4. Whether Alex's Google organization enforces the key-creation block; the robot's own Cloud IAM roles; the AI Search permission group name.
5. A dashboard click path for Orgo computers (the docs read cover the CLI and API); what Orgo's egress fields mean.
6. Which tunnel, if any, the Meta MCP's tunnel client in `/opt/increase-roas-mcp` uses. None of the 4 tunnels points at it, and its `tunnel-runtime.env` was not opened (rule).

**Findings (not acted on; each belongs to another lane or needs Alex)**
- **The hub's SSH.** It runs `--ssh --shields-up`. Tailscale documents shields-up as blocking incoming Tailscale SSH, so the Tailscale tab's open question (R7) has a documented answer: no SSH into the hub.
- **The saved Tailscale auth key dies by 2026-12-30 at the latest.** A rebuild after that fails at installer step 11 unless someone makes a new key first. Nothing reminds anyone, so this depends on someone remembering.
- **Two Node.js copies.** The one first on PATH (v26.7.0) is Hermes's bundled Node, not a deliberate install; `/usr/local/bin/node` is v24.14.0.
- **The IAM API is off in the robot's Cloud project.** The next key rotation by CLI or REST needs it on; turning it on is a standing yes.
- **Meta's 60-day token policy** may apply to a new business; a 60-day token adds a refresh job, which is Alex's call.
- **Cloudflare recommends remotely-managed tunnels;** the hub uses a locally-managed one. That is a design question for the Director, not a defect.
- **The exposure issue is unchanged.** The allow-all grant stays until Alex decides (To do R2).
- **Composio installer default.** The docs page says plugin setup is off by default; the script read by spp-p18a ran it unless `COMPOSIO_INSTALL_PLUGINS=0`. G04 uses `=0` explicitly. The composio card could carry the same line, which needs the Director's go.
- **The Meta item's `reaches` note names client ad accounts.** That is fine inside the vault, but anyone reading item notes sees it. No change was made.

## 10. How the builder uses these files

1. **RESEARCH.** spp-p20a's one-line `RESEARCH` change (`+ sorted(glob.glob(f"{JOB}/notes/gap-facts*.md"))`, `notes/gap-facts.md` §9) also picks up this file, so every URL in G04, G08, G09, G10 and G11 resolves.
2. **Placing rows.** Each file's `target_tab` says where its rows go. G09's §1–§3 replace the Tailscale tab's NOT_PROVEN policy row and Rebuild 6.1–6.5. G10 §2 and G11 §3 are new pre-build steps 8.0a (the computer) and 8.0b–8.0e (the tunnel), next to the 8.0 that G22 already added. G04 §1 is the new step 2.0.
3. **One long cell.** G09 §2 holds the whole policy file: 16 lines, 15 line breaks, under Excel's 253.
4. **Workbook row numbers.** Every `workbook <Tab> R<n>` in these five files points at the master as saved at 21:14:13Z (sha256 f6a9636bce3ac65d…). That save, the builder applying spp-p20a's batch, moved the Rebuild tab from 188 to 228 rows while this play was running, so the 16 Rebuild citations were re-pointed by matching each step label (old to new: 10→21, 16→27, 21→32, 26→37, 27→38, 29→40, 33→44, 44→55, 46→57, 52→63, 53→64, 54→65, 70→81, 79→91, 82→94, 95→107; 3.5's hook row is R48). Every cited row was then read back against its claim. The other tabs cited (Tailscale, Route power, Tracking access, All connections, To do) didn't move. If the builder inserts rows again before applying these files, its content check re-points them.
