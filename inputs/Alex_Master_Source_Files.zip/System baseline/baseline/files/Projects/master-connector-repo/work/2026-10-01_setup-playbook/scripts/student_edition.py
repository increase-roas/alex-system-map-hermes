#!/usr/bin/env python3
"""Build the student edition: the connectors workbook and a history-free code folder with every client swapped for a
label (Client A, client-a.example, CLIENT_A_LOCATION_ID ...), then prove nothing leaked (play spp-p32a, 2026-10-01).

  python3 student_edition.py build      # build into a temp folder, leak-check it, then replace student-edition/
  python3 student_edition.py check      # leak-check the current student-edition/ again
  python3 student_edition.py selftest   # plant a real name, an ID, a secret shape and a vault value in a copy: must fail

Run build and check outside the Claude Code sandbox: the 1Password CLI needs the system trust store (TLS fails inside
it). selftest reads no 1Password item and runs anywhere.

Mapping: built in memory on every run from knowledge/clients.md (names, aliases, IDs) plus identifiers found next to a
client's name in the workbook and repo files (GHL IDs, long numbers, emails, phones) and client domains. It is never
written anywhere; outputs hold labels only (EDPB Guidelines 01/2025: keep the pseudonym table separate).
Workbook: every XML part of the .xlsx package is rewritten in place (cells, comments, hyperlinks, sheet and defined
names, headers and footers, document properties); openpyxl is only used to prove the result opens, because it drops
parts it can't read. Code: `git archive HEAD` of each source repo (tracked files of one commit, no .git history);
.env, key and certificate files are never copied. Leak check: client names (any case, separators, aliases), mapped
IDs, domains, emails and phones, vendor secret shapes, and every 1Password Connectors secret by SHA-256 window, in
every file, file name and package part. Findings show paths, kinds and labels only.
Beyond clients (spp-c4e, 2026-10-02): personal addresses on public mail domains (gmail, outlook, yahoo, icloud ...)
become person-N@example.com, except in LICENSE-style credit files and for placeholder names like user@; Google file
links (Docs, Sheets, Slides, Forms, Drive files and folders, open?id=) get GOOGLE_FILE_ID, and those IDs are swapped
wherever else they appear; Alex's GHL Marketplace developer/team ID becomes OWNER_GHL_DEVELOPER_ID, and partners' GitHub
usernames (PARTNER_HANDLES, 2026-10-02) become PARTNER_GITHUB_USER. build and check
also run the publish agent's two scans (access_link_scan.py: links that let someone in without a key;
secret_scan.py: key-shaped strings, with vendor tokens that are public by design allowlisted by SHA-256).
Rule files (batch 6, G19): the files the shipped Director docs cite (One-Shot-Builder's RULES.md, docs/LESSONS.md and,
since batch 10, checklists/ONE_SHOT_READINESS.md;
the Director home's STACK.md, CONCEPTS.md and, since batch 7, scripts/controller-write-guard.py) ship from HEAD through
the same scrub and leak check, executable when the source is. A file STAND_IN
names, or whose scrubbed text the leak check still flags or that still holds a phone number the scrubber can't map,
ships as a stand-in (the write guard's refuses every protected write), named in build.json; the starter also gets an
empty mission-graphs/ with a one-line README (batch 7), and a .gitignore, empty STANDING_AUTHORIZATIONS.md and
docs/solutions/README.md and SUPERVISING_DIRECTOR_THREAD_ID: NONE in the blank block (batch 10). The edition README says
GHL Command's builder is out of the student
build (G14). Every op call runs under a hard timeout that kills it (lesson L-010), inside agents-home's
op_items.robot_env (one private HOME and one shared op daemon for every robot call, spp-p49a/p49b), so op doesn't stall
under the real HOME.
Affiliate links (Director dispatch 2026-10-02, Alex: "i want the student copy to auto use all my affiliate links"):
build first reads Alex's affiliate Sheet (the one home, knowledge/affiliate-links.md) through Composio
custom_google_robot sheets_read as alex@, and stops if it can't (no stored copy, so no stale links). Rows whose Status
is live AND that have a link count. In the workbook (cells and their hyperlinks) and in the docs (Markdown and text
files; code files are never opened) that product's own home, pricing and sign-up URLs become the link exactly as
written, each followed by "(paid link)"; API, docs, help, app and login URLs, cited sources ("URL (read <date>)"),
front matter, code blocks, inline code, HTML comments and shell-command lines stay as they are. The disclosure "I earn
a commission if you buy through these links." goes once where links first appear: before the first swapped link's block
in each doc, in the first swapped cell of each sheet. No live link: nothing changes. build.json records the rows used,
by tool. The plain sign-up spots that give a live row somewhere to land (Rebuild from zero section 1, STUDENTS.md) are
listed in notes/student-edition.md §11.
"""
import argparse, bisect, collections, contextlib, datetime, fnmatch, hashlib, html, io, json, os, re, shutil, subprocess, sys, tarfile, tempfile, zipfile
import urllib.parse

H = os.path.expanduser("~")
JOB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = os.path.dirname(os.path.dirname(JOB))
CLIENTS = f"{REPO}/knowledge/clients.md"
BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"
OUT = os.environ.get("STUDENT_EDITION_OUT") or f"{JOB}/student-edition"  # override only for a scratch proof build (spp-p53a)
BOOK_OUT = "connectors-student-edition.xlsx"
SOURCES = [  # (folder in the edition, git repo, paths inside it; [] = the whole tree). Student starter kit section 1.
    ("agents-home", f"{H}/.agents", ["skills", "tools", "instructions", ".skill-lock.json", ".gitignore"]),
    ("master-connector-repo", REPO, ["AGENTS.md", "CLAUDE.md", ".agents/skills/README.md", "setup", "tools/README.md",
                                     "tools/_card-template.md", "tools/browser-and-computer.md", "tools/composio.md",
                                     "tools/exa.md", "tools/web-search.md", "system/evals/README.md",
                                     "system/evals/golden-tasks.md", "work/_template"]),
    ("ghl-command-universal", f"{H}/Development/ghl-command-universal", []),
    ("increase-roas-oauth-gateway", f"{H}/Development/increase-roas-oauth-gateway-hotfix", []),
]
DIRECTOR_HOME = f"{H}/Alex-Director"  # only a blank starter goes out: never the live ledger, graphs or receipts
ONE_SHOT = f"{H}/Documents/One-Shot-Builder"  # the rules repo the Director's role card reads (private, increase-roas)
RULE_FILES = [  # G19 (spp-c4e): files the shipped Director docs cite, from HEAD: (edition folder, path there, repo, path)
    ("one-shot-builder", "RULES.md", ONE_SHOT, "RULES.md"),                # alex-director/AGENTS.md L32 and L54 (§10)
    ("one-shot-builder", "docs/LESSONS.md", ONE_SHOT, "docs/LESSONS.md"),  # alex-director/references/execution.md L110
    ("alex-director", "STACK.md", DIRECTOR_HOME, "STACK.md"),              # AGENTS.md L33 (~/STACK.md links to it)
    ("alex-director", "CONCEPTS.md", DIRECTOR_HOME, "CONCEPTS.md"),        # AGENTS.md L36 (./CONCEPTS.md)
    # batch 7 (spp-c4f): gates.md L75 and RULES.md §13 run it before any shared or live write
    ("alex-director", "scripts/controller-write-guard.py", DIRECTOR_HOME, "scripts/controller-write-guard.py"),
    # batch 10 (spp-c4h): RULES.md L425 certifies against it
    ("one-shot-builder", "checklists/ONE_SHOT_READINESS.md", ONE_SHOT, "checklists/ONE_SHOT_READINESS.md"),
]
FALLBACK = {  # the stand-in a file gets if a build ever has to hold it back (the default is a one-line note)
    "alex-director/scripts/controller-write-guard.py": (
        "#!/usr/bin/env python3\n"
        "import json, sys; print(json.dumps({\"reason\": \"student edition stand-in: the real write guard did not pass the "
        "scrub, so every protected write is refused; live-write missions are out of scope for students\", \"status\": "
        "\"denied\"})); sys.exit(4)\n"),
}
GRAPHS_README = "# Mission graphs: one mission graph per file, copied from templates/mission-graph-template.md\n"
STARTER_FILES = {  # batch 10 (spp-c4h): a clean tree after first use, and the files the shipped docs point to
    ".gitignore": ".runtime/\n*.bak\n*.lock\n",  # the write guard's claims; ledger_check.py's .bak and .lock
    "STANDING_AUTHORIZATIONS.md": ("# Standing authorizations: none yet. The Director adds one bounded grant per line "
                                   "when the owner gives it (references/gates.md, 'Everything else' row).\n"),
    "docs/solutions/README.md": ("# Solutions: none yet. One file per solved problem, written once the fix works; "
                                 "AGENTS.md reads this folder when debugging or building a documented area.\n"),
}
STAND_IN = {  # client material the scrubber can't map: a one-line stand-in ships instead (edition path: (why, the line))
    "one-shot-builder/docs/LESSONS.md": (
        "it names clients' people and a client location's phone number, which knowledge/clients.md doesn't map",
        "# Lessons (student edition stand-in): Alex's lesson log isn't shipped because it names clients' people and phone "
        "numbers; keep your own here, one row per lesson: | # | Date | What happened | Root cause | Rule now | Enforced in |\n"),
}
OP_TIMEOUT = 60  # seconds per op call: subprocess.run kills op when it runs over (L-010: a perl alarm can't stop Go's op)
STATUS_TEMPLATE = "skills/repo-conform/assets/skeleton/STATUS.md"  # inside agents-home
HOOK_BOOK = os.path.relpath(BOOK, REPO)  # where the agents-home hook (cards_to_sheet.py) writes the workbook
VAULT = "r6z62bjyy3c5ipilbgs4lyakwi"  # 1Password Connectors, read by the connectors-sync robot (Keychain token)
OWN_NAMES = {"increaseroas", "increase roas", "increaseroas account", "increaseroas master"}  # = build_tabs.py OWN
OWN_ANCHORS = re.compile(r"(?<![A-Za-z0-9])(?:(?i:increase[\s_-]*roas|hot[\s_-]*tub[\s_-]*launch|dynamite|javar)|HTL)"
                         r"(?![A-Za-z0-9])")
SECRET_NAMES = [".env", ".env.*", "*.env", ".dev.vars", ".dev.vars.*", "*.pem", "*.key", "*.p12", "*.pfx", "*.jks",
                "*.keystore", "*.ppk", "id_rsa*", "id_ed25519*", "id_ecdsa*", "credentials.json", "*.tfvars", ".npmrc",
                ".netrc", ".pypirc"]
SECRET_SHAPES = [  # vendor key formats; generic "password = '...'" lines are not shapes (they hit test fixtures)
    ("1Password service account", r"\bops_[A-Za-z0-9_-]{40,}"), ("OpenAI or Anthropic key", r"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{30,}"),
    ("GitHub token", r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})"),
    ("Slack token", r"\bxox[abposr]-[A-Za-z0-9-]{10,}"), ("Google API key", r"\bAIza[0-9A-Za-z_-]{35}"),
    ("Google OAuth secret", r"\bGOCSPX-[A-Za-z0-9_-]{20,}"), ("Google refresh token", r"\b1//0[A-Za-z0-9_-]{30,}"),
    ("Meta token", r"\bEAA[A-Za-z0-9]{60,}"), ("GHL private integration", r"\bpit-[0-9a-f]{8}-[0-9a-f-]{20,}"),
    ("AWS key", r"\bAKIA[0-9A-Z]{16}\b"), ("Hugging Face token", r"\bhf_[A-Za-z0-9]{30,}"),
    ("Stripe live key", r"\b[rs]k_live_[A-Za-z0-9]{20,}"), ("private key", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    ("Composio key", r"\b(?:ak|uak)_[A-Za-z0-9_-]{20,}"), ("Apify token", r"\bapify_api_[A-Za-z0-9]{20,}"),
    ("Firecrawl key", r"\bfc-[0-9a-f]{32}\b"), ("Tailscale key", r"\btskey-[a-z]+-[A-Za-z0-9]{8,}-[A-Za-z0-9]{16,}"),
    ("xAI key", r"\bxai-[A-Za-z0-9]{40,}"), ("JWT", r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
]
SHAPES_RX = [(n, re.compile(r)) for n, r in SECRET_SHAPES]
BLOB = re.compile(r"[A-Za-z0-9+/=_-]{2000,}")  # longest real key here: a 1Password service-account token, 832
TLD = r"(?:com|net|org|io|co|us|biz|info|pro|app|dev|ai|site|online|ca|me|tv|store|shop|xyz|tech|page|live|club|agency|services|solutions|cloud|uk)"
HOST = re.compile(r"(?<![A-Za-z0-9@._-])((?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+" + TLD + r")(?![A-Za-z0-9-])", re.I)
EMAIL = re.compile(r"(?<![A-Za-z0-9._%+-])[A-Za-z0-9._%+-]+@((?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,24})(?![A-Za-z0-9-])")
PHONE = re.compile(r"(?<![\w+])(?:\+?1[\s.-]?)?\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-](\d{4})(?![\w])|(?<![\w])\+1(\d{3})(\d{3})(\d{4})(?!\d)")
GHL_ID = re.compile(r"(?<![A-Za-z0-9])[A-Za-z0-9]{20}(?![A-Za-z0-9])")
NUM_ID = re.compile(r"(?<![A-Za-z0-9])\d{9,20}(?![A-Za-z0-9])")
OWN_EMAIL_DOMAINS = ("increaseroas.com", "example.com", "example.org", "example.net")
# People who never agreed to be shared (spp-c4e): any address on a public mail domain gets a label.
PUBLIC_MAIL = re.compile(r"(?:^|\.)(?:g(?:oogle)?mail\.com|(?:outlook|hotmail|live|yahoo|aol)\.(?:com|co\.uk|co|ca|fr|de|it|es"
                         r"|com\.au|co\.jp|in)|icloud\.com|me\.com|mac\.com|proton\.me|protonmail\.(?:com|ch)|pm\.me)$", re.I)
PLACEHOLDER_LOCALS = {"user", "user1", "user2", "username", "you", "your", "yourname", "your.name", "your_name", "your-name",
                      "youremail", "your.email", "your_email", "name", "firstname", "first.last", "firstname.lastname",
                      "someone", "somebody", "example", "test", "foo", "bar", "john.doe", "jane.doe", "johndoe", "janedoe",
                      "email", "me", "x", "xxx", "abc"}
CREDIT_FILE = re.compile(r"^(?:LICEN[CS]E|COPYING|NOTICE|AUTHORS|CONTRIBUTORS)(?:[._-].*)?$", re.I)  # authors' credits stay
GFILE_LABEL = "GOOGLE_FILE_ID"
GFILE_PATH = re.compile(r"(https?://(?:docs|drive)\.google\.com/(?:(?:document|spreadsheets|presentation|forms|drawings|file)"
                        r"/(?:u/\d+/)?d/(?:e/)?|(?:drive/)?(?:u/\d+/)?folders/))([A-Za-z0-9_-]{20,})", re.I)
GFILE_QUERY = re.compile(r"(https?://(?:docs|drive)\.google\.com/[^\s\"'<>()]*?[?&]id=)([A-Za-z0-9_-]{20,})", re.I)
PARTNER_HANDLES = ("Manny2026", "ssaofficial")  # people's GitHub usernames on Alex's repos (repo-lock.md §1): never ship
PARTNER_LABEL = "PARTNER_GITHUB_USER"
PARTNER_RX = re.compile(r"(?i)(?<![A-Za-z0-9-])(?:" + "|".join(map(re.escape, PARTNER_HANDLES)) + r")(?![A-Za-z0-9-])")
DEV_ID = re.compile(r"(?i)\bdeveloper(?:/team)?\s+id\s*[:=]?\s*`?([0-9a-f]{24})(?![0-9a-f])")  # GHL Marketplace
SCRIPTS = os.path.dirname(os.path.abspath(__file__))
SEP = r"(?:[^A-Za-z0-9]|%20){0,6}"
AND = r"(?:and|&amp;|&|\+)"
WINDOW_BEFORE, WINDOW_AFTER = 160, 40


def _read(path, mode="rb"):
    with open(path, mode) as f:
        return f.read()


def _write(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def code_for(n):  # 0 -> A, 25 -> Z, 26 -> AA
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def squash(s):
    return re.sub(r"[^a-z0-9]", "", s.lower().replace("&", "and"))


def words(s):
    return [w.lower() for w in re.findall(r"[A-Za-z0-9]+|&", s.replace("&", " and "))]


class Client:
    def __init__(self, name):
        self.names, self.aliases, self.code = [name], [], None  # aliases: (text, exact_case)
        self.ids = {k: [] for k in ("ghl", "meta_account", "ga4_account", "ga4_property", "meta_id", "num")}
        self.emails, self.phones, self.domains = [], [], {}

    def keys(self):
        return [" ".join(words(n)) for n in self.names] + [" ".join(words(a)) for a, _ in self.aliases]


class ClientList(list):
    own_ids = frozenset()


def parse_clients(md):
    """Clients in order of first appearance, merged by name, word prefix ('Sun Pool' / 'Sun Pool & Spa') or alias.
    A row whose first name is our own (Increaseroas account ...) keeps its IDs as ours; its other names are clients."""
    clients, own_ids = ClientList(), set()

    def find(name):
        k = words(name)
        for c in clients:
            for ck in c.keys():
                ckw = ck.split()
                if ckw == k or (min(len(ckw), len(k)) >= 2 and (ckw[:len(k)] == k or k[:len(ckw)] == ckw)):
                    return c
        return None

    def add_name(c, n):
        if words(n) not in [words(x) for x in c.names]:
            c.names.append(n)

    header = None
    for line in md.splitlines():
        if not line.startswith("|"):
            header = None
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if line.startswith("|---"):
            continue
        if header is None:
            header = [c.lower() for c in cells]
            continue
        row = dict(zip(header, cells))
        names = [re.sub(r"\*", "", n).strip() for n in re.split(r"[(),]", cells[0])]
        names = [n for n in names if len(n) >= 5]
        if not names:
            continue
        rest = " | ".join(cells[1:])
        if names[0].lower() in OWN_NAMES:
            own_ids |= set(re.findall(r"\b\d{6,}\b", rest))
            for n in names[1:]:
                if n.lower() not in OWN_NAMES:
                    c = find(n)
                    if c is None:
                        clients.append(Client(n))
                    else:
                        add_name(c, n)
            continue
        c = next((x for x in map(find, names) if x), None)
        if c is None:
            c = Client(names[0])
            clients.append(c)
        for n in names:
            if n.lower() not in OWN_NAMES:
                add_name(c, n)
        for a in re.split(r"[,;]", row.get("also written as", "")):
            a = a.strip()
            if a:
                c.aliases.append((a.strip("`"), a.startswith("`") and a.endswith("`")))
        c.ids["meta_account"] += re.findall(r"\bact_(\d{6,})\b", rest)
        c.ids["ga4_account"] += re.findall(r"\baccount (\d{6,})\b", rest)
        c.ids["ga4_property"] += re.findall(r"\bproperty (\d{6,})\b", rest)
        c.ids["ghl"] += [t for t in GHL_ID.findall(rest) if _mixed(t)]
        c.ids["num"] += [t for t in NUM_ID.findall(row.get("other ids", "")) if t not in c.ids["meta_account"]]
    for i, c in enumerate(clients):
        c.code = code_for(i)
        for k in c.ids:
            c.ids[k] = list(dict.fromkeys(v for v in c.ids[k] if v not in own_ids))
    clients.own_ids = frozenset(own_ids)
    return clients


def _mixed(t):
    return bool(re.search(r"[a-z]", t) and re.search(r"[A-Z]", t) and re.search(r"\d", t))


def word_rx(w):
    if w == "and":
        return AND
    if len(w) > 3 and w.endswith("s"):
        return re.escape(w[:-1]) + r"['’]?s"
    return re.escape(w)


def name_body(text):
    return SEP.join(word_rx(w) for w in words(text))


def render(code, matched, starts_with_the):
    """The label in the style of the matched text: Client A / client-a / client_a / CLIENT_A / clientA."""
    letters = re.sub(r"[^A-Za-z]", "", matched)
    seps = re.findall(r"[^A-Za-z0-9]+", matched)
    if starts_with_the and re.match(r"the[^A-Za-z0-9]", matched) and re.search(r"[A-Z]", matched[3:]):
        return "the Client " + code
    if letters.isupper() and len(letters) > 1:
        return "CLIENT" + (" " if " " in matched else "_") + code
    if letters.islower():
        sep = "_" if "_" in matched else "-" if ("-" in matched or not seps or "." in matched) else " "
        return "client" + sep + code.lower()
    if not seps and matched[:1].islower():
        return "client" + code
    sep = "_" if "_" in matched else "-" if "-" in matched else " "
    return "Client" + sep + code


class Mapping:
    """Real identifier -> label, in memory only."""

    def __init__(self, clients, own_terms=()):
        self.clients = clients
        self.own_ids = set(getattr(clients, "own_ids", ()))
        self.own_rx = OWN_ANCHORS if not own_terms else re.compile(
            "|".join(f"(?<![A-Za-z0-9])(?i:{name_body(t)})(?![A-Za-z0-9])" for t in own_terms))
        alts, self._groups = [], []
        for c in clients:
            starts_the = words(c.names[0])[:1] == ["the"]
            items = [(n, False) for n in c.names] + list(c.aliases)
            for text, exact in items:
                body = name_body(text) if not exact else SEP.join(re.escape(w) for w in re.findall(r"[A-Za-z0-9]+", text))
                alts.append((len(text), f"(?<![A-Za-z0-9])({body if exact else '(?i:' + body + ')'})(?![A-Za-z0-9])",
                             c, starts_the))
        alts.sort(key=lambda a: -a[0])
        self._groups = [(c, st) for _, _, c, st in alts]
        self.name_rx = re.compile("|".join(a[1] for a in alts)) if alts else None
        self.squashed = sorted(((squash(t), c) for c in clients for t, ex in
                                [(n, False) for n in c.names] + c.aliases if not ex and len(squash(t)) >= 6),
                               key=lambda x: -len(x[0]))
        self.person_label, self.owner_label, self.gfile_ids, self._personal = {}, {}, set(), True
        self._id_index()
        self._extra_index()

    # ------------------------------------------------------------------ identifiers
    def _id_index(self):
        self.id_label, self.code_of = {}, {}  # code_of: real identifier -> client code (for findings)
        for c in self.clients:
            for kind, base in (("ghl", "LOCATION_ID"), ("meta_account", "AD_ACCOUNT_ID"), ("ga4_account", "GA4_ACCOUNT_ID"),
                               ("ga4_property", "GA4_PROPERTY_ID"), ("meta_id", "META_ID"), ("num", "ID")):
                for n, v in enumerate(c.ids[kind], 1):
                    if v not in self.id_label:
                        self.id_label[v] = f"CLIENT_{c.code}_{base}" + (f"_{n}" if n > 1 else "")
                        self.code_of[v] = c.code
            for v in c.emails + c.phones:
                self.code_of[v] = c.code
        ghl = [v for v in self.id_label if not v.isdigit()]
        num = [v for v in self.id_label if v.isdigit()]
        parts = []
        if ghl:
            parts.append(r"(?<![A-Za-z0-9])(?:" + "|".join(map(re.escape, sorted(ghl, key=len, reverse=True))) + r")(?![A-Za-z0-9])")
        if num:
            parts.append(r"(?<!\d)(?:" + "|".join(sorted(num, key=len, reverse=True)) + r")(?!\d)")
        self.id_rx = re.compile("|".join(parts)) if parts else None
        self.email_label = {e: f"contact{n if n > 1 else ''}@client-{c.code.lower()}.example"
                            for c in self.clients for n, e in enumerate(c.emails, 1)}
        self.phone_label = {p: f"CLIENT_{c.code}_PHONE" + (f"_{n}" if n > 1 else "")
                            for c in self.clients for n, p in enumerate(c.phones, 1)}
        self.phone_rx = re.compile("|".join(
            rf"(?<!\d)(?:\+?1[\s.-]?)?\(?{p[:3]}\)?[\s.-]?{p[3:6]}[\s.-]?{p[6:]}(?!\d)" for p in self.phone_label)) \
            if self.phone_label else None

    def client_of(self, m):
        return self._groups[m.lastindex - 1]

    def domain_client(self, label):
        s = squash(label)
        for key, c in self.squashed:
            if key in s:
                return c
        return None

    def _domain_label(self, c, real, kind):
        if real not in c.domains:
            n = sum(1 for k in c.domains.values() if k[0] == kind) + 1
            code = c.code.lower()
            c.domains[real] = (kind, f"client-{code}{'-' + str(n) if n > 1 else ''}" + (".example" if kind == "site" else ""))
        return c.domains[real][1]

    def scrub_host(self, host):
        labels = host.split(".")
        if len(labels) < 2:
            return host
        reg = labels[-2]
        c = self.domain_client(reg)
        if c:
            return ".".join(labels[:-2] + [self._domain_label(c, ".".join(labels[-2:]).lower(), "site")])
        out, changed = [], False
        for lab in labels[:-2]:
            c = self.domain_client(lab)
            if c:
                out.append(self._domain_label(c, lab.lower(), "label"))
                changed = True
            else:
                out.append(lab)
        return ".".join(out + labels[-2:]) if changed else host

    # ------------------------------------------------------------------ beyond clients (spp-c4e)
    def _extra_index(self):
        """Regexes for the owner's account IDs and the Google file IDs harvested from links (bare copies too)."""
        alt = lambda vals: "|".join(map(re.escape, sorted(vals, key=len, reverse=True)))
        self.owner_rx = re.compile(r"(?i)(?<![0-9a-f])(?:" + alt(self.owner_label) + r")(?![0-9a-f])") \
            if self.owner_label else None
        self.gfile_rx = re.compile(r"(?<![A-Za-z0-9_-])(?:" + alt(self.gfile_ids) + r")(?![A-Za-z0-9_-])") \
            if self.gfile_ids else None

    def harvest_extra(self, units):
        """Alex's GHL Marketplace developer/team ID (by its label in the text) and every Google file ID seen in a link."""
        for _, text in units:
            if not text:
                continue
            for mt in DEV_ID.finditer(text):
                v = mt.group(1).lower()
                if v not in self.owner_label:
                    n = len(self.owner_label) + 1
                    self.owner_label[v] = "OWNER_GHL_DEVELOPER_ID" + (f"_{n}" if n > 1 else "")
            for rx in (GFILE_PATH, GFILE_QUERY):
                self.gfile_ids |= {mt.group(2) for mt in rx.finditer(text) if mt.group(2) != GFILE_LABEL}
        self._extra_index()
        return {"owner_ids": len(self.owner_label), "google_file_ids": len(self.gfile_ids)}

    def _person(self, e):
        if e not in self.person_label:
            self.person_label[e] = f"person-{len(self.person_label) + 1}@example.com"
        return self.person_label[e]

    def _email(self, m):
        e = m.group(0)
        if e.lower() in self.email_label:
            return self.email_label[e.lower()]
        dom = m.group(1).lower()
        c = self.domain_client(dom.split(".")[-2]) if "." in dom else None
        if c is None:
            local = e.split("@", 1)[0].lower()
            if self._personal and PUBLIC_MAIL.search(dom) and local not in PLACEHOLDER_LOCALS:
                return self._person(e.lower())
            return e
        c.emails.append(e.lower())
        n = len(c.emails)
        self.email_label[e.lower()] = f"contact{n if n > 1 else ''}@client-{c.code.lower()}.example"
        self.code_of[e.lower()] = c.code
        return self.email_label[e.lower()]

    # ------------------------------------------------------------------ scrub
    def scrub(self, text, personal=True):
        """personal=False keeps public-mail addresses (LICENSE-style credit files); everything else is the same."""
        if not text:
            return text
        self._personal = personal
        try:
            text = EMAIL.sub(self._email, text)
        finally:
            self._personal = True
        for rx in (GFILE_PATH, GFILE_QUERY):
            text = rx.sub(lambda m: m.group(1) + GFILE_LABEL, text)
        if self.gfile_rx:
            text = self.gfile_rx.sub(GFILE_LABEL, text)
        if self.owner_rx:
            text = self.owner_rx.sub(lambda m: self.owner_label[m.group(0).lower()], text)
        text = PARTNER_RX.sub(PARTNER_LABEL, text)
        text = HOST.sub(lambda m: self.scrub_host(m.group(1)), text)
        if self.phone_rx:
            text = self.phone_rx.sub(lambda m: self.phone_label[re.sub(r"\D", "", m.group(0))[-10:]], text)
        if self.id_rx:
            text = self.id_rx.sub(lambda m: self.id_label[m.group(0)], text)
        if self.name_rx:
            text = self.name_rx.sub(lambda m: render(self.client_of(m)[0].code, m.group(0), self.client_of(m)[1]), text)
        return text

    def scrub_path(self, rel):
        return "/".join(self.scrub(p) for p in rel.split("/"))

    # ------------------------------------------------------------------ harvest by context
    def harvest(self, units):
        """IDs, emails and phones written next to a client's name join that client. Each mention votes: 3 when the
        name follows right after the ID ('543642271 Paradise Spas'), 1 when it is nearby. Our own names vote too; the
        client keeps the ID only with more votes than ours (a tie stays ours)."""
        votes, order = {}, []
        known = set(self.id_label) | self.own_ids
        for _, text in units:
            if not text or not self.name_rx:
                continue
            anchors = [(m.start(), m.end(), self.client_of(m)[0]) for m in self.name_rx.finditer(text)]
            if not anchors:
                continue
            anchors += [(m.start(), m.end(), None) for m in self.own_rx.finditer(text)]
            anchors.sort(key=lambda a: a[0])
            for kind, value, s, e in self._candidates(text):
                if value in known:
                    continue
                owner, weight = _nearest(anchors, s, e, text)
                if owner is False:
                    continue
                key = (kind, value)
                if key not in votes:
                    votes[key] = {}
                    order.append(key)
                who = "own" if owner is None else owner.code
                votes[key][who] = votes[key].get(who, 0) + weight
        by_code = {c.code: c for c in self.clients}
        taken = {k: 0 for k in ("ghl", "meta_account", "meta_id", "num", "email", "phone")}
        for key in order:
            own = votes[key].pop("own", 0)
            if not votes[key]:
                continue
            code, score = max(votes[key].items(), key=lambda kv: kv[1])
            if score <= own:
                continue
            kind, value = key
            c = by_code[code]
            bucket = c.emails if kind == "email" else c.phones if kind == "phone" else c.ids[kind]
            if value not in bucket:
                bucket.append(value)
                taken[kind] += 1
        self._id_index()
        return taken

    def _candidates(self, text):
        for m in GHL_ID.finditer(text):
            if _mixed(m.group(0)):
                yield "ghl", m.group(0), m.start(), m.end()
        for m in NUM_ID.finditer(text):
            v = m.group(0)
            kind = "meta_account" if text[max(0, m.start() - 4):m.start()] == "act_" else "meta_id" if len(v) >= 15 else "num"
            yield kind, v, m.start(), m.end()
        for m in EMAIL.finditer(text):
            if not m.group(1).lower().endswith(OWN_EMAIL_DOMAINS):
                yield "email", m.group(0).lower(), m.start(), m.end()
        for m in PHONE.finditer(text):
            yield "phone", re.sub(r"\D", "", m.group(0))[-10:], m.start(), m.end()


def _nearest(anchors, s, e, text=""):
    """Who the identifier at s..e belongs to, with the weight of that vote: a name starting right after it
    ('543642271 Paradise Spas', weight 3), else the closest name ending before it (within WINDOW_BEFORE), else the
    first one starting after it (within WINDOW_AFTER), weight 1. The owner is a Client, None for our own name, or
    False when no name is near."""
    i = bisect.bisect_right([a[1] for a in anchors], s)  # anchors sorted by start; ends rise with starts here
    for a in anchors[i:]:
        if a[0] >= e:
            if a[0] - e <= 2 and not re.search(r"[A-Za-z0-9,;]", text[e:a[0]]):
                return a[2], 3
            break
    best = next((a for a in anchors[:i][::-1] if a[1] <= s), None)
    if best and s - best[1] <= WINDOW_BEFORE:
        return best[2], 1
    for a in anchors[i:]:
        if a[0] >= e:
            return (a[2], 1) if a[0] - e <= WINDOW_AFTER else (False, 0)
    return False, 0


# ---------------------------------------------------------------------------------------------------------- xlsx
HF = re.compile(r"(<(odd|even|first)(Header|Footer)>)(.*?)(</\2\3>)", re.S)
HF_CODE = re.compile(r'(&(?:"[^"]*"|\d+|K[0-9A-Fa-f]{6}|[A-Za-z&]))')
TEXT_NODE = re.compile(r">([^<]+)<")
ATTR = re.compile(r'(\s[\w:.-]+=)("([^"]*)"|\'([^\']*)\')')


def _xml_escape(s, attr=False):
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return s.replace('"', "&quot;") if attr else s


def scrub_xml(text, m):
    def hf(mt):
        inner = html.unescape(mt.group(4))
        new = "".join(p if HF_CODE.fullmatch(p) else m.scrub(p) for p in HF_CODE.split(inner))
        return mt.group(1) + (_xml_escape(new) if new != inner else mt.group(4)) + mt.group(5)

    def node(mt):
        raw = mt.group(1)
        plain = html.unescape(raw)
        new = m.scrub(plain)
        return ">" + (_xml_escape(new) if new != plain else raw) + "<"

    def attr(mt):
        raw = mt.group(3) if mt.group(3) is not None else mt.group(4)
        plain = html.unescape(raw)
        new = m.scrub(plain)
        return mt.group(1) + ('"' + _xml_escape(new, True) + '"' if new != plain else mt.group(2))

    text = HF.sub(hf, text)
    text = TEXT_NODE.sub(node, text)
    return ATTR.sub(attr, text)


def xml_text(text):
    """What a reader could see in an XML part: tag-free text (runs joined per string), attribute values, and header or
    footer text without its &C-style codes. Used by the leak check."""
    plain = html.unescape(re.sub(r"<[^>]+>", " ", text))
    runs = [html.unescape("".join(re.findall(r"<(?:\w+:)?t\b[^>]*>(.*?)</(?:\w+:)?t>", blk, re.S)))
            for blk in re.findall(r"<(?:\w+:)?(?:si|is|text)\b[^>]*>(.*?)</(?:\w+:)?(?:si|is|text)>", text, re.S)]
    attrs = [html.unescape(a or b) for _, _, a, b in ATTR.findall(text)]
    out = "\n".join([plain] + runs + attrs)
    return HF_CODE.sub(" ", out)


def scrub_xlsx(src, dst, m):
    changed = 0
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            data = zin.read(info.filename)
            if info.filename.endswith((".xml", ".rels", ".vml")):
                old = data.decode("utf-8")
                new = scrub_xml(old, m)
                changed += old != new
                data = new.encode("utf-8")
            zout.writestr(info, data)
    return changed


# ---------------------------------------------------------------------------------------------------------- export
def is_text(data):
    if b"\0" in data[:8192]:
        return False
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def export_tree(root, paths, dst, m):
    """Tracked files of HEAD (git archive: no .git, no history, no untracked files), scrubbed, keys and .env left out."""
    head = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    tar = subprocess.run(["git", "-C", root, "archive", "--format=tar", "HEAD", "--"] + list(paths),
                         capture_output=True, check=True).stdout
    stats = {"commit": head[:12], "files": 0, "text_changed": 0, "renamed": 0, "binary": 0, "skipped_secret_names": 0,
             "skipped_links": 0}
    with tarfile.open(fileobj=io.BytesIO(tar)) as t:
        for mem in t.getmembers():
            if mem.isdir() or mem.name == "pax_global_header":
                continue
            if not mem.isfile():
                stats["skipped_links"] += 1
                continue
            if any(fnmatch.fnmatch(os.path.basename(mem.name), p) for p in SECRET_NAMES):
                stats["skipped_secret_names"] += 1
                continue
            data = t.extractfile(mem).read()
            rel = m.scrub_path(mem.name)
            stats["renamed"] += rel != mem.name
            if is_text(data):
                old = data.decode("utf-8")
                new = m.scrub(old, personal=not CREDIT_FILE.match(os.path.basename(mem.name)))
                stats["text_changed"] += new != old
                data = new.encode("utf-8")
            else:
                stats["binary"] += 1
            path = os.path.join(dst, rel)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
            os.chmod(path, 0o755 if mem.mode & 0o111 else 0o644)
            stats["files"] += 1
    return stats


def blank_block(lines):
    """(start, end) of the commented-out blank mission block at the top of the ledger (lines[start] is '<!--',
    lines[end] is '-->'); its fields must be empty or NONE. Refuses anything else, so live data never ships."""
    try:
        start = next(i for i, l in enumerate(lines[:12]) if l.strip() == "<!--")
        end = next(i for i in range(start + 1, len(lines)) if lines[i].strip() == "-->")
    except StopIteration:
        raise SystemExit("DIRECTOR_STATE.md has no blank mission block at the top; no ledger shipped")
    body = lines[start + 1:end]
    if (not body or not body[0].startswith("## Mission: [")
            or not all(re.fullmatch(r"[A-Z0-9_]+:[ \t]*(?:NONE)?[ \t]*\n?", l) for l in body[1:] if l.strip())):
        raise SystemExit("DIRECTOR_STATE.md's top block is no longer the blank mission block; no ledger shipped")
    return start, end


def director_starter(root, dst, m):
    """A Director home a student can start from: the blank ledger (DIRECTOR_STATE.md at HEAD up to the end of its
    commented-out blank mission block: title, rule and the block), the mission-graph template, an empty mission-graphs/,
    the role card when it names no client, and (batch 10, spp-c4h) a .gitignore for the ledger's .bak/.lock files and
    the write guard's .runtime/, plus one-line stand-ins for the files the shipped docs point to but a student starts
    without (STANDING_AUTHORIZATIONS.md, docs/solutions/README.md). The blank block gets
    SUPERVISING_DIRECTOR_THREAD_ID: NONE (the conductor's Report reads it) when the live one lacks it."""
    show = lambda f: subprocess.run(["git", "-C", root, "show", f"HEAD:{f}"], capture_output=True, text=True,
                                    check=True).stdout
    lines = show("DIRECTOR_STATE.md").splitlines(keepends=True)
    start, end = blank_block(lines)
    added = []
    if not any(l.startswith("SUPERVISING_DIRECTOR_THREAD_ID:") for l in lines[start:end]):
        at = next((i + 1 for i in range(start, end) if lines[i].startswith("CONTROLLER_HOST_ID:")), end)
        lines.insert(at, "SUPERVISING_DIRECTOR_THREAD_ID: NONE\n")
        end += 1
        added.append("SUPERVISING_DIRECTOR_THREAD_ID")
    os.makedirs(f"{dst}/templates", exist_ok=True)
    os.makedirs(f"{dst}/mission-graphs", exist_ok=True)
    os.makedirs(f"{dst}/docs/solutions", exist_ok=True)
    _write(f"{dst}/DIRECTOR_STATE.md", m.scrub("".join(lines[:end + 1])))
    _write(f"{dst}/templates/mission-graph-template.md", m.scrub(show("templates/mission-graph-template.md")))
    _write(f"{dst}/mission-graphs/README.md", GRAPHS_README)  # batch 7 (spp-c4f): step 5b copies a graph in here
    for rel, text in STARTER_FILES.items():
        _write(f"{dst}/{rel}", text)
    card = show("AGENTS.md")
    client = any(k.startswith("client") for k, _ in scan_text(card, m, VaultIndex([]), shapes=False))
    if not client:
        _write(f"{dst}/AGENTS.md", card)
    head = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
    return {"commit": head[:12], "files": 3 + len(STARTER_FILES) + (not client), "blank_block_fields_added": added,
            "agents_md": "left out: client data" if client else "included"}


def add_repo_files(edition):
    """Make the student copy of the connector repo work like the real one: the workbook where the agents-home hook
    writes it, and a blank STATUS.md from the repo-conform skeleton."""
    book = f"{edition}/repo/master-connector-repo/{HOOK_BOOK}"
    os.makedirs(os.path.dirname(book), exist_ok=True)
    shutil.copyfile(f"{edition}/{BOOK_OUT}", book)
    shutil.copyfile(f"{edition}/repo/agents-home/{STATUS_TEMPLATE}", f"{edition}/repo/master-connector-repo/STATUS.md")


def rule_files(dst, m, vault, files=None, stand_in=None, fallback=None):
    """G19 (spp-c4e, spp-c4f): the rule files and the write guard the shipped Director docs cite, as scrubbed copies of
    each repo's HEAD (committed text only, like the code), executable when the source is. A file stand_in names, or
    whose scrubbed text the leak check still flags, or that still holds a phone number the scrubber can't map, ships as
    a stand-in instead: its fallback text (the write guard's refuses every protected write), else a one-line note.
    Returns ({edition path: what shipped}, {edition folder: commit})."""
    files = RULE_FILES if files is None else files
    stand_in = STAND_IN if stand_in is None else stand_in
    fallback = FALLBACK if fallback is None else fallback
    shipped, commits = {}, {}
    for folder, rel, root, path in files:
        git = lambda *a: subprocess.run(["git", "-C", root, *a], capture_output=True, text=True, check=True).stdout
        commits.setdefault(folder, git("rev-parse", "HEAD").strip()[:12])
        new = m.scrub(git("show", f"HEAD:{path}"))
        executable = git("ls-tree", "HEAD", "--", path).split(" ")[0] == "100755"
        key = f"{folder}/{rel}"
        why, line = stand_in.get(key, (None, None))
        if not why:
            kinds = sorted({k for k, _ in scan_text(new, m, vault)})
            why = ("the scrubbed copy still had: " + ", ".join(kinds)) if kinds else \
                ("a phone number the scrubber can't map" if PHONE.search(new) else None)
        target = os.path.join(dst, folder, rel)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if why:
            text = line or fallback.get(key) or \
                f"# {os.path.basename(rel)} (student edition stand-in): not shipped because {why}.\n"
            _write(target, text)
            shipped[key] = f"{'one-line stand-in' if text.count(chr(10)) <= 1 else 'stand-in'}: {why}"
        else:
            _write(target, new)
            shipped[key] = f"scrubbed copy of {os.path.basename(root)} {path} @ {commits[folder]}"
        os.chmod(target, 0o755 if executable else 0o644)
    return shipped, commits


BUILDER_NOTE = ("> **Student edition:** Running GHL Command needs your own GHL Command licence and sign-in; not part of the "
                "student build. This code ships for reading only (Rebuild from zero checks 10.3 and 10.5 are partner "
                "route only).\n\n")


def builder_note(edition):
    """G14 (spp-c4e): the GHL builder's own README in the edition opens with the student note."""
    p = f"{edition}/repo/ghl-command-universal/README.md"
    if not os.path.exists(p):
        return False
    _write(p, BUILDER_NOTE + _read(p).decode("utf-8"))
    return True


# ---------------------------------------------------------------------------------------------------------- affiliate links
# Alex: "i want the student copy to auto use all my affiliate links" (Director dispatch, 2026-10-02). The list lives in
# ONE place, his Google Sheet (knowledge/affiliate-links.md); every build reads it there and keeps no copy to fall back on.
AFFILIATE_SHEET = "18G7-Ry6M4suDWUAyEs4on4UOaSXOZD3Ss3fxDxnrbKI"  # "Affiliate programs - Alex (Increase ROAS)"
AFFILIATE_RANGE = "Programs!A1:O"
SHEETS_READ = "CUSTOM_GOOGLE_ROBOT_SHEETS_READ"  # Composio custom_google_robot, read-only (google-workspace card)
GOOGLE_ROBOT = "ca_vm6rcasgNEIk"  # the robot's one Composio login; SHEET_USER picks whose Drive it reads
SHEET_USER = "alex@increaseroas.com"
COMPOSIO = f"{H}/.local/bin/composio"
SHEET_TIMEOUT = 120  # seconds: subprocess.run kills the CLI when it runs over
AFFILIATE_COLUMNS = ("Tool", "Apply here (URL)", "Your affiliate link", "Status", "Source URL")
# Director, 2026-10-02: FTC staff call "paid link" next to a link adequate and HighLevel's own example is "(Paid Link)"
# (affiliate-programs.md §3 C4); the old "at no cost" wording is gone because no vendor's price was checked (§4.4).
AFFILIATE_DISCLOSURE = "I earn a commission if you buy through these links."
AFFILIATE_LABEL = " (paid link)"  # right after every swapped link: HighLevel wants the disclosure close to each one
DOC_EXT = (".md", ".markdown", ".mdx", ".txt")  # the docs; code files are never opened
SITE_SKIP = {"help", "docs", "doc", "support", "community", "developer", "developers", "dev", "api", "apis", "app",
             "apps", "dashboard", "console", "login", "signin", "auth", "oauth", "sso", "id", "account", "accounts",
             "partner", "partners", "affiliate", "affiliates", "portal", "status", "blog", "marketplace", "academy",
             "learn", "forum", "forums", "ideas", "changelog", "cdn", "static", "services", "rest", "code", "platform",
             "knowledge", "mcp", "backend", "connect", "admin", "mail", "hooks", "webhooks", "billing"}
SITE_FALLBACK = {"claude": ("claude.com",), "chatgpt": ("chatgpt.com",)}  # rows whose Sheet URLs are docs or help pages
# only; each site's pricing page checked 2026-10-02 (notes/student-edition.md §11). Used only when the row gives no host.
Affiliate = collections.namedtuple("Affiliate", "rank tool link hosts")
_LOCALE = r"(?:/intl)?(?:/[a-z]{2}(?:[-_][a-z]{2})?)?"
PRICING_PATH = re.compile(_LOCALE + r"/(?:pricing|plans|prices?)(?:/[^/]+)?/?", re.I)
SIGNUP_PATH = re.compile(_LOCALE + r"/(?:sign[-_]?up|register|get[-_]?started|join|start|try|trial|free[-_]?trial|"
                         r"\d+[-_]days?[-_]free[-_]trial)(?:/[^/]+)?/?", re.I)
LINK_RX = re.compile(r"(?P<pre>\]\()(?P<md>https?://[^\s()<>]+)(?P<post>(?:\s+(?:\"[^\"]*\"|'[^']*'))?\))"  # [x](url)
                     r"|<(?P<auto>https?://[^\s<>]+)>"  # <url>
                     r"|(?P<attr>=\s*[\"'{]\s*)https?://[^\s\"'<>{}]+"  # an HTML or JSX attribute: left alone
                     r"|(?P<bare>https?://[^\s<>\"'`|\\\[\](){}]+)", re.I)
CMD_BEFORE = re.compile(r"(?:^|[\s`(])(?:curl|wget|xh)\s")  # "run curl -I <url>": a command written into a sentence
CITED = re.compile(r"\s*\((?:read|checked|seen|accessed)\s+\d{4}-\d{2}-\d{2}", re.I)  # "URL (read 2026-10-01)": a source
FENCE = re.compile(r" {0,3}(`{3,}|~{3,})")
INDENTED = re.compile(r"(?: {4}|\t)")
LISTY = re.compile(r"\s*(?:[-*+]\s|\d{1,9}[.)]\s|\||>)")
COMMAND = re.compile(r"\s*(?:\$\s|(?:sudo\s+)?(?:curl|wget|npx|npm|pnpm|yarn|pip3?|brew|git|gh|composio|op|python3?|node|"
                     r"bash|sh|zsh|ssh|uvx?|docker|wrangler|hyperframes|firecrawl|import|export)\s)")
INLINE_CODE = re.compile(r"(`+)(?:(?!\1).)+?\1|<code\b.*?</code>|<pre\b.*?</pre>|<!--.*?-->", re.S | re.I)
OPENER = re.compile(r"<!--|<pre\b", re.I)  # a comment or <pre> left open on a line runs on to its close
GENERIC_WORDS = {"portal", "studio", "online", "agency", "systems", "software"}  # never a site name on their own
T_NODE = re.compile(r"(<t(?:\s[^>]*)?(?<!/)>)([^<]*)(</t>)")  # a text run; never an empty <t/>
SI_ITEM = re.compile(r"<si\b[^>]*/>|<si\b[^>]*>.*?</si>", re.S)
CELL = re.compile(r"<c\b[^>]*?/>|<c\b[^>]*>.*?</c>", re.S)
SHEET_PART = re.compile(r"xl/worksheets/sheet\d+\.xml$")


def _redact(s):
    for _, rx in SHAPES_RX:
        s = rx.sub("[redacted]", s)
    return s


def _values(o):
    """The first {"values": [[...], ...]} inside a Composio answer."""
    if isinstance(o, dict):
        if isinstance(o.get("values"), list):
            return o["values"]
        o = list(o.values())
    if isinstance(o, list):
        for v in o:
            got = _values(v) if isinstance(v, (dict, list)) else None
            if got is not None:
                return got
    return None


def read_affiliates(composio=None):
    """Alex's live affiliate links, read at build time from his Sheet through Composio custom_google_robot sheets_read
    as alex@. Any problem stops the build (SystemExit): there is no stored copy, so old links can never come back."""
    def fail(why):
        raise SystemExit(f"affiliate Sheet not read ({why}); build stopped before anything was built, so the old edition "
                         "is kept and no old links are reused")
    cmd = [composio or COMPOSIO, "execute", SHEETS_READ, "--account", GOOGLE_ROBOT, "-d",
           json.dumps({"spreadsheet_id": AFFILIATE_SHEET, "range": AFFILIATE_RANGE, "user": SHEET_USER})]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=SHEET_TIMEOUT)
    except subprocess.TimeoutExpired:
        fail(f"Composio ran over {SHEET_TIMEOUT} s and was stopped")
    except OSError as e:
        fail(f"the Composio CLI did not start: {e.strerror}")
    if r.returncode != 0:
        last = (r.stderr.strip() or r.stdout.strip()).splitlines()[-1:] or [""]
        fail(f"Composio exit {r.returncode}: {_redact(last[0])[:200]}")
    try:
        out = json.loads(r.stdout)
    except ValueError:
        fail("Composio's answer is not JSON")
    if not isinstance(out, dict) or out.get("successful") is not True:
        fail("Composio says: " + _redact(str(out.get("error") if isinstance(out, dict) else out))[:200])
    values = _values(out.get("data"))
    if not values or not isinstance(values[0], list):
        fail(f"no rows came back for {AFFILIATE_RANGE}")
    return parse_affiliates(values)


def parse_affiliates(values):
    """(live, stats) from the Programs rows. Only rows whose Status is live AND that have a link count; each gets its
    product's own web hosts. A live link that isn't a web address, or two live rows claiming one host, stop the build."""
    head = [str(h).strip() for h in values[0]]
    missing = [c for c in AFFILIATE_COLUMNS if c not in head]
    if missing:
        raise SystemExit(f"affiliate Sheet: no {', '.join(missing)} column in {AFFILIATE_RANGE}; build stopped")
    col = {c: head.index(c) for c in head}
    cell = lambda row, c: str(row[col[c]]).strip() if c in col and col[c] < len(row) else ""
    live, owner = [], {}
    stats = {"rows": len(values) - 1, "live_rows": 0, "live_without_link": [], "no_product_site": []}
    for row in values[1:]:
        if cell(row, "Status").lower() != "live":
            continue
        stats["live_rows"] += 1
        tool, link, rank = cell(row, "Tool"), cell(row, "Your affiliate link"), cell(row, "Rank")
        if not link:
            stats["live_without_link"].append(tool)
            continue
        p = urllib.parse.urlsplit(link)
        if p.scheme not in ("http", "https") or not p.hostname or re.search(r"\s", link):
            raise SystemExit(f"affiliate Sheet row {rank or '?'} ({tool}): 'Your affiliate link' is not a web address; "
                             "build stopped")
        urls = re.findall(r"https?://[^\s;,]+", cell(row, "Apply here (URL)") + " " + cell(row, "Source URL"))
        hosts = product_hosts(tool, urls) or {h for w in re.split(r"[^a-z0-9]+", tool.lower())
                                              for site in SITE_FALLBACK.get(w, ()) for h in (site, "www." + site)}
        if not hosts:
            stats["no_product_site"].append(tool)
            continue
        for h in hosts:
            if owner.setdefault(h, tool) != tool:
                raise SystemExit(f"affiliate Sheet: {tool} and {owner[h]} are both live for {h}; build stopped")
        live.append(Affiliate(rank, tool, link, frozenset(hosts)))
    return live, stats


def product_hosts(tool, urls):
    """The product's own web hosts, taken from the row's program and source URLs: a host whose site name matches the
    tool (gohighlevel.com for "HighLevel (GoHighLevel)"); apex and www count together, another subdomain only as itself
    (workspace.google.com), and never a help, docs, API, app, login or partner host."""
    name = squash(tool)
    parts = {squash(w) for w in re.split(r"[^A-Za-z0-9]+", tool)} - {""}
    hosts = set()
    for u in urls:
        try:
            h = (urllib.parse.urlsplit(u).hostname or "").rstrip(".")
        except ValueError:
            continue
        labels = h.split(".")
        if len(labels) < 2:
            continue
        n = 3 if len(labels) >= 3 and len(labels[-1]) == 2 and labels[-2] in ("co", "com", "org", "net", "ac", "gov") else 2
        site, sub = labels[-n], labels[:-n]
        if not (site == name or (len(site) >= 4 and site in name)
                or any(len(w) >= 6 and w not in GENERIC_WORDS and w in site for w in parts)):
            continue  # someone else's site (an affiliate network, a directory, a social network)
        if sub[:1] == ["www"]:
            sub = sub[1:]
        if any(piece in SITE_SKIP for label in sub for piece in label.split("-")):
            continue
        apex = ".".join(labels[-n:])
        hosts |= {h} if sub else {apex, "www." + apex}
    return hosts


def link_kind(url, hosts):
    """"home", "pricing" or "sign-up" when url is one of these hosts' own home, pricing or sign-up page; None for
    anything else (API, docs, help, app and login hosts aren't in hosts, and no other path counts)."""
    try:
        p = urllib.parse.urlsplit(url)
        host, port = (p.hostname or "").rstrip("."), p.port
    except ValueError:
        return None
    if p.scheme.lower() not in ("http", "https") or port or p.username or host not in hosts:
        return None
    if p.path in ("", "/"):
        return "home"
    if PRICING_PATH.fullmatch(p.path):
        return "pricing"
    if SIGNUP_PATH.fullmatch(p.path):
        return "sign-up"
    return None


def swap_links(text, live, label=AFFILIATE_LABEL):
    """Each live product's home, pricing and sign-up URLs in text become its affiliate link, exactly as written in the
    Sheet (HighLevel bans redirects and short links), with the label right after the link. URLs in HTML or JSX
    attributes, and cited sources ("URL (read 2026-10-01)", the workbook's "where the fact comes from"), stay.
    Returns (text, count)."""
    count = 0

    def rep(mt):
        nonlocal count
        if mt.group("attr") is not None:
            return mt.group(0)
        url, tail = mt.group("md") or mt.group("auto") or mt.group("bare"), ""
        if mt.group("bare"):
            kept = url.rstrip(".,;:!?*_~")
            url, tail = kept, url[len(kept):]
        a = next((a for a in live if link_kind(url, a.hosts)), None)
        if not a or CITED.match(text, mt.end()):  # a cited source keeps the exact page it cites
            return mt.group(0)
        count += 1
        if mt.group("md"):
            return mt.group("pre") + a.link + mt.group("post") + label
        if mt.group("auto"):
            return "<" + a.link + ">" + label
        line = text[text.rfind("\n", 0, mt.start()) + 1:mt.start()]
        if CMD_BEFORE.search(line):  # an argument to curl or wget written into a sentence
            count -= 1
            return mt.group(0)
        inside_text = line.endswith("[") and text[mt.end() - len(tail):].startswith(tail + "]")
        reference = re.fullmatch(r"\s{0,3}\[[^\]]+\]:\s*", line)  # [id]: url - a label there would become its title
        return a.link + ("" if inside_text or reference else label) + tail

    return LINK_RX.sub(rep, text), count


def _swap_outside_code(line, live, label):
    """One line: swap links, leaving inline code spans, <code> and HTML comments as they are."""
    out, pos, n = [], 0, 0
    for mt in INLINE_CODE.finditer(line):
        new, k = swap_links(line[pos:mt.start()], live, label)
        out += [new, mt.group(0)]
        n, pos = n + k, mt.end()
    new, k = swap_links(line[pos:], live, label)
    return "".join(out) + new, n + k


def affiliate_doc(text, live, md=True, label=AFFILIATE_LABEL, disclosure=AFFILIATE_DISCLOSURE):
    """One doc: swap live links outside code (front matter, fenced, indented and <pre> code, inline code, HTML comments
    and shell-command lines stay exactly as they are), then put the disclosure once, as its own paragraph right before
    the block that holds the first swapped link. Returns (text, swapped); the text is untouched when nothing was swapped."""
    if not live:
        return text, 0
    lines = text.splitlines(keepends=True)
    out, code, n, first, state = [], [], 0, None, None
    for i, line in enumerate(lines):
        body = line.rstrip("\r\n")
        is_code = True
        if state == "front":
            state = None if body.strip() in ("---", "...") else state
        elif isinstance(state, tuple):
            mt = FENCE.match(body)
            if mt and mt.group(1)[0] == state[0] and len(mt.group(1)) >= state[1] and not body[mt.end():].strip():
                state = None
        elif state in ("<!--", "<pre"):
            state = None if ("-->" if state == "<!--" else "</pre>") in body.lower() else state
        elif md and i == 0 and body.strip() == "---":
            state = "front"
        elif md and FENCE.match(body):
            mt = FENCE.match(body)
            state = (mt.group(1)[0], len(mt.group(1)))
        elif (md and INDENTED.match(body) and not LISTY.match(body)) or COMMAND.match(body):
            pass  # indented code or a shell command: left alone
        else:
            is_code = False
            head = body
            for mt in OPENER.finditer(body):  # the first comment or <pre> this line leaves open: code from there on
                close = "-->" if mt.group(0) == "<!--" else "</pre>"
                if close not in body[mt.end():].lower():
                    head, state = body[:mt.start()], ("<!--" if close == "-->" else "<pre")
                    break
            new, k = _swap_outside_code(head, live, label)
            if k:
                line = new + line[len(head):]
                n += k
                first = i if first is None else first
        out.append(line)
        code.append(is_code)
    if not n:
        return text, 0
    j = first
    while j > 0 and out[j - 1].strip() and not code[j - 1] and not out[j - 1].lstrip().startswith("#"):
        j -= 1
    eol = "\r\n" if lines[0].endswith("\r\n") else "\n"
    out[j:j] = [("> " if md else "") + disclosure + eol, eol]
    return "".join(out), n


def affiliate_docs(root, live, label=AFFILIATE_LABEL, disclosure=AFFILIATE_DISCLOSURE):
    """Every doc under root (Markdown and text files; code files are never opened). Returns counts."""
    stats = {"links": 0, "docs": 0, "disclosures": 0}
    if not live:
        return stats
    for base, dirs, files in os.walk(root):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(base, f)
            if not f.lower().endswith(DOC_EXT) or os.path.islink(p):
                continue
            data = _read(p)
            if not is_text(data):
                continue
            new, n = affiliate_doc(data.decode("utf-8"), live, md=not f.lower().endswith(".txt"), label=label,
                                   disclosure=disclosure)
            if n:
                with open(p, "wb") as fh:
                    fh.write(new.encode("utf-8"))
                stats["links"] += n
                stats["docs"] += 1
                stats["disclosures"] += 1
    return stats


def _cell_swap(text, live, label):
    """A workbook text: line by line like a doc; JSON-looking cells, shell-command lines and inline code stay."""
    if text.lstrip().startswith(("{", "[")) or re.search(r'"[\w$.-]+"\s*:', text):
        return text, 0
    out, n = [], 0
    for line in text.splitlines(keepends=True):
        body = line.rstrip("\r\n")
        if COMMAND.match(body):
            out.append(line)
            continue
        new, k = _swap_outside_code(body, live, label)
        out.append(new + line[len(body):])
        n += k
    return "".join(out), n


def _swap_t(xml, live, label):
    n = 0

    def node(mt):
        nonlocal n
        plain = html.unescape(mt.group(2))
        new, k = _cell_swap(plain, live, label)
        if not k:
            return mt.group(0)
        n += k
        return mt.group(1) + _xml_escape(new) + mt.group(3)

    return T_NODE.sub(node, xml), n


def _append_t(xml, suffix):
    """suffix added to the last text run of a cell or shared string; unchanged when it has no text."""
    last = None
    for last in T_NODE.finditer(xml):
        pass
    if not last:
        return xml, False
    return xml[:last.end(2)] + _xml_escape(suffix) + xml[last.end(2):], True


def _attr(tag, name):
    mt = re.search(r"\s" + re.escape(name) + r'="([^"]*)"', tag)
    return html.unescape(mt.group(1)) if mt else None


def affiliate_xlsx(path, live, label=AFFILIATE_LABEL, disclosure=AFFILIATE_DISCLOSURE):
    """The workbook: live links swapped in worksheet cells (inline and shared strings) and in cell hyperlinks (a cell
    whose hyperlink changed gets the label in its text); in each sheet the first cell holding a swapped link also gets
    the disclosure, in the same cell. Same sheets, rows and columns. The file is rewritten only when something was
    swapped, so a build with no live link leaves it byte-identical. Returns counts."""
    stats = {"cell_links": 0, "hyperlinks": 0, "disclosures": 0}
    if not live:
        return stats
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        data = {i.filename: z.read(i.filename) for i in infos}
    text = {k: v.decode("utf-8") for k, v in data.items() if k.endswith((".xml", ".rels"))}
    ss_name, items, gaps, ss_hit, ss_done = "xl/sharedStrings.xml", [], [], set(), set()
    if ss_name in text:
        pos = 0
        for k, mt in enumerate(SI_ITEM.finditer(text[ss_name])):
            gaps.append(text[ss_name][pos:mt.start()])
            new, c = _swap_t(mt.group(0), live, label)
            items.append(new)
            pos = mt.end()
            if c:
                ss_hit.add(k)
                stats["cell_links"] += c
        gaps.append(text[ss_name][pos:])
    changed = set()
    for name in sorted(n for n in text if SHEET_PART.match(n)):
        rels = name.replace("xl/worksheets/", "xl/worksheets/_rels/") + ".rels"
        swapped_ids = set()
        if rels in text:
            def rel(mt):
                tag, target = mt.group(0), _attr(mt.group(0), "Target")
                if not target or not (_attr(tag, "Type") or "").endswith("/hyperlink"):
                    return tag
                a = next((a for a in live if link_kind(target, a.hosts)), None)
                if not a:
                    return tag
                swapped_ids.add(_attr(tag, "Id"))
                stats["hyperlinks"] += 1
                return re.sub(r'(\sTarget=")[^"]*(")', lambda m2: m2.group(1) + _xml_escape(a.link, True) + m2.group(2),
                              tag, count=1)
            new = re.sub(r"<Relationship\b[^>]*>", rel, text[rels])
            if new != text[rels]:
                text[rels] = new
                changed.add(rels)
        linked = {_attr(t, "ref") for t in re.findall(r"<hyperlink\b[^>]*>", text[name]) if _attr(t, "r:id") in swapped_ids}
        noted = False

        def cell(mt):
            nonlocal noted
            c = mt.group(0)
            open_tag = c[:c.find(">") + 1]
            ref, kind = _attr(open_tag, "r"), _attr(open_tag, "t")
            if kind == "inlineStr":
                c, k = _swap_t(c, live, label)
                stats["cell_links"] += k
                if ref in linked and not k:
                    c, k = _append_t(c, label)
                if k and not noted:
                    c, noted = _append_t(c, " " + disclosure)
                    stats["disclosures"] += noted
                return c
            v = re.search(r"<v>(\d+)</v>", c)
            if kind != "s" or not v or int(v.group(1)) >= len(items):
                return c
            k = int(v.group(1))
            if ref in linked and k not in ss_hit and ("label", k) not in ss_done:
                items[k], ok = _append_t(items[k], label)
                ss_done.add(("label", k))
                if ok:
                    ss_hit.add(k)
            if k in ss_hit and not noted:
                if ("note", k) not in ss_done:
                    items[k], ok = _append_t(items[k], " " + disclosure)
                    ss_done.add(("note", k))
                    stats["disclosures"] += ok
                noted = True
            return c

        new = CELL.sub(cell, text[name])
        if new != text[name]:
            text[name] = new
            changed.add(name)
    if items and (ss_hit or ss_done):
        text[ss_name] = "".join(g + s for g, s in zip(gaps, items + [""]))
        changed.add(ss_name)
    if not changed:
        return stats
    tmp = path + ".affiliate"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in infos:
            zout.writestr(info, text[info.filename].encode("utf-8") if info.filename in changed else data[info.filename])
    os.replace(tmp, path)
    return stats


def affiliate_census(base, live, disclosure=AFFILIATE_DISCLOSURE):
    """Where each live link ended up, and proof that every doc and workbook carrying one also carries the disclosure
    (SystemExit when one doesn't). Returns {tool: {"docs": n, "workbooks": n}}."""
    per, bare = {a.tool: {"docs": 0, "workbooks": 0} for a in live}, []
    if not live:
        return per
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(root, f)
            if os.path.islink(p):
                continue
            if f.lower().endswith(DOC_EXT):
                texts, key = [_read(p).decode("utf-8", "replace")], "docs"
            elif f.endswith(".xlsx"):
                with zipfile.ZipFile(p) as z:
                    texts = [html.unescape(z.read(n).decode("utf-8", "replace")) for n in z.namelist()
                             if n.endswith((".xml", ".rels"))]
                key = "workbooks"
            else:
                continue
            hits = [a for a in live if any(a.link in t for t in texts)]
            for a in hits:
                per[a.tool][key] += 1
            if hits and not any(disclosure in t for t in texts):
                bare.append(os.path.relpath(p, base))
    if bare:
        raise SystemExit(f"a live affiliate link without the disclosure in {len(bare)} file(s), e.g. {bare[:3]}; "
                         "the old edition was kept")
    return per


def affiliate_summary(aff):
    """One line for the build output: what the Sheet said and where the links went (tool names and counts only)."""
    used = "; ".join(f"{t}: {c['docs']} doc(s), {c['workbooks']} workbook(s)" for t, c in aff.get("per_tool", {}).items())
    skipped = [f"{t} (no product site in its program URLs)" for t in aff.get("no_product_site", [])] + \
              [f"{t} (no link)" for t in aff.get("live_without_link", [])]
    return (f"affiliate links: Sheet read ({aff['rows']} rows, {aff['live_rows']} live); "
            + (f"swapped {aff['docs']['links']} in {aff['docs']['docs']} doc(s) and {aff['workbook']['cell_links']} "
               f"cell link(s) + {aff['workbook']['hyperlinks']} hyperlink(s) in the workbook; {used}; disclosure in "
               f"{aff['docs']['disclosures'] + aff['workbook']['disclosures']} place(s)" if aff.get("live")
               else "no live row with a link: nothing swapped, no disclosure")
            + (f"; WARNING live but not used: {', '.join(skipped)}" if skipped else ""))


# ---------------------------------------------------------------------------------------------------------- leak check
class VaultIndex:
    """SHA-256 of each secret (raw, JSON-, XML- and URL-escaped), found by an 8-character anchor then a hashed window."""

    def __init__(self, values, refs=None):
        self.by_anchor = {}
        for i, v in enumerate(values):
            ref = refs[i] if refs else f"value {i + 1}"
            for form in {v, json.dumps(v)[1:-1], _xml_escape(v, True), urllib.parse.quote(v, safe="")}:
                if len(form) >= 8:
                    self.by_anchor.setdefault(form[:8], set()).add((len(form), hashlib.sha256(form.encode()).hexdigest(), ref))
        self.count = len(values)
        self.rx = re.compile("|".join(map(re.escape, self.by_anchor))) if self.by_anchor else None

    def find(self, text):
        hits = set()
        if self.rx:
            for mt in self.rx.finditer(text):
                for n, digest, ref in self.by_anchor[mt.group(0)]:
                    if hashlib.sha256(text[mt.start():mt.start() + n].encode()).hexdigest() == digest:
                        hits.add(ref)
        return hits


def _blank(text, spans):
    if not spans:
        return text
    out, last = [], 0
    for a, b in sorted(spans):
        if a >= last:
            out += [text[last:a], " " * (b - a)]
            last = b
    return "".join(out) + text[last:]


def scan_text(text, m, vault, shapes=True, personal=True):
    """(kind, detail) pairs for one text. Each span is reported once, by its most specific kind; details are labels.
    personal=False skips the public-mail check (LICENSE-style credit files keep their authors' addresses)."""
    out, spans = set(), []
    if personal:
        for mt in EMAIL.finditer(text):
            e = mt.group(0).lower()
            if (PUBLIC_MAIL.search(mt.group(1)) and e.split("@", 1)[0] not in PLACEHOLDER_LOCALS
                    and e not in m.code_of):
                out.add(("personal email", "public mail domain"))
    for rx in (GFILE_PATH, GFILE_QUERY):
        if any(mt.group(2) != GFILE_LABEL for mt in rx.finditer(text)):
            out.add(("google file id", "in a link"))
    if PARTNER_RX.search(text):
        out.add(("partner github handle", "a partner's GitHub username"))
    for rx, kind in ((m.gfile_rx, "google file id"), (m.owner_rx, "owner account id")):
        if rx:
            for mt in rx.finditer(text):
                out.add((kind, "bare" if kind == "google file id" else m.owner_label[mt.group(0).lower()]))
    for mt in EMAIL.finditer(text):
        e, dom = mt.group(0).lower(), mt.group(1)
        c = m.code_of.get(e) or next((x.code for x in [m.domain_client(lab) for lab in dom.split(".")[:-1]] if x), None)
        if c:
            out.add(("client email" if e in m.code_of else "client domain", "Client " + c))
            spans.append(mt.span())
    text2 = _blank(text, spans)
    for mt in HOST.finditer(text2):
        c = next((x for x in map(m.domain_client, mt.group(1).split(".")[:-1]) if x), None)
        if c:
            out.add(("client domain", "Client " + c.code))
            spans.append(mt.span(1))
    text2 = _blank(text, spans)
    for rx, kind, key in ((m.phone_rx, "client phone", lambda v: re.sub(r"\D", "", v)[-10:]), (m.id_rx, "client id", str)):
        if rx:
            for mt in rx.finditer(text2):
                out.add((kind, "Client " + m.code_of[key(mt.group(0))]))
                spans.append(mt.span())
    text2 = _blank(text, spans)
    if m.name_rx:
        for mt in m.name_rx.finditer(text2):
            out.add(("client name", "Client " + m.client_of(mt)[0].code))
    if shapes:
        blobs = [mt.span() for mt in BLOB.finditer(text)]  # embedded base64 (fonts, images): no key is that long
        for name, rx in SHAPES_RX:
            if any(not any(a <= mt.start() and mt.end() <= b for a, b in blobs) for mt in rx.finditer(text)):
                out.add(("secret shape", name))
    for ref in vault.find(text):
        out.add(("1Password value", ref))
    return out


def _scan_bytes(data, m, vault):
    views = [data.decode("latin-1")]
    if len(data) > 1:
        views.append(data.decode("utf-16-le", "ignore"))
    out = set()
    for v in views:
        out |= scan_text(v, m, vault)
    return out


def leak_check(base, m, vault):
    findings = set()
    for root, dirs, files in os.walk(base):
        dirs.sort()
        for f in sorted(files):
            path = os.path.join(root, f)
            rel = os.path.relpath(path, base)
            for kind, detail in scan_text(rel, m, vault, shapes=False):
                findings.add((rel, kind + " in path", detail))
            data = _read(path)
            if data[:4] == b"PK\x03\x04":
                try:
                    z = zipfile.ZipFile(io.BytesIO(data))
                except zipfile.BadZipFile:
                    z = None
                if z:
                    for name in z.namelist():
                        part = z.read(name)
                        for kind, detail in scan_text(name, m, vault, shapes=False):
                            findings.add((f"{rel}!{name}", kind + " in path", detail))
                        if name.endswith((".xml", ".rels", ".vml")) and is_text(part):
                            hits = scan_text(xml_text(part.decode("utf-8")), m, vault)
                        elif is_text(part):
                            hits = scan_text(part.decode("utf-8"), m, vault)
                        else:
                            hits = _scan_bytes(part, m, vault)
                        findings |= {(f"{rel}!{name}", k, d) for k, d in hits}
                    continue
            hits = scan_text(data.decode("utf-8"), m, vault, personal=not CREDIT_FILE.match(f)) if is_text(data) \
                else _scan_bytes(data, m, vault)
            findings |= {(rel, k, d) for k, d in hits}
    return sorted(findings)


def extra_scans(base):
    """The publish agent's two scans, on every build and check (Director, 2026-10-02): access links (anything that lets
    someone in without a key) and key-shaped strings (secret_scan.py, public vendor tokens allowlisted by SHA-256).
    Both print counts only. Returns (summary, failure lines)."""
    fails, summary = [], {}
    with tempfile.TemporaryDirectory() as d:
        r = subprocess.run([sys.executable, f"{SCRIPTS}/access_link_scan.py", base, f"{d}/access.json"],
                           capture_output=True, text=True, timeout=600)
        if r.returncode not in (0, 3) or not os.path.exists(f"{d}/access.json"):
            fails.append(f"access-link scan did not finish (exit {r.returncode})")
        else:
            per = json.load(open(f"{d}/access.json"))["per_file"]
            hits = {w: {k: v for k, v in c.items() if not k.startswith("info_")} for w, c in per.items()}
            hits = {w: c for w, c in hits.items() if c}
            summary["access_link_files"] = len(hits)
            fails += [f"ACCESS LINK | {w} | {json.dumps(c)}" for w, c in sorted(hits.items())]
        paths = []
        for root, dirs, files in os.walk(base):
            dirs.sort()
            paths += [os.path.relpath(os.path.join(root, f), base) for f in sorted(files)]
        with open(f"{d}/paths", "w") as fh:
            fh.write("\0".join(paths))
        r = subprocess.run([sys.executable, f"{SCRIPTS}/secret_scan.py", base, f"{d}/secrets.json", "--paths-file",
                            f"{d}/paths"], capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or not os.path.exists(f"{d}/secrets.json"):
            fails.append(f"secret scan did not finish (exit {r.returncode})")
        else:
            res = json.load(open(f"{d}/secrets.json"))
            summary["secret_scan_files"], summary["secret_scan_hit_files"] = res["scanned"], len(res["hit_files"])
            summary["secret_scan_allowlisted"] = sum(v for c in res["files"].values() for k, v in c.items()
                                                     if k.endswith(":allowlisted"))
            fails += [f"SECRET SHAPE | {p} | {json.dumps(c)}" for p, c in sorted(res["hit_files"].items())]
    summary["result"] = "PASS" if not fails else "FAIL"
    return summary, fails


# ---------------------------------------------------------------------------------------------------------- 1Password
def read_vault():
    """Secrets of the Connectors vault through the connectors-sync robot: concealed fields and the secret keys inside
    document items. Returns (values, refs); refs name the item and field, never the value. Fails closed."""
    try:
        tok = subprocess.run(["/usr/bin/security", "find-generic-password", "-a", "connectors-sync", "-s",
                              "op-service-account-connectors-sync", "-w"], capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        raise SystemExit("1Password: reading the robot token from the Keychain ran over 30 s and was stopped")
    if tok.returncode != 0 or not tok.stdout.strip():
        raise SystemExit("1Password: the connectors-sync robot token is not in the Keychain")
    token = tok.stdout.strip()
    del tok
    robot_env = _robot_env()
    if robot_env is not None:  # one private HOME and one shared op daemon (agents-home ad0158c), so op doesn't stall
        ctx = robot_env(token)
    else:  # agents-home without the helper: the robot token alone, the desktop-app integration off (as before)
        ctx = contextlib.nullcontext(dict(os.environ, OP_SERVICE_ACCOUNT_TOKEN=token, OP_BIOMETRIC_UNLOCK_ENABLED="false"))
    del token
    with ctx as env:
        return _read_vault_items(env)


def _robot_env():
    """op_items.robot_env from ~/.agents/tools/connectors (spp-p49a, spp-p49b), or None when that copy lacks it."""
    sys.path.insert(0, f"{H}/.agents/tools/connectors")
    try:
        from op_items import robot_env
    except ImportError:
        return None
    return robot_env


def _read_vault_items(env):
    """The vault reads themselves, with op's environment from read_vault."""

    def run(*a):  # L-010: subprocess.run's timeout kills a hung op (Go ignores SIGALRM, so no perl alarm)
        try:
            return subprocess.run(["op", *a, "--vault", VAULT], capture_output=True, env=env, timeout=OP_TIMEOUT)
        except subprocess.TimeoutExpired:
            raise SystemExit(f"1Password: op {a[0]} {a[1]} ran over {OP_TIMEOUT} s and was stopped (L-010); nothing written")
    lst = run("item", "list", "--format", "json")
    if lst.returncode != 0:
        raise SystemExit("1Password read failed (run outside the Claude Code sandbox): " + lst.stderr.decode()[:160])
    values, refs, extra = [], [], {"documents_not_json": 0, "location_ids": {}}
    secret_key = re.compile(r"(?i)(private_key(_id)?|client_secret|secret|password|token|refresh_token|api_?key|credential)$")
    for it in json.loads(lst.stdout):
        title = it.get("title", "")
        if it.get("category") == "DOCUMENT":
            doc = run("document", "get", it["id"])
            try:
                obj = json.loads(doc.stdout)
            except ValueError:
                extra["documents_not_json"] += 1
                continue
            for path, v in _walk(obj):
                if isinstance(v, str) and len(v) >= 16 and secret_key.search(path.split(".")[-1]):
                    values.append(v)
                    refs.append(f"{title} / {path.split('.')[-1]}")
                    for line in v.splitlines():
                        if len(line) >= 40 and "PRIVATE KEY" not in line:
                            values.append(line)
                            refs.append(f"{title} / {path.split('.')[-1]} line")
            continue
        got = run("item", "get", it["id"], "--format", "json")
        if got.returncode != 0:
            raise SystemExit(f"1Password: could not read item {it['id']}")
        for f in json.loads(got.stdout).get("fields", []):
            v = f.get("value")
            if not isinstance(v, str) or not v:
                continue
            if (f.get("type") == "CONCEALED" or f.get("purpose") == "PASSWORD") and len(v) >= 8:
                values.append(v)
                refs.append(f"{title} / {f.get('label')}")
            elif re.fullmatch(r"(?i)location_?id", f.get("label") or "") and GHL_ID.fullmatch(v):
                extra["location_ids"][v] = title
    return values, refs, extra


def _walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from _walk(v, f"{path}.{k}")
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from _walk(v, f"{path}[{i}]")
    else:
        yield path, o


# ---------------------------------------------------------------------------------------------------------- build
def workbook_units(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)
    for ws in wb.worksheets:
        yield f"workbook {ws.title}", ws.title
        for row in ws.iter_rows(values_only=True):
            for v in row:
                if isinstance(v, str):
                    yield f"workbook {ws.title}", v
    wb.close()


def repo_units(root, paths=None, head=False):
    if head:
        tar = subprocess.run(["git", "-C", root, "archive", "--format=tar", "HEAD", "--"] + list(paths or []),
                             capture_output=True, check=True).stdout
        with tarfile.open(fileobj=io.BytesIO(tar)) as t:
            for mem in t.getmembers():
                if mem.isfile():
                    data = t.extractfile(mem).read()
                    if is_text(data):
                        for para in re.split(r"\n\s*\n", data.decode("utf-8")):
                            yield mem.name, para
        return
    files = subprocess.run(["git", "-C", root, "ls-files", "-z"], capture_output=True, text=True).stdout.split("\0")
    for f in files:
        p = os.path.join(root, f)
        if not f or os.path.islink(p) or not os.path.isfile(p) or f.endswith((".env",)) or os.path.basename(f).startswith(".env"):
            continue
        data = _read(p)
        if is_text(data):
            for para in re.split(r"\n\s*\n", data.decode("utf-8")):
                yield f, para


def make_mapping(location_ids=None):
    m = Mapping(parse_clients(_read(CLIENTS, "r")))
    for loc, title in (location_ids or {}).items():  # 1Password items named after a client hold its GHL location
        mt = m.name_rx.search(title) if m.name_rx else None
        if mt and loc not in m.id_label:
            m.client_of(mt)[0].ids["ghl"].append(loc)
    m._id_index()
    units = list(workbook_units(BOOK))
    for _, root, paths in SOURCES:
        units += list(repo_units(root, paths, head=True))
    for _, rel, root, path in RULE_FILES:  # G19: the rule files' IDs join their clients too
        units += list(repo_units(root, [path], head=True))
    units += list(repo_units(REPO))
    harvested = m.harvest(units)
    harvested.update(m.harvest_extra(units))
    return m, harvested


README = """# Student edition: Alex's AI setup

A teaching copy of the code behind the connectors workbook (connectors-student-edition.xlsx, shipped beside this
folder). Built {built} by student_edition.py from the private repos below. It has no git history, no keys and no
.env files. Every client business is replaced by a label: Client A, Client B ... in text, client-a.example for their
websites, contact@client-a.example for their emails, CLIENT_A_LOCATION_ID (and similar) for their account IDs.
Personal addresses read person-N@example.com, Google file links read GOOGLE_FILE_ID, Alex's GHL developer ID reads
OWNER_GHL_DEVELOPER_ID, and partners' GitHub usernames read PARTNER_GITHUB_USER. Alex's own accounts and the tools'
own names are real. Keys come from your own 1Password at run time.

| Folder | Put it at | From |
|---|---|---|
{rows}

**GHL Command's builder (ghl-command-universal):** Running GHL Command needs your own GHL Command licence and sign-in;
not part of the student build. Its code ships for reading only, and Rebuild from zero checks 10.3 and 10.5 are partner
route only.

**The Director's rule files:** alex-director/AGENTS.md reads ~/Documents/One-Shot-Builder/RULES.md (section 10, before
spawning workers), ~/STACK.md and ./CONCEPTS.md, and the Director skill files lessons in
~/Documents/One-Shot-Builder/docs/LESSONS.md. They ship in one-shot-builder/ and alex-director/ as scrubbed copies,
with alex-director/scripts/controller-write-guard.py, the guard the Director's gates.md and RULES.md section 13 run
before any shared or live write, and an empty alex-director/mission-graphs/ for your mission graphs. After you copy
alex-director to ~/Alex-Director, make it its own git repo (cd ~/Alex-Director && git init && git add -A && git commit
-m 'Director starter'; it has no remote) and run ln -s ~/Alex-Director/STACK.md ~/STACK.md. Its .gitignore keeps the
ledger's .bak and .lock files and the guard's .runtime/ out of git; STANDING_AUTHORIZATIONS.md and docs/solutions/
start empty ("none yet"), and the blank ledger block has SUPERVISING_DIRECTOR_THREAD_ID: NONE.{stand_ins}

Start with master-connector-repo/AGENTS.md, then the workbook's "Rebuild from zero" tab.
"""
HOME_AT = {"agents-home": "~/.agents", "master-connector-repo": "~/Projects/master-connector-repo",
           "ghl-command-universal": "~/Development/ghl-command-universal",
           "increase-roas-oauth-gateway": "~/Development/increase-roas-oauth-gateway",
           "alex-director": ("~/Alex-Director (blank starter: empty ledger, graph template, empty mission-graphs/, role card, "
                             "STACK.md, CONCEPTS.md, write guard)"),
           "one-shot-builder": "~/Documents/One-Shot-Builder (RULES.md, docs/LESSONS.md, checklists/ONE_SHOT_READINESS.md only)"}


def build(args):
    live, aff = read_affiliates()  # first: an unreadable Sheet stops the build before anything is touched
    values, refs, extra = read_vault()
    vault = VaultIndex(values, refs)
    del values
    m, harvested = make_mapping(extra["location_ids"])
    parent = os.path.dirname(OUT)
    tmp = tempfile.mkdtemp(prefix=".student-edition-", dir=parent)
    try:
        cells = scrub_xlsx(BOOK, f"{tmp}/{BOOK_OUT}", m)
        aff["workbook"] = affiliate_xlsx(f"{tmp}/{BOOK_OUT}", live)
        import openpyxl
        src_wb, new_wb = openpyxl.load_workbook(BOOK, read_only=True), openpyxl.load_workbook(f"{tmp}/{BOOK_OUT}", read_only=True)
        shape_ok = [(ws.max_row, ws.max_column) for ws in src_wb.worksheets] == [(ws.max_row, ws.max_column) for ws in new_wb.worksheets]
        src_wb.close(); new_wb.close()
        if not shape_ok:
            raise SystemExit("workbook shape changed (sheet count, rows or columns)")
        stats = {}
        for name, root, paths in SOURCES:
            stats[name] = export_tree(root, paths, f"{tmp}/repo/{name}", m)
        stats["alex-director"] = director_starter(DIRECTOR_HOME, f"{tmp}/repo/alex-director", m)
        shipped, commits = rule_files(f"{tmp}/repo", m, vault)
        for folder in commits:
            mine = {k.split("/", 1)[1]: v for k, v in shipped.items() if k.startswith(folder + "/")}
            if folder == "alex-director":
                stats[folder]["files"] += len(mine)
                stats[folder]["rule_files"] = mine
            else:
                stats[folder] = {"commit": commits[folder], "files": len(mine), "rule_files": mine}
        add_repo_files(tmp)
        noted = builder_note(tmp)
        built = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
        rows = "\n".join(f"| {n} | {HOME_AT[n]} | {n} @ {stats[n]['commit']} |" for n in HOME_AT)
        stand = sorted(k for k, v in shipped.items() if "stand-in" in v.split(":")[0])
        stand_ins = ("\nStand-ins (the real file isn't shipped): " + ", ".join(stand) + ".") if stand else ""
        _write(f"{tmp}/repo/README.md", README.format(built=built, rows=rows, stand_ins=stand_ins))
        aff["docs"] = affiliate_docs(f"{tmp}/repo", live)
        aff["per_tool"] = affiliate_census(tmp, live)
        aff.update(source="Alex's affiliate Sheet, Programs tab (knowledge/affiliate-links.md; its file ID stays out: the "
                          "leak check counts Google file IDs)", read_at=built, disclosure_shown=bool(
            aff["docs"]["disclosures"] or aff["workbook"]["disclosures"]),
            live=[{"rank": a.rank, "tool": a.tool, "link": a.link, "hosts": sorted(a.hosts)} for a in live])
        _write(f"{tmp}/.gitignore", "# generated by student_edition.py; never commit the edition to the private repo\n*\n")
        findings = leak_check(tmp, m, vault)
        scans, scan_fails = extra_scans(tmp)
        report = {"built": built, "workbook_master_sha256": hashlib.sha256(_read(BOOK)).hexdigest(),
                  "workbook_xml_parts_changed": cells, "sources": stats, "clients": len(m.clients),
                  "aliases": sum(len(c.aliases) for c in m.clients), "harvested": harvested,
                  "personal_addresses_swapped": len(m.person_label), "rule_files": shipped,
                  "builder_readme_note": noted, "affiliate_links": aff,
                  "vault_secrets_checked": vault.count, "vault_documents_not_json": extra["documents_not_json"],
                  "leak_check": {"findings": len(findings), "result": "PASS" if not findings else "FAIL"},
                  "extra_scans": scans}
        if findings or scan_fails:
            for f in findings:
                print("LEAK", *f, sep=" | ")
            for f in scan_fails:
                print(f)
            raise SystemExit(f"leak check FAILED: {len(findings)} findings, {len(scan_fails)} scan hits; "
                             "the old edition was kept")
        _write(f"{tmp}/build.json", json.dumps(report, indent=1) + "\n")
        if os.path.exists(OUT):
            if not os.path.exists(f"{OUT}/build.json"):
                raise SystemExit(f"{OUT} exists but was not made by this script; not replacing it")
            shutil.rmtree(OUT)
        os.rename(tmp, OUT)
        tmp = None
        print(json.dumps(report, indent=1))
        print(affiliate_summary(aff))
        print(f"PASS: {OUT}")
    finally:
        if tmp and os.path.exists(tmp):
            shutil.rmtree(tmp)


def check(args):
    values, refs, extra = read_vault()
    vault = VaultIndex(values, refs)
    del values
    m, _ = make_mapping(extra["location_ids"])
    findings = leak_check(OUT, m, vault)
    scans, scan_fails = extra_scans(OUT)
    for f in findings:
        print("LEAK", *f, sep=" | ")
    for f in scan_fails:
        print(f)
    print(f"leak check on {OUT}: {'PASS' if not findings else 'FAIL'} ({len(findings)} findings, {vault.count} vault secrets by hash)")
    print(f"extra scans on {OUT}: {scans['result']} {json.dumps(scans)}")
    return 1 if findings or scan_fails else 0


def selftest(args):
    """Plant one real client name (in a code file, a workbook cell and a file name), one of its IDs, a secret shape,
    a synthetic vault value, a personal Gmail address, a Google Sheet link and Alex's Marketplace developer ID into a
    throwaway copy; the leak check and the two extra scans must report them, and the unplanted copy must be clean.
    Prints labels only. Reads no 1Password item: the real vault check runs in build and check."""
    synthetic = "selftest-" + hashlib.sha256(os.urandom(16)).hexdigest()[:24]
    vault = VaultIndex([synthetic], ["synthetic selftest value"])
    m, _ = make_mapping()
    c = next(c for c in m.clients if c.ids["ghl"])
    name, loc = c.names[0], c.ids["ghl"][0]
    # spp-c4e plants: a personal Gmail address, a Google Sheet link, and the harvested Marketplace developer ID
    gmail = f"plant.{hashlib.sha256(os.urandom(8)).hexdigest()[:8]}@gmail.com"
    gsheet = f"https://docs.google.com/spreadsheets/d/1{hashlib.sha256(os.urandom(16)).hexdigest()[:32]}Plant/edit"
    owner = next(iter(m.owner_label), None)
    with tempfile.TemporaryDirectory() as d:
        copy = f"{d}/edition"
        shutil.copytree(OUT, copy)
        before = leak_check(copy, m, vault)
        _, scan_fails_before = extra_scans(copy)
        with open(f"{copy}/repo/README.md", "a") as f:
            f.write(f"\nplanted: {name} {loc} ghp_{'Ab1' * 12} {synthetic} {gmail} {gsheet} {owner or ''} "
                    f"(`{PARTNER_HANDLES[0]}`)\n")
        _write(f"{copy}/repo/{name.lower().replace(' ', '-')}-notes.md", "x\n")
        book = f"{copy}/{BOOK_OUT}"
        with zipfile.ZipFile(book) as z:
            parts = {i.filename: (i, z.read(i.filename)) for i in z.infolist()}
        info, data = parts["xl/worksheets/sheet1.xml"]
        data = data.decode().replace("<t>", f"<t>{html.escape(name)} ", 1).encode()
        parts["xl/worksheets/sheet1.xml"] = (info, data)
        with zipfile.ZipFile(book, "w", zipfile.ZIP_DEFLATED) as z:
            for i, d2 in parts.values():
                z.writestr(i, d2)
        after = leak_check(copy, m, vault)
        _, scan_fails_after = extra_scans(copy)
    kinds = sorted({(f[0].split("!")[0] if "!" in f[0] else ("repo/<planted file>" if "-notes.md" in f[0] else f[0]), f[1]) for f in after})
    print(f"before planting: {len(before)} findings, {len(scan_fails_before)} scan hits; after: {len(after)} findings "
          f"(client planted: Client {c.code})")
    for k in kinds:
        print("  caught:", *k, sep=" ")
    want = {("repo/README.md", "client name"), ("repo/README.md", "client id"), ("repo/README.md", "secret shape"),
            ("repo/README.md", "1Password value"), ("repo/<planted file>", "client name in path"),
            (BOOK_OUT, "client name"), ("repo/README.md", "personal email"), ("repo/README.md", "google file id"),
            ("repo/README.md", "owner account id"), ("repo/README.md", "partner github handle")}
    missed = want - set(kinds)
    if owner is None:
        missed.add(("harvest", "no Marketplace developer ID found to plant"))
    for kind in ("ACCESS LINK", "SECRET SHAPE"):
        caught = any(f.startswith(f"{kind} | repo/README.md") for f in scan_fails_after)
        print(f"  extra scan {kind.lower()}: planted README {'caught' if caught else 'MISSED'}")
        if not caught:
            missed.add(("extra scan", kind))
    ok = not missed and not before and not scan_fails_before
    print("SELFTEST", "PASS: every plant was caught" if ok else f"FAIL: missed {sorted(missed)}"
          + (f"; {len(before)} findings and {len(scan_fails_before)} scan hits before planting" if before or scan_fails_before else ""))
    return 0 if ok else 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("cmd", choices=["build", "check", "selftest"], nargs="?", default="build")
    a = ap.parse_args()
    sys.exit({"build": build, "check": check, "selftest": selftest}[a.cmd](a) or 0)
