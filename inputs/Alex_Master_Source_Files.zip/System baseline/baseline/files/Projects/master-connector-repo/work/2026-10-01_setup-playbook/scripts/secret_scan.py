#!/usr/bin/env python3
"""mha-h1 secret scan. Never prints a matched value.

usage: secret_scan.py REPO OUT_JSON [--paths-file F]   (default: every uncommitted path, git status -uall)

Scans every regular file (text, plus the text inside zip-format files such as .xlsx/.zip,
recursively) with key-shaped patterns. Writes per-file counts to OUT_JSON and prints a summary
of files with hits (counts only). Values are never written or printed; the triage file records
pattern name, line number, value length and a placeholder flag only.

Copied 2026-10-02 from the Director session's scratchpad (mha-h1/secret_scan.py, 13:18) into this job's scripts/,
where student_edition.py runs it on every build and check (spp-c4e) with --paths-file. One change: ALLOW_SHA256,
vendor tokens that are public by design, matched by the SHA-256 of the exact value (counted as allowlisted, never a hit).
"""
import hashlib, io, json, os, re, subprocess, sys, zipfile

# --- key-shaped patterns (the play's list, plus vendor formats used in this workspace) ---
P = {
    # play list
    "1password_ops":   (r"(?<![A-Za-z0-9_])ops_[A-Za-z0-9+/=_\-]{40,}", "mixed"),
    "sk_dash":         (r"(?<![A-Za-z0-9_\-])sk-[A-Za-z0-9_\-]{20,}", "mixed"),
    "github_token":    (r"(?<![A-Za-z0-9_])gh[pousr]_[A-Za-z0-9]{30,}", "vendor"),
    "github_pat":      (r"(?<![A-Za-z0-9_])github_pat_[A-Za-z0-9_]{40,}", "vendor"),
    "slack_token":     (r"(?<![A-Za-z0-9])xox[abpr]-[A-Za-z0-9\-]{10,}", "digit"),
    "aws_akid":        (r"(?<![A-Za-z0-9])(?:AKIA|ASIA)[0-9A-Z]{16}(?![0-9A-Za-z])", "vendor"),
    "google_api_key":  (r"(?<![A-Za-z0-9_\-])AIza[0-9A-Za-z_\-]{35}(?![0-9A-Za-z_\-])", "vendor"),
    "jwt":             (r"(?<![A-Za-z0-9_\-])eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}", "jwt"),
    "pem_private_key": (r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----", "pem"),
    "bearer":          (r"\bBearer\s+([A-Za-z0-9._~+/=\-]{20,})", "mixed"),
    "named_secret":    (r"(?i)([A-Za-z0-9_\-\.]*(?:api[_\-]?key|apikey|token|secret|passw(?:or)?d|pwd|private[_\-]?key|access[_\-]?key|client[_\-]?secret|auth[_\-]?key)[A-Za-z0-9_\-\.]*)[\"']?\s*[:=]\s*[\"']?([A-Fa-f0-9]{32,}|[A-Za-z0-9+/_\-]{32,}={0,2})(?![A-Za-z0-9+/_\-=])", "named"),
    # extra vendor formats seen in this workspace
    "stripe_like_sk":  (r"(?<![A-Za-z0-9])[sr]k_(?:live|test)_[A-Za-z0-9]{16,}", "vendor"),
    "huggingface":     (r"(?<![A-Za-z0-9_])hf_[A-Za-z0-9]{30,}", "mixed"),
    "tailscale":       (r"(?<![A-Za-z0-9_])tskey-[A-Za-z0-9\-]{20,}", "digit"),
    "ghl_pit":         (r"(?<![A-Za-z0-9_])pit-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", "vendor"),
    "firecrawl":       (r"(?<![A-Za-z0-9_])fc-[0-9a-f]{32}(?![0-9a-f])", "vendor"),
    "apify":           (r"(?<![A-Za-z0-9_])apify_api_[A-Za-z0-9]{20,}", "vendor"),
    "notion":          (r"(?<![A-Za-z0-9_])(?:ntn_|secret_)[A-Za-z0-9]{40,}", "mixed"),
    "composio_ak":     (r"(?<![A-Za-z0-9_])u?ak_[A-Za-z0-9_\-]{16,}", "digit"),
}
RX = {k: re.compile(v[0]) for k, v in P.items()}
# Public by design; the vendored files stay untouched (Director, 2026-10-02).
ALLOW_SHA256 = {
    "2692474e98a6418137139be6c29d4e9ebe3706ec45152cb672b9bdbabf29e316":
        "HeyGen PostHog project token (client-side, public in heygen-com/hyperframes): agents-home skills/media-use/scripts/lib/telemetry.mjs",
}
PLACEHOLDER = re.compile(r"(?i)x{4,}|\*{4,}|\.{3}|your|example|redact|placeholder|dummy|fake|sample|changeme|insert|replace|<|>|0{12,}|1234567890|abcdef0123|test_?token|not_?a_?real")
HASHNAME = re.compile(r"(?i)hash|sha\d*|fingerprint|digest|checksum")


def classes(v):
    return (any(c.isdigit() for c in v), any(c.isupper() for c in v), any(c.islower() for c in v))


def keyshaped(kind, v, name=None):
    """True when v looks like a real credential (not a placeholder or identifier)."""
    if PLACEHOLDER.search(v) or len(set(v)) < 6:
        return False
    d, u, l = classes(v)
    if kind == "vendor" or kind == "pem":
        return True
    if kind == "digit":
        return d
    if kind == "jwt":
        return len(v) > 60
    if kind == "mixed":
        return d and u and l
    if kind == "named":
        if name and HASHNAME.search(name):
            return False  # a labelled hash/fingerprint of a secret is not the secret
        if re.fullmatch(r"[A-Fa-f0-9]+", v):
            return d and any(c.isalpha() for c in v)
        if re.fullmatch(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", v):
            return True  # UUID-shaped API keys (e.g. Exa) assigned to a key/token/secret name
        return d and u and l
    return True


def scan_text(text, counts, triage, where):
    for name, rx in RX.items():
        kind = P[name][1]
        for m in rx.finditer(text):
            if name == "named_secret":
                field, val = m.group(1), m.group(2)
            elif name == "bearer":
                field, val = None, m.group(1)
            else:
                field, val = None, m.group(0)
            ok = keyshaped(kind, val, field)
            line = text.count("\n", 0, m.start()) + 1
            if ok and hashlib.sha256(val.encode()).hexdigest() in ALLOW_SHA256:
                counts[name + ":allowlisted"] = counts.get(name + ":allowlisted", 0) + 1
                continue
            key = name if ok else name + ":ignored_placeholder_or_identifier"
            counts[key] = counts.get(key, 0) + 1
            if ok:
                triage.append({"where": where, "pattern": name, "line": line, "len": len(val),
                               "field_name": field if (field and len(field) < 60) else None})


def scan_bytes(data, counts, triage, where, depth=0):
    if data[:4] == b"PK\x03\x04" and depth < 4:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                counts["_zip_members"] = counts.get("_zip_members", 0) + len(z.namelist())
                for info in z.infolist():
                    if info.is_dir():
                        continue
                    scan_bytes(z.read(info), counts, triage, where + "!" + info.filename, depth + 1)
            return
        except Exception as e:  # corrupt zip: fall through to raw scan
            counts["_zip_error"] = counts.get("_zip_error", 0) + 1
    if b"\x00" in data[:8192]:
        counts["_binary"] = counts.get("_binary", 0) + 1
        text = data.decode("latin-1")
    else:
        text = data.decode("utf-8", errors="replace")
    scan_text(text, counts, triage, where)


def main():
    repo, out = sys.argv[1], sys.argv[2]
    os.chdir(repo)
    if "--paths-file" in sys.argv:
        raw = open(sys.argv[sys.argv.index("--paths-file") + 1], "rb").read().decode()
        paths = [p for p in raw.split("\0") if p]
    else:
        st = subprocess.run(["git", "status", "--porcelain=v1", "-uall", "-z"], capture_output=True, check=True).stdout.decode()
        paths = [e[3:] for e in st.split("\0") if e]
    res, triage, skipped = {}, [], []
    for p in paths:
        if os.path.basename(p) == ".DS_Store":
            skipped.append((p, "DS_Store"))
            continue
        if os.path.islink(p) or not os.path.isfile(p):
            skipped.append((p, "not a regular file"))
            continue
        counts = {}
        scan_bytes(open(p, "rb").read(), counts, triage, p)
        res[p] = counts
    hits = {p: {k: v for k, v in c.items() if not k.startswith("_") and ":ignored" not in k and ":allowlisted" not in k}
            for p, c in res.items()}
    hits = {p: c for p, c in hits.items() if c}
    json.dump({"scanned": len(res), "skipped": skipped, "files": res, "hit_files": hits},
              open(out, "w"), indent=1)
    json.dump(triage, open(out.replace(".json", "-triage.json"), "w"), indent=1)
    ign = {}
    for c in res.values():
        for k, v in c.items():
            if ":ignored" in k:
                ign[k] = ign.get(k, 0) + v
    zips = {p: c.get("_zip_members", 0) for p, c in res.items() if c.get("_zip_members")}
    print(f"scanned={len(res)} skipped={len(skipped)} files_with_hits={len(hits)}")
    print("skipped:", skipped)
    print("zip-format files scanned (members):", zips)
    print("binary files scanned raw:", [p for p, c in res.items() if c.get("_binary")])
    print("ignored as placeholder/identifier (totals by pattern):", ign)
    for p, c in sorted(hits.items()):
        print(f"HIT {p}: {c}")


if __name__ == "__main__":
    main()
