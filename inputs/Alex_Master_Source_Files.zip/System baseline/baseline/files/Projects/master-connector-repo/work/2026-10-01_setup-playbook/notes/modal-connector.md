# modal-connector (play spp-p39a, 2026-10-02, conductor v2.3, Claude agent in session 294b676b)

Owner request (Alex, Director chat): "how do we get this set up correctly" (Modal, workspace alex-13722, Starter). Done
before this play: the Director saved Alex's token in 1Password Connectors as item `ozvkxvoxqgiy3ednp3tkx6rkqe` ("Modal
API token": `username` = token ID, `credential` = secret), hash-verified; Composio has no Modal toolkit.

**Status: VERIFIED on Claude Code** (terminal route, one free read, no key file). Codex: NOT_PROVEN (same script, not run
there). The card-list line in the instruction files is prepared as a patch, **not applied**: that needs Alex's own yes (§6).

## 1. Research (read 2026-10-02; Exa through Composio: search log_ynKM2xRDnFLm, $0.007; contents log_LBm0KQ1LT6EB, log_TJipdukEEACr, log_d8-jo31c--7-)
| Question | Answer | Source |
|---|---|---|
| Install route | `pip install modal` (or `uv add modal`, conda) installs the CLI with the SDK; needs Python 3.10 to 3.14; current 1.5.3 | modal.com/docs/guide/getting-started; pypi.org/project/modal |
| Token without a file | MODAL_TOKEN_ID / MODAL_TOKEN_SECRET env vars outrank the active profile in ~/.modal.toml; `modal token set` writes the file; MODAL_CONFIG_PATH moves the file | modal.com/docs/sdk/py/latest/config |
| Free check | `modal token info`: "Display information about the token that is currently in use" (the docs' own verify step) | getting-started; modal.com/docs/cli/latest/token |
| Who writes ~/.modal.toml | `setup`, `token new`, `token set`, `profile activate`, `config set-environment`, hidden `config set KEY VALUE` | cli/latest/{setup,token,profile,config}; installed source modal/cli/config.py L52-L56, token_flow.py L160, cli/profile.py L31 |
| Other writes or leaks | `curl` caches endpoint tokens in ~/.cache/modal/curl-flash-auth-tokens.json; `config show --no-redact` prints the secret; `skills install/update` writes a skill to .agents/ or .claude/ (`-g` = home) | modal/cli/curl.py L23-L25; cli/latest/config; cli/latest/skills |
| Command parsing | modal's only global options are `--version` and `-h/--help` (flags), so the first two words name the command | modal/cli/entry_point.py L37-L56 |
| Cost | Starter: $30 a month of free compute, 3 seats; compute is billed per second | modal.com/pricing |
| Environments | sub-divisions of a workspace (default `main`; dev/prod typical), each with its own Secrets; chosen per command with `--env` or MODAL_ENVIRONMENT | modal.com/docs/guide/environments |

## 2. Install
`/opt/homebrew/bin/python3.14 -m venv ~/.agents/runtime/modal/venv`, then `pip install --no-cache-dir modal==1.5.3` (outside
the sandbox: inside it pip failed TLS, SSLCertVerificationError OSStatus -26276). Result: modal 1.5.3 on Python 3.14.6,
`~/.agents/runtime/modal/venv/bin/modal`. `runtime/` is gitignored in ~/.agents; nothing in system Python or a project.

## 3. Wrapper and tests (test first)
- `~/.agents/tools/connectors/modal_op.py` (orgo_op.py pattern): Keychain robot token + OP_BIOMETRIC_UNLOCK_ENABLED=false
  -> `op_items.item_id("Modal API token", <Alex's ID as fallback>)` -> `op read` of `username` (must start ak-) and
  `credential` (as-) -> exec of the venv's modal with MODAL_TOKEN_ID, MODAL_TOKEN_SECRET and MODAL_CONFIG_PATH=/dev/null
  in the child environment only. Refused before any 1Password read: the writers in §1, `curl`, `skills install/update`,
  `--token-id/--token-secret`, `--no-redact`; the refusal message never echoes the command line.
- OP_BIOMETRIC_UNLOCK_ENABLED=false is set because the play asked; spp-p33a measured no effect on the macOS prompt.
- `test_modal_op.py`, 8 tests: RED first (8/8 `No module named 'modal_op'`), then GREEN 8/8 on Python 3.14.6 and 3.9.6.
  Mutations, 7/7 caught: config path dropped, fields swapped, modal env built from the op env (robot token leak), command
  line echoed on refusal, `token set` allowed, value printed on a bad shape, biometric flag dropped. test_fresh_vault.py
  23/23 still pass.

## 4. Live proof (2026-10-02T02:24:14Z, Claude Code CLI, outside the sandbox; output redacted in Python)
- `modal_op.py token info`, exit 0: "Using MODAL_TOKEN_ID and MODAL_TOKEN_SECRET environment variables"; Token ak-[redacted];
  Name modal; Workspace alex-13722; User alex-13722; Created 2026-10-01 22:09:35 EDT; Expires 2027-10-01 22:09:35 EDT.
  A control-plane read: no compute, nothing created.
- Negative control: bare `~/.agents/runtime/modal/venv/bin/modal token info` -> "Token missing. Could not authenticate
  client", exit 1.
- After: ~/.modal.toml absent, ~/.cache/modal absent, 0 MODAL_* variables in the shell.

## 5. Card and hosted notes
- ~/.agents a9b9a05 (modal_op.py, test_modal_op.py, tools/cards/modal.md) + a8d07ff (index fits the served cut), with
  the post-commit hook skipped (it runs build_instructions.py apply and cards_to_sheet.py into the workbook). Not pushed.
- Card: 54 lines, 4,657 chars, index 67 chars.
- sync_notes.py by hand (outside the sandbox), twice: 15 cards, server restarted, Composio refresh 200 (02:27:42Z,
  02:29:41Z). `CUSTOM_IR_NOTES_GET_APP_RULES` app=modal returns the local file byte for byte (4,657 chars,
  log_-14iIn-OVV4P); app='' lists modal (log_17V52kkiaqf7).
- Finding: server.py's `describe()` cuts every index line at 70 chars, with 14 cards (1,897 of 1,900 chars) and with 15
  (1,893). 0 of 15 index lines show in full, while the card template says "cut at 100 chars". So for chat apps,
  hazards past char 70 drop out of the always-present description. The modal index now fits in 70 (route, spend, key
  hazard). The other cards are a template/Limits item for the Director.

## 6. Card-list line: prepared, not applied
- Patch: work/2026-10-01_setup-playbook/candidates/modal-card-list.patch (sha256 07387e950bd8; `git apply --check` OK on
  ~/.agents af3b811; a9b9a05/a8d07ff don't touch instructions/). It adds one item to shared.md L16:
  `` `firecrawl` (scrape, crawl), `modal` (cloud compute), `web-search` ``.
- Dry run (`AGENTS_INSTR=<temp copy> build_instructions.py plan`, read-only): 2 files would change, ~/.codex/AGENTS.md
  and ~/.claude/CLAUDE.md, the App rules line only. Live files match the sources today (plan: "no changes").
- Why not applied: the rebuild rewrites ~/.claude/CLAUDE.md and ~/.codex/AGENTS.md. The mission header makes changes to
  an AI's own instructions Alex's, and Firecrawl's card-list line went live only on his own "Yes, apply the app rules."
  (system/CHANGELOG.md, 18:25 entry). A request relayed by another agent can't stand in for that.
- Apply on Alex's yes: lock line; snapshot the live CLAUDE.md and AGENTS.md; `git -C ~/.agents apply <patch>`; commit
  with the hook skipped; `python3 ~/.agents/tools/unify/build_instructions.py apply`; CHANGELOG line.
- Until then agents still find the card: the local file, the hosted tool (app=modal) and the hosted card list.

## 7. Not done here, for the Director
1. The card-list line (§6): Alex's yes.
2. Codex: same script and robot, not run there. One test for parity-recheck: `codex exec "Run
   ~/.agents/tools/connectors/modal_op.py token info and report only the Workspace line"`. Codex's sandbox may block op's
   TLS the way Claude Code's does.
3. Spend is gated by the card only. The wrapper runs `run`, `deploy`, `serve` and `shell` when asked, and the Claude
   Code and Codex guard hooks match Composio calls, not `modal_op.py`. Candidate for the queued guard-hook play.
4. The token expires 2027-10-01 22:09 EDT. That depends on Alex remembering, so it's queued as a To do row.
5. Not pushed: ~/.agents a9b9a05 + a8d07ff (housekeeping pushes after its scan). Tool cards tab: cards_to_sheet.py not
   run (hook skipped), queued in workbook-updates.md.
