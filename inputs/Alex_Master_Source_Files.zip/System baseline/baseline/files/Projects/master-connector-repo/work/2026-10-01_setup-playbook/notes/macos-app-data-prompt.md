# macOS "claude would like to access data from other apps": decision and evidence

Director research, 2026-10-02 (session 294b676b). Trigger: Alex reported the prompt keeps coming back after he clicked Allow
several times (screenshot in the Director chat, 2026-10-02 ~01:00Z).

## Decision
1. Agents never read, list, grep, hash or copy anything under `~/Library/Containers` or `~/Library/Group Containers`
   (1Password's database, the ChatGPT/Codex app containers, any other app's private data). They use the app's own CLI or
   API instead (`op` with the robot token, `codex`, `composio`). A step that truly needs such a read is skipped and reported
   NOT_PROVEN. Broadcast to every running agent and the Conductor at 00:57Z.
2. Enforce it in the guard hook (Claude Code + Codex): deny tool calls whose paths fall under those folders. Prose rules
   are not enforcement (spp-p25a research, notes/app-rules-research-hooks.csv).
3. Alex presses "Don't Allow" from now on; nothing in the setup needs that access.
4. Not done: granting Full Disk Access to the `claude` binary. It is the documented workaround, but it grants access to
   everything on the Mac (a security setting, Alex's) and Claude Code's path changes on every update, so it breaks again.
5. Setting `OP_BIOMETRIC_UNLOCK_ENABLED=false` in a script is fine and per 1Password's docs (it turns off the app
   integration); it is not the fix for the macOS prompt (A/B: no change). New scripts may set it; nothing needs a
   retrofit (Director, 2026-10-02, reworded from the 2026-10-01 ~21:25 EDT decision on spp-p33a's evidence). The trigger
   is the 1Password CLI 2.39.0: 3 of the 4 claude-code App Data prompts in the TCC log
   name it. The variable doesn't stop the request (A/B, the same 1 App Data request in every arm). Don't Allow is cached
   (authValue=0) and `op` still reads the vault with the service account, so Don't Allow is the harmless, lasting answer
   until the claude binary's path changes on an update. Finding op's exact probe path is optional and parked.
   Evidence: "Our own evidence" below.

## Why (Exa via Composio, EXA_ANSWER, 2026-10-02)
| Claim | Verdict | Source |
|---|---|---|
| The prompt appears when a process reads another app's sandboxed container data | SUPPORTS decision 1 | talk.macpowerusers.com/t/permissions-issue-with-noteplan3-folder/45333 (2026-04-24); richtong.org/2025/04/11/mac-annoying-would-like-to-access-data-from-other-apps/ (2025-04-12) |
| Allow does not persist for CLI binaries with no app bundle or with version-pinned paths that change on update | SUPPORTS decisions 1-3 | github.com/anthropics/claude-code/issues/36675 ("2.1.80" would like to access data from other apps) |
| Claude Code's TCC grants reset after updates; embedded CLI re-prompts every new session | SUPPORTS decisions 1-3 | github.com/anthropics/claude-code/issues/86715; github.com/anthropics/claude-code/issues/87453; github.com/anthropics/claude-code/issues/36832 (node, every launch) |
| Background (launchd) runs re-prompt and Allow never persists | SUPPORTS decision 2 (block, don't rely on Allow) | github.com/openclaw/wacrawl/issues/61 |
| Workaround: Full Disk Access for the binary at a stable path | QUALIFIES decision 4 (works, but broad access + path changes) | same sources (stable-path FDA advice) |

## Our own evidence for the trigger
- Today's agents read 1Password's Group Container database read-only (notes/onepassword-verify.md, onepassword-vault-scope.md) and app files.
- The terminal CLI was updated 2.1.251 -> 2.1.287 today (notes/skills-cap.md), so any earlier Allow no longer applies to the new path.
- Every new agent is a new process: Allow is asked again.
- TCC log (spp-p33a, `log show` on the TCC subsystem, read 2026-10-01 ~21:15 EDT; no app container was opened): in the 3 h
  before 21:10 EDT there were 4 App Data prompts whose subject is `com.anthropic.claude-code`. The accessing binary was
  Claude Code itself at 18:46:31 (Allow, 18:47:44), and `/opt/homebrew/Caskroom/1password-cli/2.39.0/op` at 18:56:51
  (Allow after 4 s), 20:56:38 and 21:01:32 (both ended Don't Allow, authValue=0). The 18:56:51 prompt matches spp-p33a's
  one `op` run inside the Claude Code sandbox (op's own error is stamped 18:56:56). So `op` started under Claude Code does
  raise this prompt: log-proven for those 3. Which app's container `op` touches is private in the log: NOT_PROVEN.
- A/B (spp-p33a, ~21:16 EDT): one read-only `op item list` (service account) per arm, TCC requests counted by msgID.
  No variable: 1 App Data + 1 Full Disk Access request. `OP_BIOMETRIC_UNLOCK_ENABLED=false` (1Password CLI docs:
  "Toggles the 1Password app integration on or off", developer.1password.com/docs/cli/environment-variables, read
  2026-10-01): the same 1 + 1. No variable again: the same. The variable does not stop the request. No prompt appeared in
  any arm because the 21:01 Don't Allow is cached (authValue=0, authReason=2), and `op` still read the vault.
- Probable, NOT_PROVEN: `op`'s prompt returns when the cached decision no longer matches, for example after a Claude Code
  or 1Password CLI update (both paths carry a version: claude-code/2.1.286/..., 1password-cli/2.39.0). With Don't Allow,
  every script still works.

## Workbook
Decisions and why: new row (this note). Do/Don't: "Never read another app's private folders" with this why (queued to the builder 00:57Z).
