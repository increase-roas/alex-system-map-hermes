# Gap facts (play spp-p20a): sources to close the replication gaps

Mission `mission-setup-playbook-parity`, node `playbook-tabs`. Claude Code subagent of session 294b676b (workspace `~/Projects/master-connector-repo`), conductor v2.3 loaded first. Date 2026-10-01, about 20:05–20:55Z.

- **Input:** `notes/replication-retest-prelim.md`, which lists 24 blocking gaps (19 missing content, 2 unclear steps, 3 wrong order).
- **Output:** one source file per gap in `tabs/gap-facts/<gap>.json`, shaped like a tab section (`title`, `header`, `rows`, last column `source`), plus this summary.
- **Who wrote what:** three read-only helpers wrote `notes/gap-facts-g01.md`, `notes/gap-facts-g02.md` and `notes/gap-facts-order.md`. The lead wrote G06, G12 and G16, lifted the helpers' rows into their gap files and resolved the conflicts (§6).

## 1. What each file closes

| Gap | Type | File | Target tab | Rows | Status |
|---|---|---|---|---|---|
| G01 | missing content | `tabs/gap-facts/G01.json` | Rebuild from zero, new section 0 | 8 | Sourced from vendor docs and workbook rows. Orgo has no documented invite steps. Partner access today isn't listed. |
| G02 | missing content | `tabs/gap-facts/G02.json` | new tab: Student starter kit | 4 + 11 | Sourced. GitHub is behind Alex's Mac. The helper counted agents-home 31 and master-connector-repo 10 commits behind at about 20:25Z; a recount at 20:52Z found 36 and 16. |
| G05 | unclear step | `tabs/gap-facts/G05.json` | Rebuild from zero (4.1–4.3, 8.1) | 3 + 1 | Sourced. Where the backup goes is a proposal (§8). |
| G06 | missing content | `tabs/gap-facts/G06.json` | new tab: 1Password item catalog | 30 + 17 + 2 + 8 | Done. **2 hub-only keys saved to 1Password and verified by hash.** |
| G12 | missing content | `tabs/gap-facts/G12.json` | Composio | 18 + 6 + 7 + 4 | Done (read through Composio's REST API). |
| G15 | unclear step | `tabs/gap-facts/G15.json` | AI apps | 7 | Sourced. The lead corrected 2 cells from live reads (§6). |
| G16 | missing content | `tabs/gap-facts/G16.json` | new tab: AI app settings | 11 + 11 + 5 | Done (sanitized copies of the live files). 3 rows differ from the target (§5). |
| G21 | wrong order | `tabs/gap-facts/G21.json` | Rebuild from zero (8.2, new 10.7, 17.1–17.2) | 4 | Sourced. |
| G22 | wrong order | `tabs/gap-facts/G22.json` | Rebuild from zero (new 8.0, 8.4, 8.7) | 3 | Sourced. |
| G23 | wrong order | `tabs/gap-facts/G23.json` | Rebuild from zero (17 checks moved) | 28 | Sourced. |

**Not covered by this play.** These gaps were outside its brief: G03 (only the clone half, through G02 row 7), G04, G07, G08, G09, G10, G11, G13, G14, G17, G18, G19, G20 and G24.

Some facts found here also help those gaps:
- **G13:** the gateway checks the Worker secret `GHL_MCP_INTERNAL_API_KEY`.
- **G14:** the builder origin key and the GHL Command license key are now in 1Password.
- **G11:** both tunnel tokens can be fetched from Cloudflare.

## 2. Research log

Every URL below was read on 2026-10-01 (read 2026-10-01). The builder accepts a URL only when it appears in a research note, so these lines are that record.

| URL | read | route and log | used for |
|---|---|---|---|
| https://www.1password.dev/cli/item-create | read 2026-10-01 | Exa `EXA_SEARCH` log_bifACF0Y86Fo, then `EXA_GET_CONTENTS_ACTION` log_k3ZPfWuo1t0Y | Sensitive values go in through a JSON template, because command arguments can be seen by other processes. A template can be piped on stdin (`op item create --vault <v> -`). |
| https://www.1password.dev/cli/reference/management-commands/item | read 2026-10-01 | Exa log_k3ZPfWuo1t0Y | `item create`, `get` and `list` subcommands |
| https://www.1password.dev/cli/item-template-json | read 2026-10-01 (search text only) | Exa log_bifACF0Y86Fo | Template fields match the shape `op item get` returns |
| https://developer.1password.com/docs/service-accounts/get-started/ | read 2026-10-01 by the G01 helper | Exa log_mrJeSb_6Va81 (`notes/gap-facts-g01.md` §1, W9) | A robot's vaults are fixed when it's made. Robots can't reach the Personal, Private or Employee vault. |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/do-more-with-tunnels/local-management/tunnel-permissions/ | read 2026-10-01 | Exa `EXA_SEARCH` with page text, log_NtUEY2oD-o_m | `cert.pem` is account-wide: anyone holding it can create, delete and manage every tunnel. A credentials file covers one tunnel. |
| https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/configure-tunnels/remote-tunnel-permissions/ | read 2026-10-01 | Exa log_NtUEY2oD-o_m | A remotely managed tunnel needs only its token to run. `GET …/cfd_tunnel/<id>/token` returns it. |
| https://docs.composio.dev/docs/extending-sessions/custom-mcp.md | read 2026-10-01 | Exa `EXA_GET_CONTENTS_ACTION` log_gYqyErbXuCcm | Upsert bodies for NO_AUTH, API_KEY and DCR_OAUTH. `app_url` and `auth_schemes` can't be changed later (409). The auth config needs `is_enabled_for_tool_router`. Sync after tool changes. |
| https://developers.openai.com/codex/config-reference | read 2026-10-01 | Composio docs reader `CUSTOM_OPENAI_DOCS_SEARCH_OPENAI_DOCS` log_e3-EKxOU64A6 (it returned this page's skills rows) | `skills.config.<n>.path` and `.enabled` are per-skill overrides |

The helpers' URLs are logged in their own files: `notes/gap-facts-g01.md` §1, `notes/gap-facts-g02.md` §2 and `notes/gap-facts-order.md` §1.

**Live reads and the one write** (times are UTC on 2026-10-01; each script lives in this session's scratchpad):

| Time | What | Route | Result |
|---|---|---|---|
| 20:26:29Z | Hub secret inventory, pass 1: names, sizes and sha256[:16] only. `.env` names and non-regular files were not opened. | `orgo_op.py orgo computers bash` to My OpenClaw | 15 secret files. Route-token files exist for atlas-cloud and google-robot only. |
| 20:28:17Z | Hub pass 2: counts and hashes inside the GHL Command files | same | 49 registry location keys, 2 of them in 1Password. A license key and 3 sign-in values are not in 1Password. |
| 20:30:07Z | **Write:** 2 items created in Connectors with the hub's read-write robot, from a JSON template on stdin. Then read back. | same | Both hash matches true. Vault went from 28 to 30 items. |
| 20:30:33Z | Mac-side vault read: metadata and field labels, values only as sha256[:16] | `op item list` / `op item get` with the Keychain robot, run outside the sandbox | 30 items, no duplicate titles. Both new values found. |
| 20:30:55Z | Hub health state (names and status only) | `orgo_op.py` | All 8 routes answer. 9 watched Composio logins pass a read check. |
| ~20:31Z | Builder tunnel token compared with Cloudflare's | Composio `CUSTOM_CLOUDFLARE_API_EXECUTE` log_vbqjjunTGD_x | Hashes equal: the token is derivable, not hub-only |
| 20:33:12Z | Composio custom toolkits, auth configs and logins | REST GET only, using the CLI login headers | 13 auth configs plus 5 no-auth readers. Stored login values come back masked. |
| 20:35:30Z | Claude Code, Claude Desktop and Codex settings | Python allowlist and redaction | §5 |

## 3. G06: 1Password item catalog and hub-only secrets

**Method.**
1. The Connectors vault (`r6z62bjyy3c5ipilbgs4lyakwi`) was read with the Keychain robot. The script kept item ID, title, category, dates, field labels and types, and whether each field has a value.
2. Each value became only a sha256[:16] in memory and in a scratch file (mode 600). No value was printed or saved.
3. Notes fields were searched only for toolkit slugs and script names.
4. Documentation fields (`used by`, `url`, `reaches` and similar) were read through an allowlist that also masks emails and query strings.
5. On the hub, each secret file was hashed the same way and matched against the vault hashes.

**What the hub holds, in short:**
- **Already in 1Password, and equal:** `creds/hub-token`, both route tokens, `atlas-cloud-key`, `xai-key` and `tagging.json`.
  - The xAI key was already in 1Password (item `hzbgkns2qocgczsq5kcv2ckl64`), so workbook All connections R260 is stale on that point.
  - A duplicate copy sits on the Mac at `~/.cursor/mcp-servers/xai-research/key.txt` (same hash). It's a cleanup candidate under the standing yes; this play didn't touch it.
- **The IR notes token** is the shared hub token. There is no `creds/route-tokens/ir-notes`, and the proxy falls back to `creds/hub-token` (proxy.mjs L9–L10). So the IR notes login uses item `qhzv4z3vflmqdi64rx3wfh7sji`, which answers All connections R296 ("which 1Password item: not checked").
- **Hub-only before this play, now saved:**
  - the builder origin key (`/opt/ghl-command-universal/origin-key`), now item `5bfzdypjiimr7ov4kyua6wxtha`;
  - the GHL Command (EliteDCS) license key (`/opt/increase-roas-mcp/ghl-config/credentials.json`, field `license_key`), now item `smsqrb4cyzqvdsu3eedizvpxgy`.
- **Not moved, each with its reason (G06.json §2):**
  - **The read-write robot token.** It's on the hub and in the Mac Keychain, equal by hash. Saving it in Connectors would let the read-only robot read a write token. Robots can't reach a Private vault, so that backup is an owner step.
  - **47 client-location keys** in the GHL Command registry. Copying them in bulk into the shared vault widens who can read client keys, which is Alex's call.
  - **3 GHL Command sign-in values.** They are refreshed by the sign-in, so a copy would go stale.
  - **`cert.pem`.** Account-wide tunnel power that isn't needed to run.
  - **Two tunnel credentials.** Derivable from Cloudflare.
  - **The builder's `sessions/`.** Client session state.
- **Not opened (`.env` rule):** `creds/prime.env` and `creds/spyfu.env` (proven equal on 2026-10-01 by spp-p2b), `/opt/increase-roas-mcp/meta-ads.env` and `tunnel-runtime.env` (NOT_PROVEN), and OpenClaw's two `.env` files.

**The write.** It went through a guarded path:
- **Target.** Exactly 2 items in vault Connectors, created with the hub's read-write robot.
- **Dedup.** Before the write, no item had either title and no item held either value (by hash).
- **How.** Each value went from the hub file into `op item create --vault <id> -` on stdin, following 1Password's guidance for sensitive values.
- **Readback.** `op read` on the hub gave a hash match (true for both), and a second, independent read from the Mac found both values in the new items.
- **Guard.** The Director's write guard wasn't armed: the ledger shows `AUTHORIZATION_SCOPE_HASH: NONE`, so an acquire would fail on scope mismatch. The play used the standalone rule instead (exact target, deduplication, authoritative readback), as rebuild-sources did.
- **Authority.** Repo AGENTS.md rule 1 and the owner's "keys belong in 1Password". Nothing was deleted.

**Stale item notes found:**
- The `used by` field of "GHL OAuth CRM (ghl-oauth-crm) — gateway key" still names direct Claude and Cursor connectors and a relay.
- The `used by` field of "Orgo API key" still says `~/.orgo/credentials.json`.
- Three filled items still have "(paste here)" in their titles: Higgsfield, Make and Tailscale.

## 4. G12: Composio custom routes

**Method.** GET only, against `https://backend.composio.dev`, using the CLI login headers (push_key_to_composio.py L34): `/api/v3/auth_configs`, `/api/v3/connected_accounts`, `/api/v3/connected_accounts/<id>` and `/api/v3/toolkits/<slug>`. A Python allowlist dropped every value under a key-like name and masked long strings.

**Findings:**
- **Auth configs.** 13 custom auth configs, all ENABLED, type custom, tool router on.
  - 11 use API_KEY (`generic_api_key`).
  - `custom_ghl_command_builder` uses DCR_OAUTH.
  - `custom_htl_google_tracking` has 0 logins.
- **Logins.** 12 custom logins are ACTIVE.
- **Docs readers.** The 5 readers are NO_AUTH, with no auth config and no login.
- **Endpoints.** Each toolkit's endpoint is its `base_url` / `meta.app_url`, and all 8 hub routes sit under `https://mcp.increaseroas.com/<route>/mcp`.
- **Masked values.** Composio returns stored login values masked, so which key a login holds can't be matched by hash. The mapping rests on two facts:
  - **The proxy rule.** A route without its own token file accepts only the hub token.
  - **The hub health check.** At 20:30:55Z all 8 routes answered, and read checks passed for 9 watched logins: cloudflare, ga4, ghl-builder, ghl-crm, google-ads, google-robot, gtm, ir-notes and meta-ads.
  - **Not covered.** The prime-intellect, spyfu, xai-research, atlas-cloud and foreplay logins aren't watched and weren't read-tested here (no free read call was chosen).
- **Builder sign-in.** The discovery document, read at `https://ghl-command-universal.increase-roas.workers.dev/.well-known/oauth-authorization-server`, gives `/authorize`, `/token` and `/register`, scopes `mcp:read mcp:write offline_access`, and PKCE S256.
- **Header templates.** Composio's API doesn't return the header template a toolkit was registered with. Only atlas-cloud's is on record (`Authorization: Bearer {{generic_api_key}}`, atlas-cloud.md L29). The proxy accepts Bearer or `x-api-key` (proxy.mjs L21), so the documented Bearer form is the rebuild default.
- **One-machine-only code.** The `custom_htl_google_tracking` Worker's code is in `~/Development/htl-google-tracking-mcp`, a local git repo with no remote (last commit f66b506, 2026-09-29). It's in none of the 4 private repos. Its setup has no login, so it isn't a live route.

## 5. G16: target settings

**Method.** Python read `~/.claude/settings.json`, `~/.claude.json` (only `mcpServers` and update keys), `~/.claude/plugins/{known_marketplaces,installed_plugins}.json`, `~/.composio/plugin-cc-self-update.json`, Claude Desktop's `claude_desktop_config.json` (only the server names and env names) and `~/.codex/config.toml` (through tomllib). Values under env, headers or secret-named keys were replaced, and secret-shaped and long strings were masked before anything was printed.
- `~/.codex/hooks.json` was read whole: it holds only hook commands.
- Claude Desktop's own `config.json` was read only for the 1Password key and its booleans. It also holds OAuth token caches, which were never printed.
- Codex's `developer_instructions` are personal and were not copied.

**Re-read at 20:52Z.** The run log showed another play (spp-p16a, skills-vendoring Phase 2) wrote config.toml at about 20:45Z, after the 20:35Z read, so the same sanitizer ran again and G16 and G15 were updated:
- compound-engineering's Codex plugin is now off.
- [[skills.config]] went from 163 to 166 entries: all 15 Superpowers plugin skills and all 30 compound-engineering plugin skills are off, and the vendored copies in ~/.agents/skills serve both AIs.
- config.toml now has [hooks.state] with trusted hashes for both hooks.json hooks.
- Claude Code has 11 vendored Superpowers links.
- config.toml's hash had moved again (625a30d1…), so other plays are still editing it. Re-read before applying.

**Live compared with the target:**
- **Matches:**
  - Composio pinned to v0.2.4 (installed 0.2.4; self-update result "current").
  - The guard hook in both Claude Code and Codex. Codex's `hooks.json` was written at 16:29 EDT.
  - Playwright as the only server in `~/.claude.json`.
  - The Codex plugins and the Composio app set to approve.
  - The environment filter.
- **Superpowers in Claude Code.** The plugin is off (`false`), and its skills come from vendored copies in `~/.agents/skills` linked into `~/.claude/skills`. This changed after `hard-rule-checks.md` (15:33) turned the plugin on. It matches the skills-vendoring end state (`skills-vendoring.md` L237).
- **Differs from the target (3):**
  - The terminal Codex CLI 0.150.1 can't run `gpt-6.1-sol` (HTTP 400). The app's bundled 0.159.2 can.
  - Codex still has `[mcp_servers.1password]`, which is decided for removal.
  - Claude Desktop still lists 2 local servers (item L01, waiting for Desktop to quit).
- **Seen but unexplained:** `grandPrix.onePassword.paired = true` in Claude Desktop's `config.json`. It isn't a key route; which feature uses it is NOT_PROVEN.

## 6. Merged from the helpers, and conflicts resolved

- **G01 and G02:** lifted as written. Each source check in the helper files passed when they were written.
- **G05, G15, G21, G22 and G23:** lifted from `notes/gap-facts-order.md` §7.
- **Lead's corrections to G15** (live reads in §5 beat the helper's notes, including the 20:52Z re-read):
  - **Claude Code row.** "Plugins: Superpowers" became "Superpowers skills from vendored copies; the plugin is off".
  - **Claude Desktop row.** The 1Password pairing flag is now marked as seen.
  - **Codex row.** "Superpowers 5 on, compound-engineering 6 on" became "vendored copies in ~/.agents/skills; the remote Superpowers plugin's skills are switched off and the compound-engineering plugin is off" (the state after spp-p16a Phase 2).
- **Agreement between independent reads:**
  - **Where the read-write token's backup goes.** The lead (G06, from 1Password's per-vault rule and the robot design) and the order helper (G05, from 1Password's security page and decision D08) both concluded "outside Connectors". The workbook's Rebuild 4.3 and C+1P R59 imply Connectors. G05.json carries the proposal for the Director or Alex.
  - **Codex's 1Password MCP.** Both the order helper (G15, from D03, W03 and the onepassword-one-route node) and the lead's live read (G16: still present) say remove.

## 7. Checks

All results below were observed at about 20:55Z on 2026-10-01. Script: `validate_gap_facts.py` in this session's scratchpad.

- **Builder validation.** `build_tabs.py`'s own `check_source`, `scan_text` and the Excel cell limits ran over all 10 files and 188 rows, with `RESEARCH` extended by `notes/gap-facts*.md`.
  - **First run:** 2 problems, both in G02. A quoted locator contained a URL, which the URL rule then wanted dated. They were requoted as `git_setup.sh L5`.
  - **Second run:** 0 problems.
  - **Warnings (40):** all are "looks like a 1Password item id". This is expected: G06, G12 and G05 must name item IDs.
- **Secret scan, two methods, over the 10 gap files and the 4 `notes/gap-facts*.md` files:**
  - the builder's 10 secret-shape rules: 0 hits;
  - every token checked against the sha256[:16] of every CONCEALED value and document in the Connectors vault: 0 hits.
- **Negative check 1: the URL rule.** The same validation without the extra `RESEARCH` line gives 55 "URL not in the research notes" problems. So the check really bites, and the one-line builder change in §9 is required.
- **Negative check 2: client names.** A grep for 5 client names, including the 2 masked GHL PIT titles, finds 0 in the gap files and notes.

**verify-before-done (normal stakes: internal source files plus 2 vault records):**

| Check | How | Result |
|---|---|---|
| Done means: one file per gap with rows and a source column, no secret values | 10 files in tabs/gap-facts/; builder validation and two secret scans | Met |
| Done means: G06 catalog plus hub-only secrets saved, or written down with a reason | G06.json §1–§3 against the vault read (30 items) and the hub inventory | Met: 2 saved, 15 not moved with reasons, 2 NOT_PROVEN |
| Done means: G12 per toolkit (slug, auth, URL), docs-reader setup, GHL URLs | G12.json against the Composio GET reads | Met (header templates NOT_PROVEN) |
| Done means: G16 sanitized snippets | G16.json from the Python sanitizer, re-read at 20:52Z | Met |
| Done means: the 3 wrong-order and 2 unclear gaps | G05, G15, G21, G22, G23 files | Met (2 items are proposals, §8) |
| Counts recomputed from source | 30 vault items (op list), 49/2 registry keys (hub), 13 auth configs and 12 ACTIVE logins (REST), 8 routes (routes.json), 166 off-switches (tomllib), 188 rows (validator), commit gaps (git rev-list) | Match, except the commit gaps had grown (updated above) |
| Records written to a tool | 2 new 1Password items read back on the hub and from the Mac | Hash match on both |
| Citations | Builder check on every path, line, § and quote locator; URLs fetched by the lead or a helper this play. Two high-impact helper claims re-read (Exa log_qrCsHGzt-S0P): Composio "A normal PRIVATE connection belongs to the user who created it"; GitHub "Collaborators can't have read-only access to repositories owned by a personal account" | Pass |
| Negative checks | No RESEARCH line: 55 URL failures. Client-name grep: 0. Secret shapes: 0. Vault values: 0 | Pass |
| Couldn't check | The .env files on the hub (rule), OpenClaw's secrets, which key each masked Composio login holds, header templates, the 5 unwatched logins working today | Listed in §8 |


## 8. NOT_PROVEN, and findings for the Director

**NOT_PROVEN**
1. Whether `/opt/increase-roas-mcp/meta-ads.env` and `tunnel-runtime.env` hold a value 1Password lacks. They were not opened, by rule.
2. OpenClaw's own secrets under `/root/.openclaw`. These are Orgo-managed and outside the hub rebuild; only names were listed.
3. Which exact key each Composio login holds (values are masked). For prime-intellect, spyfu, xai-research, atlas-cloud and foreplay, it also isn't proven that the login works today.
4. The header template each custom toolkit was registered with, and the exact upsert body used for the GHL builder.
5. The terminal Codex CLI after an update. What Claude Desktop's 1Password pairing does.
6. From the helpers:
   - Orgo invite steps (none documented).
   - Partner access as it stands today.
   - Composio team-login reach for a partner's CLI and for custom logins.
   - GitHub invitation expiry.
   - The read-write backup location (a proposal).
   - The removal of ChatGPT's 1Password plugin (no decision row).
   - The health check's exit-node test, which only passes on Alex's ISP.

**Findings (not acted on; each belongs to another lane or needs Alex)**
- **GitHub is behind the Mac.** At 20:52Z, agents-home was 36 commits ahead of GitHub's main (ae2136d) and master-connector-repo 16 ahead (f1b1355). A newcomer's clone misses today's work until Alex's normal push, and the numbers grow with every commit.
- **The 47 client-location GHL keys** exist only on the hub. Copying them into 1Password is Alex's access decision.
- **Dead copies to clean up under the standing yes** (back up first):
  - hub `creds/wsadmin-token`;
  - hub `/root/.cloudflared/cert.pem`, which isn't needed to run;
  - the Mac's `~/.cursor/mcp-servers/xai-research/key.txt`.
  - Vault items for retired routes, to archive: "MCP Workspace Admin token" and "Google service account — workspace-admin".
- **Codex `[mcp_servers.1password]`:** decided for removal; still present.
- **The health check doesn't watch 5 custom logins:** prime-intellect, spyfu, xai-research, atlas-cloud and foreplay.
- **The HTL tracking Worker's code** is one-machine-only (no remote).
- **Spillover in the shared scratchpad:** the G01 helper overwrote a file named `exa.py` that another helper had left there earlier today. It's only in the session scratchpad, not the project.

## 9. How the builder uses these files

1. **Add one line to `RESEARCH`** in `build_tabs.py`, so URLs cited in the gap files pass its URL check: `+ sorted(glob.glob(f"{JOB}/notes/gap-facts*.md"))`. Without that line, the URL items fail with "URL not in the research notes", and the path-only sources still pass.
2. **Place the rows.** Each gap file's `target_tab` says where its rows go. The wrong-order and unclear-step files (G05, G21, G22, G23) carry replacement cells by section title and step label for `tabs/rebuild-from-zero.json`; "(unchanged)" means keep the cell.
3. **Run the check:** `python3 build_tabs.py check`, then the dry run, as usual.

**Validation output (§7)** was run from the job folder with `build_tabs.py`'s functions imported and `RESEARCH` extended. Result:

```
files: 10 rows per file: {'G01.json': 8, 'G02.json': 15, 'G05.json': 4, 'G06.json': 57, 'G12.json': 35, 'G15.json': 7, 'G16.json': 27, 'G21.json': 4, 'G22.json': 3, 'G23.json': 28}
PROBLEMS (0)
WARNINGS (40): {'looks like a 1Password item id': 40}
SECRET SHAPES (0)
VAULT SECRET VALUES FOUND (0)
```
