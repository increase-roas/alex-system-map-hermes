# Gap facts, spp-c14: For You project ID, GHL Command sign-in files, ChatGPT cloud skills, partner robot (Conductor, 2026-10-01)

All reads were on 2026-10-01 and read-only. Composio was read through its REST API (GET only) and the `composio` CLI. claude.ai/Composio and chatgpt.com were viewed in a separate Chrome tab, since closed. Web pages were read through Composio Exa. No key, token or secret value was printed.

## 1. Where a new org finds its For You project ID (G12 and G21)

**Places that don't show it:**
- The For You dashboard (`dashboard.composio.dev/<org>/~/connect/...`). Its Settings page shows only the organization name, "Enhanced Control" (it calls this "this Connect project") and Delete organization. The page loads data through server-side page actions, so no request shows a project ID.
- `composio whoami`, which prints account_type, email, current_org_name and enhanced_controls_enabled.
- `composio orgs list`, which prints the org ID and name only.
- `GET https://backend.composio.dev/api/v3/org/project/list` and `GET /api/v3/auth/session/info`. Both return only the org's Platform project ("alex_workspace_first_project", ID starting `pr_UFj`), not the For You project.
- Composio's docs, which describe Platform → Settings for Platform projects only: https://docs.composio.dev/kb/guide/dashboard-project-settings-navigation and https://docs.composio.dev/kb/guide/dashboard-navigation-overview (read 2026-10-01).

**Where it IS: the CLI's own cache.** After `composio login` and one `composio execute`, `~/.composio/tool-permissions-cache.json` has one entry under `entries` whose key contains `:consumer-`. Its fields are `orgId`, `projectId`, `consumerUserId`, `connectedAccountIds`, `enhancedControlsEnabled` and `fetchedAt`.
- Checked 2026-10-01: `projectId` equals the health config's `composio_project`.
- The key's consumer part, which is also `consumerUserId`, equals the health config's `composio_user`, which starts with `consumer-`.
- **Command:** `python3 -c 'import json,os;d=json.load(open(os.path.expanduser("~/.composio/tool-permissions-cache.json")));[print(v["orgId"],v["projectId"],v["consumerUserId"]) for k,v in d["entries"].items() if ":consumer-" in k]'`
- **NOT_PROVEN:** that the file layout stays stable across CLI versions. It's an undocumented cache, not a Composio-documented location.


**Composio's documented route (docs.composio.dev, "Design a consumer agent", read 2026-10-01): https://docs.composio.dev/docs/consumer-agents**
- `POST https://backend.composio.dev/api/v3.1/org/consumer/project/resolve`, with `x-user-api-key` and `x-org-id`, returns `project_nano_id` (the value to send as `x-project-id`). It "also provisions the project when it is absent", so it was **not** called against our org. For a brand-new org it's the newcomer's first step.
- `GET /api/v3.1/org/consumer/connected_toolkits?user_id=<consumer user id>` is documented to return `project_nano_id` too, and "never provisions one". **Live 2026-10-01 on our org:** HTTP 200, but the body had only a `toolkits` list and no project fields, so docs and live behavior differ. For an existing org, the CLI cache above is the read-only lookup that worked.
- The docs: "Use the nano IDs from the resolve response (org_id and project_nano_id), always together. A UUID in either header is a 400."

**Every place Alex's value is hard-coded** (a newcomer on their own org changes each one):

| File | Line | What |
|---|---|---|
| `~/.agents/tools/connectors/push_key_to_composio.py` | 16 | `PROJECT = "pr_JDtrNq9tUa_i"` (the key mover) |
| `~/.agents/tools/connectors/ir_notes/sync_notes.py` | 61 | the `x-project-id` header |
| `~/.agents/tools/connectors/health/config.json` | 6 | `composio_project`, plus `composio_org` and `composio_user` in the same file; health_check.py sends them at lines 28 and 38 |
| `work/2026-10-01_setup-playbook/scripts/tuneup-wiring/tuneup.py` | 145 | the `x-project-id` header (tune-up wiring) |
| `work/2026-10-01_setup-playbook/scripts/p31a_delete_composio_1p_logins.py` | 37 | a one-off delete script. Don't run it on a rebuild |
| `~/.agents/tools/cards/composio.md` | 37 | documentation text |

## 2. GHL Command's sign-in files on a fresh hub (G14)

- **Where the origin expects them:** `~/Development/ghl-command-universal/origin/server.py` (repo increaseroasir/ghl-command-universal, commit 6fcc3b4).
  - L16 sets `SOURCE = /opt/increase-roas-mcp/ghl-config`.
  - L18 runs the pinned package at `/opt/ghl-command-universal/node_modules/@elitedcs/ghl-mcp/dist/index.js`.
  - L99–L103 copy `credentials.json`, `.ghl-tokens.json` and `device.json` from SOURCE into each session.
  - L106 sets `GHL_MCP_CONFIG_DIR` to the session folder.
  - The README (L17) says these files "come from the licensed GHL Command sign-in".
- **The package's documented sign-in** (npm README, https://www.npmjs.com/package/@elitedcs/ghl-mcp, and https://elitedcs.com/ghl-mcp-setup-guide, both read 2026-10-01):
  - **License activation:** a one-time call of its own tool, `setup_ghl_mcp`, with `email` (purchase email), `license_key`, `ghl_api_key` (a GHL Private Integration key) and `ghl_location_id`. The optional `firebase_paste` field unlocks the builder tools. The README: "Run setup_ghl_mcp to activate GHL Command".
  - **Headless CLI:** `npx -y @elitedcs/ghl-mcp cli install` (also `--dry-run`); `cli register-agency-key --api-key pit-…`; `cli register-location --location-id … --api-key pit-… --name "…"`; `cli register-company-firebase --company-id … --refresh-token … --user-id …`.
  - **Config dir:** "Persistent config dir — set `GHL_MCP_CONFIG_DIR=/data/ghl-mcp` (absolute path)".
  - **Storage:** credentials are stored "in a per-user credentials file … at chmod 0600".
  - **License scope:** one license covers "up to 3 machines", and "A server counts as one machine; restarts never consume extra activations".
- **Runnable on the hub (derived from the above):**
  1. `cd /opt/ghl-command-universal && npm ci` (README L17).
  2. `export GHL_MCP_CONFIG_DIR=/opt/increase-roas-mcp/ghl-config` (mkdir, mode 700).
  3. Run the `cli register-agency-key` / `register-location` / `register-company-firebase` commands with the pinned binary.
  4. Activate the license with one `setup_ghl_mcp` tool call over the package's stdio JSON-RPC. That's the same `initialize` → `tools/call` exchange `server.py`'s Child class uses (L109–L113).
- **NOT_PROVEN:**
  - which of these writes `device.json` (the package's own code references it; `dist/index.js` in the 3.88.2 package cached at `~/.npm/_npx/156bedb4b924cf03/`);
  - the exact headless guide the npm page names (`docs/HEADLESS.md`), which isn't shipped in the cached 3.88.2 package;
  - a run of this sequence on record.

## 3. The 3 ChatGPT cloud skills (G18)

Source: https://chatgpt.com/skills (read 2026-10-01, viewed in a Chrome tab). All three are listed under both "Installed" and "Created by me". Each skill page names the author and shows one date, without saying whether it's the creation date or the last update.

| Skill (display / name) | What it is | Author, date shown | Files | Home in ~/.agents/skills |
|---|---|---|---|---|
| Fulfill Hot Tub Launch / `fulfill-hot-tub-launch` | Fulfil, audit, troubleshoot, validate and prepare launches of HTL paid funnels, retailer websites and GHL snapshot integrations | Alexander Lobaito, Aug 15, 2026 | SKILL.md, agents/openai.yaml, assets/icon.svg, about 18 references | none |
| Hot Tub Scene Variator / `higgsfield-hot-tub-scene-variation` | Controlled batches of photorealistic dealer-style hot-tub images in new scenes through Higgsfield, keeping the exact product | Alexander Lobaito, Aug 13, 2026 | SKILL.md, agents/openai.yaml, assets/icon.svg | none |
| Local Meta Ad Creative System / `create-local-meta-ads` | Direct-response Meta ad creative systems for local service businesses (formats, hooks, messaging, review) | Alexander Lobaito, Jul 10, 2026 | SKILL.md, agents/openai.yaml, references (formats-and-concepts, messaging-playbook, review-checklist) | none |

**Origin:** created in ChatGPT by Alex ("Created by me"). Nothing was copied.

## 4. A partner's own robot and the read-write backup (G05)

1Password docs: https://developer.1password.com/docs/service-accounts/get-started and https://developer.1password.com/docs/cli/reference/management-commands/service-account (read 2026-10-01).

- **Create** (owner): `op service-account create <name> --vault <vault-name>:<permission>[,<permission>]`. Permissions are `read_items`, `write_items` and `share_items`. "If no permissions are specified, it will default to `read_items`."
- **Fixed permissions:** in the web wizard, a robot's vault permissions and its Environments "can't be changed later".
- **Token shown once:** "1Password CLI only returns the service account token once. Save the token in 1Password immediately to avoid losing it. Treat this token like a password, and don't store it in plaintext."
- **Private vaults are out of reach:** "You can't grant a service account access to your built-in Personal, Private, or Employee vault."
- **Partner procedure:**
  1. Alex creates one read-only robot per partner Mac, e.g. `op service-account create "connectors-sync <partner> Mac" --vault Connectors:read_items`.
  2. He saves the token in 1Password at once and gives the partner access to that item.
  3. On the partner's Mac, the token goes into the Keychain under the names the scripts use: account `connectors-sync`, service `op-service-account-connectors-sync`. The command is `security add-generic-password -U -a connectors-sync -s op-service-account-connectors-sync -w`, with `-w` last so it prompts. Apple's security(1) manual: "-w password: Specify password to be added. Put at end of command to be prompted (recommended)". It also says `-A` is "insecure, not recommended!".
- **Read-write backup:** Alex's built-in Private vault. Service accounts can't be granted access to it, so only Alex can read it.
