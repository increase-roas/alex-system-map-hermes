# onepassword-vault-scope (play spp-p28a, node onepassword-one-route), 2026-10-01

- Controller: Claude Code subagent of session 294b676b-77d8-4d64-976e-70a783b96d65, workspace
  `~/Projects/master-connector-repo`, conductor v2.3 loaded first. Owner request (Director chat): "cursor said if we use
  composio 1pass then it doesnt show local vault. we need to ensure everything is outside of local vault".
- `Stage: RESEARCH/AUDIT, read-only | Route: direct + 1 research helper | Gap: none for the sweep; the moves are Alex's | Next: Alex's moves (section 4), then an agent repoints the Lone Star scripts`
- `Checkpoint: robot proof 21:29:00-21:29:05Z | Settled: Connectors is the one robot vault for our tools; Javar's and the agent team's vaults stay (their fence) | Interrupted: usage-limit pause, resumed; no write was in flight`
- Rules kept: metadata only. No secret value was printed or saved, no `.env` file or pipe was opened, and every `op` call
  ran with a robot token and the desktop-app sign-in switched off, so no 1Password prompt could appear. Nothing was
  changed except this note and one line in `workbook-updates.md`.

## Result: VERIFIED for the sweep. 7 things for Alex to move, 2 more need his call, and 1 security finding

- **"Local vault" is a real vault named "Local Vault (operator secrets)"** (`x36mcnjxsu7mafmgb3n5n4qrre`). It was
  created 2026-08-31 and holds 25 items. It is not a 1Password 7 local vault: none exists on this Mac.
- **Which routes can't see it:**
  - the two connectors-sync robots;
  - Javar's robot;
  - the new "composio" robot behind Composio's 1Password login;
  - 1Password Connect.
  None of them can see Employee or the default Shared vault either.
- **What does not depend on it:** our own scripts, the hub and Javar's loader. Every item they need is visible to their
  robot.
- **What does depend on it:**
  - 3 Lone Star items in Local Vault;
  - 1 HTL Dashboard item in Employee that Codex remembers;
  - keys that exist only in 1Password Environments (Apify, PageSpeed and 36 GHL location keys).
  Section 4 lists each one with its move.
- **Seven routes involve Alex's own account or a robot outside Connectors** (section 5). Two are already removed.

## 1. Research (owner rule 5)

The research helper used Exa through Composio and fetched each page; its log IDs are listed below. I re-fetched two
pages myself to check them: `log_NgRibAfD6J8f` (the service-account page and 1Password for Claude) and
`log_E9twWKGlhlJD` (moving items).

| Question | Answer | Source |
|---|---|---|
| Which vaults a 1Password service account can reach | Any vault its creator manages, **never** the built-in Personal, Private or Employee vault or the default Shared vault. Its vaults are fixed when it's made (change = new account). Environments: read-only, and only if picked at creation. | https://www.1password.dev/service-accounts/get-started , /manage-service-accounts , /security (undated, read 2026-10-01; log_aiXAxqzy48im, log_c-urJXyvYfjG, rechecked log_NgRibAfD6J8f) |
| Do local vaults still exist in 1Password 8 | No. Standalone, device-only vaults were a 1Password 7 feature. 1Password 8 needs an account, and migration moves them into account vaults. 1Password 7 is being retired (account sync stops May 2027). | https://support.1password.com/migrate-1password-account/ (2026-08-17), /upgrade/ (2026-07-28), /employee-vault/ (2026-08-06), 1Password Community PSA (2026-09-01) (log_rhTGIJHQMxMm, log_aMF8E7Q2pTRo, log_T92XS4LgdOgH) |
| What this Mac has | Only 1Password 8.12.36. The 1Password 7 container holds no data. The app's own vault list (Cursor chat's `op vault list`, 20:21Z) names `x36mcnjx…` "Local Vault (operator secrets)". Its local database records it as type U, a normal user-made vault. | `/Applications/1Password.app` Info.plist; `~/Library/Group Containers/2BUA8C4S2C.com.agilebits/Library/Application Support` empty; `/tmp/op-vaults.json`; 1Password.sqlite `vaults.vault_type` (read-only) |
| Composio's 1Password toolkit | Slug `_1password`, 6 tools (list vaults, list/get/create/update/delete items). Login = Base URL + Bearer token (a service-account token, a Connect token or an Events token). Composio has no managed login for it. A service account or Connect server can never see Personal, Private, Employee or the default Shared vault. | https://docs.composio.dev/toolkits/_1password , https://www.1password.dev/connect/security (log_RF_tr5_9P3zm, log_WmAd16-HyGnn); toolkit record `GET /api/v3/toolkits/_1password` |
| Our org's 1Password login | Auth config `ac_FFWFZ84tq6l7` (custom, made 2026-08-19). Two logins, both made today by Alex's Cursor chat 19f0f512: `ca_PSjKn84-Yd_T` **ACTIVE** (20:40Z) and `ca_tUN0EokIrKzF` EXPIRED (20:24Z). The active one holds a service-account token: the new robot "composio" (read+write on 26 vaults). **It sees 26 vaults: not Employee, not Shared, not Local Vault (operator secrets).** | REST GET (values masked); `_1PASSWORD_LIST_VAULTS` log_lzyr0Esmt8P_ (names only); Cursor transcript 19f0f512 L345-L371 |
| Claude Desktop's 1Password pairing (`grandPrix.onePassword.paired = true`, read 2026-10-01) | "1Password for Claude" (beta, 2026-07-16). It is connected in Claude Desktop under Customize > Connectors > 1Password with Touch ID. It acts as the signed-in desktop account, and each sign-in request asks Alex to approve. It covers Login items and one-time codes only. That the `grandPrix` key is this feature is an inference. | https://support.1password.com/1password-claude/ (2026-09-15), https://support.claude.com/en/articles/15936181 (2026-07-16) (log_YR5Kg-RX47Hn, log_OzgIsbgAxGUw, rechecked log_NgRibAfD6J8f) |
| Cursor's 1Password plugin and the Environments MCP server | Both act as the desktop-app user, and each use needs approval in 1Password. They cover Environments only (create, list names, add variables, mount .env files) and read no vault item. The plugin's hook reads the app's local database without signing in. | https://www.1password.dev/environments/mcp-server , https://www.1password.dev/security-for-ai/cursor-plugin (log_GMQGSTbiWu4A, log_X7Fqwo2ChL3n) |
| `op` without a robot token | Signs in through the desktop app as Alex (Touch ID per terminal session), so it can read Private and Employee. With `OP_SERVICE_ACCOUNT_TOKEN` set it acts as the robot; only the Connect variables override that. `OP_BIOMETRIC_UNLOCK_ENABLED=false` turns off the app sign-in. | https://www.1password.dev/cli/environment-variables , /cli/app-integration (log_q8AnZU7TAmlk, log_BMCck0qwi1zx); github.com/1Password/shell-plugins/issues/606 (2026-05-30) |
| How Alex moves an item | Select the item, then **Edit > Move Item**, and choose the vault (or drag it onto the vault in the sidebar). A move is a copy plus a delete, so the item gets a new ID (inference from that) and scripts that name the old ID need updating. | https://support.1password.com/move-copy-items/ (log_E9twWKGlhlJD) |

## 2. Vault map (read-only; no prompt)

Sources: the 1Password app's local database (`vault_type` is plain text, names are encrypted), opened read-only; the
Composio vault list; and `/tmp/op-vaults.json`. The database holds 37 vault records: 27 user-made (U), 7 Environments
(D), plus one each of Employee (P), Shared (E) and a system vault (S).

| Vault | Type | Read by |
|---|---|---|
| Connectors `r6z62bjyy3c5ipilbgs4lyakwi` (made 2026-10-01; 42 items, 10 archived) | U | connectors-sync read-only and read-write robots, the "composio" robot, Alex |
| Local Vault (operator secrets) `x36mcnjxsu7mafmgb3n5n4qrre` (made 2026-08-31; 25 items) | U | **Alex only** (no robot, not Connect, not Composio) |
| Employee `qskk2dqi6mtrhvc2jb77r37evi` (10 items) / Shared `evlf4jdk377thgt4caupf6mxzi` (1) | P / E | Alex only (robots can never get these) |
| 24 agent and client vaults (Agent — EA-Javar, CSM, Media, Ops, Javante, Finance and others, Hermes – Increase ROAS Team, HTL B2B, ...) | U | each agent's own robot, the "composio" robot, Alex |
| 7 Environments (section 6) | D | Alex through the desktop app; robots only if granted at creation, read-only |

## 3. References (step 2) and what the robots see (step 3)

**Local sweep** (scratchpad `scan_refs.py`): regular files only, 14 `.env`-named files skipped unopened, token shapes
redacted. Covered `~/.agents`, this repo, `~/.codex`, `~/.claude` + `~/.claude.json`, Claude Desktop config, `~/.cursor`
configs and plugins, `~/.hermes`, `~/Alex-Director`, `~/Development`, `~/.local/bin`, LaunchAgents,
`~/Documents/ChatGPT/Build` and `~/Projects`. 881 files hit: 103 distinct `op://` references and 79 item or vault IDs.
Each ID was matched to its real vault through the app's local database (scratchpad `id_map.json`).

**Hub and Javar's loader:** `orgo_op.py orgo computers bash`, script on stdin, read-only. The scan skipped secret-named
files, `.env` names and pipes.
- My OpenClaw (hub): 1,927 files. The only 1Password reader is `/opt/mcp-hub/health/health_check.py`, which reads
  Connectors with the robot token file.
- Javar's EA computer: 7,944 files. The live `config.yaml` and plugins name only items in Agent — EA-Javar — PROD. The
  loader's `*_OP_REF` names sit in its `.env` (not opened); its documented list (Build `1Password-Config.md`, verified
  2026-09-21) points at the same vault.
- The `op://Manus…` and `$VAULT` hits on Javar's computer come from the August bootstrap and skill backups.

| Who uses it | Items | Where they live | Can connectors-sync read them? |
|---|---|---|---|
| Our scripts: `orgo_op.py`, `push_key_to_composio.py`, `gcloud_robot.py`, `hub/rebuild_hub.py`, `hub/install_hub.sh`, `health/config.json`, ad-recreator `atlas_generate_image.mjs`, `~/.codex/mcp-servers/spyfu/spyfu_api.py` | 12 | Connectors | **Yes: 12 of 12, both robots** |
| Hub health check | via config | Connectors | Yes |
| Javar: loader, `config.yaml`, inbox and team plugins | 11 | Agent — EA-Javar — PROD | No, by design (his own robot; 403 below) |
| Hermes team code (Build repo: CSM, Media, Ops, Ops OAuth, OpenClaw, Javante, Finance, Setter) | 25 | 8 agent vaults | No, by design (each agent's own robot) |
| Lone Star scripts (`~/Projects/lone-star-spas/scripts/`) | 3 | **Local Vault (operator secrets)** | **No → section 4** |
| Codex memory (`~/.codex/memories/MEMORY.md` L2626, rollout 2026-08-28) | 1 | **Employee** | **No → section 4** |
| Build docs naming robot recovery tokens | 3 | Local Vault (operator secrets) | No; stays (section 4, last table) |
| `op://Private/…` in `~/.hermes/hermes-agent` | examples | upstream docs and tests | Not ours |

**Robot proof** (scratchpad `robot_visibility.py`, 21:29:00-21:29:05Z, op 2.39.0, output `robot_visibility.json`):
- Both robots are service accounts on increaseroas.1password.com, with different tokens:
  - the Keychain robot (`op-service-account-connectors-sync`) is user `TSPEFDMZ2VBOJDSVIAGV76JVNU`;
  - the read-only robot (token taken from its Connectors backup item and kept in memory) is user
    `MA5UFZVUJFHYXC5UEXMYYDL53I`.
- Each lists exactly one vault, Connectors, with the same 42 items (10 archived). All 12 script items are visible to both.
- Negative checks with the read-only robot, each **403 Forbidden**:
  - Lone Star item `42qu6bms…` in Local Vault;
  - the Local Vault itself;
  - the Employee item `2kipyd2j…`;
  - Javar's Composio key `ql44u4zp…`.
- **Changes to Connectors since G06** (30 items): 12 new, 9 of them archived. Two are active:
  - "1Password service account — composio" (`yp6ons6e…`, 20:39:36Z): finding F1;
  - "Tailscale API token" (`75uhbn7d…`, 21:17:06Z).

## 4. List (a): items an AI or script needs that the robots can't see

**How Alex moves an item:** open the 1Password app, select the item, then **Edit > Move Item** and choose
**Connectors**.

An Environment value has no Move. Instead: **Developer > View Environments**, open the Environment, copy the value, and
paste it into a new API Credential item in Connectors.

| # | Item | Now in | Needed by | Alex's move | Then (agent, no clicks) |
|---|---|---|---|---|---|
| A1 | Lone Star Tracking Runtime Credentials `42qu6bmsljkttqa2bylgg4mqhq` | Local Vault (operator secrets) | `provision-tracking-secrets.py` L14, `connect-ghl-stage-secret.py` L6; `RECOVERY-START-HERE.md` L48 | Edit > Move Item > Connectors | point both scripts at the new ID through the Keychain robot (B1) |
| A2 | Lone Star GA4 server credential `6d6xvefgwibcjt4ggztovrz2x4` | Local Vault (operator secrets) | `connect-ga4-server.py` L11, `provision-tracking-secrets.py` (via `outputs/tracking/ga4-server-credential.json`); `RECOVERY-START-HERE.md` L50 | Edit > Move Item > Connectors | same, and update the receipt's `vaultItem` |
| A3 | Increase ROAS Shared Lead Vault Credentials `77m7fwiorgpljzenm2xgawnudm` | Local Vault (operator secrets) | `provision-tracking-secrets.py` L74; `RECOVERY-START-HERE.md` L49 | Edit > Move Item > Connectors | same |
| A4 | HTL Dashboard – Owner & Production Secrets `2kipyd2jw354yxh3dfappp5jp4` | Employee | Codex memory: HTL dashboard work reads it (`MEMORY.md` L2626; rollout summary 2026-08-28) | Edit > Move Item > Connectors | new ID into Codex's memory pointer |
| A5 | Apify token (`APIFY_TOKEN` in Environment Apify; `APIFY_API_TOKEN` in Environment Agents — Shared Integrations — PROD) | Environments only; no vault item | the Composio `apify` login (its source for rotation or re-push; spp-p24a §3) | copy into a new Connectors item "Apify API token" | add to the 1Password item catalog |
| A6 | PageSpeed key (`PAGESPEED_API_KEY`, Environment Agents — Shared Integrations — PROD) | Environment only | the audit factory's PageSpeed step (SKILL.md L29-L31); where Javar gets it is NOT_PROVEN | copy into a new Connectors item | catalog |
| A7 | 36 GHL location keys `GHL_PIT_<location>` (Environment GHL-Command) | Environment only. The 2 Connectors GHL PIT items match none of the 36 (checked by their `locationId`). The keys also sit as files in the GHL Command registries on the Mac and the hub. | the registries are the runtime source; 1Password is the rebuild source | **Alex's call first.** These are client keys; copying them into Connectors widens who can read them (G06 §2). If yes, copy each one. | catalog |

Client keys (A1-A3, A7): Connectors can be read by both connectors-sync robots and by the "composio" robot (F1).

Needs Alex's call, no consumer found:
- `OPENAI_IMAGE_API_KEY` (Agents — Shared Integrations — PROD).
- Revstead `META_CAPI_ACCESS_TOKEN` (one-off CAPI test, 09-02). Whether it is the Connectors Meta token can't be checked
  without reading the Environment.

Already covered by name (values not compared): `ATLAS_CLOUD_API_KEY` → "Atlas Cloud API key"; every `SPYFU_*` →
"SpyFu API keys".

**Stays where it is (not a gap):**

| Item(s) | Now in | Why it stays |
|---|---|---|
| Robot recovery tokens: Finance `kcfdmvjhzct5py6g5drxrfmfdm`, Ops broker `bmbwsff7vllddtkgpx7gyegjku`, Javante Mac robot `mbgnqekjqvfqpjd5qbvxu3u3um` | Local Vault (operator secrets) | No AI reads them at runtime: the live copies sit in each agent's `.op.env` or Keychain (Finance: only in Build backups `~/.codex/private-backups/Build-*-20260914*/BUILD_STATUS.md` L111; Ops: Build `agents/team-template/runtime-secrets/README.md` L29; Javante: `agents/javante/setup/RECOVERY.md` L11). In Connectors, the connectors-sync and composio robots could read every other robot's token. Least privilege (1Password; D08 source https://www.1password.dev/get-started/secure-developers). |
| GHL Command — Universal MCP, RevStead GHL Tunnel, GHL Marketplace OAuth Gateway — Reference | Local Vault (operator secrets) (titles from `work/2026-09-30_composio-connect/notes/ghl.md` L37-L39) | No consumer found. The live keys are Connectors items (`yxvess6d…`, `3yxpnoxi…`), and `ir-mcp-revstead-ghl` is no longer a hub program (supervisor list, 2026-10-01). |
| Javar's and the agent team's items | their own agent vaults | Their own robots read them; Javar's fence stays (AGENTS.md). |
| Employee web logins (GHL – Agency Login, Agent IR, 2 Orgo items per the Cursor chat) | Employee | Browser sign-ins. 1Password for Claude handles these by design, with Alex's approval each time (B3). |

## 5. List (b): routes that read 1Password as Alex's own account

Not touched, as the play said: the scripts spp-p24a moved off the pipes are fine. apify is retired, spyfu and atlas use
the Keychain robot, and `public_signals.py` uses Composio.

| # | Route | Evidence | What it reaches | Fix | Status |
|---|---|---|---|---|---|
| B1 | 3 Lone Star scripts call `op item get … --account 2IIKZWBRR5ATDD4KSWB52KQTTA` with no robot token | `provision-tracking-secrets.py` L14-L16, L64, L69, L74; `connect-ga4-server.py` L11, `connect-ghl-stage-secret.py` L6 | Local Vault; Touch ID on every run | after A1-A3: read the robot token from the Keychain into `OP_SERVICE_ACCOUNT_TOKEN` (as `orgo_op.py` does), use the Connectors vault ID and the new item IDs, drop `--account` | open, waits on A1-A3 |
| B2 | AI agents running plain `op` in a terminal | Cursor chat 19f0f512 today: `op vault list` saw all 28 vaults as Alex (L263-L271), `op connect server create/delete`, `op service-account create` (L317-L356), `op item list` on Local Vault ("command runner not responding", L374-L380) | everything, Touch ID prompts | Agents read only through the Keychain robot. Creating robots, Connect servers or vault grants are security settings, which stay Alex's (CLAUDE.md); agents give him the steps. | rule, workbook line |
| B3 | Claude Desktop "1Password for Claude" pairing | `~/Library/Application Support/Claude/config.json` `grandPrix.onePassword.paired = true` | Login items in any vault Alex can open (inference), with approval per request | none by default: it is the approved route for browser sign-ins (Alex: browser use is extremely important); unpairing is in Claude Desktop Customize > Connectors > 1Password | by design |
| B4 | Cursor `~/.cursor/mcp.json` `1password` (Environments MCP) | removed 21:19:53Z | - | - | **done (spp-p24d)** |
| B5 | Codex `[mcp_servers.1password]` | no longer in `~/.codex/config.toml`; the curated plugin's `1password-environments` skill is `enabled = false` (L1424-L1426); 6 old app-server children run until restart (spp-p24d) | - | - | **done (Conductor)**; correction in F4 |
| B6 | Cursor 1Password plugin (cache v1.2.0 and its hook) | cached, hook not loaded (spp-p24a §4); it did not re-offer the tools (spp-p24d) | Environments | optional: Cursor > Customize > Plugins > 1Password > Uninstall | optional |
| B7 | `~/.hermes/.op.env`, a robot token file at rest (892 B, mode 600, 2026-08-15, from `~/.local/bin/bootstrap-cursor-1password`) | stat only | a robot, not Alex; which one is NOT_PROVEN (`.env` is never opened); `~/.zshrc` doesn't load it | Director: find which robot it is and whether anything uses it; then retire it to ~/Backups (standing yes) | open |

## 6. Environments (Director's addition)

**Read route:** no live listing exists that raises no pop-up.
- The installed `op` 2.39.0 has no `environment` command (beta builds only).
- The Environments MCP asks for approval on every use.
- A robot can only read an Environment it was given when it was made.

So the names below come from the tool calls that wrote them: Cursor transcripts (spp-p24d table, reused) and Codex
session files (this play), names only. The app's local database confirms there are exactly **7** Environments (type D,
made 08-30 to 09-11), and all 7 are identified.

| Environment | Made by (date) | Variables | In Connectors? |
|---|---|---|---|
| AtlasCloud `xntt4q6u…` | Cursor fe8d152b (08-30) | `ATLAS_CLOUD_API_KEY` | yes, by name |
| Apify `tupzsrra…` | Cursor 45ed65b3 (08-31) | `APIFY_TOKEN` | **no (A5)** |
| SpyFu `v7vy4c3k…` | Cursor 45ed65b3 (08-31) | `SPYFU_API_ID`, `SPYFU_SECRET_KEY`, `SPYFU_BASE64_KEY` | yes, by name |
| Revstead `ufzokff7…` | Cursor 034e1409 (09-02) | `META_PIXEL_ID`, `META_PIXEL_BASECODE` (settings), `META_CAPI_ACCESS_TOKEN` | token unknown (Alex's call) |
| GHL-Command `slwirchr…` | Cursor f74569be (09-04) | 36 × `GHL_PIT_<location>` (full list: `onepassword-verify.md`, spp-p24d table) | **no (A7)** |
| Lone Star Tracking `5kiq57co…` | made 09-09; maker not found in Cursor or Codex tool calls | settings only, per `lone-star-spas/docs/TRACKING-RESUME.md` L23 (not checked) | n/a |
| Agents — Shared Integrations — PROD `uhdphtv7…` | **Codex chat 01a08323 (2026-09-11 16:18-16:32Z)** | `APIFY_API_TOKEN`, `SPYFU_API_KEY`, `PAGESPEED_API_KEY`, `OPENAI_IMAGE_API_KEY`, `ATLAS_CLOUD_API_KEY`, `SPYFU_API_ID`, `SPYFU_SECRET_KEY`, `SPYFU_BASE64_KEY`, plus 3 settings `AUDIT_FACTORY_DEFAULT_BRAND`, `_DEFAULT_VERTICAL`, `_IMAGE_PROVIDER` | Apify, PageSpeed: **no (A5, A6)**; OpenAI image: Alex's call; Atlas, SpyFu: yes, by name |

## 7. Findings for the Director (reported; nothing changed)

- **F1, security.** The "composio" robot's token is now a Connectors item ("1Password service account — composio",
  `yp6ons6e…`, 20:39:36Z).
  - That robot can read and write 26 vaults, including Javar's and every agent vault (list log_lzyr0Esmt8P_).
  - Anything holding a connectors-sync token (the Mac Keychain, the hub's token file) can read it. That undoes the
    robot isolation G06 and D08 kept.
  - No AI needs the 1Password copy: Composio already stores the token.
  - Facts for the decision (security settings stay Alex's):
    - moving the item to Local Vault (operator secrets) takes it out of robot reach;
    - a robot's vaults can't be narrowed after creation, so a smaller one means a new robot plus revoking the old one
      (1password.dev/service-accounts/manage-service-accounts).
- **F2.** The active Composio login's base URL `https://op-connect.increaseroas.com` doesn't resolve (NXDOMAIN at 1.1.1.1,
  2026-10-01). Vault listing still works because of the service-account token, but the workbook shouldn't cite that URL.
  - The Connect server "composio-hub" was taken off the hub and its token item archived (`maffpehh…`, 20:40:39Z).
  - The chat issued `op connect server delete composio-hub`, but its result isn't stored, so that the server record is
    gone is NOT_PROVEN. Checking needs Alex's account.
- **F3.** The Codex chat `rollout-2026-09-08T18-28-34-01a08323…` holds the 11 `append_variables` values in plain text
  (lengths only checked). Same kind of problem as spp-p24d's Cursor transcripts.
- **F4, correction to spp-c11.** Codex's 1Password Environments server was used for real on 2026-09-11:
  `create_environment` plus 3 `append_variables`, 11 variables. spp-c11 counted only `mcp__1password__*` names, and these
  calls were unprefixed. The removal still stands; only its "0 calls" reason changes.
- **F5.** `/tmp/op-vaults.json` (mode 644) is the vault list left by the Cursor chat's own-account `op vault list`. It
  holds names, IDs and counts, no secrets. Cleanup candidate.
- **F6, workbook fact.** All connections r6 (Javar 1Password loader), column G says "1Password Local Vault service
  accounts". In fact Javar's robot reads only Agent — EA-Javar — PROD (`6nzybkhdgdp343i3cgekgnxwhi`).

## 8. Checks (verify-before-done, normal stakes)

| Check | How | Result |
|---|---|---|
| Brief: every AI/script secret is in Connectors, or listed for Alex | references section 3 → vault per ID (local database) → robot test | Pass: all 12 script items visible to both robots; every other gap is listed in section 4 |
| "Local vault" identified | app's vault list, local `vault_type`, Composio list (elimination), Lone Star docs naming the vault | Pass: 4 sources agree on `x36mcnjx…` = Local Vault (operator secrets), type U |
| Counts recomputed from the outputs | `robot_visibility.json`, `id_map.json`, `composio_vaults.json` | 42/10/12, 21+11+25+6+2 references, 26 vaults: match the text |
| Citations | re-fetched the 3 pages that carry the main claims (log_NgRibAfD6J8f, log_E9twWKGlhlJD) | Pass: robots never get Personal/Private/Employee/default Shared; approval per Claude request; Move Item = copy + delete |
| **Negative check** | read-only robot asks for a Local Vault item, the vault itself, an Employee item and a Javar item | 403 Forbidden on all 4. If any had been visible, section 4 would be wrong |
| No prompt | every `op` call had a robot token plus `OP_BIOMETRIC_UNLOCK_ENABLED=false`; Composio and the local database need no 1Password sign-in | Pass, by design |
| No secret leaked | outputs are names, IDs, statuses and lengths only; scripts assert that the tokens are absent from their output | Pass |

**Couldn't check:**
- Environment values (no read without a prompt), so "in Connectors" is by name only.
- Which robot `~/.hermes/.op.env` holds.
- Whether the Connect server record was deleted.
- The `*_OP_REF` lines in Javar's `.env` (the documented list was used).
- Where Javar's PageSpeed key comes from.
- Items in Local Vault and Employee that nothing references: titles are encrypted, so only referenced items were mapped.

Scratchpad scripts (outside the repo): `scan_refs.py`, `robot_visibility.py`, `remote_scan.sh`, `javar_live_scan.sh`.
