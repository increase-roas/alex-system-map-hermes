# Gap facts (play spp-p20d): repos, chat-app blocks, skills, Director home, tune-up, Hermes pointers

Mission `mission-setup-playbook-parity`, node `playbook-tabs` (closing the rebuild gaps). Claude Code subagent of session 294b676b (workspace `~/Projects/master-connector-repo`), conductor v2.3 loaded first. Date 2026-10-01, about 20:58–21:40Z.

- **Input:** `notes/replication-retest-prelim.md`, gap rows G03, G17, G18, G19, G20 and G24.
- **Output:** one source file per gap in `tabs/gap-facts/<gap>.json`, shaped like spp-p20a's `G06.json` (`title`, `header`, `rows`, last column `source`), plus this summary.
- **Who wrote what:** one agent, no helpers. Read-only everywhere: nothing was pushed, committed, uploaded or changed outside these 7 files and one run-log line. No `.env` file or pipe was opened, and no secret value was read or printed.

## 1. What each file closes

| Gap | Type | File | Target tab | Rows | Status |
|---|---|---|---|---|---|
| G03 | missing content | `tabs/gap-facts/G03.json` | Rebuild from zero (replace 0.4; new 3.1b; one line each in 3.5, 16.3, 17.5) | 2 + 6 | Sourced from live GitHub and git reads. Invites stay on the Student starter kit tab (placed from G02). |
| G17 | missing content | `tabs/gap-facts/G17.json` | Templates (new section); step 11.3 points here | 2 + 8 + 8 + 6 | Both blocks byte-exact: the rows rebuild the read-back hashes. |
| G18 | missing content | `tabs/gap-facts/G18.json` | Skills (new section 0); Skills, where they live R24 and R61; step 14.4 | 5 + 11 + 14 + 5 | Live re-count matches the notes: 58 on in Codex, 102 off. |
| G19 | missing content | `tabs/gap-facts/G19.json` | Director + Conductor (new section); steps 15.1–15.4 | 4 + 7 + 3 | A blank ledger block exists (inside the ledger); no blank mission-graph file. Nothing written into `~/Alex-Director`. |
| G20 | missing content | `tabs/gap-facts/G20.json` | Self-improving loop; replaces step 17.3 | 8 + 19 + 6 | Read through the scheduled-tasks list and the two files the task lives in. |
| G24 | missing content | `tabs/gap-facts/G24.json` | new tab: Hermes and Javar rebuild; Rebuild R183 points here | 13 + 6 | Pointers only. One read-only Orgo metadata read; nothing ran on Javar's computer. |

## 2. Research log

Every URL below was read on 2026-10-01 (read 2026-10-01). The builder accepts a URL only when it appears in a research note, so these lines are that record. Route: Composio `exa` through the CLI (`composio execute`), per the exa card.

| URL | read | route and log | used for |
|---|---|---|---|
| https://support.claude.com/en/articles/10185728-understanding-claude-s-personalization-features | read 2026-10-01 | `EXA_GET_CONTENTS_ACTION` log_Fsy1URFC9S5o (full text; log_n9xaVZs5Rnqs was a 1,200-character first pass) | "Instructions for Claude" is account-wide and applies to all conversations; path: your initials > Settings. Cowork's global instructions move into it. |
| https://help.openai.com/en/articles/8096356-chatgpt-custom-instructions | read 2026-10-01 | same log (Exa served a cached copy) | Web and desktop: Settings > Personalization, Enable customization on, Custom Instructions; phone: Settings > Customize ChatGPT. This copy says the longer fields take 1,500 characters. |
| https://docs.github.com/en/organizations/managing-membership-in-your-organization/inviting-users-to-join-your-organization | read 2026-10-01 | same log | Organization > People > Invite member; a paid per-user plan needs an unused license first; invites expire after 7 days. |
| https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/setting-base-permissions-for-an-organization | read 2026-10-01 | same log | Base permissions apply to every member on every org repo, and not to outside collaborators. |
| https://code.claude.com/docs/en/desktop-scheduled-tasks | read 2026-10-01 | `EXA_SEARCH` log_JS3eNOvJoI4F found it; `EXA_GET_CONTENTS_ACTION` log_e5YQpxuGINL2 | Local tasks: Routines > New routine > Local; the picker's presets; ask Claude for other intervals; a fixed per-task delay; runs only while the app is open and the Mac awake; one catch-up run; `~/.claude/settings.json` allow rules apply; Run now plus "always allow"; SKILL.md holds only name, description and prompt. |
| https://support.claude.com/en/articles/13854387-schedule-recurring-tasks-in-claude-cowork | read 2026-10-01 | log_e5YQpxuGINL2 | Cowork scheduled tasks run remotely and can't be tied to a folder on the computer, so the tune-up must be a Local task. |

Reused, not re-read (read 2026-10-01 by spp-p20a's helpers and logged in `notes/gap-facts-g01.md` and `notes/gap-facts-g02.md`; owner rule 3, prove once):
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/repository-access-and-collaboration/permission-levels-for-a-personal-account-repository
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/repository-access-and-collaboration/inviting-collaborators-to-a-personal-repository
- https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository
- https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-outside-collaborators/adding-outside-collaborators-to-repositories-in-your-organization (on a paid plan each outside collaborator on a private repo uses a license: `gap-facts-g01.md` fact F23)
- https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization

**Live reads** (UTC on 2026-10-01; every one read-only; scripts in this session's scratchpad `p20d/`):

| Time | What | Route | Result |
|---|---|---|---|
| ~20:58Z | Remotes and HEAD of `~/.agents`, the connector repo and `~/Alex-Director` | git | agents-home pushes to GitHub and to a second URL, `agency-mini:agents-home`. The Director home's remote is `github.com/increase-roas/alex-director`. |
| ~21:00Z | Repo metadata and collaborators: agents-home, master-connector-repo, alex-director, one-shot-builder, agency-agent-os; org increase-roas | `gh api` GETs, outside the sandbox (inside it gh can't reach the keychain or verify TLS) | All five private. agents-home, master-connector-repo and agency-agent-os belong to the user account increaseroasir; alex-director and one-shot-builder to the org. Each repo's only collaborator is increaseroasir (admin). Org: Team plan, 3 seats, 1 filled, base permission read, 2FA requirement off, 1 member, 26 repos. |
| ~21:01Z | GitHub main vs this Mac | `git ls-remote` (no fetch, so no local refs changed), then `git rev-list --count` | agents-home: GitHub ae2136d, Mac df32e15, +40. master-connector-repo: f1b1355 vs 9cf8540, +17. alex-director: 2f2296c (last push 2026-09-02) vs 836f93f, +46. one-shot-builder: dcae73c on both. agency-agent-os: GitHub main 3f3fd4b vs the Mac's branch fix/javar-maintenance-reporting 4cc5839 (23 on the branch only, 10 on main only; GitHub's copy of the branch is ace2b73, 6 behind). |
| ~21:03Z | Orgo computers (the one read-only check that touches Javar's computer) | `orgo_op.py orgo --json computers list`, filtered in memory to id, name, status, size and workspace; the raw response was neither printed nor saved, and nothing ran on any computer | 7 computers, all running. Javar's is "EA", d9b475e2-47b2-46d4-b8eb-102564f93283, workspace "EA (Lil smoove - javar)", 4 CPU, 16 GB RAM, 50 GB disk, created 2026-08-07. |
| 21:05Z | The tune-up task | `list_scheduled_tasks`, `list_task_runs`, the task's SKILL.md, the desktop app's `scheduled-tasks.json` (named fields only), `.claude/settings.local.json` | §7 |
| ~21:10Z | Skills inventory | Python: the `~/.agents/skills` folders against `[[skills.config]]` in `~/.codex/config.toml` (tomllib; nothing else in that file was read), `vendor-lock.json`, the `~/.claude/skills` links, the claude.ai sync manifest, two saved Claude Code init events | §5 |
| ~21:12Z | Workbook rows cited here | openpyxl read-only on the live workbook (sha256 first 16: 0801635d515654f9; 31 tabs) | Every `workbook <tab> R<n>` in the six files was checked against this file, not the 15:48 export. |
| ~21:15Z | Which cited repo files a clone would have | `git ls-files` against every repo path cited anywhere in the live workbook | 111 distinct paths cited, 105 on disk, 53 never committed (49 in `work/2026-10-01_setup-playbook`, 4 in `work/2026-10-01_chatgpt-claude-research`). |

## 3. G03: the connector repo and the shared home

- **Owner and address.** Both repos are private, belong to the user account increaseroasir, were created on 2026-10-01 and have the owner as their only collaborator: `https://github.com/increaseroasir/agents-home.git` (→ `~/.agents`) and `https://github.com/increaseroasir/master-connector-repo.git` (→ `~/Projects/master-connector-repo`).
- **Why the connector repo is needed, and why its path is fixed.** agents-home's post-commit hook runs `cards_to_sheet.py`, which writes the workbook at exactly `~/Projects/master-connector-repo/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx` and copies it to `~/Documents` (cards_to_sheet.py L15–L18). The risk tiers (`tools/README.md`) and golden tasks (`system/evals/golden-tasks.md`) exist only there. So the clone goes in right after agents-home (new step 3.1b), before the first card commit.
- **What was already covered.** The Student starter kit tab (placed from G02) has the invite, accept, sign-in and clone steps (R12–R19). G03 adds only what was missing: Rebuild step 0.4 (R19) names three repos and leaves out master-connector-repo, and Phase 3 never clones it.
- **GitHub is further behind than G02 recorded.** agents-home +40 and master-connector-repo +17 (G02 counted +31/+10 at about 20:25Z and +36/+16 at 20:52Z; Student starter kit R27 still says +31/+10).
- **A push alone isn't enough.** 53 of the 111 repo files the workbook cites were never committed, including `notes/v05-app-instructions.md`, `notes/app-batch.md`, `notes/skills-cap.md`, `notes/skills-vendoring.md` and the four research notes `r1`–`r4` that `build_tabs.py` reads as its own research corpus. A clone made after a push still lacks them.
- **Second push address.** This Mac's `~/.agents` config pushes `origin` to GitHub and to `agency-mini:agents-home` (an SSH host name). No script sets it (`git_setup.sh` only creates the GitHub remote) and no note explains it. Not contacted: NOT_PROVEN.

## 4. G17: the chat-app instruction blocks

- **Exact text.** Block 1 is `notes/v05-app-instructions.md` L15–L22 and block 2 is L28–L35, both 8 lines with an empty line 2. Recomputed here: block 1 has 1,246 characters, sha256 first 32 `1fa79bcd2a1c80aebd3ec6de89a679f1`, and block 2 has 1,336 and `564f52850aa752919f70ac8481d449a3`. These equal the fresh-load readbacks in `app-batch.md` (claude.ai at 20:50Z after Alex's Save; ChatGPT at 20:24:50Z). With one trailing newline the hashes become `2614d7bb…` and `e2556b1c…`, so the check catches that difference.
- **Where to paste.** The help article says your initials > Settings > "Instructions for Claude". The live page on 2026-10-01 had it under Settings > Account > Profile (`app-batch.md` §7), and the row gives both. ChatGPT has two entries under Custom instructions. The block goes in the one named "ChatGPT"; the other one, "Custom instructions", holds the Codex instructions (`app-batch.md` §8).
- **Limits.** Anthropic publishes no limit for the claude.ai field. For ChatGPT, Exa's cached FAQ says 1,500 characters for the longer fields, while spp-p4a read 5,000 for paid plans earlier the same day. Block 2 (1,336) fits both, so the difference changes nothing here.
- **V05's open question is answered.** Both phone apps read GHL rules "from IR notes through Composio" (T1 PASS on Claude, transcript L36; on ChatGPT, transcript L8 and L28). So the official ChatGPT plugin does reach the IR notes tool the blocks rely on.
- **New and not run:** the person's check in G17 §4 step 3 (copy the field, then `pbpaste` into a Python one-liner). The 2026-10-01 readbacks used a page script through Claude in Chrome.

## 5. G18: today's active skill set

- **Codex.** The app-server inventory found 63 enabled: 58 from `~/.agents/skills` (24 own + 34 vendored) and 5 system skills (`skills-vendoring.md` L352). The exec-session catalogs showed 61 or 62 because they listed 3 or 4 of the system skills; that is the 1-skill gap `skills-cap.md` L171–L173 left unchecked. Re-derived here from live files: 160 skill folders, 166 off-switches (102 shared folders, 7 template copies under `repo-conform/assets/universal-skills`, and 57 plugin skills: compound-engineering 30, remote Superpowers 15, others 12), giving 58 on and 102 off. The 5 system skills on disk are imagegen, openai-docs, review-agent, skill-creator and skill-installer. config.toml's hash had moved again (sha256 first 16 `3f2d12b60d8d607e`; it was `625a30d1…` at 20:52Z), so other plays are still editing it.
- **Claude Code.** A fresh terminal session on 2.1.287 had 67: 29 links (18 own + 11 Superpowers), 19 built-ins and 19 synced from claude.ai (T7 final init event). The "49" in the brief came from the 2.1.251 terminal at 20:39Z (`claude-init-after-phase2.json`: version 2.1.251, 0 `anthropic-skills:`), which can't sync claude.ai skills. The two init lists differ by exactly the 19 synced skills and a few built-ins.
- **Claude app.** 9 uploads are on and 6 switched off (`app-batch.md` L202–L212). This Mac's sync cache (`~/.claude/skills/synced/…/manifest.json`, last updated 20:38:23Z) lists 19: 9 uploads, 6 Anthropic examples and 4 Anthropic document skills.
- **The lock.** `vendor-lock.json` (`agents-home` 9de9e66) pins Superpowers at tag v6.4.2, commit 8ca22db, where every file matched upstream "blob for blob". It pins compound-engineering at tag compound-engineering-v3.30.2, commit bb5899b. Both are MIT. That closes "the Superpowers source was never checked".
- **The 14 skills from the prelim** (the export's Skills tab: R2, R11, R16, R18, R23, R38, R59, R81, R98, R114–R117, R124):
  - 10 were moved into `~/.agents/skills`: 9 in `fc064e5` ("9 Claude-only folders moved in") and skool-apify-scraper earlier, in `4f919c1`. Of those, html-video-production was retired in `6a9fa95`.
  - 4 are untouched in `~/.cursor/skills`: manus-skill-builder, orgo-hermes-docs, the Manus skill-creator and speak-normal. No decision row names them, and Cursor is outside this mission.
  - Only transcript-to-workflow-opportunity-mapper is active anywhere, through its claude.ai upload. Its `~/.agents` copy is byte-identical to the synced upload (sha256 first 16 `80cca29d690e251a`).
- **The 2 Claude-app-only skills** (hermes-boss-director, native-fix-research) are still only on claude.ai. Their only local copies are sync caches. The workbook's own step (Skills, where they live R61: copy both into `~/.agents/skills` first) hasn't been done.
- **The active set can't be regenerated from git.** The 29 links and the off-switches live only on this Mac. The scripts that made them (`skills_cap_phase_b.py`, `scripts/phase2_agents.py`, `scripts/phase2_codex.py`) and `zips/build_zips.py` were never committed. So G18 lists the set by name.

## 6. G19: the Director home

- **Remote and owner.** `https://github.com/increase-roas/alex-director.git`: private, owned by the organization increase-roas, created 2026-09-02. Its last push was 2026-09-02 (GitHub main 2f2296c), and this Mac is 46 commits ahead, with 53 untracked and 2 modified paths. The org is on the Team plan (3 seats, 1 filled), its base permission is Read, its 2FA requirement is off, and it has one member and 26 repos.
- **What a clone brings.** The ledger `DIRECTOR_STATE.md` is tracked, so a clone carries the owner's missions. Only 9 of the 64 files in `mission-graphs/` are tracked, and this mission's own graph isn't one of them.
- **Dependencies.** `~/Documents/One-Shot-Builder` (`github.com/increase-roas/one-shot-builder`, private, in step with GitHub at dcae73c) holds RULES.md, whose §10 is read before spawning workers, and `scripts/check.sh`, the "check script": 12 checks, including mirror equality (check 5) and local equals remote (check 12). `~/STACK.md` is a link to `~/Alex-Director/STACK.md`.
- **Templates.**
  - A blank ledger mission block exists, commented out at the top of the ledger (`DIRECTOR_STATE.md` L5–L30): a `## Mission: [short name]` heading and 22 empty fields, matching `references/ledger.md` plus the fields from `gates.md` L69–L71. GitHub's 2026-09-02 copy has an older 16-field version.
  - One-Shot-Builder's `templates/TEMPLATES.md` (2026-09-02) has a Mission Template (§1) and a Director Ledger Template (§2). Both predate v2.3, and the ledger template's `## <MISSION_ID>` heading isn't a mission block to `ledger_check.py` (L28 needs `## Mission: <name>`).
  - No blank mission-graph file exists in today's format. The format is in `references/mission-graph.md` L42–L65.
  - Per the brief, nothing was written into `~/Alex-Director`.
- **W06 is done.** `zips/build_zips.py` builds the thin pointers from each skill's `claude-edition.md`, and Alex uploaded both as v5 (`app-batch.md` L142–L143). The terminal T7 run listed each pointer once (`skills-cap.md` L165).

## 7. G20: the tune-up

- **Two places define it.**
  - The prompt is `~/.claude/scheduled-tasks/connector-repo-tuneup/SKILL.md`: 19 lines, 2,593 bytes, sha256 first 16 `dae1d4e505ca3b43`, last edited 2026-10-01 06:41 EDT.
  - Everything else is in the desktop app's store, `~/Library/Application Support/Claude/claude-code-sessions/<account>/<org>/scheduled-tasks.json` (817 bytes; only named fields read). It holds the id, the display name "Connector repo tune-up (every 8 hours)", cron `0 */8 * * *`, enabled, the working folder `/Users/alexlobaito/Projects/master-connector-repo`, one saved approval (WebFetch, domain backend.composio.dev), created 2026-10-01 05:59:03Z, and the last slot `2026-10-01T20:00:00Z`. No model, permission-mode or worktree field is stored.
- **Schedule as it runs.** The list tool reports "At 0 minutes past the hour, every 8 hours, every day", jitter 716 seconds, next run 2026-10-02 04:11:56Z. The 20:00Z slot equals 16:00 EDT, so the cron runs in the Mac's local time (an inference from the store, not from documentation). The ~12-minute offset is the app's fixed per-task delay.
- **Runs.** 3 on 2026-10-01, all succeeded: 06:00:49Z (about 2 minutes after creation), 12:12:31Z and 20:12:15Z.
- **Allow rule.** `Bash(python3 /Users/alexlobaito/.agents/skills/weekly-tuneup/scripts/tuneup.py:*)` sits at `.claude/settings.local.json` L9, and that file is untracked, so a clone doesn't bring it.
- **Recreate route.**
  - Desktop app: Routines > New routine > Local. The picker can't express "every 8 hours", so ask Claude in a desktop session to set it.
  - A Cowork scheduled task is the wrong kind: it runs remotely and can't use a folder on the Mac, while this task needs `~/Projects/master-connector-repo` and `tuneup.py`.
  - `tuneup.py finish` sets "Last tune-up" in STATUS.md (tuneup.py L15), which is what Rebuild step 17.3's check reads.

## 8. G24: Hermes/Javar pointers

- **Build repo.** `https://github.com/increaseroasir/agency-agent-os` is private and owned by the user account increaseroasir, the only collaborator; its last push was 2026-09-25. The Mac clone at `~/Documents/ChatGPT/Build` is on the branch `fix/javar-maintenance-reporting` and has 166 uncommitted paths.
  - Startup `INDEX.md`, `TOOLS.md` and `AGENTS.md` equal GitHub main.
  - These exist on no GitHub branch: the whole `agents/ea/runtime-update/` package, including the loader source `assets/start-with-secrets.py` and `update_runtime.py`, plus `WORKFLOWS.md`. They live only on this Mac and, as installed copies, on Javar's computer.
  - `1Password-Config.md` is git-ignored on purpose (`.gitignore` L57). The repo keeps private inputs out of git by design (`docs/PRIVATE-MATERIAL.md` L3–L7).
- **Fenced tools.** All are registered in `agents/ea/hermes-inbox/__init__.py`: javar_composio_execute at L1234, javar_meta L1252, javar_composio_discovery L1254, javar_ghl L1259 and javar_propose_message L1286. The plugin manifest `plugin.yaml` lists 8 tools and leaves out javar_ghl, javar_meta and both Composio tools: the manifest has drifted from the code (Javar's lane; not touched).
- **The 1Password loader** is `/home/orgo/lil-smoove/home/.hermes/start-with-secrets.py` on his computer (`1Password-Config.md` L10). It reads Javar's own vault, "Agent — EA-Javar — PROD", which is separate from the Connectors vault in G06's catalog. No item IDs, references, Slack IDs or values were copied into G24.json; it points to file and line only.
- **The Orgo read.** One filtered metadata read (§2). The 7 computers match the fleet plan's roles (`work/2026-10-01_fleet-and-offmac/plan.md` L7).

## 9. Checks

All results below were observed on 2026-10-01 at about 21:35Z. Script: `p20d/validate_p20d.py` in this session's scratchpad. It is spp-p20a's `validate_gap_facts.py` with two changes: its file list is the six files of this play, and it uses the builder's own `RESEARCH`, which since spp-p20a already includes `notes/gap-facts*.md`.

- **Builder validation.** `build_tabs.py`'s own `check_source`, `scan_text` and the Excel cell limits ran over the 6 files and 133 rows, plus each file's title, target, closes and not_proven text.
  - **First run:** 0 problems. Spot checks against live data then found 5 wrong cells: `agents/javante` is untracked, not tracked; the hub repoint step is 8.5 in the live tab, not 8.4; the composio plugin adds no skill in the terminal; the exact split of tracked and untracked Javar guides; and the Routines location. All were corrected and the files regenerated.
  - **Final run:** 0 problems, 0 warnings.
- **Secret scan, two methods, over the 6 files and this note:**
  - the builder's 10 secret-shape rules: 0 hits;
  - every token checked against spp-p20a's sha256[:16] of every CONCEALED value and document in the Connectors vault: 0 hits.
- **Hash rebuilds (numbers recomputed from the rows themselves):**
  - G17 block 1 rows give 1,246 characters and `1fa79bcd2a1c80aebd3ec6de89a679f1`, which matches the claude.ai readback;
  - G17 block 2 rows give 1,336 and `564f52850aa752919f70ac8481d449a3`, which matches the ChatGPT readback;
  - G20's 19 prompt rows give `dae1d4e505ca3b43`, equal to the task file. The file has no final newline: the first comparison added one and failed, which is how that was found.
- **Negative check 1: the URL rule.** The same validation with this note removed from `RESEARCH` gives 13 "URL not in the research notes" problems, exactly the rows citing the 6 URLs this play read. The 5 reused GitHub URLs still pass through spp-p20a's notes. So the rule bites, and this note is what makes the 6 URLs pass.
- **Negative check 2: client names.** The 43 names in `knowledge/clients.md`, searched in every cell (source columns included) and in this note: 0 hits.
- **All gap files together.** spp-p20a's own validator, unchanged, over all 23 files now in `tabs/gap-facts/` (other plays added G04, G07–G11 and G13): 0 problems, 0 secret shapes, 0 vault values. Its 43 warnings ("looks like a 1Password item id") come from other plays' files; this play's files have none.

Output of the final run (`p20d/validate_p20d.out`):

```
RESEARCH files: 18 | includes gap-facts-repos.md: True
files: 6 rows per file: {'G03.json': 8, 'G17.json': 24, 'G18.json': 35, 'G19.json': 14, 'G20.json': 33, 'G24.json': 19} total 133
PROBLEMS (0)
WARNINGS (0): {}
SECRET SHAPES (0)
VAULT SECRET VALUES FOUND (0)
CLIENT NAMES IN ANY CELL OR NOTE (0)
G17 block 1 (claude.ai): 1246 characters, sha256[:32] 1fa79bcd2a1c80aebd3ec6de89a679f1 -> MATCH
G17 block 2 (ChatGPT): 1336 characters, sha256[:32] 564f52850aa752919f70ac8481d449a3 -> MATCH
G20 prompt rows (file has no final newline): sha256[:16] dae1d4e505ca3b43 vs file dae1d4e505ca3b43 -> MATCH
```

**verify-before-done (normal stakes: internal source files; nothing written to any tool or account):**

| Check | How | Result |
|---|---|---|
| Done means: one file per gap, rows a newcomer needs, a source on every row | 6 files; the builder validation passes every source cell | Met |
| G03: owner and URL of both repos, clone steps, access | GitHub API and git reads (§2) against G03 §1–§2; invites point to the placed Student starter kit rows | Met (no push, per the brief) |
| G17: both saved blocks as rows, where to paste, how to check | Rows rebuild both read-back hashes exactly | Met (the person-run check is new and not run) |
| G18: active set, the home of every skill, the 14 plus what was done | Live re-count (58 on, 102 off, 29 links, 19 synced) against the notes; each of the 14 located on disk and in git history | Met |
| G19: remote and owner, clone step, templates or "none" | gh and git reads; the ledger's own blank block; One-Shot templates checked against `ledger_check.py` | Met: blank ledger block exists (inside the ledger), no blank graph file; nothing written into `~/Alex-Director` |
| G20: where the task is defined, schedule, prompt, recreate steps | list_scheduled_tasks, list_task_runs, the two files it lives in, the vendor doc | Met |
| G24: pointers to the real homes, at most one check of Javar's computer | Build repo files and git state; one filtered Orgo metadata read | Met: one read, nothing ran on his computer |
| Numbers recomputed from source | Commit gaps (rev-list), the 166 off-switches, 58/102, the 29 links, 19 synced, 7 computers, 111/105/53 cited files, both block hashes, the prompt hash | Match. G02's commit gaps had grown (updated here). |
| Citations | The builder checks paths, lines, sections and quotes on every source; this play read each of its own 6 URLs (§2); the reused URLs were read today by spp-p20a | Pass |
| Negative checks | No-notes run: 13 URL failures. Client names: 0. Secret shapes and vault values: 0 | Pass |
| Couldn't check | Invites end to end, `agency-mini`, the person-run paste check, check.sh and ledger_check.py on a fresh Mac, Javar's installed state | Listed in §10 |

## 10. NOT_PROVEN, and findings for the Director

**NOT_PROVEN**
1. What host `agency-mini` is, and whether pushes reach it.
2. Any invite end to end (no invite sent; no second GitHub account tried), for the user-owned repos or the org repos.
3. The person-run copy-and-`pbpaste` check of the two instruction fields (G17 §4 step 3).
4. The claude.ai field's limit, and ChatGPT's exact limit on this plan (block 2 fits both figures read).
5. How the 3 custom ChatGPT cloud skills were added; the Claude desktop app's skill count (needs a fresh session).
6. One-Shot-Builder's `check.sh` and `ledger_check.py` on a fresh machine (documented, not run here).
7. The tune-up's cron time zone (inferred) and a fresh Mac with only the project allow rule.
8. Javar's installed files and services today, and which version his computer runs. One metadata read only; nothing ran on his computer.

**Findings (not acted on; each belongs to another lane or needs Alex)**
- **A clone can't follow the workbook yet.** GitHub is behind this Mac by 40 commits (agents-home), 17 (master-connector-repo) and 46 (alex-director, last pushed 2026-09-02), and 53 of the 111 repo files the workbook cites were never committed. Committing and pushing are Alex's normal work; this play did neither.
- **Undocumented push target:** `~/.agents` also pushes to `agency-mini:agents-home`.
- **Director home:** the live ledger is tracked, so it travels with every clone, while this mission's graph is untracked. Whether the ledger should travel is an owner decision.
- **Org access is wide:** a member of increase-roas gets Read on all 26 org repos (client sites included). For Director-home access, outside-collaborator Read on two repos is the narrower route; Alex's call.
- **Skills without a home:** hermes-boss-director and native-fix-research exist only on claude.ai (the workbook's R61 step "copy into ~/.agents/skills first" isn't done). The 4 Cursor-only skills have no decision, and orgo-hermes-docs matters for the Hermes rebuild.
- **Active skill set lives only on this Mac:** the links, the off-switches, and the scripts that made them are uncommitted.
- **Build repo:** the runtime update package (with the loader source) and WORKFLOWS.md are on none of its 5 GitHub branches, and `agents/javante/setup/` is untracked and not on GitHub main. The working branch has diverged from GitHub main (23 and 10 commits). `plugin.yaml` omits 4 registered tools.
- **Tune-up:** its allow rule lives only in the untracked `.claude/settings.local.json`; nothing in git recreates the task.
- **Stale workbook cells this play's rows replace:**
  - Rebuild from zero: R19 (0.4, three repos), R141 (14.4 "waits on Alex (W07)"), R145 (15.1 "version 2.1"; it is 2.3), R148 (15.4's T7 text), R193 (G26 "a blank ledger … not written": the ledger block exists), R196 (G29 "steps … not written").
  - Skills, where they live: R24 and R61.
  - Student starter kit: R27 (+31/+10).
  - Skills: the "where it is now" cell of the 14 rows.
- **config.toml** moved again during this play (`3f2d12b6…`). The builder should re-read before applying any Codex row.

## 11. How the builder uses these files

1. **No `RESEARCH` change needed.** `build_tabs.py` L52–L55 already globs `notes/gap-facts*.md`, so this file joins the corpus as written (spp-p20a's one-line change has landed).
2. **Place the rows** by each file's `target_tab`:
   - G03 §2 "0.4 (replace the cell)" replaces Rebuild R19's text; "3.1b" goes after 3.1 (R44).
   - G20 §3 replaces step 17.3 (R162), and G20 §2 can sit on the Self-improving loop tab beside R13.
   - G17 §2–§3 are line-per-row blocks for the Templates tab.
   - G18 §3 updates the Skills tab's 14 rows.
   - G24 is a new pointer tab.
3. **Run the check:** `python3 build_tabs.py check`, then the dry run, as usual.
