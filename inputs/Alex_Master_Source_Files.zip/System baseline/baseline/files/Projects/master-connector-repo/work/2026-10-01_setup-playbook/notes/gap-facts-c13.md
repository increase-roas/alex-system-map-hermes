# Gap facts, spp-c13: G12 and G21 leftovers from the interim retest (Conductor, 2026-10-01)

All reads were on 2026-10-01. Composio's REST API was called with GET only and the key read from `~/.composio/user_data.json`; no key or secret was printed. Web pages were read through Composio Exa.

## 1. Header names for the two upstream API-key routes (G12 leftover 1)

| Toolkit | Upstream (Composio `base_url`) | Header the upstream documents | Source |
|---|---|---|---|
| `custom_cloudflare_api` | `https://mcp.cloudflare.com/mcp` | `Authorization: Bearer <Cloudflare API token>` | Cloudflare's README, "Option 2: API Token": "MCP URL `https://mcp.cloudflare.com/mcp` / Bearer Token: Your Cloudflare API Token". It also says "Both user tokens and account tokens are supported", account tokens need "Account Resources : Read", and "API tokens with Client IP Address Filtering enabled are not currently supported". https://github.com/cloudflare/mcp/blob/main/README.md (read 2026-10-01) |
| `custom_foreplay` | `https://public.api.foreplay.co/mcp` | `Authorization: <Foreplay API key>` (no Bearer prefix) | Foreplay Public API: "Every request to the API requires your key to be sent in the `Authorization` header", followed by "Authorization: YOUR_API_KEY". https://public.api.foreplay.co/docs (read 2026-10-01). The MCP URL is in https://help.foreplay.co/articles/0009441-what-is-the-foreplay-mcp (read 2026-10-01) |

- **What Composio records for both:** auth scheme `API_KEY`, one field `generic_api_key` ("Your API key for this app. It is stored securely and only sent to this app's server."). Source: `GET /api/v3/toolkits/<slug>`, `auth_config_details`.
- **Not recorded:** neither the toolkit nor its auth config (`GET /api/v3/auth_configs`) returns the header template the toolkit was registered with.
- **Live use:** both routes have answered live calls (the Foreplay usage read on 2026-10-01, the Cloudflare card), so whatever template is registered works.

## 2. Looking up x-project-id for a new org (G12 leftover 2)

- **Two surfaces:** Composio's docs say the dashboard has two surfaces, Platform (developer projects, project API keys, auth configs) and For You (a person's apps for agents), and "Resources in one surface do not automatically appear in the other". https://docs.composio.dev/kb/guide/dashboard-navigation-overview (read 2026-10-01)
- **Platform projects:** "Open Platform → Settings for the selected project." The settings pages are General, API Keys, Webhooks, White Labeling and others. https://docs.composio.dev/kb/guide/dashboard-project-settings-navigation (read 2026-10-01)
- **API:** `GET https://backend.composio.dev/api/v3/org/project/list` with `x-user-api-key` and `x-org-id` returns the org's Platform projects. Here that's one, named "alex_workspace_first_project", whose ID starts `pr_UFj`. It is **not** the project the connector logins live in (`pr_JDtrNq9tUa_i`, the For You project).
- **Without x-project-id:** `GET /api/v3/connected_accounts` returns 0 logins. So a new org can't discover its For You project ID through the API.
- **Where the values come from:** `~/.composio/user_data.json` holds `api_key`, `base_url`, `org_id`, `test_user_id` and `web_url`, but no project ID.
- **NOT_PROVEN:** where the dashboard shows the For You project's ID for a new org. The docs page covers Platform projects only.

## 3. The GHL builder's DCR auth config (G12 leftover 3)

- **Live config:** `GET /api/v3/auth_configs`, toolkit `custom_ghl_command_builder`, shows:
  - auth scheme `DCR_OAUTH`, `is_composio_managed: false`;
  - credentials `scopes` = `mcp:read`, `mcp:write`, `offline_access`;
  - `oauth_redirect_uri` = `https://backend.composio.dev/api/v1/auth-apps/add`.
- **Create body (derived):** the documented API_KEY create shape on the Composio custom routes tab, with the live DCR values:
  `{"toolkit": {"slug": "custom_ghl_command_builder"}, "auth_config": {"type": "use_custom_auth", "authScheme": "DCR_OAUTH", "credentials": {"scopes": ["mcp:read", "mcp:write", "offline_access"]}, "is_enabled_for_tool_router": true}}`
- **NOT_PROVEN:** that Composio accepts this exact body for DCR_OAUTH. No create call was run; the live config was made earlier.

## 4. Health check settings (G21 leftovers)

**Code:** `~/.agents/tools/connectors/health/health_check.py` (agents-home repo, last commit b7d8f65):
- line 28 builds the Composio headers from `composio_org` and `composio_project`;
- line 38 sends `composio_user` as `user_id`;
- lines 101–107 are the home-exit check.

| Setting | Where the value comes from | Evidence |
|---|---|---|
| `composio_org` | `org_id` in `~/.composio/user_data.json` (written by `composio login`) | config.json's value equals user_data's `org_id` (checked 2026-10-01, equality only) |
| `composio_project` | the For You project's ID, sent as `x-project-id` | config.json's value equals `pr_JDtrNq9tUa_i`. The lookup for a new org is NOT_PROVEN (§2) |
| `composio_user` | the `user_id` that owns the logins: `GET /api/v3/connected_accounts` with the three headers, field `items[].user_id` | One distinct value across the logins, and config.json's value equals it. It is **not** user_data's `test_user_id` (they differ) |
| ISP line | line 105: `ok = "comcast" in org.lower()`, after line 101 asks `https://ipinfo.io/org` through the exit node (`socks5h://localhost:1055`). Line 106 holds the label "home IP (Comcast)" | On another home ISP, change `"comcast"` on line 105 to a lowercase piece of that ISP's ipinfo.io org name, and update the label on line 106. NOT_PROVEN: the org string for other ISPs. Get it by running `curl -s https://ipinfo.io/org` on the exit node |
