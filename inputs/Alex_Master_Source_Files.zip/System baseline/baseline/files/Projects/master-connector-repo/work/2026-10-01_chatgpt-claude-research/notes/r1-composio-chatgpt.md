# R1: Composio in ChatGPT, the strongest route on every surface

Job: `work/2026-10-01_chatgpt-claude-research` · Note r1 · 2026-10-01 · Claude Code research helper, read-only (no installs, sign-ins, UI or config changes).
Labels: **SEEN** = read back live or in a cache written today · **FILE** = on disk · **DOC** = vendor docs · **NOT_PROVEN** = not checked yet.
Times are UTC (the Mac is UTC-4).

## 1. Verdict

**Use one route: the official Composio plugin from the ChatGPT Plugins Directory (v1.0.1, developer "Sampark Inc", app `asdk_app_6a58503580c08191b78cc5bdaf4eba6e`). Sign in once as alex@increaseroas.com and pick org wearenumber1. Add nothing else for Composio in ChatGPT.**

Why, in plain words:
- It is the only option built for every surface: ChatGPT web, desktop, phone, ChatGPT Work (which replaced agent mode), dots, and Codex in the desktop app (DOC). In Codex it already worked 09:41–09:48Z today (SEEN).
- It can write. ChatGPT's normal app permissions decide when it asks first (DOC).
- It needs no developer mode and runs nothing on the Mac. OpenAI periodically re-checks its tool definitions (DOC).
- It reaches the same Composio server as a hand-added connector (`https://connect.composio.dev/mcp`, per Composio's README). It sees the same connections as Alex's CLI: the same connection IDs show up in both (SEEN). A hand-added connector would only add limits.
- The old Codex plugin v0.2.3 added nothing ChatGPT needs. Its app link points at Composio's own test app, its skill is the same one v1.0.1 ships, and its 2 hooks only add hints plus an unreviewed daily self-update. They show no sign of ever running here (section 4).

**Already done by the other chat (SEEN):** by 18:02Z, v0.2.3, its marketplace entry and its cache were gone from `~/.codex`. v1.0.1 is installed at `~/.codex/plugins/cache/openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e/1.0.1/`, and it has no hooks folder. Nothing here needs undoing. I found no copy of v0.2.3 in `~/Backups`, but it can be fetched again from GitHub at commit `3c0aab4`.

## 2. The three options

- **(a) Directory plugin.** Catalog entry `plugin_asdk_app_6a585035…` v1.0.1, author "Sampark Inc", `authentication_policy: ON_INSTALL`, `eligible_plan_types: null`. It bundles the hosted app plus the `composio` skill and has no hooks (FILE: `~/.codex/cache/remote_plugin_catalog/b2ecdcc97a3b9502.json`, fetched 2026-10-01T16:33Z, and the installed copy).
- **(b) Codex plugin `composio@composio` v0.2.3** from github.com/ComposioHQ/composio-plugin-openai (commit `3c0aab4`, 2026-07-29). It has the same skill, 2 hooks, and an `.app.json` pointing at `plugin_asdk_app_6a57f13d63988191ae58e8494105a461`. Composio's README calls that its "team-owned Composio Developer Mode app". That ID never appears in Alex's app directory or app-tool caches (FILE). In ChatGPT the plugin therefore contributed nothing (inferred).
- **(c) Hand-added MCP.** Settings → Security and login → Developer mode, then chatgpt.com/plugins → + → `https://connect.composio.dev/mcp` → Composio sign-in (Composio docs; OpenAI developer docs).

## 3. Comparison

### Where each one works

| Surface | (a) Directory plugin | (b) Codex plugin v0.2.3 | (c) Hand-added MCP (developer mode) |
|---|---|---|---|
| ChatGPT web | Yes (DOC) | No, Codex-only local plugin | Yes, web is the documented surface (DOC) |
| ChatGPT desktop, Chat | Yes (DOC) | No | NOT_PROVEN (docs say "on the web") |
| Phone | Yes, once installed on the account (DOC) | No | No: Help Center says web only (DOC) |
| ChatGPT Work cloud (replaced agent mode), dots | Yes: plugins and apps work in Work and dots (DOC). Not tested | No: plugin hooks aren't supported in cloud Work, and the local plugin isn't deployed (DOC) | Old agent mode wouldn't use custom apps (DOC). Work: NOT_PROVEN |
| Codex in desktop app (Local) | Yes: 9 tools exposed (FILE). Worked 09:41–09:48Z (SEEN). One hosted-task call failed 17:20Z with "Unknown tool" (SEEN report) | Skill and hooks only. The app ID never resolved | Probably: another of Alex's developer-mode apps shows up in Codex (FILE). Untested for Composio |
| Codex CLI | Expected (same `~/.codex`; apps are on by default with ChatGPT sign-in). NOT_PROVEN | Yes (skill; hooks only if trusted) | NOT_PROVEN |
| Codex Cloud tasks | Not a listed plugin or connector surface (glossary) | No | No |

### How each one behaves

| | (a) Directory plugin | (b) Codex plugin v0.2.3 | (c) Hand-added MCP |
|---|---|---|---|
| Write actions and plans | Yes. Composio's execute tools are marked as writes. The directory is open across plans; in a Business workspace the admin controls apps (DOC) | ChatGPT: none. Codex: CLI writes run as shell commands under Codex's own policy (here full access, never asks) | **Docs conflict.** Developer docs: read and write for Plus, Pro, Business, Enterprise and Edu on web. Help Center: full writes only for Business, Enterprise and Edu; Pro gets read/fetch only. The test decides |
| Sign-in and Composio account | Composio OAuth at install, where you pick the org. It binds to the member's own connections in the org's consumer ("Connect / For You") project (DOC). Current link owner: an increaseroas.com identity, "Alexander" (FILE). Same connection IDs as the CLI (SEEN) | App part: Composio's private developer app, so no binding for Alex. CLI part: `composio login` = alex@increaseroas.com, org wearenumber1 (SEEN `composio whoami`) | Same OAuth and org pick as (a), as a separate second link. Clients without OAuth can use an `x-consumer-api-key` header instead (DOC) |
| Tool discovery | 9 meta-tools (FILE): search, schemas, multi-execute (≤50 parallel), manage/wait connections, remote bash (180 s cap), workbench, feedback, skills. The 1,000+ toolkits are found at run time, so no ChatGPT tool-count limit is hit | CLI: any slug through `composio search` / `execute`, plus `composio proxy` | Same meta-tools. The tool list is a snapshot until you press Refresh. A Business-published custom app stays frozen until an admin refreshes it (DOC) |
| Approval prompts | ChatGPT: Always ask / Allow read / Allow low-risk / Allow all (for an eligible personal account). Cards offer Allow once or Always allow; managed workspaces get no persistent Always allow (DOC). Codex: `[apps.asdk_app_6a5850…] default_tools_approval_mode = "approve"` (FILE) | Hooks: trust once in `/hooks`, then they run silently every session. CLI: Codex sandbox and approval policy | Writes ask by default. Tools without `readOnlyHint` count as writes, which includes Composio's execute tools. "Remember" lasts one conversation, and new chats ask again (DOC) |
| Updates | Composio publishes new versions through OpenAI review. Tool changes go through continuous review: deleted tools drop at once, new and changed tools apply after automated checks. Codex picks up directory changes within 6 h (DOC). Nothing runs locally | Self-updates daily through its hook from GitHub's default branch (install record had `ref_name: null`, so nothing pinned). Changed hooks need re-trust; skill or app-ID changes apply silently | Manual Refresh in plugin settings |
| Runs code on the Mac | No | Yes, if hooks are trusted | No |
| **Decision** | **Use** | Removed; keep it removed | Don't add |

## 4. The 2 hooks in (b)

I read them from `~/.codex/plugins/cache/composio/composio/0.2.3/hooks/` at about 17:50Z, before the removal at 18:02Z. GitHub main still has the same code at version 0.2.3 (live crawl today).

**Hook 1: SessionStart, `session-start.sh`** (runs on startup, resume, clear and compact; 8 s timeout)
1. Toolkit list: if `composio` and `jq` are installed, it runs `composio dev toolkits list --limit 50`. That is a network call using the CLI's stored login. It saves 50 popular toolkit names to `$TMPDIR/composio-plugin-toolkits.cache`. These come from Composio's public catalog, not Alex's connections.
2. Self-update: if `codex` is on PATH and the last attempt was over 24 h ago, it writes a stamp to `~/.composio/plugin-codex-self-update.json`. It then starts a detached background job, with output discarded and never waited on, that runs:
   - `codex plugin marketplace upgrade composio`, which pulls the GitHub repo;
   - `codex plugin add composio@composio`, which installs whatever version is there.

   The new version loads next session. Nothing is pinned and OpenAI does not review it.
3. CLI status: it runs `composio whoami` and reads `~/.composio/update-check.json` so it can suggest `composio upgrade`.
4. It adds developer context telling the model to prefer the local CLI in Codex, use the hosted app only as a fallback, and never retry an uncertain write on the other surface.

**Hook 2: UserPromptSubmit, `user-prompt-submit.sh`** (runs on every prompt; 5 s timeout)
- It exits unless the toolkit cache exists and `composio` is installed.
- It reads Alex's full prompt locally and looks for any of the 50 cached names as a whole word (gmail, slack, linear, canvas, cal, exa, reddit and so on).
- On a match it adds a one-line "prefer the CLI" hint. It makes no network call and cannot block a prompt.

**What runs outside the sandbox: all of it.** Codex starts hook commands as plain child processes through the user's login shell (`$SHELL -lc`) with the session's environment. The hook runner has no sandbox call. A code comment says completed hooks "may intentionally leave detached helpers running" (`openai/codex` `codex-rs/hooks/src/engine/command_runner.rs`, cached copy). So these all run with Alex's full user rights and no approval prompt:
- the Composio API call;
- the GitHub pull and the plugin reinstall, which write under `~/.codex`;
- the writes to `~/.composio` and `$TMPDIR`.

On this Mac that changes little, because Codex already runs with `sandbox_mode = "danger-full-access"` and `approval_policy = "never"` (FILE).

**Did they ever run here?** There are strong signs they did not, but this is NOT_PROVEN:
- `~/.composio/plugin-codex-self-update.json` does not exist. `codex` is at `~/.local/bin/codex` and hooks run in a login shell, so the first run would have created it.
- None of the 44 Codex session files since install (2026-09-30 22:44Z) contains the hook's context line.
- Codex "skips plugin-bundled hooks until you review and trust" them (DOC), and I found no trust record.
- The `$TMPDIR/composio-plugin-toolkits.cache` file that does exist comes from the Claude Code Composio plugin v0.2.4, which uses the same file name.

**What breaks without them: nothing that works today.**
- The hosted app and the CLI work without hooks.
- The routing advice lives in the `composio` skill. v1.0.1 ships that skill with the same text and the same file sizes (2383 / 1312 / 1765 / 196 bytes).
- What is lost: the per-session "CLI signed in?" line, the keyword nudge, the CLI-upgrade nudge, and the silent self-update. v1.0.1 updates through OpenAI's directory instead.

**"Trust its 2 hooks"?** No. They add hints, and the self-update installs unreviewed code from GitHub with full user rights. With v1.0.1 they are not needed.

**Related, outside ChatGPT:** the Claude Code Composio plugin v0.2.4 has the same self-updating SessionStart hook (`claude plugin marketplace update` + `claude plugin update`), and it has run: `~/.composio/plugin-cc-self-update.json` shows 2026-09-30T23:51:38Z, result "current" (FILE).

## 5. "Sampark Inc is Composio's legal name": confirmed

- Primary: composio.dev/terms says "Sampark Inc, doing business as Composio".
- Primary: composio.dev/legal/dpa says "Sampark, Inc. dba Composio, a Delaware company", with an office at 2 Bryant St., San Francisco.
- Secondary: Crunchbase lists the legal name as Sampark Inc. The MIT AI Agent Index cites Delaware entity SAMPARK INC, file 7417658.
- Local: the installed v1.0.1 manifest names author "Sampark Inc" and links composio.dev for its website, terms and privacy pages (FILE).

## 6. Test plan (one read and one reversible write per surface)

**Setup, once:**
- Check that the Composio plugin is connected as alex@increaseroas.com with org wearenumber1.
- For the test, set Composio's permission to Always ask so every call is visible.
- Use a new chat on each surface.

**Read (proves the account, not just the app).** Ask: "Use Composio to run CUSTOM_IR_NOTES_GET_APP_RULES for app cloudflare." Pass means `successful: true`, and the search shows the active connection `custom_ir_notes_privy-bulse`, the same ID the CLI lists under wearenumber1.

**Reversible write.** Ask: "Use Composio Gmail to create a draft to alex@increaseroas.com, subject 'composio route test – <surface>', body 'test'. Do not send. Then delete that draft." Pass means:
- a draft ID comes back;
- the draft appears in Gmail;
- the draft is gone after the delete.

If Composio asks which Gmail account to use, pick alex@increaseroas.com. Never send.

| Surface | Read | Write | Also record |
|---|---|---|---|
| ChatGPT web, Chat | as above | as above | approval cards shown |
| ChatGPT desktop, Chat | as above | as above | same |
| iPhone app (note which workspace is selected) | as above | as above | whether Composio appears under + / @ |
| ChatGPT Work, cloud task (replaced agent mode) | as above | as above | whether the run pauses for approval |
| A dot (optional) | as above | as above | same |
| Codex in the desktop app (Local) | as above, via `codex_apps` Composio tools | as above | whether any prompt appears (expected none: `approve` + `never`) |
| Codex CLI | as above | as above | whether the hosted tools appear at all |

**Negative check (Codex):** start a new Codex session, then confirm:
- `/hooks` lists no Composio hooks;
- `~/.composio/plugin-codex-self-update.json` is still absent;
- `~/.codex/plugins/cache/composio` is still absent.

## 7. Risks

1. **Two ChatGPT workspaces.** The ChatGPT sign-in is alowbaito@gmail.com, plan Pro, with workspaces "Increase Roas" and "Personal" (FILE). The plugin connection is set up per workspace, and the phone uses whichever workspace is selected. If "Increase Roas" is a Business workspace, its admin settings govern apps.
2. **Consumer and developer projects are separate.** Connections made in Composio's developer dashboard don't appear in ChatGPT (DOC). Today the CLI and the ChatGPT app share connection IDs. Connect new apps through Composio Connect or the CLI, then confirm them in ChatGPT.
3. **Possibly stale description.** Codex's cached Composio tool description says only "gmail, slack" are "manually connected" (FILE, written 16:04Z). It may be stale; the read test settles it.
4. **Cloud dispatch error.** A hosted Codex task got `Mcp error -32001: Unknown tool composio.COMPOSIO_SEARCH_TOOLS` at 17:20Z (SEEN, `~/Documents/Codex/2026-10-01/task/director-e2e-test/plugin-path-report.json`). Cloud contexts may misroute, so test Work cloud and Codex separately.
5. **Full power cuts both ways.** Composio can send, delete and run remote code (remote bash and workbench). "Allow all actions" removes the last human check, and Codex already runs with approvals off.
6. **Duplicate tool sets.** Adding (c) on top of (a) would put two Composio tool sets in every chat; an earlier live check already found two Composio entries. Keep one.
7. **CLI may refuse destructive tools.** `~/.composio/config.json` has `developer.destructive_actions: false`, so the CLI route in Codex may refuse destructive tools (not tested).

## 8. Gaps

- **INFORMATION:** Is "Increase Roas" a Business workspace, and which workspace does the phone use? Alex can see this from the ChatGPT profile menu.
- **NOT_PROVEN until section 6 runs:** phone, Work cloud, dots, Codex CLI, and the current account binding in ChatGPT itself.
- **Job folder:** `work/2026-10-01_chatgpt-claude-research/` has no `brief.md` or `checks.md` yet (the lead agent owns those).

## 9. Sources (read 2026-10-01; "updated" ages are as the page showed when crawled)

**Composio, primary:**
- https://composio.dev/terms (legal name)
- https://composio.dev/legal/dpa (legal name, Delaware)
- https://composio.dev/privacy (effective 2025-11-18)
- https://docs.composio.dev/docs/composio-connect (Connect URL, ChatGPT steps, 7 meta-tools, consumer key; live crawl)
- https://docs.composio.dev/kb/guide/consumer-project-boundaries-and-auth-selection ("Consumer-project connections are not available in the developer project.")
- https://docs.composio.dev/docs/consumer-agents (every org has one consumer project behind Connect)
- https://github.com/ComposioHQ/composio-plugin-openai (README, hooks, `.app.json`, v0.2.3; commit 3c0aab4 of 2026-07-29; live crawl)

**OpenAI, primary:**
- https://learn.chatgpt.com/docs/plugins (surfaces: web, desktop, mobile, Work, Codex. "Plugin hooks are not supported in cloud-orchestrated ChatGPT Work.")
- https://learn.chatgpt.com/docs/hooks (trust review, plugin hooks, `PLUGIN_ROOT`)
- https://developers.openai.com/plugins/build/plugins (`.app.json` → `plugin_asdk_app` mapping; Codex skips untrusted plugin hooks)
- https://developers.openai.com/plugins/guides/submit-claude-plugin (hook scripts must exist in the execution environment)
- https://developers.openai.com/api/docs/guides/developer-mode ("Available to Pro, Plus, Business, Enterprise, and Education accounts on the web.")
- https://developers.openai.com/plugins/deploy/connect-chatgpt (developer-mode setup and Refresh)
- https://developers.openai.com/plugins/deploy/app-review (continuous review of tool changes)
- https://help.openai.com/en/articles/12584461 (Developer mode and MCP apps; updated 14 days ago; "No - web only."; Pro read/fetch only; agent mode won't use custom apps)
- https://help.openai.com/en/articles/20001256 (Plugins in ChatGPT and Codex; published 2026-09-19; Codex directory refresh up to 6 h)
- https://help.openai.com/en/articles/11487775 (Connected apps; updated 2 days ago)
- https://help.openai.com/en/articles/20001495 (Managing app permissions; updated 8 days ago)
- https://help.openai.com/en/articles/11752874 ("ChatGPT agent is no longer available."; updated 27 days ago)
- https://learn.chatgpt.com/docs/enterprise/chatgpt-work-overview (plugins in Work; plugin hooks unsupported with cloud orchestration)
- https://learn.chatgpt.com/docs/dots/getting-started (dots connect services through plugins)
- https://learn.chatgpt.com/docs/glossary (surface lists for Plugin, Connector, Hook, Codex Cloud)
- https://learn.chatgpt.com/docs/config-file/config-reference (`apps.<id>.default_tools_approval_mode`; app traffic is outside the command network proxy)
- https://learn.chatgpt.com/docs/extend/mcp (the `writes` mode prompts for tools not marked read-only)
- https://github.com/openai/codex/blob/main/codex-rs/hooks/src/engine/command_runner.rs (hooks spawned via the login shell with no sandbox call; Exa cached copy, date unknown)

**Secondary:**
- https://www.crunchbase.com/organization/composio-b822 (legal name)
- https://aiagentindex.mit.edu/swe-agent/ (Delaware file number)
- https://community.openai.com/t/write-actions-blocked-on-custom-mcp-server-business-plan-workspace-developer-mode-unavailable-at-workspace-level/1384381 (June 2026; a reply says write actions are available to everyone; the poster isn't verified as OpenAI staff)
- https://composio.dev/content/best-chatgpt-plugins (2026-09-16; directory moved to the Plugin Directory 2026-07-09)
- https://composio.dev/content/connect-multiple-gmail-accounts-to-chatgpt-codex (2026-09-17; install flow for the directory plugin)

**Local evidence (FILE / SEEN):**
- `~/.codex/cache/remote_plugin_catalog/b2ecdcc97a3b9502.json`: directory entry v1.0.1, Sampark Inc
- `~/.codex/cache/codex_apps_tools/24aff18899c1788047b6e52874d38038e76acf6e.json`: 9 Composio tools, link `link_6abe9d58…`, owner domain increaseroas.com
- `~/.codex/cache/codex_app_directory/7f393ab2….json`: ECOSYSTEM_DIRECTORY, consequential
- `~/.codex/plugins/cache/openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e/1.0.1/`: no hooks
- `~/.codex/config.toml`: features.hooks on, full access, never ask, Composio app set to `approve`; v0.2.3 entries gone by 18:02Z
- `~/.codex/sessions/2026/10/01/rollout-2026-10-01T05-45-57-01a0f6db-….jsonl`: Composio app tools returned `custom_ir_notes_privy-bulse`, `custom_cloudflare_api_sari-sud`, `custom_ga4_admin_arundo-sower`
- `composio whoami` and `composio connections list` (run 2026-10-01): alex@increaseroas.com, org wearenumber1, same connection IDs
- `~/.composio/`: no `plugin-codex-self-update.json`; `plugin-cc-self-update.json` = 2026-09-30T23:51:38Z
- `work/2026-10-01_setup-playbook/notes/live-codex.md` §9 and `live-chatgpt.md` §7: earlier live-state notes
