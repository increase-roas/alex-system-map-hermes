# Student edition (node student-edition, play spp-p32a, 2026-10-01/02)

Owner decision (Alex, Director chat, quoted in the mission graph): "Yes, approved. Go ahead with the clean student copy:
a script makes a duplicate with client names swapped for Client A, Client B and so on. The real workbook and repos stay
with me and my partners." Result: VERIFIED. The build passed its leak check, and the selftest caught every plant.
No client names appear in this note.

## 1. Research (owner rule 5), read 2026-10-01

| Question | Finding | Source |
|---|---|---|
| Where can an .xlsx hide personal data? | Document Inspector checks comments, document properties and personal information (incl. comments on defined and table names), headers and footers, hidden rows, columns, sheets and names, custom XML, external links, PivotTables and invisible content. | https://support.microsoft.com/en-us/office/collab-files/remove-hidden-data-and-personal-information-by-inspecting-documents-presentations-or-workbooks ; https://learn.microsoft.com/en-us/office/vba/library-reference/concepts/using-the-document-inspector (Exa log_AjSe82haxcZN) |
| What is an .xlsx made of? | A ZIP package of XML parts: workbook (sheet names, defined names), worksheets (cells, formulas, headers and footers, hyperlink refs), relationship parts (hyperlink targets), shared strings, tables, comments, threaded comments and persons, docProps. | https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/structure-of-a-spreadsheetml-document (Exa log_taTQE8zvDEF7) |
| Can openpyxl do the rewrite? | "openpyxl does currently not read all possible items in an Excel file so shapes will be lost". The script rewrites every XML part in place and uses openpyxl only to prove the result opens. | https://openpyxl.readthedocs.io/en/latest/tutorial.html (Exa log_kpo9e72QlXCn); Context7 openpyxl docs for comments, defined names and reader internals (log__S5FLf2hq8p1, log_uwYiA43EUQna, log_e6r-qHLSTTb-, log_9gfhINluaTBm) |
| How do you export repo files without history? | git archive "creates an archive ... containing the tree structure for the named tree". That gives one commit's tracked files and no .git folder. | https://git-scm.com/docs/git-archive (Exa log_w7Avu6Hy4Dyt) |
| Why not redact in place and push? | After a history rewrite, old commits stay reachable in clones, forks, cached SHA views and pull requests. | https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository (Exa log_Vrl7Mx2l_pS2) |
| Where does the name-to-label table live? | The additional information (tables matching pseudonyms to the identifiers they replace) must be kept separately and not disclosed to those who get the data. Here it is rebuilt in memory on each run and never written. | https://www.edpb.europa.eu/system/files/2025-01/edpb_guidelines_202501_pseudonymisation_en.pdf (Exa log_cN3Ct74bWfgZ) |
| Case studies (owner rule 6) | PSNI 2023: one Excel file in an FOI answer exposed the whole workforce, 9,483 officers and staff, through extra worksheets (dpnetwork.org.uk, 2024-10-06; infosecurity-magazine.com, 2023-08-09). Islington 2012: hidden pivot-table source data exposed 2,375 people, and the council was fined £70,000 (pinsentmasons.com, 2013-08-26). So the check scans every part, not only visible cells. | https://dpnetwork.org.uk/ico-data-breach-fine/ ; https://www.infosecurity-magazine.com/news/northern-ireland-police-data-leak/ ; https://www.pinsentmasons.com/out-law/news/hidden-personal-data-disclosures-in-foi-responses-results-in-70000-london-council-fine- (Exa log_NNQV1KXWyku6) |
| Does op touch the 1Password app? | OP_SERVICE_ACCOUNT_TOKEN makes the CLI authenticate as the service account. The app integration has its own switch, which the script now sets off (OP_BIOMETRIC_UNLOCK_ENABLED=false). | https://www.1password.dev/cli/environment-variables ; https://www.1password.dev/cli/app-integration (Exa log_ngymAszhi2fU) |

Cost: 9 Exa searches at $0.007 (the Exa card lets EXA_SEARCH run freely).

## 2. What runs

`work/2026-10-01_setup-playbook/scripts/student_edition.py` (`build`, `check`, `selftest`; usage is in its docstring),
with tests in `scripts/test_student_edition.py`. All test data is invented.
- **Mapping**: built in memory from `knowledge/clients.md`. That covers 42 clients, with their names, GA4, Meta and GHL IDs, plus the
  new "Other names our files use" table: 8 sourced rows of short names and one GHL sub-account missing from the client
  list. 1Password items named after a client add that client's location ID. IDs, emails and phones written next to a
  client's name are added too: 3 votes when the name directly follows the ID, 1 when it's nearby. Our own names vote as
  well, and the client gets the ID only with more votes. The real run added 5 GHL IDs, 1 Meta ID and 6 numeric IDs.
  Labels: `Client A` (in the style of the match: `client-a`, `CLIENT_A`), `client-a.example`, `contact@client-a.example`,
  `CLIENT_A_LOCATION_ID`, `act_CLIENT_A_AD_ACCOUNT_ID`, `CLIENT_A_GA4_PROPERTY_ID`, `CLIENT_A_PHONE`.
- **Workbook**: every XML part of the package is rewritten in place: cells, formulas, comments, hyperlink targets,
  sheet and defined names, headers and footers (the format codes are skipped), and document properties.
- **Code**: `git archive HEAD` of agents-home (skills, tools, instructions, .skill-lock.json, .gitignore), the connector
  repo's map, setup guide, templates, project cards and golden tasks, and both GHL Worker repos. File names are scrubbed
  too. .env, key, certificate and credentials files are never copied.
- **Leak check**: run on every file, file name and package part. It looks for client names (any case or separator, plus
  short names), mapped IDs, emails and phones, and client domains; 19 vendor secret shapes (skipped inside base64 blobs of
  2,000+ characters, since the longest real key is 832); and every Connectors-vault secret, by SHA-256 of a window
  (raw, JSON-, XML- and URL-escaped). Findings show path, kind and label only. Nothing is replaced unless the check
  passes.

## 3. Proof

| Check | Result |
|---|---|
| Unit tests | 23/23 pass (`python3 scripts/test_student_edition.py`). |
| Mutation check | 10 single breaks: squashed names, header codes, attributes, own-name votes, key files, vault JSON escaping, path check, shapes, domains, exact-case aliases. 10/10 caught. |
| Real build, 2026-10-02T01:02Z | Leak check **PASS, 0 findings**, with 92 vault secrets compared by hash (`student-edition/build.json`). Sources: agents-home bfeacb24ed56, master-connector-repo 86d019f3bbd3, ghl-command-universal 6fcc3b4f05a1, increase-roas-oauth-gateway b464b6d99076. Master workbook sha256 4c5b4340d304... |
| First real build (before the fix) | Failed closed: 1 finding, a false "Meta token" inside a base64 font in a third-party skill's fonts.css. No edition was written. Fixed with the base64-blob rule, test first. |
| Selftest on the real edition | 0 findings before planting. Planted: a real client's name in README.md, in a workbook cell and in a file name; its GHL ID; a GitHub-shaped token; a synthetic vault value. **All 6 caught**, kinds client name, client name in path, client id, secret shape and 1Password value (`python3 scripts/student_edition.py selftest`; it reads no vault item). |
| Workbook | Opens in openpyxl. Same 36 sheets and names, same rows and columns per sheet. 111 cells changed (13 sheet parts). |
| Code folder | 2,409 files (33 MB). 0 .git, .env, .pem or .key files. 20 text files changed and 3 file names renamed. The 9 changed JSON, Python and JS files still parse (json, compile, node --check). |
| Builder check after the clients.md edit | client_names() 43 -> 44 names. No playbook tab names the added one. `build_tabs.py check` shows 6 problems, all stale quotes into the composio and google-workspace cards, which another play rewrote during this session. They are unrelated to this play. |

## 4. Files

- New: `scripts/student_edition.py`, `scripts/test_student_edition.py`. Output: `student-edition/`
  (`connectors-student-edition.xlsx`, `repo/` with a generated README, `build.json`, and `.gitignore` = `*`, so the
  edition never lands in this repo's commits).
- Changed: `knowledge/clients.md` (new sourced table; existing rows untouched); `workbook-updates.md` (the spp-p32a block:
  Start-here and Student starter kit, Rebuild note, hook, Decisions row, count correction).
- Real workbook, ~/Documents copy and all four repos: read only.

## 5. Not done or not proven

- The 1Password read ran once in the build, before the 2026-10-02 STOP-RULE on ~/Library/Containers. Whether op
  touched 1Password's group container is NOT_PROVEN. The app integration is now off in the script, and op was not run
  again in this play.
- Out of scope and left as is: a third-party Gmail address (the GTM account's admin) in a few workbook cells, employees'
  increaseroas.com addresses and Alex's own accounts. A client ID that is never written near a client's name, and isn't
  in knowledge/clients.md, can't be mapped, so the check can't see it either.
- Alex's later step: share the edition (a new private repo from `student-edition/repo`, or a zip). No GitHub repo has
  been made or pushed.

## 6. Student-route gaps G03 and G19 (play spp-p32b, 2026-10-02)

Source: notes/replication-retest-final-2.md §4 (spp-c4d). Tests first: 4 new tests (27/27 pass) and 3 new mutants (13/13 caught).
- **G03**: `add_repo_files` puts the scrubbed workbook into `repo/master-connector-repo/` at the agents-home hook's path
  (work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx, byte-identical to connectors-student-edition.xlsx) and
  a blank STATUS.md (the repo-conform skeleton, byte-identical).
- **G19**: `director_starter` builds `repo/alex-director/` from ~/Alex-Director at HEAD (8487dcdefc61), with 3 files:
  - DIRECTOR_STATE.md: lines 1–30, the title, the one-line rule and the commented-out blank block (lines 5–30). The build
    stops if those lines ever stop being an empty block.
  - templates/mission-graph-template.md.
  - AGENTS.md, which the matcher shows holds no client data; it is left out automatically if it ever does.
  - Never the live ledger, mission graphs, receipts or fence files.
- Rebuild 2026-10-02T03:02Z: leak check **PASS, 0 findings**, 96 vault secrets by hash (build.json). The master
  workbook is now sha256 3acd4313...; agents-home 3a970c28d7e5, master-connector-repo 1002e9387370. 2,457 files, with
  0 .git, .env, .pem or .key files.
- Selftest after the rebuild: 0 findings before planting, **6/6 planted leaks caught**.
- op ran with the 1Password app integration off (`OP_BIOMETRIC_UNLOCK_ENABLED=false`). Nothing here read ~/Library.
- Rebuild 2026-10-02T17:35Z (after op unfroze): build + check **PASS, 0 leaks**, 96 vault secrets by hash; sha256
  ca8487ceff38fd73...; built from master d68f61c8 (batch 5); agents-home 10b9aa970118, repo 08316920031d; 2,459 files,
  no .git/.env/.pem/.key; selftest 6/6. op calls ran through a stand-in that kills a hung call after 30 s (a perl
  alarm does not stop op: Go ignores SIGALRM; lesson L-010).

## 7. Batch 6: the Director's rule files (G19), the builder note (G14), op timeouts (2026-10-02)

Source: the Director's decisions after notes/replication-retest-final-3.md (workbook-updates.md L279-L293). Tests first:
4 new tests, 31/31 pass (test_student_edition.py).
- **G19, `rule_files`:** the files the shipped Director docs cite now ship from each repo's HEAD (committed text only,
  like the code), through the same scrub and leak check:
  - `one-shot-builder/RULES.md` (One-Shot-Builder; alex-director/AGENTS.md L32 and L54 read its §10): scrubbed copy, the
    scrub changed nothing in it;
  - `alex-director/STACK.md` and `alex-director/CONCEPTS.md` (the Director home; AGENTS.md L33 and L36): scrubbed
    copies; STACK.md had 3 client mentions swapped for labels;
  - `one-shot-builder/docs/LESSONS.md` (execution.md L110): a **one-line stand-in**. The real log names clients' people
    and a client location's phone number, and knowledge/clients.md maps neither, so the scrubber can't make it safe
    (`STAND_IN`). The stand-in keeps the row format, so "add one row to docs/LESSONS.md" still works.
  - Any other rule file whose scrubbed text the leak check still flags, or that still holds a phone number the scrubber
    can't map, ships as a stand-in automatically. build.json `rule_files` names what shipped for each file.
  - The edition README tells students where each folder goes (~/Documents/One-Shot-Builder, ~/Alex-Director) and to
    link ~/STACK.md, so the role card's references resolve. The rule files' text joins the harvest, so IDs written
    next to a client's name there are mapped too.
- **G14:** the edition README says "Running GHL Command needs your own GHL Command licence and sign-in; not part of the
  student build.", and the builder's own README in the edition opens with the same note (`builder_note`).
- **README labels line (L293):** personal addresses, Google file links and Alex's GHL developer ID are named with
  their labels.
- **Timeouts (lesson L-010):** every op call in `read_vault` runs under `subprocess.run(..., timeout=60)`, which kills
  a hung op and stops the build with nothing written; the Keychain read has a 30 s cap.
- **Batch 6 build (outside the sandbox):** the build_tabs.py apply hook stopped on one failed `op item get` and kept
  the previous edition; the same item read fine a minute later (transient). Then build 19:15:50-19:18:41Z **PASS**
  (edition built 2026-10-02T19:17Z): leak check 0 findings, 97 vault secrets by hash; extra scans 0 access-link files,
  0 secret hits (1 allowlisted) over 2,465 files. Edition workbook sha256 790ac8e9b672851e…, from master 1b7648cc…
  (batch 6); sources agents-home 10b9aa970118, master-connector-repo 08316920031d, ghl-command-universal 6fcc3b4f05a1,
  oauth-gateway b464b6d99076, alex-director bc0a1d1be558 (5 files), one-shot-builder dcae73cc4f86 (2 files);
  rule_files: RULES.md, STACK.md and CONCEPTS.md scrubbed copies, docs/LESSONS.md the one-line stand-in; the builder's
  README note in. check 19:21Z **PASS** (0 findings, 97 vault secrets; scans 0 hits over 2,466 files, build.json included); selftest **PASS** (0 before planting, 9 plant kinds caught, both
  scans caught their plants). Published by student_publish.py as dc98d06 "Student edition 790ac8e9 (built
  2026-10-02T19:17Z)" (+4 ~4 -0, 2,465 files); the rerun said "no changes".

## 8. Batch 7: what the Director starter still lacked (G19, spot check spp-c4f, 2026-10-02)

Source: notes/replication-spotcheck-c4f.md §1 and the QUEUED spp-c4f block (workbook-updates.md L298). Tests first:
2 new or changed tests, 32/32 pass; 2 mutants (no exec bit kept, no mission-graphs README) both caught.
- **mission-graphs/:** `director_starter` writes `mission-graphs/README.md`, one line (`GRAPHS_README`), so step 5b's
  `cp ... ~/Alex-Director/mission-graphs/<MISSION_ID>.md` has a folder to copy into.
- **The write guard:** `RULE_FILES` gains ~/Alex-Director's `scripts/controller-write-guard.py` (HEAD, 777 lines), which
  the shipped gates.md (L75) and RULES.md §13 run before any shared or live write. It goes through the same scrub and
  leak check; the scrub changes nothing in it. `rule_files` now keeps the source's executable bit (gates.md runs the
  guard by its path). If a build ever has to hold it back, its `FALLBACK` stand-in ships instead: an executable that
  prints the guard's own "denied" JSON and exits 4 (its deny code), so every protected write is refused; build.json and
  the README then name it, and the Director home rebuild tab says live-write missions are out of scope for students
  until a build ships the real script.
- **The git step:** the README and Director home rebuild step 5a tell a student to make the starter its own git repo
  (`git init`, then a first commit; it has no remote), which Rebuild 15.2's student check reads.
- Not changed here: the modal card (agents-home tools/cards/modal.md L33) still names /opt/homebrew/bin/python3.14; the
  batch 7 dispatch allowed only modal_op.py in agents-home (8091133).
- **Batch 7 build (outside the sandbox):** apply hook build + check PASS; then build 20:08:23-20:11:14Z **PASS** (edition
  built 2026-10-02T20:09Z) from master 9a73aa30… and agents-home 8091133ebea8 (the fixed modal_op.py hint): leak check
  0 findings, 97 vault secrets by hash; extra scans 0 access-link files, 0 secret hits (1 allowlisted). alex-director
  now ships 7 files: the guard (executable, the scrub left it byte-identical) and mission-graphs/README.md included.
  check **PASS**; selftest **PASS** (0 before planting, 9 plant kinds, both scans). Edition workbook sha256
  fe9cffcc6587453…; published as e9dc746 "Student edition fe9cffcc (built 2026-10-02T20:09Z)" (+2 ~4 -0, 2,467
  files; the guard is 100755 in the repo); the rerun said "no changes".
- **Batch 8 build (outside the sandbox):** build 20:53:28-20:56:21Z **PASS** (edition built 2026-10-02T20:54Z) from
  master 1a77b48f…, agents-home 22a16c26c06a and alex-director 79392886e0ee (the template's "## Node:" comment and the
  guard's ~ expansion); leak check 0 findings, 98 vault secrets by hash; extra scans 0 hits; check **PASS**; selftest
  **PASS**. Edition workbook sha256 376fd0119f6fef83…; published as 63d942d "Student edition 376fd011 (built
  2026-10-02T20:54Z)" (+1 ~17 -0, 2,468 files); the rerun said "no changes".
- **Batch 9 build (outside the sandbox):** build 21:18:09-21:21:04Z **PASS** (edition built 2026-10-02T21:19Z) from
  master 7a239944…, agents-home a9d4ae4b0f97 and alex-director 55ae26049cc4; leak check 0 findings, 98 vault secrets by
  hash; extra scans 0 hits; check **PASS**; selftest **PASS**. Edition workbook sha256 229bf9c46bb95c38…; published as
  0deb579 "Student edition 229bf9c4 (built 2026-10-02T21:19Z)" (+0 ~6 -0, 2,468 files); the rerun said "no changes".

## 9. Batch 10: the starter stays clean and reads true (spot check spp-c4h follow-ups, 2026-10-02)

Source: notes/replication-spotcheck-c4h.md §2 and workbook-updates.md L317-L318. Tests first: 3 new or changed tests,
34/34 pass; 3 mutants (no field insert, no .gitignore, NONE refused) all caught.
- `STARTER_FILES`: `.gitignore` (.runtime/ for the write guard's claims; *.bak and *.lock for ledger_check.py), so the
  student variant of Rebuild 15.2 ("clean tree") holds after first use; `STANDING_AUTHORIZATIONS.md` and
  `docs/solutions/README.md` as one-line "none yet" stand-ins for the files gates.md L19 and AGENTS.md L35 point to.
- `RULE_FILES` gains One-Shot-Builder's `checklists/ONE_SHOT_READINESS.md` (RULES.md L425 certifies against it): a
  scrubbed copy, which the scrub left unchanged.
- `blank_block` finds the commented-out blank mission block wherever it sits (it was a fixed lines 5-30) and still
  refuses live data: every field must be empty or NONE. If the block lacks SUPERVISING_DIRECTOR_THREAD_ID (the
  conductor's Report reads it), the starter's copy gets "SUPERVISING_DIRECTOR_THREAD_ID: NONE" after
  CONTROLLER_HOST_ID; build.json `blank_block_fields_added` says so. The live ledger itself is the Director's.
- Build 21:50:25-21:53:16Z **PASS** (edition built 2026-10-02T21:51Z) from master e9e70449…, agents-home 6e4c1363f7a2,
  alex-director 3c038e812996 (10 starter files) and one-shot-builder dcae73cc4f86 (3 files); leak check 0 findings, 98
  vault secrets; extra scans 0 hits; check **PASS**; selftest **PASS**. Edition workbook sha256 229f09d704b07381…;
  published as 8288064 (+4 ~7 -0, 2,472 files); the rerun said "no changes".

## 10. Affiliate links in the student copy (Director dispatch, 2026-10-02)

Ask (Alex, relayed by the Director): "i want the student copy to auto use all my affiliate links." Design read first:
knowledge/affiliate-links.md and work/2026-10-02_affiliate-links/notes/ (affiliate-programs.md §3 and §4, sheet.md).
Snapshot before: system/snapshots/2026-10-02_1821_affiliate-links/ (the three scripts at f6eb943, sha256 in README.txt).
- **One source, read at build time.** `build` first reads Alex's affiliate Sheet (knowledge/affiliate-links.md) through
  Composio CUSTOM_GOOGLE_ROBOT_SHEETS_READ (login ca_vm6rcasgNEIk, user alex@, range Programs!A1:O, 120 s timeout that
  kills the CLI). Only rows with Status live AND a link count. Any read problem (CLI missing or hung, non-zero exit,
  not JSON, refused, no rows, a column renamed) stops the build before 1Password or any file is touched, so the old
  edition stays and no old link can come back (nothing is stored). A live "link" that isn't a web address, or two live
  rows claiming one host, also stop it. build.json `affiliate_links` keeps the live rows (tool, link, hosts) and the
  counts, not the Sheet's file ID: the leak check counts Google file IDs (`check` caught it on the first build).
- **What gets swapped.** A product's own hosts come from its row's program and source URLs whose site name matches the
  tool (apex and www together, another subdomain only exactly; help, docs, API, app, login and partner hosts never):
  HighLevel = gohighlevel.com and www.gohighlevel.com. Only home, pricing and sign-up pages on those hosts change, in the
  workbook (cells, inline or shared strings, and cell hyperlinks) and in the docs (.md, .markdown, .mdx, .txt; code
  files are never opened). Left as they are: API, docs, help, app and login URLs, cited sources ("URL (read <date>)",
  the workbook's "where the fact comes from"), front matter, fenced, indented and <pre> code, inline code, HTML comments,
  HTML and JSX attributes, shell-command lines and curl or wget arguments. The link goes in exactly as the Sheet has it
  (HighLevel: raw link, no redirect or short link), followed by "(affiliate link)" (the Director, 2026-10-02: HighLevel
  wants the disclosure close to each link). "Some links are affiliate links; I may earn a commission at no cost to you."
  goes once where links first appear: as its own paragraph before the block holding a doc's first swapped link, and at
  the end of the first swapped cell of each sheet; never when nothing was swapped. STUDENTS.md (written by
  student_publish.py) gets the same swap from build.json's live rows. A census then fails the build if any doc or
  workbook carries a live link without the disclosure.
- **Tests:** 7 new, 41 of 41 pass. A fake live row swaps home, pricing and sign-up and leaves API, docs, help, app,
  login, the program page, another product, a cited source, front matter, inline code, a fenced block, indented code,
  command lines, a comment and an HTML attribute alone (CRLF too); the workbook in both string forms plus a hyperlink,
  one disclosure per sheet; non-live rows and a live row without a link change nothing (byte-identical); the Sheet call's
  arguments; six unreadable-Sheet cases and a missing CLI fail, and `build` stops before 1Password with the edition
  untouched; the leak check and both scans pass on a copy with links, and a hand-placed link without the disclosure
  fails the census; STUDENTS.md gets the recorded link. Mutants: dropping the citation, fence, command-line,
  inline-code, curl-sentence or host-skip rule each fails at least one test. student_publish.py selftest 6/6.
- **What it changes today: nothing visible.** HighLevel went live in the Sheet during the job (row 2, link on
  www.gohighlevel.com with FirstPromoter tags). Builds since read 41 rows, 1 live, 0 links swapped, no disclosure: the
  copy has no HighLevel home, pricing or sign-up link. Its HighLevel URLs are developer-portal (marketplace), OAuth,
  help-center and API pages, which must stay. With every program row set live (fake links, on a copy) the workbook still
  swaps 0 (its only candidates are cited sources) and the docs 3 (GitHub's sign-up page, Cursor twice; neither has a
  program). So a link shows up only once a sign-up link exists where the student needs the account.
- **Builds:** 22:33Z PASS but `check` FAIL (build.json held the Sheet's file ID; fixed), 22:42Z PASS (check PASS, 0
  findings, 98 vault secrets; selftest PASS; publish dry run: only other agents' changes and README's build time), then
  23:02Z through the batch 11 apply hook (playbook-tabs.md §39).
- **Open (not code):** a HighLevel sign-up link has to exist for the swap to fill (a proposal goes to the Director);
  HighLevel's terms want a privacy policy naming Alex an independent HighLevel affiliate (his website: Alex's item);
  research flags, affiliate-programs.md: FTC staff say "affiliate link" alone may not be understood and "paid link" is
  adequate (§3 C4), "at no cost to you" wasn't checked per vendor (§4.4), and some vendors limit where a link may sit
  (§3), while a live Status is the only gate here.
- **Batch 11 publish and a handle fix (2026-10-02).** The batch 11 apply hook rebuilt the edition (23:02Z, PASS; HighLevel
  live, 0 swapped) and it was published as 3d4c8de. That copy carried the partner's GitHub username in the GitHub card
  (another agent's card change, agents-home b49487f). Fix: `PARTNER_HANDLES` (the people with access to Alex's repos,
  repo-lock.md §1) become PARTNER_GITHUB_USER in every file and path, the leak check flags any left, and the selftest plants
  one (42 of 42 tests). Rebuilt 23:18Z PASS, check PASS (0 findings, 98 vault secrets), selftest PASS, published as 656dda4
  (+0 ~6 -0), rerun "no changes"; 0 files with the handle in the published tree. 3d4c8de keeps it in the template repo's
  history (only Alex has access; no invitations): removing it means a force-push, which is Alex's call. A new partner's
  username has to be added to PARTNER_HANDLES by hand.

## 11. Sign-up spots, "(paid link)" and the new disclosure (Director decisions, 2026-10-02)

Decisions (the Director, after §10; snapshot first: system/snapshots/2026-10-02_1940_affiliate-spots/):
1. Plain sign-up spots: HighLevel in STUDENTS.md's "Before anything else" and in Rebuild from zero step 1.9, plus every
   other section-1 account a student signs up for that has a program row in the Sheet. Each spot is a plain official
   sign-up or pricing URL, so a row turned live swaps in on its own (Alex: "auto use all my affiliate links").
2. Label "(paid link)" (FTC staff call "paid link" next to a link adequate; HighLevel's own example is "(Paid Link)":
   work/2026-10-02_affiliate-links/notes/affiliate-programs.md §3 C4). Disclosure "I earn a commission if you buy through
   these links."; "at no cost to you" is dropped because it wasn't verified per vendor (same file, §4.4).
3. **No force-push** for the template repo's commit 3d4c8de (the partner's GitHub username, §10). Why: a GitHub username
   is a public handle, the template repo is private with no other collaborators, and "Use this template" copies start
   without history. The username stays scrubbed from every new edition (PARTNER_HANDLES).
4. STATUS.md item 0e gains: a live row shows up only where the student copy has a sign-up link for that product.

The spots (each URL fetched 2026-10-02; Sheet rank and status as read through the Google robot that day):

| Step | Account | Program row | Spot | Checked |
|---|---|---|---|---|
| 1.1 | 1Password | rank 4, cash (CJ), not applied | https://1password.com/pricing | 200, "1Password Pricing and Plans" |
| 1.2 | Composio | rank 5, cash (Dub), not applied | https://composio.dev/pricing | 200, "Pricing \| Composio" |
| 1.5 | Tailscale | rank 25, partner (Insiders), not applied | https://tailscale.com/pricing | 200, "Tailscale pricing" |
| 1.6 | Google Workspace | rank 3, cash (referral), not applied | https://workspace.google.com/pricing | 200, "Compare Flexible Pricing Plan Options" |
| 1.6 | Google Cloud | rank 6, cash (CJ), not applied | https://cloud.google.com/pricing | 200, "Pricing Overview \| Google Cloud" |
| 1.8 | Claude | rank 23, credit (Claude Code guest passes), not applied | https://claude.com/pricing | 200, "Plans & Pricing \| Claude by Anthropic" |
| 1.8 | ChatGPT and Codex | rank 24, credit (trial invites), not applied | https://chatgpt.com/pricing | curl 403 (bot wall); the built-in browser loaded https://chatgpt.com/pricing/, "Pricing \| ChatGPT" |
| 1.9 and STUDENTS.md | HighLevel | rank 1, cash (FirstPromoter), live | https://www.gohighlevel.com/pricing | 200, "HighLevel Pricing" (the /30-day-free-trial path answers 404, so not used) |

- Left out, no program (Status "no program"): 1.3 Orgo, 1.4 Cloudflare, 1.7 GitHub.
- The Claude and ChatGPT rows cite only docs and help pages (code.claude.com, help.openai.com), which the host rule
  skips, so `SITE_FALLBACK` names their own sites (claude.com, chatgpt.com), used only when a row gives no host. Both
  programs are per-person passes or in-app invites, so one link may not suit a shared copy: Alex's call when he marks
  them live.
- Code: the two constants, SITE_FALLBACK, the STUDENTS.md spot (student_publish.py), Rebuild from zero section 1 via
  scratch gen_spots.py. Tests 44 of 44: every spot belongs to exactly one program row of the research copy of the Sheet
  and is a page the swap recognizes; a docs-only row uses its product's own site and leaves the app and docs URLs alone;
  STUDENTS.md gets the swap with the disclosure under its heading, and stays as written when no row is recorded.
- **Result (2026-10-02 19:41-19:58 local).** The workbook apply (playbook-tabs.md §40) rebuilt the edition through its hook:
  build 23:43Z PASS (HighLevel live: 1 workbook cell swapped, in the edition workbook and its repo copy; the disclosure in
  that cell; the other spots stay plain), check PASS, selftest PASS. Published as bd8f08c "Student edition b785c076
  (built 2026-10-02T23:43Z)" (+3 ~11 -0, 2,475 files; leak check 0 findings, 99 vault secrets); the rerun said "no
  changes". What the published copy shows: STUDENTS.md's "Before anything else" opens with "> I earn a commission if you
  buy through these links." and its GHL bullet ends "plans and sign-up at <Alex's HighLevel link> (paid link)."; the
  workbook's Rebuild from zero 1.9 ends "plans and sign-up at <Alex's HighLevel link> (paid link). I earn a commission if
  you buy through these links."; no plain gohighlevel.com/pricing link is left. The same publish carried other agents'
  committed work (the repo-conform 2.3 speed files; the Director home's write guard and gates.md), as built from HEAD.

## 12. Rebuild for the final write guard (Director, 2026-10-02 20:04 local)
- Why: the guard upgrade is final (alex-director 8d5926a: multi-step scopes with a step lock; agents-home 779f8b7: gates.md
  "One fence, several steps" and how unresolved or failed steps clear). The Director 2.6 skill update had not landed in
  agents-home at build time (HEAD 779f8b7), so the next build picks it up.
- Build 2026-10-03T00:05Z PASS from master 20d762a7 (unchanged since §11), agents-home 779f8b755d55, alex-director
  8d5926a7ab21, one-shot-builder e9c91e93120d; the shipped scripts/controller-write-guard.py is byte-identical to
  alex-director HEAD and executable (rule_files: "scrubbed copy ... @ 8d5926a7ab21"). Affiliate step: 1 live row, the
  HighLevel cell swapped as in §11. Check PASS (0 findings, 99 vault secrets; scans 0 hits), selftest PASS.
- Published as 4f2e43d "Student edition b785c076 (built 2026-10-03T00:05Z)" (+0 ~5 -0: README, gates.md, the guard,
  instructions/codex.md, repo-conform fix-recipes.md; 2,475 files; the publish leak check counted 98 vault secrets, one
  fewer than the build's check minutes earlier, so the vault changed in between); the rerun said "no changes".

## 13. Rebuild for Director 2.6 (builder, 2026-10-02 21:40 local, after the 20:46 crash)
- Why: Director 2.6 landed (agents-home cca6959, alex-director 0fd6a83). The previous builder built it at 2026-10-03T00:42Z
  (from master 97a8ebe) but the 20:46 EDT out-of-memory crash stopped it before check, selftest or publish: the student
  repo stayed at 4f2e43d (ls-remote, 01:41Z). That local build differed from the published copy in README.md and five
  Director 2.6 files, so a rebuild was due.
- Order: the commit sweep (7233a83, pushed) went first, so the edition also carries the tune-up's six new rows in
  system/evals/golden-tasks.md, a shipped file, and matches a fresh build of every source's HEAD.
- Build 2026-10-03T01:44Z PASS (01:42:57-01:45:54Z) from master workbook 20d762a7 (unchanged since §11), agents-home
  cca69594b03d, master-connector-repo 7233a83d81dd, alex-director 0fd6a835aab3, one-shot-builder e9c91e93120d,
  ghl-command-universal 6fcc3b4f05a1, oauth gateway b464b6d99076. Inside the sandbox op failed TLS (x509 OSStatus
  -26276) before anything was written, so build and check ran outside it. Affiliate step: 41 rows, 1 live (HighLevel),
  1 workbook cell swapped, the disclosure once. Leak check 0 findings (98 vault secrets); scans PASS (0 hits).
  Check PASS (0 findings, 98 vault secrets; scans 0 hits). Selftest PASS (every plant caught, both scans too).
  Edition workbook sha256 b785c07678db72f6413fc33dbc31a117b5bb880e87af89549701702c8514fb9c (the same as §11 and §12).
- Published as f2c353c "Student edition b785c076 (built 2026-10-03T01:44Z)" (+0 ~7 -0: README, alex-director SKILL.md,
  controllers.md, execution.md, handoff.md, repo-conform fix-recipes.md, golden-tasks.md; 2,475 files; the publish leak
  check counted 0 findings, 98 vault secrets); the rerun said "no changes"; ls-remote main = f2c353c. The five Director
  files are byte-identical to agents-home HEAD (SKILL.md says version "2.6"); golden-tasks.md has all six 16:12 rows,
  and its three other changed lines are the client-label scrub.

## 14. Rebuild for Director 2.7 (builder, 2026-10-02 23:12 local)
- Why: Director 2.7 landed (agents-home a28cacd: scripts/accept.py, graph_edit.py, graph_lint.py, the receipt-columns
  migration; alex-director a68bd6c mirror), and the version cells moved to 2.7 (parity-fix-2026-10-03.md "## Follow-up:
  version cells for Director 2.7"). The parity-fix builder's 02:58Z build was checked but never published.
- Build 2026-10-03T03:13Z PASS, run by that workbook apply (03:11:59-03:17:38Z, outside the sandbox: op and the
  affiliate Sheet read) from master workbook c372e737…, agents-home a28cacdc4b45, master-connector-repo b08883983d16,
  alex-director b98dd0a937f2, one-shot-builder e9c91e93120d, ghl-command-universal 6fcc3b4f05a1, oauth gateway
  b464b6d99076. Affiliate step: 41 rows, 1 live (HighLevel), 1 workbook cell swapped, the disclosure once. Leak check 0
  findings (98 vault secrets); scans PASS (0 hits over 2,484 files, 1 allowlisted). Check PASS. Selftest (03:18-03:21Z)
  PASS: 0 findings before planting, 10 after, every plant caught (client name in the workbook, in a path and in
  README.md, client ID, 1Password value, Google file ID, owner account ID, partner handle, personal email, secret
  shape), and both extra scans caught theirs. Edition workbook sha256
  35cf3fb7756086303c667aa8059f524c6295835761ae130666de0eef46c10d8c.
- Publish dry run: leak check PASS (0 findings, 98 vault secrets, 2,484 files), +9 ~9 -0.
- Published as 080a290 "Student edition 35cf3fb7 (built 2026-10-03T03:13Z)" (+9 ~9 -0, 2,484 files; added: the three
  Director 2.7 scripts, test_graph_tools.py, the migration, chat_guard.py, codex_plugins.py with its JSON and test;
  changed: README, Director SKILL.md, mission-graph.md, ledger_check.py, check.py, the ga4 and ghl cards, both workbook
  copies); the rerun said "no changes"; ls-remote main = 080a290. The shipped Director files (SKILL.md "2.7",
  mission-graph.md, the 5 scripts, the migration) and the conductor SKILL.md ("2.5") are byte-identical to agents-home
  HEAD; the edition workbook shows the 2.7 cells (Director + Conductor C13 and B132, Limits H17, Skills, where they live
  B60).
- Order: this ran before the commit sweep that followed it, as asked; that sweep touches none of the shipped
  master-connector-repo paths (AGENTS.md, CLAUDE.md, setup, tools cards, system/evals, work/_template).

## 15. Rebuild for batch 12 (spp-p45f, builder, 2026-10-03 04:03 local)
- Why: batch 12 landed (spp-p45a: master-connector-repo f1053b5, workbook 66435e6b…; notes/playbook-tabs.md §41), and so
  did the 1Password CLI fix (agents-home fd72079 and ad0158c: robot op calls get one private HOME and one shared
  daemon, op_items.robot_env). The batch 12 applies' hook builds (07:27Z, 07:31Z) were never published and predate both.
- op: student_edition.py still calls op itself (read_vault: the robot token with the real HOME, OP_TIMEOUT 60 s), not
  through op_items.robot_env. This run it didn't stall: build, check and both publish leak checks read the 98 vault
  secrets. Not changed here.
- Build 2026-10-03T08:05Z PASS (08:03:48-08:06:55Z, outside the sandbox) from master workbook 66435e6b…, agents-home
  ad0158c7dad4, master-connector-repo f1053b54574f, alex-director b98dd0a937f2, one-shot-builder e9c91e93120d,
  ghl-command-universal 6fcc3b4f05a1, oauth gateway b464b6d99076. Affiliate step: 41 rows, 1 live (HighLevel), 1
  workbook cell link swapped, the disclosure once. Leak check 0 findings (98 vault secrets); scans PASS (0 hits over 2,485
  files, 1 allowlisted). Edition workbook sha256 e3ea9cfed1eff56fc665a8c88f96f65133e9acadc37491966f6db7628a5dc39a.
- Check (08:07-08:10Z, outside the sandbox) PASS: 0 findings, 98 vault secrets by hash; access-link and secret scans 0
  hits over 2,486 files (build.json counted too), 1 allowlisted.
- Selftest (08:10-08:13Z) PASS: 0 findings before planting, 10 after, every plant caught (client name in the workbook, in
  a path and in README.md, client ID, 1Password value, Google file ID, owner account ID, partner handle, personal email,
  secret shape), and both extra scans caught theirs.
- Publish dry run: leak check PASS (0 findings, 98 vault secrets, 2,485 files), +1 ~13 -0.
- Published as 9e6fbec "Student edition e3ea9cfe (built 2026-10-03T08:05Z)" (+1 ~13 -0, 2,485 files; added:
  test_op_robot_home.py; changed: README, op_items.py and the six scripts that now use robot_env (firecrawl_op,
  gcloud_robot, rebuild_hub, modal_op, orgo_op, push_key_to_composio), codex-plugins.json, setup/00-start-here.md and
  02-app-settings.md (every 8 hours), both workbook copies); the rerun said "no changes"; ls-remote main = 9e6fbec.
- GitHub readback (Composio GITHUB_GET_A_REPOSITORY, login github_lipase-modern): private (visibility private),
  is_template true, default branch main, pushed_at 2026-10-03T08:17:47Z. Visibility and collaborators were not touched.
- Spot checks: the shipped op_items.py and test_op_robot_home.py are byte-identical to agents-home HEAD; the published
  workbook equals the built edition (e3ea9cfe) and carries batch 12 (Decisions D34, the Composio Tailscale login row,
  To do R2's policy v4 text, the partner rule in Rebuild from zero r12).
