# Partner limited robot: design (spp-p47a)

Status: **design only, written 2026-10-03.** Nothing was built, configured or changed: no service account, key,
delegation, OAuth client, hub file, Composio login or workbook cell. Every web fact below was read on 2026-10-03
through Composio Exa (`EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`); page dates and URLs are in §12. Local facts point to
files and lines. Path: architectural (new hub routes, a new OAuth app, new Composio toolkits), so nothing is built
until Alex approves this design through the Director and a builder gets a fence. A fresh verifier checked this
design against its sources; its fixes are in (checks.md).

## 0. The answer in short
- **Recommended: per-partner OAuth sign-in, no domain-wide delegation (option 2, hardened).** Each partner signs in
  once to an internal Google app that Alex owns. The partner's token lives only in that partner's own hub route,
  which runs as its own Linux user. The partner's own Composio login reaches that route. Alex limits the app in the
  Admin console to a "Partner AI" unit and to 5 scopes.
- **Why:** Google says domain-wide delegation gives an app access to all users' data, and that scopes don't limit
  which user it can act as. Google advises OAuth consent instead (F1, F2). A user's own sign-in can only act as that
  user, so Google holds the pin, and a bug in our code can't reach alex@ or the Admin API.
- **Correction:** spp-c20 §7 calls "its own service account with only the Gmail and Drive scopes" the strongest
  choice, because "Google enforces it". Rebuild r12 (changed today) names that account as the plan. Google enforces
  the scopes, not the user. That account could read every user's mail, and only our code would stop it (§3).
- **Prerequisite the design can't fix:** the partner's AI must not be able to read the main robot's key. Today's
  plan gives each partner Mac a read-only 1Password robot on the Connectors vault. That vault holds the robot's key
  (all users, 39 scopes, Admin API) and the hub tokens (§6, P0).
- **Alex's part, once:** about 30 clicks in the Cloud console and 17 in the Admin console (47 in all), or 64 with
  the recommended Partner AI unit. No delegation entry. Each partner signs in once from a link Alex sends. This
  replaces the "one click in Google Admin" promised on 2026-10-02, which assumed delegation. Option 1 would cost
  Alex fewer clicks (about 34, none for partners), but it fails the bar (§4).
- **What's left:** Manny and Anthony are super admins. With Drive read access, Google would let a partner's token
  list every shared drive in the domain by passing an admin flag. The route never sends that flag (code). Google's
  general advice for super admins, a separate non-admin account for daily work (F16), would remove this. That's
  Alex's call (§11).

## 1. The bar
Alex, 2026-10-02 (verbatim in work/2026-10-01_setup-playbook/notes/spp-c20-member-test.md §7, decision D34):
partners may stay super admins, but their AIs get less power. The partner robot must be pinned to the partner's own
mailbox and Drive, with no Admin API and no other users. Tests used below:
1. Only the partner's own mail and the files they can open. 2. No Admin API. 3. No other user, alex@ included.
4. Less than the partner can do by hand. 5. Held by Google where possible, so a bug or a leak can't widen it.

## 2. Facts that decide it
Google (official pages; "updated" is the page's own date):
| # | Fact | Source |
|---|---|---|
| F1 | Delegation lets an app use the data of **all** users without their consent. It lives in Admin console > Security > Access and data control > API controls > Manage Domain Wide Delegation. Deleting a client stops dependent apps at once. With multi-party approval on, a second super admin approves. | Control API access with domain-wide delegation (updated 2026-10-01) |
| F2 | "OAuth scopes don't restrict which users the service account can impersonate." Google advises avoiding delegation when OAuth consent can do the job, hosting delegated accounts in dedicated projects, and avoiding keys (signJwt instead). | Domain-wide delegation best practices (updated 2026-10-01) |
| F4 | An Internal app can be authorized only by members of the organization (others get `org_internal`). High-risk Gmail and Drive scopes may need the admin to allow the app. | Manage App Audience (read 2026-10-03) |
| F5 | An internal app needs no Google verification, shows no unverified-app screen and has no 100-user cap. Its project must belong to the organization. Internal apps don't need to list scopes. | When is verification not needed (read 2026-10-03); Configure the OAuth consent screen (updated 2026-09-03) |
| F6 | A refresh token **may** stop working when the user revokes it, after 6 months unused, after a password change (Gmail scopes), past the token limit (100 per account per client), when time-based access ends, or when an admin restricts a service it uses. External apps in Testing get 7-day tokens. | Using OAuth 2.0 (updated 2026-05-26) |
| F7 | Revoking removes every scope the user granted that project and invalidates its access and refresh tokens. It may take some time to take full effect. Offline access is the documented way to act while the user is away. | OAuth 2.0 for web server apps (no page date) |
| F8 | Admin console: user > Security > Connected applications lists third-party apps; Remove ends access until the user signs in again; blocking the app makes it permanent. Admin SDK `tokens.delete` deletes a user's tokens for one client ID (scope `admin.directory.user.security`). That it has the same effect as Remove is an inference. | Manage a user's security settings (updated 2026-10-01); tokens.delete (updated 2026-03-10) |
| F9 | App access control sets an app to Trusted, Specific Google data, Limited or Blocked, per organizational unit. A child unit's setting survives a different top-level one. Specific Google data allows only the scopes the admin lists (sign-in scopes included). The scope list shows the scopes the app has requested. Restricting a service revokes untrusted apps' tokens. | Control which apps access Google Workspace data (updated 2026-10-01) |
| F10 | Child units inherit the parent's settings unless the unit sets its own. An admin can't move himself to another unit. | Add an organizational unit; Move users (both updated 2026-10-01) |
| F11 | `gmail.modify` reads, composes and sends, but can't permanently delete. Settings and filters need separate scopes. `gmail.settings.sharing` operations and `delegates.create` work only for delegated service accounts. | Choose Gmail API scopes (updated 2026-09-10); delegates.create (updated 2026-04-15) |
| F12 | `drive.readonly` views and downloads all of the user's files; `drive.file` covers only files the app created or the user opened with it. An admin with the Drive and Docs privilege can manage any shared drive by passing `useDomainAdminAccess=true`. `drives.list` does it with `drive` or `drive.readonly`. `drives.delete` with `allowItemDeletion` needs `drive`. `permissions.create` accepts `drive` or `drive.file`. | Drive scopes (2026-09-03); Manage shared drives (2026-09-03); drives.list (2026-07-07); drives.delete (2025-08-13); permissions.create (2026-09-14) |
| F13 | Google's own Workspace MCP servers are a developer preview. Prerequisite: Developer Preview Program membership, an application form. Terms: not in public apps before GA, provided "as is", and Google may use data sent through pre-GA APIs to improve them. The Gmail server uses `gmail.readonly` + `gmail.compose` and has draft tools but no send tool. The Drive server uses `drive.readonly` + `drive.file` and has no delete or share tool. (The May launch post called the preview open to all, but the newer setup page requires membership.) | Configure the Workspace MCP servers (updated 2026-09-18); Gmail MCP (updated 2026-09-18); Developer Preview Program (updated 2026-10-01) |
| F14 | The device sign-in flow doesn't allow Gmail or `drive.readonly`, so it can't be used here. | OAuth for limited-input devices (no page date) |
| F15 | Higher Gmail, Drive and Calendar quotas will need billing later in 2026, with 90 days' notice. Standard quotas stay free. | Workspace standardized model for agent tools (updated 2026-09-03) |
| F16 | Google advises each super admin to have two accounts, one admin and one non-admin for daily work. | Security best practices for administrator accounts (updated 2026-10-01) |
| F17 | Google's remote MCP servers don't support dynamic client registration. | Authenticate to Google and Google Cloud MCP servers (updated 2026-09-30) |

Research (not Google):
- **F3, Hunters' DeleFriend** (The Hacker News, 2023-11-28): delegation is tied to the account's client ID, not to
  one key. Anyone who can make a new key for a delegated account can act as other users. Google's answer was least
  privilege. **Unit 42** (2023-11-30): an identity able to generate a token for a delegated account can impersonate
  Workspace users.

Composio (official docs, no page dates; read 2026-10-03):
| # | Fact | Source |
|---|---|---|
| C1 | A custom auth config uses your own OAuth app and scopes in place of Composio's shared app. | Managed vs custom auth |
| C2 | Deleting a login stops it at once. `revoke_on_delete=true` also starts a best-effort revoke at the provider. | Delete a connected account; Revoke a connected account |
| C3 | A custom MCP server can use no auth, an API key (`Authorization: Bearer {{generic_api_key}}`) or DCR OAuth; other OAuth grants aren't supported. The feature is experimental. | Custom MCP |
| C4 | Tool allowlists and read-only filters are documented per SDK session; nothing shows them for the CLI or MCP doors. | Create read-only and restricted sessions |
| C5 | Hobby ($0) includes 100,000 tool calls a month and 3 team members. Logins on your own app, API key or MCP are unlimited and free. | composio.dev/pricing |
| C6 | The `googledrive` toolkit has 105 tools. 16 take a domain or admin parameter, among them DELETE_DRIVE, UPDATE_DRIVE, CREATE_PERMISSION and LIST_SHARED_DRIVES with `useDomainAdminAccess`. The `gmail` toolkit includes send, permanent delete, filter, forward and send-as tools. | Composio API v3.1 `GET /tools?toolkit_slug=googledrive` (read-only call, 2026-10-03; raw output not saved); docs.composio.dev/toolkits/gmail |

Case studies (Exa, fetched this turn):
- **Microsoft, Midnight Blizzard (2024-01-25).** Attackers compromised a legacy test OAuth app with elevated
  access, used it to give apps they created mailbox access, and used those apps against Microsoft corporate email
  accounts. Microsoft's advice is to give apps access only to the specific mailboxes they need.
- **ERNW on Shortwave (2025-09-02).** A single email with a hidden prompt injection steered an AI email assistant.
  The mail leaked once the user clicked a link the assistant generated (another path needed a confirmation setting
  turned off). The vendor implemented most of the fixes.
- **Salt Labs on Manus (2026-10-01).** A general-purpose AI agent with mailbox access was asked to check the user's
  mail. One malicious email gave code execution inside the agent, and with it the tokens it held for the user's
  connected email, cloud storage and code accounts. Fixed.
- **Hunters and Unit 42 (2023).** See F3.

Local (read-only):
- L1 `~/.agents/tools/connectors/google_robot/server.py`. Service-account key only (L75 `with_subject(user)`). The
  user defaults to alex@ (L23) and can be any @increaseroas.com address (L67-72). `google_api` reaches any known API
  family's googleapis.com URL, Admin included; unknown APIs are rejected (L52-64, L95-96). `list_users` calls the
  Admin API (L125-136). So it can't simply be reused for a partner.
- L2 `hub/root/opt/mcp-hub/proxy.mjs`. A route with its own token file accepts only that token. **If the file is
  missing, the route falls back to the hub token** (L10). `/healthz` is the only public path (L18).
- L3 `hub/root/etc/supervisor/conf.d/mcp-hub.conf`. No program sets `user=`, so they all run as the supervisor's
  user. That's root if it was installed as a system service (inference; check with `ps -o user` on the hub).
- L4 `hub/install_hub.sh` L26-38: `tagging.json` (the robot's key), the hub token and the Google robot route token
  all come from vault Connectors (`op_items.py` VAULT = "Connectors"). The installer reads secrets only there.
- L5 Rebuild from zero r7: the Connectors vault is shared with Alex, Manny and Anthony. r8 and gap-facts
  G05-addendum: each partner Mac gets a read-only robot, `--vault Connectors:read_items`. Its NOT_PROVEN line says no
  partner robot has been proven end to end.
- L6 spp-c20 §2: Alex's key created a PRIVATE login owned by contact@ (`ca_0k7D-aR92VD7`, read back, then deleted).
  §4: a member sees only 4 characters of a login's key. Running a partner-owned login with Alex's key is not
  proven.
- L7 `~/.agents/tools/cards/composio.md`: Composio disclosed a breach on 2026-05-21.

## 3. Correction to the earlier plan
spp-c20 §7 calls the strongest choice "its own service account with only the Gmail and Drive scopes delegated, so
Google enforces it and a code bug can't widen it". Rebuild r12's partner cell, changed today, names that delegated
account as the plan. F1 and F2 contradict the reasoning. With delegation, Google enforces only the scope list. Any
user in the domain, alex@ included, is one parameter away, and only our code pins the partner. A leaked key, or a new
key minted by anyone who can create one for that account (F3), opens every user's Gmail and Drive. To pin the person,
the token itself has to be the person's own consent: option 2.

## 4. Options compared
Click counts are counted from the documented steps, not timed.
| | (1) Own delegated service account, Gmail + Drive scopes, pin in code | (2) Per-partner OAuth sign-in, no delegation, token in a pinned hub route (**recommended, with 4b**) | (3) Per-partner Composio `gmail` + `googledrive` logins owned by the partner | (4a) Google's own Gmail and Drive MCP servers, per-partner sign-in |
|---|---|---|---|---|
| Google enforces | The scope list, for every user. No Admin API (no admin scopes). | Identity: the token can only act as the partner. The 5 consented scopes. No Admin API. Org-only app. App access control (4b). | Identity and scopes, as in (2), if our own internal client is used (C1). With Composio's shared app: its default scopes. | Identity, narrow scopes, and Google's own narrow tools (no send, delete or share) (F13). |
| Our code enforces | **The user pin** and the tool list. | The tool list (no send, no raw API, no admin flag) and the route token. OS: the process can't read the robot key. | Nothing of ours. Composio's tools are wide (C6), and allowlists are documented only per SDK session (C4). | Nothing, unless a hub adapter is added for Composio (C3, F17). |
| Can a bug or leak widen it? | **Yes, to every user's mail and Drive** (F2, F3). | Only within the partner's own account (e.g. send, or listing shared drives via the admin flag, §5.5). Never another user, never the Admin API. | Within the partner's account: Composio's send, delete and admin-flag tools are bounded only by the scopes. The token sits at Composio (L7). | Within the partner's account. Preview software (F13). |
| Alex's clicks, once | About 17 per partner (34 for both): a Cloud account and key into 1Password, then an Admin delegation entry. A second super admin if multi-party approval is on. | About 47 for both partners (30 Cloud, 17 Admin), or 64 with the recommended Partner AI unit. | About 47 Google, plus 2 Composio auth configs (about 10). | About 47 plus the MCP API enables (about 6), the program application form, and days of waiting (F13). |
| Partner's clicks | 0, and it never expires. | One sign-in link, 3 to 6 clicks. Again only if the token stops (F6). | 2 sign-ins (Gmail and Drive). | One sign-in per MCP server per AI app. |
| Fits Composio and the robot route | Closest to today's server.py: hub route, route token, partner-owned login. | New partner server (no service-account code), one hub route per partner, route token (D22), Composio custom toolkit, partner-owned login (L6), health watch. Adds one public sign-in callback per partner. | No hub work. Goes against the google-workspace card ("not routes: the Composio gmail/googledrive toolkits") and adds a second Google route type. | Composio can't connect to it (C3, F17); it would need a hub token-injecting adapter. |
| Revocation | Delete the delegation entry (at once, F1) or disable the key. | `tokens.delete` (the main robot has that scope), the app Blocked for the unit (F9), Connected applications > Remove if the app is listed there (F8), the partner revoking it, or a new route token (§7). | Composio delete with revoke (best effort, C2), plus a Google-side revoke. | As in (2). |
| Cost | $0 | $0: no billing step, standard quotas (F15), Composio logins free (C5) | $0 (C5) | $0 now; preview terms (F13) |
| Verdict | **Fails the bar** (test 5) and goes against Google's advice. | **Meets tests 1 to 5.** Residual in §5.5. | Fallback if hub work is refused. Weaker control. | Revisit at general availability. |

4b. Admin console app limits (F9): the app is Specific Google data for the Partner AI unit and Blocked for the top
unit, so Google refuses it to everyone else and to any scope beyond the 5. It's part of the recommendation, not a
separate option.

## 5. The recommendation
### 5.1 Shape (per partner; Manny = contact@, Anthony = anthony@)
Google sign-in (internal app "IR partner AI", own Cloud project) -> sign-in helper and route both running as Linux
user `gp-<name>` -> token stored only in `/opt/mcp-hub/partner/<name>/` -> proxy route `/google-partner-<name>/mcp`
with its own route token -> Composio custom toolkit `custom_google_partner_<name>` -> a login owned by the partner's
Composio user. Partner AIs never use `custom_google_robot`. Alex's robot is unchanged.

### 5.2 Who enforces what
The 5 scopes, exact strings (used everywhere below): `openid`, `https://www.googleapis.com/auth/userinfo.email`
(alias `email`), `https://www.googleapis.com/auth/gmail.modify`, `https://www.googleapis.com/auth/drive.readonly`,
`https://www.googleapis.com/auth/drive.file`.
| Layer | Enforces | Kind |
|---|---|---|
| Google identity | The token acts only as the partner. Other mailboxes refused, files not shared with the partner not found. | Google |
| Google scopes | The 5 scopes. No permanent delete, mail settings, filters, forwarding or delegates (F11). No deleting or re-sharing files the app didn't create, no deleting shared drives (needs `drive`, F12). Admin-flag sharing under `drive.file` is NOT_PROVEN (B-P4b). No Admin API. | Google |
| Admin console app access | Only the Partner AI unit may use the app, and only with the 5 scopes. Everyone else is Blocked (F9). | Google |
| Linux user per partner | The partner's processes can't read `tagging.json`, the hub token or another partner's token (root-only, 0600). | OS |
| Route code | Fixed tools on `users/me` only. No send, no raw API, no delete or share tools, never the admin flag. Refuses any `user` other than the partner. | Code |
| Proxy | The partner's route token only (L2). The builder makes partner routes refuse when the token file is missing (§8). | Code |
| Composio | The login is owned by the partner. Members see 4 characters of the key (L6). Whether another member can use it is spp-c20's check (P1). | Vendor |

### 5.3 Tools the route offers (default)
`whoami`, `gmail_search`, `gmail_read`, `gmail_draft` (create or update, threaded), `gmail_labels` (label,
archive), `drive_search`, `drive_read`, `drive_create` (a new file in the partner's Drive). Not offered: send,
delete, sharing, settings, calendar, admin, raw API. Why drafts only: Google's own Gmail MCP server has draft tools
and no send tool (F13). Single malicious emails steered AI agents with mailbox access in the ERNW (2025-09-02) and
Salt Labs (2026-10-01) cases. The scope still allows send, so turning send on later is a route switch (Q1).

### 5.4 The one-time sign-in
The device flow can't carry Gmail scopes (F14). A desktop loopback flow would put the token on the partner's own
machine, within reach of the partner's AI. So it's the web-server flow with offline access (F7), and the callback
lands on the hub:
1. When the partner is ready, the builder runs `partner_signin.py start` as `gp-<name>` on the hub. It stores one
   single-use state (24-hour expiry, PKCE verifier, expected email) in that partner's folder and prints Google's
   sign-in URL, which holds no secret. A leaked link is useless to anyone else, because step 3 accepts only the
   expected account. An expired link just means a new `start`.
2. Alex sends that link to the partner. Real-person contact stays Alex's.
3. The partner signs in and clicks Allow. Google redirects to
   `https://mcp.increaseroas.com/partner-oauth-<name>/callback`, served by that partner's own sign-in helper (same
   Linux user as the route). The helper checks the state and swaps the code (PKCE plus the client secret). It then
   checks the ID token: audience, issuer, verified email, `hd=increaseroas.com`, and the email equal to the
   expected partner. The granted scopes must equal the 5 exactly.
4. Any mismatch: the helper revokes the new token at once and stores nothing. Success: it writes the token (0600,
   owner `gp-<name>`, written by that user itself) and shows "Done". Codes and tokens are never logged.

### 5.5 What's left (residual risks)
1. **Super admins on shared drives.** With `drive.readonly`, Google lets an admin's token list every shared drive
   in the domain using the admin flag (F12). With `drive.file`, `permissions.create` accepts the flag on paper;
   whether it works on a shared drive the app didn't create is NOT_PROVEN (B-P4b). The route never sends the flag,
   so this is code-enforced. Google's general advice for super admins (F16) would remove it (Q5).
2. **Sending** is allowed by the scope. Only the route blocks it.
3. **The public callbacks** are new attack surface: exact paths, GET only, single-use state, PKCE, email check.
4. **Re-sign-in** is needed whenever the token stops (F6). The health watch flags it.
5. **Alex's own robot** can still act as contact@ and anthony@ through delegation. That's unchanged and Alex's.
6. **Composio custom MCP is experimental** (C3). `custom_google_robot` already relies on it.
7. **Google says not to use user credentials for server-to-server deployment** (Using OAuth 2.0, Cloud session
   control section). Our reading, an inference: that means server jobs running on a person's credentials in place
   of a service identity. The web-server guide (F7) documents offline access for acting while the user is away,
   which is this use. The failure it names is Cloud session control, which applies to apps with the cloud-platform
   scope, and that's not one of the 5.

## 6. Prerequisites (the design is moot without them)
- **P0, vault scope (new node needed).** No partner AI may hold a 1Password robot that can read the tagging-admin
  key, the MCP hub token, the MCP Google robot token, any partner route token, or the partner OAuth client secret.
  Today's plan (L5) gives partner Macs `Connectors:read_items`, and Connectors holds all of these (L4). A partner AI
  on Claude Code or Codex could then act as alex@ with all 39 scopes, Admin API included (inference from L4 and L5).
  A robot's vaults can't change after creation, and the hub's installer reads secrets only from Connectors (L4). So
  Connectors stays AI-reachable for Alex's robots only, and partner robots get a separate vault holding only what
  partner AIs may read. Which items go there is an item-by-item call for Alex. Draft text in §10.4. No partner robot
  is recorded yet (L5); check 1Password's service-account list. Not checked: a partner AI using the op CLI through
  the partner's own 1Password app, where the partner's Touch ID approval is the only gate.
- **P1, spp-c20 member test.** A member key can't use, change or delete Alex's logins (checks 4-7). Add one check:
  Anthony's member key can't run Manny's partner login.

## 7. Alex's exact steps (they change nothing until he does them)
Order: Part A, Part B (B1-B5), run A of the proof (§9), B6, then Part C.

Part A: Google Cloud console, as alex@ (about 30 clicks, 10 minutes)
1. Project picker > New project > Name `increaseroas-partner-ai` > Organization: increaseroas.com > Create. Keep it
   separate from `increaseroas-tagging`, where the robot's delegation lives (F2: dedicated projects). If no
   organization can be chosen, stop and tell the Director: the app has to be Internal (F5).
2. APIs & Services > Library > Gmail API > Enable. Then Google Drive API > Enable.
3. Menu > Google Auth Platform > Branding > Get started. App name `IR partner AI`, support email alex@ > Next >
   Audience: **Internal** > Next > contact email alex@ > Next > agree > Continue > Create.
4. Branding > Authorized domains > add `increaseroas.com` > Save.
5. Clients > Create client > Application type **Web application** > Name `partner-robot hub` > Authorized redirect
   URIs > Add URI `https://mcp.increaseroas.com/partner-oauth-manny/callback`, Add URI
   `https://mcp.increaseroas.com/partner-oauth-anthony/callback`, Add URI
   `https://mcp.increaseroas.com/partner-oauth-test/callback` (run A) > Create.
6. Copy the Client ID and Client secret straight into a new 1Password item in vault **Connectors**, titled
   `Google partner AI OAuth client` (username = Client ID, credential = secret). Never paste them in chat, a file or
   a screenshot. Connectors is the only vault the hub's installer reads (L4); P0 keeps partner AIs off it.
7. Data Access > Add or Remove Scopes > Manually add the 5 scopes (§5.2) > Add to table > Update > Save. It's
   optional for Internal apps (F5) but gives B3 a scope list to show.

Part B: Google Admin console, as alex@ (about 17 clicks for B3 alone; about 34 with the recommended unit, B1-B4).
Without the unit (Q2 = no): skip B1, B2 and B4, and in B3 leave the top unit selected.
1. Directory > Organizational units > Create new organizational unit > Name `Partner AI` > parent: the top unit >
   Create. It inherits the top unit's settings (F10).
2. Directory > Users > tick Manny (contact@), Anthony (anthony@) and the run-A test identity > More > Change
   organizational unit > Partner AI > Continue > Change. Admin roles don't change.
3. Security > Access and data control > API controls > Manage App Access > Configure new app > search the Client ID
   from A5 > pick it > Scope: Select org units > Include organizations > tick Partner AI > Select > Continue. Access
   to Google data: **Specific Google data**, ticking the 5 scopes (§5.2). If the list doesn't offer them yet (F9
   shows requested scopes, and nobody has signed in), pick **Trusted** now and do B6 after run A's first sign-in.
   If this edition has no Specific Google data option, keep Trusted. Continue > Finish.
4. Same app > Access to Google data > select the top unit (increaseroas.com) > **Blocked** > Save.
5. With multi-party approval on, another super admin approves. Changes can take up to 24 hours.
6. (Only if B3 had to use Trusted.) After run A's first sign-in: the app > Access to Google data > Partner AI >
   Specific Google data > tick the 5 scopes > Save.
Nothing goes under Manage Domain Wide Delegation. The robot's client 112417209265494842557 stays as it is.

Part C: each partner, after run A passes (about 1 minute)
- The builder runs `start` when the partner is ready, and Alex sends the partner the link. The partner signs in with
  their own account, ticks every box and clicks Allow.

To cut a partner's AI off (any time)
- At once: tell an agent to run `tokens.delete` (partner, client ID) through the main robot (F8; the scope
  `admin.directory.user.security` is delegated, see work/2026-10-01_google-robot/dwd-scopes.txt). Alex can also
  use the Admin console: the partner > Security > Connected applications > Remove, if the app is listed there (F8
  speaks of third-party apps; run A checks).
- For good: Manage App Access > IR partner AI > Partner AI > Blocked (F9).
- Ours: give the partner's route a new random token, which nobody holds (the route then answers 401), or remove the
  route from `routes.json` and stop its program. **Never just delete the token file**: the proxy would then accept
  the hub token on that route (L2).

## 8. Builder plan (after Alex's Parts A-B and a Director fence; nothing here is done)
1. `agents-home tools/connectors/google_robot/partner_server.py` (new). It loads only an authorized-user token file,
   never imports `google.oauth2.service_account`, and won't start on a service-account file or on any scope outside
   the 5. It checks once that Gmail `users/me/profile` equals `PARTNER_EMAIL`. It offers the §5.3 tools on fixed
   URLs (Gmail `users/me/...`, Drive `files...`). A final guard rejects any request carrying `useDomainAdminAccess`
   or a userId other than `me`. `invalid_grant` comes back as "sign-in revoked or expired, Alex sends a new link".
2. `partner_signin.py` (new): `start` and the callback helper from §5.4, run as `gp-<name>`. Tests: state reuse,
   expired state, wrong email, missing or extra scope (revoke, store nothing), success (file 0600, owner
   `gp-<name>`).
3. `proxy.mjs`: (a) public exact paths `GET /partner-oauth-<name>/callback`, nothing else unauthenticated; (b)
   routes named `google-partner-*` or `partner-oauth-*` refuse (401) when their token file is missing instead of
   falling back to the hub token (L2). Tests: every existing route still answers 401 without its token; POST and
   other paths on a callback are refused; a partner route with no token file refuses the hub token.
4. Hub: first check free ports on My OpenClaw (`ss -ltn`; the GHL builder, increase-roas-mcp and openclaw programs
   run there outside the hub folder). Proposed: `google-partner-manny:8111`, `google-partner-anthony:8112`,
   `google-partner-test:8113` (run A only), sign-in helpers `partner-oauth-manny:8121`, `partner-oauth-anthony:8122`,
   `partner-oauth-test:8123` (8110 is the stale javante program, hub README). Supervisor programs get
   `user=gp-<name>`. Route tokens go in `creds/route-tokens/google-partner-<name>` (D22). Add `Google partner AI
   OAuth client` and the partner route tokens to `install_hub.sh` SECRETS. Partner tokens are never restored from
   1Password: after a hub rebuild each partner signs in again. Update `capture_hub.py` (exclude
   `/opt/mcp-hub/partner/`) and the hub README.
5. Composio: first build the key mover's `--user` option (spp-c20 §5, "to be added"). Register one custom MCP
   toolkit per route (API key, `Authorization: Bearer {{generic_api_key}}`, C3). Make each login with Alex's key for
   the partner's Composio user ID (L6), read back owner = the partner, then probe `whoami`.
6. `health/config.json`: one watch entry per partner login (probe `whoami`). An alert on 401 or `invalid_grant`
   tells Alex a re-sign-in is due.
7. Card `google-workspace.md` (tool-card skill): partner AIs use `custom_google_partner_<name>` only.
Unit tests: the tool list equals §5.3; no service-account import; refusal of another `user` and of the admin flag in
every argument; refusal of a token with a scope outside the 5.

## 9. Proof plan
Each check logs method, URL without token, status, Google's reason and the time. Tokens are never printed, and any
redaction is done in Python.

**Run A, a test identity Alex picks** (an increaseroas.com user he can sign in as, ideally not an admin), in the
Partner AI unit, on the temporary route `google-partner-test` (port 8113, user `gp-test`):
- A-P1 works: through Composio, `whoami` = the test identity, plus one `gmail_search` and one `drive_search`
  answer 200.
- A-P2 other users refused. The route refuses `user=alex@increaseroas.com` and makes no Google call. On the hub, as
  `gp-test`: Gmail `users/alex@increaseroas.com/profile` expects 403, `users/contact@increaseroas.com/profile`
  expects 403, and a Drive file only alex@ holds expects 404. The builder makes that file through the robot as
  alex@ under the fence and deletes it after.
- A-P3 no Admin API: `admin.googleapis.com/admin/directory/v1/users?customer=my_customer` expects 403. The reason
  may be the missing scope or the API being off in this project; both refuse.
- A-P4 no admin flag: the route refuses `useDomainAdminAccess` in any argument (unit test and one live attempt).
- A-P6 revoke works (run before A-P5): `tokens.delete` (test identity, client ID) through the robot. Allowing for
  the delay in F7, the next `whoami` expects `invalid_grant` and `tokens.list` no longer shows the client. Check
  whether the app was listed under Connected applications. Then give the test route a new random token: Composio
  expects 401.
- A-P5 nobody else can authorize (after A-P6): Alex opens a fresh link signed in as alex@ and expects Google's
  "blocked by your admin" (needs B4; without the unit, only the next check applies). Then the test identity
  completes a link started for a different expected email: expect "revoked, nothing stored".
- Cleanup: the builder removes the test route, helper, toolkit and login. Alex moves the test identity back to its
  old unit (a B2-style step).

**Run B, each partner, after their one sign-in:**
- B-P1 `whoami` = the partner, plus one Gmail and one Drive read, through the partner's login. The builder runs it
  by login ID if Composio allows an admin run (not proven, L6); otherwise the partner's AI runs `whoami` once.
- B-P2 alex@'s profile expects 403, and the other partner's profile expects 403. B-P3 the Admin API expects 403.
- B-P4, read-only, characterizes the super-admin residual. Google-level `GET drive/v3/drives?useDomainAdminAccess=true`:
  record the answer (200 means the residual in §5.5 is real). The route refuses the same call.
  `DELETE drive/v3/drives/<made-up id>?useDomainAdminAccess=true` expects 403 (scope).
- B-P4b (optional, its own fence): the builder, through the robot as alex@, creates a throwaway shared drive, tries
  `permissions.create` with the admin flag using the partner's token, then deletes the drive. If Google allows it,
  drop `drive.file` (read-only Drive) and have the partner sign in again.
- B-P7 (with spp-c20): Anthony's member key can't run Manny's partner login.
Revoke isn't repeated per partner: run A proved it on the same code and settings.

## 10. Workbook drafts (text only; nothing was written to the workbook or its tab sources)
10.1 **Rebuild from zero r12 (Google Workspace), partner cell**, replacing the current text:
"You keep your own increaseroas.com account and your admin role (Manny and Anthony are super admins). Your AI
gets less than you on purpose. It reaches Google only through your own partner robot login in Composio, which
opens a hub route holding one thing: a Google sign-in you gave once, for your own account. Google limits it to your
own mailbox and the Drive files you can already open, plus new files it creates. It refuses other mailboxes, files
not shared with you, the Admin API, permanent deletes and mail settings. The route adds: no sending, and no admin
access to shared drives. No domain-wide delegation is used. Alex can cut it off at once. (Not built yet: Alex's
Cloud and Admin console steps, then your one sign-in from a link Alex sends.) A new partner first gets a user
account."
- **How cell, add:** "Partner AI (not built yet): Alex makes the internal app IR partner AI in its own Cloud
  project and limits it to the Partner AI unit in Admin console > Security > API controls > Manage App Access
  (work/2026-10-03_partner-robot/design.md §7). Each partner signs in once from a link Alex sends."
- **Who cell, add:** "Partner AI: Alex (Cloud and Admin console; security settings stay his); each partner signs
  in once. No new license and no Google charge."
- **Source cell, add:** "https://knowledge.workspace.google.com/admin/apps/domain-wide-delegation-best-practices
  (updated 2026-10-01, read 2026-10-03) ; https://knowledge.workspace.google.com/admin/apps/control-which-apps-access-google-workspace-data
  (updated 2026-10-01, read 2026-10-03) ; https://developers.google.com/identity/protocols/oauth2 (updated
  2026-05-26, read 2026-10-03) ; work/2026-10-03_partner-robot/design.md"

10.2 **Decisions and why D34, update.**
- **What the evidence suggests instead, replace with:** "Proof when done: spp-c20's checks 4-7 show a member key
  can't change, re-share or delete Alex's logins (otherwise no member key on a partner's machine: the stop case),
  and Anthony's key can't run Manny's partner login. Each partner's robot is the partner's own sign-in, with no
  domain-wide delegation (D35): a read as the partner works; reads as alex@ or the other partner get 403 from
  Google; the Admin API gets 403; a revoke stops it. Partner AIs' 1Password robots can't read the robot key or any
  hub token. The partner's GitHub role is Read."
- **Note, add:** "2026-10-03 (spp-p47a): a delegated account limited to Gmail and Drive doesn't pin a person;
  Google says scopes don't restrict which users a delegated account can impersonate. So the partner robot is
  per-partner OAuth consent instead (D35)."

10.3 **Decisions and why, new row D35** (the next free ID as of 2026-10-03 07:30Z; check again before applying):
- id D35 | verdict PROOF PENDING | group director | found in work/2026-10-03_partner-robot/design.md (spp-p47a)
- decision: "Each partner's AI reaches Google through the partner's own one-time sign-in, never domain-wide
  delegation. The sign-in is to an internal app in its own Cloud project, limited by Alex in the Admin console to
  the Partner AI unit and 5 scopes (openid, https://www.googleapis.com/auth/userinfo.email,
  https://www.googleapis.com/auth/gmail.modify, https://www.googleapis.com/auth/drive.readonly,
  https://www.googleapis.com/auth/drive.file). One hub route per partner holds only that partner's token and runs
  as its own Linux user. It offers search, read, drafts, labels and new files: no send, no raw API, no admin flag.
  Each partner's Composio login for it belongs to the partner."
- what the evidence suggests instead: "Proof when done: run A on a test identity (works; other users refused by the
  route and by Google; Admin API refused; revoke stops it; nobody outside the unit can authorize), then run B per
  partner (design §9)."
- best evidence: "Google, Domain-wide delegation best practices (updated 2026-10-01): avoid delegation when OAuth
  consent can do the job; scopes don't restrict which users a delegated account can impersonate. Google, Control API
  access with domain-wide delegation: a delegated app can use all users' data."
- why it was decided: "Alex's partner rule (D34, 2026-10-02). A delegated account limited to Gmail and Drive is
  pinned to one person only by our code. A bug, its key, or a new key minted by anyone who can create one
  (Hunters' DeleFriend, 2023-11-28) reaches every user. Unit 42 (2023-11-30) showed the same with generated tokens.
  A user's own sign-in can only act as that user. In Microsoft's Midnight Blizzard case (2024-01-25), attackers
  turned a compromised test app with elevated access into apps that targeted corporate mail; Microsoft's advice is
  to give apps access only to the mailboxes they need. Drafts only, because single malicious emails steered AI
  agents with mailbox access in the ERNW (2025-09-02) and Salt Labs (2026-10-01) cases."
- evidence type: "vendor docs + research + incident case studies" | source title: "Domain-wide delegation best
  practices (Google Workspace Help)"
- other sources: "https://knowledge.workspace.google.com/admin/apps/control-api-access-with-domain-wide-delegation
  (updated 2026-10-01); https://knowledge.workspace.google.com/admin/apps/control-which-apps-access-google-workspace-data
  (updated 2026-10-01); https://thehackernews.com/2023/11/design-flaw-in-google-workspace-could.html (2023-11-28);
  https://unit42.paloaltonetworks.com/critical-risk-in-google-workspace-delegation-feature/ (2023-11-30);
  https://www.microsoft.com/en-us/security/blog/2024/01/25/midnight-blizzard-guidance-for-responders-on-nation-state-attack/
  (2024-01-25); https://insinuator.net/2025/09/stealing-emails-via-prompt-injections/ (2025-09-02)"
- note: "Corrects spp-c20 §7's 'strongest' line and Rebuild r12's delegated-account plan. $0: no billing step, and
  Composio logins are free on Hobby. Alex: about 47 console clicks once, about 64 with the Partner AI unit. Each
  partner: one sign-in, repeated only if the token stops (password change, 6 months unused, a revoke, an admin
  restriction or the token limit). Residual: partners are super admins, so their Drive read token can list shared
  drives with the admin flag; the route never sends it. Not built."
- source: the URLs above with dates ; work/2026-10-03_partner-robot/design.md ; notes/decision-evidence.csv row D35
  (to add)

10.4 **Rebuild from zero r8 (1Password robot logins), partner cell** (prerequisite P0; its own node). Draft:
"A partner's own Mac gets its own read-only robot from Alex for a vault that holds no admin-grade keys. It's never
Connectors, which holds the Google robot's key and the hub tokens. Which items that vault holds is Alex's call
(open)." The G05-addendum step 1 (`--vault Connectors:read_items`) changes the same way.

## 11. Open questions for Alex (none blocks the design; the defaults above stand until he answers)
- Q1 Send: drafts only for partner AIs (the default, as in Google's own Gmail MCP server), or allow send?
- Q2 The Partner AI unit plus the block elsewhere (B1, B2, B4; about 17 extra clicks): recommended, yes or no?
- Q3 The test identity for run A.
- Q4 Partner tokens: no 1Password copy (default; a hub rebuild means one re-sign-in each), or a copy in an
  Alex-only vault the hub can't read today?
- Q5 Google's general advice (F16), a separate non-admin daily account per partner, would remove the last admin
  residual, at one more license each. It isn't offered as a recommendation: no case study turned up this turn.
- Q6 P0: which 1Password items partner AIs may read.

## 12. Sources (all read 2026-10-03 via Composio Exa; "updated" = the page's own date)
Google:
- https://knowledge.workspace.google.com/admin/apps/control-api-access-with-domain-wide-delegation (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/apps/domain-wide-delegation-best-practices (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/apps/control-which-apps-access-google-workspace-data (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/security/manage-a-users-security-settings (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/users/security-best-practices-for-administrator-accounts (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/users/advanced/add-an-organizational-unit (updated 2026-10-01)
- https://knowledge.workspace.google.com/admin/users/advanced/move-users-to-an-organizational-unit (updated 2026-10-01)
- https://developers.google.com/identity/protocols/oauth2 (updated 2026-05-26)
- https://developers.google.com/identity/protocols/oauth2/web-server (no page date)
- https://developers.google.com/identity/protocols/oauth2/limited-input-device (no page date)
- https://developers.google.com/identity/protocols/oauth2/native-app (updated 2026-09-14)
- https://developers.google.com/identity/protocols/oauth2/service-account (updated 2026-03-23)
- https://support.google.com/cloud/answer/15549945 (Manage App Audience, no page date)
- https://support.google.com/cloud/answer/13464323 (When is verification not needed, no page date)
- https://developers.google.com/workspace/guides/configure-oauth-consent (updated 2026-09-03)
- https://developers.google.com/admin-sdk/directory/reference/rest/v1/tokens/delete (updated 2026-03-10)
- https://developers.google.com/workspace/gmail/api/auth/scopes (updated 2026-09-10)
- https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.settings.delegates/create (updated 2026-04-15)
- https://developers.google.com/workspace/drive/api/guides/api-specific-auth (updated 2026-09-03)
- https://developers.google.com/workspace/drive/api/guides/manage-shareddrives (updated 2026-09-03)
- https://developers.google.com/workspace/drive/api/reference/rest/v3/drives/list (updated 2026-07-07)
- https://developers.google.com/workspace/drive/api/reference/rest/v3/drives/delete (updated 2025-08-13)
- https://developers.google.com/workspace/drive/api/reference/rest/v3/permissions/create (updated 2026-09-14)
- https://developers.google.com/workspace/guides/configure-mcp-servers (updated 2026-09-18)
- https://developers.google.com/workspace/gmail/api/guides/configure-mcp-server (updated 2026-09-18)
- https://developers.google.com/workspace/preview (updated 2026-10-01)
- https://developers.google.com/workspace/tools-safety (updated 2026-09-03)
- https://workspaceupdates.googleblog.com/2026/05/agent-tools-and-security-updates-for-workspace-developers.html (2026-05-01)
- https://docs.cloud.google.com/mcp/authenticate-mcp (updated 2026-09-30)
Composio:
- https://docs.composio.dev/docs/authentication/custom-app-vs-managed-app ; https://docs.composio.dev/docs/auth-configuration/custom-auth-configs
- https://docs.composio.dev/reference/api-reference/connected-accounts/deleteConnectedAccountsByNanoid ; https://docs.composio.dev/reference/api-reference/connected-accounts/postConnectedAccountsByNanoidRevoke
- https://docs.composio.dev/docs/extending-sessions/custom-mcp ; https://docs.composio.dev/kb/guide/platform-session-tool-policies
- https://docs.composio.dev/toolkits/gmail ; https://composio.dev/pricing ; Composio API `GET /api/v3.1/tools?toolkit_slug=googledrive` (read-only)
Research and case studies:
- https://thehackernews.com/2023/11/design-flaw-in-google-workspace-could.html (2023-11-28)
- https://unit42.paloaltonetworks.com/critical-risk-in-google-workspace-delegation-feature/ (2023-11-30)
- https://www.microsoft.com/en-us/security/blog/2024/01/25/midnight-blizzard-guidance-for-responders-on-nation-state-attack/ (2024-01-25)
- https://insinuator.net/2025/09/stealing-emails-via-prompt-injections/ (2025-09-02)
- https://www.prnewswire.com/news-releases/salt-labs-research-a-single-email-could-hijack-an-ai-agent-and-reach-a-users-connected-accounts-302895317.html (2026-10-01)
Composio log IDs of the page fetches cited above: log_l-oYeqKTDnNT, log_ncZThHVVflGK, log_hSrBCkw7j3zx,
log_idmtcZPI4eRu, log_XlAgmpBp-wKb, log_TU6aswWqRNu4, log_TE0mEFfL4V7U, log_eb6eCwE9QvmS, log_N9PKZGZ5adTE,
log_3S8yYQ3l8ymC, log_kGZqyUhsbZhU, log_SBNyYP1ivO51, log_fv71SLqxAjJz, log_v1Q5DylcTQ7g, log_l-q2GhOF6x-2.
Exa cost this play: about $0.19 (20 searches at $0.007, and page fetches of about $0.05, as Exa reported per call).
