# spp-c18: how a partner reaches the shared Composio logins (G01) — research only (Conductor, 2026-10-01)

**Short answer: a partner who joins org wearenumber1 today reaches nothing. All 46 logins are PRIVATE to Alex, and 0 are shared.**
- **Stock apps** (OAuth and API-key alike, e.g. Firecrawl) can be shared from the dashboard with "For your team". Members without their own login then use it automatically, "In MCP".
- **Custom routes** (the Google robot, GHL CRM, Meta's custom pieces, Cloudflare, Foreplay, the hub routes, and the DCR-based GHL builder) have no team option in the dashboard. They can only be shared through Composio's API, with an experimental SHARED account type and an access list.
- **NOT_PROVEN:** whether a member's MCP or CLI session picks up an API-made SHARED login. Nothing in the account was changed.

## 1. What a new member sees
- **Live (read-only GET of the For You project's connected accounts, run outside the sandbox because large responses get cut off inside it):**
  - 46 connected accounts, all `PRIVATE`, all owned by Alex's consumer user; 0 `SHARED`.
  - The custom routes are API-key logins: custom_google_robot, custom_ghl_oauth_crm, custom_cloudflare_api, custom_foreplay, custom_atlas_cloud, custom_ga4_admin, custom_google_tag_manager, custom_ir_notes, custom_prime_intellect, custom_spyfu, custom_xai_research. metaads is an API-key login too.
  - custom_ghl_command_builder is `DCR_OAUTH`.
  - Script: scratchpad `c18_accounts.py`. It prints toolkit, status, type and owner only, never credentials.
- **Dashboard (Conductor's own tab, look only, closed after):**
  - Settings → Members: 1 member, alex@increaseroas.com, Admin, joined Aug 4, 2026.
  - Apps → Shared connections: "No shared connections yet … Teammates without their own connection are covered automatically in MCP."
- **Docs:** Composio KB, "Consumer and Developer Project Boundaries" (https://docs.composio.dev/kb/guide/consumer-project-boundaries-and-auth-selection, read 2026-10-01):
  - For You connections "belong to the member who authorized them". A teammate's own Connect MCP or `ck_*` key "resolves to their own connected accounts, not yours".
  - Members can connect their own; Viewers can't connect or invoke.
- **Verdict:** a new member sees and can use none of Alex's 46 logins.

## 2. Does "For your team" cover API-key and custom-auth logins?
- **Stock API-key apps: yes, in the dashboard.** Firecrawl (an API-key app) offers a dropdown with two choices:
  - "For you — Only you can use this connection";
  - "For your team — Anyone on your team can use this connection (In MCP)".
  - Composio's post "Introducing Composio Shared Connections" (https://composio.dev/blog/introducing-composio-shared-connections, 2026-09-14) describes the flow: Apps → Connect dropdown → Connect for your team, then sign in again to make a separate shared copy, while the private one stays private. Teammates without their own connection "automatically use the team connection", and a personal connection always takes priority.
- **Custom routes: not in the dashboard.** The custom app page (custom_google_robot) shows only Delete, Sync and "Connect another account", and its card has no team dropdown.
- **Custom routes: yes in the API, experimental.** Composio API reference, "Create a new connected account" v3.1 (https://docs.composio.dev/reference/api-reference/connected-accounts/postConnectedAccounts, read 2026-10-01):
  - the same request that carries `state.authScheme` (OAUTH1, OAUTH2, API_KEY, …) takes `experimental.account_type: "PRIVATE" | "SHARED"` and `acl_config_for_shared` (`allow_all_users`, `allowed_user_ids`, `not_allowed_user_ids`);
  - so an API-key login like our key mover's can be created as SHARED.
- **The catch, from the docs.** "Shared connections" (https://docs.composio.dev/docs/shared-connections) says:
  - a SHARED connection "is never resolved implicitly", so a session reaches it only when pinned by `ca_` ID;
  - access is deny-by-default and governed by the access list, which only the creator or an API-key caller can change;
  - at most one SHARED connection per toolkit per session.
  - The dashboard's "covered automatically in MCP" means the For You MCP layer does that pinning for dashboard-made team connections. Whether it also pins a SHARED login made through the API (our only route for custom toolkits) is NOT_PROVEN.
- **DCR_OAUTH (the GHL builder):** no evidence either way that it can be shared. NOT_PROVEN.

## 3. The documented way for a partner to use shared logins
- **The steps:** Alex invites the partner (Settings → Members → Invite Member, role Member) and creates team connections. The partner then uses Composio through MCP (Composio Connect, https://connect.composio.dev/mcp, or the Claude/ChatGPT Composio apps), and team connections apply where they have no login of their own (blog; dashboard wording).
- **"In MCP" is the documented scope.** Whether the partner's composio CLI (our first choice on Claude Code and Codex, per the composio card) sees team connections is NOT_PROVEN; the dashboard only promises MCP.
- **Platform guidance** (Composio "Design a B2B agent", https://docs.composio.dev/docs/b2b-agents):
  - choose member-owned or workspace-owned per connection;
  - give workspace-owned logins a dedicated integration identity so they survive membership changes;
  - "Shared connections are … experimental … Pin and test the SDK version before making shared connections part of a production tenant model";
  - test that "a removed member can no longer invoke workspace-owned connections".

## 4. Three designs
| Design | How | Access implications | Work |
|---|---|---|---|
| **A. Shared org logins** ("partners equal") | Stock apps: dashboard "For your team" (Alex re-signs in or re-enters the key). Custom routes: the key mover gets a `--shared` option that creates an API SHARED login with `allowed_user_ids` = named partners (not allow-all). | Partners act with Alex's full credentials: the robot acts as any increaseroas.com user, the Meta system user, the Cloudflare read/write token, the GHL agency. One login per app; usage history shows who used each shared login; revoke by access list or by removing the member. Guard hooks protect only Macs that have them, and ChatGPT web has no per-write approval (spp-c17). | Lowest long-term clicks. Rests on two NOT_PROVEN points: auto-use of API-made SHARED logins, and CLI support. |
| **B. Partner's own logins** (member-owned) | Partners connect their own stock apps. For custom routes, Alex makes PRIVATE logins owned by the partner's consumer user ID, with partner-specific tokens (a per-partner hub route token, a per-partner GHL gateway key, a scoped Cloudflare token, a partner Meta token). | Least privilege, clean per-partner revoke, separate audit. Uses only ordinary PRIVATE resolution (no experimental feature), so it works in the CLI and in MCP. NOT_PROVEN: creating a login for another member's consumer ID with Alex's user key. | Most setup: tokens and 1Password items per partner per route. |
| **C. Mix** | Share the low-risk read and research routes with "For your team" (IR notes rules, Exa, Firecrawl, Apify, SpyFu, Foreplay, docs readers). The sensitive routes (Google robot, GHL CRM, Meta Ads, Google Ads, Cloudflare, Gmail/Slack sends) get per-partner logins as in B, or stay with Alex's agents. | A partner researches and reads rules on day one; spend, sends and client data stay behind per-person credentials. | Medium. Needs a per-route split decision. |

**Recommendation: A**, with named-partner access lists. It matches the mission's "partners equal", one source of truth and fewest clicks. Gate it on the live test below, because its custom-route half rests on Composio's experimental API.

## 5. The one live test that proves A (needs a second account: Alex's call)
1. **Alex:** invite one test member to wearenumber1 as Member (a partner's increaseroas.com account or a spare test account), and say yes to one shared test login.
2. **Conductor:** create one SHARED copy of a read-only custom route, custom_ir_notes. The key goes from 1Password through the key mover, so no one sees it. `allowed_user_ids` = the test member's consumer ID only.
3. **As the test member:**
   - (a) Composio Connect MCP with their own `ck_` key: call `CUSTOM_IR_NOTES_GET_APP_RULES` app=ghl. **Pass = it answers through the shared login.**
   - (b) The composio CLI signed in as the test member, in a separate profile so Alex's CLI isn't touched: the same call. This result decides whether partners' Claude Code and Codex can stay on the CLI or must use MCP.
4. **Alex's dashboard:** the shared login's usage history shows the test member's call.
5. **Revoke:** take the test member off the access list, then repeat 3(a). **Pass = denied.**
6. **Clean up:** delete the shared test login; Alex removes the test member.

About 30 minutes and no spend. If 3(a) fails, A works only for stock apps, so switch the custom routes to C or B.

## 6. Live test prep and one change: a fake key first (Conductor, 2026-10-02 13:30 EDT)
- **State.**
  - Alex said yes to the test with contact@increaseroas.com, and contact@ has joined wearenumber1.
  - op works again (the Director confirmed it at about 13:20).
  - The contact@ CLI profile (scratchpad `c18-contact-home`) is still signed out, so a fresh sign-in link gets made only when Alex says his brother is ready. Links expire in about 10 minutes.
- **Read-only checks (scratchpad `g01_shared.py prep`):**
  - auth config `ac_Ypwo60n-AhHy` (custom_ir_notes, API_KEY, ENABLED);
  - Alex's PRIVATE login `ca_zTNUL9d6xZDl` ACTIVE;
  - 0 SHARED logins in the project;
  - consumer user IDs look like `consumer-…`. contact@'s ID comes from their CLI profile's cache after sign-in, because `composio whoami` shows only email and org.
- **Why the first round uses a fake key.** custom_ir_notes' key is the hub token (gap-facts §74). The hub proxy accepts that token on every route without its own token file (proxy.mjs `tokenFor`). install_hub.sh installs only two route tokens, google-robot and atlas-cloud. So the hub token also opens gtm, ga4-admin, xai-research, prime-intellect and spyfu. Sharing it could hand a member GTM and GA4 writes and two paid APIs, if Composio shows members the stored key. Nobody has tested whether it does.
- **The change.** The SHARED copy is created with an obviously fake key. That still proves resolution:
  - if contact@'s call reaches the hub, the hub answers `401 unauthorized`, so the shared login was used;
  - if Composio doesn't resolve the login, the call fails before the hub;
  - step 3 adds a check of whether contact@ can read the stored key (`g01_shared.py get <ca> --home <profile>`). That's safe to print, because the value is fake.
- **Test order** (CLI as contact@):
  1. implicit call (no `--account`);
  2. explicit pin (`--account <ca_…>`);
  3. key visibility;
  4. usage history in Alex's dashboard;
  5. revoke (`acl <ca> --clear`), then repeat 1 and 2, expecting a Composio denial (`ComposioSharedAccessDeniedError`);
  6. clean up after Alex's go.
- **Real-key round, only if resolution works and members can't read the key.** First give ir-notes its own route token (`creds/route-tokens/ir-notes`, 1Password item, Alex's PRIVATE login updated) so a shared login never carries the hub token. The same rule applies to design A in general: every hub-routed custom login that gets shared needs its own route token first.
- **API facts used** (docs read 2026-10-02):
  - create: `POST /api/v3.1/connected_accounts`, with `connection.experimental.account_type` and `acl_config_for_shared`;
  - change the access list or swap the key: `PATCH /api/v3.1/connected_accounts/{id}` (https://docs.composio.dev/reference/api-reference/connected-accounts/patchConnectedAccountsByNanoid);
  - access-list writes are allowed only for the creator or an API-key caller.

## Also found (for spp-c17)
Composio Settings → General → Enhanced Control (BETA) is "temporarily disabled … will relaunch in the future", and per the same page it isn't supported on Claude.ai or ChatGPT.com. So spp-c17's optional server-side backstop isn't available today.

## 7. Live test, round 1 (fake key): results (Conductor, 2026-10-02, about 17:55–18:15 EDT)
**Verdict: an API-made SHARED login DOES reach a partner, but only when the partner's session pins it by ID. It is never picked up implicitly, and the CLI can't pin it. Members can't read the key, and revoking access works at once. Not proven: whether Composio's chat-app MCP (connect.composio.dev/mcp) pins SHARED logins by itself.**
- **Setup:**
  - Alex said "ready". Manny approved a fresh CLI sign-in link as contact@increaseroas.com (org wearenumber1 selected; contact@ also has its own contact_workspace).
  - contact@ had 0 connections of its own. Its consumer user ID has the form `consumer-<uuid>-ok_<org id>`, in the same For You project pr_JDtrNq9tUa_i.
  - Created (as Alex): SHARED custom_ir_notes login `ca_sEh_ubvV2Jka`, alias g01-shared-test, with a FAKE key, ACL allowed_user_ids = [contact@'s consumer ID] only (`g01_shared.py create`).

| # | Test (as contact@ unless noted) | Result |
|---|---|---|
| 1 | CLI, implicit: `composio execute CUSTOM_IR_NOTES_GET_APP_RULES -d '{"app":"ghl"}'` | Not resolved: "No active connection found for toolkit custom_ir_notes" (ToolRouterV2_NoActiveConnection) |
| 2 | CLI, explicit: `--account ca_sEh_ubvV2Jka` | Fails: ConnectedAccountResolutionError, "No connected account matched … for toolkit custom_ir_notes". The CLI only searches the caller's own logins |
| 3 | Tool-router session (POST /api/v3.1/tool_router/session, contact@'s own user key), no pin, then execute | Not resolved (NoActiveConnection) |
| 4 | Same session API with `connected_accounts: {custom_ir_notes: [ca_sEh_ubvV2Jka]}`, then execute (POST /api/v3/tool_router/session/{id}/execute) | **Resolved:** the call reached the hub with the shared login's fake key, and the hub answered `HTTP 401 Unauthorized` (log_id log_RyJtr95SeAQA) |
| 5 | Key visibility: GET the connection as Alex (creator) and as contact@ | Both see the ACL. The key comes back masked as `g01-...` (first 4 characters) in data, params and state.val, for creator and member alike |
| 6 | Revoke (as Alex): `acl --clear`, then repeat test 4 | **Denied** at session create: ToolRouterV2_SharedConnectionNotAccessible, "Session user … is not authorized to use SHARED connection" |

- **Clean-up, done:**
  - the test login was deleted (200), so the project has 0 SHARED logins again, and Alex's PRIVATE ir_notes login is untouched;
  - contact@'s CLI test profile was signed out and its folder removed;
  - contact@ stays a member of wearenumber1. Removing it is Alex's choice, since Manny is onboarding as a partner.
- **What this means for the designs:**
  - **A (shared org logins) works for custom routes only through pinned sessions.**
    - A partner's Claude Code or Codex can't use the composio CLI for shared logins; they'd need a small wrapper that opens a pinned session (as g01_session.py did) or the SDK's `sessions.create(..., connected_accounts=…)`.
    - Chat apps pin only if Composio's chat-app MCP does it for them. That's untested for API-made SHARED logins, and the dashboard promises it only for its own "For your team" connections.
  - **The key stays server-side:** a member sees only the first 4 characters.
  - **The route-token rule (§6) still stands,** because the hub token's blast radius is about what a shared login can do, not about reading the key.
  - **B (per-partner PRIVATE logins)** works in every path (CLI, chat apps), because it's ordinary implicit resolution.
- **To settle the chat-app question (needs contact@'s clicks, owner's call):**
  - (1) re-create the shared test login (fake key, ACL contact@);
  - (2) Manny connects Composio in a chat app as contact@;
  - (3) he asks it to run CUSTOM_IR_NOTES_GET_APP_RULES. A "401" from the hub means the MCP pins SHARED logins; "no active connection" means it doesn't.
