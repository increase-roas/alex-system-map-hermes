# Gap facts: order and wording for G05, G15, G21, G22, G23

As of 2026-10-01. Play spp-p20a (mission-setup-playbook-parity, node playbook-tabs). This was read-only research. No system, config, hub, repo or service was changed, and this file is the only output.

Step labels are the Rebuild tab's own, from `tabs/rebuild-from-zero.json`. The tester's labels differ in Phases 4 and 8: the tester's 4.3 is JSON 4.5, 4.5 is JSON 4.6, 8.3 is JSON 8.4 and 8.4 is JSON 8.5. Workbook rows are cited as they stood in the 15:48 export.

## 1. Research log

Web pages. Each one was fetched in full before it was cited.

| URL | read | Exa logId | what it supports |
|---|---|---|---|
| https://www.1password.dev/service-accounts/get-started | read 2026-10-01 | search `log_mNvtQ029o32R`; fetch `log_YSQ0QdWQ_M57` | The wizard and `op service-account create` show the token only once. 1Password says to save it in 1Password right away (the wizard's Save in 1Password lets you pick the vault) and never to keep it in plaintext. |
| https://www.1password.dev/service-accounts/security | read 2026-10-01 | search `log_mNvtQ029o32R`; fetch `log_YSQ0QdWQ_M57` | You set access per vault and per permission, and a robot only reads the vaults it was given. Saving and protecting the token is the owner's job. Tokens can be rotated or revoked. |
| https://www.1password.dev/service-accounts/use-with-1password-cli | read 2026-10-01 | search `log_mNvtQ029o32R`; fetch `log_YSQ0QdWQ_M57` | The CLI takes the token from `OP_SERVICE_ACCOUNT_TOKEN`. `op user get --me` shows the robot's Name and Type SERVICE_ACCOUNT. |
| https://github.com/zalando/go-keyring/issues/24 | read 2026-10-01 | search `log_iCzFJYBHSCDj`; fetch `log_YSQ0QdWQ_M57` | When a password is passed to `security` on the command line, other processes can see it. The fix is a prompt or stdin. |
| https://ss64.com/mac/security.html | read 2026-10-01 | search `log_iCzFJYBHSCDj`; fetch `log_YSQ0QdWQ_M57` | Fetched but not cited: its text doesn't include the add-generic-password options. |

Local fact (not web): this Mac's man page, `/usr/share/man/man1/security.1`. L457 says that with `-w` placed last, `security` prompts for the password, and marks that as recommended. L465 says `-U` updates an item that already exists. L471 says the app that creates an item is trusted to read it without a warning.

Local files read (newest evidence kept when two disagree):
- **Gaps:** `notes/replication-retest-prelim.md`, `notes/replication-export/connectors-workbook-export-1548.txt` and `tabs/rebuild-from-zero.json`.
- **Hub:** `~/.agents/tools/connectors/hub/{install_hub.sh, rebuild_hub.py, README.md, root/etc/supervisor/conf.d/mcp-hub.conf, root/opt/mcp-hub/health/loop.sh}` and the file list of `root/opt/mcp-hub/`.
- **Health check:** `~/.agents/tools/connectors/health/health_check.py` and `config.json` (keys only, no values printed).
- **Scripts:** `orgo_op.py`, `gcloud_robot.py`, `push_key_to_composio.py` and `~/.agents/tools/unify/check.py` (docstrings and key lines).
- **Cards:** `~/.agents/tools/cards/browser-and-computer.md`.
- **Notes, by file time:** `conductor-ui-lane.md` (16:06), `decision-evidence.csv` (15:39), `hard-rule-checks.md` (15:34), `codex-restore.md` (15:31), `onepassword-one-route.md` (14:44), `expected-state.csv` (12:24, stale on these points), plus `rca-codex-plugins.md` and `work/2026-10-01_chatgpt-claude-research/notes/r2-1password-chatgpt.md`.
- **Skimmed by keyword only:** `cursor-audits-review.md` (14:28). It added two points to G15: the unused `~/.codex/mcp-servers` folders, and Claude Desktop's 1Password pairing flag.
- **Not read:** the `live-*.md` notes (12:24–12:26). Newer notes cover the same points.

## 2. G05: unclear step 4.2 (the robot token in the Keychain)

**Problem.** Step 4.2 names the Keychain item. It doesn't say how to store the token safely, which robot belongs there, or where the backup lives.

**Corrected order**
1. 4.1: create both robots and save each token in 1Password as soon as it's shown.
2. 4.2: put one token in the Keychain with the prompt form of `security`, then check it with `op user get --me`.
3. 4.3: the record of today's state; one sentence changes.
4. 8.1: run the full hub-item check (`rebuild_hub.py --check`), which moves here from 4.2.

**Replacement wording.** The full text is in the G05 block in §7. Targets in `tabs/rebuild-from-zero.json`:
- Section "4. Keys (1Password)", step 4.1, "what to do": add the backup rule.
- Same section, step 4.2:
  - "what to do": replace the whole cell.
  - "repo, file or command": `security add-generic-password -U -a connectors-sync -s op-service-account-connectors-sync -w ; pbcopy < /dev/null`.
  - "how you know it worked": replace the whole cell.
- Same section, step 4.3, "what to do": change one sentence. "Still open: the read-write token has no backup item in Connectors." becomes "Still open: the read-write token has no backup item; save one outside the Connectors vault (step 4.1 says why)."
- Section "8. The Orgo hub", step 8.1, "how you know it worked": say that it now also covers 4.2's old check.
- For consistency, the lead may also align Composio + 1Password right way R59 ("saves a backup item for the read-write token") with the outside-Connectors rule.

**Reason**
- **History and process list.** A token typed after `-w` lands in shell history and shows in the process list (go-keyring #24). The export already records keys found in shell history (Do, Don't and why R5). With `-w` placed last, `security` prompts and hides the input (man page L457).
- **No prompt for the scripts.** Four scripts read the item with `/usr/bin/security` under these exact names: `rebuild_hub.py` L48–L53, `orgo_op.py` L33, `gcloud_robot.py` L39 and `push_key_to_composio.py` L21. The app that creates an item is the one trusted to read it (man page L471), so creating it with the same command means no prompts later. Keychain Access or `-A` would break that or open the item to every app.
- **Which robot.** Today the item holds the read-write robot (install_hub.sh L4; C+1P R32). D08 (read-only by default) is decided but deferred until testing ends (decision-evidence.csv row D08). A rebuild should match today's state. `-U` swaps the value when D08 is applied (man page L465).
- **Backup.** 1Password shows each token once and says to save it in 1Password straight away. A robot can read every item in its vault, so a read-write token stored in Connectors would give the read-only robot write power and undo D08. The read-only token's backup item stays as step 4.3 names it. Item names are in the G06 catalog.

**Conflicts resolved**
- Rebuild 4.3 ("no backup item in Connectors") and C+1P R59 suggest the read-write backup goes in Connectors. I kept the 1Password security page and D08's least-privilege aim, which point outside Connectors. This is a proposal that Alex or the Director should confirm (§8).
- The item's name says read-only but it holds the read-write token. I kept today's fact (fingerprints, Rebuild 4.3; the scripts' docstrings) and kept the name, because four scripts hard-code it.

## 3. G15: unclear step (what each AI keeps)

**Problem.** The rule (SOP R4) points to the AI apps rows for each AI's built-ins, but those rows don't name them. Four keep-or-remove points also contradict each other across tabs.

**Corrected order.** The order doesn't change:
1. 0.2: the rule, now pointing at the new AI apps table (G15 block, §7).
2. 11.1 to 11.6: set up each AI as its row says.
3. 11.7: remove only what the row's "removes" column lists, backing up first.

**Replacement wording.** The per-surface table is the G15 block in §7, target tab AI apps. It replaces the "only here" and verdict text of AI apps R4, R5 and R9. Rebuild cells in `tabs/rebuild-from-zero.json`:
- **Section "0. Read this first", step 0.2, "what to do":** "Each AI keeps only Composio, its own 1Password route and the built-ins its AI apps row names (browser, computer use, document tools and the skill packs a role skill needs), one per job. Anything else on an AI is a finding to remove."
- **Section "11. Connect each AI app", step 11.5:**
  - "what to do": replace "Keep [mcp_servers] 1password." with "Remove [mcp_servers.1password] (1Password's Environments server) after backing up config.toml to ~/Backups. Codex's 1Password route is the op CLI and the connectors-sync scripts."
  - "how you know it worked": replace "`codex mcp list` shows 1password" with "`codex mcp list` no longer lists 1password".
- **Same section, step 11.7, "what to do":** replace "Remove only what the expected-state list (notes/expected-state.csv) marks as a duplicate of a proven route" with "Remove only what that AI's row on the AI apps tab lists under removes". The expected-state list isn't in the export, and it's stale here: it still marks the Codex 1password MCP as kept.
- **Rows that follow from this:**
  - C+1P R15 and R65: the Codex removal is no longer blocked.
  - C+1P R17: "stays installed" becomes "remove (proposed)".
  - All connections R3: "Stays" becomes "Remove".
  - All connections R210: "Decide" becomes "Removed (D07)".
  - All connections R86–R88: "Remove" becomes "Removed (W04)".

**Reason.** The rule can't be checked until each AI has a named list. These lists come from the newest decisions and live readbacks.

**Conflicts resolved (four)**
1. **Codex's 1Password MCP** (Rebuild 11.5 says keep; All connections R3 says stays; D07 says all 5 MCP servers off).
   - D07's five servers are orgo, composio-docs, hermes-docs, meta-ads-docs and computer-use (rca-codex-plugins.md L91–L98, L132). The 12:47 cleanup kept any block whose name contained "1password" (rca L14), so 1password was never one of the five. It still starts in Codex threads (codex-restore.md L106; conductor-ui-lane.md L16).
   - **Kept: remove it.** That follows D03 (secrets only through the service-account route), W03 (Codex's 1Password route is the op CLI and scripts), onepassword-one-route.md L89–L94 and L128, and C+1P R65. Those are newer than the early r2 research ("keep", r2 L69–L71) and the retired "exactly two connectors" rule behind R3.
   - The edit was waiting for the Codex config writer, which released the file at 19:31Z (codex-restore.md L8). It is now unblocked but not yet done.
2. **Codex's Orgo MCP and docs helpers** (All connections R210 says Alex decides; AI apps R5 counts them as kept).
   - **Kept: D07 and W04, both off.** Orgo goes through `orgo_op.py`. The docs helpers were replaced by the Composio docs readers once Context7 answered Composio and Meta questions (Decisions R46).
   - Applied and read back: "Left off, as decided" (codex-restore.md L21). Those decisions are newer than R5 and R210.
3. **The Claude app's plugins** (AI apps R9 says "Composio connector only"; L04 keeps desktop-commander and pdf-viewer).
   - This isn't a real conflict: R9 is about connectors, and W03 (SOP R4) says built-ins aren't connectors. **Kept:** L04 for the plugins, and R9's rule for connectors.
   - Qt docs: W05 and R9 leave it to Alex. **Kept:** SK40-D5, the later Director decision, which uninstalls qt-development-skills. Composio CUSTOM_QT_DOCS stays the Qt docs route.
   - browser-use: L04 keeps it only if it can be fixed. It failed to connect on 2026-10-01 (R9), so it goes unless fixed.
4. **ChatGPT's 1Password plugin** (C+1P R17 and r2 L13–L14 say keep; W03 says ChatGPT's 1Password route is none).
   - The plugin only manages Environments and can't see Connectors (C+1P R17). It relies on the local `1password-mcp` server in config.toml (r2 L13–L19), which item 1 removes. D04 retires Environments mounts.
   - ChatGPT and Codex share one plugin directory (codex-restore.md L143), so removing it covers both.
   - **Kept: W03, D03 and D04 (remove).** No decision row names the plugin itself, so the Director should confirm (§8).
   - `codex plugin` can remove plugins (codex-restore.md L29), and Superpowers came in from the same remote catalog that way (L46). Whether a remote-catalog removal works through the CLI is NOT_PROVEN.

## 4. G21: wrong order (the health check)

**Problem.** The hub build (8.2) starts connector-health before the logins it watches (7, 9, 10) and its two alert routes (9.1, 10.2) exist. Its config is first touched at 17.2.

**Facts**
- **Ship and start.** `rebuild_hub.py` ships `health_check.py` and `config.json` from `~/.agents/tools/connectors/health` (L30–L31). `install_hub.sh` copies them (L75), holds connector-health while the routes are checked (L135–L141), then starts it (L169). `loop.sh` runs one check at once and then one every 30 minutes (L4–L6).
- **First run.** On the first run there's no state.json, so every failing check counts as newly broken (health_check.py L130, L141).
- **Alert routes.** Email goes out as `CUSTOM_GOOGLE_ROBOT_GMAIL_SEND` through `robot_account` (L92–L95), which needs custom_google_robot from 9.1. Texts go through `CUSTOM_GHL_OAUTH_CRM_GHL_EXECUTE_OPERATION` with `ghl_account` (L117–L122), which needs custom_ghl_oauth_crm from 10.2.
- **Fresh accounts.** The shipped config still names Alex's Composio key item, org, logins and contacts. Its first call, `secret(composio_item)`, fails (L20–L24, L132), so the checker crashes every 30 minutes while supervisor still shows it RUNNING. That means 17.1's check ("RUNNING") passes on a checker that does nothing.
- **Moving Alex's hub.** When the build reuses Alex's own accounts, the config is already right.

**Corrected order (one new step, three cells reworded)**
1. 8.2: build the hub (it starts the checker; on fresh accounts it waits, harmlessly, for 10.7).
2. 9.1 and 10.1 to 10.6: the watched logins and both alert routes come into being.
3. 10.7 (new): write the health config in `~/.agents`, ship it, prove it with `--test`.
4. 17.1: check it's RUNNING and its last log line shows every check ok.
5. 17.2: the rule for watching new logins later.

**Replacement wording.** The full text is in the G21 block in §7:
- Section "8. The Orgo hub", step 8.2, "what to do": one sentence added.
- Section "10. GoHighLevel routes", new step 10.7, every column.
- Section "17. Health check, tune-up and proof", steps 17.1 and 17.2: "what to do" and "how you know it worked".

**config.json key structure** (values not shown; the file holds contact details):

| key | type | what it is | can be filled after |
|---|---|---|---|
| `vault` | string | 1Password vault the robot token reads | 1.1 |
| `op_token_file` | string | path on the hub of the robot-token file | 8.2 |
| `composio_item` | string | ID of the 1Password item holding the Composio API key (G06 catalog) | 4.5 |
| `composio_org`, `composio_project` | string | Composio org and project IDs (sent as x-org-id and x-project-id) | 1.2 |
| `composio_user` | string | Composio user ID the logins belong to | 7.2 |
| `watch` | list of objects (9 today) | one per login: `name` (shown in alerts), `account` (Composio connected-account ID), `probe` (a cheap read-only tool slug), `args` (that tool's arguments, often empty) | 7.2–7.5, 9.1, 10.2–10.5 |
| `robot_account` | string | connected-account ID of the Google robot login that sends mail | 9.1 |
| `email_from` | string | Workspace user the robot sends as | 9.1 |
| `emails` | list of strings (2 today) | who gets alert mail | — |
| `ghl_account` | string | connected-account ID of the GHL CRM login that texts | 10.2 |
| `ghl_location` | string | GHL location that sends the texts | 10.2 |
| `sms_from` | string | that location's sending number | 10.2 |
| `sms_contacts` | list of strings (2 today) | GHL contact IDs to text | 10.2 |

**Reason.** The checker can only be right once its logins and alert routes exist. Writing the config once, at 10.7, takes fewer steps than writing a partial one before the build and finishing it later. The `--test` run and the log line prove it works, which RUNNING doesn't. Edit the copy in `~/.agents`, because every rebuild overwrites the hub copy and `capture_hub.py --diff` compares it (README L18–L19). `rebuild_hub.py --force` is the documented way to ship it (install_hub.sh L9).

**Conflicts resolved.** Section 18 row G28 says "CLOSED … config.json holds contacts to fill in", and Rebuild 17.2 makes that the last step. I kept the code's behavior (install_hub.sh and health_check.py above) over the tab's ordering.

## 5. G22: wrong order (the dead javante program)

**Problem.** The mirror's `mcp-hub.conf` still defines `[program:mcp-hub-google-robot-javante]` (L64–L69), and its wrapper is gone. A new hub would show it FATAL and fail the "every program RUNNING" check. The fix is at 8.7, after the build.

**Corrected order**
1. 8.0 (new): delete the block from the mirror (and from Alex's live conf), back up first, commit.
2. 8.1: dry run and `--check`.
3. 8.2: build.
4. 8.4: `supervisorctl status` shows every program RUNNING (no change; it can pass now).
5. 8.7: keeps only the `/opt/increase-roas-mcp` leftover.

**Replacement wording.** The full text is in the G22 block in §7. Also:
- In section "18. Every gap from the replication check, and where it stands", row G10, column 4: change "Leftover: the dead javante program (step 8.7)" to "(step 8.0)".
- Whoever applies the fix in agents-home should also drop that line from the hub README's "Known issues".

**Reason**
- The installer copies `mcp-hub.conf` as it is (install_hub.sh L137). The mirror has no `google-robot-javante.sh` (the file list of `root/opt/mcp-hub/`, read 2026-10-01; README L38). The README says the program "would go FATAL on a rebuild".
- Nothing uses the program (All connections R300), so it is dead config under the standing yes in AGENTS.md rule 1.
- If siblings add pre-build rows for G10 (the hub computer) or G11 (the tunnel), merge them into one "8.0 Before you build" row with this item first.

**Conflicts resolved.** Section 18 row G10 says "CLOSED" with a leftover, and To do R23 lists the fix as left. Both agree it has to be done. I only moved it before the build.

## 6. G23: wrong order (checks that need a later step)

**Problem.** Several "how you know it worked" checks can only pass after a later step.

**Corrected order: where each check moves**
1. 1.2 moves to 2.2.
2. 1.3 moves to 4.6 (the CLI check). The hub listing moves to the step that creates the hub computer (G10, before 8.1).
3. 1.7 moves to 2.2.
4. 4.2 moves to 8.1.
5. 5.2 moves to 9.1.
6. 12.3's exit-0 check moves to 14.2.

Also found beyond the tester's list, same treatment:
7. 1.5 can't be checked yet: no step installs Tailscale on the Mac (missing content).
8. 3.5 moves to 13.2.
9. 4.6's gcloud part moves to 5.1.
10. 6.1 moves to 6.4.
11. 6.2 moves to 8.2.
12. 7.1 moves to 7.3.
13. 7.5 moves to 8.1.
14. 10.1 moves to 10.2.
15. 10.3 moves to 10.5.
16. 13.1 moves to 13.2.
17. 14.1 moves to 14.2.

**Replacement wording.** The G23 block in §7 gives the new "how you know it worked" text for each step that loses a check and each step that receives one. "what to do" stays the same unless another gap changes it. Keep 4.6's note about the open `~/.orgo/credentials.json` exception.

**Reason**
- The CLIs are installed and signed in only at 2.1 and 2.2.
- `rebuild_hub.py --check` reads every hub item plus the tunnel token (L83–L88, L109–L119).
- custom_google_robot reaches Composio only at 9.1.
- `check.py` exits 1 for broken links, missing off-switches or uncommitted changes until 14.2 (Skills, where they live R39).
- `gcloud_robot.py` reads the robot key from 5.1 (L21).
- The Slack login comes at 7.2 and 7.3.
- The gateway key is pushed at 10.2.
- `switch_location` needs 10.4 and 10.5.
- The hook rewrites the Tool cards tab only after the 13.2 commit.

**Conflicts resolved.** None: no source disagrees about these dependencies.

## 7. Proposed rows

```json
{"gap": "G05", "type": "unclear step", "target_tab": "Rebuild from zero", "sections": [
 {"title": "4. Keys (1Password)", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["4.1", "In the Connectors vault, create two service accounts (robot logins that need no Touch ID): connectors-sync (read only) and connectors-sync-rw (read and write), both limited to Connectors. Each token is shown only once, so choose Save in 1Password the moment it appears. Keep the read-write token's backup outside Connectors (for example in the owner's private vault): a robot can read every item in its vault, so a read-write token saved in Connectors would hand write power to the read-only robot. Item names: the G06 catalog.", "Both show on the Developer page with access to Connectors only, and each token has a backup item in 1Password.", "—", "1Password shows each token once and says to save it in 1Password at once; today the read-write token has no backup.", "https://www.1password.dev/service-accounts/get-started (read 2026-10-01) ; https://www.1password.dev/service-accounts/security (read 2026-10-01) ; workbook Rebuild from zero R43 ; workbook Composio + 1Password right way R59 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D08"],
  ["4.2", "Put one robot token in the Mac's Keychain without ever typing it on a command line, so it can't land in shell history or the process list. In Terminal run: security add-generic-password -U -a connectors-sync -s op-service-account-connectors-sync -w (the -w goes last with no value, so security asks for the token and hides what you paste). Then clear the clipboard: pbcopy < /dev/null. Keep these exact names: four scripts look the item up by them. Make it with this command, not Keychain Access and never with -A: the app that creates the item is the one trusted to read it without a prompt, and the scripts read it with /usr/bin/security. Which robot: today the item holds the read-write robot (connectors-sync-rw) on Alex's Mac and hub, so a rebuild stores that one. Decision D08 (least privilege: the read-only robot here, read-write only inside the key-save step) is decided but deferred until testing ends; when Alex applies it, run the same command with the read-only token (-U replaces the value).", "security find-generic-password -a connectors-sync -s op-service-account-connectors-sync > /dev/null && echo stored prints stored (without -w it never shows the token). Outside the Claude Code sandbox, OP_SERVICE_ACCOUNT_TOKEN=$(security find-generic-password -a connectors-sync -s op-service-account-connectors-sync -w) op user get --me shows Type SERVICE_ACCOUNT and the robot's name (connectors-sync-rw today). The full hub item check is at step 8.1.", "—", "A token typed after -w sits in shell history and is visible to other processes; the prompt form avoids both. The old check (rebuild_hub.py --check) reads items made at 5.1, 6.2 and 7.5.", "/usr/share/man/man1/security.1 L457 ; /usr/share/man/man1/security.1 L465 ; /usr/share/man/man1/security.1 L471 ; https://github.com/zalando/go-keyring/issues/24 (read 2026-10-01) ; https://www.1password.dev/service-accounts/use-with-1password-cli (read 2026-10-01) ; ~/.agents/tools/connectors/hub/rebuild_hub.py L48–L53 ; ~/.agents/tools/connectors/orgo_op.py L33 ; ~/.agents/tools/connectors/gcloud_robot.py L39 ; ~/.agents/tools/connectors/push_key_to_composio.py L21 ; ~/.agents/tools/connectors/hub/install_hub.sh L4 ; workbook Composio + 1Password right way R32 ; workbook Do, Don't and why R5 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D08"],
  ["4.3", "Settled 2026-10-01 by fingerprints, values never printed: the Keychain entry and the hub's /opt/mcp-hub/creds/op-connectors-sync hold the same token, and it belongs to the read-write robot, connectors-sync-rw. That robot last edited 12 Connectors items that day, which a read-only login can't do. The read-only robot's token is only in the 1Password item \"1Password service account — connectors-sync (read-only Connectors)\". Still open: the read-write token has no backup item; save one outside the Connectors vault (step 4.1 says why). The notes in install_hub.sh, gcloud_robot.py, orgo_op.py and push_key_to_composio.py now say read-write (agents-home ea6c339). Alex decides which robot the Mac and the hub should run on. The Director has since decided least privilege (the read-only robot by default, read-write only inside the key-save script), deferred until testing is done (Decisions and why, D08).", "—", "—", "Only the backup sentence changes, to match the rule in 4.1.", "workbook Rebuild from zero R43 ; https://www.1password.dev/service-accounts/security (read 2026-10-01) ; agents-home ea6c339"]
 ]},
 {"title": "8. The Orgo hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["8.1", "(unchanged)", "Both finish without a missing item. --check also covers what step 4.2 used to check: every hub item is readable with the Keychain token, plus the tunnel credentials.", "4.2", "First step where every item the check reads exists.", "workbook Rebuild from zero R78 ; ~/.agents/tools/connectors/hub/rebuild_hub.py L109–L119"]
 ]}
]}
```

```json
{"gap": "G15", "type": "unclear step", "target_tab": "AI apps", "sections": [
 {"title": "What each AI keeps and removes (2026-10-01)", "header": ["surface", "Composio route", "1Password route", "built-ins it keeps", "removes", "source"], "rows": [
  ["Claude Code (terminal and desktop app)", "The composio command first (composio search, then composio execute), run outside the sandbox. The composio@composio plugin, pinned to marketplace tag v0.2.4 (hooks and a command, no MCP). The claude.ai Composio connector as the fallback (it arrives on its own). Never add a third copy with claude mcp add.", "The op CLI plus the connectors-sync scripts (push_key_to_composio.py, gcloud_robot.py, orgo_op.py), which read the robot token from the Keychain. No 1Password MCP.", "Browser and computer: Playwright (the only server in ~/.claude.json) for public pages from a terminal, the desktop app's built-in browser, Claude in Chrome for pages behind Alex's login, and computer use for desktop apps. Plugins: Superpowers (the Director and conductor call its skills) and the claude.ai plugins desktop-commander and pdf-viewer (decision L04), which sync in from claude.ai.", "Already gone: the Apify, Exa, Workspace Admin, GHL CRM, Atlas Cloud and SkillsMP server copies (backups in ~/Backups/claude-config-2026-10-01). Still to remove: the other 11 claude.ai plugins (L04), the qt-development-skills plugin (SK40-D5) and browser-use unless it is fixed (it failed to connect on 2026-10-01).", "workbook AI apps R4 ; workbook Rebuild from zero R102 ; work/2026-10-01_setup-playbook/notes/hard-rule-checks.md L13 ; work/2026-10-01_setup-playbook/notes/hard-rule-checks.md L136 ; work/2026-10-01_setup-playbook/notes/hard-rule-checks.md L137 ; ~/.agents/tools/cards/browser-and-computer.md L13–L17 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row L04 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row SK40-D5 ; workbook Composio + 1Password right way R8 ; workbook AI apps R9"],
  ["Claude Desktop (the Claude app on the Mac)", "The account's Composio custom connector, the same one as the Claude app on web and phone. Nothing in the local config.", "None. Claude Desktop's own config.json carries a 1Password pairing flag nobody has explained yet; check it before calling this final.", "The claude.ai plugins desktop-commander (controls this Mac) and pdf-viewer (views PDFs on this Mac), per decision L04. browser-use only if it gets fixed.", "Every server in mcpServers of ~/Library/Application Support/Claude/claude_desktop_config.json (two leftovers were still listed on 2026-10-01). Quit fully with Cmd+Q first and back the file up to ~/Backups.", "workbook Rebuild from zero R105 ; workbook AI apps R9 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row L04 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row W03 ; work/2026-10-01_setup-playbook/notes/cursor-audits-review.md L97"],
  ["Claude app on web and phone", "The custom connector named Composio (URL https://connect.composio.dev/mcp), signed in to your Composio org. It is the only connector.", "None: keys reach it only through Composio.", "Anthropic's own: Code execution and file creation (turned on for skills), visualize and Claude Docs (decision V10).", "Ref (out of credits), the GHL OAuth Gateway connector (it still exposed tools in chats), Shopify once Composio shopify is proven, and the connectors that were never signed in (Slack, Notion, Gmail, Calendar, Drive, Foreplay).", "workbook Rebuild from zero R103 ; workbook AI apps R9 ; work/2026-10-01_setup-playbook/notes/conductor-ui-lane.md L28–L30 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row V10 ; workbook SOP R4"],
  ["Codex (terminal CLI and the desktop app)", "The composio command first. The second door is the official Composio plugin (ChatGPT plugin directory, developer Sampark Inc, which is Composio), with default_tools_approval_mode = \"approve\" on its [apps.<id>] block.", "The op CLI plus the connectors-sync scripts (key mover, gcloud_robot.py, orgo_op.py). Orgo goes through orgo_op.py orgo <args>.", "Bundled plugins browser, chrome, computer-use and unified-computer-use; node_repl (the app's browser runtime); Messages with send_message turned off; Superpowers with 5 skills on (brainstorming, dispatching-parallel-agents, systematic-debugging, test-driven-development, verification-before-completion; using-superpowers off); compound-engineering with 6 skills on (ce-plan, ce-work, lfg, ce-debug, ce-handoff, ce-compound); the app's own codex_app, codex_apps and code-review servers. Messages and Computer Use run only in the desktop app.", "The [mcp_servers.1password] entry (1Password's Environments server) and the account-level 1Password plugin (see ChatGPT); the orgo MCP; the docs helpers composio-docs, hermes-docs and meta-ads-docs; [mcp_servers.computer-use] (it never started); the other 11 plugins and the 4 codex_app approve lines (left off); the 4 switched-off ChatGPT connectors (Slack, Notion, Google Drive, Increase ROAS GoHighLevel). Already gone: the old composio@composio 0.2.3 plugin, its 2 hooks and its marketplace. Leave the five imported plugins at Finish setup (Exa, Google Drive, Cloudflare, Supabase, Vercel): they load nothing and can't be removed in the background. Also remove the unused ~/.codex/mcp-servers folders (apify, slack-docs, spyfu) once their 1Password Environments destinations are off (D04).", "workbook Composio + 1Password right way R15 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D07 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row W04 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D03 ; work/2026-10-01_setup-playbook/notes/codex-restore.md L15–L18 ; work/2026-10-01_setup-playbook/notes/codex-restore.md L21 ; work/2026-10-01_setup-playbook/notes/codex-restore.md L35–L36 ; work/2026-10-01_setup-playbook/notes/codex-restore.md L89–L93 ; work/2026-10-01_setup-playbook/notes/rca-codex-plugins.md L91–L98 ; work/2026-10-01_setup-playbook/notes/rca-codex-plugins.md L132 ; work/2026-10-01_setup-playbook/notes/onepassword-one-route.md L89–L94 ; workbook Composio + 1Password right way R65 ; work/2026-10-01_setup-playbook/notes/conductor-ui-lane.md L42–L47 ; workbook AI apps R5 ; work/2026-10-01_setup-playbook/notes/cursor-audits-review.md L78"],
  ["ChatGPT (desktop app, web, phone, Work, dots)", "Only the official Composio plugin from the plugin directory (Sampark Inc), signed in once as your Composio user with the org picked. Work and Codex chats on the Mac's Local host use the composio command first. No hand-made developer-mode connector.", "None. To move a key, a Codex or Work chat on the Local host runs the key mover, which is Codex's route.", "OpenAI's own apps that come with the account (listed on 2026-10-01: Sites, Pets, Codex Document Control, Codex Goals, ChatGPT Space and Plugin Management).", "The 1Password plugin (proposed: it only manages 1Password Environments, never returns a key and can't see Connectors; ChatGPT and Codex share one plugin directory, so this removes it from Codex too). Already gone on 2026-10-01: the Gmail, GitHub, Exa, Descript, Slack, Notion, Drive and ClickUp apps and both Increase ROAS apps (GoHighLevel, Meta Ads).", "workbook Composio + 1Password right way R17 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D02 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D03 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row D04 ; work/2026-10-01_setup-playbook/notes/decision-evidence.csv row W03 ; work/2026-10-01_setup-playbook/notes/conductor-ui-lane.md L6–L13 ; work/2026-10-01_setup-playbook/notes/conductor-ui-lane.md L16 ; work/2026-10-01_setup-playbook/notes/codex-restore.md L143 ; work/2026-10-01_chatgpt-claude-research/notes/r2-1password-chatgpt.md L13–L19 ; workbook Rebuild from zero R107"],
  ["Cursor", "Outside this mission.", "—", "—", "— (its 1password MCP entry waits on Alex's plugin decision)", "workbook Rebuild from zero R21 ; work/2026-10-01_setup-playbook/notes/onepassword-one-route.md L89–L94"],
  ["Hermes/Javar agents", "Outside this mission: their fenced tools and their own Composio logins need a mission of their own.", "—", "—", "—", "workbook Rebuild from zero R21 ; workbook Rebuild from zero R170"]
 ]}
]}
```

```json
{"gap": "G21", "type": "wrong order", "target_tab": "Rebuild from zero", "sections": [
 {"title": "8. The Orgo hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["8.2", "Build the hub on a new Orgo computer. The installer refuses a computer that already has a hub unless you add --force. It also starts the health check: when you move Alex's hub its config is already right; on fresh accounts it can't read its Composio key yet, so it logs an error every 30 minutes and sends nothing until step 10.7.", "Step 11 joins the hub to the tailnet as openclaw-hub with tag:server; step 12 shows each route answering 401 without a token and 200 with one, and the public healthz answers.", "6.2 (the tailnet join check)", "The installer starts connector-health at the end of its route checks, long before the logins and alert routes it needs exist.", "~/.agents/tools/connectors/hub/install_hub.sh L135–L141 ; ~/.agents/tools/connectors/hub/install_hub.sh L169 ; ~/.agents/tools/connectors/health/health_check.py L20–L24 ; ~/.agents/tools/connectors/health/health_check.py L129–L132 ; workbook Rebuild from zero R79"]
 ]},
 {"title": "10. GoHighLevel routes", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["10.7", "Turn on the health check. This is the first point where every login it watches and both alert routes exist (email through the Google robot from 9.1, texts through the GHL CRM gateway from 10.2). Moving Alex's hub: nothing to do. Fresh accounts: edit your copy of ~/.agents/tools/connectors/health/config.json (never only the hub copy: every rebuild overwrites it and capture_hub.py --diff compares it), commit, ship it with python3 ~/.agents/tools/connectors/hub/rebuild_hub.py --computer <hub id> --force (it re-sends the bundle and restarts only changed programs), then send one test alert: ~/.agents/tools/connectors/orgo_op.py orgo computers bash <hub id> -c 'cd /opt/mcp-hub/health && python3 health_check.py --test'. The keys: vault and op_token_file (the vault name and the hub's robot-token file); composio_item (the ID of the 1Password item with your Composio API key, from the G06 catalog), composio_org, composio_project and composio_user (your Composio IDs); watch, one entry per login with name (shown in alerts), account (its Composio connected-account ID), probe (a cheap read-only tool) and args (that tool's arguments, often empty); robot_account and email_from (the Google robot login and the Workspace user it sends as) and emails (who gets mail); ghl_account, ghl_location, sms_from and sms_contacts (the GHL CRM login, the location that texts, its sending number and the GHL contact IDs to text).", "The test run prints email ok and one sms ok per contact, the email and the texts arrive, and its last line shows every check ok with broke=[] (on a different home ISP the exit-node check fails until the ISP name in health_check.py is changed). capture_hub.py --diff shows config.json matching.", "17.1 (the start) and 17.2 (the first config edit)", "The checker can only be right once its logins and alert routes exist. Its first run treats every failing check as newly broken, and on fresh accounts the shipped config can't even read its Composio key, so RUNNING alone proves nothing.", "~/.agents/tools/connectors/hub/rebuild_hub.py L30–L31 ; ~/.agents/tools/connectors/hub/install_hub.sh L9 ; ~/.agents/tools/connectors/hub/install_hub.sh L75 ; ~/.agents/tools/connectors/hub/root/opt/mcp-hub/health/loop.sh L4–L6 ; ~/.agents/tools/connectors/health/health_check.py L10 ; ~/.agents/tools/connectors/health/health_check.py L92–L95 ; ~/.agents/tools/connectors/health/health_check.py L117–L122 ; ~/.agents/tools/connectors/health/health_check.py L129–L141 ; ~/.agents/tools/connectors/health/health_check.py L98–L107 ; ~/.agents/tools/connectors/health/config.json ; ~/.agents/tools/connectors/hub/README.md L18–L19 ; ~/.agents/tools/connectors/orgo_op.py L1–L16 ; workbook SOP R49 ; workbook Rebuild from zero R148"]
 ]},
 {"title": "17. Health check, tune-up and proof", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["17.1", "The health check runs on the hub under supervisor's connector-health program, every 30 minutes (the box has no cron; the script's header still says cron). It ships with the hub (step 8.2) and is configured and tested at step 10.7.", "supervisorctl status on the hub lists connector-health RUNNING, and the last line of /opt/mcp-hub/logs/health.log shows every check ok.", "—", "RUNNING only shows the loop is alive; the log line shows the checks pass.", "~/.agents/tools/connectors/hub/root/etc/supervisor/conf.d/mcp-hub.conf L50–L55 ; ~/.agents/tools/connectors/health/health_check.py L159–L160 ; workbook Rebuild from zero R147"],
  ["17.2", "What it checks: every hub route answers, the home exit node is up, every watched Composio login is ACTIVE, and every 6 hours one read-only call per login. It emails and texts the contacts in config.json only on a break or a recovery, plus a Monday all-good email. To watch a new login later, add one watch entry with a cheap read-only call, commit, ship it as in step 10.7 and run --test.", "The Monday email arrives.", "— (the first config edit moved to 10.7)", "17.2 stays as the rule for later changes.", "~/.agents/tools/connectors/health/health_check.py L1–L11 ; ~/.agents/tools/connectors/health/health_check.py L98–L107 ; workbook SOP R49 ; workbook SOP R66 ; workbook Rebuild from zero R148"]
 ]}
]}
```

```json
{"gap": "G22", "type": "wrong order", "target_tab": "Rebuild from zero", "sections": [
 {"title": "8. The Orgo hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["8.0", "Before you build, remove the dead program from the hub's supervisor file. The mirror's mcp-hub.conf still defines [program:mcp-hub-google-robot-javante], a copy rolled back on 2026-10-01 whose wrapper script is gone, so a new hub would show it FATAL. Copy the file to ~/Backups, delete that block (lines 64 to 69) from ~/.agents/tools/connectors/hub/root/etc/supervisor/conf.d/mcp-hub.conf and commit agents-home. On Alex's live hub, delete the same block from /etc/supervisor/conf.d/mcp-hub.conf (back it up first), then run supervisorctl reread and supervisorctl update, so the live file and the mirror stay equal. Dead config falls under the standing yes.", "grep -c javante on the mirror's mcp-hub.conf prints 0. On the live hub, supervisorctl status no longer lists it, and capture_hub.py --diff reports every file matching.", "8.7", "The build's own check (8.4) needs every program RUNNING and the installer copies this file as it is, so the fix has to come before the build.", "~/.agents/tools/connectors/hub/root/etc/supervisor/conf.d/mcp-hub.conf L64–L69 ; ~/.agents/tools/connectors/hub/README.md L37–L39 ; ~/.agents/tools/connectors/hub/install_hub.sh L135–L141 ; AGENTS.md \"remove any duplicate or dead login, config or local copy\" ; workbook Rebuild from zero R84 ; workbook To do R23 ; workbook All connections R300"],
  ["8.4", "(unchanged)", "supervisorctl status shows every program RUNNING (it can pass now that step 8.0 removed the program with no wrapper).", "—", "No change to the check itself; 8.0 makes it passable.", "workbook Rebuild from zero R81 ; ~/.agents/tools/connectors/hub/install_hub.sh L170"],
  ["8.7", "Known leftover: /opt/increase-roas-mcp (a Meta MCP and its tunnel client) is on the hub but in no repo, so a rebuild drops it.", "—", "— (the javante sentence moved to 8.0)", "Only the leftover that needs no pre-build action stays here.", "~/.agents/tools/connectors/hub/README.md L40–L42 ; workbook Rebuild from zero R84"]
 ]}
]}
```

```json
{"gap": "G23", "type": "wrong order", "target_tab": "Rebuild from zero", "sections": [
 {"title": "1. Accounts to create", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["1.2", "(unchanged)", "The Composio dashboard opens on your organization, and Connect is its consumer project. The CLI check (composio whoami) is at step 2.2.", "—", "The composio command is only installed and signed in at steps 2.1 and 2.2.", "workbook Rebuild from zero R15 ; workbook Rebuild from zero R26 ; workbook Rebuild from zero R27"],
  ["1.3", "(unchanged)", "You can sign in at orgo.ai and see your account. The CLI check (orgo_op.py orgo computers list) is at step 4.6; the hub computer is checked when it is made, before step 8.1.", "—", "orgo_op.py needs the orgo CLI (2.1), ~/.agents (3.1), the Keychain token (4.2) and the Orgo key in 1Password; the hub computer doesn't exist until just before the build.", "workbook Rebuild from zero R16 ; ~/.agents/tools/connectors/orgo_op.py L1–L16 ; ~/.agents/tools/connectors/orgo_op.py L20 ; work/2026-10-01_setup-playbook/notes/replication-retest-prelim.md §2"],
  ["1.5", "(unchanged)", "You can sign in to the Tailscale admin console. A machine only shows there after Tailscale is installed on it, and no step installs it on your Mac yet (a missing step, not an order fix).", "—", "Only the hub joins the tailnet in a written step (8.2, installer step 11); the tool list in 2.1 has no Tailscale.", "workbook Rebuild from zero R18 ; workbook Rebuild from zero R26 ; ~/.agents/tools/connectors/hub/install_hub.sh L143–L151"],
  ["1.7", "(unchanged)", "You can sign in at github.com and see the private repos. The CLI check (gh auth status) is at step 2.2.", "—", "gh is installed at 2.1 and signed in at 2.2.", "workbook Rebuild from zero R20 ; workbook Rebuild from zero R26 ; workbook Rebuild from zero R27"]
 ]},
 {"title": "2. The Mac", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["2.2", "(unchanged)", "composio whoami shows your email and org, and gh auth status shows the GitHub account (this also closes steps 1.2 and 1.7).", "1.2, 1.7", "First step where both commands are installed and signed in.", "workbook Rebuild from zero R27"]
 ]},
 {"title": "3. The shared home ~/.agents", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["3.5", "(unchanged)", "— (this row explains the hook; its live check is at step 13.2).", "—", "On a fresh Mac in Phase 3 the hook's sync step has no hub (8.2) and still points at the old hub until step 8.5.", "workbook Rebuild from zero R37 ; workbook Rebuild from zero R82 ; ~/.agents/tools/unify/hooks/post-commit L1–L13"]
 ]},
 {"title": "4. Keys (1Password)", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["4.2", "(see the G05 block)", "The Keychain item is found and op user get --me names the robot (G05 wording). The full hub item check is at step 8.1.", "—", "rebuild_hub.py --check reads every hub item and the tunnel token, and those are only made at 5.1, 6.2, 7.5 and the tunnel step.", "workbook Rebuild from zero R42 ; ~/.agents/tools/connectors/hub/rebuild_hub.py L83–L88 ; ~/.agents/tools/connectors/hub/rebuild_hub.py L109–L119"],
  ["4.6", "(unchanged)", "orgo_op.py orgo computers list answers (an empty list is fine before the hub exists) and no key file exists. The gcloud_robot.py check is at step 5.1. One exception was still open on 2026-10-01: ~/.orgo/credentials.json, kept until the three hub scripts switch to orgo_op.py.", "1.3", "gcloud_robot.py reads the Google robot's key, which only exists after step 5.1.", "workbook Rebuild from zero R46 ; ~/.agents/tools/connectors/gcloud_robot.py L21 ; ~/.agents/tools/connectors/orgo_op.py L20"]
 ]},
 {"title": "5. The Google robot (one identity for Workspace, GA4, GTM and Search Console)", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["5.1", "(unchanged)", "1Password holds the key, no copy is on disk, and ~/.agents/tools/connectors/gcloud_robot.py iam roles describe roles/viewer answers (run it outside the Claude Code sandbox).", "4.6 (the gcloud part)", "First step where the robot's key exists.", "workbook Rebuild from zero R51 ; ~/.agents/tools/connectors/gcloud_robot.py L1–L17"],
  ["5.2", "(unchanged)", "In the Admin console, Manage Domain-wide Delegation lists the robot's client ID with all 39 scopes from dwd-scopes.txt. The live read through Composio is at step 9.1.", "—", "custom_google_robot is a hub route, added to Composio at 9.1.", "workbook Rebuild from zero R52 ; workbook Rebuild from zero R88 ; work/2026-10-01_google-robot/dwd-scopes.txt"]
 ]},
 {"title": "6. Tailscale (home internet address for the agent computers)", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["6.1", "(unchanged)", "The admin console shows MagicDNS on and the home Mac approved as an exit node. The web check from an agent computer is at step 6.4.", "—", "Agent computers only send traffic through the exit node once tailscaled (6.3) and the Chrome policy (6.4) are set.", "workbook Rebuild from zero R58 ; workbook Rebuild from zero R60 ; workbook Rebuild from zero R61"],
  ["6.2", "(unchanged)", "1Password holds the item Tailscale auth key, and the admin console's Keys page lists a reusable key tagged tag:server. The hub's join is checked at step 8.2.", "—", "The installer's step 11 only runs during the build.", "workbook Rebuild from zero R59 ; ~/.agents/tools/connectors/hub/install_hub.sh L143–L151"],
  ["6.4", "(unchanged)", "A fresh headless Chrome on an agent computer shows the home address (this also closes step 6.1).", "6.1", "First step where an agent computer routes through the exit node.", "workbook Rebuild from zero R61"]
 ]},
 {"title": "7. Composio, before the hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["7.1", "(unchanged)", "Connect > Settings shows Enhanced Control off. The Slack read is at step 7.3.", "—", "Slack is only connected at 7.2 and 7.3.", "workbook Rebuild from zero R66 ; workbook Rebuild from zero R68"],
  ["7.3", "(unchanged)", "Each tool card names the default account, and a Slack read from Claude Code works.", "7.1", "First step where the Slack login and its named account exist.", "workbook Rebuild from zero R68"],
  ["7.5", "(unchanged)", "A read-only custom_cloudflare_api call (for example listing your account's tunnels) answers. The tunnel-credentials check runs in step 8.1's --check.", "—", "The credentials can only be derived once the tunnel exists, and no step before 8.1 creates it (a missing step, G11).", "workbook Rebuild from zero R70 ; ~/.agents/tools/connectors/hub/rebuild_hub.py L64–L80"]
 ]},
 {"title": "8. The Orgo hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["8.1", "(unchanged)", "Both finish without a missing item; --check also covers the old checks of steps 4.2 and 7.5 (every hub item and the tunnel credentials).", "4.2, 7.5", "First step where every item and the tunnel exist.", "workbook Rebuild from zero R78 ; ~/.agents/tools/connectors/hub/rebuild_hub.py L109–L119"],
  ["8.2", "(G21 adds one sentence)", "Step 11 joins the hub to the tailnet as openclaw-hub with tag:server; step 12 shows each route answering 401 without a token and 200 with one, and the public healthz answers.", "6.2", "The tailnet join happens inside the build.", "workbook Rebuild from zero R79 ; ~/.agents/tools/connectors/hub/install_hub.sh L143–L171"]
 ]},
 {"title": "9. Composio, after the hub", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["9.1", "(unchanged)", "One read-only tool per toolkit answers (CUSTOM_IR_NOTES_GET_APP_RULES for the notes), and one custom_google_robot read as your admin user works, which also proves step 5.2's delegation.", "5.2", "First step where custom_google_robot exists in Composio.", "workbook Rebuild from zero R88 ; workbook Rebuild from zero R52"]
 ]},
 {"title": "10. GoHighLevel routes", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["10.1", "(unchanged)", "wrangler deploy finishes without an error. The list-locations check is at step 10.2.", "—", "Composio can only call the gateway after 10.2 pushes its key into custom_ghl_oauth_crm.", "workbook Rebuild from zero R93 ; workbook Rebuild from zero R94"],
  ["10.2", "(unchanged)", "A list-locations call through custom_ghl_oauth_crm returns the agency's locations.", "10.1", "First step where Composio holds the gateway key.", "workbook Rebuild from zero R94"],
  ["10.3", "(unchanged)", "The Worker deploy finishes without an error and the origin's supervisor programs show RUNNING on the hub. The switch_location check is at step 10.5.", "—", "switch_location needs the origin key (10.4) and a registered location (10.5).", "workbook Rebuild from zero R95 ; workbook Rebuild from zero R96 ; workbook Rebuild from zero R97"],
  ["10.5", "(unchanged)", "switch_location then get_location returns the new location.", "10.3", "First step where a location is registered with the builder.", "workbook Rebuild from zero R97"]
 ]},
 {"title": "12. Global instructions", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["12.3", "(unchanged)", "check.py reports no instruction drift. On a fresh Mac it still exits 1 until step 14.2 makes the skill links and Codex off-switches; the exit-0 check is at 14.2.", "—", "check.py exits 1 for broken links, missing Codex off-switches or uncommitted changes, which step 14.2 fixes.", "workbook Rebuild from zero R114 ; workbook Skills, where they live R39"]
 ]},
 {"title": "13. Tool cards and the hosted notes", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["13.1", "(unchanged)", "Each card's settings block has route, aliases, index, tasks and updated. The Tool cards tab check is at step 13.2.", "—", "The hook rewrites the Tool cards tab only after the commit in 13.2.", "workbook Rebuild from zero R119 ; ~/.agents/tools/unify/hooks/post-commit L1–L13"],
  ["13.2", "(unchanged)", "CUSTOM_IR_NOTES_GET_APP_RULES returns the new card text, the Tool cards tab lists every card, and ~/.agents/runtime/notes-sync.log shows sync_notes.py, build_instructions.py apply and cards_to_sheet.py.", "3.5, 13.1", "First step where the commit, the hub and its notes route all exist.", "workbook Rebuild from zero R120 ; workbook Rebuild from zero R37"]
 ]},
 {"title": "14. Skills", "header": ["step (new order)", "what to do", "how you know it worked", "moved from", "why", "source"], "rows": [
  ["14.1", "(unchanged)", "Each shared skill has one real folder, in ~/.agents/skills. The once-per-AI check is at step 14.2.", "—", "The links and off-switches that make each skill show once are made at 14.2.", "workbook Rebuild from zero R125 ; workbook Rebuild from zero R126"],
  ["14.2", "(unchanged)", "check.py exits 0: no instruction drift, no broken links and 0 missing Codex off-switches (this also closes step 12.3), and each skill name shows once per AI.", "12.3, 14.1", "First step where the links and off-switches exist.", "workbook Rebuild from zero R126 ; workbook Skills, where they live R39"]
 ]}
]}
```

## 8. Gaps (not settled here)

1. **G05: the read-write token's backup vault.** "Outside Connectors" is my proposal, based on vault-scoped reads and D08's aim. Rebuild 4.3 and C+1P R59 suggest Connectors. Alex or the Director decides.
2. **G05: D08 isn't fully specified.** It doesn't say where the read-write token lives once the default flips, for example in a second Keychain item that only the key-save step reads. The key-save script itself doesn't exist yet (section 18, G07 "no script exists"). I also didn't confirm whether `security` asks for the token a second time; the wording avoids saying.
3. **G15: ChatGPT's 1Password plugin.** No decision row names the plugin, so its removal is proposed under W03, D03 and D04 and needs the Director to confirm. Removing it through the `codex plugin` CLI is NOT_PROVEN for a remote-catalog plugin.
4. **G15: other open points.**
   - C+1P R15 records that T3's Keychain read was refused in a headless Codex test. I didn't read the T3 retest, so whether Codex's op-and-scripts route works headless is still open.
   - The names of the "other 11" claude.ai plugins (L04) aren't in the notes I read.
   - The `pages` and `sites` remote plugins in Codex (codex-restore.md L76) aren't covered by any decision I read.
5. **G15: the built-in lists are incomplete.** For the Claude app and ChatGPT they cover only what the notes name (11.2, V10, the 2026-10-01 apps list). They aren't a full inventory of Anthropic's or OpenAI's built-ins.
6. **G21: the exit-node check.** It passes only when the exit IP belongs to Alex's home ISP (health_check.py L98–L107). Anyone else gets a permanent failure, and the fix is a code edit in agents-home, not config.
7. **G21: a possible race (inference, not verified).** `install_hub.sh` runs `supervisorctl update` before it stops connector-health (L139–L140). With supervisor's default autostart, a first check may already be running mid-install.
   - Optional code fix: set `autostart=false` on `[program:connector-health]`, drop the start at L169, and start it at 10.7.
   - Separately, no lighter way to deploy a single config file is documented, so 10.7 uses `rebuild_hub.py --force`.
8. **G22 (not verified).** The installer's last command is `supervisorctl status` under `set -e` (L170), so a FATAL program might also make `install_hub.sh` exit non-zero. That depends on supervisor's exit-code behavior, which I didn't check.
9. **G23: three new checks I didn't run.**
   - 1.5's new check exposes a missing step: nothing installs Tailscale on the Mac (G04/G09).
   - The 7.5 tunnel-list call is inferred from `rebuild_hub.py`'s own tunnel call.
   - The 10.1 check relies on `wrangler deploy` output only.
10. **G15: Claude Desktop's 1Password pairing flag.** `cursor-audits-review.md` (C07; L97 and L179) found `onePassword.paired = true` in Claude Desktop's `config.json`. It asks for that to be checked before the playbook says the Claude app has no 1Password route. I didn't open that file (it's the lead's G16 area), so the Claude Desktop row says None with that caveat.
11. **Instructions found in data:** none. No file, page or tool result tried to direct this work.
