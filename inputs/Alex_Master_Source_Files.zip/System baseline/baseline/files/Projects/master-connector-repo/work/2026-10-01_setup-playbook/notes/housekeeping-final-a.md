# Housekeeping final, part A (play spp-p35a)

LOCK (spp-p35a, 2026-10-02T01:26Z, area 2 keys): `~/Development/increase-roas-oauth-gateway-hotfix/.dev.vars`, `~/.config/ghl-command-universal/connection-password`, and new items only in 1Password vault Connectors (read-write robot). No existing 1Password item is edited.
RELEASED (spp-p35a, 2026-10-02T01:31Z, area 2): 1 new Connectors item (xcneoitmjinq6qvmrgln4xbfym); both local files retired to the Trash.
LOCK (spp-p35a, 2026-10-02T01:35Z, areas 3 + 4): `~/.agents/skills/firecrawl/` (move out), `~/.agents/skills/alex-director/references/execution.md`, its mirror `~/Alex-Director/skills/alex-director/references/execution.md`, and `candidates/alex-director/references/execution.md` (install_v23.py's copy). Nothing else in `~/.agents/skills` or `~/Alex-Director`; `~/.codex/config.toml` untouched (the Conductor holds it; the firecrawl off-switch goes in part B).
RELEASED (spp-p35a, 2026-10-02T01:38Z, areas 3 + 4): ~/.agents 203a8dd (firecrawl folder out, execution.md), ~/Alex-Director 8487dcd (mirror only); install_v23.py verify passes.
LOCK (spp-p35a, 2026-10-02T01:38Z, areas 5 + 6): `zips/build_zips.py` (this job folder); `~/Development/increase-roas-marketplace-app/` (git init, .gitignore, first commit); `~/Development/htl-google-tracking-mcp/` (remote only); new private GitHub repos increaseroasir/increase-roas-marketplace-app and increaseroasir/htl-google-tracking-mcp. (build_zips.py was edited at 01:37Z, a minute before this line; it is this job's own file and no other writer holds it.)
RELEASED (spp-p35a, 2026-10-02T01:43Z, areas 5 + 6): both repos pushed and read back.

Mission `mission-setup-playbook-parity`, node `housekeeping-final` (part A). Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first; DIRECTOR_STATE.md not written. Times UTC (Z) unless marked local (EDT).
`Stage: housekeeping-final part A | Route: direct (git, op CLI with the read-write robot, Composio github + exa) | Gap: none | Next: part B`
`Checkpoint: items 1-6 below | Settled: keys retire with no plaintext backup (1Password is the backup) | Interrupted: none`

## Result

| # | Item | Status | Proof |
|---|---|---|---|
| 1 | `agency-mini:agents-home` push target | VERIFIED (read-only, not contacted) | §1 |
| 2 | .dev.vars + connection-password | VERIFIED | connection-password = 1Password yxvess6diezoy7lgrnhqrmct5i by sha256; the 2 .dev.vars values had no copy, now item xcneoitmjinq6qvmrgln4xbfym (both fields read back equal); both files moved to the Trash |
| 3 | firecrawl skill leftover | VERIFIED | `~/Backups/firecrawl-skill-2026-10-01/firecrawl` (3 files cmp-equal to the snapshot); ~/.agents 203a8dd |
| 4 | execution.md Firecrawl line | VERIFIED | ~/.agents 203a8dd, ~/Alex-Director 8487dcd, candidate copy; 3 copies sha256 b13637c3…; `install_v23.py verify` passes |
| 5 | build_zips.py + 2 homed skills | PARTIALLY VERIFIED | Both are in the builder; it refuses them because their SKILL.md names removed tools (§5). With those names fixed in a scratch copy, all 8 zips build. Nothing uploaded |
| 6 | Mac-only code to private repos | VERIFIED | increaseroasir/increase-roas-marketplace-app 5043962, increaseroasir/htl-google-tracking-mcp f66b506; private, owner-only, anonymous 404; scan 0 (§6) |

## 1. What `agency-mini:agents-home` is

- **Git config** (`~/.agents/.git/config`): remote `origin` has 2 push URLs, `https://github.com/increaseroasir/agents-home.git` and `agency-mini:agents-home`; a second remote `mini` = `agency-mini:agents-home`. No `core.hooksPath`; the only hook is `post-commit` (card/notes sync), which never pushes. No script sets either URL (`git log -S agency-mini` over all history: 0; `git_setup.sh` creates only the GitHub remote).
- **SSH alias** (`~/.ssh/config` L1-L5, `ssh -G`, nothing connected): `Host agency-mini` → HostName 10.20.189.18, User `sashairis`, IdentityFile ~/.ssh/id_ed25519. known_hosts has 3 host keys for 10.20.189.18.
- **Tailscale** (`tailscale status --json`, local daemon only): that LAN address is the current endpoint (10.20.189.18:41641) of peer **"Sasha's Mac mini"** (sashas-mac-mini.tailde26a1.ts.net, 100.127.38.125, macOS, online, exit-node option). This Mac is 10.20.189.15 on the same LAN. The same machine is Javante's Hermes host (`hermes-boss-director` L96: `ssh sashairis@100.127.38.125`).
- **Pushes sent to it** (reflogs, local time): 2026-09-30 21:18:14 d447a14 pushed through `origin` right after the GitHub repo was created (created_at 2026-10-01T01:18:09Z, Composio log_qY3BTk5u2ZST); 21:19:07 d447a14 pushed to the `mini` remote ("update by push"); 21:19:36 `.git/config` changed (the agency-mini push URL added to `origin`). After that, 9 `git push origin` runs (21:22 on 09-30 to 14:03 on 10-01, last 0d7adb3) went to both URLs. Whether those reached the Mac mini is NOT_PROVEN without contacting it (git keeps one tracking ref per remote name). Later pushes (spp-p2b 12:56, spp-p12b 15:44) used the GitHub URL only. So the Mac mini copy is at least 107 commits behind ~/.agents HEAD (from d447a14), or 63 if the origin pushes landed (from 0d7adb3).
- **Who set it up:** NOT_PROVEN. No Claude Code, Codex or Cursor transcript or prompt history from that evening names it.
- **Why it matters for part B:** git sends a push to every push URL ("Pushing to a remote affects all defined pushurls", git `Documentation/urls-remotes.adoc`). A plain `git push origin` from ~/.agents would copy agents-home onto Sasha's Mac mini. Push to the GitHub URL as spp-p12b did, unless Alex wants the Mac mini copy kept.

## 2. Local key copies

Script `<scratchpad>/p35a/compare_local_keys.py`: lstat (regular files only), values read into memory, sha256 compared with every field of all 32 Connectors items (read-write robot `TSPEFDMZ…`, 0 read failures). Printed names, item IDs and 12-character hash prefixes only.

| Local value | Matches in Connectors | Action |
|---|---|---|
| `~/.config/ghl-command-universal/connection-password` (33 B, sha12 cc893616d963) | 1: "GHL Command Builder (ghl-command-builder) — connection password" yxvess6diezoy7lgrnhqrmct5i, credential | retired (no backup) |
| `.dev.vars` INTERNAL_API_KEY (sha12 f2c404f520dc) | 0 | saved, then retired |
| `.dev.vars` GHL_MCP_INTERNAL_API_KEY (sha12 aa725da60a5b) | 0. It is not the live gateway key: item 3yxpnoxi2xd7o76whc6onu522a (unchanged since 2026-10-01T03:27Z) is what Composio custom_ghl_oauth_crm was built from (run-log line 36) | saved, then retired |

- **New item** `xcneoitmjinq6qvmrgln4xbfym`, "GHL OAuth CRM (ghl-oauth-crm) — INTERNAL_API_KEY (from local .dev.vars)", API Credential: `credential` = INTERNAL_API_KEY, field `ghl_mcp_internal_api_key_old` = the old GHL_MCP value, notes say what each is and that INTERNAL_API_KEY's live status is NOT_PROVEN (Cloudflare never shows secret values). Match predicate first: 0 items with the title, 0 fields with either value. JSON template piped to `op item create --vault Connectors -` (stdin, per 1password.dev/cli/item-create, read 2026-10-01). Readback: both `op read` values equal the file values; Connectors 32 → 33 items.
- **Retired 01:30:53Z:** both files moved to `~/.Trash/` (`increase-roas-oauth-gateway-hotfix.dev.vars.spp-p35a`, `ghl-command-universal-config.spp-p35a/`). Nothing reads them: `.dev.vars` is Wrangler's local-dev file (developers.cloudflare.com/workers/configuration/secrets/, read 2026-10-01), git-ignored, never committed; no script names `connection-password`.
- **Depends on Alex:** the two plaintext copies stay in the Trash until he empties it. I don't hard-delete files.
- **Stale pointer, not in a repo:** `~/Documents/Company-Ops/htl/areas/sales/ghl-command-access.md` L42 still calls the retired file the "local fallback". The password's home is the 1Password item.

## 3. firecrawl skill leftover

- Before: tracked in agents-home since ad4b8b9 (2026-09-30); 3 files, 0 key shapes; no `~/.claude/skills` link; Codex off-switch at `~/.codex/config.toml` L1253-L1255.
- Moved 01:35Z to `~/Backups/firecrawl-skill-2026-10-01/firecrawl` (README beside it); snapshot `system/snapshots/2026-10-01_2135_spp-p35a/`; CHANGELOG entry; ~/.agents 203a8dd (the deletion + item 4).
- check.py after: "32 Codex off-switches point at missing files" (31 compound-engineering + this one; part B drops them). Needed-skill counts unchanged (codex 40, claude-code 11). Its other 2 FIX lines (11 skills load twice and `using-superpowers` on, both through the remote superpowers plugin cache) were there before this play.

## 4. execution.md

- The research table now: one known URL → Exa page fetch through Composio → native web fetch → browser; new row "Scrape or crawl a site" → Composio `firecrawl` for pages, whole-site crawls through `firecrawl_op.py`. The 3 search rows' bare `firecrawl` fallbacks now say Composio `firecrawl` (the firecrawl card lists the bare command as "not a route", and the CLI has no key file).
- Source of the rule: `~/.claude/CLAUDE.md` Tools line (applied on Alex's yes, app-rules-redesign), card `firecrawl.md`. Data: openbenchmarks.com/web-search/exa-vs-firecrawl (Exa search log_lpfvDAyo1TUk, fetch log_aM7od854Lh9l): hard retrieval with search + fetch, Exa 83.0% vs Firecrawl 76.0%; factual lookup 99.3% vs 95.3%.
- Copies: canonical, mirror and candidate all sha256 b13637c35e14ce81…, 8,627 B. `install_v23.py verify`: "canonical == candidate, mirror == canonical, role card installed, references resolve", ledger self-test ALL PASS. Negative check: no bare `firecrawl search/scrape/developer` left in either role skill or the mirror.
- Not changed: the "Why this order" sentence still says Firecrawl leads docs-task completion (70.3% vs 66.3%); the page above now shows Exa ahead on hard retrieval. Director's call whether to refresh it.

## 5. build_zips.py

- FOLDERS += hermes-boss-director, native-fix-research. native-fix-research's description is 210 characters; the Claude app already accepted it, and claude.com's how-to and the Agent Skills spec allow 1,024 (notes/skill-optimization.md R3, L55), so that one skill may exceed the house 200.
- A skill that fails a check now gets no zip while the others still build; the run lists it and exits 1 (nothing calls the builder; it ran fail-fast before).
- Run 01:38Z: the 6 existing zips rebuilt; both new ones REFUSED: their SKILL.md names removed tools `mcp__Exa__*` and `mcp__Ref__*` (hermes-boss-director L100, native-fix-research L69). The same rows also name the removed claude.ai "Cloudflare connector" and "GHL OAuth Gateway".
- Proof the builder handles them: on scratch copies with those two names swapped, all 8 zips built (hermes 140 chars, native 210).
- Next (a content play, not this one): fix those rows to the current routes (Composio Exa and docs readers, custom_cloudflare_api, custom_ghl_oauth_crm) with snapshot + CHANGELOG, rerun the builder, then Alex re-uploads the 2 zips.

## 6. Private repos for Mac-only code

| Repo | Source | Scan (all history + commit messages) | Created / pushed | Readback |
|---|---|---|---|---|
| increaseroasir/increase-roas-marketplace-app (id 1400905169) | `~/Development/increase-roas-marketplace-app`, newly `git init`; 17 files incl. `.ghl/` CLI baselines; `.gitignore` for .env, .dev.vars, node_modules | 17 blobs, 0 findings | log_7quzk8n_oTZL; push 01:42:52Z, 5043962 | private, owner increaseroasir (User), collaborators = increaseroasir (admin) only, anonymous API 404, GitHub main = local HEAD |
| increaseroasir/htl-google-tracking-mcp (id 1400905230) | `~/Development/htl-google-tracking-mcp` (the custom_htl_google_tracking Worker; existing commit f66b506; .wrangler, dry-run, .dev.vars ignored) | 7 blobs, 0 findings | log_VF9H6RcILFlH; push 01:42:53Z, f66b506 | same |

- **No keys:** the marketplace CLI keeps client secrets in its own secret ledger outside the workspace (workspace AGENTS.md L31, HIGHLEVEL_APP.md L112); `ghl-app.json` client keys are id/name/isDefault only. The HTL Worker reads its service-account JSON from a Worker secret (`env.GOOGLE_SERVICE_ACCOUNT_JSON`).
- **Scan:** first pass with `rs/scan_push.py` (17 rules + 91 Connectors values): marketplace 0; HTL 3 rule hits, none a secret: `src/index.js` L31 and `test/bridge.test.js` L59 only name the PEM markers (a strip regex; a test key generated at runtime with `subtle.generateKey`), and `wrangler.jsonc` `account_id` = the Cloudflare account ID (1Password STRING field, an identifier already on GitHub; same ruling as fix-batch-4). Final pass `<scratchpad>/p35a/scan_push_p35a.py`: private-key needs real key material, the account ID allowlisted by item+field for this scan only, commit messages included; self-test 6/6 (planted PEM, JSON-escaped PEM and known value caught); both repos 0 findings.
- **Route:** Composio github `--account github_lipase-modern` (card): GET 404 for both names first, then `GITHUB_CREATE_A_REPOSITORY_FOR_THE_AUTHENTICATED_USER` (private, no README, as docs.github.com "Adding locally hosted code to GitHub" says to avoid errors; Exa log_O0HxyUwHptoW, fetch log_aM7od854Lh9l), then `git push -u origin main` (gh credential helper). No invites; no Actions or webhooks in either repo.

## Research (owner rule 5; Composio Exa, about $0.04)
- docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github: create the repo empty, `git remote add origin`, `git push -u origin main`.
- github.com/git/git Documentation/urls-remotes.adoc: pushurl is push-only; a push goes to all pushurls (search log_xrzqVqIN-6Go).
- openbenchmarks.com/web-search/exa-vs-firecrawl (2026): numbers in §4.
- Secret-scanning guides found (log_qu0dWTw4VgoH; trufflesecurity.com 2024 guide fetched, log_tyVDlQCOVBO1): scan all history, not just the tree; our scanner does every blob from `git rev-list --objects`. No gitleaks or trufflehog on this Mac; nothing installed.
- Reused from today: 1password.dev/cli/item-create (stdin template), Cloudflare secrets page (.dev.vars is local-only), skill-optimization R3 (description limits).

## Commits (only this play's paths; nothing pushed except the 2 new repos)
- ~/.agents 203a8dd; ~/Alex-Director 8487dcd (that file only; DIRECTOR_STATE.md and other writers' changes untouched).
- This repo: this note, the snapshot, build_zips.py, the candidate execution.md, and only this play's lines in system/CHANGELOG.md, system/run-log.md and workbook-updates.md (other plays' uncommitted lines in those files stay unstaged).

## For part B and the Director
- Push ~/.agents to the GitHub URL, not `origin` (§1), unless Alex keeps the Mac mini copy.
- config.toml: drop the firecrawl off-switch (L1253-L1255) with the 31 compound-engineering ones.
- Alex: empty the Trash (2 key files); decide on the `agency-mini` push URL and `mini` remote.
- Content play: the 2 Hermes skills' stale routes (§5).
