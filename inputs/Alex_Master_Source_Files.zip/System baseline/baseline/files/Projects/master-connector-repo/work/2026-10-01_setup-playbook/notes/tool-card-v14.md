# tool-card v1.4: the whole add-a-connector process (play spp-p42a)

LOCK (spp-p42a, 2026-10-02T02:43Z, until this file says released): `~/.agents/skills/tool-card/` (SKILL.md edit, new `references/`), its repo-conform mirror `~/.agents/skills/repo-conform/assets/universal-skills/tool-card/`, and the `tool-card` entry of `~/.agents/skills/repo-conform/assets/universal-skills/.past-versions.json`. Nothing else in `~/.agents` (not `instructions/`, `tools/cards/` or `tools/connectors/`, which other plays hold); no claude.ai upload (tool-card has none); `~/Alex-Director` not touched.
RELEASED (spp-p42a, 2026-10-02T02:55Z): ~/.agents 97409f1 + 3a970c2 (02:53:28Z; the 2 skill folders and .past-versions.json only; not pushed); tree clean.

Mission `mission-setup-playbook-parity`, node `tool-card-update`. Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first; DIRECTOR_STATE.md not written. Start: `~/.agents` a8d07ff. Approval: Alex, Director chat: "update tool card."
`Stage: done | Route: direct (Write/Edit, git, Composio exa for research, codex exec for the trigger check) | Gap: none | Next: Director: the findings in §8`

## 1. Result
tool-card v1.4 carries the whole add-a-connector process as a 9-step checklist core that links one level deep to 5 reference files. The v1.3 steps 1-12 are all kept, merged where they overlapped.

| File | Lines / chars | Holds |
|---|---|---|
| SKILL.md | 45 / 3,133 (v1.3: 86 / 5,326; house target 60 / 5,000) | description (181 chars, trigger-first), checklist 1-9, 6 gotchas |
| references/key-capture.md | 87 / 7,508 | step 1: pbpaste flow, skeleton, why (1Password docs), the 3 Director runs |
| references/route-compare.md | 63 / 5,524 | steps 3-4: key mover, tool-router flag, both-door proof, search gap, native vs hosted MCP, disable then delete behind the guard, strongest route (v1.3 step 8) |
| references/cli-wrapper.md | 46 / 4,245 | step 5: isolated install, tests first, `<tool>_op.py`, old key file retired by hash, proof, spend |
| references/tools-and-tiers.md | 31 / 2,552 | step 6: v1.3 steps 2-4, 6, 7, 10 and their gotchas; tiers point at tools/README.md (no copy) |
| references/card-and-logs.md | 74 / 5,549 | steps 7-9: card rules, card list on Alex's yes, commit and sync outside the sandbox, hosted lookup, routing row, workbook lines, run-log, report format |

Commits: ~/.agents **97409f1** (13 files: core, 5 references, mirror, .past-versions.json) and **3a970c2** (6 files: the Hugging Face facts in 3 references + mirror). Not pushed. Tree hash of v1.4 (repo-conform `tree_hash`): `ef6791a2ca78…`, equal for the live folder and the mirror.

## 2. Where each brief step and each v1.3 step lives
| Brief step | Core step | Reference | Source cited there |
|---|---|---|---|
| 1 Key capture | 1 | key-capture.md | Director transcript lines 19193 / 20276 / 20341 (Firecrawl uuopqngw…, Modal ozvkxvox…, Hugging Face u4gavrfz…); system/handoff/2026-10-01_connectors-handoff.md; 1Password docs |
| 2 Push into Composio | 3 | route-compare.md §1 | firecrawl-connector.md §2; huggingface-connector.md §2, §5; handoff (tool-router PATCH) |
| 3 Native vs hosted MCP | 4 | route-compare.md §2 | firecrawl-connector.md §3-§4 (30 vs 27; MCP experimental, no batch, no proxy); huggingface-connector.md §3-§4 |
| 4 CLI only if needed | 5 | cli-wrapper.md | firecrawl-connector.md §5; fresh-vault-fixes.md §1-§2; modal-connector.md §2-§4 (landed 22:31 local) |
| 5 Card + always-loaded list | 7 | card-and-logs.md §1-§2 | app-rules-redesign.md apply steps; modal-connector.md §5-§6; fresh-vault-fixes.md §6 |
| 6 Workbook and logs | 8 | card-and-logs.md §3 | workbook-updates.md spp-p30a and spp-p39a blocks |
| Gotchas (macOS prompt, Containers, .env/pipes) | Gotchas | key-capture.md cites macos-app-data-prompt.md | macos-app-data-prompt.md decisions 1-3 |

| v1.3 step | Now |
|---|---|
| 1 name the family, check connected | core 2 (+ route-compare §1) |
| 2 list every tool | tools-and-tiers 1 |
| 3 job + tier (name-pattern table) | tools-and-tiers 2: points at tools/README.md's classifier (the table was a copy of it) |
| 4 probe | tools-and-tiers 3 (+ guarded-delete case) |
| 5 write the card | card-and-logs §1 (merged with the template step) |
| 6 inventory | tools-and-tiers 5 |
| 7 T3-T5 settings for the owner | tools-and-tiers 4 |
| 8 strongest route | route-compare §3 (merged with the compare) |
| 9 routing row | card-and-logs §3 |
| 10 incidents | tools-and-tiers 6 |
| 11 report + format | core 9 + card-and-logs §4 |
| 12 run-log | card-and-logs §3 (merged with brief step 6) |
Anchor sweep: all 12 found in the new text.

## 3. Research (owner rule 5; Composio exa, about $0.04)
| Question | Finding | Source |
|---|---|---|
| How to split a skill | SKILL.md is an overview that points to detail; "Keep references one level deep from SKILL.md"; body under 500 lines; reference files over 100 lines get a table of contents; complex workflows get a copyable checklist; description in third person, what + when | platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices (EXA_SEARCH log_y1SKVFEPblmd, EXA_GET_CONTENTS_ACTION log_2fxKIi0wym-v) |
| Saving a key without exposing it | "Command arguments can be visible to other processes on your machine. If you're assigning sensitive values, use an item JSON template instead"; "You can also create an item from standard input using a template" | developer.1password.com/docs/cli/item-create (log_GnSxszi_Vy8j, log_55VZ9atHZ_0J) |
| Filling an existing item | `op item edit` takes piped JSON ("You can also edit an item using piped input") | developer.1password.com/docs/cli/reference/management-commands/item (log_atZtAXaYzqVO) |
| Robot and flags | `op item` needs `--vault` when the service account sees more than one vault; `OP_BIOMETRIC_UNLOCK_ENABLED` "Toggles the 1Password app integration on or off" | developer.1password.com/docs/service-accounts/use-with-1password-cli; /docs/cli/environment-variables (log_6-Juj4RkDgFJ) |
| Why key capture comes first | Modal: "This is the only time you can view the token secret"; Hugging Face's token page shows only the first and last characters later | modal.com/docs/guide/service-users (log_DWsbfoahyOZg; EXA_ANSWER log_shurSsyNrMZz); discuss.huggingface.co/t/149346, 2025-04 (EXA_ANSWER log_VNT55gLqQjLT) |

## 4. Mirrors and copies
- repo-conform mirror `~/.agents/skills/repo-conform/assets/universal-skills/tool-card/`: whole folder copied, `diff -r` equal, same tree hash. Its Codex off-switch (~/.codex/config.toml L860-L862, path = the mirror's SKILL.md) still matches, so Codex lists tool-card once.
- `.past-versions.json`: the v1.3 tree hash `ae6df25e…` added under tool-card (one line), so a project copy of v1.3 still counts as an unedited copy for repo-conform's K11.
- claude.ai upload: none. `zips/build_zips.py` builds 8 zips, none is tool-card, and the session's claude.ai skill list has no tool-card. Claude Code reads it through the `~/.claude/skills/tool-card` link; this session's skill list showed the new description right after the edit.
- Not a mirror, reported: `student-edition/repo/agents-home/skills/tool-card/` is v1.3 from a `git archive` of agents-home (notes/student-edition.md); it picks up v1.4 on the next student-edition build.

## 5. Trigger check (lean rule: one run, Codex, no Claude test runs)
- Harness: the spp-p13b runner + tripwire, copied to `notes/transcripts/spp-p42a/harness/`; the guard also blocks pbpaste, pbcopy, `find-generic-password` and `op` (self-test: 4 blocked, 2 reads allowed).
- Run 2026-10-02T02:50:31-02:51:35Z, `codex exec` (app-bundled 0.159.2) in ~/Projects/test-dynamite-parity, prompt: the read-only preamble + "Add the Notion connector." Exit 0, 64 s.
- **PASS.** It read `~/.agents/skills/tool-card/SKILL.md` ("I'm using the `tool-card` setup checklist"), then `references/route-compare.md` and `references/card-and-logs.md`, the composio card, and looked for a notion card (none). Also read in its first batch: Codex's system skill openai-docs (not ours). Guard: 2 calls, 0 blocks. `~/.codex/config.toml` sha cc54161cc796 before and after. Secret-pattern scan of the saved files: 0.
- Files: `notes/transcripts/spp-p42a/` (prompts.json, expected.json, trigger-1/N1.jsonl, N1.last.md, N1.guard.jsonl, batch.json). The run used the 97409f1 text; 3a970c2 changed references only (core and description unchanged), so the result stands.

## 6. Checks
- Sizes with repo-conform's own functions (`over`, `frontmatter`): SKILL.md 45 / 3,133 within target (K6 none); description 181 <= 200 (K4 none); frontmatter keys allowed (K5 none); name = folder; references all <= 87 lines (K17 none); `## Gotchas` present (K7 none). Same for the mirror.
- `audit.py <repo> --json`: no K4/K5/K6/K7/K11/K12/K17 finding for tool-card (only the pre-existing K1 copies in `.claude/worktrees/` and the student edition).
- `check.py` OK (rc 0) after the commits; `skill_deps.py` OK.
- Links: the 5 files named in the core = the 5 present; all 27 named scripts, notes and files exist. The key-capture skeleton parses (ast) and never prints the key.
- Negative check: sweep for retired names (mcp__Exa__, mcp__Ref__, web_search_exa, deep-research, "GHL OAuth Gateway", bare `orgo computers`, the hard-coded Composio project ID) and key-shaped strings: 0. Planted `mcp__Exa__` and a fake `hf_` token in an in-memory copy: both caught.

## 7. Workbook
Queued in workbook-updates.md (spp-p42a block): Skills R123; SOP R22 (what the skill now covers); Composio + 1Password right way R26-R28 (they still describe `op item edit` with Touch ID and a length-only check).

## 8. Findings for the Director
1. **Contradiction, queued:** Composio + 1Password right way R26-R28 (tabs/composio-1password.json) says the agent saves the key "with `op item edit`, and Alex approves with Touch ID". The three proven runs today used the read-write robot, `op item create` from a stdin template, no Touch ID, a hash readback and `pbcopy </dev/null`. The workbook-updates block has the replacement text.
2. **Stale decision:** notes/macos-app-data-prompt.md decision 5 says "no OP_BIOMETRIC_UNLOCK_ENABLED in our scripts". modal_op.py (spp-p39a), the Director's Modal and Hugging Face runs, and now tool-card all set it. Its stated effect matches the docs (it turns the app integration off; it doesn't stop the App Data prompt), so the note's decision 5 and Decisions and why R16 need one line saying it's used for that reason, or the Director reverses it in all three places.
3. **Index length:** card-and-logs.md says the card `index:` fits 70 characters (server cuts at 70, modal-connector.md §5; huggingface card 68). The card template L33-L36 and Rebuild from zero R355 still say 100: the template/Limits decision spp-p39a raised.
4. firecrawl_op.py still reads a fixed item ID (no op_items.py title lookup), so a fresh vault needs an edit there; orgo_op.py and modal_op.py don't. Small fix for whoever holds tools/connectors.
5. Not proven: a Claude Code trigger run (lean rule: Codex only). tool-card isn't on the Claude app or ChatGPT, by design (Skills, where they live R27).
