"""App decisions tab: one row per app in the workbook's All connections tab, with its keeper and why every other route stays.

Keeper = the live route All connections marks "THE ... route" (status H, notes J or target_home K); else the working
Composio login(s), one per account. An app with no live route still gets a row, as ADD TO COMPOSIO, when one of its rows
is still on the plan (decision_rules.open_step, W30); apps the owner dropped stay out.

'Routes to remove' are proposals checked against the tool cards, never authorization, and they are opt-in. A live route
is proposed only when ALL of these hold:
  1. its target_home (K) starts with "Remove" and K or its notes (J) call it a duplicate;
  2. the app is not a PLATFORM app (those never get a removal list);
  3. it is not a Composio route, plugin, connector or app, not a 1Password route, not hub plumbing, not a local CLI and
     not Javar's fence;
  4. the app has a proven keeper (status starts with "working" and how_verified is filled);
  5. its notes or K name that keeper's login, word ID or custom toolkit, and it reaches the same account (its
     account_it_reaches shares a domain, email, ID or company name with the keeper's);
  6. the app's tool card (~/.agents/tools/cards, matched by file name or aliases) names that keeper on its route: line.
Every other live route lands in a column that says why it stays or waits. A last check refuses to save if a proposal
names Composio, 1Password, op, Orgo, a hub or Javar.
Keeper power comes from the Route power tab (column L, verdict), joined on login ID, word ID or toolkit slug."""
import collections, csv, glob, os, re, shutil, sys

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decision_rules import open_step  # noqa: E402  W30: an app with no live route but an open setup step keeps its row

REPO =os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"
OUT = f"{REPO}/work/2026-10-01_app-decisions/app-decisions.csv"
CARDS = os.path.expanduser("~/.agents/tools/cards")
PLATFORM = {"Codex", "Codex plugin", "Cursor", "Composio", "Mac tools", "1Password", "Orgo", "Docs helper", "Hermes", "Unknown app"}
CLI_SURFACES = ("Mac CLI", "Mac (local tool)", "Mac scripts / agents")

wb = openpyxl.load_workbook(BOOK)


def table(name, header_row):
    """A tab's rows as dicts keyed by its header names, plus 'row' (the sheet row number). Columns are read by name."""
    ws = wb[name]
    head = [str(c.value or "").strip() for c in ws[header_row]]
    rows = []
    for cells in ws.iter_rows(min_row=header_row + 1):
        vals = ["" if c.value is None else str(c.value) for c in cells]
        if vals and vals[0].strip():
            d = dict(zip(head, vals))
            d["row"] = cells[0].row
            rows.append(d)
    return head, rows


head, rows = table("All connections", 1)
missing = {"app", "connection", "surface", "account_it_reaches", "status", "how_verified", "notes", "target_home"} - set(head)
if missing:
    sys.exit(f"All connections lacks columns {sorted(missing)}: fix the tab or this script")
phead, power_rows = table("Route power", 3)
if not {"app", "route", "verdict"} <= set(phead):
    sys.exit("Route power lacks its app, route or verdict column: fix the tab or this script")

app = lambda r: r["app"].split("(")[0].strip()
H = lambda r: r["status"].lower()
K = lambda r: r["target_home"].strip()
live = lambda r: not any(k in H(r) for k in ("removed", "deleted", "placeholder"))  # placeholders were never signed in
working = lambda r: H(r).startswith("working")
proven = lambda r: working(r) and bool(r["how_verified"].strip())
THE = re.compile(r"(?<!not )\bTHE\b[^.;]{0,40}?\broute\b")
marked = lambda r: any(THE.search(r[c]) for c in ("status", "notes", "target_home"))
acct = lambda r: re.sub(r"\s+", " ", r["account_it_reaches"]).strip()[:120] or "unknown"
fence = lambda r: ("javar" in (r["connection"] + r["surface"]).lower() or "hermes" in r["surface"].lower()
                   or K(r).startswith("Javar"))
onepw = lambda r: (app(r) == "1Password" or r["surface"].startswith("1Password")
                   or "1password" in (r["connection"] + " " + K(r)).lower())
composio_login = lambda r: r["surface"].startswith("Composio")
composio_any = lambda r: (app(r) == "Composio" or composio_login(r) or K(r).startswith("Composio")
                          or re.search(r"\bcomposio(?![-\w])", r["connection"], re.I) is not None)
hub = lambda r: (r["surface"].startswith("Orgo") or K(r).startswith("Orgo")
                 or re.search(r"\bhub\b|mcp-hub|openclaw", r["connection"], re.I) is not None)
cli = lambda r: r["surface"] in CLI_SURFACES

LOGIN = re.compile(r"\bca_[a-z0-9_-]{6,}")
WORDID = re.compile(r"\b([a-z][a-z0-9]*(?:_[a-z0-9]+)*?)_([a-z]+-[a-z]+)\b")  # toolkit_word-word
SLUG = re.compile(r"\bcustom_[a-z0-9]+(?:_[a-z0-9]+)*")
LONE = re.compile(r"(?<![\w-])([a-z]{3,}-[a-z]{3,})(?![\w-])")  # a bare word ID, as Route power writes them


def ids(text, lone=False):
    """Composio identifiers in a text: login IDs (ca_...), word IDs, toolkit slugs. 'strong' = specific to one route."""
    t = text.lower()
    out = {"login": set(LOGIN.findall(t)), "word": set(), "kit": set(SLUG.findall(WORDID.sub(" ", t)))}
    for kit, word in WORDID.findall(t):
        out["word"].add(word)
        out["kit"].add(kit)
        out["login"].add(f"{kit}_{word}")
    if lone:
        out["word"] |= set(LONE.findall(t))
    out["strong"] = out["login"] | out["word"] | {k for k in out["kit"] if k.startswith("custom_")}
    return out


def acct_ids(r):
    """Account identifiers in account_it_reaches: emails, domains, mixed letter+digit IDs, CamelCase company names."""
    t = r["account_it_reaches"]
    emails = re.findall(r"[\w.-]+@[\w.-]*\w|[\w.-]+@", t.lower())
    found = set(emails) | {e.split("@", 1)[1] for e in emails if not e.endswith("@")}
    found |= set(re.findall(r"(?<![\w.@-])(?:[\w-]+\.)+(?:com|io|ai|co|dev|net|org)\b", t.lower()))
    found |= {w.lower() for w in re.findall(r"\b[A-Z][a-z]+(?:[A-Z][a-z]+)+\b", t)}
    found |= {w for w in re.findall(r"\b[a-z0-9_-]{5,}\b", t.lower()) if re.search(r"\d", w) and re.search(r"[a-z]", w)}
    return found


def load_cards():
    cards = []
    for path in sorted(glob.glob(f"{CARDS}/*.md")):
        m = re.match(r"---\n(.*?)\n---", open(path, encoding="utf-8").read(), re.S)
        meta = dict((k.strip(), v.strip()) for k, _, v in (l.partition(":") for l in (m.group(1).splitlines() if m else [])))
        stem = os.path.basename(path)[:-3]
        names = {stem.replace("-", " ")} | {a.strip().lower() for a in meta.get("aliases", "").split(",") if a.strip()}
        cards.append({"file": os.path.basename(path), "route": meta.get("route", "").lower(), "names": names})
    return cards


CARD_LIST = load_cards()
if not CARD_LIST:
    print(f"warning: no tool cards in {CARDS}: every removal waits", file=sys.stderr)


def card_for(name):
    hits = [c for c in CARD_LIST if name.lower() in c["names"]]
    return hits[0] if len(hits) == 1 else None


BAD = re.compile(r"composio|1password|\bop\b|orgo|\bhub\b|plumbing|openclaw|javar|hermes", re.I)
identity = lambda r: " ".join((r["app"], r["connection"], r["surface"]))


def check_removal(r, name, keepers, card):
    """(keeper, None) when r may be proposed for removal, else (None, why it waits)."""
    said = (K(r) + " " + r["notes"]).lower()
    if name in PLATFORM:
        return None, "platform app: never gets a removal list"
    if BAD.search(identity(r)):
        return None, "names Composio, 1Password, op, Orgo, a hub or Javar: never proposed"
    good = [k for k in keepers if proven(k)]
    if not good:
        return None, "no proven keeper for this app yet"
    if "duplicate" not in said:
        return None, "All connections doesn't call it a duplicate"
    named = [k for k in good if any(i in said for i in ids(k["connection"])["strong"])]
    if not named:
        return None, "All connections doesn't name the keeper it duplicates"
    same = [k for k in named if acct_ids(k) & acct_ids(r)]
    if not same:
        return None, "not shown to reach the same account as the keeper"
    if card is None:
        return None, "no tool card for this app: run tool-card first"
    carded = [k for k in same if any(i in card["route"] for i in ids(k["connection"])["strong"])]
    if not carded:
        return None, f"tool card {card['file']} doesn't name the keeper"
    return carded[0], None


def power_for(keeper):
    """Route power rows for a keeper: the closest join wins (login ID, then word ID, then toolkit slug)."""
    k = ids(keeper["connection"])
    for level in ("login", "word", "kit"):
        hits = []
        for p in power_rows:
            q = ids(p["route"], lone=True)
            first = re.split(r"[\s,(]", p["route"].strip().lower(), maxsplit=1)[0]
            if (q["kit"] | {first} if level == "kit" else q[level]) & k[level]:
                hits.append(p)
        if hits:
            return hits
    return []


def label(r, n=60):
    s = re.sub(r"\s+", " ", r["connection"]).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def flag(r):
    return f" [K: {K(r)[:60]}]" if K(r).startswith(("Decide", "Remove")) else ""


groups = collections.defaultdict(list)
for r in rows:
    groups[app(r)].append(r)

out, proposed = [], []
for name, rs in sorted(groups.items()):
    lv = [r for r in rs if live(r)]
    if not lv and not any(open_step(r) for r in rs):  # W30: an app still on the plan (Shopify) shows as ADD TO COMPOSIO
        continue
    the = [r for r in lv if marked(r)]
    comp_ok = [r for r in lv if composio_login(r) and working(r)]
    if the:
        keep = the
        why = ("proven one way in (marked THE route in All connections)" if any(working(k) for k in the)
               else f"marked THE route in All connections, but not working now ({the[0]['status'][:40]})")
    elif comp_ok:
        seen, keep = set(), []
        for r in comp_ok:
            if acct(r) not in seen:
                seen.add(acct(r))
                keep.append(r)
        why = "working Composio route" + (f", one per account ({len(keep)})" if len(keep) > 1 else "")
    else:
        keep, why = [], "no proven keeper yet: add one through tool-card; nothing is removable until it is proven"
    if name in PLATFORM:
        why = (why + "; " if keep else "") + "platform tools and plumbing: never get a removal list"
    keep_ids = {id(r) for r in keep}
    card = card_for(name)
    props, wait, stays = [], [], []
    col = collections.defaultdict(list)
    for r in lv:
        if id(r) in keep_ids:
            continue
        if fence(r):
            col["fence"].append(r)
        elif onepw(r):
            col["1password"].append(r)
        elif composio_any(r):
            col["composio"].append(r)
        elif hub(r):
            col["hub"].append(r)
        elif cli(r):
            col["cli"].append(r)
        elif K(r).startswith("Remove"):
            k, reason = check_removal(r, name, keep, card)
            if k:
                props.append((r, k))
                proposed.append((name, r, k))
            else:
                wait.append((r, reason))
        elif K(r).startswith("Decide"):
            wait.append((r, f"Alex decides ({K(r)[:50]})"))
        else:
            stays.append(r)
    pw = list(dict.fromkeys(f"{p['verdict']} (Route power R{p['row']})" for k in keep for p in power_for(k)))
    names = lambda key: " | ".join(label(r, 45) + flag(r) for r in col[key]) or "—"
    status = ("PLATFORM" if name in PLATFORM else "CUT DUPLICATES" if props else "DONE" if the else
              "KEEP AS IS" if keep else "ADD TO COMPOSIO")
    out.append([name, status, len(lv), len({acct(r) for r in lv}),
                " | ".join(f"R{r['row']} {label(r)}" for r in keep) or "—", why, len(props),
                " | ".join(f"R{r['row']} {label(r)} [{r['surface'][:20]}, {r['status'][:24]}]" for r, _ in props)[:1500] or "—",
                " | ".join(f"R{r['row']} duplicates keeper R{k['row']}, same account; tool card {card['file']} names the keeper"
                           for r, k in props) or "—",
                " | ".join(f"R{r['row']} {label(r, 45)}: {reason}" for r, reason in wait) or "—",
                " | ".join(f"R{r['row']} {label(r, 45)} [K: {K(r)[:60] or 'blank'}]" for r in stays)[:1500] or "—",
                names("fence"), names("1password"), names("hub"), names("cli"), names("composio"),
                " | ".join(pw) or ("not in Route power" if keep else "—")])


def refuse_if_protected(proposed):
    """Last check: no proposal may name a kept or protected route. If one does, write nothing."""
    for name, r, k in proposed:
        if (name in PLATFORM or not K(r).startswith("Remove") or marked(r) or not proven(k)
                or BAD.search(identity(r))):
            sys.exit(f"refusing to write App decisions: R{r['row']} ({label(r)}) would be proposed but is a kept or protected route")


refuse_if_protected(proposed)

hdr = ["app", "status", "live routes", "accounts reached", "keeper", "why", "to remove",
       "routes to remove: proposals, not authorization [All connections row, where, status]",
       "removal check (keeper it duplicates, same account, tool card)",
       "not removable yet [row: why it waits]",
       "stays: All connections K says so [row, K]",
       "kept as Javar fence", "1Password keys and routes (stay)", "hubs behind Composio (stay)",
       "local CLIs (stay until Alex decides)", "Composio routes and other logins (stay; verify other accounts first)",
       "keeper power (Route power tab, column L)"]
with open(OUT, "w", newline="") as f:
    csv.writer(f).writerows([hdr] + out)
c = collections.Counter(r[1] for r in out)
print(f"{len(out)} apps | " + " | ".join(f"{k}: {v}" for k, v in c.most_common()), "| routes proposed for removal:",
      sum(r[6] for r in out), "| waiting:", sum(0 if r[9] == "—" else r[9].count(" | ") + 1 for r in out))

# Write the workbook tab from the same rows (the sheet is a projection; never hand-edit it).
if "App decisions" in wb.sheetnames:
    del wb["App decisions"]
ws = wb.create_sheet("App decisions", index=wb.sheetnames.index("All connections") + 1)
ws["A1"] = ("One row per app, built by work/2026-10-01_app-decisions/build_decisions.py from All connections (status, notes, "
            "target_home), the tool cards in ~/.agents/tools/cards and the Route power tab. Rerun the script; don't hand-edit "
            "this tab. Keeper = the route marked THE route in All connections, else the working Composio route (one per "
            "account). ADD TO COMPOSIO = no proven keeper yet: run tool-card; nothing is removable until one is proven.")
ws["A2"] = ("Removal lists are proposals checked against the tool cards, not authorization. A route is proposed only when "
            "All connections marks it Remove and a duplicate, it reaches the same account as a proven keeper, and the app's "
            "tool card names that keeper. Composio routes, plugins and connectors, 1Password, hub plumbing, local CLIs, "
            "Javar's fence and anything marked Stays, Keep, Leave off or Decide are never proposed. Before removing a proposed "
            "route, re-read its tool card and its All connections row, prove the keeper still works and back it up to "
            "~/Backups. Only then does the standing yes apply, and only to CUT DUPLICATES rows.")
for cell, height in (("A1", 48), ("A2", 64)):
    ws.merge_cells(f"{cell}:Q{cell[1]}")
    ws[cell].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[int(cell[1])].height = height
ws["A2"].font = Font(bold=True)
ws["A2"].fill = PatternFill("solid", fgColor="FCE4D6")
fill = {"CUT DUPLICATES": "FFEB9C", "ADD TO COMPOSIO": "F8CBAD", "KEEP AS IS": "C6EFCE", "DONE": "C6EFCE", "PLATFORM": "DDEBF7"}
for i, row in enumerate([hdr] + out, 3):
    for j, v in enumerate(row, 1):
        cell = ws.cell(i, j, value=v)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        if i == 3:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F3864")
    if i > 3 and row[1] in fill:
        ws.cell(i, 2).fill = PatternFill("solid", fgColor=fill[row[1]])
for col, w in zip("ABCDEFGHIJKLMNOPQ", (20, 16, 8, 9, 40, 30, 8, 50, 36, 44, 44, 24, 30, 26, 22, 34, 32)):
    ws.column_dimensions[col].width = w
ws.freeze_panes = "B4"
wb.save(BOOK)
if os.path.isdir(os.path.expanduser("~/Documents")):
    shutil.copy2(BOOK, os.path.expanduser("~/Documents/connectors-2026-09-30.xlsx"))
print("App decisions tab written")
