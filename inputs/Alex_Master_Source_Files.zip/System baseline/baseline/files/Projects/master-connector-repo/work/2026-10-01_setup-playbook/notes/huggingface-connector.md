# huggingface-connector (play spp-p40a, 2026-10-02, conductor v2.3, Claude Code subagent of session 294b676b)

Owner request (Alex, Director chat): "adding hugging face now i have they key copied rn". Done before this play: the
Director saved the token in 1Password Connectors as item `u4gavrfzax27phth755upip3lq` ("Hugging Face API token", field
`credential`, hf_, 37 chars). No local hf CLI, no ~/.cache/huggingface/token.

**Status: VERIFIED for the route; one parked delete.** One Hugging Face route in Composio (native `hugging_face`, login
`hugging_face_pricer-drongo`), reads proven from the CLI and the hosted door; no key file; no CLI. The hosted-MCP
duplicate is disabled; its delete waits on the Composio guard (CG-QWAA, Alex's typed yes). The card-list line in
shared.md is the Director's (Alex: "Add both cards"), not this play's.

Checkpoint: Claude Code subagent of session 294b676b, workspace master-connector-repo, conductor v2.3 | Settled: native
route (live comparison §3) | Interrupted: none. LOCK: none held. The card was a new file. shared.md was handed to the
Director mid-play, and server.py (spp-p41a) and the tool-card skill rewrite (another play) were left alone.

## 1. Research (read 2026-10-02; Exa through Composio: log_RReavPhvMtwu, log_Ccw7zwIeDvFv, 11 pages, ~$0.011)
| Question | Finding | Source |
|---|---|---|
| Composio `hugging_face` toolkit | native; API_KEY (`generic_api_key`) or Composio-managed OAUTH2; 135 tools at 20260729_00; base `https://huggingface.co/api`, user check `/api/whoami-v2`; no auth config or login existed | `GET /api/v3/toolkits/hugging_face`; `GET /api/v3.1/tools?toolkit_slug=hugging_face`; https://docs.composio.dev/toolkits/hugging_face |
| HF hosted MCP | `https://huggingface.co/mcp` with `Authorization: Bearer <token>` (or OAuth `?login`); docs list 7 built-ins (Spaces/papers/model/dataset/docs search, Jobs, repo details) + Gradio Space tools and Dynamic Spaces (experimental), each switched in hf.co/settings/mcp | https://huggingface.co/docs/hub/hf-mcp-server ; https://github.com/huggingface/hf-mcp-server (v0.3.5, 2026-02-24) |
| Composio proxy | any path on the toolkit's registrable domain, key injected server side; other domains refused | https://docs.composio.dev/docs/extending-sessions/proxy-execute.md ; live §3 |
| Custom MCP in Composio | experimental; the auth config is a separate required step; later tool changes need a manual sync; app_url and auth_schemes are immutable | https://docs.composio.dev/docs/extending-sessions/custom-mcp.md |
| Spend | Inference Providers: free users $0.10 a month, more needs bought credits; PRO $2. Jobs need a positive credit balance, billed per second. ZeroGPU: free 5 min a day, PRO 40 (more with credits) | https://huggingface.co/docs/inference-providers/pricing ; /docs/huggingface_hub/guides/jobs ; /docs/hub/spaces-zerogpu |
| Tokens | read, write or fine-grained roles; fine-grained recommended for production | https://huggingface.co/docs/hub/security-tokens |
| CLI | `hf auth login` writes ~/.cache/huggingface/token + stored_tokens; HF_TOKEN env is the scripted route; large uploads go through hf_xet to the Xet CAS service | https://huggingface.co/docs/huggingface_hub/guides/cli ; /guides/upload |

## 2. Native route (standing yes: push keys from 1Password into Composio)
- Auth config: `POST /api/v3/auth_configs` {toolkit hugging_face, use_custom_auth, API_KEY, credentials {}, tool router on} -> `ac_brfB1pNg8XRc` (ENABLED, field generic_api_key), 02:27:44Z; 0 existed before.
- Key: the title resolved to exactly `u4gavrfzax27phth755upip3lq` (op_items.py); `push_key_to_composio.py --item "Hugging Face API token" --toolkit hugging_face --field credential --scheme API_KEY --val-key generic_api_key` -> `ca_LT97uOiNLDhk` (`hugging_face_pricer-drongo`) ACTIVE 02:28:05Z.
- Free reads, login named: `HUGGING_FACE_GET_WHOAMI` log_trzUdBVhTnX8 = user bloomsterhehe, free plan (isPro false), no orgs; token "accss", fine-grained, created 02:20:56Z: repo read/write, contribute, discussions, posts, collections, webhooks, notifications, inference (serverless + endpoints), jobs; gated repos readable; no billing scope (`..._GET_SETTINGS_BILLING_USAGE_JOBS` 403, log_S7QeyTNybYKC). `HUGGING_FACE_GET_TRENDING` log_uirlDHuMtkQK.
- Proxy (`composio proxy <url> --toolkit hugging_face --account hugging_face_pricer-drongo --method GET </dev/null`; without `</dev/null` the CLI sends stdin as a body: "GET and HEAD requests cannot have body"): `/api/models?search=qwen3` (Qwen3-0.6B, Qwen3-VL-8B-Instruct, Qwen3-8B), `/api/spaces/semantic-search?q=transcribe audio files` (48 Spaces), `/api/jobs/bloomsterhehe` ([]), `https://router.huggingface.co/v1/models` (Inference Providers list). Refused: `https://nvidia-parakeet-tdt-0-6b-v3.hf.space/config` ("not on the same registrable domain as ... huggingface.co"). Xet host from `..._GET_MODELS_XET_READ_TOKEN` log_gizFUFZ3nDUu = cas-server.xethub.hf.co (token discarded unread).

## 3. Hosted MCP set up and compared (the docs show a job native + proxy can't reach: Gradio Space apps on *.hf.space)
- Upsert `{"slug":"HF_MCP","toolkit_config":{"name":"Hugging Face MCP (hosted)","app_url":"https://huggingface.co/mcp","auth_schemes":[{"mode":"API_KEY","headers":{"Authorization":"Bearer {{generic_api_key}}"}}]}}` -> `CUSTOM_HF_MCP`; auth config `ac_1vMgmmQKh5an`; key mover -> `ca_YEECCwwIMmni` (`custom_hf_mcp_invite-alose`) ACTIVE 02:32:50Z; auto-sync 4 tools (20261002_00). No key in any URL.

| Capability | Native `hugging_face` (135 tools + proxy) | Hosted MCP (4 tools with Alex's MCP settings) |
|---|---|---|
| whoami | `GET_WHOAMI` log_trzUdBVhTnX8 | `HF_WHOAMI` log_wa5lCeTyjc2x (same user, same scopes) |
| model search | proxy `/api/models?search=` (same top 3) | `HUB_REPO_SEARCH` log_SqzCu-LgIa5t |
| datasets, Spaces, trending, papers, docs, files | `LIST_DATASETS`, `LIST_SPACES`, `GET_TRENDING`, `SEARCH_PAPERS`, `GET_DAILY_PAPERS`, `SEARCH_DOCS`, `LIST_REPO_FILES`, `GET_RESOLVE`; Spaces semantic search via proxy | `HUB_REPO_SEARCH`, `HUB_REPO_DETAILS`, `HF_FS` |
| dataset viewer | 10+ tools (rows, search, SQL-like filter, statistics, parquet, splits) | preview + structure |
| writes | repos, commits, branches, tags, discussions, collections, webhooks, Space settings/secrets/variables, notifications | none (all 4 read-only) |
| inference, Jobs | 2 inference tools; router + `/api/jobs` via proxy (spend: ask Alex) | none in Alex's settings |
| Gradio Space apps | no (proxy refuses *.hf.space) | none in Alex's settings (needs Spaces or Dynamic Spaces switched on + a manual Composio resync) |
| upkeep | Composio maintains and versions it | experimental; manual resync on any HF or settings change |
**Verdict: keep native `hugging_face` (STRONGEST).** Every MCP tool has a native tool or proxy path; the MCP adds no job
with Alex's settings, and its one extra kind (Space apps) needs his click plus a resync. While active, the duplicate
also took every Hugging Face search result on both doors (§5).

## 4. Removing the duplicate (standing yes: a proven duplicate login)
- Dependency check: no file in ~/.agents, ~/Alex-Director or this repo names it. `PATCH /api/v3/auth_configs/ac_1vMgmmQKh5an/DISABLED` -> DISABLED (readback); hosted search then shows `custom_hf_mcp` has_active_connection false.
- **Parked on the Composio guard:** `DELETE https://backend.composio.dev/api/v3.1/custom/toolkits/CUSTOM_HF_MCP` (also removes `ac_1vMgmmQKh5an` and `ca_YEECCwwIMmni`) stopped as **CG-QWAA** (no-yes; nothing ran). Same call, once, after Alex types a yes naming CG-QWAA. Not retried, no other route.

## 5. Every AI: the two doors
- CLI (Claude Code, Codex): `composio execute HUGGING_FACE_* --account hugging_face_pricer-drongo` (§2).
- Hosted door (Claude app, Claude Desktop chat, Cowork, ChatGPT): `COMPOSIO_MULTI_EXECUTE_TOOL` ran `HUGGING_FACE_GET_WHOAMI` with that account, log_fYB8vY78B2mQ; `COMPOSIO_GET_TOOL_SCHEMAS` for `HUGGING_FACE_GET_TRENDING`, log_XraWAUaim74f.
- **Finding:** `COMPOSIO_SEARCH_TOOLS` (log_VF420yqc6nQH, log_etpGrumMNaO9 tool_search, log_Jroh9Cp-T6Un after the disable) and the unfiltered CLI search (02:48:51Z, 20 min after connecting) never list `HUGGING_FACE_*` and leave hugging_face out of their connected list, while firecrawl (same auth-config kind, same user id; records compared field by field) is found (log_6pxD0qo-68Wj). `composio search ... --toolkits hugging_face` finds `GET_WHOAMI` and `GET_TRENDING`. So the card sends chat apps card -> schema by slug -> execute.
- Not run here: Codex, the Claude app, ChatGPT (same CLI or hosted door; NOT_PROVEN until parity-recheck).

## 6. CLI: not installed
No task of Alex's needs uploads today. Composio can't do large ones: files the preupload check marks `lfs` go to Xet
storage on another domain (§2), and the commit tool sends only small inline files. If that need comes, the Director adds
the hf CLI with a wrapper on the firecrawl_op.py pattern (HF_TOKEN from 1Password per run, refusing `hf auth login`).
Key scan (02:5xZ, value compared in memory, never printed): 0 of 521,717 files hold the token (~/.agents, ~/.claude,
~/.codex, ~/.cursor, ~/.config, ~/.cache, ~/.composio, ~/.hermes, this repo, ~/Alex-Director, ~/Backups, Claude
Desktop's Application Support, /private/tmp/claude-501, $TMPDIR, shell history, ~/.claude.json); ~/.cache/huggingface
absent. Not checked: 137 files over 20 MB, 10 .env files and 2,270 pipes/links (skipped by rule), ~/Library/Containers.

## 7. Card and hosted notes
`~/.agents/tools/cards/huggingface.md` (54 lines, 4,807 chars; index 68 chars, so the hosted description's 70-char cut
keeps the whole line), ~/.agents `3aed53d` + `210e14d` (that path only, hook skipped). `sync_notes.py` by hand twice:
16 cards, restarted, Composio refresh 200. `CUSTOM_IR_NOTES_GET_APP_RULES` 20261002_04 lists
"- huggingface: HF: Composio hugging_face_pricer-drongo; inference/compute: ask Alex"; app=huggingface log_PxNeyuWPa-d4,
app=hf log_n6L0kYaiZape, after the fix log_O6IcJQZu8lmK. Snapshot `system/snapshots/2026-10-01_2245_spp-p40a/README.txt`.
Tiers: T0 reads (whoami, info, lists, dataset viewer, papers, docs, notifications); T1 Hub search; T2 repo create
(private), commits, branches, tags, collections, webhooks, Space variables/secrets, settings; T3 deletes, squashes,
commits with deleted_entries; T4 discussions, comments, paper claims, gated-access requests, making a repo public;
T5 inference tools (credits), Jobs/Endpoints/Space hardware through the API (never via proxy).

## 8. Not done here, for the Director
1. CG-QWAA (Alex's typed yes), then drop the MCP rows queued in workbook-updates.md.
2. Card-list line `huggingface` (models, datasets) in shared.md + rebuild: the Director (told in one line after 3aed53d).
3. Write power is shown by the token's scopes, not exercised (no live write: the only clean undo is a delete, which the guard stops).
4. Search gap (§5): a Composio-side behaviour; worth one line on the composio card if it repeats for the next native toolkit.
5. tools/_inventory.md not updated (another writer has it modified and uncommitted).
