# composio-1password-removal (play spp-p31a, node onepassword-one-route, finding F1), 2026-10-01

- Controller: Claude Code subagent of session 294b676b-77d8-4d64-976e-70a783b96d65, workspace
  `~/Projects/master-connector-repo`, conductor v2.3 loaded first.
- Owner yes (Alex, Director chat, quoted by the Director): "i see. this new upgrade is much riskier and im okay with
  that. but this seems like easy risk mitigation. prompt injection seems serious".
- `Stage: LIVE-SYSTEM | Route: direct (Composio REST + CLI, op as robots) | Gap: PERMISSION (guard yes for the permanent delete; Alex's revoke click) | Next: Alex's 2 steps, then the 2 scripts below`
- `Checkpoint: pause + archive read back 22:13-22:18Z | Settled: no Composio 1Password toolkit (Alex) | Interrupted: none (the guard stopped the delete before it ran)`
- Rules kept: no token or key was printed, saved or logged. No `.env` file or pipe was opened. Every `op` call ran as a
  robot with the desktop-app sign-in off (`OP_BIOMETRIC_UNLOCK_ENABLED=false`), so no 1Password prompt could appear.
  Scripts print IDs, statuses and lengths only, and assert that no token is in their output.

## Result: PARTIALLY VERIFIED

| Outcome | Status | Proof |
|---|---|---|
| No AI can reach 1Password through Composio | **VERIFIED** (22:13:57Z) | Both logins paused, auth config disabled; a 1Password call through Composio fails with "No active connection"; the hosted connector's search offers no 1Password tool (§2) |
| The token is gone from Composio (permanent delete of both logins) | **PARKED**: guard code **CG-SZRA** | The Composio guard stopped the delete before it ran (22:15:41Z). It needs Alex's own yes in the Director chat (§2.4) |
| The token item is out of the active Connectors vault | **VERIFIED** (22:17:09Z) | Archived. The read-only robot no longer lists it, and a lookup by name fails (§3) |
| No robot can read that token | **NOT MET until Alex revokes** | Archiving doesn't stop reads by ID. The read-only robot read the archived token by ID (exit 0), as 1Password's docs say it can (§3) |
| The old token gets an auth error | **WAITING ON ALEX** | His click is in §4. The proof script is ready, and its baseline says ALIVE (26 vaults) |

## 1. Research (owner rules 5 and 6)

Pages read through Exa (Composio `exa`), 2026-10-01.

| Question | Answer | Source |
|---|---|---|
| What deleting a Composio login does | "The account immediately stops working for API calls and cannot be restored through the API." `revoke_on_delete` is optional. | docs.composio.dev/reference/api-reference/connected-accounts/deleteConnectedAccountsByNanoid (log_oM7cTu2KMDxE) |
| A reversible pause | "Set to INACTIVE to pause access, or ACTIVE to restore"; "INACTIVE accounts cannot execute tools." | docs.composio.dev/docs/auth-configuration/connected-accounts (log_oM7cTu2KMDxE) |
| What disabling or deleting the auth config does | Disabled: it "cannot be used to create new connected accounts", but "existing connections may continue to work". Deleted: "will prevent any connected accounts that use this auth config from functioning". Neither text says the logins' stored tokens are removed, so the logins are deleted themselves. | docs.composio.dev/reference/sdk-reference/typescript/auth-configs (log_PT0IgEZ5EwSW); search log_LMwxNtJ8UQzz |
| Revoking a 1Password service account | "Revoking a service account token immediately removes its access to 1Password vaults." Click path in §4. | https://www.1password.dev/service-accounts/manage-service-accounts (= developer.1password.com/docs/service-accounts/manage-service-accounts/) (log_Ig5aYMcmqYv-) |
| Archiving a 1Password item | `op item delete <item> --archive` moves the item to the Archive. "To get details for an item in the Archive, specify the item by ID or use the `--include-archive` option." | developer.1password.com/docs/cli/reference/management-commands/item/ (log_O80Yyl-JxB25) |
| Why: prompt injection | 160 automated tests across 8 models: "up to 40% data leakage" in authorized-looking contexts, and up to 90% exfiltration of sensitive files. The authors' conclusion: MCP setups can't rely on the model's own safety. | Barcelos, Quincozes, Souza, SBSeg 2026, published 2026-09-01, https://sol.sbc.org.br/index.php/sbseg/article/view/44305 (log_uUCmpnVyL99G; search log_RqFnL7FXpAvW) |
| Why: a real case | A malicious public GitHub issue made Claude 4 Opus, using the official GitHub MCP server, copy private-repo data into a public pull request. "Always Allow" settings remove the last check. | Invariant Labs, 2025-05-26, https://invariantlabs.ai/blog/mcp-github-vulnerability (log_uUCmpnVyL99G) |

## 2. Composio (project pr_JDtrNq9tUa_i)

### 2.1 Before (22:10:44Z; IDs and creation dates only)

| Kind | ID | State | Created |
|---|---|---|---|
| auth config `_1password` (API_KEY, custom) | ac_FFWFZ84tq6l7 | ENABLED, 2 logins, none from another toolkit | 2026-08-19T05:07:24.708Z |
| login | ca_PSjKn84-Yd_T | ACTIVE | 2026-10-01T20:40:00.606Z |
| login | ca_tUN0EokIrKzF | EXPIRED | 2026-10-01T20:24:13.486Z |

- The toolkit query and the config query each found the same 2 logins.
- 0 Composio MCP server configs and 0 triggers on these logins.
- The org's other project (Platform, `pr_UFj…`, 7 auth configs) has no 1Password config or login.
- Files: `notes/composio-1password-removal-composio.json` (before, pause log, after);
  scratchpad `p31a_composio_1p_inventory.py`.

### 2.2 Step 1: pause before delete (R6 "disable before delete", notes/r5-r6-vocabulary-drift.md)

| Time (UTC) | Change | Readback |
|---|---|---|
| 22:13:42Z | target check: both logins `_1password` on ac_FFWFZ84tq6l7 | pass |
| 22:13:42.962Z | ca_PSjKn84-Yd_T paused (`PATCH …/status {"enabled": false}`), HTTP 200 | INACTIVE |
| 22:13:43.530Z | ca_tUN0EokIrKzF pause refused, HTTP 409 (sent once, not retried) | still EXPIRED, which can't run tools either |
| 22:13:43.840Z | ac_FFWFZ84tq6l7 disabled (`PATCH …/DISABLED`), HTTP 200 | DISABLED |

### 2.3 Proof that no AI can reach it

- **Execute** (Composio CLI, 22:13:57Z): `composio execute _1PASSWORD_LIST_VAULTS -d '{}'` returned
  `"successful": false`, "No active connection found for toolkit "_1password"" (`ToolRouterV2_NoActiveConnection`).
- **CLI search** (22:14:09Z): it lists the catalog's 2 tools, as it does for any toolkit, with
  `"connected_toolkits": []`, and its next step is "composio link _1password".
- **Hosted connector search** (the Composio door for the Claude app, Claude Desktop chat and ChatGPT; run from this
  session's claude.ai Composio connector, `COMPOSIO_SEARCH_TOOLS`, 22:14:27Z, log_PRh6-mh2qkEn): for "list the vaults
  in my 1Password account using the 1password toolkit", it returned no 1Password tool at all.
- **New logins:** the auth config is disabled, so it can't be used to make one (Composio docs above).

### 2.4 Step 2: permanent delete, stopped by the guard

- 22:15:41Z: the Composio guard (`~/.agents/tools/guards/composio_guard.py`, decision V13) denied
  `scripts/p31a_delete_composio_1p_logins.py` before it ran:
  - `DELETE … /connected_accounts/ca_PSjKn84-Yd_T`;
  - targets ca_PSjKn84-Yd_T, ca_tUN0EokIrKzF, pr_JDtrNq9tUa_i;
  - code **CG-SZRA** (`~/.agents/runtime/composio-guard/decisions.jsonl`).
- As the guard asks of a subagent, it was reported, not retried, and no other route was tried.
- **Quirk found after the stop (for the composio card).** A disabled auth config hides its logins:
  - by-ID `GET` and `PATCH` return 404 "Connected account … not found";
  - the toolkit-filtered list returns 0;
  - only `GET /api/v3/connected_accounts?auth_config_ids=ac_FFWFZ84tq6l7` still shows both (INACTIVE, EXPIRED);
  - `GET /api/v3/auth_configs` also hides disabled configs unless `show_disabled=true` (Composio OpenAPI).
- So the after-list at 22:18:40Z looked empty, but nothing had been deleted: the guard log shows no allow, and no delete log exists.
- The first delete script would have skipped both logins as "already gone", so it was rewritten:
  1. check the config's list holds exactly these 2 `_1password` logins;
  2. re-enable the config (the logins stay INACTIVE/EXPIRED, so nothing can run);
  3. delete each login once;
  4. check by ID for 404;
  5. always set the config back to DISABLED (`finally`) and read that back.
- The guard's own `analyze_bash` gives the rewritten file the same code, CG-SZRA.
- **Resume:**
  1. Alex types his yes in the Director chat, after a question that names CG-SZRA or the two login IDs.
  2. Run once, outside the sandbox: `python3 work/2026-10-01_setup-playbook/scripts/p31a_delete_composio_1p_logins.py`.
  3. Expected: delete HTTP 200 twice, by-ID 404, config DISABLED, 0 logins left.
  4. Log: `notes/composio-1password-removal-deletes.json`.

## 3. 1Password (vault Connectors `r6z62bjyy3c5ipilbgs4lyakwi`)

- **Target:** "1Password service account — composio", `yp6ons6ebd6zcot6tv6dzyssb4`.
  - API Credential, made 2026-10-01T20:39:36Z.
  - One concealed `credential` field, 832 characters.
  - Connectors before: 33 active items, 43 with the archive.
- **Archive (22:17:09Z):** the read-write robot (`connectors-sync-rw`, user `TSPEFDMZ2VBOJDSVIAGV76JVNU`) ran
  `op item delete yp6ons6ebd6zcot6tv6dzyssb4 --vault r6z62bjyy3c5ipilbgs4lyakwi --archive`, exit 0.
  - Readback: not in the active list (32), in the list with the archive (43), state ARCHIVED.
  - The token is kept, because the revoke proof reads it.
- **Read-only robot** (`MA5UFZVUJFHYXC5UEXMYYDL53I`; its token came from its backup item `5l5qorgqmbn5bdlqqlupxu4w5a`,
  held in memory), 22:17:20Z:
  - active list: item absent (32 items);
  - lookup by name: error "isn't an item in the … vault";
  - list with `--include-archive`: present;
  - **lookup by ID: exit 0, ARCHIVED, token field present.**
- **So archiving only hides the item from lists and name lookups.** Any robot that has the ID can still read the token,
  and the ID is in our notes and the workbook's 1Password item catalog. Both connectors-sync robots can read it until
  Alex revokes it.
- **Baseline for the revoke proof:** `scripts/p31a_check_composio_token_revoked.py`, log
  `notes/composio-1password-revoke-check.jsonl`.
  - At 22:17:55Z and 22:18:25Z the token signed in: SERVICE_ACCOUNT `YS3DH2HI7VHS3LITY7MEF55HOA`, 26 vaults. Verdict ALIVE.
  - Control: the read-write robot signed in at the same moment (exit 0).
- **Other copies:** 0 of 175 Cursor chat-record files under `~/.cursor/projects/empty-window/agent-transcripts`
  hold the token. That includes chat 19f0f512, which made the robot. Checked for the full token, a JSON-escaped form,
  and its first and last 64 characters.
- Files: `notes/composio-1password-removal-1password.json`; scratchpad `p31a_op.py`, `p31a_token_copies.py`.

## 4. Alex's click: revoke the robot's token (a 1Password security setting)

From 1Password's "Manage service accounts" page, section "Revoke a service account token"
(https://www.1password.dev/service-accounts/manage-service-accounts, read 2026-10-01, log_Ig5aYMcmqYv-):
1. Sign in to your account on 1Password.com (increaseroas.1password.com).
2. Select **Developer** in the sidebar.
3. Select **Service accounts** at the top of the page, then choose **composio**.
4. Under the **Token** section, select **Revoke Token**.
5. Enter the service account name (**composio**) to confirm, then select **Revoke Token**.

The docs say: "Revoking a service account token immediately removes its access to 1Password vaults."

After his click (agent, no clicks):
- Run `python3 work/2026-10-01_setup-playbook/scripts/p31a_check_composio_token_revoked.py` once, outside the sandbox.
- Expected: `REVOKED`, both calls fail with an auth error while the control robot still signs in.
- If the error text isn't recognised, the verdict is `UNCLEAR`, never a false `REVOKED`.

Optional, also Alex's: permanently delete the archived item once the token is dead. 1Password keeps deleted items 30
days in Recently Deleted (CLI docs, log_O80Yyl-JxB25).

## 5. Left, with resume conditions

1. **Permanent delete of the 2 Composio logins.**
   - Waits on Alex's yes in the Director chat, naming CG-SZRA or ca_PSjKn84-Yd_T + ca_tUN0EokIrKzF.
   - Then one run of `scripts/p31a_delete_composio_1p_logins.py`.
2. **Revoke.**
   - Waits on Alex's click (§4). Then one run of `scripts/p31a_check_composio_token_revoked.py`.
   - Until then, "no robot can read that token" is not met.
3. **For the lead (queued, not done here):**
   - workbook rows (workbook-updates.md, spp-p31a line);
   - the composio card quirk line (§2.4), which goes through the card rebuild with its lock line.
4. **Not in this play:** the optional item moves A1-A4 from spp-p28a.

## 6. Checks (verify-before-done, normal stakes)

| Check | How | Result |
|---|---|---|
| Right Composio targets | 2 queries (toolkit and config) agree; the script re-checked toolkit and config before changing anything | Pass |
| Pause written | GET after each PATCH | Pass: INACTIVE and DISABLED; the EXPIRED login refused (409) and stays EXPIRED |
| No AI reach | CLI execute; CLI search; hosted connector search | Pass (§2.3) |
| Archive written | lists before and after; get with `--include-archive` | Pass: 33 -> 32 active, 43 total unchanged, ARCHIVED |
| Read-only robot, active vault | active list; lookup by name | Pass: absent; lookup by name fails |
| **Negative 1**: would archiving be enough? | read-only robot reads the item by ID | Fails: the token is readable by ID. Recorded as NOT MET, not as a pass |
| **Negative 2**: is "0 logins" true? | list by auth config after the empty after-list | Fails: both logins still exist (hidden). The false reading was caught and the delete script fixed |
| **Negative 3**: can the checker say REVOKED wrongly? | a fake token gives "invalid credentials provided", which the pattern catches; REVOKED also needs the control robot to sign in | Pass |
| Guard code still valid for the fixed script | the guard's own `analyze_bash` on the final file | Pass: CG-SZRA |
| Citations | each page fetched; quoted lines match | Pass (§1) |
| No secret leaked | outputs are IDs, statuses, lengths; in-script asserts; `ops_` and API-key grep of the new notes and scripts | Pass |

**Couldn't check:**
- The real error text of a revoked token. Until Alex revokes, the script answers UNCLEAR rather than REVOKED.
- Whether a by-ID DELETE works while the config is disabled. That call is guarded; the 404 on the by-ID PATCH probe
  suggests it doesn't, so the script re-enables the config first.
- The ChatGPT and Codex Composio plugins weren't searched from those apps. They use the same Composio account, so the
  same backend state applies (inference).
- Whether `composio link _1password` could make a new auth config on its own. Not run: it would create state.
- Token copies in Cursor's `state.vscdb` (22.7 GB) and other apps' stores. Only the chat-record files were scanned.
