# Playbook tabs (node playbook-tabs, play spp-p5c)

- Date: 2026-10-01. Controller: Claude Code subagent of session 294b676b, workspace ~/Projects/master-connector-repo.
- Independent run: this node did not open `peer-comparison/`, `work/2026-10-01_master-sop/` or any "Master SOP and Sources" file.
- STOP-RULE (Director, during this play): no `.env` file or named pipe was opened, read, grepped, copied, hashed or moved. Listings used `find <path> -type f -not -name '*.env' -not -name '.env*' -not -flags +dataless`; source checks use `lstat` only.
- The real workbook was not written. Every build ran on a copy in `$TMPDIR` (section 5).

## 1. ~/.agents (agents-home) as read 2026-10-01 ~18:30Z
- Remote: `origin https://github.com/increaseroasir/agents-home.git` (second push remote `mini`). Latest commits: f77e02c (orgo_op, K05), 2713b89 (instruction layer + 4 global cards, spp-p4a), 0d7adb3 (Composio "two doors" rule), 70f9ed8 (Director + conductor v2.1), 2917d22 (gcloud_robot), 73a494e (hub rebuild source + tracked post-commit hook).
- Top level: `instructions/`, `plugins/`, `runtime/` (ignored), `skills/`, `tools/`, `.skill-lock.json`, `.gitignore`.
- `tools/`: `cards/` (13 cards), `connectors/` (`cards_to_sheet.py`, `gcloud_robot.py`, `google_robot/`, `health/`, `hub/`, `ir_notes/`, `orgo_op.py`, `push_key_to_composio.py`), `skill-hygiene/`, `unify/` (`build_instructions.py`, `check.py`, `git_setup.sh`, `hooks/post-commit`, `unify.py`).
- `tools/connectors/hub/`: `README.md`, `VERSIONS.json`, `capture_hub.py`, `install_hub.sh`, `rebuild_hub.py`, `requirements/` (4 venv freezes), `root/` (28 files: `/opt/mcp-hub` and the two supervisor confs). rebuild-sources.md's "32 of 32 files match the live hub" also counts the 4 files deployed from elsewhere in agents-home (ir-notes server, google-robot server, `health_check.py`, `config.json`).
- Skills: 121 skill folders on disk, 119 tracked. `git status --porcelain` showed two untracked folders: `skills/intake-triage/` and `skills/verify-before-done/` (another agent's work in progress). Until they are committed, a fresh clone lacks them; repo-conform's `assets/universal-skills/` holds copies and `audit.py --fix` installs universal skills globally (check K12). Re-read at ~18:46Z: both were committed in 135cdda (spp-p8a), and 294913c (spp-p4c, S10) merged the Claude-side skill variants into ~/.agents and linked them.
- Health check scheduling: `hub/root/etc/supervisor/conf.d/mcp-hub.conf` defines `[program:connector-health]` running `/opt/mcp-hub/health/loop.sh`, which runs `health_check.py` every 1,800 s ("no cron on this box"). The docstring of `health_check.py` still says cron: stale wording, behaviour is supervisor.
- `tailscaled` on the hub: `--tun=userspace-networking --socks5-server=localhost:1055 --outbound-http-proxy-listen=localhost:1056` (mcp-hub.conf).

## 2. Other repos (remotes read 2026-10-01)
| Folder | Remote | Latest commit |
|---|---|---|
| ~/Projects/master-connector-repo | origin github.com/increaseroasir/master-connector-repo | f1b1355 |
| ~/Development/ghl-command-universal | origin github.com/increaseroasir/ghl-command-universal | 6fcc3b4 |
| ~/Development/increase-roas-oauth-gateway-hotfix | origin github.com/increaseroasir/increase-roas-oauth-gateway (old remote kept as increase-roas-org) | b464b6d |
| ~/Alex-Director | origin github.com/increase-roas/alex-director | ba9337c |

## 3. Research for the build script (owner rule 5: the right way first, on Exa)
Exa through Composio (`EXA_SEARCH`, 3 searches, $0.021, log_82gmEktHqdAz), read 2026-10-01:
- https://support.microsoft.com/en-us/excel/excel-specifications-and-limits: a cell holds at most 32,767 characters and 253 line feeds; row height at most 409 points.
- https://support.microsoft.com/en-us/excel/rename-a-worksheet: a sheet name can't be blank, longer than 31 characters, contain `/ \ ? * : [ ]`, begin or end with an apostrophe, or be "History".
- https://openpyxl.readthedocs.io/en/3.1/tutorial.html: openpyxl doesn't read every item in an Excel file, so shapes are lost when a file is opened and saved. The workbook has always been written by openpyxl; the dry run compares every cell of every existing tab to prove nothing else changed.
Consequences in `build_tabs.py`: the requested names "Do / Don't and why", "Composio + 1Password, the right way" and "Skills: where they live" are illegal, so the tabs are "Do, Don't and why", "Composio + 1Password right way" and "Skills, where they live"; templates go one line per row (no 253-line-feed or 409-point limit, and a column copies back as the file).

## 4. Template sources
- Blueprint: `~/.agents/skills/repo-conform/assets/skeleton/` (37 files, repo-conform 2.1).
- The repo's `work/_template/` files equal the skeleton's (cmp). The repo's `tools/_card-template.md` is an older version: it lacks the `route:` line and the Composio-slug wording of the skeleton copy. The tab uses the skeleton copy.
- `setup/00-start-here.md` differs between the repo and the skeleton (the repo copy was updated by spp-p4b).

## 5. Dry run (2026-10-01 18:44Z; full report `notes/playbook-tabs-dryrun.md`)
- Built into a copy in `$TMPDIR`; master sha256 `dfb9496452d0…` before and after (also the ~/Documents copy): untouched.
- New tabs after SOP, in order: Rebuild from zero (129 rows in 19 sections, 34 of them the gap table), Templates (413 rows: 8 files verbatim plus two layouts), Do, Don't and why (50), Composio + 1Password right way (45), Skills, where they live (45), Decisions and why (34, from `notes/decision-evidence.csv`). Glossary slot: `tabs/glossary.json` is built after Rebuild from zero once it exists.
- Director + Conductor: rebuilt by `build_tab.py build_sheet()`; 636 of 636 old cells unchanged, 26 rows added (sections 8, 8a, 8b, split test).
- Queued corrections: 69 guarded cell edits (All connections R150; To do R22, R23; Plan R23, R30; SOP R7; Composio R5, R10, R13, R14, R24, R37, R41, R62, R88, R93, R90; GoHighLevel R25, R26) and 5 appended To do rows (parity-diff addendum L11–L15). Every other cell of every existing tab is unchanged (cell-by-cell compare).
- The copy opens outside openpyxl: zip test ok, 34 XML parts parse, and macOS Quick Look rendered it (first sheet SOP shows the corrected R7 count; throwaway copies with Rebuild from zero, Templates and Decisions and why moved first rendered with wrapped rows). Opening in Excel itself: NOT_PROVEN.

## 6. Split-test token columns (checked 2026-10-01)
- In `~/Alex-Director-splittest-kit/results.csv` and `results2.csv`, `total` = input tokens (cached included) + output tokens for the run's turn, and `uncached` = input − cached + output.
- Checked on three runs against the `turn.completed` usage line of their logs in `~/Alex-Director-splittest-kit/out/`: r1-new-s1 (175,801 in, 147,584 cached, 1,615 out → 177,416 and 29,832), r3-old-s7 (→ 139,473 and 31,313), r1-old-s3 (→ 251,380 and 37,236). All equal the CSV values. `summ.py` prints the same total (in + out).
- The CSVs were logged 2026-09-30 (file times 04:40 and 05:49 local); `SPLIT-TEST.md` 03:41.

## 7. Checks
| # | Check | Result |
|---|---|---|
| 1 | Every row of every new tab has a source, and every source resolves: file exists (lstat only), line range in range, CSV row id exists, quoted text present, workbook tab and row exist, commit exists, URL appears in the research notes with a date | `build_tabs.py check`: 0 problems, 0 warnings (also covers corrections.json and the split-test rows in skills-map.json) |
| 2 | Negative: the checker fails bad input | All 9 planted bad sources fail (missing file, URL not in the notes, URL without a date, `.env` path refused without touching it, CSV row Z99, workbook SOP R999, commit 0000000, quoted text absent, line 9999); a fake `ops_` token fails the secret scan without printing it |
| 3 | No client data, no keys | Client names from `knowledge/clients.md`, foreign emails, Meta account ids, GHL-style location ids, phone numbers and 10 secret patterns: 0 hits |
| 4 | Templates equal their files | Each verbatim section equals its skeleton file line for line; both layouts equal a fresh listing |
| 5 | Sheet names legal in Excel | All 6 new names ≤31 characters, none of `/ \ ? * : [ ]` |
| 6 | Split-test numbers recomputed from the CSVs | v2 23 pass / 0 fail / 1 not scored of 24; old 20 / 3 / 1; median total tokens 167,646 vs 191,397; 8 of 8 vs 7 of 8 situations; adopt rule met |
| 7 | Master workbook untouched until "workbook free" | sha256 unchanged before and after both dry runs |

## 8. For the Director
- **Claims with no source yet:** 17, listed at the end of `notes/playbook-tabs-dryrun.md` (install commands and plan costs, the robot's enabled APIs, Tailscale ACL text, which robot token is where, several live-surface checks).
- **Security, NOT_PROVEN:** `fix-keys-2.md` L9–L10 says the Keychain entry `op-service-account-connectors-sync` holds the read-write token, while the key mover, `gcloud_robot.py` and `orgo_op.py` say read-only, and rebuild-sources found the hub's token equal to the Keychain copy. Rows Rebuild 4.3 and Composio + 1Password §3/§5 flag it.
- **Fresh-clone gap, closed while this play ran:** `skills/intake-triage/` and `skills/verify-before-done/` were untracked in agents-home at ~18:30Z and committed in 135cdda; Rebuild 3.3 and the Skills tab now cite 135cdda and 294913c.
- **Workbook rows still contradicting newer sources (not in the queue, not changed):** SOP R4 ("exactly two connectors"), SOP R8, R24, R26 and AI apps R4 G (Composio routes), Skills R7 (W06), Director + Conductor R138 (V17). STATUS.md's gcloud-key line is stale (lead owns STATUS).
- **Small drift:** the repo's `tools/_card-template.md` lacks the skeleton's `route:` line; `health_check.py`'s docstring says cron, but supervisor runs it (`loop.sh`).
- **Apply:** `python3 work/2026-10-01_setup-playbook/build_tabs.py apply --workbook-free`, run outside the Claude Code sandbox (it writes `~/Backups` and `~/Documents`). It backs up the master, builds into a temp copy, refuses if the master changed meanwhile (the cards hook), then replaces the master and copies it to ~/Documents.

## 9. Fold-in and apply (Director: "workbook free", 2026-10-01 ~18:58Z)
Folded in before the write, each row sourced to the new note:
- **K04 done** (`notes/fix-batch-2.md` §1, agents-home b11d939): All connections R200 (removed) and R304 J; Route power R27 (REMOVED); Tracking access R6 F and R38 D, written as the same edit made first in their source of truth `knowledge/tracking-checklist-access.csv` (2 cells, CRLF kept, 2-line diff); Composio + 1Password open items and the plaintext-file row; two Do, Don't and why rows; G03 and its unsourced line no longer list the meta CLI. App decisions was regenerated by `build_decisions.py` (run unchanged, with its book path, CSV path and ~/Documents copy swapped in memory): only Meta Ads (6 → 5 live routes, CLI gone) and Google Cloud (gcloud CLI now under 1Password routes) changed.
- **Codex plugin root cause** (`notes/rca-codex-plugins.md`): the lesson "a cleanup removes only what the expected-state list marks as a duplicate of a proven route" is a DON'T row on Do, Don't and why, and Rebuild 11.7. The Skills tab row now gives the actor, time and what broke.
- **1Password Environments pop-ups** (`notes/onepassword-one-route.md`): two Never rows and two open items on Composio + 1Password right way (the 4 destinations and the 1password-mcp entries); a DON'T row on Do, Don't and why; Rebuild step 4.7 (the app's Enabled toggle is the only off switch).
- **Live tests** (`notes/live-tests-claude-code-codex.md`): Codex 5 of 7 (T1 by design, T3 refused without a prompt), Claude Code blocked by a signed-out terminal, T7 88 skills with 0 duplicates. Updated: the Claude Code and Codex status cells, Rebuild 2.1, 2.2, 4.3, 11.5, 15.4 and G15, and three Skills rows. 4 unsourced items are now sourced (13 left). No Tests tab.

Apply (`build_tabs.py apply --workbook-free`, outside the sandbox, 14:59 local): first try, no hook conflict.
- Backup: `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1459.xlsx`, sha256 `dfb9496452d0…` (the pre-apply master).
- Master and `~/Documents` copy: sha256 `3ebe6ad36269fee27245622b13fdfe8fb3323acaed68bf4fa8384715524458d7` (equal), 329,764 bytes.
- Read-back: 25 tabs. SOP · Rebuild from zero · Templates · Do, Don't and why · Composio + 1Password right way · Skills, where they live · Decisions and why · Projects · Evidence · Limits · Self-improving loop · Plan · All connections · App decisions · AI apps · GoHighLevel · Composio · To do · Claude app connectors · Tailscale · Route power · Tracking access · Director + Conductor · Tool cards · Skills. Spot reads: All connections R150 K and R200 H, SOP R7 D, Route power R27 L, Tracking access R38 D, To do R54 B, Composio R5 H all carry the new text; Decisions and why starts V13, I15 (CONTRADICTED), V14 (NO EVIDENCE FOUND); Director + Conductor has sections 8, 8a, 8b.
- Also rewritten by the generator: `work/2026-10-01_app-decisions/app-decisions.csv` (sha256 `fbdd38e8…`).
- Nothing committed (not requested). Uncommitted: the workbook, app-decisions.csv, the tracking CSV, build_tab.py, skills-map.json and this play's new files.

## 10. Readbacks for the W03/W06 batch (2026-10-01 ~19:10Z)
- `grep -n -i -w ref ~/.agents/skills/alex-director/references/execution.md`: no match (the file has 91 lines). The Ref docs row that Skills R7 H still mentions is gone from the Director's execution.md.
- The workbook cells that state the old "exactly two connectors" rule as current: SOP R4 B and C, and AI apps R1 A. All connections R3/R4 ("1Password + Composio are the two connectors") stay true under W03, because built-ins are not connectors. Do, Don't and why R16 D and R23 D, and Decisions and why R25, quote the old rule as history.
- Skills R7 (alex-director) and R8 (alex-workflow-conductor) both carry the old fix "replace other copies with a link in ~/.claude/skills", which W06 (approved) replaces with a thin Claude-app edition and no link.

## 11. W03/W06 batch, Glossary, decisions, phone and Claude Code results (applied 15:11 local)
- **W03 wording:** SOP R4 B, C, D now say "Composio + the surface's 1Password route + a named list of built-ins (built-ins are not connectors)", citing shared.md L10 and decision W03; AI apps R1 A reworded the same way (W03 names that row). Newer sources also fixed: SOP R8 D (which robot token is where is NOT_PROVEN, fix-keys-2), SOP R24 (Claude: connector for the app, command first in Claude Code, proof scope per W16), SOP R26 (ChatGPT: only the official directory plugin; Cowork moved under R24), AI apps R4 G (two doors; the op CLI is Claude Code's allowed 1Password route), Skills R7 and R8 (W06 thin pointer, no ~/.claude/skills link; the Ref row is gone from execution.md), Director + Conductor R138 via skills-map.json ("Visible in Codex: yes, from ~/.agents/skills", live T7).
- **Glossary** tab (tabs/glossary.json, 32 rows) after Rebuild from zero, from notes/r5-r6-vocabulary-drift.md §1 (Alex's "tools are what the connector can do": QUALIFIED, with the 4 qualifiers and the plain wording).
- **Decisions and why:** decision-evidence.csv edited with the Director's authorization (K04 note DONE; new D07 Codex restore and SK40-D1 to D5, all PROOF PENDING); a "Decided, proof pending" section follows the act-first rows. notes/codex-restore.md held only its lock line at apply time, so D07 stays pending.
- **Phone tests** (notes/conductor-ui-lane.md, transcripts/claude-mobile/): T1, T2, T4 PASS on Claude and ChatGPT mobile, T7 PASS with gaps. ChatGPT's account has 3 custom cloud skills; the Skills rows that said none were fixed.
- **Claude Code** (notes/live-tests-claude-code-conductor.md): T1–T6 PASS, T7 FAIL (322 skills, 11 repeated names; fix in progress), in the Composio + 1Password, Skills and Rebuild rows (4.3, 17.5, G15).
- **Apply:** backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1511.xlsx` (sha256 `3ebe6ad3…`); master and ~/Documents copy sha256 `da857e6683a2a573e26d7aec25b09420b703a2c9c4530972958200ab993eec9c`; 26 tabs; 17 new edits, every earlier edit "already applied"; App decisions 0 rows changed.
- **Not yet:** tabs/sources-17.json had not appeared, so the 13 unsourced claims stand.

## 12. Director decision and waiting state (2026-10-01 ~19:20Z)
- Director: W06 stands. The Director and Conductor get no `~/.claude/skills` link; their claude.ai thin-pointer upload is their Claude copy (research 4: one delivery path per skill). The Conductor's T7 note (link them) was overruled. Skills R7 and R8 stay as applied in §11; no workbook change.
- `notes/decision-evidence.csv` committed on its own: 9ebedb1 (40 rows, K04 done, D07 and SK40-D1 to D5 proof pending).
- Waiting, nothing in flight: `tabs/sources-17.json` (verdicts for the 13 unsourced claims) had not appeared; the Tests tab waits for the Director's "tests done". Resume: `build_tabs.py check`, fold the verdicts into the tab JSON, `dry-run`, then `apply --workbook-free` outside the sandbox, and commit this play's paths.

## 13. Sources-17 batch: state on resume and one more source (2026-10-01 ~19:35Z)
- Resume check after two restarts: the master and ~/Documents copy were sha256 `247fd787…` (15:22 local). Compared with commit 33e2c96 (`da857e66…`), only the Tool cards tab differed (8 cells), rewritten by the ~/.agents post-commit hook after agents-home b074a83 (15:22:45, cards from the live tests). The sources-17 batch had not been applied. Also new since 33e2c96: agents-home fc064e5 (skills cap: build-ghl-systems back, 2 MuAPI skills retired) and 86752d7 (javar SpyFu step via Composio custom_spyfu; ad-recreator reads the Atlas key from 1Password per run).
- Least privilege, Exa through Composio (`EXA_SEARCH`, $0.007, log_4NW9uIS4dbPE), read 2026-10-01:
  - https://www.1password.dev/get-started/secure-developers: "Follow the principle of least privilege when you create service accounts: give each service account access only to the vaults and Environments it needs, with the minimum permissions required."
  - https://www.1password.dev/service-accounts/security: a service account can read items only in vaults it has READ access to, and create, update or delete items only where it has WRITE access.

## 14. Sources-17 batch applied (15:35 local)
- `notes/sources-17.md` added to RESEARCH in build_tabs.py. All 17 verdicts from `tabs/sources-17.json` applied with their exact wording (7 SOURCED, 9 CORRECTED, 1 NOT_PROVEN: 40 cell edits on 27 rows), each row's source extended with the verdict's builder_source; the 13 remaining unsourced items cleared, so the check reports 0 claims without a source.
- Director decisions (owner rule 7): wrangler per Worker project (Rebuild 2.1, and a scoped exception appended to Projects R24 C), cited to Cloudflare's install page through sources-17 S01. G05 truth: SOP R8 D, All connections R273 G and J and R311 G, the Composio + 1Password Keychain step row and open item, and Rebuild 4.2/4.3/G05 now say the Keychain entry and the hub hold the read-write robot. New Decisions row D08 (least privilege, DEFERRED until testing is done), sourced to 1Password's least-privilege guidance (§13) and onepassword-one-route.md §6.
- Newer than sources-17 and folded in: agents-home ea6c339 (the notes in install_hub.sh and the three wrapper docstrings now say read-write), 86752d7 (no skill opens the .env pipes any more), fc064e5 (SK40-D2 and D3 applied; readback pending).
- Not folded in, for the Director: a8959c7 (a Composio guard hook for spend, client sends and deletes, V13) touches Do, Don't and why ("Change Google Ads budgets…") and Decisions V13; ae2136d (using-superpowers off the keep-list) touches D07 and SK40-D1 ("the same 6 skills").
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1535.xlsx` (sha256 `3b0d1e3e…`, which already held the hook's Tool cards updates from b074a83 and 06e3717); master and ~/Documents copy sha256 `83df0ee92a98a7cceedf91bb00165886911b0875db33838e22c7936fc2a30e38`; 26 tabs; 5 new workbook edits, every earlier one already applied; App decisions 0 rows changed.

## 15. V13 guard, I15 pin and the Superpowers keep-list (applied 15:40 local)
- V13 (agents-home a8959c7, notes/hard-rule-checks.md): Claude Code's guard hook stops Composio spend, client-send and delete calls until Alex types the guard code or names the target, in bypass mode too (three live stops, CG-XJVP, CG-9UGE and CG-847Q, with reads running; 27 unit tests). Folded into the Do, Don't and why budget row, the Composio + 1Password "Always allow" row, Evidence R14 F and To do R48 C (each says Codex is in progress). Decisions V13: DONE (Claude Code), Codex equivalent in progress.
- I15: the Composio plugin is pinned to marketplace tag v0.2.4 (hard-rule-checks §4). Decisions I15: DONE; the Do, Don't and why plugin-hooks row and the Composio + 1Password Claude Code cell and open item now say so.
- ae2136d and codex-restore.md: using-superpowers stays off (policy.txt); the restore turned on 5 Superpowers + 6 compound-engineering skills, the browser and computer-use plugins, and Messages without send (PARTIALLY VERIFIED: running desktop threads need a reload or a new thread). D07 and SK40-D1 say "5 Superpowers + 6 compound-engineering skills, using-superpowers off"; the Skills rows say Superpowers is on again in Claude Code.
- Decisions now: 1 act-first row (V14), 7 decided-not-done, 2 done, 11 qualified, 20 supported.
- build_tabs.py logs a chained correction whose later edit is already applied as "superseded" rather than SKIP (SOP R8 D).
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1540.xlsx` (sha256 `83df0ee9…`); master and ~/Documents copy sha256 `4dae9201a6d6677cce990bacb0b86d182e85d4398c48c0d6941242f160554bd8`; 2 new workbook edits; App decisions 0 rows changed.

## 16. meta-ads-cli renamed meta-ads (agents-home 2c53ed3), applied 15:48 local
- Skills R85 A and C now name meta-ads and ~/.agents/skills/meta-ads; All connections R200 L keeps its dated history and adds "(skill renamed meta-ads 2026-10-01)"; the "Skills, where they live" ChatGPT cloud row says "meta-ads (Composio app route)".
- Tool cards is regenerated by `~/.agents/tools/connectors/cards_to_sheet.py`, now run inside `build_tabs.py`'s build on the same copy, so one guarded write covers it. F13 (Meta Ads) lists meta-ads; F6 (Composio) and F10 (GitHub) only changed their "+N more" skill counts by one.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1548.xlsx`; check 0 problems; App decisions 0 rows changed.
- Master and ~/Documents copy sha256 `c3847ca960c3bf502a49d969180197644a8681774613e6d3ef1507e741235ad6`.

## 17. Tests tab, round 1 (Director: "tests done (round 1)"), applied 16:20 local
- New tab **Tests** after "Decisions and why": 6 sections, 36 rows, columns surface, test, what it proves, result, evidence path, date, what would close it if pending. The evidence path is each row's source: tabs/tests.json names it with the section key `source_col`, `build_tabs.py check` validates it like any source column, and the builder styles it small and gray. Built by the scratchpad generator gen_tests.py; tabs/tests.json is the record, and pending rows are rebuilt from the same evidence files.
- Rows: Codex 7 of 7 PASS (T1 by design: the local card is the Mac route; T3 on the 19:57Z retest, hash only); Claude Code T1–T6 PASS, T7 PENDING (250 skills, 2 repeated names; clears with the thin-pointer uploads, D5, L04 and the 2 stray alex-* links out); Claude phone and ChatGPT phone T1, T2, T4 PASS and T7 PASS with gaps; hard-rule guard 5 PASS (CG-XJVP, CG-9UGE, CG-847Q, reads ran, 27 unit tests) and the fresh headless session PENDING; automations: Dynamite reads PASS (72 of 72 over 2 runs), its prompt update PENDING (fences from its Director), the Payzer Messages check PENDING (its 19:32Z run failed; waits on a Codex plugin reload); not tested, with the reason: Claude Desktop chat, ChatGPT web.
- Added beyond the Director's list, each sourced: the ChatGPT desktop Composio read and write (conductor-ui-lane.md L11–L14, PASS), and two not-tested rows: the Claude Code terminal (signed out) and the Codex guard (in progress, V13).
- Colors: PASS green; PENDING and PASS with gaps yellow; FAIL and NOT TESTED orange. No cell in the other tabs starts with these words (checked), so nothing else changes color.
- Drift fixed before the apply:
  - agents-home 1c10184 (repo-conform 2.2, 15:49 local) moved SKILL.md's guarantees table to references/checks.md and changed the skeleton skills README (descriptions trigger first; body 60 lines / 5,000 characters, cap 200 / 16,000). The check caught it (Templates §3 and §11; Skills-where §5 citing SKILL.md L94). Templates regenerated; 17 Skills-where citations re-anchored with difflib; Skills-where §2 row 1 no longer says the sources differ, and §5 row 4 now gives the trigger-first rule.
  - A content check of every line citation (its cited text when first committed against the text now, 363 citations) found 16 more: 9 pure moves re-anchored (composio.md ×6, google-workspace.md, unify/check.py ×2); composio.md L15–L22 changed (b074a83), so the Composio + 1Password Claude Code row now says `composio execute` works inside the Claude Code sandbox while `search` and `--get-schema` don't (card-fixes.md §4), cited L15–L25; orgo_op.py's docstring grew a line (L2–L16); 4 changed in place and still support their rows (the read-write docstrings and install_hub.sh L4 from ea6c339, and shared.md L16, another play's uncommitted edit); 1 false alarm (a re-used citation string).
  - Rows that restated older live-test results now match the Tests tab: Rebuild from zero 17.5, the Composio + 1Password Claude Code status, Skills-where §4 row 5 and §6 rows 4 and 6 (T7 re-run, the 2 stray links, and the stale "Contradictions" sentence removed, since Skills R7 and Director + Conductor R138 were corrected in §11).
- For the Director, not changed here: Decisions and why §4 row 3 (from decision-evidence.csv) still says the Composio CLI can't run inside the Claude Code sandbox, but the card now says `execute` can. Skills R7 H says Claude Code sees only the older edition; while the 2 stray links exist it sees both, and the cell changes again after the pointer upload. Skills-where §6 rows 4 and 6 describe other items as they were before the skills cap; a refresh from notes/skills-cap.md is a separate job.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1620.xlsx` (sha256 `c3847ca9…`); check 0 problems, 0 warnings, 0 claims without a source; Tool cards regenerated (F6, F8, F9, F14: the skills that mention each card changed with spp-p13b); App decisions 0 rows changed.
- Master and ~/Documents copy sha256 `83359e09ba52b6237ca868d980d29384bf19a68fe2bf39d10f89fbe68c6d0818`; 27 tabs.

## 18. Limits tab: vendor numbers vs house style (Director, after Tests round 1; source notes/skill-size-rca.md), applied 16:24 local
- R9 D now labels "under 500 lines" and "under 5,000 tokens" as vendor numbers and names the pages the RCA read (platform.claude.com agent-skills best-practices and overview, code.claude.com/docs/en/skills, agentskills.io/specification, read 2026-10-01). R9 G labels "60 lines / 5,000 chars" (and the 200 / 16,000 cap) as house style, taken from one benchmark repo's median and 95th percentile.
- R9 E: "~5 KB (~60 lines) typical of the winners" overstated a repo statistic; it now says the repo's median and 95th percentile aren't tied to results (RCA §2). Not in the Director's list: changed because the RCA contradicts the old wording.
- New row R17 (the empty row at the end of the table, so no row number moves): the alex-director and alex-workflow-conductor SKILL.md cap of 12,000 characters, the RCA's derivation from Claude Code's 5,000-token re-attach limit. Ours today: v2.3, Director 88 lines / 6,366 characters, conductor 86 / 6,377 (re-measured on the live files; agents-home 21c9857).
- build_tabs.py: corrections.json gained `fill_rows` (writes a new row into an empty table row, styled like a template row; refused if the row is no longer empty), and the research corpus now includes notes/skill-size-rca.md and skill-size-rca-vendor-guidance.md so their vendor URLs can be cited.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1624.xlsx`; check 0 problems; Limits 12 cells changed, nothing else. Master and ~/Documents copy sha256 `15c16df7c3ad66ed4213675e86e4069db9d650e788641425e7c2924fbd32eaf1`.

## 19. Payzer PASS, T7 after the link removal, W02 at its source (Director, after accepting §17 and §18), applied 16:31 local
- Tests: the Payzer Messages check is PASS. The in-app Computer Use toggle reloaded the plugin servers on Codex's local host (19:55–19:57Z), and the 20:02:29Z run read Messages (find_chats, read_messages) with no errors and no send; the 19:32Z failure came before that (automation-restore.md §9). Section 5's title now says the runs only read and sent nothing, since spp-c7 itself changed app settings.
- Tests: Claude Code T7 stays PENDING. The 2 stray alex-* links were removed at 20:07:53Z after the pointer upload (skills-cap.md open item 0); what clears it now is D5, L04, vendoring Phase 2 and this Mac pulling the new Conductor pointer, then the T7 re-run.
- Decisions and why: W02 corrected at its source, notes/decision-evidence.csv (data row 3): `composio execute` works inside the Claude Code sandbox, `composio search` and `--get-schema` don't, and the card's "run the CLI outside the sandbox" stays the safe default; the note records the correction. Tab rebuilt with `build_tabs.py decisions`. CHANGELOG line added to system/CHANGELOG.md, not committed (the file holds other plays' uncommitted lines).
- Rebuild from zero §18: G15 gives round 1 of the live tests; G30 is PARTLY (the Tests tab exists; pending rows and untested surfaces remain); G31 stays OPEN (done per surface, not per route).
- Held until skills-cap re-runs T7 after the app batch and vendoring Phase 2 (Director): Skills R7 H and Skills-where §6 rows 4 and 6, refreshed together in one pass then.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1631.xlsx`; check 0 problems; Tool cards F10 and F15 regenerated (skills changed by other plays). Master and ~/Documents copy sha256 `92a31be0583555700f948a362303a3306eeac16423fdd6fe90abdd505b9496d9`.

## 20. App batch, Composio's Connect page and the Codex guard (Director, while the gap facts are pending), applied 16:42 local
- (a) notes/app-batch.md, what the Claude app keeps now: 2 connectors (Composio, GitHub Integration) and 2 plugins (PDF Viewer, Desktop Commander); Ref, Foreplay, GHL OAuth Gateway, Google Calendar and Notion removed; 12 plugins removed, Qt Development Skills among them (W05; Qt docs stays through Composio). Written into AI apps R9 B, C, D and G (the row that says what the Claude app keeps), Claude app connectors R29, R45, R51, R76, R81, R82 plus a note row R84 for the 12 removed plugins, To do R6 and R50–R53 (Done) and R54 (now Security: revoke the Ref key), and in my tabs: Composio + 1Password §2 row 2, Skills-where §1 row 4 and §5 row 6, Rebuild 11.3 (ChatGPT V05 saved and read back; claude.ai V05 waits on Alex's Save click), and the T7 close conditions on the Tests tab (L04 done).
- D4 and D5 in notes/decision-evidence.csv: D4's note says the 6 uploads are backed up and switched off (permanent delete is Alex's click; the Mac's sync copy doesn't show it yet). D5's decision is amended to 10 skills: chrome-browser and built-in-browser stay on because Alex said browser and computer use are "extremely important" (mission graph, codex-plugins-restore row) and switching off 2 of about 78 gains almost nothing (Director). Its note gives the app batch result: 5 stay off, docs turned itself back on, and 4 desktop built-ins wait for the Conductor (spp-c9). build_tabs.py's Decisions source cell now also cites ~/Alex-Director paths named in other_sources.
- (b) notes/composio-connect-agents.md: a DON'T row in Do, Don't and why §2 for Composio's "Connect my agent" page (same routes as ours; never the CLI one-liner without COMPOSIO_INSTALL_PLUGINS=0 and COMPOSIO_INSTALL_SHELL=none; don't click the Claude row's Add; remove the custom connector first if an official Claude listing appears).
- (c) The Codex guard (agents-home 26ee11c, ~/.codex/hooks.json): installed and inactive until Alex trusts it (0 trusted_hash entries in config.toml at 20:33Z, count only); release path off (workbook-updates.md L9). Updated: Tests (Codex guard row, close condition: Alex's trust, then codex-guard.md §5's 14-line test), Decisions V13 note, Composio + 1Password §4 row 11, Do/Don't §7 row 6, Evidence R14 F and To do R48 C (chained replaces). Two new To do rows for Alex: R55 trust the Codex guard, R56 save or discard the claude.ai V05 instructions.
- Not changed, flagged: Do/Don't §7 row 3 says Alex denied agents the browser on claude.ai; app-batch.md's boundary check says the 10:43:18Z event was the built-in Browser pane refusing claude.ai and Alex never wrote a denial in chat. The mission header line is the Director's.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1642.xlsx`; check 0 problems; 33 corrections applied (AI apps 4, To do 19 + 2 rows, Claude app connectors 6 + 1 row, Evidence 1). Master and ~/Documents copy sha256 `f4be5756d6345177164aeda8f44957c786eec73998ba7138c647ffdc85e560ef`.

## 21. Three small fixes: the denial row, D5's sources, and spp-c9 (Director, after accepting §20)
- Check, 2026-10-01 about 20:46Z, read-only: `claude --version` prints 2.1.287 (Claude Code); `claude auth status` reports loggedIn true, authMethod claude.ai (only those two fields were read; no email or token printed). notes/spp-c9-d5-remainder.md §3 has the update time: 2.1.287 installed 20:38:05Z, and `claude mcp list` shows the claude.ai Composio and Claude Docs connectors.
- Do, Don't and why §7 row 3: a tool's refusal is not Alex's no. The built-in browser pane refused claude.ai at 10:43Z; Alex never denied anything in chat; claude.ai work goes through Claude in Chrome (the logged-in route in ~/.agents/instructions/claude.md L4), and the app batch ran there after his yes (notes/app-batch.md, approval and boundary-check lines). The old sources (parity-diff W09, L03, parity-diff.md §4, fix-k01-w20.md L201) backed the old example and are dropped; shared.md L5 stays for the rule.
- Decisions D5 (CSV): "about 78" now cites notes/skills-cap.md "Expected Claude Code desktop count" (18 + 16 + 17 + 15 + 12 = 78; the Director's line numbers 51–53 had moved to 80–82 as the note grew, so the cite is a quote). The decision is now 9 skills: docs stays on too (it runs the default-on Claude Docs feature, help center article 16923645, has no switch of its own, and the Artifact tool's documents use it). The note says the 4 desktop built-ins are optional clicks for Alex in the Claude desktop app, because computer use can't reach it. build_tabs.py now keeps a line or quoted locator after a path in a decision's other_sources, so D4 and D5 also cite r4's "Steps in order" and "Risks" sections.
- AI apps R9 B: Claude Docs added as a first-party, system-managed connector (the terminal CLI lists it; leave it on).
- Tests: Claude Code T7's close condition says D5 is done as far as agents can go. The terminal rows (headless T1–T7, guard headless) now wait on a run, not on Alex's sign-in.
- Also fixed: Rebuild 2.2 told you to run `composio setup --target auto`, which on a Mac with Codex re-adds the old Codex GitHub plugin v0.2.3 and its hooks (composio-connect-agents.md §4); it now says `composio login` only, and that the terminal was signed in again. Rebuild 2.1 notes 2.1.287. Composio + 1Password §2 row 1 no longer asks Alex to sign the terminal in.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1648.xlsx`; check 0 problems; 1 correction (AI apps R9 B). Master and ~/Documents copy sha256 `fdb2ab34f70a3938a39226e8655bc8f2756793a406b0eb19c957bee667712d1d`.

## 22. GitHub Integration stays, and the vendoring Limits row (Director, after accepting §21), applied 16:51 local
- G12 decision recorded for the gap batch: a separate tab "Composio custom routes" right after the Composio tab; the Composio tab itself is not written (one writer per tab).
- (a) spp-c10: AI apps R9 C now says GitHub Integration is a named built-in that stays: it attaches repo files to chats and Project knowledge, read-only, while Composio github does the API actions (help center article 10167454; workbook-updates.md L18–L22). R9 D and the Composio + 1Password Claude app row say the same.
- (b) spp-p16a decision 3: a new Limits row R18, "Codex active skills after vendoring": 62 active (39 triggerable + 23 dependency-only), 0 repeated names, 0 descriptions cut, and the measured cost: on 3 of 10 trigger prompts an extra vendored skill loaded next to the expected one and never displaced it (notes/skills-vendoring.md "Seen, for weighing 62 against about 40"; workbook-updates.md L17). Status in gray: above the 40 cap by decision.
- build_tabs.py: corrections.json gained insert_rows (guarded by an anchor, "How to use" in A18, and by its marker, so it runs once). How to use, Who checks and Confidence moved to R19–R21; the one citation of the old R19 (Skills, where they live §2 row 1) now says R20. A second dry run after the apply reports the row as already there.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1651.xlsx`; check 0 problems; 3 corrections (AI apps R9 C and D, the Limits insert). Master and ~/Documents copy sha256 `ce58ab949ec5201401ea51ed6e0dcba5f7dafd0409c8e99da012c2f2464f3f18`.

## 23. Replication gaps closed from spp-p20a's gap facts (Director), applied 17:01 local
- Sources: tabs/gap-facts/G01, G02, G05, G06, G12, G15, G16, G21, G22, G23 (.json) and notes/gap-facts.md (spp-p20a; landed about 20:52Z). build_tabs.py's research corpus now includes notes/gap-facts*.md, so their dated URLs pass the URL rule.
- New tabs (31 tabs in all): Student starter kit after Templates (G02: the 4 private repos and 11 access and clone steps); 1Password item catalog after Composio + 1Password right way (G06: 30 vault items by name and ID, 17 hub secrets compared by hash, the 2 keys saved, 8 files with hard-coded IDs); Composio custom routes as its own tab right after Composio (G12, Director: one writer per tab); AI app settings right after AI apps (G16: sanitized target settings for Claude Code and Codex). Each ends with the gap file's NOT_PROVEN items. build_tabs.py: a tab marked "standalone" sits after its own insert_after instead of after the previous tab.
- Rebuild from zero: a Start-here section first (G01: partner or student, and how access is granted for each service); the rewrites of G05 (4.1 to 4.3, 8.1) and the order fixes of G21 (8.2, 17.1, 17.2, new 10.7), G22 (new 8.0, 8.4, 8.7) and G23 (the checks of 28 steps), each tagged "retest Gxx" in its closes-gap column and sourced to its gap file; overlaps resolved per cell (4.2 from G05, 8.1's check from G23, 8.2 from G21); and section 19, the 24 gaps of the second replication check with status (10 FILLED with their NOT_PROVEN items, G03 PARTLY, the rest OPEN, outside spp-p20a). The retest's G-numbers are its own, so they carry "retest" wherever they sit next to the first check's G01 to G34.
- The gap files cite Rebuild rows by the 189-row layout they read. The new rows moved most of them, so the generator (scratchpad gen_gapbatch.py) checked the old layout against the master (168 keyed rows) and re-pointed all 72 Rebuild citations by step label; a read-back of the built book found 0 label mismatches and 0 citations on a blank or header row.
- G15 (what each AI keeps) went into the AI apps tab through corrections: rows 4 (Claude Code) and 5 (Codex) now name their built-ins in "only here"; row 5's why lists what Codex removes and keeps the old count's breakdown; row 9 adds Anthropic's own built-ins; row 10 says Claude Desktop keeps nothing of its own; row 11 (ChatGPT connectors) is RETIRED in ChatGPT; and a new row 14 for ChatGPT names its built-ins (OpenAI's own apps) and the proposed 1Password plugin removal. The G15 file's "still to remove" items that the app batch already removed were not copied.
- build_tabs.py fix: a replace whose new text contains its old text counted as not done, so a rebuild would have applied it twice (AI apps R9 D in the first dry run). It now counts as done once the new text is in the cell; the next dry run applied nothing twice.
- Warnings: 40 "looks like a 1Password item id", all in the 1Password item catalog and Composio custom routes. Item IDs are identifiers, not secrets, and spp-p20a's own validation expected them; the secret and client-name scans found 0.
- Not committed here: tabs/gap-facts/ and notes/gap-facts*.md belong to spp-p20a and are still untracked, though the new tabs cite them.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1701.xlsx`; check 0 problems; 8 corrections (AI apps 6 cells and 1 row). A second dry run applies nothing. Master and ~/Documents copy sha256 `8ad85306c5508c7f49ad9b4d086a6ee0e3b164d328342a17cb5e7ba5ce67abfe`.

## 24. Director's answers after eacf010: item IDs stay, gap sources committed, done items, Skills refresh, applied 17:06 local
- (1) The 40 "looks like a 1Password item id" warnings are marked expected: the 1Password item catalog and Composio custom routes carry `expected_warnings` with the reason (the scripts and hub fetch by ID; identifiers, not secrets). build_tabs.py counts expected warnings separately; the check now shows 0 warnings and lists the 40 as expected.
- (2) spp-p20a's sources committed on their own paths only: tabs/gap-facts/ and notes/gap-facts*.md (f9ab91c).
- (3) Done items: To do R56 (claude.ai V05 saved by Alex, read back as a match: 1,246 characters, sha256 1fa79bcd…, app-batch.md), R55 (Codex hooks trusted 20:45:39Z, Run H PASS, codex-guard.md §8) and R54 (Ref key revoked per Alex, owner statement, not verified) are Done; Claude app connectors R76 and AI apps R9 G say the same. The Codex guard is now PASS on the Tests tab (Run H, moved into section 4), and Decisions V13, Composio + 1Password, Do/Don't, Evidence R14 and To do R48 say trusted and proven. K02 (the Google deletes) is left for spp-p27a's verification note: no file records it yet.
- (4) The held cells are refreshed from skills-cap.md "T7 final run on all three surfaces": Skills R7 H and R8 H (the conductor row had the same stale sentence), Skills-where §6 rows 4 and 6, and the Tests rows (Codex T7: 62 skills, 0 repeats; Claude Code T7: PASS on the 2.1.287 terminal, 67 skills, 0 repeats; desktop PENDING until the next Claude restart; the terminal's headless row now covers T1–T6).
- gen_gapbatch.py now builds from eacf010^ (the layout before the gap batch), so it can be re-run.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1706.xlsx`; check 0 problems, 0 warnings (40 expected); 17 corrections; a second dry run applies nothing. Master and ~/Documents copy sha256 `0801635d515654f99610f9282ad83d0a5b4560ef74bfec1312ca16bc5e8d6aed`.

## 25. ChatGPT row 14: the 1Password plugin removed; Finances and Superpowers named as kept (Director)
- Source for the removal: notes/app-batch.md "Item 9 (add-on): ChatGPT 1Password plugin removed" (Alex typed "yes remove" at 21:04:31Z; uninstalled about 21:06:54Z; a fresh load shows Composio, Finances and Superpowers, Composio still connected as alex@) and workbook-updates.md L32.
- Finances, read for this row: https://help.openai.com/en/articles/20001222-finances-in-chatgpt (read 2026-10-01 through Composio Exa EXA_GET_CONTENTS_ACTION, log_4KSrbflq52q0; the page says "Updated: 4 days ago"). It connects U.S. financial accounts through Plaid so ChatGPT can review spending, balances, subscriptions and holdings, and it "cannot take financial actions": no moving money, paying bills, changing account settings or making trades. The plugin list shows it with "Allow read-only tools" (app-batch.md item 9).
- Superpowers stays on the account for the remote cloud Codex environment, which can't see the vendored copies; its 15 skills are switched off on this Mac (notes/skills-vendoring.md "Decision 1, the dependency check").
- NOT_PROVEN: Codex still holds a cached copy of the removed 1Password plugin (~/.codex/plugins/cache/openai-curated-remote/1password, its one skill already off) until Codex's next plugin sync; the parity re-check verifies it (app-batch.md item 9).
- Applied with K02 (below), 17:12 local: AI apps R14 B (the plugin list after a fresh load), D (Finances and Superpowers kept, each with its reason) and G (the removal, and the NOT_PROVEN cached copy in Codex); R5 G (the account-level 1Password plugin is already removed); Composio + 1Password §2 row 6 and Do/Don't §1 row 5 now say the plugin was removed; Rebuild §19 G15 drops its old NOT_PROVEN.

## 26. K02 verified (spp-p27a, notes/k02-verify.md), applied 17:12 local
- Alex removed the dead delegation entry for client 114216599725767886067 at 20:51:11Z (Google Admin audit log, read back through the robot). The old account can't get a token (invalid_grant, twice), Google lists 0 keys for it, the live robot still works, and the Mac copy of the old key moved to ~/Backups/google-workspace-admin-retired-2026-10-01/.
- Updated: To do R9 (Done) and R46, Plan C18, Route power M13, All connections G177, G178, G180, G182 and G183 (the stale cells that k02-verify.md §4 lists). Still open and named: the hub's backup of the dead key (Alex's call) and L01's Claude Desktop entry that points at the moved folder (parked until a Claude restart).
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1712.xlsx`; check 0 problems, 0 warnings (40 expected); 15 corrections; a second dry run applies nothing. Master and ~/Documents copy sha256 `e045ff81d1476c70d4ab6d53aa62d6b1b8faa7d4cade128aa585ffd5c3952a5d`.

## 27. The hub's dead-key backup is ours to retire (Director), applied 17:14 local
- Correction to §26: the hub's backup of the dead workspace-admin key (/opt/mcp-hub/backups/2026-10-01_wsadmin-retired/wsadmin.json) is not Alex's call. It is our own dead credential, not client data, so the final cleanup play (housekeeping-final in the mission graph) retires it under the standing yes (~/.agents/instructions/shared.md L3). To do R9 C and All connections G177, G178, G180, G182 and G183 now say so; when that play's note lands, the cells are updated from it.
- notes/k02-verify.md committed by path only (4cf356d). Standing rule from the Director: when a play is finished and these tabs cite its note, commit that note by path only.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1714.xlsx`; check 0 problems; 6 corrections; a second dry run applies nothing. Master and ~/Documents copy sha256 `f6a9636bce3ac65d186db27a1d4cdab4a60702ecf8a6ddb193ba4b7706692c74`.

## 28. The combined gap apply: spp-p20b, p20c, p20d, the interim retest, spp-c13 and spp-p28a, applied 18:02 local
- Generator: scratchpad gen_gapbatch3.py rebuilds every touched tab from 060a77f, so it can be rerun. Placement as the Director set it, one writer per tab:
  - Rebuild from zero: G03 (0.4, 0.4a, 3.0, 3.1b, sections 3a-3b), G04 (2.0, sections 2a-2d), G07 (5.2, 5.3, sections 5a-5e), G08 pointers (5.1, 7.4, 7.5), G09 (6.0-6.6), G10 and G11 (8.0a-8.0e, 8.2, 10.3a-10.3c, sections 8a-8e), G13 and G14 (10.1-10.5), G17-G20 pointers (11.3, 14.4, 15.1, 15.2, 17.3), the G21 addendum (10.7, sections 10a-10c), N01 (step 4.5a), N02 (5.1 checks with the storage read of All connections R150), the Start-here student bar (G02/G03) and 11.5 (no Codex 1Password MCP). Gap lists 18 and 19 updated, with N01 and N02 added.
  - New tabs: Tailscale policy (G09), Tune-up (G20), Director home rebuild (G19), Hermes and Javar rebuild (G24), GoHighLevel rebuild (G13, G14; the 5 Worker secrets with no 1Password copy are a named rebuild risk for Alex after this mission; the Marketplace workspace, the gateway's .dev.vars and ~/.config/ghl-command-universal/connection-password are handed to the final cleanup play).
  - Composio custom routes: the G12 addendum (header names, x-project-id lookup, the builder's DCR body) as sections 5-7; Not proven is section 8. Composio + 1Password: G08 as sections 6-10. Templates: G17 as section 12. Skills, where they live: G18 sections 7-10; the Skills tab's 14 rows through corrections.
  - G16: the terminal Codex CLI is 0.160.0 and ran gpt-6.1-sol (system/run-log.md L132): AI app settings Model row, Rebuild 2.1 and 2b, Composio + 1Password section 2, gap list 19.
  - G15 (Codex's 1Password MCP removed, spp-c11): All connections R3, AI apps R5, AI app settings, Composio + 1Password sections 2 and 5, Rebuild 11.5; App decisions drops it when regenerated. Cursor's entry (removed 21:19:53Z, spp-p24d) went the same way in All connections R4.
  - spp-p28a (notes/onepassword-vault-scope.md; workbook-updates.md L71): the rule "every secret an AI needs lives in Connectors" (Composio + 1Password section 1, Do/Don't section 1), All connections R6 G (the note numbers this finding F6, not F5), Composio R2 and the cells that called _1password empty (To do R22, Plan R23, Do/Don't, Composio + 1Password section 4), 2 catalog items, To do R57-R59 (Alex's moves A1-A7, the agent's repoint B1, finding F1), and the F4 correction to Codex's 1Password MCP reason.
  - D08 (CSV, logged in system/CHANGELOG.md): the robot's three best-practice gaps from notes/gap-facts-apps.md L219-L224. Tests: the Payzer automation was paused on Alex's word after its passing run.
- Citations: every "workbook Rebuild from zero R<n>" (110) and "workbook Composio + 1Password right way R<n>" (7) was re-pointed by step label and section to the new layout, including the base tabs' own citations, which the first version of the generator had missed. A check script confirmed each lands on a step row.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1802.xlsx`; check 0 problems, 0 warnings (49 expected item IDs); 81 corrections and 3 appended rows; App decisions changed only in its 1Password row; a second dry run applies nothing. 36 tabs. Master and ~/Documents copy sha256 `9e8b20c7b0c7e68e05457d13d4c9003e16f097454eae06ca4d258d16e491ea0f`.
- Not done here: G15's remaining contradictions from the interim retest (items 2, 3 and 5: Codex's Orgo MCP and docs helpers, the Claude app plugins, the expected-state list; item 4, ChatGPT's plugin, was fixed in dc8ecce), left for the final retest; the hub's dead-key backup (final cleanup play); desktop T7 (next Claude restart).

## 29. G15 items 2, 3 and 5 of the interim retest closed (Director), applied 18:12 local
- Item 2, Codex's Orgo MCP and docs helpers: All connections R86-R88 and R210 now say removed (Alex's 12:47 EDT cleanup, rca-codex-plugins.md L91-L98; kept off by D07, codex-restore.md L21; W04 and K05). A names-only re-read of ~/.codex/config.toml found only node_repl under [mcp_servers]. GoHighLevel R2 I notes the re-read. App decisions dropped its Docs helper row and R210 from Orgo when regenerated.
- Item 3, Claude app plugins: All connections R22 (Browser Use) and R220 (Qt docs plugin) now say removed in the app batch (app-batch.md §3), Composio R77 and Plan R17 no longer call the Qt plugin Alex's call, and AI apps R9's verdict names what the app keeps (Composio for apps, plus GitHub Integration, Claude Docs and 2 Mac plugins). App decisions dropped its Browser Use row and R220 from Qt docs.
- Item 5, the expected-state list: step 11.7, the Glossary term (and its one-home row) and Do/Don't's cleanup row now point at the App decisions tab (proposals, checked by hand as its row 2 says) and the AI apps tab (what each AI keeps), both in the workbook. notes/expected-state.csv is named as a dated read-only extract (spp-p1a, from the 11:51 file), not a list to act on. This is a choice of where the rule points; building the single generated list that r5-r6-vocabulary-drift.md step 1 proposes would be a separate build.
- Gap list 19's G15 row names all three. Cell side: gen_corrections.py section 21; tab side: scratchpad gen_g15.py (idempotent).
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_1812.xlsx`; check 0 problems, 0 warnings (49 expected); 41 corrections; App decisions changed only as intended (Browser Use and Docs helper rows gone, Orgo and Qt docs rows shorter); a second dry run applies nothing. Master and ~/Documents copy sha256 `f4795e37f781e55457618d6eb31f42a2e58c873a70e2b51f62aa3b0beda93682`, 36 tabs.
- Also queued for the final cleanup play (workbook-updates.md, last line): redact client names from repo files a student could see, before the push and before student access; forward redaction, no history rewrite.

## 30. Batch 4, staged (not applied; the Director says when), 2026-10-02
- Generator: scratchpad gen_batch4.py rebuilds the touched tabs from 86d019f on every run; the cell side is gen_corrections.py section 22; decisions D09-D14 are new rows in notes/decision-evidence.csv. Row citations ("workbook <Tab> R<n>") are re-pointed by row identity, and the addenda's Rebuild citations by step label in the layout each one read (spp-c13: 060a77f, spp-c14: 86d019f).
- In it:
  - spp-c14: G05 (Composio + 1Password sections 11-12; Start-here row, 4.1, 4.2), G12 (Composio custom routes section 6 and its Not proven), G14 (GoHighLevel rebuild, Builder 2a-2b; 10.3), G18 (Skills, where they live, section 10), G21 (Rebuild 10a-10c).
  - Stale card text after ~/.agents 7f35eeb: the 6 quoted problems the check found (4 tab cells, 2 correction sources) and 15 line citations whose lines moved, each re-pointed to the new card text or dropped with its claim (the card no longer says that `composio dev` needs a developer project, or that OAuth for Meta would need our own app). Rebuild 11.1 and 13.1, the Templates tool-card row and SOP R24 now say what the new cards say (search and --get-schema run outside the sandbox; cards have a logins line; 14 cards).
  - spp-p25a: Do/Don't rows Name the login and Per-app index, the Spend guard and Connect-my-agent rows extended, Rebuild 12.5, the Limits row (inserted before How to use), decisions D10-D12.
  - spp-p34a: Skills-where r61, r68 and r81, two Skills rows (appended at the end: an insert would shift the rows that earlier corrections address by number), Director home step 0, step 5b, section 3 and its Blank mission graph row.
  - spp-p31a: Composio R2, To do R22, R59 and Plan R23, the Composio + 1Password and Do/Don't rows about the _1password toolkit, the catalog item (archived), decision D13.
  - Director STOP-RULE (2026-10-02) and its correction: Do/Don't row "Other apps' private folders" and decision D09 (the trigger is op, per the TCC log; Don't Allow is cached and harmless; no Full Disk Access). Exa read of anthropics/claude-code issues 36675 and 87453 through Composio, 2026-10-02 (log_OMOrQLE8QUrS): https://github.com/anthropics/claude-code/issues/36675 (2026-03-20, read 2026-10-02) and https://github.com/anthropics/claude-code/issues/87453 (2026-08-17, read 2026-10-02). build_tabs.py now refuses a cited path under ~/Library/Containers or ~/Library/Group Containers without touching it.
  - Desktop T7 after the restart (PASS, 83 skills): Tests, Skills-where, Skills R7-R8, gap lists 18 and 19. L01 (spp-c12 §5): Alex's 2 trash clicks in Claude Desktop Settings -> Developer replace the retire script and the plugin trim (Composio + 1Password, AI app settings, catalog, Tests).
  - spp-p32a: students get the student edition only (Start-here GitHub row, 0.5 with the regenerate note, 3.0, Student starter kit intro and section 2), decision D14, and the build_tabs.py hook (student_edition.py build, then check, after every apply; a failure fails the apply). The old redaction line in workbook-updates.md is marked superseded.
  - The final retest's non-blocking notes 3 (SOP R25), 5 (gap list 18: G08, G09, G19, G26, G33), 6 (Skills-where Superpowers line and cross-references, All connections R312, Templates 12) and 7 (2.2 without wrangler whoami, 1.5).
- Check: 0 problems, 0 warnings (49 expected). Dry run: every intended edit lands; App decisions unchanged; Tool cards picks up 4 skill-mention cells from the live cards.
- Added after the Director's review (still staged):
  - spp-p33a (~/.agents 79626ca, notes/fresh-vault-fixes.md): items found by exact title, so the ID-edit rows say nothing needs editing (step 4.5a, catalog section 4 and its last row, the Orgo and Tailscale catalog rows; the Tailscale item is now titled 'Tailscale auth key'); steps 2.1, 2.2, 4.6, 5.1, 6.2, 7.7, 8.1, 3.5 and 13.2; section 10a's composio_project row and a composio_item row; Composio custom routes' newcomer row and REST row (the project ID from --project, COMPOSIO_PROJECT_ID, then the CLI cache); the orgo_op.py and plaintext-keys rows; decisions D06 (note) and D15; gap list 19 N01 updated and N03 added.
  - spp-p30a (Firecrawl): All connections 2 new rows (the Composio login and the CLI; the hosted MCP's row is left out because CG-KH45 deleted it), Route power 2 rows (the second REMOVED), Composio R19, To do R22 and Plan R23, Skills R49, a note on 4 AI apps rows, Rebuild 7.10, the catalog item, decision D16. App decisions then gets a Firecrawl row by itself.
  - Retest note 8 (the Director's read of ~/.codex/config.toml [plugins]): All connections R53, R58, R61-R63 and R65 off, R64 (remote Superpowers) account-level with its skills off here.
  - Retest note 4: Rebuild section 0a lists the files that name alex@increaseroas.com, with the line numbers and which ones a newcomer changes; step 0.5 points there.
  - 49 line citations into scripts that 79626ca and 7f35eeb moved, re-pointed (pure moves by the drift scan's line map; partly changed ones checked by hand or switched to the file's docstring).
- Waiting: the Conductor's spp-c15 (the 3 ChatGPT skills) and the Director's go.
- Not in it: the Director + Conductor tab's v2.1 lines (its own generator); N01's last piece (where a newcomer makes the Composio user API key).

## 31. N01's last piece: where the Composio user API key comes from (sources, staged with batch 4)
- The Director's Exa run (2026-10-02) named the sources; I re-read them through Composio Exa (EXA_GET_CONTENTS_ACTION, log_PMi9BNS-ivcT, 2026-10-02):
  - https://github.com/ComposioHQ/composio/pull/3132 (merged 2026-04-08, read 2026-10-02): "Adds a new `composio login --user-api-key` flow for direct login without the browser/session-key path"; `--org` picks the default organization, and the direct login "writes the expected user config values".
  - https://docs.composio.dev/reference/authenticating-to-composio (read 2026-10-02): three kinds of dashboard key: a project API key (header x-api-key, from composio.dev > Settings > Project Settings > API Keys), an organization API key (x-org-api-key) and a scoped project API key (x-api-key).
  - https://docs.composio.dev/reference/v3/authentication (read 2026-10-02): the same keys and headers.
  - https://docs.composio.dev/reference/authenticating-to-composio/project-api-key-permissions (read 2026-10-02): scoped keys are made under Platform > the project > Settings > API Keys > Create API Key.
  - github.com/ComposioHQ/composio docs/content/docs/cli.mdx was the Director's other source; the cached copy Exa returned didn't show the login passage, so the tabs cite the PR instead.
- None of these pages issues a user key (x-user-api-key): that key is the one composio login writes to ~/.composio/user_data.json (gap-facts-c13 §2; the composio card). Where a newcomer gets a user key for --user-api-key, and which route created today's 'Composio — user API key' item, are NOT_PROVEN.

## 32. Batch 4 applied (the Director's go), 2026-10-01 21:49 local
- Folded in last: spp-c15 (the 3 ChatGPT skills homed in ~/.agents/skills, agents-home e7916f1): 3 Skills rows (appended at the end), Skills-where's homes row, the ChatGPT state row, the remember-to-re-upload row, the Codex counts, the Not proven row, and sections 10-11 from the updated G18 addendum (homes, then ChatGPT's own record), Not proven now section 12; gap list 19's G18 row.
- Also folded in, because the staged text would otherwise be wrong: spp-p35a's housekeeping results (notes/housekeeping-final-a.md): the firecrawl skill was moved to ~/Backups (Skills R49), and the 3 items handed to the final cleanup are done (GoHighLevel rebuild: the Marketplace workspace is a private repo, the .dev.vars values went to a new Connectors item, the connection-password copy matched 1Password); the new item is in the catalog.
- Apply: backup `~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_2149.xlsx`; check 0 problems, 0 warnings (48 expected item IDs); 82 corrections, appends and the Limits insert; a second dry run applies nothing. Master and ~/Documents copy sha256 `3acd43136f306306c8d5f23e23a4979c6ad59e2d4cd33275071e7681d7921349`, 36 tabs.
- The apply's new hook ran outside the sandbox: student_edition.py build PASS, then check PASS (0 findings, 94 vault secrets compared by hash).

## 33. Batch 5 applied (the Director's go), 2026-10-01 23:29 local
- Folded in: spp-p35a (local key copies retired, 2 Mac-only repos, Firecrawl route), spp-p36a/b (Hermes skills' routes, one re-upload), spp-p37a (config.toml: 139 off-switches, no features.skills), spp-c16 (ChatGPT web T1, T2, T4 PASS, T7 PASS with gaps), spp-p38a/b (terminal guard check PASS; T1 to T6 headless PASS), spp-p39a (Modal), spp-p41a (app-rules lookup), the Director's Limits row (hosted app-rules description, new Limits R20), spp-c17 (ChatGPT Always ask; per-write approval FAIL by design; a DO row), spp-p40a (Hugging Face; the hosted-MCP duplicate stays listed until CG-QWAA), spp-p42a (tool-card v1.4), spp-p32b (student edition G03 and G19), spp-p44a (N05, N06, N02 code fixes) and spp-p43a's first line (catalog: firecrawl_op.py by title; section 19 N01). The 7.10 line waits for spp-p43a's live proof.
- The Director's decisions on spp-p42a: (1) Composio + 1Password right way, section 3 rows 2 to 4: the read-write robot, op item create from a template on stdin, hash readback, pbcopy </dev/null, no Touch ID; (2) notes/macos-app-data-prompt.md decision 5 and Decisions D09: setting OP_BIOMETRIC_UNLOCK_ENABLED is fine per 1Password's docs, it isn't the fix for the macOS prompt; (3) the card index line is 70 characters: card template, Limits R19, Rebuild 12.5 and 13.1, the Templates tool-card row (builder string too).
- spp-c4d workbook fixes: G17 (Templates 12c step 7, partners rewrite line 1), G23 (the Orgo check moved from 2.2 to 4.6), N02 (5.1 and All connections R150 name gs://cloud-samples-data/vision/label/wakeupcat.jpg), N07 (the Orgo API key in 4.5a), section 0a (DEFAULT_COMPANY_ID, BASE, DOMAIN, INTERNAL and TO; students change, partners keep). N06: 8.0d is unchanged because spp-p44a fixed it in code (rebuild_hub.py --exit-node); 8.2 says how. Section 19 records the final re-run per gap and adds N04 to N07.
- Kept as each tool writes them: App decisions comes from build_decisions.py (Modal shows "not in Route power" because the generator joins Route power only on Composio IDs; Route power R70 lists it as ONLY ROUTE), and Tool cards from cards_to_sheet.py (16 cards).
- Builder side: tabs regenerated from HEAD by a scratch generator (gen_batch5.py); corrections.json section 24 (16 edits, 13 appends, 1 Limits insert); 14 moved code-line citations re-pointed (agents-home 4fe35e6 and 203a8dd); 110 Rebuild row citations re-pointed after the new rows; the Director + Conductor research-routes row (skills-map.json part 20) follows execution.md L63-L83; sources-17.json S11 and S15 (builder source only); the research corpus adds the 9 play notes that hold batch 5's URLs.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-01_2329.xlsx; check 0 problems, 0 warnings (51 expected item IDs); 30 corrections; readback 20 of 20 spot cells; a second dry run applies nothing. Master and ~/Documents copy sha256 d68f61c8e7f61d2bcbfd3630cc538fda155b0ea0c3ad6c8aed62a4d7298b6ea9, 36 tabs.
- Student edition: NOT rebuilt. The apply's hook waited 7 minutes on its first `op item list` (every op call from Claude Code has hung since 23:01 local: a macOS App Data request is probably waiting on Alex's screen, notes/firecrawl-op-title.md §5), so I stopped that op call; the hook reported "1Password read failed" and kept the previous edition (built 2026-10-02 03:02Z from workbook 3acd4313 and agents-home 3a970c2, so without batch 5, 4fe35e6 or 10b9aa9). Once Alex presses Don't Allow on that prompt, run outside the sandbox: `python3 work/2026-10-01_setup-playbook/scripts/student_edition.py build && python3 work/2026-10-01_setup-playbook/scripts/student_edition.py check` (both must PASS before the student re-run).

## 34. Batch 6 applied (the Director's dispatch), 2026-10-02 15:15 local
- Applied, each block's own condition met today (workbook-updates.md L263-L293):
  - spp-p43a: Rebuild 7.10's check gets the `firecrawl_op.py --status` line (live proof passed 2026-10-02T17:40:05Z) and section 19's N01 says so.
  - Hermes (mha-r1 + mha-a1): Decisions D20 (D-1 strict, PROOF PENDING: Javante's other .env literals and the MacBook's .op.env are still open) and D21 (Javante's gateway keys through secrets.command, DONE: live proof in notes/javante-fix-f1.md); the Hermes and Javar rebuild tab's top note, as a new section 0 with its sources.
  - spp-c18: Decisions D22 (each hub route gets its own token before its login is shared; PROOF PENDING).
  - spp-c4e: step 0.5's wording (students swap, partners keep and skip the marked steps); 57 "Partner: skip" marks: 55 rows that create or configure what Alex's shared accounts already have (1.1-1.7, 1.9, 4.1, 4.5a, 5.1-5.3, 5.2a-5.2d, 5.3a, 6.1a-6.4, 7.1-7.6, 7.9, 7.11, 8.0-8.2 with the Tailscale join, 8.5, 9.1, 10.1-10.4 with 10.3a-10.3c, 10.7, 17.1, 17.3) plus 2 partial marks (6.0: the exit node is Alex's, the Mac is yours; 7.10: the key steps are Alex's, the CLI is per Mac). Rules for everyone and per-Mac steps stay unmarked (1.8, 4.2-4.5, 4.6, 4.7, 7.7, 7.8, 8.6, 9.2, 10.5, 10.6 and the reference rows).
  - spp-c4e decisions: N08 (a) in the Start-here Modal row (no token of your own; making it is Alex's only) and the 1Password item catalog's Modal row and section 4's last row (D23); G14 (D24): a Students row at the top of GoHighLevel rebuild Builder 2b, its 3 not-proven builder rows marked partner route only, the Student starter kit's builder row; G19 (D25): Director home rebuild steps 3 and 5 take One-Shot-Builder's files, STACK.md and CONCEPTS.md from the edition.
  - spp-c4e privacy pass: Decisions D26-D28 (personal addresses, Google file links and the developer ID, the two scans), DONE. The decision text says "person-N labels on example.com": build_tabs.py's check refuses an address-shaped string in a tab.
  - Section 19 bookkeeping from the applied blocks: title (spp-c4e added N08), G01, G14 and G19 lines, a new N08 row.
- Skipped, condition not met: L270 (the Hermes update lane waits on the update-proof test) and L271 (Hermes restrictions wait on the restrictions play). L278 needed nothing: the Conductor already added the alias (L280). L293 is student_edition.py's README (notes/student-edition.md §7).
- Also re-pointed: STATUS.md's "Recently done" lines moved to the run log in the lead's 14:58 edit, so 4 quoted citations (catalog Foreplay, Higgsfield and Make rows; Composio custom routes' custom_foreplay row) now quote system/run-log.md.
- Builder side: tabs regenerated from HEAD by a scratch generator (gen_batch6.py); no original-tab corrections, so corrections.json is unchanged; decisions D20-D28 in notes/decision-evidence.csv; build_tabs.py's research corpus adds notes/spp-c18-partner-composio-access.md (the Composio shared-connections URL). Only the GoHighLevel rebuild and the Hermes and Javar rebuild tabs gained rows above others, and nothing cites them by row number (checked).
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1515.xlsx; check 0 problems, 0 warnings (51 expected item IDs); 0 corrections (all earlier ones already in); readback 30 of 30 spot cells, one of them negative (1.8 is not marked); a second dry run applies nothing. Master and ~/Documents copy sha256 1b7648ccb80cbfe5385c5be784c69390f8fc308243f2b5746a32307b75047da9, 36 tabs.
- Student edition: the apply's hook stopped on one failed op item read and kept the previous edition (a direct read of the same item a minute later passed, so it was transient). Then, outside the sandbox: build 19:15:50-19:18:41Z PASS (edition built 19:17Z), check 19:21Z PASS, selftest PASS (notes/student-edition.md §7). Edition workbook sha256 790ac8e9b672851e27372e65a97a7ba82d0ac5980d21b2aba7207ac9ce2b2fbc. student_publish.py pushed dc98d06 "Student edition 790ac8e9 (built 2026-10-02T19:17Z)" (+4 ~4 -0, 2,465 files); the rerun said "no changes".

## 35. Batch 7 applied (the Director's dispatch), 2026-10-02 16:02 local
- Source: the QUEUED spp-c4f block (workbook-updates.md L294-L299), from the Conductor's notes/replication-spotcheck-c4f.md (N08 and G14 closed, G19 partly, new N09 and N10).
- Rebuild from zero: a numbered Modal step 7.12 after 7.11 (python3 from 2a; partner: no token of your own; student: own token; check: modal_op.py token info names the token's user), which sits after the clone (3.1) and the robot (4.2) it needs (N09, N10). Start here's Modal row no longer installs or proves anything before 0.4: it says "Set up in step 7.12 (after the robot in 4.2)" and keeps who makes the token. 15.2 gets the student check (clean tree, no remote).
- Director home rebuild: step 5 names the empty mission-graphs/ and the write guard the starter ships (and what a stand-in would mean: live-write missions out of scope for students); new step 5a makes the starter its own git repo (git init, first commit, no remote).
- Bookkeeping from the spot check's verdicts: section 19 (N08 CLOSED, G14 closed for students, G19's spot-check line, new N09 and N10 rows); Decisions D23 and D24 to DONE (their "proof when done" was this spot check), D25's note lists what G19 still lacked.
- Inserting 7.12 moved every Rebuild row below it down by one: 45 row citations in the other tabs were re-pointed by row identity, and all 110 now name the same rows as before (checked).
- agents-home 8091133 (only modal_op.py, not pushed): the install hint says python3 from python.org (section 2a) and step 7.12, not /opt/homebrew/bin/python3.14; tests 8/8. The modal card (tools/cards/modal.md L33) still names the Homebrew path; not in this dispatch's scope.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1602.xlsx; check 0 problems, 0 warnings (51 expected item IDs); 0 corrections; readback 18 of 18 spot cells; a second dry run applies nothing. Master and ~/Documents copy sha256 9a73aa30b6a24ccb3f1bee40eef560e9eb64a25b18d6726744d94462890a0352, 36 tabs.
- A second writer in between: at 16:15:15 another agent's agents-home commit (2609320, instructions) ran the post-commit hook, whose cards_to_sheet.py re-saved the master (sha256 b869267f…) and then failed to copy it to ~/Documents (its sandbox). Every sheet part was byte-identical to the apply's output; only docProps/core.xml's save time differed. So the master was set back to the apply's bytes from the ~/Documents copy (9a73aa30), which is also the master the edition was built from.
- Student edition (outside the sandbox): the apply hook's build and check passed; then build 20:08:23-20:11:14Z PASS (built 2026-10-02T20:09Z), check PASS, selftest PASS (notes/student-edition.md §8). Edition workbook sha256 fe9cffcc65874532cd1f50c5e00a6468461d0649a3af2c4b9764172a7e935458. student_publish.py pushed e9dc746 "Student edition fe9cffcc (built 2026-10-02T20:09Z)" (+2 ~4 -0, 2,467 files); the rerun said "no changes".

## 36. Batch 8 applied (the Director's dispatch), 2026-10-02 16:47 local
- Source: the QUEUED spp-c4g G19 block (workbook-updates.md L304-L306), from the Conductor's notes/replication-spotcheck-c4g.md (N09 and N10 closed on both routes; G19 still partly: the shipped guard denied a mission started the documented way). alex-director 7939288 (already pushed): the guard expands ~ in MISSION_GRAPH, and the template has the '## Node:' comment.
- Director home rebuild step 5b: "Before a protected write, add one '## Node: <NODE_ID>' line ... The guard accepts the ~/Alex-Director/mission-graphs/<id>.md path as written." Rebuild section 19: G19's fix line; N09 and N10 CLOSED on both routes. Decisions D25's note says what spp-c4g found and that 7939288 fixes it. Not in this dispatch: the codex-voice block (L300-L303) and the mha-j2r rename block (L307-L312).
- agents-home (committed by path, not pushed): fe7cd64 cards_to_sheet.py leaves the workbook alone when the Tool cards tab already holds these values (it re-saved the master on every instructions or card commit; batch 7 §35), and refreshes the ~/Documents copy only when needed, reporting a refused copy instead of a traceback; test_cards_to_sheet.py 5/5, and the always-save version fails it. b5f51f8 modal card L33: python.org's python3, as step 7.12 says. Its hook, run outside the sandbox: hosted notes synced (16 cards, Composio refresh 200), instructions "already up to date", Tool cards "tab unchanged, not saved", "copy already equal"; workbook sha256 9a73aa30... before and after.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1647.xlsx; check 0 problems, 0 warnings (51 expected item IDs); readback 8 of 8; a second dry run applies nothing. Master and ~/Documents copy sha256 1a77b48f7688b35e7ef9f8eab2ca4fa5e298d6ced614b890d3488376b35fe0b9, 36 tabs.
- Student edition: the apply hook's build and check passed; then build 20:53:28-20:56:21Z PASS (built 2026-10-02T20:54Z), check PASS (98 vault secrets by hash: the vault gained an item), selftest PASS. It carries alex-director 7939288 (the template's '## Node:' comment, the guard's ~ expansion) and agents-home 22a16c2 (with fe7cd64 and b5f51f8). Edition workbook sha256 376fd0119f6fef83e26624ed7b906771641e276104a234ef19b947c4acc66649; student_publish.py pushed 63d942d "Student edition 376fd011 (built 2026-10-02T20:54Z)" (+1 ~17 -0, 2,468 files); the rerun said "no changes".

## 37. Batch 9 applied (the Director's dispatch), 2026-10-02 17:12 local
- codex-voice block (workbook-updates.md L300-L303): Rebuild 12.2 says what build_instructions.py apply writes now (~/.codex/AGENTS.md with the Codex Voice section, and the Codex talk-length and progress-note settings, model_verbosity medium and model_reasoning_summary concise; agents-home b39becc). Limits R16 (a guarded cell edit, gen_corrections.py section 25): Codex developer_instructions load in codex exec and the CLI only; the app ignores them, so app chats get the voice from ~/.codex/AGENTS.md (5,579 of 6,000 chars). Decisions D29 with the row's current text (pings only when something happens; the 25-minute check-in a silent backstop; no timed status pings), PROOF PENDING: the codex exec before/after proof covers the voice and talk settings, and the ping behavior still has to be seen in a live Director chat. In place: agents-home 2609320, b39becc, a9d4ae4 and Director home 55ae260.
- mha-j2r block (L307-L313): Rebuild 8.2's Tailscale join and section 19's N06 name the default exit node javante.tailde26a1.ts.net (agents-home 22a16c2); the Tailscale tab R3 (tailscale name) and the To do R60 '~/.agents pushes' row say javante, by guarded cell edits (section 25; section 24's append text too, so a rebuilt sheet gets the new name). No cell in any tab names sashas-mac-mini.tailde26a1.ts.net now. The refresh's truth/13_tailscale.tsv is the three-way merge's base snapshot, so it stays as it was; ~/Alex-Director/STACK.md and the Build repo are their owners' (L313).
- G19 rows untouched (the Conductor's spot check). No rows moved above others in a tab that is cited by row number (Decisions gains D29 in its section 2; nothing cites that tab by row).
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1712.xlsx; check 0 problems, 0 warnings (51 expected item IDs); 3 corrections (Limits R16, Tailscale R3, To do R60); readback 11 of 11; a second dry run applies nothing. Master and ~/Documents copy sha256 7a239944d64655738941d275e4dbe4e2209aada4e6474e2c0eae487ffa190f6f, 36 tabs.
- Student edition: the apply hook's build and check passed; then build 21:18:09-21:21:04Z PASS (built 2026-10-02T21:19Z; agents-home a9d4ae4, alex-director 55ae260), check PASS (0 findings, 98 vault secrets), selftest PASS. Edition workbook sha256 229bf9c46bb95c389172cbf963065ae997c5809f092a83ffc2277d3ccffb65be; student_publish.py pushed 0deb579 "Student edition 229bf9c4 (built 2026-10-02T21:19Z)" (+0 ~6 -0, 2,468 files); the rerun said "no changes".

## 38. Batch 10 (the Director's dispatch), 2026-10-02
- Lock line, 2026-10-02T21:38:34Z: the batch 10 builder touches ~/.agents/skills/alex-director/references/gates.md and ledger.md (and their mirror in ~/Alex-Director/skills), and ~/Alex-Director's STANDING docs only through the student starter; snapshot system/snapshots/2026-10-02_1738_batch10-director-docs/ first. ~/Alex-Director/DIRECTOR_STATE.md is not written (the conductor's rule): the starter's blank block gets SUPERVISING_DIRECTOR_THREAD_ID from student_edition.py instead.
- Source: the QUEUED spp-c4h follow-ups block (workbook-updates.md L314-L320), from the Conductor's notes/replication-spotcheck-c4h.md (G19 CLOSED; the student route has 0 blocking items).
- Version labels: Rebuild 15.1 (10 references, version 2.4 or later, and its check) and Director home rebuild "The two role skills" (2.4 or later). Director + Conductor tab: section 2 names each part by its 2.4 file and section (no v2.1 line ranges; the v2.1 SKILL.md parts that moved point at references/intake.md, continuation.md, supervision.md, execution.md and routing.md) and drops the per-part sizes; R13 and the conductor row say version 2.4 (seven rules); section 7's first 10 rows re-measured live at 2.4 (sizes, versions, the Director home files, the 19/19 self-test, the copies: 30 entries in ~/.claude/skills, the thin claude-edition.md pointers instead of the 90-line edition). build_tab.py: section 2's header and both titles.
- Director home rebuild step 2: "Students: skip this step, there's no clone without an invite. Use step 5 (the starter)."
- Starter (student_edition.py, notes/student-edition.md §9): .gitignore (.runtime/, *.bak, *.lock), STANDING_AUTHORIZATIONS.md and docs/solutions/README.md stand-ins ("none yet"), One-Shot-Builder's checklists/ONE_SHOT_READINESS.md as a scrubbed copy, and SUPERVISING_DIRECTOR_THREAD_ID: NONE in the starter's blank block (after CONTROLLER_HOST_ID).
- gates.md and ledger.md (agents-home 6e4c136; mirror alex-director 3c038e8, pushed): the seven fence fields, and the NONE convention plus SUPERVISING_DIRECTOR_THREAD_ID. Where the outcome and scope JSON come from: the live ledger's AUTHORIZATION_REF values all point at <id>-authorization.json files beside the mission graphs, which hold both objects (not the play's scratchpad, as the queue line guessed).
- Limits R3 and R16 "ours today", measured live: Claude CLAUDE.md 26 lines / 4,758 chars and Codex AGENTS.md 32 / 5,579; the Claude output style 36 lines / 2,644 chars and Codex developer_instructions 2,869 chars (gen_corrections section 26).
- Bookkeeping from the spot check: section 19's G19 CLOSED for students; Decisions D25 DONE.
- Not done (the conductor's rule): ~/Alex-Director/DIRECTOR_STATE.md's live blank block lacks SUPERVISING_DIRECTOR_THREAD_ID; the Director adds the one line "SUPERVISING_DIRECTOR_THREAD_ID: NONE" after CONTROLLER_HOST_ID with ledger_check.py backup/verify. Once it's there, student_edition.py ships it as written.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1744.xlsx; check 0 problems, 0 warnings; 2 corrections; readback 16 of 16; a second dry run applies nothing. Master and ~/Documents copy sha256 e9e70449cfa52d350695b30cdba995964d829c884d7b82792dade8c2ce83c173, 36 tabs.
- Student edition: build 21:50:25-21:53:16Z PASS (built 2026-10-02T21:51Z; agents-home 6e4c136, alex-director 3c038e8), check PASS (0 findings, 98 vault secrets), selftest PASS. Edition workbook sha256 229f09d704b07381959b42f69fad575c097d36f61647f5e93f2b6bd82f593089; published as 8288064 "Student edition 229f09d7 (built 2026-10-02T21:51Z)" (+4 ~7 -0, 2,472 files); the rerun said "no changes".

## 39. Batch 11 (the Director's dispatch), 2026-10-02 19:01 local
- Sources: repo-lock (work/2026-10-02_repo-lock/notes/repo-lock.md §9-§10, facts §1, §4-§6), codex-voice round 2
  (work/2026-10-02_codex-voice/notes/round-2.md, the Part 1 follow-up), the Conductor's QUEUED spp-c21 block
  (notes/spp-c21-claude-app-connectors.md §3), and the card refresh repo-lock §8 asked for. Generator: scratch
  gen_batch11.py from HEAD; gen_corrections.py sections 27 and 28.
- Rebuild from zero (20 cells): r9 B and E (agents-home and master-connector-repo in the increase-roas organization since
  2026-10-02 with per-person roles; the two Worker repos stay on increaseroasir with read and write; seats: GitHub Team, 3,
  2 used, a pending invitation by username uses none), r20 B and C (who owns which repo; the Director's home is also in the
  organization; "all owned by increaseroasir" was no longer true, so B20 changed with C20), r95 B and D, r96, r97 (clone
  addresses), r105 and r106 (owner, address, one partner invited with read, pending), 12.4 (budgets 6,000 characters for
  Claude's file and 8,000 for Codex's; measured 26 lines / 4,758 and 47 / 7,374).
- Student starter kit (20 cells): r5, r6 (address, owner, 1 read invitation pending), r14 (a role per repo in the
  organization; Alex chose Read for the 2026-10-02 partner; personal repos still read and write), r15 (owner per repo,
  the organization's Collaborators and teams page, the role, invite by username, PATCH an invitation's role), r16 and r22
  (<owner> paths), r18 and r19 (clone addresses), r26 (invitations are listed now; expiry likely 7 days, not proven). The
  partner's GitHub handle is in neither tab (both ship in the student edition).
- Limits R3 (section 27): OUR LIMIT "80 lines each; 6,000 chars for Claude's file, 8,000 for Codex's"; ours today 26 / 4,758
  and 47 / 7,374, measured 18:57 EDT. AI apps r9 and r10 (section 28, spp-c21 §3): r9 count 7 (Composio, GitHub
  Integration, Claude in Chrome, 1Password for Claude, Claude Docs, PDF Viewer, Desktop Commander; the Ref confirmed gone)
  and "only here" adds Claude in Chrome and 1Password for Claude; r10 0 and 0, the pairing explained, RETIRED 2026-10-02,
  done. The 1Password security page isn't in the research corpus, so those rows cite the spp-c21 note that quotes it, plus
  Anthropic's help article.
- Card refresh (repo-lock §8), outside the sandbox at 19:00 local: sync_notes.py 16 cards, server restarted, Composio refresh
  200; cards_to_sheet.py saved the Tool cards tab (github card b49487f, ghl card 22a188e) and copied the workbook to
  ~/Documents (both 990fab62... before the apply). Run under a process-group timeout (lesson L-010).
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1901.xlsx; check 0
  problems, 0 warnings; 9 corrections; both playbook tabs rebuilt; readback 30 of 30; no old address of the two moved repos
  left in either tab; a second dry run applies nothing. Master and ~/Documents copy sha256
  202c96871f84a19410836892dd2de4d0145c8117bb70bfc91f35f48e06b4b34f, 36 tabs. Later the agents-home hook (another agent's ga4
  card, 02d7e4d) re-saved the Tool cards tab: master and copy a8d31e308eb3beee2b3fb2a200d31abb3f06bfb5c79b529ff68fcfe63cfaf410;
  the batch 11 cells unchanged.
- Student edition: the apply hook's build PASS (23:02Z) and check PASS; selftest PASS; published as 3d4c8de. That copy
  carried a partner's GitHub username in agents-home/tools/cards/github.md (another agent's card change b49487f, not these
  tabs). Fixed the same hour (notes/student-edition.md §10): rebuilt 23:18Z, check PASS (0 findings, 98 vault secrets),
  selftest PASS, published as 656dda4 "Student edition 12e94944 (built 2026-10-02T23:18Z)" (+0 ~6 -0, 2,472 files; the
  rerun said "no changes"). Commit 3d4c8de stays in the template repo's history (owner-only, no invitations); students'
  "Use this template" copies start from the current tree only.

## 40. Affiliate sign-up spots (the Director's decision 1 after §39), 2026-10-02 19:41 local
- Rebuild from zero section 1 (scratch gen_spots.py from HEAD; 12 cells): 1.1 https://1password.com/pricing, 1.2
  https://composio.dev/pricing, 1.5 https://tailscale.com/pricing, 1.6 https://workspace.google.com/pricing and
  https://cloud.google.com/pricing, 1.8 https://claude.com/pricing and https://chatgpt.com/pricing, 1.9 "For the
  GoHighLevel routes (section 10) you need a HighLevel agency account: plans and sign-up at
  https://www.gohighlevel.com/pricing." Each row cites notes/student-edition.md §11 (every URL fetched that day, program
  row named). No spot for 1.3 Orgo, 1.4 Cloudflare, 1.7 GitHub (no program).
- Check first reported 1 problem not from this change: the Templates tab's §3 example listing of the repo-conform skill
  lagged its committed 2.3 files (agents-home 33c52ee, fb5c882: references/speed-checks.md, scripts/speed.py,
  scripts/test_speed.py; nothing uncommitted in that folder). `build_tabs.py templates` regenerated it (12 rows added; the
  rows below shift; no citation points at Templates row numbers). Then check 0 problems, 0 warnings.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-02_1941.xlsx; Rebuild from
  zero 12 cells, Templates rebuilt, Tool cards F6 and F10 (the cards hook's state); second dry run applies nothing. Master
  and ~/Documents copy sha256 20d762a7fbb9e141c5899887ea0ae940b6604c5c17855a500caf9cdf7f2986cb, 36 tabs. The master keeps
  the plain links; only the student edition swaps live ones (student-edition.md §11, published bd8f08c).

## 41. Batch 12, spp-p45a (the Director's dispatch, parity-recheck fix pass), 2026-10-03
- Live reads this batch cites (2026-10-03, read-only, nothing printed but names, IDs and dates):
  - Composio REST `GET /api/v3/connected_accounts?toolkit_slugs=tailscale` (whitelisted fields only): 1 login,
    ca_Qr4XRwIDafoq, word id tailscale_eaved-netter, ACTIVE, created 2026-10-01T21:17:21.215Z, auth config
    ac_PuHkSI8S2VOZ (API_KEY, not Composio-managed).
  - 1Password title check for that login's key, `op item list --vault Connectors` (titles, IDs, categories and dates
    only; no values): it timed out at 30 s twice at about 07:00Z (inside and outside the sandbox; other agents' op calls
    hung too), so the first apply wrote the Tailscale rows without an item. op answered again by 07:27Z (the second
    apply's student-edition hook read the vault), and the retry listed 37 items with two Tailscale ones: 'Tailscale API
    token' (75uhbn7dxm5lmzugcrmr4cfida, API_CREDENTIAL, created 2026-10-01T21:17:06Z, never updated) and 'Tailscale auth
    key' (the device join key). With the key metadata the network-rules job read through this login
    (notes/api/keys-metadata.json: API key kqEDA2QHaj11CNTRL, description '1pass', created 21:16:37Z, expires
    2026-12-30T21:16:37Z), the chain is key made 21:16:37Z, item saved 21:17:06Z, login created 21:17:21Z. That is the
    title-and-time confirmation the third apply writes; the values were never compared.
  - ~/.codex/config.toml, names-only parse of [apps] and [plugins] (file last written 05:57:52Z): [apps] holds _default,
    connector_openai_safety_settings (off), connector_openai_hotline (off) and the Composio app
    asdk_app_6a58503580c08191b78cc5bdaf4eba6e (approve); no Google Drive or Calendar app or plugin.
  - Composio REST `GET /api/v3/connected_accounts?toolkit_slugs=custom_foreplay` (same whitelist): 1 login,
    ca_Ewk5F5TGN7Yg, word id custom_foreplay_sain-cogue, ACTIVE, created 2026-10-01T17:23:22Z; the rotation's run-log line
    says the old ca_jPNptM7GgFeW was deleted, and it no longer exists.
  - `git ls-remote`: agents-home main a28cacd = local HEAD; master-connector-repo main 71de3e2 = local HEAD before this
    batch's commit (spp-p45b's 18aa41e was local only then).
  - The Director skill mirror: `diff -rq` of ~/.agents/skills/alex-director and alex-workflow-conductor against
    ~/Alex-Director/skills: only scripts/__pycache__ differs; no SKILL.md.bak in the live folder; the mirror's last commit
    is a68bd6c; ~/Alex-Director/AGENTS.md line 34 names ~/.agents/skills/mission-intake-and-approval-gate/SKILL.md.
- Sources, and the cells each one changed (old → new, written into the sources only: tabs/*.json, corrections.json,
  notes/decision-evidence.csv, the Director tab's skills-map.json; built by build_tabs.py):
  - Parity recheck b §6 (notes/parity-recheck-2026-10-03b.md):
    - L22: Tailscale R5 and R9–R13 F (the 2026-10-01 exposure issue, fixed by policy v4; R5's SSH note; R10's port
      9223); To do R2 A/C/D (and B in the past tense) and R10 B/C.
    - L01/W11: All connections R121 and R178 J/L/M (and K, same row); Route power R7 M and R14 L/M; To do R42 C, one text
      that also carries W16 and the claims audit's Cursor cell (§3 item 12).
    - W14: AI apps r11 B/C; All connections R114 L/M (and J), R117 J/K/L; GoHighLevel R3 and R6 H/K/L/M (and R3 J);
      To do R5 A/C/D (and B); Plan R17 B and C.
    - L29: To do R12 A/C/D. V16: Projects R7 D. L33: All connections R55 D/H/K/L.
    - L34: Rebuild from zero R105 E and R106 E, their sources (the old commit pins dropped), and section 3a's title.
    - W25 and V17 (skills-map.json): Director + Conductor R141 B/C, R143 B, R144–R148 B, R149 B and R156 B.
    - W09: Plan R15 C, To do R20 C, Composio R82 J (and L). W10: To do R7 A/C/D, SOP R29 D. W15: All connections R123 K.
    - W16: Plan R9 C, To do R42 C, SOP R24 C. W19: To do R28 A/C/D (B keeps the hand counts as dated history), Plan
      R33 B/C, SOP R11 D.
    - W22: All connections R73 L and R75 L (one per row: its plugin, its CLI), R230 and R231 K/L, R223 D/H/J/K/L/M.
    - V04: SOP R44 D. V08: All connections R112, R148, R165, R205 and R246 D/H/K/L/M. V11: All connections I276 and
      Claude app connectors F75 (appended). V15: Self-improving loop R12 C (STATUS.md line 11 already says 24 hours,
      18aa41e).
    - L03: Route power R65 M. L08: All connections R74 B/J/L (and G: the official plugin signs in through the ChatGPT
      app, SOP R26); App decisions E12 follows. I08: Route power R29 M. S07: Route power R58 L/M.
  - L35, pre-fix wording only (Director ruling 2026-10-03: D02 covers the Mac mini, as L32 did for D07): AI apps R15 B,
    by an edit and in the appended row's own text; Decisions D02's note records the ruling. The removal itself waits.
  - Claims audit (work/2026-10-03_claims-audit/notes/verify-workbook-other.md):
    - §1: W05 Plan R11 C/F and Evidence R2 F; W22 Composio + 1Password right way R44 B; O11 Hermes and Javar rebuild B12
      (rename.md §6 row 1; tabs/gap-facts/G24.json mirrors it); O12 the 7 LoneStar cells (Plan R6 C and R26 B,
      GoHighLevel R23 J, To do R18 A/C/D, Route power R8 F, Tracking access R7 F and R39 F, and their twins in
      knowledge/tracking-checklist-access.csv).
    - W37: the Tailscale login rows (All connections R318, Composio R100; App decisions gains a Tailscale row) and the
      1Password item catalog's 'Tailscale API token' rows (R36 C–F, R83).
    - §2 O28, Foreplay rotated 2026-10-01: SOP R62 D, To do R3 A/B/C/D, Plan R16 B/C, and item 2 of
      system/handoff/2026-10-01_connectors-handoff.md.
    - §3: item 3 All connections R229 D/H (and K); item 4 Route power R21 D/L/M, after the names-only [apps] read above;
      item 6 To do R13 A/C/D; item 7 To do R59 A/B/C/D and Composio R2 E/H/J/L/M; item 8 To do R66 A/C/D, All connections
      R317 D/H/J/K/L, Route power R72 D/L/M (the audit's "R71" is the native hugging_face row; R72 is the hosted-MCP row)
      and Composio custom routes R23 E/F with section 1's title; item 12 AI apps r6 B/D; item 13 the R106 recount. Items
      1, 2, 5, 9, 10 and 11 are the §1/§2/W37 entries above.
  - spp-c22 R3 (notes/spp-c22-app-lane-disposition.md §5): To do R4 C.
  - Alex's partner rule (notes/spp-c20-member-test.md §7; verify-director-repo-files.md NEVER TRUE 2): Rebuild from zero
    r6, r12 (§7's text, keeping the existing "A new partner first gets a user account."), r433 status and "where it is
    now", one pointer sentence in r5 (the row the audit quoted), Templates 12c step 7 "Partners" (R490 today, not r487:
    the tab gained rows above it since spp-c20 §4), and Decisions D34 (new, PROOF PENDING). The variant (a)/(b) detail
    waits for Manny's member test.
  - Follow-ups the readback's stale-phrase scan found (same items and evidence, on no source list): O28, the rotation
    replaced login ca_jPNptM7GgFeW with ca_Ewk5F5TGN7Yg (live read above): All connections R289 B/G/J and R309 H/J/L/M,
    Composio R21 B/G/J/L/M, Route power R61 B/M, Plan R8 C. L22: Plan R19 B and C (Kanwal). W09: Route power R67 M (the
    spp-c22 R3 sentence). L29's twins: the CSV's two GTM rows now equal Tracking access R34–R35 (the 10-03 fix had
    changed only the workbook).
- Left as is, with the reason: AI apps R9 G (a dated 2026-10-01 progress note that ends in its own later update; R9 is
  held for spp-c22 R1, which regenerates that area); All connections I121 and I178 (dated 2026-10-01 live-check records);
  Projects R7 F (a fact about 2.1.251 that stays true); To do R12 B (not in the queue; it names an outside address).
  Not in this play: I17, I21, spp-c22 R1, the L35 removal on the Mac mini, the student edition's rebuild and publish.
- Builder side: scratch generator gen_p45a.py (session da73c8be scratchpad, folder p45a), idempotent; it checks every
  edit against the master first. corrections.json: 196 edits and 2 appended rows (the AI apps Mac mini row's text
  updated in place); notes/decision-evidence.csv: D34 added, D02's note; decisions.json regenerated with
  `build_tabs.py decisions`.
- Applies, outside the sandbox (the third followed the title check):
  1. 07:16Z: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-03_0316.xlsx
     (sha256 c372e737…); 176 corrections; the student-edition hook stopped on `op item list` (60 s, L-010) and kept the
     previous edition.
  2. 07:20Z: backup …_0320.xlsx (b7346646…); the 18 follow-ups; hook build and check PASS (local only).
  3. 07:29Z: backup …_0329.xlsx (a9667052…); 4 Tailscale cells, 7 catalog cells and R106; hook build and check PASS
     (0 secret hits in 2,485 files; local only, not published).
- Final master and ~/Documents copy: sha256 66435e6b2b05f0e3c75c2ba6d68f88bcd519a039f71c3143e78cc5390c9ea7f4, 541,130
  bytes, byte-identical (cmp), 36 tabs.
- Checks: `build_tabs.py check` 0 problems, 0 warnings (51 expected item IDs), 0 unsourced claims. Readback from the
  saved file: 196 of 196 corrected cells old → new as planned, 27 of 27 rebuilt-tab cells, both Tailscale rows identical;
  0 hits left for 24 retired phrases (AI apps R9 G keeps one on purpose, above). Second dry run: 0 corrections applied,
  every tab 0 cells different, Director + Conductor 701 of 701, master untouched.
- R106 recount (every repo path in any cell that resolves to a file): 208 before this batch (the claims audit's own
  method gave 204), 215 after. Untracked once this batch is committed: 1, .claude/settings.local.json, which the global git
  ignore keeps local on purpose. The commit adds the cited notes that were untracked (parity-recheck-2026-10-03b.md,
  verify-workbook-other.md, verify-director-repo-files.md) and spp-c22-app-lane-disposition.md (cited in
  corrections.json), by path (§27's standing rule).

## 42. Batch 13, spp-p53a (the Director's dispatch after parity recheck c), 2026-10-03
- Live reads this batch cites (2026-10-03 about 08:30Z, read-only):
  - ~/Alex-Director: HEAD b98dd0a equals GitHub main (`git ls-remote`); 18 uncommitted paths (DIRECTOR_STATE.md and
    17 in mission-graphs/), names only. agents-home: HEAD ad0158c equals GitHub main.
  - The App decisions generator's input: the apps whose All connections rows are all removed, deleted or placeholders
    (AWS, Appwrite, Browser Use, Clerk, ClickUp, Convex, Docs helper, GitLab, OpenAI, Parallel, Postman, Ref, Shopify,
    Supabase, Vercel, WhatsApp). Only Shopify has a row still on the plan: R310 (target 1Password, "Alex fills the item,
    then the agent adds Composio shopify"). The others' open steps end their route (target Remove, Removed or Leave off).
- Item 1, report c §8 (notes/parity-recheck-2026-10-03c.md), applied as written (cells through corrections.json,
  tabs/*.json and notes/decision-evidence.csv; 23 guarded edits):
  - L22: Plan R20 B/C/D/F. L29: Plan C24 (it also carries W28's Zoom line) and Route power M9.
  - L34: Director home rebuild A3 (title), E5 (live count: 18 uncommitted ledger and graph paths, not report c's 16),
    E6, F5 (the two commit pins dropped); Rebuild from zero R105 E (the hash dropped; agents-home has moved on).
  - W26 (CG-SZRA): Composio + 1Password right way B40, Do, Don't D10, Decisions D13 (DONE, note), To do B22. W33
    (ccf-dc2): Composio R38 K/L/M, To do C22/D22, Plan C23 (one text with W26's facts).
  - W27: Decisions D19's note. W28: All connections J264, Composio J96. W29: All connections L99/M99, To do C40. W31:
    Plan R18 B. L37: AI apps R5 G (Firecrawl, Hugging Face) and D (Modal), from spp-p48a. L38: Decisions D30's note.
    W32: SOP C3, AI apps r12 F.
  - W30: work/2026-10-01_app-decisions/build_decisions.py keeps an app with no live route when one of its rows is still
    on the plan (decision_rules.open_step: an open setup step on a row whose target doesn't end the route), as ADD TO
    COMPOSIO. test_build_decisions.py: 4 tests, red before the fix (3 errors, Shopify missing), green after; the
    generator test runs on a temp copy of the workbook. Result: 59 apps, Shopify "ADD TO COMPOSIO | 0 | 0"; no dropped
    app came back.
  - W09 and W19: STATUS.md line 29 (the Shopify connector went with the Small Business plugin), line 42 (no removal
    step) and line 45 (the hand-counted wording pass dropped). Line 15's "56 apps" is now 59 (not in the dispatch; left).
  - Not dispatched, left: L36's To do row and the O5 row (owner steps); report c's optional rows (Composio R75, R95 and
    R90 L; a tcp:9999 To do row).
- Item 2, L18 detection: check.py is ~/.agents/tools/unify/check.py, and this play may not edit ~/.agents, so it's
  proposal L-022 in system/lessons.md (check 8 for the 4 model keys; its target read only by the check, so it never
  restores xhigh, which stays Alex's call). Another writer added its own L-021 while this play ran, hence L-022.
- Item 3, the partner design (work/2026-10-03_partner-robot/design.md §10): 10.1 Rebuild r12's partner, how, who and
  source cells (the who cell also gives the click count, about 47, or 64 with the Partner AI unit, in place of the 10-02
  "one click"); 10.2 D34's proof line and note; 10.3 D35 (free when applied); 10.4 Rebuild r8's partner cell and the
  G05-addendum step 1 (Composio + 1Password right way R115 C and tabs/gap-facts/G05-addendum.json), both waiting on the
  P0 node partner-1password-isolation. D34 and D35 stay PROOF PENDING. build_tabs.py's research corpus adds design.md
  (its Google URLs).
- Item 4, the Hermes "why" rows, in the D-row format: D36 the whole operating standard for Hermes agents (PROOF
  PENDING; supersedes the one-route ruling for Javar's Cloudflare server), D37 one Composio member identity per agent
  (PROOF PENDING; seats may be spend), D38 Alex's key file on Javar locked to 0600 (DONE), D39 Javante's keys in his own
  vault (PROOF PENDING), D40 no agency GHL key for an agent (DONE). The dispatch's run-log line 265 for D36 is the probe
  fix; the rule's lines are 264 and 268 (L-018 added, then widened), so the rows cite lesson L-018 and quoted run-log
  text instead of line numbers.
- Item 5, optional hardening: scripts/student_edition.py reads the vault inside op_items.robot_env (one private HOME and
  one shared op daemon, agents-home ad0158c), with the old environment as a fallback; STUDENT_EDITION_OUT lets a proof
  build go to a scratch folder. Proof, outside the sandbox: build 08:43:51-08:47:03Z PASS and check PASS (0 findings, 98
  vault secrets by hash; scans 0 hits over 2,486 files) into the session scratchpad; the 10 op daemons running before
  stayed 10; test_student_edition.py 44/44. Nothing published.
- Apply: backup ~/Backups/workbook-2026-10-01/connectors-2026-09-30_before-playbook-tabs_2026-10-03_0436.xlsx (66435e6b…);
  23 corrections; App decisions 59 apps. Master and ~/Documents copy sha256
  50a1aba7404f6561e3556b3724b09ae2f117d0069902a5b62f66b514577df3eb, 547,267 bytes, byte-identical (cmp). The apply hook's
  local student-edition build and check PASS (not published).
- Checks: `build_tabs.py check` 0 problems, 0 warnings (51 expected), 0 unsourced. Readback: 23 of 23 corrected cells,
  every rebuilt-tab cell, D13/D19/D30/D34 and the new D35-D40, the Shopify row; 0 hits left for the retired phrases
  (left on purpose: AI apps R9/R14 "Not run from this surface yet", true for the Claude app and ChatGPT; Rebuild R8's
  Connectors:read_items, which is Alex's own two robots; Composio R75/R95, report c's optional rows). Second dry run: 0
  corrections, every tab 0 cells different.
- R106 recount after this batch: 221 cited repo files, 220 committed once the newly cited notes are committed, plus
  .claude/settings.local.json (git-ignored on purpose).
