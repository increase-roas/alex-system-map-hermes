#!/usr/bin/env python3
"""Build Claude-app upload zips (spp-p4c, items W06, S04, S10). Writes <name>.zip next to this file.

  python3 build_zips.py          # build and check every zip below

- alex-director, alex-workflow-conductor: thin pointers; SKILL.md comes from ~/.agents/skills/<name>/claude-edition.md
- mission-intake-and-approval-gate: the ~/.agents folder as it is (the uploaded copy is older)
- integration-fit-and-source-of-truth, first-principles-speed-analyzer, plain-english-repo-explainer: same, the
  ~/.agents folder as it is (added in spp-p15a, 2026-10-01: their descriptions changed, so the uploads are replaced)
- hermes-boss-director, native-fix-research: same (homed in ~/.agents by spp-p34a from the claude.ai copies; added in
  spp-p35a, so an edit in ~/.agents can be re-uploaded from here)
Checks: name matches the folder, description <= 200 characters (the Claude app's upload limit; native-fix-research keeps
its 210, which the app already accepted, under the 1,024 that claude.com's how-to and the Agent Skills spec allow:
notes/skill-optimization.md R3), only regular files,
no .env names (they can be 1Password pipes: never opened), none of the five removed tool prefixes.
"""
import hashlib, os, re, stat, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
A = os.path.expanduser("~/.agents/skills")
POINTERS = ["alex-workflow-conductor", "alex-director"]
FOLDERS = ["mission-intake-and-approval-gate", "integration-fit-and-source-of-truth", "first-principles-speed-analyzer",
           "plain-english-repo-explainer", "hermes-boss-director", "native-fix-research"]
LONG_DESC_OK = {"native-fix-research"}  # account copy (2026-09-29) already has 210 characters
OLD = re.compile(r"mcp__(cloudflare|atlascloud|Exa|Ref|apify)__")
SKIP = {"__pycache__", ".DS_Store", ".git"}


def check_skill_md(name, text):
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    assert m, f"{name}: no frontmatter"
    fm = dict(re.findall(r"^(\w+):\s*(.*)$", m.group(1), re.M))
    assert fm.get("name", "").strip('"') == name, f"{name}: frontmatter name is {fm.get('name')!r}"
    d = fm.get("description", "").strip('"')
    assert 0 < len(d) <= (1024 if name in LONG_DESC_OK else 200), f"{name}: description is {len(d)} characters"
    assert not OLD.search(text), f"{name}: SKILL.md names removed tool prefix(es) {sorted(set(OLD.findall(text)))}"
    return len(d)


def files_of(d):
    for base, dirs, files in os.walk(d):
        dirs[:] = sorted(x for x in dirs if x not in SKIP)
        for f in sorted(files):
            p = os.path.join(base, f)
            if f in SKIP or f.startswith(".env") or f.endswith(".env") or re.search(r"\.(bak\d*|prev|orig)$", f):
                continue
            if not stat.S_ISREG(os.lstat(p).st_mode):
                continue
            yield p


def build():
    out = []
    for n in POINTERS:
        src = os.path.join(A, n, "claude-edition.md")
        text = open(src).read()
        dl = check_skill_md(n, text)
        z = os.path.join(HERE, n + ".zip")
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"{n}/SKILL.md", text)
        out.append((n, z, dl, hashlib.sha256(text.encode()).hexdigest()[:10], 1))
    refused = []  # a skill that fails a check gets no zip; the others still build (spp-p35a)
    for n in FOLDERS:
        d = os.path.join(A, n)
        try:
            text = open(os.path.join(d, "SKILL.md")).read()
            dl = check_skill_md(n, text)
            bodies = [(p, open(p, "rb").read()) for p in files_of(d)]
            for p, body in bodies:
                assert not OLD.search(body.decode(errors="ignore")), f"{n}: {os.path.relpath(p, d)} names a removed tool prefix"
        except AssertionError as e:
            refused.append(str(e))
            continue
        z = os.path.join(HERE, n + ".zip")
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for p, body in bodies:
                zf.writestr(f"{n}/{os.path.relpath(p, d)}", body)
        out.append((n, z, dl, hashlib.sha256(text.encode()).hexdigest()[:10], len(bodies)))
    for n, z, dl, h, c in out:
        with zipfile.ZipFile(z) as zf:
            names = zf.namelist()
        assert f"{n}/SKILL.md" in names and all(x.startswith(n + "/") for x in names), z
        print(f"{os.path.basename(z)}: {c} file(s), description {dl} chars, SKILL.md sha256 {h}, zip sha256 {hashlib.sha256(open(z, 'rb').read()).hexdigest()[:10]}")
    for r in refused:
        print("REFUSED (no zip; fix the skill in ~/.agents, then rerun):", r)
    if refused:
        sys.exit(1)


if __name__ == "__main__":
    build()
