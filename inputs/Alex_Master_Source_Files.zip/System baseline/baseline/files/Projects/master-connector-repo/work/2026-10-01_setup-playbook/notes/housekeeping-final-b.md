# Housekeeping final, part B (play spp-p37a)

LOCK (spp-p37a, 2026-10-02T02:00Z, until this file says released): `~/.codex/config.toml` (single writer, sha guard `8bd8ebbf1d56eb1a`, removals only: the 32 `[[skills.config]]` blocks whose path is missing + `features.skills`); `~/Documents/Company-Ops/htl/areas/sales/ghl-command-access.md` (L42 only). No other file in `~/.codex`, `~/.agents/skills` or `~/Alex-Director`; pushes wait for the Director's "push".
RELEASED (spp-p37a, 2026-10-02T02:03Z): `~/.codex/config.toml` (one write 02:01:40Z, `8bd8ebbf…` → `cc54161c…`).
RELEASED (spp-p37a, 2026-10-02T02:04Z): `ghl-command-access.md` (one write, L42 only, `ca77186e…` → `c57b2089…`).
RELEASED (spp-p37a, 2026-10-02T02:12Z): pushes done (§3); nothing held.

Mission `mission-setup-playbook-parity`, node `housekeeping-final` (part B). Claude Code subagent of session 294b676b, workspace `~/Projects/master-connector-repo`, conductor v2.3 loaded first; DIRECTOR_STATE.md not written. Times UTC (Z) unless marked local (EDT).
`Stage: housekeeping-final part B | Route: direct (python guard scripts, git, op CLI read-only robot, Composio exa + OpenAI docs reader) | Gap: none | Next: Director`
`Checkpoint: items 1-3 below | Settled: ~/.agents goes to the GitHub URL only (Mac mini push URL = Alex's call) | Interrupted: none`

## Result

| # | Item | Status | Proof |
|---|---|---|---|
| 1 | config.toml: 32 dead off-switches + `features.skills` out | VERIFIED | §1: parsed diff = 33 keys removed, 0 added, 0 changed; Codex 63 enabled before and after (same names and paths), 0 repeats; check.py `OK`; startup stderr empty |
| 2 | ghl-command-access.md L42 | VERIFIED | §2: not dataless; L42 now names 1Password item `yxvess6diezoy7lgrnhqrmct5i`; only L42 changed |
| 3 | Secret scans + pushes | VERIFIED | §3: final scan 0 findings in all 3 ranges; all 3 repos private; remote main = local: agents-home af3b811, alex-director 8487dcd, master-connector-repo 2c4889c, then this note's follow-up commit, scanned and pushed the same way |

## 1. config.toml

- **What was dead (correction to the count's labels):** the 32 missing paths are 30 compound-engineering 3.30.2 cache skills (the cache is 3.30.3 now; the plugin stays `enabled = false`), the retired `~/.agents/skills/firecrawl`, and `openai-curated-remote/1password/0.2.0/skills/1password-environments` (that plugin's cache folder is gone since the 1Password plugin uninstall, 2026-10-01 ~21:06Z). Not 31 compound-engineering.
- **Write:** `scripts/p37a_config_cleanup.py` (check / apply / verify). Text-level removal of the 32 blocks (3 lines + 1-2 blank lines each) and the one `skills = true` line in `[features]`; atomic replace, mode 0644 kept; values never printed. Guards: exactly 32 stale entries, each an off-switch in one of the 3 groups, each block found once, parsed config equal to the old one minus those entries, 0 added text lines. Negative check: a planted 33rd stale path and a missing `skills = true` both STOP.
- **Backup:** `~/Backups/codex-config-2026-10-01/config.toml.before-spp-p37a-220135` (sha equal to the live file before the write).
- **Readback:** sha `8bd8ebbf1d56eb1a` → `cc54161cc7960bf2`; 43,456 → 38,083 B; skills.config 171 → 139; independent parsed diff (backup vs live): 414 → 381 keys, removed 33 (32 off-switches whose paths are missing + `features.skills`), added 0, changed 0, kept order equal; text diff 158 lines removed, 0 added.
- **Codex skills list** (`scripts/codex_skills_probe.py`, fresh app-server, `skills/list` forceReload; raw in `notes/transcripts/spp-p37a/`): before 02:01:23Z and after 02:02:00Z both 176 listed, 63 enabled (58 `~/.agents` + 5 system), 0 repeated names, 0 load errors, 34/34 vendored once; the 63 (name, path) pairs are identical.
- **check.py** after: `info: 139 Codex off-switches` … `OK` (exit 0); before: `FIX: 32 Codex off-switch(es) point at missing files`.
- **Startup warning:** before, the app-server logged `Codex is ignoring 1 unrecognized configuration setting … features.skills is ignored`; after, its stderr is empty (0 B).

## 2. ghl-command-access.md L42

- **Not a placeholder:** `find … -not -flags +dataless` prints the file, `-flags +dataless` prints nothing; flags 0x40 (UF_TRACKED) only. Company-Ops is a git repo with no commits; this file is untracked.
- **Item readback** (read-only robot, no values): `yxvess6diezoy7lgrnhqrmct5i`, "GHL Command Builder (ghl-command-builder) — connection password", API Credential, vault Connectors, value in `credential` (part A matched the retired file to it by sha256).
- **Edit:** L42 now says the password lives only in that item (ID and field named) and that the local copy was retired on 2026-10-01 after its SHA-256 matched; its rotation step "update the Connectors vault item and its local fallback" → "update that Connectors item". The rest of the line is unchanged. sha `ca77186e…` → `c57b2089…`, 47 lines before and after, changed lines [42], the retired path is named nowhere else in the file. In-place write (inode, flags, xattr kept).
- **Backup:** `~/Backups/company-ops-2026-10-01/ghl-command-access.md.before-spp-p37a`.

## 3. Secret scans and pushes

- **Scanner:** Part A's `scan_push_p35a.py` rules (17 provider shapes, secret-named assignments, every Connectors value: 33 items, 90 values; PEM needs key material; Cloudflare account ID allowlisted) over every blob in remote main..HEAD plus commit messages, values loaded once (`<scratchpad>/p37a/scan3.py`). For ~/Alex-Director it also checks the ledger and the 10 tracked graph files at HEAD.
- **First pass (02:05Z):** ~/.agents 2 findings, repo 4, ~/Alex-Director 0 (ledger + graphs 0). None is key-shaped:
  - 5 × `known-secret-value`, in `tools/cards/composio.md` and the codex-parallel-2 transcripts T2/T4/T5/T6 that quote it. All 5 are the `org` field of item ej5xlb52icpaabh4vto4a67na4, which holds the org label "wearenumber1 (alex@increaseroas.com)" (checked by equality; value never printed). It was already on GitHub in both remotes (composio.md at ae2136d; 5 files at f1b1355). spp-p12b allowlisted the same field.
  - 1 × `generic-assignment:SECRET`, in `tools/connectors/health/test_codex_automation_alerts.py` L21 (spp-p26a's test; new to GitHub). It's a canary shaped `WORD-WORD-9a9a`: two dictionary words + 4 characters, checked without printing. It is used only to assert that planted text never reaches the alert output.
- **Final pass (`scan_final.py`, 02:10Z):** the same scan with those two rulings applied by identity, plus 7 shapes the base rules lack (GHL `pit-`, Meta `EAA…`, Firecrawl `fc-`, Apify, Google `ya29.`/`1//0`, Composio `ak_`). Self-test 7/7: a planted vault value, a `pit-` token and a Meta token are caught; the canary is still caught outside its own file, and a random secret is caught inside it. Result 0 / 0 / 0.

| Repo → GitHub | Remote before | Pushed (UTC) | Commits | Private (readback) | Remote = local after |
|---|---|---|---|---|---|
| ~/.agents → increaseroasir/agents-home, by URL (the Mac mini push URL on `origin` not used, not contacted) | ae2136d | af3b811, 02:11:23Z | 49 | yes: Composio log_G3Bc5Lr1ruGF; anonymous API 404 | af3b811 |
| master-connector-repo → increaseroasir/master-connector-repo | f1b1355 | 2c4889c, 02:11:29Z | 36 (35 + this play's 2c4889c) | yes: log_iN2qbU2BwZGt; anonymous 404 | 2c4889c |
| ~/Alex-Director → increase-roas/alex-director | 2f2296c | 8487dcd, 02:11:34Z | 48 | yes, org-owned: `gh api` (the org's OAuth-app restriction blocks Composio's GitHub app, log_lVvuPAReymsN); anonymous 404 | 8487dcd |

- Each push sent the exact scanned sha (`<sha>:refs/heads/main`), fast-forward. The ~/Alex-Director push couldn't write its local tracking ref inside the sandbox, so I refreshed it with `git fetch origin main`, and did the same for ~/.agents. All three now show `## main...origin/main`.
- ~/Alex-Director sends committed files only. DIRECTOR_STATE.md's working copy and the untracked graphs (this mission's included) stay local.

## Left for Alex
- ~/.agents `origin` still lists Sasha's Mac mini (`agency-mini:agents-home`) as a 2nd push URL, plus the `mini` remote. Keep or remove is his call. Until he decides, pushes go to the GitHub URL only.
- Empty the Trash (part A's 2 retired key files) and re-upload the 2 Hermes zips (spp-p36a).

## Research (owner rule 5)
- developers.openai.com/codex/skills, "Enable or disable local Codex skills" (Composio OpenAI docs reader, log_2wDz9ffFyAJm): `[[skills.config]]` with `path` to the SKILL.md and `enabled = false` disables a skill; restart Codex after changing config.toml. No feature flag is needed.
- learn.chatgpt.com/docs/config-file/config-reference (log_aeRi6sJe_MKY): documents `skills.config`, `.path`, `.enabled` and `skills.max_context_tokens`; of its ~50 `features.*` keys none is `features.skills`.
- Exa (log_cEvsVlaN0o1h, $0.007): github.com/openai/codex `docs/skills.md` at 2c6995ca (skills were once "behind the experimental `skills` feature flag", `[features] skills = true`: where the dead key came from); openai/codex PR #9328 (per-skill enable/disable through `[[skills.config]]`); PR #20559 (unknown config fields are ignored with a warning unless strict mode is on).
