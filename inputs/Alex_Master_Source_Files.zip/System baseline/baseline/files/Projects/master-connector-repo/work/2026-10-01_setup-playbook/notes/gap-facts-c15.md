# Gap facts, spp-c15: the 3 ChatGPT skills get their home (Conductor, 2026-10-01)

All reads were on 2026-10-01 and read-only, in the Conductor's own Chrome tab (closed after). No token or key was printed. The full record is notes/spp-c15-chatgpt-skills.md.

## 1. ChatGPT's own record of each skill (G18)

Source: https://chatgpt.com/backend-api/hazelnuts (read 2026-10-01). This is the skills API that the chatgpt.com Skills page calls. The per-skill GET returns the fields below, plus a `files` map and a `sediment_id` (the package the files are read from).

| Skill | updated_at (the date the page shows) | latest / default version | safety_check_status |
|---|---|---|---|
| fulfill-hot-tub-launch | 2026-08-15T14:47:02Z | 4 / 1 | blocked |
| higgsfield-hot-tub-scene-variation | 2026-08-13T19:13:26Z | 2 / 1 | unchecked |
| create-local-meta-ads | 2026-07-10T04:44:39Z | 1 / 1 | unchecked |

- The date on each skill page (Aug 15, Aug 13, Jul 10; gap-facts-c14.md §3) equals `updated_at`.
- The Skills page's own file viewer reads a file from the skill's `sediment_id` package with a byte-range read, and sends no version number. Seen in the page's JavaScript bundle 438981…js, in the "browser-skills" query. The copy made here used the same path, so it is what the Skills page shows.
- **NOT_PROVEN:**
  - which version ChatGPT runs when latest and default differ;
  - whether "blocked" stops Fulfill Hot Tub Launch from running in ChatGPT. The page code derives a "blocked" label from a safety risk score.

## 2. The home in ~/.agents/skills (G18)

- **What's there:** `~/.agents/skills/create-local-meta-ads/` (5 files), `higgsfield-hot-tub-scene-variation/` (3) and `fulfill-hot-tub-launch/` (20). That's 28 files, all committed in agents-home e7916f1.
- **Byte-exact:** each sha256 equals the one computed in the page from ChatGPT's bytes. The combined digest is a867dd37e6faced0 on both sides.
- **The only edit:** line 3 of each SKILL.md. The description was rewritten trigger-first, at 194, 189 and 193 characters.
- **Codex:** off (W07), with 3 `[[skills.config]]` blocks; 171 off-switches now. A fresh app-server `skills/list` lists each name once, from `~/.agents/skills`, disabled. 63 skills are enabled, 0 names repeat and 0 fail to load.
- **Claude and Cursor:** no `~/.claude/skills` link. Cursor reads `~/.agents/skills` by the Skills tab's rule, which wasn't tested here.
