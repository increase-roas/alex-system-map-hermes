"""Build the "Director + Conductor" tab of the connectors workbook from notes/skills-map.json and notes/research.json.

  python3 build_tab.py                     # rebuilds the tab in the repo workbook, then copies it to ~/Documents
  python3 build_tab.py --book <copy.xlsx>  # rebuilds the tab in another file only (dry runs)

The tab is a projection of the two notes files: edit them (or re-run the agents), never the sheet. Section 8 (the split
test) comes from skills-map.json "split_test", which work/2026-10-01_setup-playbook/build_tabs.py splittest regenerates
from ~/Alex-Director-splittest-kit; build_tabs.py also calls build_sheet() when it builds the playbook tabs.
"""
import argparse, json, os, shutil

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

H = os.path.expanduser("~")
JOB = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(JOB))
BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"
COPY = f"{H}/Documents/connectors-2026-09-30.xlsx"
TAB = "Director + Conductor"
WIDTHS = [24, 34, 60, 46, 22, 14, 48]
INTRO = ("How Alex runs big jobs with AI: one Director (the alex-director skill) holds the goal and judges results; one "
         "controller per job (the alex-workflow-conductor skill) does the routing, the work through helpers, and the "
         "checking. Below: who does what, what is inside each skill and why each part exists, how one job runs from goal "
         "to done, and what outside research (Exa, 2026-10-01) says about this way of working, with links. Built from "
         "work/2026-10-01_director-tab/notes; rebuild with build_tab.py, never edit by hand.")
TITLE = PatternFill("solid", fgColor="1F3864")
HEAD = PatternFill("solid", fgColor="D9E1F2")
VERDICT = {"SUPPORTS": "E2EFDA", "QUALIFIES": "FFF2CC", "CONTRADICTS": "FCE4D6"}


def build_sheet(wb):
    """Rebuild the tab inside an open workbook, in the same place if it exists. Returns the number of rows used."""
    m = json.load(open(f"{JOB}/notes/skills-map.json"))
    rs = json.load(open(f"{JOB}/notes/research.json"))
    old = wb.sheetnames.index(TAB) if TAB in wb.sheetnames else None
    if old is not None:
        del wb[TAB]
    ws = wb.create_sheet(TAB, index=old if old is not None else
                         (wb.sheetnames.index("Skills") if "Skills" in wb.sheetnames else None))
    for i, w in enumerate(WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(WIDTHS))
    ws["A1"] = INTRO
    ws["A1"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[1].height = 90
    r = 3

    def section(title, header, rows, fill_col=None):
        nonlocal r
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(WIDTHS))
        c = ws.cell(r, 1, title)
        c.font, c.fill = Font(bold=True, color="FFFFFF", size=12), TITLE
        r += 1
        for i, h in enumerate(header, 1):
            c = ws.cell(r, i, h)
            c.font, c.fill = Font(bold=True), HEAD
            c.alignment = Alignment(wrap_text=True, vertical="top")
        r += 1
        for row in rows:
            for i, v in enumerate(row, 1):
                c = ws.cell(r, i, v)
                c.alignment = Alignment(wrap_text=True, vertical="top")
                if fill_col is not None and i == fill_col + 1:
                    tone = next((k for k in VERDICT if k in str(v).upper()), None)
                    if tone:
                        c.fill = PatternFill("solid", fgColor=VERDICT[tone])
                if isinstance(v, str) and v.startswith("http"):
                    c.hyperlink, c.font = v, Font(color="0563C1", underline="single")
            r += 1
        r += 1

    section("1. Who does what", ["role", "what it is", "who runs it", "what it never does"], m["overview"])
    section("2. What's inside each skill, and why (version 2.7 for the Director, 2.5 for the conductor: each part named by its file and section, not line numbers; "
            "the descriptions summarize the parts as first written at v2.1, and the files hold the current text)",
            ["skill", "file / section", "what's inside", "why it's there"], m["parts"])
    section("3. How one job runs, start to finish", ["step", "who", "what happens", "proof required"], m["flow"])
    section("4. What the research says (Exa, 2026-10-01)", ["our design choice", "what the research found", "verdict",
                                                            "source", "publisher", "date", "link"], rs["rows"], fill_col=2)
    section("5. Lessons for students", ["lesson"], [[t] for t in rs.get("takeaways", [])])
    section("6. Where no good source was found", ["design choice"], [[g] for g in rs.get("gaps", [])])
    section("7. Facts checked on this Mac (2026-10-01; the first 10 rows, sizes, versions and copies, re-measured 2026-10-02 at version 2.4; the two SKILL.md sizes and the version row again 2026-10-03 at Director 2.7 / conductor 2.5)", ["fact", "value", "where checked"], m["facts"])
    st = m.get("split_test")
    if st:
        section("8. Split test: old vs v2 Director + Conductor skills, same 8 situations, 3 runs each (2026-09-30)",
                ["arm", "runs and results", "situations passed (2 of 3 runs or more)", "median tokens per run (total)",
                 "median tokens per run (uncached)", "which runs failed", "source"], st["summary"])
        section("8a. The 8 situations, run by run (rounds 1, 2, 3)",
                ["#", "situation (prompt in prompts/N.txt)", "what it tests", "old", "v2", "median tokens, old → v2",
                 "source"], st["scenarios"])
        section("8b. The adopt rule, the verdict and how to read it", ["item", "what it says", "source"], st["how"])
    ws.freeze_panes = "A2"
    return r - 1


def main():
    ap = argparse.ArgumentParser(description="Build the Director + Conductor tab.")
    ap.add_argument("--book", default=BOOK, help="workbook to write (default: the repo master, then copy to ~/Documents)")
    a = ap.parse_args()
    wb = openpyxl.load_workbook(a.book)
    n = build_sheet(wb)
    wb.save(a.book)
    if a.book == BOOK:
        shutil.copy2(BOOK, COPY)
    print(f"{TAB}: {n} rows -> {a.book}" + (f" and {COPY}" if a.book == BOOK else ""))


if __name__ == "__main__":
    main()
