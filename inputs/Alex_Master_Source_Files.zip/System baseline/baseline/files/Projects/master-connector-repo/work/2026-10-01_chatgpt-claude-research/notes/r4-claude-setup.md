# R4: Claude setup for Composio, 1Password and skills

**Question:** For the Claude app (claude.ai web, Claude Desktop, phone) and Claude Code, what is the strongest way to connect Composio and 1Password, and how should skills be set up?
**As of:** 2026-10-01. Read-only research: nothing was installed, connected, enabled or edited.
**Method:** Exa through the Composio CLI (9 searches, 2 answers, 10 page reads covering 22 pages, about $0.10). Also used this session's own registry, plugin, skill and connector tools, plus read-only local checks. Reused today's notes: `work/2026-10-01_setup-playbook/notes/live-claude-*.md` and `parity-diff.md`, and `work/2026-10-01_master-sop/notes/onepassword-newest.md` and `composio-newest.md`.
**Labels:** SEEN = read live in this session · FILE = on disk · DOC = vendor docs (dates in Sources) · NOT_PROVEN = not checkable from here.

## Verdict per surface

**Claude app: claude.ai web, Claude Desktop (Chat and Cowork), phone**
- **Composio:** keep the custom connector at `https://connect.composio.dev/mcp`. It is already connected and reaches the same Composio org and logins as the CLI. Claude's directory has no Composio listing. Composio's own setup page says it is "pending publication on the Claude marketplace" and tells Claude users to add a custom connector. Nothing needs to change.
- **1Password:** the only official option is **1Password for Claude**, set up in Claude Desktop under Customize > Connectors > 1Password. It fills website logins and one-time codes through Claude in Chrome, and Claude never sees the password. It works only in Claude Desktop on a Mac and does not handle API keys. claude.ai web and the phone have no 1Password route, by design.
- **Skills:** keep "Code execution and file creation" on. Upload skills as ZIPs built from `~/.agents/skills`, never edited by hand. Uploaded skills follow the account to web chat, desktop chat, Cowork and Claude Code.

**Claude Desktop local config**
- Remove the two leftover local servers, `google-workspace-admin` and `ghl-oauth-crm`. They load only in desktop Chat, read keys from plaintext files, and both are replaced by proven Composio routes.

**Claude Code: terminal and the desktop Code tab**
- **Composio:** keep the CLI plus the `composio@composio` plugin, as installed now. That is Composio's own recommendation for Claude Code. The claude.ai Composio connector also arrives on its own; keep it as the fallback and don't add a third copy.
- **1Password:** use the `op` CLI. Interactive work signs in with Touch ID through the 1Password app; scripts use the connectors-sync service account; values are piped to their target, never printed. The official 1Password plugin is optional, and only useful if local `.env` files move into 1Password Environments.
- **Skills:** one delivery per skill. A skill needed everywhere comes from claude.ai, which syncs it one way into Claude Code. A Claude-Code-only skill stays as a symlink in `~/.claude/skills`. The terminal CLI is 2.1.251 with auto-update off, which is too old to sync; syncing needs 2.1.273 or later. Prune the 15 claude.ai plugins first, because plugins sync to the terminal too.

## What is installed now (read 2026-10-01)

| Item | State | Proof |
|---|---|---|
| claude.ai connectors | Composio (custom, `connect.composio.dev/mcp`, connected, 11 tools); Ref (custom, `api.ref.tools/mcp`, connected); visualize (Anthropic-hosted, `sandbox.claudemcpcontent.com`); Claude Docs (Anthropic, disabled in this session). No 1Password connector visible here, since it is desktop-only. | SEEN: `session_connectors_status`, `search_mcp_registry` |
| Composio connector type | Custom connector. Its registry entry has no description or icon, unlike directory listings, and no Composio directory listing came back for "composio". | SEEN: registry; DOC: Composio setup page and troubleshooting ("CUSTOM badge") |
| Composio identity | `composio whoami`: alex@increaseroas.com, org wearenumber1, enhanced controls off. Connector and CLI see the same custom toolkits and logins (project pr_JDtrNq9tUa_i). | SEEN today; `live-claude-code.md` §9 (16:06Z, log_22HYsjSsm9Q9) |
| Composio in Claude Code | CLI 0.4.2; plugin `composio@composio` 0.2.4 enabled; `~/.claude/skills/composio-cli` is a symlink to `~/.agents/skills/composio-cli` | SEEN, FILE |
| Claude Code MCP on disk | `~/.claude.json`: user scope `playwright` only; no project servers. `skillsmp` and `atlascloud` are live in this session only. | FILE, SEEN |
| Claude Desktop config | `mcpServers`: `google-workspace-admin`, `ghl-oauth-crm` (both stdio). No desktop extensions. | FILE |
| claude.ai plugins | 15 enabled. They bring 76 MCP servers into Code-tab sessions (4 connected, 60 need sign-in, 12 failed). | SEEN: `ListPlugins`, `session_connectors_status` |
| claude.ai skills | 30 enabled: 15 uploaded by Alex, 15 from Anthropic. Desktop sync cache for this account holds 35 folders (last change 2026-09-30 21:37). | SEEN: `ListSkills`; FILE |
| Claude Code skills | `~/.claude/skills`: 95 entries (79 symlinks into `~/.agents/skills`, 15 real folders, 1 file). No `~/.claude/skills/synced`. | SEEN |
| Claude Code version | Terminal 2.1.251, `autoUpdates: false`. Desktop Code tab gets claude.ai skills in-process as `anthropic-skills:*`. | SEEN |
| 1Password | 1Password for Mac 8.12.36; `op` 2.39.0; `/usr/local/bin/1password-mcp` present (root symlink); Labs "MCP Server" toggle state unknown | SEEN |
| Browser | Chrome installed; Claude in Chrome paired (`chromeExtensionEnabled: true`); Cowork's preferred browser is `built_in`, not Chrome | FILE |
| Anthropic plugin directory | Official **1Password** plugin, partner tier, listed 2026-09-24, not installed: one skill, one MCP server, one PreToolUse hook. No Composio plugin listed. | SEEN: `SearchPlugins` |

## Comparison

### (a) Composio

| Option | Surfaces | Write actions | Sign-in, and which Composio account | Secret values in the model's context | Verdict |
|---|---|---|---|---|---|
| Directory listing in Claude | – | – | – | – | **Not available.** Composio says it is pending; none shows in the registry or plugin directory. |
| **Custom connector** `https://connect.composio.dev/mcp` | claude.ai web, Desktop Chat, Cowork, phone (works there once connected on web or desktop), and Claude Code: the desktop Code tab gets it in-process; the terminal fetches it when signed in with claude.ai | Everything the connected logins allow. `COMPOSIO_MULTI_EXECUTE_TOOL` runs up to 50 tools per call, plus connection management and remote Python and bash. Composio Enhanced Controls is off, so Claude's per-tool permission is the only click. | OAuth in the browser to Composio, then choose the org. Anthropic holds the token. It acts as the member who signed in, in that org's Connect project. Proven: the same org, project and logins as the CLI. The signed-in user is inferred to be alex@increaseroas.com. | No provider keys; Composio keeps them, and only tool results come back. Never paste a key into chat to connect an app. | **Keep: the Claude app route.** |
| **Composio CLI + `composio@composio` plugin** | Claude Code only (terminal and Code tab) | Same tools through `composio execute`, plus `composio proxy` (raw API calls with the stored login), `composio link` and scripts | `composio login` in the browser stores a user API key in `~/.composio/user_data.json`. Account: alex@increaseroas.com, org wearenumber1. | Only if Claude reads the key file. The repo's `.claude/settings.local.json` allows `Read(~/.composio/**)`. | **Keep: the Claude Code primary route.** |
| `claude mcp add` for the same URL (OAuth, or an `x-consumer-api-key` header) | Claude Code | Same as the connector | OAuth, or a `ck_` consumer key | The key sits in plaintext in `~/.claude.json` if the header form is used | **Don't.** It duplicates the connector, and a local entry for the same URL hides the claude.ai connector. |
| SDK session MCP URL | Apps built on Composio's SDK | – | Per session | – | Not for this setup |

### (b) 1Password

| Option | Surfaces | Write actions | Sign-in | Secret values in the model's context | Verdict |
|---|---|---|---|---|---|
| **1Password for Claude** (connector; beta) | Claude Desktop on a Mac only, in tasks that use Claude in Chrome. Paid Claude plan; 1Password for Mac and its browser extension 8.12.28 or later. | None in the vault. It fills usernames, passwords and one-time codes, including Google or Facebook sign-in. No passkeys or other item types. | Connect in Customize > Connectors and authorize in the 1Password app (Touch ID). Each request is approved with biometrics, and access lasts for one task. | **Never.** Claude only learns which login it used. | **Use** for website sign-ins on the desktop |
| **1Password plugin** (Anthropic directory, partner; GitHub `1Password/1password-claude-plugin`) | Claude Code; Cowork. Its local MCP server and hook don't run in chat. | Create and rename Environments, add variables, mount `.env` files | 1Password app prompt per Environment; needs 1Password Settings > Labs > MCP Server | **Never.** It returns names only. | **Optional.** Only worth it if local `.env` files move into Environments. It can't read vault items. |
| `1password-mcp` added by hand (stdio) | Claude Code; Desktop Chat via local config | Same as the plugin | Same | Never | Use the plugin instead; 1Password recommends it over a hand-made entry. |
| **`op` CLI in Claude Code** | Claude Code | Full read and write on items. Touch ID mode acts as Alex across his vaults. The connectors-sync (read-only) and connectors-sync-rw tokens reach only the Connectors vault. | Touch ID through the 1Password app, or a service-account token from Keychain per call | **Yes** if a command prints a value (`op read`, `op item get --reveal`). **No** when values are piped (`op run`, `op inject`, `push_key_to_composio.py`). | **Use.** It is the only route that reaches vault items. |
| Composio `_1PASSWORD` toolkit | Any Composio surface | Create, update and permanently delete items | Key stored in Composio | **Yes**: Get Item returns every field | **Don't** |
| Community 1Password MCP servers | – | Varies | – | Some return values | **Don't** |
| Desktop extension (MCPB) | – | – | – | – | None found. The 1Password repo's tagline mentions MCPB, but the repo ships a Claude Code plugin. |

### (c) Skills

| Option | Where it works | Limits | How changes reach it | Relation to the other surface |
|---|---|---|---|---|
| **ZIP upload in the Claude app** (Customize > Skills > + > Create skill > Upload a skill) | Web chat, desktop chat, Cowork, Office add-ins, and Claude Code via sync. Phone: likely, but NOT_PROVEN. | Needs Settings > Capabilities > Code execution and file creation. The folder name must equal `name`. `name` is at most 64 characters (lowercase letters, digits, hyphens). `description` is at most **200 characters on claude.ai** (the spec allows 1,024). The ZIP holds the skill folder, not loose files. Anthropic gives no size or file-count number; secondary sources say 30 MB and 200 files. Custom skills are per user. | Re-upload each time | **One-way sync into Claude Code.** Terminal 2.1.273+ downloads into `~/.claude/skills/synced/` at start, then about every 10 minutes. The desktop Code tab gets them in-process (seen as `anthropic-skills:*`). Turn off with `syncClaudeAiSkills: false`. |
| **`~/.claude/skills`** (personal) | Claude Code local sessions: terminal, desktop Code tab, desktop scheduled tasks | The skill listing gets 1% of the context window. Each `description` plus `when_to_use` is cut at 1,536 characters. Least-used skills lose their descriptions first. | Picked up live, no restart | Never reaches claude.ai, Cowork or cloud sessions. If a local and a synced skill share a name, the local one gets `/name` and the synced one stays reachable as `/anthropic-skills:name`. |
| Plugin skills (Claude Code marketplace) | Claude Code | Named `plugin:skill` | Plugin update | – |
| Plugin added in the Claude app (uploaded file, or a marketplace from a GitHub repo) | Web and desktop chat (skills and commands), Cowork (also hooks, agents, local MCP), Claude Code terminal 2.1.273+ | Paid plans | Git push to the marketplace repo; Cowork checks for updates | One copy for every surface. NOT_PROVEN: private-repo access on a Max account, and one Anthropic page says plugins aren't used in chat (see Conflicts). |
| Project `.claude/skills` | Claude Code in that repo; cloud sessions of that repo | – | Git | – |

## Steps in order

Order matters because Claude Code pulls skills, plugins and connectors from the Claude account. Steps marked **Alex** are clicks in the Claude app; the browser route to claude.ai was denied, so an agent can't do them. Decision IDs (L04, S04, S10, S12) refer to `work/2026-10-01_setup-playbook/notes/parity-diff.md`.

**A. Claude app (web, desktop, phone)**
1. **Alex:** Settings > Capabilities: confirm "Code execution and file creation" is on. Proof: Customize > Skills is not greyed out.
2. **Alex:** Customize > Connectors: check that Composio shows the CUSTOM badge and is connected; change nothing. Remove Ref, which is already on his list. Visualize and Claude Docs are Anthropic built-ins.
   - Optional, his call: Composio > Tool permissions > "Always allow" is the fewest-clicks setting, and it also lets writes run without a click.
   - If Composio ever needs re-adding: + > Add custom connector, name `Composio`, URL `https://connect.composio.dev/mcp`, Connect, sign in as alex@increaseroas.com, choose wearenumber1.
3. **Alex:** Customize > Plugins: uninstall the plugins that L04 drops. Do this before step 9, because plugins sync into the terminal. One check first: in this session, the small-business plugin's Shopify server shows as connected (52 tools), while STATUS says Composio will be the only Shopify route.
4. **Alex, Mac:** 1Password for Claude.
   - Update the 1Password extension in Chrome to 8.12.28 or later.
   - Claude Desktop > Customize > Connectors > 1Password > Connect, then approve with Touch ID.
   - For sign-in tasks, make Cowork use Claude in Chrome. Its preferred browser is the built-in pane today, where 1Password can't fill.
   - Test on a low-risk login.
5. **Agent builds, Alex uploads:** skills.
   - Shorten the source descriptions in `~/.agents/skills` to 200 characters or less, so one copy fits both surfaces. This is a control-file change that needs Alex's approval.
   - Build each ZIP from `~/.agents` and replace the stale uploads (S04).
   - Upload the agreed set (S12), leaving out skills that can't work in chat (see Risks).
   - Copy `native-fix-research` and `hermes-boss-director` into `~/.agents/skills` first. Their only copies are on claude.ai and in the desktop sync cache.
6. **Alex, phone:** open a new chat, then + > Connectors: confirm Composio is listed and run one read-only Composio search. Check that an uploaded skill shows in the `/` menu.

**B. Claude Desktop local config**

7. **Agent (standing yes, replacements proven):**
   - Copy `claude_desktop_config.json` to `~/Backups/claude-config-2026-10-01/`.
   - Remove `google-workspace-admin` and `ghl-oauth-crm`, then restart Claude Desktop.
   - Proof: no new starts in `~/Library/Logs/Claude/mcp.log`.
   - The plaintext key files under `~/.cursor/mcp-servers/` follow parity-diff K03.

**C. Claude Code**

8. **Composio:**
   - Keep the plugin and the CLI. Run `composio upgrade`, then `composio whoami`, which should show alex@increaseroas.com and wearenumber1.
   - Don't add a separate MCP entry for `connect.composio.dev`.
   - After any future `composio login`, check that `~/.claude/skills/composio-cli` is still the symlink into `~/.agents`, since login installs its own copy of that skill.
9. **Update the terminal CLI** to 2.1.273 or later with `claude update` (auto-update is off). Do this only after step 3.
   - Then `/skills` should list the claude.ai skills under "claude.ai sync", and `/plugin` should show the synced plugins.
   - `/doctor` estimates the skill listing's context cost.
10. **Skills, one delivery per skill:**
    - If a skill is uploaded to claude.ai, remove its `~/.claude/skills` symlink, so Claude Code loads only the synced copy. If a skill is Claude-Code-only, keep the symlink.
    - Merge the 5 diverging real folders into `~/.agents` and symlink them (S10).
    - Proof: `/skills` lists each name once.
11. **1Password:**
    - Keep `op`: Touch ID for interactive work, the connectors-sync service account for scripts, values piped and never printed (the `push_key_to_composio.py` pattern).
    - Install the official 1Password plugin only if Alex moves local `.env` files into Environments; it needs 1Password Settings > Labs > MCP Server.
    - Never connect Composio's `_1PASSWORD` toolkit.

**Upgrade path (needs one pilot first):** put the "everywhere" skills in one private plugin in a GitHub marketplace repo, such as `increaseroasir/agents-home`. Add it once in Customize > Plugins > Add marketplace. After that, a git push updates web chat, desktop, Cowork and Claude Code with no re-uploads. Pilot with one skill to prove private-repo access, chat support and the phone before moving the rest.

## Risks
1. **Updating the CLI turns on two syncs at once.** Version 2.1.273+ brings claude.ai skills and claude.ai plugins into the terminal: today that is 15 plugins, 76 MCP servers and about 170 plugin skills. Prune first (step 3), or set `syncClaudeAiPlugins: false` before updating.
2. **Duplicate skills cost context and cause misfires.** A local and a synced skill with the same name both appear; the synced one becomes `anthropic-skills:name`. The listing gets only 1% of context, and over 300 skills are already visible, so descriptions get cut. The conductor and Director that Claude Code loads today are the older claude.ai copies, not `~/.agents` v2.1.
3. **The 200-character cap drives drift.** 95 of the 122 skills in `~/.agents/skills` have longer descriptions. The claude.ai copies of first-principles-speed-analyzer, integration-fit-and-source-of-truth, mission-intake-and-approval-gate and plain-english-repo-explainer carry shorter descriptions than their sources. Fix descriptions at the source. Odd case: event-fair-campaign and the four sales-* uploads exceed 200 characters, so the cap may apply only to new uploads (NOT_PROVEN).
4. **Some skills can't work in chat.** composio-cli needs the CLI; in chat, Composio comes through the connector. repo-conform, weekly-tuneup and others need Alex's repo or local scripts. Uploading them puts misleading skills into web, phone and Cowork.
5. **1Password for Claude is narrow.** It is beta, Mac only, website logins and one-time codes only, and it needs Claude in Chrome, while Cowork currently prefers the built-in browser. It does nothing for API keys.
6. **`op` can leak a secret into the transcript** if Claude runs a value-printing command. The rule "keys never in chat, files or logs" is model judgment only. An optional enforcement is a permission deny for value-printing `op` commands; that is a control-file change for Alex to decide. The CLI's `~/.composio/user_data.json` is a plaintext local key, and the repo settings allow reading it.
7. **"Always allow" on Composio tools** removes the last click before writes. Composio's Enhanced Controls is off, and claude.ai web and the phone can't show Composio's own approval prompts anyway.
8. **The Composio connector is a custom (unverified) connector.** If Composio later publishes a directory listing, don't run both, because that would duplicate the same tools. Switch only if the listing changes something.
9. **The desktop Code tab can't drop the claude.ai connector locally.** It receives connectors in-process, so MCP settings don't reach it; the only way to remove one there is to disconnect it on claude.ai. The terminal can toggle connectors per project in `/mcp`.
10. **Steps that depend on someone remembering:** re-uploading a skill after its `~/.agents` source changes (until the plugin path or a tune-up drift check exists), and checking the composio-cli symlink after a `composio login`.

## Conflicts
- **Plugins in chat.** The help article "Use plugins in Claude" (updated this week) says plugin skills and commands work in web and desktop chat. The undated Cowork guide says plugins aren't used in Chat. I went with the newer help article.
- **Description cap.** Anthropic's skills how-to sets 200 characters for claude.ai, but five longer descriptions are live on the account (see Risks 3).
- **Composio directory status.** This comes only from Composio's setup page, which I re-crawled today. Anthropic's registry and plugin directory agree: no Composio listing.

## NOT_PROVEN, and what would prove it
| Item | Access needed |
|---|---|
| The Code execution toggle is on | Alex: Settings > Capabilities. Indirect evidence: all 30 skills show as enabled. |
| Which Composio user the connector signed in as | Alex: Customize > Connectors > Composio. Inferred alex@ from the shared logins. |
| Composio connector and uploaded skills on the phone | Step 6 |
| 1Password extension version in Chrome; whether 1Password for Claude connects | Step 4 |
| Whether `syncClaudeAiSkills: false` also affects the desktop Code tab | One test after step 9 |
| Private GitHub marketplace on a Max account | The plugin pilot |
| Exact ZIP size and file limits | Anthropic doesn't state them; the 30 MB and 200-file figures are secondary |
| `op` with Touch ID inside the Claude Code sandbox | One run by Alex (earlier note: x509 failures are reported in the sandbox) |

## Sources (all read 2026-10-01)
- Composio setup instructions, Claude section with the pending-publication note: https://connect.composio.dev/api/onboarding/setup (undated; crawled live)
- Composio Connect, setup per client and troubleshooting: https://docs.composio.dev/docs/composio-connect (undated)
- Composio agent plugins (Claude Code uses the plugin and CLI): https://docs.composio.dev/docs/agent-plugins (undated)
- Composio plugin for Claude Code README: https://github.com/ComposioHQ/composio-plugin-cc (repo created 2026-04-08)
- Composio consumer and developer project boundaries, member-scoped logins: https://docs.composio.dev/kb/guide/consumer-project-boundaries-and-auth-selection (undated)
- Composio Claude setup page: https://composio.dev/claude (undated)
- Composio `_1PASSWORD` toolkit: https://docs.composio.dev/toolkits/_1password (toolkit version 2026-07-15; from onepassword-newest.md row 22)
- Get started with custom connectors using remote MCP: https://support.claude.com/en/articles/11175166-get-started-with-custom-connectors-using-remote-mcp (2026-08-11)
- Use connectors (surfaces, mobile, tool permissions): https://support.claude.com/en/articles/11176164-use-connectors-to-extend-claude-s-capabilities (updated this week)
- Connectors overview, platform availability: https://claude.com/docs/connectors/overview (undated)
- Claude Code MCP (claude.ai connectors in Claude Code, precedence, desktop in-process delivery): https://code.claude.com/docs/en/mcp.md (undated; crawled live)
- Claude Code skills (locations, synced skills, budget, `skillOverrides`): https://code.claude.com/docs/en/skills.md (undated; crawled live)
- Use skills in Claude: https://support.claude.com/en/articles/12512180-use-skills-in-claude (updated this week)
- How to create custom skills: https://support.claude.com/en/articles/12512198-how-to-create-custom-skills (2026-07-22)
- Create custom skills (200-character claude.ai cap, ZIP layout): https://claude.com/docs/skills/how-to (undated)
- Use plugins in Claude (surfaces, sync to Claude Code, marketplaces): https://support.claude.com/en/articles/13837440-use-plugins-in-claude (updated this week)
- Cowork, install plugins (conflict on chat): https://claude.com/docs/cowork/guide/plugins (undated)
- Get started with 1Password for Claude (Anthropic): https://support.claude.com/en/articles/15936181-get-started-with-1password-for-claude (2026-07-16)
- Use 1Password to sign in to websites with Claude (1Password): https://support.1password.com/1password-claude/ (2026-09-15)
- 1Password plugin for Claude Code: https://github.com/1password/1password-claude-plugin (repo created 2026-06-05)
- 1Password MCP server for Environments: https://developer.1password.com/docs/environments/mcp-server/ (undated)
- Skills launch post (skills across Claude apps): https://claude.com/blog/skills (2025-10-16)
- Secondary, ZIP limits only: https://github.com/Kaminoikari/product-playbook/commit/74d35a9357d7d2025a4d353697566d39e025b61c (2026-05-25); https://agentscamp.com/guides/skills/claude-skills-on-claude-ai-and-api (2026-07-18)
- Live tools in this session: `search_mcp_registry`, `session_connectors_status`, `ListPlugins`, `ListSkills`, `SearchPlugins`, `composio whoami`, `claude --version`. Raw Exa output: session scratchpad `r4/raw/` (not kept in the repo).
