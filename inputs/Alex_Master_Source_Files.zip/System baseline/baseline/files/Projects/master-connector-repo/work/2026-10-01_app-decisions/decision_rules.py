"""Pure rules for build_decisions.py, kept apart so a test can import them without loading the workbook.

open_step (W30, parity recheck c, 2026-10-03): an All connections row that is still on the plan. Its setup_step (column
L) names work not done yet, and its target_home (column K) doesn't end the route. App decisions keeps an app that has no
live route when any of its rows is one, as ADD TO COMPOSIO. Batch 12 marked Shopify's Claude app row removed and the tab
dropped Shopify without saying so, though its 1Password row (target 1Password) still plans the Composio route. Apps the
owner dropped stay out: their open steps (uninstall a leftover plugin, nothing to do) sit on rows whose target is Remove,
Removed or Leave off, or the step itself says done, dropped or off.
"""
import re

ENDS_ROUTE = ("remove", "leave off", "ignore")  # target_home prefixes that end an app's route (Remove, Removed, ...)
FINISHED = re.compile(r"(?i)(done|app dropped|dropped|off)\b")


def open_step(r):
    """True when this row's setup step is open and its target keeps the route (see the module docstring)."""
    step = (r.get("setup_step") or "").strip()
    target = (r.get("target_home") or "").strip().lower()
    return (bool(step) and step not in ("—", "-") and not FINISHED.match(step)
            and not target.startswith(ENDS_ROUTE))
