# spp-c17: making ChatGPT's Composio plugin ask before every write (Conductor, research only, 2026-10-01)

**Answer: yes, a setting exists. ChatGPT → Settings → Plugins → Composio → Permission → "Always ask".** Today it is "Allow read-only tools" (the Default). That should already ask before changes, but in the spp-c16 test one "Allow once" let the later draft create and trash through. Whether "Always ask" gives one prompt per write is NOT_PROVEN until a 2-write test (below). Nothing was changed.

## What is set today (seen read-only in the Conductor's own tab, closed after)
- **Settings → Plugins:** "Default permission: Allow read-only tools". The other menu options are "Always ask" ("Ask before reading or making changes") and "Allow low-risk tools" ("Automatically approve low-risk tools, but sensitive tools may be denied").
- **Composio's per-plugin setting** for the alex@increaseroas.com connection (Settings → Plugins → Composio → Permission) offers four choices:
  - Always ask;
  - Allow read-only tools (marked Default, selected);
  - Allow low-risk tools;
  - Allow all tools (marked Elevated risk).
- **The same page** shows the Composio skill switched on, "Connected on Oct 1, 2026" and developer Sampark Inc.
- **Other plugins listed:** Finances ("Allow read-only tools") and Superpowers (no permission row).
- **Composio side:** `composio whoami` reports `enhanced_controls_enabled: false`.
- **Screenshots**, under the Conductor session's tool-results/: `mcp-claude-in-chrome-blob-1790908229742-1hr2ku.jpg` (Plugins page), `…249546-pc3ag1.jpg` (default options), `…263112-yktt7x.jpg` (Composio page), `…275993-y9ror7.jpg` (Composio permission choices).

## Sources (read 2026-10-01)
- OpenAI Help, "Managing app permissions in ChatGPT", https://help.openai.com/en/articles/20001495-managing-app-permissions-in-chatgpt (Exa cached copy; the live crawl was refused with 403):
  - **Levels:** "Always ask: ChatGPT asks before reading app information or making changes"; "Allow read actions: ChatGPT can read without asking but asks before making changes".
  - **Defaults:** "Allow low-risk actions … applies when no account, workspace, app, or connection policy overrides it."
  - **Where to set it:** the default is under Settings → Plugins → Permissions. Per connected account, it's Settings → Plugins → the plugin → Connected accounts ••• → Settings → Permissions.
  - **Prompt buttons:** "Allow or Allow once: Approve the current action"; "Always allow … allow supported future actions without repeated prompts".
- OpenAI Help, "Connected apps in ChatGPT", https://help.openai.com/en/articles/11487775-connected-apps-in-chatgpt: "ChatGPT may ask for approval before reading information or completing an action."
- OpenAI Developers, "Define tools", https://developers.openai.com/plugins/plan/tools:
  - "Split operations when they have different permissions, safety risks, or confirmation requirements";
  - "`readOnlyHint` is `true` only when the tool cannot change state";
  - "Annotations do not replace server-side authorization … or confirmation for consequential actions."
- Composio, "Introducing Enhanced Controls (Beta)", https://composio.dev/content/introducing-enhanced-controls-beta (2026-07-01):
  - **Risk levels:** each tool in a supported app is tagged Read, Write or Destructive. The defaults are Always allow / Ask every time / Never allow.
  - **Server-side:** "Always allow" and "Never allow" are enforced server-side "and don't depend on your client".
  - **ChatGPT web:** "approval first actions are not supported in the web-version of these apps".
  - **Coverage:** supported apps are Gmail, Google Sheets, Google Calendar, Google Drive, GitHub, Notion, Slack and Outlook. The steps: dashboard.composio.dev → For You → Project Settings → Enable Enhanced Controls.

## Real-world reports (Exa, OpenAI Developer Community; read 2026-10-01, after Alex asked)
- **"Action Confirmation for Read only tool"** (2026-05-27), https://community.openai.com/t/action-confirmation-for-read-only-tool/1381879. A developer saw a confirmation on every call of a read-only tool. The reply marked Solved, from casey-chow, who writes "We're working on tuning this model":
  - the cards are "model-driven and make decisions based on the overall context of the conversation";
  - read-only is no automatic exemption.
  - **What it means here:** the default prompting is a judgment call by a model, not a fixed per-call rule. That fits spp-c16, where one card was followed by silent writes.
- **"`ui/notifications/tool-input` isn't sent unless the Plugin's Permissions is set to 'Always ask'"** (2026-09-17), https://community.openai.com/t/ui-notifications-tool-input-isnt-sent-unless-the-plugins-permissions-is-set-to-always-ask/1398347. A developer reports that ChatGPT runs plugin calls differently under "Always ask" than under the read or low-risk modes. Indirect support that "Always ask" takes a stricter path. No answer yet.
- **Older reports show the behavior moving over time:**
  - every MCP call needing Confirm/Deny in developer mode, https://community.openai.com/t/feature-request-always-allow-option-for-mcp-connectors-remove-constant-confirm-deny/1359246 (2025-09);
  - an internal app suddenly asking before read-only calls, https://community.openai.com/t/custom-internal-app-mcp-server-started-requesting-permission-to-run-all-read-only-tool-calls/1372934 (2026-01-30).
- **No split test or case study** on per-write approval for bundled tools turned up in 3 searches (community.openai.com, reddit.com, github.com, news.ycombinator.com and the open web). The 2-write test in the recommendation is the data point.

## Why the test's writes didn't prompt (reasoning, not proven)
- **One tool for everything.** ChatGPT decides "read" vs "change" per MCP tool, from its annotations (OpenAI "Define tools"). The Composio plugin sends every app action, reads and writes alike, through one general tool, "Multi Execute Composio Tools". So ChatGPT can't tell a draft create from a rules read. It prompted at the first Multi Execute call, which happened to be 4 reads.
- **"Allow once" lasted.** After it, the same answer's later calls through that tool (draft create, trash) ran without a new card. Whether ChatGPT scopes "Allow once" to the tool for the rest of the answer, or the later calls went through a tool marked read-only, is NOT_PROVEN. The chat's work log doesn't show per-call arguments.

## Recommendation (Alex's clicks; this play changed nothing)
1. **ChatGPT, about 30 seconds:** Settings → Plugins → Composio → Permission → select **Always ask**.
   - Optionally also Settings → Plugins → Default permission → **Always ask**, so any new plugin starts strict.
   - **Cost:** every Composio call asks first, reads included, so expect more clicks in ChatGPT.
2. **Prove it, 2 minutes (the Conductor runs it in its own tab after your click):** one ChatGPT web prompt that makes two writes: create a test draft, then trash it.
   - **Pass:** two approval cards, one per write.
   - **If only one card appears again:** ChatGPT can't give per-write approval for this plugin. Then nothing in ChatGPT stands between a tricked chat and a send. Keep ChatGPT for reads and drafts, and do sends from Claude Code or Codex, where the guard hook runs.
3. **Composio-side backstop (optional, Alex's call; it's a project security setting):**
   - **What:** Enhanced Controls with Write = **Never allow** on the supported apps. It's enforced server-side in every client, ChatGPT web included.
   - **Limit:** it doesn't cover our main write routes. custom_google_robot, the GHL custom routes and the other custom toolkits aren't on its list, and its "Ask every time" mode doesn't work in ChatGPT web. NOT_PROVEN: its effect on custom toolkits.

## Not done or not proven
- No setting was changed and no test was rerun. Both wait on Alex's click.
- Whether "Always ask" shows one card per write (step 2 settles it).
- Why one "Allow once" covered later writes (reasoning above).

## Result after Alex's yes (2026-10-01, 22:45–22:50 EDT; Conductor's own tab, closed after)
- **Setting changed (Alex's yes in the Conductor chat):** ChatGPT → Settings → Plugins → Composio → Permission went from "Allow read-only tools" (Default) to **"Always ask"**. "Reset to default" then appeared, and after a reload the Composio page shows "Permission: Always ask".
  - The account-wide Default permission was left at "Allow read-only tools"; Alex's yes covered the Composio setting only.
  - Screenshots: `…1790909032032-ew02qn.jpg` (before), `…1790909044698-l48ffg.jpg` (after), `…1790909061758-d3fu3h.png` (Composio page).
- **The 2-write test:** a new Work chat with the Composio chip, "Create Gmail Draft" (https://chatgpt.com/c/6abf1afb-cfe4-83e9-b761-f9f93dd0f07e). The prompt asked for a draft "approval test - delete me" with no recipient, then a separate later call to move it to Trash. Never send, two separate tool calls.
- **Approval cards: 1.**
  - That one card was for "Search Composio Tools", use_case "Get the IR notes app rules for using the Google robot to create and trash a Gmail draft". It was a read; I checked the details before Allow once.
  - With no further card, ChatGPT read the rules, **created the draft (a write)**, read it back and **trashed it (a write)**. Its answer: "Verified: created, then moved to trash in two separate tool calls … No recipient. Nothing sent."
- **Mailbox check (Conductor, Google robot, GET only):**
  - exactly 1 message with the subject, `1a0fa833026e9703`, created 22:48:16 EDT, labels DRAFT+TRASH, no To/Cc/Bcc (log_O8lwv7C5cI4R);
  - 0 in Sent (log_WWEuiI8pjsPk);
  - since the pre-test history point 5043754, TRASH was added only to this message (log_qaIiDygHReIX) and no SENT message was added (log_DfVWQkgdurOB).
- **Verdict: FAIL** on the pass rule (2 cards for 2 writes). Even on "Always ask", ChatGPT asked once per answer, at the first Composio call, and the rest of the answer's calls, writes included, ran without a card. That fits OpenAI's "model-driven" confirmation answer (Real-world reports above).
- **What follows:**
  1. ChatGPT stays reads and drafts only. Sends go through Claude Code or Codex, where the guard hook stops spend, client sends and deletes.
  2. The rule for Alex in ChatGPT: **one "Allow" approves everything ChatGPT does with Composio in that answer.** Read its plan line before allowing.
  3. Keep "Always ask": it guarantees a card before any Composio activity in an answer, reads included, at about one click per answer. "Allow read-only tools" could let a read-only answer run with no card. The two measured the same on writes, one card per answer.
  4. Server-side hard stop, if Alex wants one (his call): Composio Enhanced Controls, Write = Never allow, for the 8 supported apps. It doesn't cover custom_google_robot or the GHL custom routes.

## Update (spp-c18, 2026-10-01): the Composio backstop isn't available today
Composio dashboard → For You → Settings → General → Enhanced Control (BETA), seen read-only: "Enhanced Control is under construction. We've temporarily disabled it and will relaunch it in the future." The same page lists it as working with desktop apps and CLIs only (Claude Code, Codex, Cursor and their CLIs), and as not supported on Claude.ai or ChatGPT.com. So recommendation 3 above can't be used now. ChatGPT stays reads and drafts only.
