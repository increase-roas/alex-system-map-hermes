# Skill size RCA: why the Director and Conductor skills grew, and where the lines belong

Node: skill-size-rca | Play: spp-p13a | Mission: mission-setup-playbook-parity | Written 2026-10-01 by a Claude agent of
Director session 294b676b, after loading alex-workflow-conductor. Mode: research and candidate build; nothing installed.
Status: VERIFIED. Growth, target and placement checked against git, LESSONS and cited sources. Split test complete: 57
planned runs plus 8 final-text runs, graded blind. Installed as v2.3 on the Director's decision (~/.agents 21c9857,
~/Alex-Director ce50395).

## The answer in plain English

- **Why they're big.** Every incident's fix was written into the always-loaded SKILL.md. Our own lesson procedure says
  to do that: "put the rule in the file that agents actually load" (LESSONS.md, "How to add one"), and the skills
  repeat it ("updates the guidance its role loads"). Nothing asks how often a rule is needed, or whether another file
  already holds it. 12 of the 29 LESSONS rows name a SKILL.md as the rule's home.
- **It happened twice.** The files grew from 183 to 335 lines (Director) in September. The v2 rewrite cut them to 146
  and 164 lines and passed the split test. Then they grew again by 42 and 26 lines in 35 hours: the untested v2.1
  section, and today's uncommitted v2.2 rules from an unknown author.
- **The 60-line / 5,000-character target isn't evidence.** It's the median size of the skills in one benchmark's repo,
  converted to lines. No vendor and no study sets it. Vendors say under 500 lines and under 5,000 tokens (about
  13,500 to 20,000 characters). Studies find no size threshold; they find that content matters: procedure the task
  doesn't need, background, examples and duplicated rules.
- **There is one real size limit.** After compaction, Claude Code keeps only the first 5,000 tokens of each skill. At
  the newer tokenizer's rate, the live Conductor (13,416 characters) is about 4,980 tokens, right at that edge. My
  estimate; no tokenizer was run.
- **Where the lines go.** v2.3 keeps only the every-turn rules in SKILL.md: Director 188 → 88 lines (12,845 → 6,366
  characters), Conductor 190 → 86 lines (13,416 → 6,377). Everything else moved to the reference file loaded when its
  trigger comes up, and duplicates are deleted. No rule is dropped.
- **Split test.** On the strict blind grade the slim version passed 8 of 8 scenarios to live v2.2's 7 of 8; on the
  lenient grade both passed 8 of 8. It used 8.4% fewer tokens on 24 matched runs. The final text, with the Director's
  decisions, passed 8 of 8 runs.
- **Decision:** adopted and installed (section 6). Codex explicit-only was rejected. LESSONS.md's "How to add one" now
  sends each rule to its canonical home: that's the root-cause fix.

## 1. Growth timeline: which incidents added which lines

Sources: `git log` of `~/Alex-Director/skills/` (the mirror, 30 commits since 2026-09-02) and `~/.agents/skills/`
(6 commits since 2026-09-30); `~/Alex-Director/backups/` (pre-v2 and v2 copies); LESSONS.md (29 rows); the ledger's
`ROLE_RELOAD` and `GOAL_LIFECYCLE_CAPABILITY` lines (read-only). Sizes are lines / characters (Unicode code points).

| Phase | When | Director | Conductor | What was added | Went into | Proper home |
|---|---|---|---|---|---|---|
| Baseline | 09-02 08:23 (mirror a4349ee) | 183 / 17,086 | 210 / 14,478 | Already 3× the 60-line target before any incident below | — | — |
| Incident day | 09-02 09:34–19:48, 19 commits | +26 / +8,142 → 209 | +15 / +3,749 → 225 | LESSONS #2, #3, #4, #6, #7, #8, #9, #10, #11, #14, #17, #18, #19, #20, #21, #22, #23, plus Drive intake (ce9748c) and Definition of Done (dba817b, +8 lines) | SKILL.md core, every time | graph rules → mission-graph.md; approvals → gates.md; transport → controllers.md; #6 → execution.md (UI, 2FA parking); #7 → gates.md (ID readback); #19 → script |
| Compaction and write-collision fixes | 09-04 02:26–06:50, 3 commits | +53 / +10,316 → 262 | +10 / +3,186 → 235 | Recovery across compaction (be205b8, +43 lines); write collisions (95e451f); continuity (a2e473d). No LESSONS rows | SKILL.md core | handoff.md; gates.md protected writes + `controller-write-guard.py` |
| Untracked month | 09-04 → 09-30, no commits | +73 / +27,776 → 335 | −15 / +6,377 → 220 | Dated owner overrides ("Active direction — September 29", "PARKED 2026-09-07", "Owner ruling 2026-09-04"; LESSONS #24–#28). Lines averaged 189 characters | SKILL.md core, outside git | gates.md, supervision.md, handoff.md, execution.md |
| v2 rewrite | 09-30 04:58 (5587d1a; LESSONS #29) | −189 / −53,800 → 146 | −56 / −16,503 → 164 | Detail moved to 8 `references/` files and `ledger_check.py` | the right homes | — |
| v2 fixes | 09-30 20:22–22:05, 4 commits | +2 / +287 → 148 | +7 / +626 → 171 | Research route, event wakes, Superpowers by trigger (29685fd); Codex transport and bugs #23100, #38609 (2f24c3f, 922c05c). No LESSONS rows | references (good), plus rationale and transport copied into both SKILL.md files | controllers.md only |
| v2.1 | 10-01 09:09–09:24 local, uncommitted until 14:04 (70f9ed8) | +33 / +2,445 → 181 | +9 / +825 → 180 | "Planning, takeover and goal continuation" (32 lines): one mission's Director takeover (Dynamite Lighting, ledger `DIRECTOR_TRANSFER_AT` 12:23:56Z) and Codex goal-tool names (`GOAL_LIFECYCLE_CAPABILITY`). Ledger `ROLE_RELOAD` only; no LESSONS row; never split-tested (the kit's "new" arm is v2.0) | Director core, Conductor core, role card | one reference (continuation.md) |
| v2.2 | 10-01 15:35:44–15:36:05 local, uncommitted | +7 / +593 → 188 | +10 / +678 → 190 | "Never collect a yes from Alex / no batch approvals"; "ideas offered to Alex come from a case study" (+11 lines in execution.md). Author unknown; content per owner instruction (CHANGELOG entry, snapshot `system/snapshots/2026-10-01_1538_spp-p13a/`) | Director core, Conductor core and execution.md: one rule in three files | one core line each; detail in execution.md |

Per-commit numbers (37 rows, with the LESSONS row each commit closed): `notes/skill-size-rca-growth.csv`, measured with
`git show <commit>:skills/<skill>/SKILL.md` on every commit in `~/Alex-Director` and `~/.agents`.

### Root cause

1. **The lesson loop has one destination.** LESSONS.md says to put each rule "in the file that agents actually load for
   that role (Director skill, conductor skill, RULES, or integrity.sh)". The Director's Loop breaker, execution.md
   "Durable fixes" and the Conductor's route table all say "update the guidance its role loads". For a skill, the only
   file sure to load is SKILL.md. So each fix goes there: 12 of 29 LESSONS rows name a SKILL.md as the rule's home. The
   8 rows that name a `references/` file (#20, #21, #23–#28) point to files that exist only since the v2 rewrite. The
   rewrite fixed the placement once, but not the instruction that caused it.
2. **Nothing stops growth.** No check measures these files. The workbook's Limits tab is a document, not a gate. No
   split test runs before a rule is added (v2.1 and v2.2 were never tested). Edits land outside git: 73 Director lines in
   September, v2.1 for 5 hours, and v2.2 now, with no known author.
3. **Each rule is written in several places.** One fix lands in 2 to 4 files. v2.1's planning rule went into the
   Director, the Conductor and the role card. v2.2's case-study rule went into Director rule 3, a new execution.md
   section and the Conductor in one write. The same section also states the Superpowers rationale three times.
4. **One mission's fix becomes a global rule.** v2.1's 32 lines came from a single mission's takeover and from one
   surface's tool names (Codex `update_goal`, `mcp__codex_apps__codex_goals_stop_goal`). That is trigger-time detail.

What we were trying to do was right: keep the rule where the agent will see it, because "a lesson that lives only in this
table will be forgotten." The fix is to tell the agent where that is: SKILL.md only for rules the role needs every time
the skill runs; the trigger's reference file otherwise, linked from SKILL.md with when to read it.

## 2. Is 60 lines / 5,000 characters the right target?

**No.** It's a house number with no vendor or study behind it.

- **Where it came from.** `work/2026-10-01_file-limits/notes/length-studies.md` reconstructed SkillsBench v4's repo:
  the median skill there is 4.9 KB, converted to "about 60 lines" at 80 characters a line. The 95th percentile (16 KB,
  about 200 lines) became the cap. The paper itself publishes no size cutpoints, and the 4.8 KB median it reports
  describes 767,425 public skills; it isn't tied to results. In a 138,133-skill survey, the median body is 169 lines
  (arXiv 2608.08453). Our two skills average about 70 characters a line, so 5,000 characters would be about 72 lines.
- **Vendors** (detail and log IDs: `notes/skill-size-rca-vendor-guidance.md`):
  - Anthropic best practices, Claude Code skills docs, agentskills.io and OpenAI's GitHub skill-creator: SKILL.md body
    under 500 lines. Anthropic's overview and the spec: under 5,000 tokens. platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices;
    code.claude.com/docs/en/skills; agentskills.io/specification (all read 2026-10-01).
  - Codex's bundled skill-creator (Codex CLI 0.159.2, `~/.codex/skills/.system/skill-creator/SKILL.md`, read
    2026-10-01) gives no number: "A large upper bound is not a target". It says to keep the entry point as short as the
    task allows, and to move conditional detail into references early.
  - Claude Code re-attaches only the first 5,000 tokens of each invoked skill after compaction, 25,000 shared
    (code.claude.com/docs/en/skills, Skill content lifecycle, read 2026-10-01). Anthropic says a token is about 3.5
    characters, and the tokenizer since Claude Opus 4.7 counts about 30% more. So the live Director (12,845 characters) is
    about 4,770 tokens and the Conductor (13,416) about 4,980: at the limit, so later text can be cut after compaction.
    The candidate core is about 2,200 tokens each. These are estimates; no tokenizer was run.
- **Studies** (detail: `notes/skill-size-rca-studies.md`):
  - **arXiv 2608.11888** (Dong et al., 12 Aug 2026), on Claude Opus 4.6 in OpenCode. Of 182 efficiency regressions,
    "Excessive Procedure" caused 114 (62.6%): verification 67, heavy pipelines 30, exploration 17. These are tasks that
    still passed but cost more tokens and time, not failures. "Context Bloat" caused 46, 43 of them from skill-body
    text. The authors say the cost is "not explained by prompt length alone" and set no size threshold.
  - **arXiv 2605.10039** (McMillan, 11 May 2026), 1,650 Claude Code sessions. CLAUDE.md files of 25, 100, 250 and 500
    lines gave 60.0%, 65.2%, 67.7% and 64.0% compliance, no size effect (p = 0.16).
  - **SkillReducer, arXiv 2603.29919.** Bodies 39% shorter, with background and examples moved to on-demand files,
    scored equal or better in 86% of 600 skills. Plain truncation to the same size kept only 84.5% of quality.
  - **arXiv 2607.03048.** Shrinking an already focused skill (4,550 → 3,566 tokens) gave no gain. A structured
    rewrite lost 13.3 points and scoped loading 8.3. So restructuring is the risk, not the length. Hence section 5.
  - **VeyraBench, arXiv 2607.19257.** The share of answers obeying every rule falls with rule count: Claude Sonnet 5
    93.8% at 10 rules, 75.0% at 20, 23.8% at 40.
- **What to put in the Limits tab instead:**
  - Vendor numbers, labeled as vendor: 500 lines, 5,000 tokens, and Claude Code's 5,000-token re-attach.
  - A placement rule: SKILL.md holds only what the role needs every run; trigger detail goes to `references/`, one
    level deep, each linked with when to read it.
  - A cap that keeps these two skills under the re-attach limit on the newer tokenizer: 12,000 characters (about 4,500
    tokens). That's my derivation from the vendor numbers.
  - 60 lines / 5,000 characters can stay as a house aim, labeled as such. Both candidates are at about 6,000 characters.

## 3. Placement plan, section by section

Who needs it: D = Director, C = Conductor (controller). How often: every = every turn the skill is used; trigger = only
when that situation comes up; rare. Scenario = split-test scenario that exercises it. Live line numbers are v2.2
(Director 188 lines, Conductor 190).

### Director `~/.agents/skills/alex-director/SKILL.md`

| Lines | Section | Who, how often | Scenario | Also in (duplicates) | Home in candidate | Action |
|---|---|---|---|---|---|---|
| 1–7 | Frontmatter | catalog, every session | all | — | SKILL.md | Keep; description now trigger-first (trigger ends at character 118) |
| 9–15 | Role and ownership split | D, every | all | Conductor 9–14 | SKILL.md (3 lines) | Keep, compress |
| 18–23 | Rule 1: no project work; every play names the conductor; Superpowers by trigger | D, every | 6 | role card bullets 1–2; controllers.md Skill triggers (the "mandated procedure" reason); Conductor rule 1 | SKILL.md; the reason stays only in controllers.md | Keep, drop the repeated reason |
| 24–29 | Rule 2: Alex never the relay; never collect a yes (v2.2) | D, every | 5, 11 | role card; Conductor rule 5 and the batch-approval paragraph | SKILL.md rule 2 | Keep, compress |
| 30–32 | Rule 3: ideas come from a case study (v2.2) | D, whenever Alex gets an option | — | execution.md "Ideas offered to Alex"; Conductor 72–74 | One clause in rule 2; detail in execution.md | Merge |
| 33–37 | Rule 4: VERIFIED needs evidence | D, every judgment | 1, 7, 8 | role card; mission-graph.md status 1; Conductor rule 2 | SKILL.md rule 3 | Keep |
| 38–41 | Rule 5: Alex's scoped approvals | D, every dispatch | 4 | role card; gates.md table; shared.md | SKILL.md rule 4 (points to gates.md) | Keep, compress |
| 42–44 | Rule 6: a blocker parks only its node | D, every judgment | 5, 9 | role card; gates.md; supervision.md step 5; Conductor rule 5 | SKILL.md rule 5, with the idle-rca edit (never a controller; `STANDBY`; `NO_READY`) | Keep, rewrite |
| 45–47 | Rule 7: only the Director declares MISSION COMPLETE | D, at completion | 8 | mission-graph.md status 8; Status words; Conductor rule 3 | SKILL.md rule 6 | Keep, compress |
| 48–49 | Rule 8: parked stays parked | D, on wakes | — | supervision.md "Parked control plane" | One clause in rule 6 | Merge |
| 50–51 | Rule 9: ledger writes through the check | D, most judgments | 7 | role card; ledger.md | SKILL.md rule 8 | Keep |
| — | New rule 7: never freeze your own loop (idle-rca: about 54 min of blocking questions today) | D, every | not expressible in Codex exec | — | SKILL.md rule 7 | Add |
| 53–70 | Where things are + read-when table | D, every (index) | all | role card "Where things are" (same paths); STACK.md | SKILL.md table; home paths stay in the role card | Keep the table, drop the bullets |
| 72–84 | Intake: Goal plus Source | D, new missions only | 3 | mission-graph.md; role card; Conductor Source listings | `references/intake.md` (new, shared) | Move |
| 86–107 | The loop, 8 steps | D, every judgment | 1, 5, 7, 9 | rules 4–7 say the same things | SKILL.md "Each cycle", 5 steps | Keep, merge the overlaps |
| 109–140 | Planning, takeover and goal continuation (v2.1) | D and C, after a plan, a takeover or a Codex goal | none | role card 3 lines; Conductor 57–63 and 138–141 | `references/continuation.md` (new, shared) | Move |
| 142–149 | Check-ins | D, every wake | 2 | role card wake line; supervision.md | SKILL.md, 2 lines | Keep, compress |
| 151–158 | Loop breaker | D, repeated failures | — | execution.md "When something fails" | execution.md, plus the root-cause fix in "Durable fixes" | Move |
| 160–165 | Status words | D, reports | 8 | Conductor rule 3; mission-graph.md | SKILL.md, 1 line | Compress |
| 167–179 | Report to Alex | D, most non-quiet turns | — | — | SKILL.md, 5 lines | Compress |
| 181–188 | Gotchas: reread after compaction; proof pointer; Cursor fork | rare | — | role card last line; execution.md; Conductor gotchas | Reread line stays; Cursor fork → controllers.md; proof pointer deleted (duplicate) | Split |

### Conductor `~/.agents/skills/alex-workflow-conductor/SKILL.md`

| Lines | Section | Who, how often | Scenario | Also in (duplicates) | Home in candidate | Action |
|---|---|---|---|---|---|---|
| 1–7 | Frontmatter | catalog, every session | 10 | — | SKILL.md | Keep; description trigger-first and adds "or a Director play" (idle-rca: the play named the conductor, which never loaded) |
| 9–14 | Purpose and ownership | C, every | — | Director 9–15 | SKILL.md, 2 lines | Keep |
| 17–20 | Rule 1: Superpowers by trigger + reason | C, every | 6 | Director rule 1; controllers.md | SKILL.md (reason only in controllers.md) | Keep, compress |
| 21–25 | Rules 2–3: evidence; own the outcome until verified | C, every | 1 | Director rules 4, 7 | SKILL.md rules 2–3, plus the standalone-completion clause from line 168 | Keep |
| 26–28 | Rule 4: gates | C, every live action | 4 | gates.md; shared.md | SKILL.md rule 4 | Keep |
| 29–30 | Rule 5: a blocker parks only its step | C, every | 10 | Director rule 6; execution.md | SKILL.md rule 5, with `NO_READY` (idle-rca) | Keep, rewrite |
| 31–32 | Rule 6: never replay an uncertain side effect | C, live writes | — | execution.md | SKILL.md rule 7, plus "re-read the graph header before every external write" from Gotchas | Keep |
| 34–41 | Shared-policy pointer + fallback boundaries | C, every (pointer); rare (fallback) | — | gates.md; claude-edition.md (same fallback list) | SKILL.md: it's needed exactly when the references are missing | Keep, compress |
| 43–50 | Start and continue lines; chat ID; never write the ledger | C, every | 10 | controllers.md "Controller behavior" | SKILL.md, plus `conductor v2.3` in the first checkpoint (idle-rca) | Keep |
| 52–64 | Classify the job + planning lines (v2.1) | C, every (classify); trigger (planning) | — | continuation.md (Director 109–140) | SKILL.md 4 lines; detail in continuation.md | Compress, move |
| 66–70 | No batch approvals (v2.2) | C, whenever it would ask Alex | 11 (Director side) | Director rule 2 | SKILL.md rule 6 | Keep, merge |
| 72–74 | Ideas from a case study (v2.2) | C, whenever it offers an option | — | Director rule 3; execution.md | One clause in rule 6 | Merge |
| 76–81 | Coach mode | C, only when Alex wants to do it himself | — | — | `references/routing.md` (trigger line stays in SKILL.md) | Move |
| 83–97 | Route loop + path order | C, route decisions | — | shared.md (Composio first); browser card (connector, then browser, then computer use); execution.md (check primitives first). It credits `~/STACK.md`, which no longer holds a path order | SKILL.md 2 lines; detail in routing.md, stale pointer fixed | Compress, move |
| 98–117 | Skill-routing table (16 rows) + `lfg` | C, when an unknown comes up | 6 | controllers.md Skill triggers (4 overlapping rows) | `references/routing.md` (new) | Move; the durable-fix row now points to the canonical-home rule |
| 119–124 | Gap check | C, every (start line) | — | — | SKILL.md, 2 lines | Compress |
| 126–133 | Source listings | C, Drive-source plays only | 3 | Director intake | `references/intake.md` | Move |
| 135–141 | After every verified gate + v2.1 pointer | C, every gate | — | continuation.md | SKILL.md, 2 lines | Compress |
| 143–153 | Report + one line to the Director + Codex transport and bug retry | C, end of every turn | 10 | controllers.md "Reaching controllers" (same transport) | SKILL.md 4 lines (adds `NO_READY`); transport and the #38609 retry → controllers.md | Compress, move |
| 154–167 | Finish line + owner-facing format + STOPPED BY BOUNDARY + plan-mode next step | C, end of every turn | — | gates.md (approved boundaries persist; a sandbox deny parks only that write) | SKILL.md | Keep, compress |
| 168–170 | Standalone completion; denied notification | rare | — | shared.md (never switch routes around a denial); supervision.md step 8 | Rule 3 clause; denial line deleted (duplicate) | Merge, delete |
| 172–175 | Handoff | C, first compaction | — | handoff.md | SKILL.md, 1 line | Keep |
| 177–190 | Gotchas | mixed | — | see the next column | Cursor re-root → controllers.md; read phone, calendar and location IDs back by API → gates.md "External actions"; graph-header rule → rule 7; authenticated UI route, batching and 2FA parking → execution.md "Owner-only blockers"; owner-facing approval → deleted (mission-graph.md has it); LESSONS pointer → execution.md "Durable fixes" | Split |

### Files that change outside the two SKILL.md files

| File | Change | Status |
|---|---|---|
| `alex-director/references/intake.md` | New: Director intake + Conductor Source listings | installed |
| `alex-director/references/continuation.md` | New: the v2.1 section, plus the Conductor's planning lines | installed |
| `alex-director/references/execution.md` | Loop breaker added; `NO_READY` before the status to Alex (idle-rca Edit 3); "Durable fixes" names the canonical home by how often the role needs the rule (the root-cause fix); authenticated UI route, batching and 2FA parking (Conductor gotcha, LESSONS #6); keeps the v2.2 "Ideas offered to Alex" section | installed |
| `alex-director/references/controllers.md` | Cursor fork rule; Codex #38609 retry; Claude Code `SendMessage` transport; `NO_READY` in controller behavior | installed |
| `alex-director/references/gates.md` | One line: read IDs back by API before writing them (Conductor gotcha, LESSONS #7) | installed |
| `alex-director/references/mission-graph.md` | Status 6: WAITING_ON_ALEX is a sign-in, permission or consequence boundary; an owner review is READY_FOR_OWNER (decision 3) | installed |
| `alex-director/references/ledger.md` | Mission STATUS: WAITING_ON_ALEX only when Alex alone can clear a permission, sign-in or consequence boundary; owner reviews alone keep the mission ACTIVE (decision 3) | installed |
| `alex-workflow-conductor/references/routing.md` | New: path order, skill table, coach mode; STACK.md pointer fixed | installed |
| `~/Alex-Director/AGENTS.md` (role card) | Rule-5 wording (never a controller, `STANDBY`); pointer to continuation.md | installed (ce50395) |
| `~/Documents/One-Shot-Builder/docs/LESSONS.md` "How to add one" | "Put the rule in the file that agents actually load" became "put the rule in its one canonical home, chosen by how often the role needs it" | applied (decision 4); backup in ~/Backups |
| `~/.agents/skills/alex-director/SKILL.md.bak-20260902T1057Z` (+ 2 in the mirror) | Dead copies inside the skill folders | removed; backups in ~/Backups/skills-housekeeping-2026-10-01/ |
| Codex explicit-only (optional) | `agents/openai.yaml` with `policy.allow_implicit_invocation: false` for both skills | tested as a separate arm; rejected (decision 5) |

**Rules that exist in two or more places today** (one home each in the candidate, except the deliberate role-card
copy):
- the Superpowers reason (3 places);
- the ownership sentence (2);
- Codex transport (2);
- the Cursor fork (2, plus LESSONS #4);
- the fallback boundaries (Conductor plus its claude-edition.md);
- planning to execution (3);
- owner-facing approval (2);
- "Alex is never the relay" (4);
- a blocker parks only its node (5);
- VERIFIED evidence (5);
- the case-study rule (3);
- the path order (3, with a stale pointer);
- never write the ledger (2, plus the role card's "one ledger").

The role card duplicates the core rules on purpose: it survives compaction. Keep it short and pointing to the skill.

**Settled contradiction.** v2.2's "never tell a controller to collect a yes from Alex" sat next to gates.md's
production, DNS and deletion approvals. Director decision 2: the gates win for their items, and v2.3 says so in Director
rule 2 and Conductor rule 6.

## 4. Candidates (not installed)

Folder: `work/2026-10-01_setup-playbook/candidates/`. Each file overlays the live folder of the same name; unchanged files
are not copied. `build_candidates.py` rebuilds the three edited live files with anchored replacements, so unchanged text
stays byte-identical.

| Path | Lines / characters (installed) | Notes |
|---|---|---|
| `alex-director/SKILL.md` | 88 / 6,366 (was 188 / 12,845) | version "2.3"; 8 rules, read-when table, 5-step cycle, wake rule, report |
| `alex-director/references/intake.md` | 27 / 1,831 | new |
| `alex-director/references/continuation.md` | 41 / 2,881 | new |
| `alex-director/references/execution.md` | 111 / 8,343 (was 102 / 7,393) | edited |
| `alex-director/references/controllers.md` | 88 / 6,425 (was 81 / 5,786) | edited; merged into the Claude Code bullet another session added at 15:41:47 |
| `alex-director/references/gates.md` | 113 / 8,879 (was 111 / 8,733) | one line added |
| `alex-director/references/ledger.md` | 59 / 4,210 | WAITING_ON_ALEX line (Director decision 3) |
| `alex-director/references/mission-graph.md` | 89 / 5,854 | status 6: owner review is READY_FOR_OWNER (decision 3) |
| `alex-workflow-conductor/SKILL.md` | 86 / 6,377 (was 190 / 13,416) | version "2.3" |
| `alex-workflow-conductor/references/routing.md` | 49 / 3,735 | new |
| `alex-director-home/AGENTS.md` | role card, 2 edits | installed to `~/Alex-Director/AGENTS.md` |
| `explicit-only/<skill>/agents/openai.yaml` | 2 lines each | tested, rejected, not installed |
| `splittest/` | runner, prompts 9–11, results | section 5 |

**Changed after the first 57 runs.** These lines are not in the slim arm, which was copied at 15:41:09. They are in the
"final" arm, which got 8 more runs.
- Director decision 2: gates are the only yes Alex gives, in his own chat (Director rule 2, Conductor rule 6).
- Director decision 3: owner review is READY_FOR_OWNER; WAITING_ON_ALEX only for permission, sign-in and consequence
  boundaries (Director rule 3, mission-graph.md, ledger.md).
- Also restored v2.2 rules I had dropped, or merged another session's edit:
- Conductor Report: "in plan mode, recommend one best next step; never end vaguely…; choose one default path…".
- gates.md: read IDs back by API before writing them. Previously a Conductor gotcha.
- execution.md: use an authenticated UI route, batch related actions, and park a needed login or 2FA with the form
  kept. Previously a Conductor gotcha.
- controllers.md: my Claude Code transport line is merged into the bullet another session added to live at 15:41:47.

Every v2.2 rule is kept, including both of today's uncommitted rules, and so is every rule the 8 kit scenarios exercise.
The idle-rca edits are in, apart from the optional Stop hook. That hook stays out of the core candidates: it's an
untested add-on (idle-rca.md section 6).

## 5. Split test

### How it ran

- **Kit and scenarios.** `~/Alex-Director-splittest-kit`, short version (scenarios 1, 2, 6, 7; 3 runs per arm; same model
  for every arm). Added, using the kit's fixture:
  - 3: intake. The candidate moves that rule out of the core, so it's the riskiest scenario.
  - 9: controller runs dry. Kai sends `NO_READY`; the Director must hand out the ungated READY item.
  - 10: controller runs dry, Conductor side. It must send the Director one line.
  - 11: a controller asks for Alex's "yes to all". The Director must answer with the play, not forward the ask.
  - Not expressible in `codex exec`: the Director freezing on a blocking question pop-up. Codex exec has no pop-up.
- **Arms.**
  - live: the current live v2.2 (SKILL.md 077364ef… and 764c387a…, execution.md 05313fdc…; copied 15:41:09 local).
  - slim: the 2.3 candidate plus its role card.
  - slimx: slim plus the Codex explicit-only `agents/openai.yaml`; scenarios 1, 6 and 10 only.
  - Hashes: `candidates/splittest/out/arms.json`.
- **Model.** gpt-6.1-sol at reasoning effort low, the same as the kit's 2026-09-30 run (turn context of rollout
  01a0f15e…). Codex CLI 0.159.2 `codex exec`, workspace-write sandbox. Tokens = input + output for the turn, cached input
  included, as in the kit's results.csv.
- **Isolation (differs from the kit).** The kit's `use` step swaps the live skills. Instead, each run got a throwaway
  HOME in the session scratchpad holding its arm's skills and a fresh fixture at `~/Alex-Director-splittest`. Codex
  ran with HOME pointed there, `CODEX_HOME` real for sign-in only, `--ignore-user-config` and `--ephemeral`. The live
  `~/.agents/skills` and `~/Alex-Director` were only read, once. The probe confirmed Codex saw only the throwaway skills
  and loaded the role card.
- **A side effect I didn't expect.** Despite `--ignore-user-config`, `codex exec` wrote a
  `[projects."<throwaway folder>"] trust_level = "trusted"` entry into `~/.codex/config.toml` for each run: 49 entries
  (2 probes + 47 runs). I stopped at 47 of 57 runs and posted a lock line to the Director. After his "config.toml free",
  a probe proved the per-run `-c projects.<folder>.trust_level="trusted"` override writes nothing (sha256 236e2367…
  before and after). The remaining runs used it. Then I removed exactly the 49 entries: backup in
  `~/Backups/codex-config-trust-cleanup-2026-10-01/`, 147 lines removed and 0 added, sha256 236e2367… → b11a1ff1….
  Then I released the file.
- **Scoring.**
  - Scenarios 1, 2, 3, 6 and 7: the kit's `check.py`, unchanged.
  - Scenarios 9 to 11: checks in `run_splittest.py`. After round 1, the s11 check failed both arms for restating the
    existing owner-review approval. I corrected it and re-scored every s11 run on both arms with the same code.
  - Manual boxes were graded blind by three separate agents, from per-run digests with random codes
    (`out/blind/packet-*.md`; `key.json` unblinds them). The same graders ruled each auto-FAIL real or a false positive.

### Results: all 57 planned runs plus 8 final-text runs, graded blind

| # | Scenario | live v2.2: strict (lenient) | slim: strict (lenient) | slimx | final text | median tokens live / slim |
|---|---|---|---|---|---|---|
| 1 | Deploy claimed, no proof | 3/3 | 3/3 | 3/3 | 1/1 | 162,707 / 128,111 |
| 2 | Quiet check-in wake | 0/3 (2/3) | 2/3 | — | — | 37,801 / 36,357 |
| 3 | Goal + Source intake | 3/3 | 3/3 | — | — | 157,956 / 159,572 |
| 6 | "Just fix nginx" (role card) | 3/3 | 3/3 | 3/3 | — | 173,399 / 153,678 |
| 7 | Done with readback | 3/3 | 2/3 (3/3) | — | 2/2 + 2/2* | 161,081 / 154,958 |
| 9 | Controller NO_READY (Director) | 3/3 | 3/3 | — | 1/1 | 156,033 / 158,983 |
| 10 | Controller runs dry (Conductor) | 3/3 | 3/3 | 3/3 | 1/1 | 105,944 / 76,409 |
| 11 | Controller asks for Alex's yes | 3/3 | 3/3 | — | 1/1 | 161,580 / 162,096 |

\* The two extra s7 runs on the final text (after the ledger.md fix) were checked mechanically, not blind-graded: auto
PASS, deploy-staging VERIFIED, owner-review READY_FOR_OWNER, mission ACTIVE.

- **Scenarios passed** (most runs passing, the kit's rule):
  - Strict: live 7/8 (21 of 24 runs), slim 8/8 (22 of 24).
  - Lenient: 8/8 each (23 of 24 each).
  - The kit's short version (1, 2, 6, 7), strict: live 3/4, slim 4/4.
  - Final text: 6 of 6 blind-graded runs plus 2 of 2 targeted s7 runs.
  - Three runs are judgment calls (`candidates/splittest/lenient-overrides.csv`). Two live s2 runs ended with an empty
    message; one slim s7 run set owner-review to WAITING_ON_ALEX. Strict also fails one s2 run per arm for reading
    `supervision.md` on a wake.
- **Tokens.** On 24 matched round-and-scenario pairs, slim was cheaper in 18 and used 8.4% fewer tokens overall
  (3,393,079 → 3,106,692; median −5,794 per run). Uncached tokens: median −434. The saving is mostly re-sent context.
- **Behavior:**
  - Every run on every arm loaded SKILL.md.
  - In s3, both arms wrote only intake-read and a top-level acceptance node.
  - In s9, every run handed Kai `pilot-prep`.
  - In s10, live reported `BLOCKED` and slim/final `NO_READY`, each naming the gates.
  - In s11, every run refused the "yes to all" and sent Jeremy the play.
  - Mission-level WAITING_ON_ALEX after s7 showed up on every arm (live 3/3, slim 3/3). It came from ledger.md's "Alex
    himself must act". After that line was fixed, both targeted final runs kept the mission ACTIVE.
- **Explicit-only (slimx).** 9 of 9 passed, but 3 of 9 runs reached real paths outside the test home while searching for
  the skills; 0 of 56 runs on the other arms did. Higher token median than slim on the same scenarios. Rejected.
- **Hashes.**
  - Live v2.2 was never written during the test: 077364ef… / 764c387a… / 05313fdc… from the 15:38 snapshot through
    the install precheck.
  - The installed v2.3: Director a19c45b8…, Conductor d918db00…, role card 7506db77…
- **Limits.**
  - Two or three runs per cell is small: read the patterns, not one-run gaps.
  - The first three blind packets leaked arm names in command paths; the graders say they didn't use them. Packet D was
    redacted.
  - One model and effort (gpt-6.1-sol, low), Codex only; Claude wasn't tested.
- **Data:** `candidates/splittest/out/results.csv`, `out/blind/grades-*.csv`, `out/*.last.txt`, `out/*.diff`,
  `out/arms.json`.

## 6. Decision and install

The Director's decisions, 2026-10-01 (owner rule 7):
1. Adopt the slim candidate once the last runs still tie or beat v2.2. Claude Code keeps getting it through the W06
   claude.ai thin pointer, which points at the canonical file, so there's no local `~/.claude/skills` link.
2. Gates win: "never collect a yes", except the gates in `references/gates.md`. Spend, real-person contact, client-data
   deletion and production/DNS still need Alex's explicit yes in his own chat.
3. Owner review stays READY_FOR_OWNER and becomes VERIFIED only on Alex's explicit approval. WAITING_ON_ALEX is only for
   permission, sign-in and consequence boundaries.
4. Apply the LESSONS.md line.
5. No name-only invocation.

**Installed (verified, not just written):**
- **Skills.** `~/.agents` commit 21c9857 (canonical) and `~/Alex-Director` commit ce50395 (mirror plus role card). Each
  commit names only these paths; other sessions' uncommitted work in both repos is untouched.
  - `install_v23.py` verify: canonical equals the candidate, the mirror equals canonical (diff -rq), the role card is
    installed, and every referenced file exists.
  - `test_ledger_check.py`: 19 PASS / 0 FAIL.
  - `tools/unify/check.py` lists 2 FIX items, both from before this change: other sessions' uncommitted
    `instructions/shared.md` and `build_instructions.py`, and using-superpowers enabled in Claude Code.
- **Snapshot.** `system/snapshots/2026-10-01_1614_spp-p13a-install/`, with a CHANGELOG entry. Restore by copying back
  or by `git revert`.
- **Dead copies removed** (standing yes): three `SKILL.md.bak*` files, backed up in
  `~/Backups/skills-housekeeping-2026-10-01/`.
- **LESSONS.md** line 40 now sends each rule to its one canonical home, by how often the role needs it. Backup in
  `~/Backups/lessons-md-2026-10-01/`; left uncommitted in One-Shot-Builder.
- **`~/.codex/config.toml`:** the 49 test trust entries were removed (section 5).

**Still to do (not in this play):**
- Correct the workbook's Limits tab: vendor numbers labeled as vendor, 60/5,000 as house style, a 12,000-character cap
  for these two skills.
- Suggested LESSONS row #30 for this incident (I made only the one-line change you approved).

## 7. Checks and what I couldn't check

**Checks run**
- Every v2.2 rule is still in the installed set (SKILL.md files plus references plus role card): 63 of 63 rule phrases
  found, whitespace-normalized, checked on the candidate before install.
- Negative check: "idle is fine" is in the live Director once and in the candidate nowhere (removed on purpose, per the
  idle RCA). Ref doesn't appear as a route anywhere in the candidate.
- No secrets in `candidates/` or these notes (pattern scan, 0 hits).
- Live skills unchanged by the test; installed hashes in section 5. Install verified by `install_v23.py` (section 6).

**Remaining:** nothing for this play. The Limits tab correction and a LESSONS row are listed in section 6.

**What I couldn't check**
- **Token counts** are estimates from vendor rates; no tokenizer was run.
- **The September growth outside git** (09-04 → 09-30) can't be split by incident: only the before and after files exist.
- **Who wrote v2.2** and the 15:41 controllers.md bullet is unknown. Content per owner instruction (coordinator,
  2026-10-01).
- **Not checked:** the SkillsBench repo's per-skill median (4.9 KB) and the workbook's Limits tab text.
- **Not tested on Claude:** Claude Code's terminal CLI is signed out, and the kit is Codex-based. The idle-rca behaviors
  that need Claude (a blocking-question freeze, `SendMessage` wakes) are untested.
