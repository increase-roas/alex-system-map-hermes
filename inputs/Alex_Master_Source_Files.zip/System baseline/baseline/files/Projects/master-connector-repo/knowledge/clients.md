# Clients and who we may change

Updated 2026-10-01 (owner, in chat). AIs change settings only on current clients and Increase ROAS's own assets.

| Name | GA4 | Status | What AIs may do |
|---|---|---|---|
| GT Tree Experts (Central de Analisis) | account 222911631, property 309267716 | **Not a client.** Alex only has access | Nothing. Don't read for client work, don't change. 2026-10-01: retention was raised by mistake and restored to 2 months the same day |
| Natural Sanitation | account 186020260, property 256987299 | Alex's brother's company (sold). Keep | Treat as a client |
| Increaseroas account (increaseroas, Paradise Spas, Sun Pool & Spa, IncreaseROAS Master, Revstead Systems, Lone Star Spas) | account 384439939 | Own and client properties | Client work per each project's rules |
| Momentum School | account 347589515, property 480195223 | Unconfirmed | Ask Alex before changing |
| The Real Tree Co | account 398514128, property 542310270 | Unconfirmed | Ask Alex before changing |

## Live customers (Customer List > Renewal Tracker, read 2026-10-01)

Source: Google Sheet "Customer List" (1w1goAAqSpRwQN_dfhLOH16altV-1hykYF8G5w6JmRuM), tab Renewal Tracker, kept by Javar. 35 rows. Only company and account IDs are copied here; billing and contacts stay in the sheet.

| Company | Meta ad account | GHL location |
|---|---|---|
| Sammys Tree Service | act_423331853815124 | Et9pfZayYyF1TZX1QRH5 |
| TipLine Tree Service | act_1484701416616395 | hC357orJZTsHhwUozEyd |
| Geo tree Service | act_651409074031459 | yGB7yt082Plp9PNJkCMV |
| Integerity Lawn Tree | act_1092524971870729 | OrvXHgsjWkj03Imbx4Nh |
| Davis Tree | act_624464440016816 | 6OASWRVrMmd6zBZ898rU |
| Tree Scouts | act_540401115186296 | Q1V9eHYXiv2R7o9011zZ |
| Midland Tree | act_1217521176827433 | qzMjrJx9sgKcSiaZo1pz |
| Martinez Tree Service | act_855468499892069 | IAhg2oUnWsVrApg9otjP |
| Pro Tree Surgeons | act_1604041853978997 | VJ6JKkXWWHOSvYo8DAyF |
| Landa Tree Service | act_669006122166469 | JcsnNVGmK5n3GQmruPsz |
| Straight Cuts | act_1109034321314702 | NhkZ6nG1VwJttainDwq7 |
| United Tree Arkansas | act_1095279018729484 | 67uLSzhwzHsZLJFlZRpv |
| Upper Cumberland | act_1542419473355348 | tqfZD0vb5DlG1dYd0OqS |
| Jp Tree | act_1986122261803946 | r9nVYD3IWaNrSVzft0NO |
| Village Tree | act_1628608781594510 | 2xGlpr96JiazaXoieIKy |
| Mr Wilson | act_526534763194786 | bv2K84YSd6Q9P6ZmwPHA |
| Heavens Gates | act_1122728325877010 | QEHO5idv3PGN5veOaAVe |
| Advanced Tree Care | act_2021528351762369 | ls1NYBg2OGdbcFAkQ1Zm |
| TG Tree | act_25865843119739572 | gEQdEKQE53O93pCWB4t1 |
| M and B Services | act_1467267761040868 | t4mVi0GSz8ne4GSCfIzc |
| Meadows Tree Service | act_108512843292775 | Uuiq24Vno4XZbA75f1nH |
| Mckenley Tree | act_1190587785435425 | FnUV6DSsusCLAVdl7KmB |
| F and M Tree Service | act_609545794858816 | iIEJQ2Sw2BZLe7eZEMKj |
| Magnoiia Tree Service | act_1800383693889362 | JDC04MNMpkaDsTCodQJJ |
| Arbotex Tree | — | DTvszsIbzeSTVA8qKx3y |
| Bloomfield Services | act_800402589223761 | bO1Se0NoynH7QlCkShS1 |
| Acree Enterprises | act_916925733568706 | 3lNfVbW3dbI4YALaZjbK |
| Beaverjack | act_524416359471812 | 4OBDOIYbLmlORPJojNBC |
| Sun Pool | act_1058707430026024 | D0ywuQp8JHKsFZojDK5u |
| The Hot Tub Store | act_1600323927500466 | urpw8NL9kycXOWr5wPno |
| Paradise Spas | act_4013508225402510 | NpZCArkZIoHhOIl8Qjd1 |
| Douglas Tree Co | act_2105631500294208 | 8oNNX1f4gs3vYbfIqWtm |
| Tree Health | act_936322958402857 | sjzTIiQB82mMcC07FSzi |
| United Tree Florida | act_8449112815214248 | DIaE7DEV8jpRfdPF0N33 |
| United Tree Ohio | act_2202531643483784 | DIaE7DEV8jpRfdPF0N33 |

Not in the tracker: the other 268 GHL locations, Momentum School and The Real Tree Co GA4 properties. Treat as not live until Alex says otherwise; archiving or deleting any of them is client data, so ask.

## Other names our files use (added 2026-10-01, play spp-p32a)

Short names and one extra GHL sub-account that the workbook and repo files use. The student edition script
(work/2026-10-01_setup-playbook/scripts/student_edition.py) reads this table at build time and swaps each name for its
client's label; the real files keep them. An alias in `backticks` matches exact case only (the words are generic). Not
a permission list: who AIs may change is the tables above.

| Company | Also written as | Other IDs | Source |
|---|---|---|---|
| Paradise Spas | Paradise | | workbook Plan R3; ~/.agents/skills/meta-hammer-them/SKILL.md |
| Revstead Systems | Revstead | | workbook Projects R3, All connections R114 (45 cells) |
| Lone Star Spas | Lone Star | | workbook Plan R6, All connections R118 (33 cells); AGENTS.md Slack row |
| The Hot Tub Store | `Hot Tub Store`, `HOT_TUB_STORE` | | workbook All connections R124, GoHighLevel R13 |
| Sun Pool | Sun Pool and Supply | | workbook All connections R124, GoHighLevel R13 |
| GT Tree Experts | GT Tree | | workbook All connections R136, Tracking access R16 |
| The Real Tree Co | Real Tree Co, The Real Tree Service | | workbook Tracking access R15; "The Real Tree Service" added 2026-10-02 (spp-c4e scrub miss): it's the name in the Search Console property's domain (Tracking access R23, R40), matched to this client by name only. Confirm with Alex |
| New Season Tree Masters | New Season | | workbook All connections R115, R124 (a GHL sub-account with a PIT key; not in the Renewal Tracker) |
