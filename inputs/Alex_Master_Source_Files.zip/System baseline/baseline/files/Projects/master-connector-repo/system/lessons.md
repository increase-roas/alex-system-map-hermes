# Bounded relevant lessons extract; source line prefixes retained

240: - status: proposed
241: 
242: ### L-018
243: - lesson: When deciding how a Hermes agent (Javar, Javante, then the rest of Alex's agents) should work, target the Director and Conductor's whole proven operating standard, not one route: one common Composio connection under the agent's own role-scoped identity (never Alex's credentials or full access), the same maintained core rules and decision history plus the agent's own role, memory, customers and permissions, current optimized skills, research-first blocker handling, own-it-to-done execution with checkpoints, and behavioral proof that the agent acts this way; keep a working direct route only until its scoped replacement is proven, because the Director recorded Javar's direct Cloudflare MCP server as his final route and Alex corrected it twice the same day: first to one Composio connection per agent, then to the whole operating standard.
244: - target: skill Gotchas: hermes-team-setup and javar-add-tool (the agent standard); AGENTS.md Tools row for Javar agents
245: - source: owner, in chat 2026-10-03 (relayed live by the restoration owner)
246: - proof: the wrong decision was reversed before anything ran (play mha-cb3 never ran); the corrected route's live proof is pending (graph node agent-composio-scoped-route)
247: - worked_run: pending: mha-cz1 dispatched 2026-10-03
248: - count: 2
249: - evidence:
250:   - 2026-10-03 (second correction, relayed live by the restoration owner): Alex: "Hermes agents of mine should use same composio same reason the director controller are working so well. so all the reasons its workling well like not have 50 connectors but using composio and all connectors there. having then rules for blockers abt doing research, having their skills optimized and follow thebest practices etc. testing things etc. do you see my point?"; the Hermes graph's ACCEPTANCE was amended with the 5-part standard and nodes javar-operating-standard and javante-operating-standard
251:   - 2026-10-03: Alex: "i thought javar was supposed to have the same type of setup the director has. like 1 composio connection but javars access is specific same for javante"; superseded decision at run-log line 263; graph nodes agent-composio-scoped-route and javar-cloudflare-one-route (mission-hermes-agents-skeleton)
252: - first_seen: 2026-10-03
253: - last_seen: 2026-10-03
254: - status: candidate
255: 
256: ### L-019
257: - lesson: When writing a write-guard fence for a mission-graph node, add exactly one "## Node: <node-id>" section to that graph, pointing at the authorization file, before the controller's first acquire, because the guard refuses with mission_node_ambiguous when the section is missing.
258: - target: skill Gotchas: alex-director (references/gates.md, Protected writes)
259: - source: task failure
260: - proof: after the section was added, mha-wh2 acquired and completed both steps with guard receipts (2026-10-03T07:28Z)
261: - worked_run: work/2026-10-02_hermes-agents/notes/javar-reply-alert-webhook.md (section mha-wh2)
262: - count: 1
263: - evidence:
264:   - 2026-10-03: mha-wh2 step 1 acquire refused at 07:24:20Z (exit 4, mission_node_ambiguous, nothing written); the Director had written the ledger fields and the authorization file but no graph section; a Dynamite controller hit the same refusal reason at 00:15:12Z (cause not checked)
265: - first_seen: 2026-10-03
266: - last_seen: 2026-10-03
267: - status: candidate
268: 
269: ### L-020
270: - lesson: When a Bash command only records text about a pending Composio delete (accept.py, notes), don't name the delete script's path or its delete URLs in that command; point to the notes section instead, because the Composio guard reads any script a command names and refuses the whole command as if the delete would run.
271: - target: tool card: composio
272: - source: tool error
273: - proof: the same receipt, re-recorded without naming the script, passed the guard (run-log line 256)
274: - worked_run: run-log line 256 (2026-10-03)
275: - count: 1
276: - evidence:
277:   - 2026-10-03: the Director's accept.py for ccf-dc1 named the removal script in its evidence text; the guard stopped it at 07:13Z with codes CG-DUTN CG-MN8Z CG-4GYH CG-BQR5 CG-HN25; nothing ran
278:   - 2026-10-03: fixed in the guard itself by spp-p52a (agents-home commit 527f1e7, 66 tests, live smoke 2026-10-03; notes/spp-p52a-guard-hook.md); status stays for weekly-tuneup
279: - first_seen: 2026-10-03
280: - last_seen: 2026-10-03
281: - status: candidate
282: 
283: ### L-021
284: - lesson: When a pilot or test runs an agent's own CLI on its host from a temporary interpreter or folder, read back the agent's launchers (and anything else that names an interpreter) after the teardown and before calling the host clean, because the mha-s2 pilot on 2026-10-02 left both of Javante's Hermes launchers pointing at its temp interpreter, the mha-s3 teardown removed that folder without checking them, and any restart, crash recovery or Update would have left Javante down.
285: - target: skill Gotchas: hermes-team-setup (pilot teardown readback)
286: - source: task failure
287: - proof: fenced repair mha-lf1: both launchers back on the permanent interpreter, then one controlled restart of the gateway and the serve came back healthy (Telegram, A2A, 330 GHL tools)
288: - worked_run: run-log 2026-10-03 mha-lf1 line (notes/javante-f2-prep.md section mha-lf1)
289: - count: 1
290: - evidence:
291:   - 2026-10-03: mha-f2a's hermes config set exited 126 (launcher line 2 execs the mha-s2 temp folder's python3: No such file or directory); both launchers were rewritten 2026-10-02T23:51:51Z; the running gateway and serve started before that on the permanent interpreter (work/2026-10-02_hermes-agents/notes/javante-f2-prep.md, section mha-f2a)
292: - first_seen: 2026-10-03
293: - last_seen: 2026-10-03
294: - status: candidate
295: 
296: ### L-022 check.py doesn't watch Codex's model settings, so the app's effort picker flips them unseen (L18)
297: - what happened: the Codex app's effort picker rewrote ~/.codex/config.toml's `model_reasoning_effort` to "low" at 2026-10-03 01:57:52 EDT; the agreed target is "xhigh" (workbook AI app settings R20 and the R37 snippet), set back once already after the 2026-10-01 flip to "medium" (Alex: "u can go back up"). Nothing reported it: check.py's check 7 covers only Codex plugins (codex_plugins.py). Found by parity recheck c (L18 reopened).
298: - why it matters: a silent model or effort change alters every Codex answer, and this is the second flip in three days. The 8-hourly tune-up reads every check.py FIX, so a check there makes the next flip visible the same day.
299: - proposed fix: add check 8 to ~/.agents/tools/unify/check.py, read-only: parse ~/.codex/config.toml with tomllib and compare the 4 top-level keys `model`, `model_reasoning_effort`, `model_verbosity` and `model_reasoning_summary` with the agreed set ("gpt-6.1-sol", "xhigh", "medium", "concise"; AI app settings R20), printing `FIX: Codex model settings differ from the agreed set: <key> is <live>, target <want>` (these 4 keys hold no secrets). Keep the target in one home that only the check reads, for example a "model" block in ~/.agents/tools/unify/codex-plugins.json: putting the effort into build_instructions.py's CODEX_SETTINGS would make every build set it back, which is restoring "xhigh", Alex's call. Tests in test_codex_plugins.py's style: a config with effort "low" fails (red), the agreed one passes (green). Not applied in spp-p53a: that play may not edit ~/.agents.
300: - target: ~/.agents/tools/unify/check.py (check 8) and its target block; ~/.agents/tools/unify/test_codex_plugins.py
301: - source: work/2026-10-01_setup-playbook/notes/parity-recheck-2026-10-03c.md §4 (L18) and §9; workbook AI app settings R20 and R37; play spp-p53a
302: - first_seen: 2026-10-01
303: - last_seen: 2026-10-03
304: - status: proposed
305: 
306: ### L-023
307: - lesson: When explaining how to replicate a Director setup, distinguish its home workspace, its assigned business scope, and its writable shared resources; check recorded missions before describing its scope, because this Director's connector-named home contains work across connector consolidation, playbook/app parity, and Hermes agents. A separate home or target repo alone does not separate shared mission records and global settings.
308: - target: skill Gotchas: alex-director (project scope and replication explanations)
309: - source: owner correction, in chat 2026-10-03
310: - proof: bounded read of the Director mission headings, project/controller fields, canonical Claude pointer, and ledger/controller references confirms the broader scope and shared state paths; a second isolated team has not been created or tested.
311: - worked_run: explanation correction only; runtime replication untested
312: - count: 1
313: - evidence:
314:   - 2026-10-03, Codex restoration chat: Alex said, "you said the team is cooking on my connector setup but is that true? its doing a ton of different tasks right?" and clarified the idea of a duplicate working only on another repo from outside it.
315: - first_seen: 2026-10-03
316: - last_seen: 2026-10-03
317: - status: candidate
318: 
319: ### L-024
320: - lesson: When writing a time into a receipt, ledger field or graph cell, take it from `date -u` (or the tool's own stamp) in the same step instead of estimating, because on 2026-10-03 the Director wrote estimated times 1 to 4 minutes ahead of the real clock three times (08:24Z for 08:20Z, 08:45Z for 08:44Z, 09:01Z for 08:57Z) and had to correct the records.
321: - target: skill Gotchas: alex-director (receipts and ledger fields)
322: - source: task failure
323: - proof: each was corrected against accept.py's own stamp; later records use the clock
324: - worked_run: run-log 2026-10-03 lines 278, 283 and the spp-p51a line (graph cells corrected)
325: - count: 3
326: - evidence:
327:   - 2026-10-03 09:17Z: the spp-p52a phase 2 receipt said 'by 09:20Z' while the clock read 09:17:44Z; corrected in the graph cell the same minute
328:   - 2026-10-03 09:01Z: right after adding this lesson, the Director wrote LAST_RECONCILED_AT 09:03Z with a '(clock-checked)' label while the clock read 09:01:52Z; corrected the same minute
329:   - 2026-10-03: parity-recheck EVIDENCE and LAST_RECEIPT (08:24Z to 08:20Z), javante-operating-standard LAST_RECEIPT (08:45Z to by 08:44Z), partner-1password-isolation LAST_RECEIPT (09:01Z to by 08:57Z)
330: - first_seen: 2026-10-03
331: - last_seen: 2026-10-03
332: - status: candidate
