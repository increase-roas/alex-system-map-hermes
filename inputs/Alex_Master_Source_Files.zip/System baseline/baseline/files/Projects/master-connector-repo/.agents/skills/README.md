# Project skills

Skills only this project needs. Each one is a folder here: `.agents/skills/<name>/SKILL.md`.
This is a control file area: Claude changes it only with the owner's approval (rule 5 in
`AGENTS.md`).

## Who reads what
| Agent | Reads project skills from | Reads universal skills from |
|---|---|---|
| Codex, Cursor | `.agents/skills/` (this folder) | `~/.agents/skills/` |
| Claude Code | `.claude/skills/` (one link per skill, pointing here) | `~/.claude/skills/` (links to `~/.agents/skills/`) |
| Claude app (desktop, web) | uploaded zips only | uploaded zips only |

So every project skill lives here once, and `.claude/skills/<name>` is a link to it:
`ln -s ../../.agents/skills/<name> .claude/skills/<name>`. Never a second copy; copies drift.
`audit.py --fix` makes missing links.

The 7 universal skills (`intake-triage`, `research-with-sources`, `fan-out`,
`verify-before-done`, `capture-lessons`, `tool-card`, `weekly-tuneup`) are installed once in
`~/.agents/skills/` for every project. Don't copy them in here.

## When a project skill earns a place
- The same multi-step job happens in this project at least twice, and no global skill does it.
- One job per skill. 2 or 3 focused skills beat one big one; past about 4 per task, results
  drop, and "comprehensive" skills test worse than none.
- A tool's quirks go in its card in `tools/`, not in a skill.

## Rules for every skill
- Folder name equals `name`: lowercase letters, numbers and hyphens, 64 characters or fewer.
- `description` is 200 characters or fewer (the Claude app's upload limit): "Does X. Use when Y."
- Frontmatter uses only `name`, `description`, `license`, `compatibility`, `metadata`,
  `allowed-tools`.
- Body 150 lines or fewer, ending with a Gotchas section. Detail goes in `references/`.
- Name tools by their Composio slug or full MCP name. No keys, passwords or client secrets.

## Claude app upload (only if the owner uses the app)
1. Turn on code execution: Settings > Capabilities, "Code execution and file creation".
2. Build the zips: `python3 ~/.agents/skills/repo-conform/scripts/audit.py . --zips` writes one
   zip per skill (folder at the zip root) to `system/skill-zips/`.
3. Customize > Skills > "+" > Upload a skill. The universal skills need uploading once per
   account; project skills once per change. Start a fresh conversation to test.

## Third-party skills
Don't install skills you haven't read end to end, scripts included. Snyk found critical issues
in 13.4% of about 4,000 public skills (Feb 2026).
