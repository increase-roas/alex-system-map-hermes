#!/bin/bash
# Split test: old vs v2 Director/Conductor skills. Run from anywhere.
#   kit.sh setup            one time: build ~/Alex-Director-splittest, save a v2 copy
#   kit.sh use old|new      swap which skills are live (and the test home's AGENTS.md)
#   kit.sh start N          reset the test home for scenario N and copy its prompt
#   kit.sh check N          rule-based checks after the Codex reply
#   kit.sh log N RUN TOKENS Y|N   record a run (Y = all manual checks yes)
#   kit.sh report           pass counts and median tokens per arm
#   kit.sh status           which arm is live
set -eu
KIT="$(cd "$(dirname "$0")" && pwd)"
T="$HOME/Alex-Director-splittest"
S="$HOME/.agents/skills"
OLD="$HOME/Alex-Director/backups/pre-v2-2026-09-30"
NEW="$HOME/Alex-Director/backups/v2-2026-09-30"
arm() { cat "$T/.arm" 2>/dev/null || echo new; }

case "${1:-help}" in
setup)
  mkdir -p "$NEW/skills"
  if [ ! -f "$NEW/skills/alex-director/SKILL.md" ]; then
    cp -R "$S/alex-director" "$S/alex-workflow-conductor" "$NEW/skills/"
    cp "$HOME/Alex-Director/AGENTS.md" "$NEW/AGENTS.md"
  fi
  [ -d "$T/.git" ] && { echo "test home exists: $T"; exit 0; }
  mkdir -p "$T"; cp -R "$KIT/fixture/." "$T/"
  printf '.last_auto\n.arm\n' > "$T/.gitignore"
  cp "$NEW/AGENTS.md" "$T/AGENTS.md"; echo new > "$T/.arm"
  git -C "$T" init -q; git -C "$T" add -A; git -C "$T" -c user.name=kit -c user.email=kit@local commit -qm base
  git -C "$T" tag base; echo "ready: $T (arm: new)" ;;
use)
  a="${2:?old or new}"; src="$OLD"; [ "$a" = new ] && src="$NEW"
  [ -f "$src/skills/alex-director/SKILL.md" ] || { echo "missing $src/skills; run setup"; exit 1; }
  for sk in alex-director alex-workflow-conductor; do
    rm -rf "$S/$sk.splittest-tmp"; cp -R "$src/skills/$sk" "$S/$sk.splittest-tmp"
    rm -rf "$S/$sk"; mv "$S/$sk.splittest-tmp" "$S/$sk"
  done
  cp "$src/AGENTS.md" "$T/AGENTS.md"; echo "$a" > "$T/.arm"
  echo "live skills + test AGENTS.md now: $a"; [ "$a" = old ] && echo "Remember: kit.sh use new when done." || true ;;
start)
  n="${2:?scenario 1-8}"; cd "$T"
  git reset -q --hard base; git clean -fdq
  src="$OLD"; [ "$(arm)" = new ] && src="$NEW"; cp "$src/AGENTS.md" AGENTS.md
  if [ "$n" = 8 ]; then python3 - <<'PY'
from pathlib import Path
g = Path('mission-graphs/test-alpha.md'); t = g.read_text()
t = t.replace('| deploy-staging | yes | ACTIVE | build-01 | Jeremy | Staging URL serves new hero + pricing; HTTP readback attached | — |',
              '| deploy-staging | yes | VERIFIED | build-01 | Jeremy | Staging URL serves new hero + pricing; HTTP readback attached | inbox/alpha-deploy-readback.txt |')
t = t.replace('| owner-review | yes | BLOCKED |', '| owner-review | yes | ACTIVE |'); g.write_text(t)
l = Path('DIRECTOR_STATE.md'); s = l.read_text()
s = s.replace('build-01 VERIFIED (inbox/alpha-build-01.txt)', 'build-01, deploy-staging VERIFIED (inbox/alpha-deploy-readback.txt)')
s = s.replace('REMAINING: deploy-staging, owner-review', 'REMAINING: owner-review')
s = s.replace('Deploy projects/alpha to staging; return the staging URL and an HTTP readback showing hero + pricing.', 'Prepare the owner-review packet (staging link + before/after) for Alex.')
s = s.replace('T-ALPHA-P07', 'T-ALPHA-P08'); l.write_text(s)
PY
  fi
  git add -A; git -c user.name=kit -c user.email=kit@local commit -qm "scenario $n start" --allow-empty
  git tag -f scenario-start >/dev/null
  pbcopy < "$KIT/prompts/$n.txt" 2>/dev/null && c="copied to clipboard" || c="see $KIT/prompts/$n.txt"
  echo "Scenario $n ready (arm: $(arm)). Prompt $c."
  echo "Open a NEW Codex chat with $T as the working folder, same model every run, paste, send." ;;
check)
  python3 "$KIT/check.py" "${2:?scenario}" "$T" ;;
log)
  n="${2:?scenario}"; r="${3:?run}"; tok="${4:?tokens}"; m="${5:?Y or N}"
  auto="$(cat "$T/.last_auto" 2>/dev/null || echo NONE)"
  p=FAIL; [ "$auto" = PASS ] && [ "$m" = Y ] && p=PASS
  [ -f "$KIT/results.csv" ] || echo "time,arm,scenario,run,auto,manual,pass,tokens" > "$KIT/results.csv"
  echo "$(date -u +%FT%TZ),$(arm),$n,$r,$auto,$m,$p,$tok" >> "$KIT/results.csv"
  echo "logged: arm=$(arm) scenario=$n run=$r $p tokens=$tok" ;;
report)
  python3 - "$KIT/results.csv" <<'PY'
import csv, statistics, sys
rows = list(csv.DictReader(open(sys.argv[1])))
for arm in ("old", "new"):
    r = [x for x in rows if x["arm"] == arm]
    if not r: print(f"{arm}: no runs"); continue
    sc = {}
    for x in r: sc.setdefault(x["scenario"], []).append(x["pass"] == "PASS")
    passed = sum(1 for v in sc.values() if sum(v) * 2 > len(v))
    toks = [int(x["tokens"]) for x in r if x["tokens"].isdigit()]
    med = statistics.median(toks) if toks else 0
    print(f"{arm}: scenarios passed (majority of runs) {passed}/{len(sc)}; runs passed {sum(x['pass']=='PASS' for x in r)}/{len(r)}; median tokens {med:,.0f}")
    print("   per scenario: " + ", ".join(f"{k}:{sum(v)}/{len(v)}" for k, v in sorted(sc.items())))
print("Adopt v2 if it passes at least as many scenarios as old and uses fewer tokens; otherwise roll back (see SPLIT-TEST.md).")
PY
  ;;
status) echo "live arm: $(arm)"; md5 -q "$S/alex-director/SKILL.md" 2>/dev/null || true ;;
*) sed -n 2,10p "$0" ;;
esac
