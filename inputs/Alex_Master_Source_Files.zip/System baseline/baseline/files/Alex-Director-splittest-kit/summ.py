#!/usr/bin/env python3
"""Summarize finished runs: tokens, commands, files changed, auto result, final reply.
Usage: summ.py [id ...]   (default: all finished runs listed in progress.txt)"""
import json, sys, re
from pathlib import Path
O = Path.home() / "Alex-Director-splittest-kit/out"
ids = sys.argv[1:] or [l.split()[0] for l in (O / "progress.txt").read_text().splitlines() if l.startswith("r")]
for i in ids:
    use, cmds = {}, []
    for line in (O / f"{i}.jsonl").read_text().splitlines():
        try:
            e = json.loads(line)
        except Exception:
            continue
        if e.get("type") == "turn.completed":
            use = e.get("usage", {})
        it = e.get("item", {})
        if e.get("type") == "item.completed" and it.get("type") == "command_execution":
            cmds.append(it.get("command", "")[:110].replace("/bin/zsh -lc ", ""))
    inp, cached, out = use.get("input_tokens", 0), use.get("cached_input_tokens", 0), use.get("output_tokens", 0)
    auto = re.search(r"AUTO: (\w+)", (O / f"{i}.check.txt").read_text())
    fails = [l for l in (O / f"{i}.check.txt").read_text().splitlines() if l.startswith("FAIL")]
    status = (O / f"{i}.status.txt").read_text().split()
    print(f"==== {i} | total {inp+out:,} (in {inp:,}, cached {cached:,}, out {out:,}) | cmds {len(cmds)} | auto {auto.group(1) if auto else '?'} {fails}")
    print("files:", " ".join(status[1::2]) or "none")
    for c in cmds:
        print("  $", c)
    print("REPLY:", (O / f"{i}.last.txt").read_text().strip()[:1800])
    print()
