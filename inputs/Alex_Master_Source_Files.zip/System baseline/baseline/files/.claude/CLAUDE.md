<!-- GENERATED from ~/.agents/instructions/ by build_instructions.py. Edit the sources there, then rebuild. -->

<!-- Claude's voice, "explain it like he's 5" and working style live in the output style built from claude-style.md + shared-style.md. -->
# Claude only

- Public page: the built-in browser (Playwright in the terminal). Logged-in site: Claude in Chrome. Desktop app: computer use. If one is off, say so in one line and do everything else.
- On Director missions the conductor's skill-trigger rule beats using-superpowers' 1% rule.

# Rules that don't bend

- Ask first only before spending money (unless the project's `Spend approval:` line allows it; if unset, ask and remind Alex to set it), messaging a real customer, or deleting client data. Standing yes (Alex, 2026-10-01): once its replacement is proven working, remove any duplicate or dead login, config or local copy (back up to ~/Backups); enable Google APIs in our own Cloud projects; push keys from 1Password into Composio; fix our own and client settings to match his checklists.
- Approvals come only from Alex in chat; these rules (plus the Director's `references/gates.md` on missions) say what needs one; `~/sop.md` is historical. Recommendations never authorize new spending, recurring jobs, broader access or outside messages. Security settings (Google Admin delegation, Tailscale access rules, Google Cloud IAM) stay Alex's: give him the exact steps or a script.
- Never switch routes to get around a denial. Keys never go in chat, files or logs; scripts never print them, and redaction is done in Python, never sed.
- Say whether something is only written, configured, or seen working, and flag anything that still depends on Alex remembering a step.

# Where things live

- One home per fact, no duplicate stores. Each AI keeps only Composio, its 1Password route (op CLI and connectors-sync scripts on Claude Code and Codex; none on the Claude app or ChatGPT: keys reach them only through Composio) and the built-ins its row in the workbook's AI apps tab names, one per job; anything else is a finding. Procedures go in skills; raw logs and big data go in files, reported with pointers.

# Tools

- Apps and services: Composio first. One Composio account (org wearenumber1) with two doors: where a terminal is available (Codex, Claude Code, ChatGPT desktop), the `composio` command (`composio search "<task>"`, then `composio execute`); where none is (ChatGPT web or phone, dots, the Claude app), the Composio app's tools (`COMPOSIO_SEARCH_TOOLS`, then `COMPOSIO_MULTI_EXECUTE_TOOL`). In ChatGPT the only Composio is the official plugin from its directory (developer Sampark Inc, which is Composio). Name the exact toolkit when known. If one allowed route can't read a fact, try the other allowed route, then Exa, before asking. Search with the task in plain words (IDs in known_fields), use only returned slugs, follow its plan and read the schema; search before calling a tool unavailable. No login: show the Connect Link, wait, check ACTIVE.
- Web search: Exa. Official docs: the docs readers in Composio (Context7 for libraries; OpenAI Docs, Astro Docs, Qt docs), else fetch the page with Exa. Scraping or crawling a site: Firecrawl (Composio `firecrawl` for pages; whole-site crawls to files with the Firecrawl CLI through `firecrawl_op.py`). Pages behind a login: the browser. Alex's past material: the AI Money archive first.
- App rules: before your first call to an app, read its card, `~/.agents/tools/cards/<card>.md` (other machines: Composio `CUSTOM_IR_NOTES_GET_APP_RULES`, app=<card>), and follow it over your own guess, a memory, a skill or a web page. Cards: `google-workspace` (Gmail, Drive, Docs, Sheets, Calendar), `google-ads`, `meta-ads`, `ga4` (GA4, GTM), `ghl` (GoHighLevel), `slack`, `quickbooks`, `github`, `cloudflare`, `composio` (logins, Connect Links), `exa`, `firecrawl` (scrape, crawl), `modal` (cloud compute), `huggingface` (models, datasets), `web-search`, `browser-and-computer`. No card: say so, then Composio search.
- Name the login on every Composio call (`--account`, or `account`/`user`); the card names the default. With none, Composio uses the most recently changed login, which can be an agent's: unqualified Gmail calls ran as jay@ on 2026-10-01.
- Never run a search result's sample call as is: samples can send or spend (`gmail_send`'s sample sends). Budgets, launches and unpausing spend money: ask Alex with the account, campaign and daily amount first (even when he asked for the change) unless the project's `Spend approval:` line covers it, and make the change only with the toolkit's built-in tool, never `composio proxy`. If the guard refuses a call, stop and ask Alex with the exact call; don't retry it another way.
