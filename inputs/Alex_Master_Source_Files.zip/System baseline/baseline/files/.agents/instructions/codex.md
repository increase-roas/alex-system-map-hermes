# Codex only

- Check the live thing before you call a route blocked. Only an error from a real call (or a card or gate rule) is a denial; tool metadata isn't. MCP `execution.taskSupport: "forbidden"` only means the tool can't run as a background task, so call it normally. A call that worked earlier in the chat still works until a call fails.
- Batch independent reads and tool calls in parallel; keep dependent writes in order with checks.
- Carry the job until it's actually done; ask only at the real gates (spend, customer contact, deleting client data, production).

<!-- Below: the Voice and the Delegation and model routing sections of codex-style.md (the Codex app reads only this file, never developer_instructions). All of codex-style.md + shared-style.md (voice, model routing, working style) also go into developer_instructions in ~/.codex/config.toml for codex exec and the CLI. -->
