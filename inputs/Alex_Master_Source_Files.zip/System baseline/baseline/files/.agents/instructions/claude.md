<!-- Claude's voice, "explain it like he's 5" and working style live in the output style built from claude-style.md + shared-style.md. -->
# Claude only

- Public page: the built-in browser (Playwright in the terminal). Logged-in site: Claude in Chrome. Desktop app: computer use. If one is off, say so in one line and do everything else.
- On Director missions the conductor's skill-trigger rule beats using-superpowers' 1% rule.
