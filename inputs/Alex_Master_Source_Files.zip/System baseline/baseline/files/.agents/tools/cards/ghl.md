---
route: Composio toolkits custom_ghl_oauth_crm (CRM) and custom_ghl_command_builder (builds)
aliases: gohighlevel, highlevel, high level, crm, lead connector, leadconnector
index: GoHighLevel: Composio custom_ghl_oauth_crm for CRM (contacts, SMS, email, calls, opportunities; pass locationId); custom_ghl_command_builder only for workflows, funnels, forms, pipelines
tasks: GoHighLevel contacts, SMS, email, calls, opportunities, calendars, workflows, funnels, forms, pipelines
updated: 2026-10-02
---
# GoHighLevel: two routes only

Never use any other GHL route: local `npx @elitedcs/ghl-mcp`, the "Increase ROAS — GoHighLevel"
ChatGPT app, HighLevel's own MCP, Composio's `highlevel` or `highlevel_mcp`, or the old `ghl`,
`ghl-oauth-gateway` and `increase-roas-ghl` names.

## CRM: `ghl-oauth-crm` (Composio `custom_ghl_oauth_crm`)
- The Increase ROAS OAuth gateway: all 303 IncreaseRoas sub-accounts, every scope the app allows.
- Use it for all CRM reads and writes: contacts, conversations, SMS, email, calls and transcripts,
  opportunities, calendars, invoices, users, cross-account scans.
- Always pass `locationId`.
- Flow: `ghl_search_operations` → `ghl_describe_operation` → `ghl_execute_operation`
  (or `ghl_execute_read_operation`). `ghl.request` reaches any API path not named.

## Builds: `ghl-command-builder` (Composio `custom_ghl_command_builder`)
- GHL Command on Orgo OpenClaw. In claude.ai it may still show as "GoHighLevel".
- Use it only to build or edit workflows, funnels, forms and pipelines, and for workflow audits,
  cloning and account export. It covers only its registered locations (49 on 2026-10-01).
- Before any build step: `switch_location`, then `get_location` (pass `locationId` to both), and
  confirm the returned ID matches. If the account isn't registered or the ID differs, stop and report.
- `switch_location` changes one default location shared by every agent (AG47jEV5rVUrGLt5FlKO,
  Hot Tub Launch B2B, on 2026-10-01). Switch, act and confirm the ID in one turn; then, if the
  default changed, switch back to the "Previous:" ID the first reply names.
- Don't skip the switch. Tested 2026-10-01 (live test T6): Codex called `get_location` on Natural
  Sanitation without it and got 403 Forbidden; Claude switched first, the ID matched, `get_workflows`
  returned 139 workflows, and the default was restored. Transcripts: master-connector-repo
  `work/2026-10-01_setup-playbook/notes/transcripts/` codex-parallel-2/T6.jsonl and claude-conductor/T6.md.
- `ghl_find_tools` shows `execution.taskSupport: "forbidden"` on builder tools. That's MCP's
  "no background-task mode" flag, not a ban: `ghl_read` and `ghl_write` calls work (2026-10-02:
  9 builder reads in 40 minutes, then a 22-minute stall when the flag was read as a ban).

## When something fails
- A CRM action that fails on `ghl-oauth-crm`: report the error. Don't retry it through the builder
  unless it is a build task.
- Setup, keys and fixes: SOP tab of the connectors workbook. Master: `~/Projects/master-connector-repo/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx`; the `~/Documents` file is a generated copy.
