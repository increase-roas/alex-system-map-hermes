---
route: Composio toolkit custom_cloudflare_api (login ca_IUuu0MrmsQya) -> Cloudflare's own API connector mcp.cloudflare.com, account token from 1Password "Cloudflare API — Composio (account token)"
aliases: cloudflare, workers, wrangler, r2, d1, kv, pages, dns, zero trust, tunnel, cloudflare access, durable objects
index: Cloudflare: Composio custom_cloudflare_api = whole Cloudflare API (2,500+ endpoints) via SEARCH/EXECUTE/DOCS, full Read & Write account token, never expires
tasks: Workers, D1, KV, R2, Pages, DNS records, domains, Zero Trust and Access, tunnels, secrets, routes, cache, analytics on Cloudflare
updated: 2026-10-01
---
# Cloudflare: one route, the whole API

| Fact | Tested 2026-10-01 |
|---|---|
| Reach | 13 zones (domains) and 30 Workers in account a3f549867f040e13df33e5bd18f785f4 |
| Power | Account token with Read & Write on every permission group (all zones + entire account, incl. Account & Billing); created and deleted a KV namespace |
| Tools | `CUSTOM_CLOUDFLARE_API_SEARCH` (find endpoints in Cloudflare's API spec), `_EXECUTE` (run JavaScript calling `cloudflare.request({method, path, body})`; `accountId` is set), `_DOCS` |
| Keys | 1Password "Cloudflare API — Composio (account token)": `credential`, `account_id`, `r2_access_key_id`, `r2_secret_access_key`, `r2_s3_endpoint` (S3-compatible R2 access) |

## How to work
- SEARCH first to find the endpoint, then EXECUTE. One EXECUTE can chain calls and paginate.
- Deploying to production, deleting zones/Workers/buckets or DNS records that serve live sites: say exactly what changes first
  (preview deploys are the default, per the tracking checklist).
- Secrets for Workers go from 1Password by script (`wrangler secret put` or the API), never typed or printed.
- Why this one: Cloudflare's per-product connectors (bindings, builds, observability, docs) and Composio's 24-tool `cloudflare`
  toolkit are weaker; this connector covers every endpoint ([Cloudflare blog](https://blog.cloudflare.com/code-mode-mcp/)).
- Not routes anymore: Composio `cloudflare_mcp` OAuth login (removed 2026-10-01), Codex's six cloudflare servers, Cursor and
  Claude Cloudflare plugins, `wrangler` login on the Mac. Javar's Cloudflare Access tokens in 1Password stay (agent fence).
