---
route: Composio toolkit firecrawl (login firecrawl_che-aday, ca_s4u_SyGN6QGq), Firecrawl Personal Team of alex@increaseroas.com; whole-site crawls: ~/.agents/tools/connectors/firecrawl_op.py
logins: one login (firecrawl_che-aday = Alex's team; its key is 1Password Connectors item uuopqngw4ikpdmpvgnclx3eive, which the CLI wrapper also reads per run)
aliases: firecrawl, fire crawl, crawl a site, whole-site crawl, download a site, map a site, site urls, batch scrape, scrape js page, extract fields, page monitor, page changes, llms.txt
index: Firecrawl: Composio firecrawl for pages; site crawls: firecrawl_op.py to files; no firecrawl login
tasks: JS-heavy or click-first page reads, batch scrapes, a site's URL map, structured extraction, crawling a site to files, page-change monitors, credit checks
updated: 2026-10-01
---
# Firecrawl: Composio for pages, the CLI for whole sites

## Before the first call
1. **Route:** Web search and plain URL reads stay Exa (shared rule). Firecrawl jobs (JS-heavy pages, actions before
   reading, batches, URL maps, extraction): `composio execute FIRECRAWL_<TOOL> --account firecrawl_che-aday`
   (tools: `account: "firecrawl_che-aday"`). Whole-site crawls: `~/.agents/tools/connectors/firecrawl_op.py crawl <url>
   --limit <n> --wait -o <file>` (outside the Claude Code sandbox); report the file path.
   Not routes: `CUSTOM_FIRECRAWL_MCP_*` (disabled duplicate, delete waits on guard CG-KH45; never connect it),
   Firecrawl's own Claude or ChatGPT connectors, any Firecrawl MCP in an app config, the bare `firecrawl` command.
2. **Never:** `firecrawl login`, `init`, `setup`, `env`, `-k` -> they write the key to a file or add skills to every
   agent; use `firecrawl_op.py` (it refuses them). A crawl with no limit -> always set `--limit` / `limit` (default
   10,000 pages). Relative proxy paths -> `composio proxy https://api.firecrawl.dev/v2/<path> --toolkit firecrawl
   --account firecrawl_che-aday` (the toolkit's base is /v1).
3. **Ask Alex first:** a plan upgrade, credit purchase or auto-recharge (spend); a monitor or scheduled crawl he
   didn't ask for (recurring credits). Everything else on this card runs without asking.

## How to call
- Big job: `FIRECRAWL_CREDIT_USAGE_GET` first (free). Costs: scrape or crawl 1 credit/page, map 1/call, search
  2 per 10 results, JSON extraction +4/page, interact 2-7 per browser minute (docs.firecrawl.dev/billing, 2026-10-01).
- Page: `FIRECRAWL_SCRAPE` {url, formats: ["markdown"]}. Many: `FIRECRAWL_BATCH_SCRAPE`, then `..._BATCH_SCRAPE_GET`.
  URLs: `FIRECRAWL_MAP_MULTIPLE_URLS_BASED_ON_OPTIONS`. Fields: `FIRECRAWL_EXTRACT` or scrape with `json` + jsonOptions.
- No tool for interact, monitor, parse, research: proxy (above); chat apps use `COMPOSIO_REMOTE_WORKBENCH`
  `proxy_execute(method="GET", endpoint="https://api.firecrawl.dev/v2/monitor", toolkit="firecrawl")`.
- Site to files: `firecrawl_op.py crawl <url> --limit 50 --wait --progress -o work/<job>/notes/<site>.json --pretty`;
  one markdown file per page: `firecrawl_op.py x download <url> --limit 20 -y` (writes ./.firecrawl/).

## Facts (tested 2026-10-01)
| Fact | Value | Evidence |
|---|---|---|
| Reach | Personal Team: 1,000 credits a month, reset on the 13th; free plan, no pay-as-you-go (HTTP 402 when out); 2 concurrent | log_OXN-IPWOQBhx; queue-status via proxy |
| Power | 30 tools (scrape, batch, crawl, map, search, extract, agent, credits, llms.txt) + proxy to any api.firecrawl.dev path | scrape log_FiOIg1JFbxaJ; proxy /v2/monitor via CLI and workbench log_RmclNQbyIoPy |
| CLI | firecrawl-cli 1.25.1; key from 1Password each run; no key file on the Mac | crawl job 01a0f983-1fa4-749b-9a69-bdde29a22507 (3 pages) |
Why this route: master-connector-repo `work/2026-10-01_setup-playbook/notes/firecrawl-connector.md`.

## Failure and fix
| Symptom | Cause | Fix (name the next tool or step) |
|---|---|---|
| `Not authenticated. Run 'firecrawl login'` | bare `firecrawl` has no key | rerun through `firecrawl_op.py`; never `firecrawl login` |
| `firecrawl_op: 1Password read failed ... tls` | ran inside the Claude Code sandbox | rerun with the sandbox off |
| HTTP 402 | month's credits used up | stop; tell Alex (more credits = spend) |
| HTTP 429 | 10/min scrape, map, search; 2/min crawl, agent, interact | wait a minute, retry once |
| `No active connected accounts ... custom_firecrawl_mcp` | picked the disabled duplicate | the same job's `FIRECRAWL_*` tool |
