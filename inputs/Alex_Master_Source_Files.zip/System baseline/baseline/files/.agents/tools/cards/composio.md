---
route: Composio project wearenumber1 (alex@increaseroas.com); the CLI first on Claude Code and Codex, the hosted connector or app when the CLI can't run and on chat apps
logins: several toolkits hold more than one login (gmail family, slack, github, quickbooks, googleads, metaads); each app's card names its default
aliases: composio, composio cli, composio connect, connect link, toolkit, tool router, auth config, connected account, login, account, custom toolkit, key mover, proxy
index: name the login on every call (--account); never run a search sample unedited; budgets never via proxy
tasks: finding the tool for an app, connecting or fixing a login, running a tool, REST calls to Composio, custom toolkits, auth configs, moving a key from 1Password into Composio
updated: 2026-10-01
---
# Composio: one project, two ways in

## Before the first call
1. **Route:** Claude Code and Codex: the CLI (`~/.local/bin/composio search "<task in plain words>"`, then
   `composio execute <SLUG> --account <word id> -d '<json>'`); the hosted connector or app only when the CLI can't run.
   Claude app, Claude Desktop chat, Cowork, ChatGPT: the hosted tools (`COMPOSIO_SEARCH_TOOLS`, then
   `COMPOSIO_MULTI_EXECUTE_TOOL` with `account`). Same logins either way. Read the app's own card before its first call.
2. **Never:**
   - `execute` without `--account` on a toolkit with more than one login -> pass the card's default. The CLI otherwise uses
     the login changed most recently: Gmail ran as jay@ (2026-10-01), Slack can flip to Lone Star, GitHub to Javante.
   - a search result's sample call unedited -> rebuild it from the schema (`--get-schema`). Samples can send or spend:
     `gmail_send`'s sample sets `"draft_only":false`.
   - budgets, launches or unpausing through `composio proxy` -> the toolkit's built-in tool (proxy skips Composio's
     approval gate).
   - Composio's install one-liner or "Connect my agent" CLI prompt as written -> `composio login` only, or the installer
     with `COMPOSIO_INSTALL_PLUGINS=0 COMPOSIO_INSTALL_SHELL=none`: its `composio setup --target auto` re-adds the old
     Codex GitHub plugin v0.2.3 and its hooks (setup-playbook notes/composio-connect-agents.md §4).
3. **Ask Alex first:** `POST /api/v3/connected_accounts/{id}/refresh` (it sets a working login to INITIATED until he
   approves), deleting a working login, and anything an app's card gates (spend, client sends, client-data deletes).

## How to call
- Search with the task in plain words (IDs in known_fields), use only the slugs it returns, follow its plan and read the
  schema. Search before saying a tool is unavailable. No login: show the Connect Link, wait, check ACTIVE.
- Claude Code sandbox (tested 2026-10-01): `execute` works inside it (at most a cache warning); `search` and
  `--get-schema` fail with EPERM writing `~/.composio/tool_definitions`, so run those two outside the sandbox. Inside it,
  REST responses of 20+ items can arrive cut off.
- Full tool list: `GET /api/v3.1/tools?toolkit_slug=<slug>` or several create/update/delete searches with `--toolkits`;
  `~/.composio/tool_definitions/` only caches tools already called.
- REST from scripts: headers `x-user-api-key` (from ~/.composio/user_data.json), `x-org-id`, `x-project-id: pr_JDtrNq9tUa_i`;
  plain `x-api-key` with that key returns 401. Running a tool can cost money (`EXA_SEARCH` reports costDollars).
- Key mover: `~/.agents/tools/connectors/push_key_to_composio.py --item <1Password item> --toolkit <slug>`.

## Facts and quirks (verified 2026-09-30 to 2026-10-01)
| Fact | Value |
|---|---|
| Login list | `composio connections list` returns at most 50; the dashboard Connected tab has all |
| Connect links | `composio link <app> --no-wait` expires in minutes; the dashboard app page ("Connect for myself") is reliable |
| Defaults | Composio has no "set default"; `is_default` marks the newest login, so ignore it |
| Custom MCP with an API key | stored as `generic_api_key`; create the login with `POST /api/v3/connected_accounts` (state API_KEY), then run a read-only tool: Composio doesn't test the key |
| Google scopes | Google blocks scopes Composio's shared app isn't approved for ("This app is blocked"); that needs our own Google app |
| Meta, Google Ads | Meta connects with a system-user token; Google Ads asks for manager account 164-028-3674 |
| Breach | disclosed 2026-05-21; all our logins are newer (drill: Master SOP and Sources §7) |

## Failure and fix
| Symptom | Cause | Fix |
|---|---|---|
| Result belongs to the wrong person or company | no `--account` | rerun with the card's default login |
| `search` or `--get-schema` EPERM | Claude Code sandbox | run that one command outside the sandbox |
| Tool "not found" | stale slug or cache | `composio search` again; never guess a slug |
| No login for the app | not connected | show the Connect Link, wait, check ACTIVE |

No keys in this card: they live in 1Password and reach Composio only through the key mover.
