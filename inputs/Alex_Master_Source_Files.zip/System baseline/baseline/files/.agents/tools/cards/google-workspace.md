---
route: Composio toolkit custom_google_robot (login ca_vm6rcasgNEIk) -> hub route /google-robot/mcp, the tagging-admin Google robot acting as any increaseroas.com user (domain-wide delegation)
logins: custom_google_robot = one login, every increaseroas.com user via `user=` (default alex@); Composio gmail/googledrive/googledocs/googlesheets logins = Javar's (jay@) and Javante's (agent@) agents, not routes for anyone else
aliases: google, gmail, email, inbox, draft, reply, google drive, drive, google docs, docs, google sheets, sheets, spreadsheet, google calendar, calendar, slides, forms, contacts, google tasks, workspace, google workspace admin, workspace admin, password reset, users, groups
index: custom_google_robot, user= (default alex@); drafts via google_api POST users/me/drafts; never gmail_send or GMAIL_*
tasks: reading, drafting or sending email, searching a mailbox, Drive files, Google Docs, Google Sheets, calendar events, Slides, Forms, contacts, Google Workspace users, groups, password resets
updated: 2026-10-01
---
# Google Workspace: one robot, any user

## Before the first call
1. **Route:** Composio `custom_google_robot`, every call with `user` = the person whose mailbox, Drive or calendar it is
   (default alex@increaseroas.com; contact@ = Manny, anthony@ = Anthony). Admin calls run as alex@.
   Not routes: the Composio `gmail`, `googledrive`, `googledocs`, `googlesheets` toolkits. Their logins are the agents'
   (jay@ = Javar, agent@ = Javante), and an unqualified `GMAIL_*` call runs as the most recent one: `GMAIL_GET_PROFILE`
   returned jay@ on 2026-10-01 (Codex guard Run H).
2. **Never:** `gmail_send` (or `GMAIL_SEND_EMAIL`) for a draft -> `google_api` POST
   `https://gmail.googleapis.com/gmail/v1/users/me/drafts` with `{"message":{"raw":"<base64url RFC 2822>","threadId":"<id for a reply>"}}`.
   Composio search offers only `gmail_send` for "create a gmail draft", and its sample sets `"draft_only":false`, so a
   copied call sends the email (seen 2026-10-01).
3. **Ask Alex first:** email or calendar invites (`send_invites`) to a client, deleting client data, changing another
   person's account. Drafts, reads and Alex's own Docs/Sheets/Drive work need no ask.

## How to call
- Common jobs: the shortcut tools (`gmail_search`, `gmail_read`, `drive_search`, `drive_read`, `drive_upload`,
  `sheets_read`, `sheets_write`, `docs_read`, `calendar_events`, `calendar_create`, `list_users`).
- Anything else: `google_api` with the full REST URL (Gmail labels and filters, Docs batchUpdate, Sheets formatting,
  Drive permissions, Slides, Forms, Admin directory and reports).
- Draft: create with the call above, read it back with GET `.../drafts/{id}` (label DRAFT), then tell Alex it's waiting.
- Password reset: `google_api` PATCH `https://admin.googleapis.com/admin/directory/v1/users/{email}` with
  `{"password": "...", "changePasswordAtNextLogin": true}`; hand the password to the person directly, never in chat or a file.

## Facts (tested 2026-10-01)
| Fact | Value | Evidence |
|---|---|---|
| Reach | All 16 increaseroas.com users; read as alex@, contact@ and anthony@: Gmail, Drive, Calendar, Tasks, Contacts, Admin | live test T2 transcripts |
| Power | Created a Doc, a Sheet with a formula and a Gmail draft, then deleted them; created and deleted an Admin group | card tests 2026-10-01 |
| Drafts | `google_api` POST drafts made the draft (label DRAFT), GET read it back, POST `.../messages/{id}/trash` trashed it; 0 sends | master-connector-repo `work/2026-10-01_setup-playbook/notes/transcripts/` claude-conductor/T2.md, codex-parallel-2/T2.jsonl |
| Login | Never expires, no clicks: service account tagging-admin (client 112417209265494842557), 39 delegated scopes; key in 1Password "Google service account — tagging-admin", hub token in 1Password "MCP Google robot token" | notes/fix-keys-2.md |

## Failure and fix
| Symptom | Cause | Fix |
|---|---|---|
| A Gmail call answers for jay@ or agent@ | the Composio `gmail` toolkit was used | redo it with `custom_google_robot` and `user=` |
| 403 on a user's data | that scope isn't delegated | tell Alex which scope; Admin console delegation is his |
| Draft has no thread | missing `threadId` | read the original with `gmail_read`, pass its `threadId` |

Still to remove (Alex): the Claude app's built-in Gmail, Drive and Calendar connectors.
