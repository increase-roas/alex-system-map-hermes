---
route: Composio toolkit exa (login exa_beode-vain), the one way in for every AI; Claude's Exa connector and local exa servers are not routes
aliases: exa, web search, search the web, semantic search, companies like, people search, lookalike, find pages, websets, exa agent, research, read a url
index: Exa: Composio exa for web search and page reads (EXA_SEARCH, EXA_GET_CONTENTS_ACTION, EXA_ANSWER run freely); agent runs, research and Websets follow Spend approval
tasks: web search, current facts and news, reading a URL, companies or people "like X", niche topics, building a list or table from the web
updated: 2026-10-01
---
# Exa: one route, through Composio

Shared rule: web search is Exa. Product or API docs go to the Composio docs readers first (`CUSTOM_CONTEXT7`,
`CUSTOM_OPENAI_DOCS`, `CUSTOM_ASTRO_DOCS`, `CUSTOM_QT_DOCS`), an Exa fetch only if no reader covers it. Login pages:
`browser-and-computer`. If Exa fails: `web-search` (the built-in fallback).

| Tool (20 in the toolkit, Composio v3.1 API, 2026-10-01) | What it does | Approval |
|---|---|---|
| `EXA_SEARCH` | semantic search with optional text, highlights or summary per result | runs freely |
| `EXA_GET_CONTENTS_ACTION` | reads the content of known URLs | runs freely |
| `EXA_ANSWER` | cited answer to a clear question | runs freely |
| `EXA_CREATE_AGENT_RUN` / `EXA_GET_AGENT_RUN` | Exa Agent: multi-step research or enrichment into rows | Spend approval line |
| `EXA_CREATE_RESEARCH` / `EXA_GET_RESEARCH` | async research report with sources | Spend approval line |
| `EXA_CREATE_WEBSET` and the Webset tools | saved, refreshable lists with enrichment and monitors | Spend approval line |

Tested 2026-10-01: `EXA_SEARCH` answered through Composio.

## Costs (Exa pricing page, Sept 2026)
- Search $7 per 1,000 requests; contents $1 per 1,000 pages; answer $5 per 1,000.
- Exa Agent per run: minimal $0.012, low $0.025, medium $0.10, high $0.50, xhigh $1.00. `auto` is metered with a $5
  default cap; beta `max` has a $20 cap. Claude's permissions have no spend cap, so per-call approval is the gate.

## How to work
1. Search with a descriptive sentence, not keywords: describe the page you want. Add a category (company, people,
   news, publication, personal site) when it fits. Try 2 to 3 different angles, not synonyms.
2. Fetch the best hits with `EXA_GET_CONTENTS_ACTION` and verify them; results are similarity, not truth.
3. A list or table: `EXA_CREATE_AGENT_RUN` with an output schema, then poll `EXA_GET_AGENT_RUN`. Leave effort out
   (it defaults to low) unless Alex approves more depth.
4. Hundreds of known rows to enrich: a script against the Exa API, not repeated calls. Bulk searching runs in
   `fan-out` subagents (3 to 5 searches each), saved to `work/<job>/notes/`.

## Quirks
- Exa is embedding-based: Boolean operators and keyword lists work poorly.
- Don't quietly swap agent-shaped work (list building) to plain search; say so if you do. Call agent results
  "best-effort discovery" unless coverage was checked.
- Old notes may name the removed Exa connector tools (`web_search_exa`, `web_fetch_exa`, `agent_run`); use
  `EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION` and `EXA_CREATE_AGENT_RUN`.

## Failure and fix
| Symptom | Cause | Fix |
|---|---|---|
| `EXA_GET_CONTENTS_ACTION` fails on a page | blocked or dynamic page | built-in web fetch, then the browser |
| Results look generic | keyword-style query | rewrite as a sentence describing the target page |
| Exa tools missing | Composio exa login not active | `composio link exa`, or tell Alex |
