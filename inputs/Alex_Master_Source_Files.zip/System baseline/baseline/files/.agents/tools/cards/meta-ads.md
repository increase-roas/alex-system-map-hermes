---
route: Composio toolkit metaads (login ca_7i7CdMbStKc9), system user "Manus" of IR Business Manus App, key from 1Password "Meta Ads — system user token (IR Business Manus App)"
aliases: meta, facebook ads, fb ads, instagram ads, meta pixel, capi, conversions api, events manager, dataset
index: Meta Ads: Composio metaads system user (57 ad accounts, never expires; CAPI via SEND_CONVERSION_EVENTS); spend follows the project's Spend approval line, unset = ask
tasks: creating or changing Meta campaigns, ad sets, ads, creatives, audiences, budgets, pixels and datasets, Conversions API events, Events Manager checks
updated: 2026-10-01
---
# Meta Ads: one route, the system user

| Fact | Tested 2026-10-01 |
|---|---|
| Reach | 57 ad accounts (`METAADS_GET_AD_ACCOUNTS`), same as the `meta` CLI. System user, `expires_at` 0 |
| Permissions (debug_token) | 22, incl. ads_management, ads_read, business_management, leads_retrieval, attribution_read, page_events, pages_manage_ads, pages_read_engagement, instagram_basic |
| Built-in tools (65, full list via `composio search --toolkits metaads`) | Campaigns, ad sets (`METAADS_READ_ADSETS`, `CREATE_AD_SET`), ads (`CREATE_AD`, `LIST_ADS`), creatives, images, custom audiences, custom conversions, insights (`GET_INSIGHTS`), pixels (`LIST_AD_ACCOUNT_PIXELS`, `GET_PIXEL_EVENT_STATS`), Conversions API (`SEND_CONVERSION_EVENTS`) |
| Everything else | `composio proxy https://graph.facebook.com/v23.0/<path> --toolkit metaads --account ca_7i7CdMbStKc9` (answered `me`) |

## How to work
- Spend (launch, unpause, budget up) follows the client project's `Spend approval:` line; unset means ask Alex with account,
  campaign and daily amount, and remind him to set the line. Change budgets with the built-in tools, not proxy.
- Tracking checklist (sources/2026-10-01_universal-site-master-checklist.md, Parts 2.5 and 5): one dataset per site; browser pixel
  and CAPI share the server's event_id; Automatic Events and Automatic + manual Advanced Matching ON; never a `test_event_code` in
  server config; event match quality 8+.
- Javar agents keep their fenced `javar_meta` route. Everyone else uses this one.
- Never use the expired Composio Meta logins (`metaads_bugi-thrimp`, `metaads_uncord-taken`) or the 1Password tokens
  "Meta Ads - EA-Javar - PROD" / "Meta Ads - Javante - PROD" for new work (reach unknown).
