---
route: Terminal only: ~/.agents/tools/connectors/modal_op.py <modal command> (Claude Code, Codex), workspace alex-13722; Composio has no Modal toolkit
logins: one token (1Password Connectors item "Modal API token", ozvkxvoxqgiy3ednp3tkx6rkqe: username = token ID, credential = secret; token "modal", user alex-13722)
aliases: modal, modal.com, modal labs, gpu, serverless gpu, cloud gpu, run on modal, modal app, modal deploy, modal function, modal sandbox, modal volume, modal secret, modal environment
index: Modal: modal_op.py only; compute: ask Alex; never `modal token set`
tasks: list apps, environments, volumes and secrets; read app logs; check the token and workspace; check this month's bill; run or deploy code on Modal (spend: ask Alex first)
updated: 2026-10-02
---
# Modal: one token from 1Password, the terminal only

## Before the first call
1. **Route:** `~/.agents/tools/connectors/modal_op.py <modal command>` from Claude Code or Codex, outside the Claude Code
   sandbox (op and Modal's TLS fail inside it). Each run reads the token from 1Password into MODAL_TOKEN_ID and
   MODAL_TOKEN_SECRET for that one process. Not routes: the bare `modal` command ("Token missing"), Composio (no Modal
   toolkit), the Claude app and ChatGPT (no terminal, so no Modal), a `~/.modal.toml` file.
2. **Never:** `modal token set`, `token new`, `setup`, `profile activate`, `config set`, `config set-environment`,
   `--token-id`, `--token-secret` -> they write the key to `~/.modal.toml`; the wrapper refuses them and points the
   client's config file at /dev/null. It also refuses `skills install/update` (a Modal skill in every agent), `curl`
   (caches an endpoint token) and `--no-redact`. Environments (`main`, `dev`, `prod`) are spaces inside workspace
   alex-13722, not where the key lives: pick one per command with `--env <name>` or MODAL_ENVIRONMENT.
3. **Ask Alex first:** anything that runs compute or keeps it running: `run`, `serve`, `deploy`, `shell`,
   `container exec`, `launch`, `app rollover`, `app rollback`, endpoint or sandbox starts (spend: Starter includes
   $30 a month of compute, then usage is billed; Spend approval is unset). Also `app stop`, any delete (volume, secret,
   dict, queue, environment, proxy token) and creating environments, secrets or proxy tokens. Everything else on this
   card runs without asking.

## How to call
- Who and where: `modal_op.py token info` (prints the token ID, never the secret; keep the ID out of notes).
- Free reads (no compute): `app list [--env dev] [--json]`, `app logs <app> --tail 100`, `app history <app>`,
  `environment list`, `volume list`, `secret list`, `billing summary` (this month's spend).
- An approved run: `billing summary` first, name the app, environment and GPU, run once, read back with `app list`
  and `app logs`, and `app stop` anything you started once the job is done.
- New Mac or broken client (Rebuild step 7.12): `python3 -m venv ~/.agents/runtime/modal/venv` with python.org's
  python3, then `~/.agents/runtime/modal/venv/bin/pip install modal` (outside the sandbox: pip's TLS fails inside it), then
  `python3 ~/.agents/tools/connectors/test_modal_op.py`.

## Facts (tested 2026-10-02)
| Fact | Value | Evidence |
|---|---|---|
| Reach | workspace alex-13722 (Starter: $30 a month of compute, 3 seats), user alex-13722, token "modal" | `modal_op.py token info` 02:24:14Z, exit 0 |
| Power | a full API token: every CLI command; only `token info` has run (no compute, nothing created) | setup-playbook notes/modal-connector.md |
| Client | modal 1.5.3 on Python 3.14.6 in ~/.agents/runtime/modal/venv (supports Python 3.10 to 3.14) | pypi.org/project/modal |
| Key file | none: ~/.modal.toml and ~/.cache/modal absent after the test; the bare client says Token missing | same note |
| Expiry | the token expires 2027-10-01 22:09 EDT | `token info` |
Why this route: master-connector-repo `work/2026-10-01_setup-playbook/notes/modal-connector.md`.

## Failure and fix
| Symptom | Cause | Fix (name the next tool or step) |
|---|---|---|
| `Token missing. Could not authenticate client` | ran the bare `modal` | rerun through `modal_op.py`; never `modal token set` |
| `modal_op: 1Password ... failed`, or an SSL/TLS error | ran inside the Claude Code sandbox | rerun with the sandbox off |
| `modal_op: refused: ...; not run.` | the command writes or shows the key | `--env` or MODAL_ENVIRONMENT; tokens only via the item |
| `modal_op: no Modal client at ...` | the venv is missing | the install lines under How to call |
| the token is rejected after 2027-10-01 | expired or revoked | tell Alex: a new token in the Modal dashboard, saved to the same 1Password item |
