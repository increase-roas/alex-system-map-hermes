---
route: Composio toolkit slack, two logins; default "Alex Slack Account" (ca_ioyaOJLKDEUK, slack_rehood-hinney, Increase ROAS workspace, acts as Alex)
aliases: slack, slack message, slack dm, slack channel, increase roas slack, lone star slack, lonestar slack
index: Slack: Composio slack, pass account "Alex Slack Account" (Increase ROAS, acts as Alex); Lonestar login only for Lone Star tasks; internal posts need no ask; clients, customers and Lone Star ask Alex first
tasks: reading Slack channels, DMs and threads, searching Slack, drafting or posting Slack messages, Slack users and channels
updated: 2026-10-01
---
# Slack: name the login every time

| Login | Use it for |
|---|---|
| `Alex Slack Account` (ca_ioyaOJLKDEUK, word id `slack_rehood-hinney`) | Default. Increase ROAS workspace (increase-roas-group.slack.com), acts as Alex. |
| `Lonestar Slack Account` (ca_XZFQvKnTJNU7, `slack_east-reps`) | Lone Star client workspace (lonestar-vow3057.slack.com). Only when the task names Lone Star. |

- Always pass the account: MCP `account: "Alex Slack Account"`, CLI `composio execute <SLUG> --account slack_rehood-hinney`.
  The Composio MCP refuses a Slack call that names no account. The CLI without `--account` uses the login changed
  most recently, so it can flip to Lonestar.
- Composio has no "set default" setting (API, CLI or dashboard, checked 2026-10-01). Its `is_default` flag only marks
  the newest connected login (Lonestar); ignore it.
- Claude and Codex may post internal Increase ROAS messages through Composio slack (Alex Slack Account) without asking.
  Anything to a client or a customer, and anything posted in the Lone Star workspace, needs Alex's yes first.
- Javar's agents send Slack through `javar_propose_message`, not Composio.
