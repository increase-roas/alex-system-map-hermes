---
route: Composio toolkit github, two logins; default "GITHUB" (ca_O_g-WhWXwO9d, github_lipase-modern, user increaseroasir); org increase-roas repos: gh CLI (the org's OAuth App access restrictions refuse Composio's GitHub app, 403)
aliases: github, git, repo, repository, pull request, pr, issues, gists, github actions, increaseroasir, javante github, iragentjavante, increase-roas, gh, org repos
index: GitHub: Composio github, pass account github_lipase-modern (increaseroasir, Alex's main, default); JAVANTE GITHUB only for the Javante agent's own work; org increase-roas repos: gh CLI (Composio refused, 403)
tasks: reading or changing repos, issues, pull requests, branches, files, gists, GitHub Actions, releases
updated: 2026-10-02
---
# GitHub: Alex's main unless the work is Javante's; org repos through gh

| Login | Use it for |
|---|---|
| `GITHUB` (ca_O_g-WhWXwO9d, word id `github_lipase-modern`, user increaseroasir) | Default. Alex's main account: his repos and anything not named as Javante's. |
| `JAVANTE GITHUB` (ca_R9YYC0dOQqYk, `github_tina-inwit`, user IRAGENTJAVANTE) | The Javante agent's own account. Only for Javante's work. |

- Always pass the account: MCP `account: "github_lipase-modern"`, CLI `composio execute <SLUG> --account github_lipase-modern`.
  The CLI without `--account` uses the login changed most recently (increaseroasir as of 2026-10-01; any change to
  the Javante login flips it). Composio's `is_default` flag marks the newest login (JAVANTE GITHUB); ignore it.
- Deleting repos or branches, force-pushing, and making a repo or gist public need Alex's yes.

## Org repos (increase-roas): `gh`, not Composio
- The org `increase-roas` (Team plan) holds `alex-director`, `master-connector-repo` and `agents-home`. The last two
  moved from increaseroasir on 2026-10-02 (master-connector-repo work/2026-10-02_repo-lock/).
- Composio's GitHub app is refused on this org's repos: HTTP 403, "the `increase-roas` organization has enabled OAuth
  App access restrictions" (GITHUB_GET_A_REPOSITORY, account github_lipase-modern, 2026-10-02; the same login reads
  Alex's personal repos). Letting it in means approving Composio's OAuth app in the org's third-party access settings,
  a security setting, so Alex's call. Use `gh` (logged in as increaseroasir, an org owner). In Claude Code run `gh`
  outside the sandbox: inside it `gh` fails TLS (`x509: OSStatus -26276`). Plain `git` over https works inside.
- Clone from `https://github.com/increase-roas/<repo>.git`. The old increaseroasir URLs redirect only until something
  is created at the old name: never create a repo or fork named `increaseroasir/master-connector-repo` or
  `increaseroasir/agents-home`.
- Manny (`Manny2026`) gets read, never write, on all three: read on alex-director; read invitations to the other two
  sent 2026-10-02 (no access there until he accepts). Seats: each member, and each outside collaborator on a private repo,
  takes one (3 seats, 2 filled on 2026-10-02: increaseroasir, Manny2026), so adding a new person can cost money: ask
  Alex first. Invite by username, not email: an email invite holds a seat until it's accepted.
