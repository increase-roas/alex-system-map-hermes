---
route: Composio toolkit hugging_face (login hugging_face_pricer-drongo, ca_LT97uOiNLDhk) = Hugging Face user bloomsterhehe (free plan, no orgs), from every AI
logins: one login (hugging_face_pricer-drongo = Alex's fine-grained token "accss"; 1Password Connectors item u4gavrfzax27phth755upip3lq)
aliases: hugging face, huggingface, hf, hf hub, hub, models, model search, datasets, dataset viewer, spaces, papers, daily papers, hf docs, model card, inference providers, hf jobs, inference endpoints
index: HF: Composio hugging_face_pricer-drongo; inference/compute: ask Alex
tasks: find models, datasets, Spaces and papers; read model cards, files and dataset rows; search HF docs; repos, discussions, collections and webhooks on Alex's account
updated: 2026-10-02
---
# Hugging Face: one Composio login, the whole Hub API

## Before the first call
1. **Route:** `composio execute HUGGING_FACE_<TOOL> --account hugging_face_pricer-drongo` (tools: `account:
   "hugging_face_pricer-drongo"`). No tool for the job: `composio proxy https://huggingface.co/api/<path> --toolkit
   hugging_face --account hugging_face_pricer-drongo --method GET </dev/null` (router.huggingface.co works too).
   Search leaves this toolkit out (2026-10-02): CLI `composio search "<task>" --toolkits hugging_face`; chat apps
   take the slugs below to COMPOSIO_GET_TOOL_SCHEMAS, then COMPOSIO_MULTI_EXECUTE_TOOL.
   Not routes: `CUSTOM_HF_MCP_*` (disabled duplicate; its delete waits on guard CG-QWAA), Hugging Face's own Claude
   or ChatGPT connector, an HF MCP in any app config, a local `hf` CLI.
2. **Never:** `hf auth login` or a token file in ~/.cache/huggingface -> the key lives in 1Password and Composio only.
   `CREATE_REPO` without `private: true` -> the account default can make it public. Proxy to `*.hf.space`, Inference
   Endpoints or Xet storage -> Composio refuses other domains; report it, don't reroute.
3. **Ask Alex first:** `HUGGING_FACE_GENERATE_CHAT_COMPLETION` and `..._GENERATE_EMBEDDINGS` (Inference Providers
   credits: $0.10 a month on this free account, more = buying credits); Jobs, Inference Endpoints, Space hardware,
   ZeroGPU past quota (spend; no built-in tool and never the proxy); public posts (discussions, comments, paper
   claims, gated-access requests, making a repo public); deletes and history squashes (the guard stops them).
   Everything else on this card runs without asking.

## How to call
- Who: `HUGGING_FACE_GET_WHOAMI` (user, plan, token scopes; never the token value).
- Find: models -> proxy GET `https://huggingface.co/api/models?search=<q>&limit=10&sort=downloads` (no model-search
  tool); `HUGGING_FACE_LIST_DATASETS`, `..._LIST_SPACES`; Spaces by meaning -> proxy GET
  `/api/spaces/semantic-search?q=<q>`; `..._GET_TRENDING`, `..._SEARCH_PAPERS`, `..._GET_DAILY_PAPERS`, `..._SEARCH_DOCS`.
- Read: `..._GET_MODEL_INFO`, `..._GET_DATASET_REPO_INFO`, `..._GET_SPACE_INFO`, `..._LIST_REPO_FILES`,
  `..._GET_RESOLVE` (one file, e.g. README.md); rows: `..._GET_DATASET_FIRST_ROWS`, `..._GET_DATASET_ROWS`,
  `..._SEARCH_DATASET`, `..._FILTER_DATASET_ROWS`.
- Write on namespace bloomsterhehe: `..._CREATE_REPO` (`private: true`), then `..._CREATE_MODELS_COMMIT` for small
  text files. Run `..._CHECK_MODELS_UPLOAD_METHOD` first: files it marks `lfs` need the hf CLI -> ask the Director.

## Facts (tested 2026-10-02)
| Fact | Value | Evidence |
|---|---|---|
| Reach | user bloomsterhehe, free plan, no orgs; token: repo read/write, discussions, collections, webhooks, notifications, inference, endpoints, jobs; no billing read | whoami log_trzUdBVhTnX8 (CLI), log_fYB8vY78B2mQ (hosted door); billing 403 log_S7QeyTNybYKC |
| Power | 135 tools (20260729_00) + proxy to huggingface.co and router.huggingface.co | trending log_uirlDHuMtkQK; proxy model search, Spaces semantic search, /api/jobs, router /v1/models |
| Limits | proxy refuses *.hf.space (Gradio apps) and cas-server.xethub.hf.co (Xet uploads) | "not on the same registrable domain" |
Why this route: master-connector-repo `work/2026-10-01_setup-playbook/notes/huggingface-connector.md`.

## Failure and fix
| Symptom | Cause | Fix (name the next tool or step) |
|---|---|---|
| `GET and HEAD requests cannot have body` | the CLI read stdin as a body | add `--method GET </dev/null` |
| `not on the same registrable domain` | proxy to a Space app, Endpoints or Xet | no Composio route: tell the Director the job |
| HTTP 402 | Inference Providers credits used up | stop; tell Alex (more credits = spend) |
| 401, or 403 on a write | token revoked or missing a scope | tell Alex: new token into the same 1Password item, then `push_key_to_composio.py` |
| search shows no `HUGGING_FACE_*` tool | the search leaves this toolkit out | `--toolkits hugging_face`, or the slug via COMPOSIO_GET_TOOL_SCHEMAS |
