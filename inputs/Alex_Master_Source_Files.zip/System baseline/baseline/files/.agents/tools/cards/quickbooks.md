---
route: Composio toolkit quickbooks, two companies; default "Increase Roas (partnership, Phoenix)" (ca_p-2iG6dDdXF_, quickbooks_genre-lapsed)
aliases: quickbooks, qbo, quickbooks online, intuit, bookkeeping, accounting, invoices, expenses, profit and loss, balance sheet, ssa, start scale automate
index: QuickBooks: Composio quickbooks, 2 companies, always name one: quickbooks_genre-lapsed Increase Roas (default) or quickbooks_arris-bigamy SSA; money moves and customer sends ask Alex
tasks: QuickBooks reports (P&L, balance sheet), invoices, bills, expenses, customers, vendors, payments, bookkeeping checks
updated: 2026-10-01
---
# QuickBooks: two companies, always name which

| Login | Company |
|---|---|
| `Increase Roas (partnership, Phoenix)` (ca_p-2iG6dDdXF_, word id `quickbooks_genre-lapsed`) | Default. Increase ROAS, the partnership in Phoenix. Company info returns "Increase Roas". |
| `SSA - Start Scale Automate (personal brand, S-Corp)` (ca_hX6MOzV-O7CS, `quickbooks_arris-bigamy`) | Alex's personal brand S-Corp. Company info returns "No company name" (not set in QuickBooks), so go by the word id. |

- Every QuickBooks answer says which company it covers. A task about SSA, Start Scale Automate, the personal brand or
  the S-Corp uses `quickbooks_arris-bigamy`; otherwise use Increase Roas. If it's unclear, ask.
- Always pass the account: MCP `account: "quickbooks_genre-lapsed"`, CLI `--account quickbooks_genre-lapsed`.
  The CLI without `--account` uses the login changed most recently; don't rely on it.
- Money movements (payments, bill pay, transfers, refunds) and anything sent to customers (invoices, estimates,
  statements, emails) need Alex's yes. Reports and reads don't.
