---
route: Composio toolkit googleads (login googleads_maned-sprack, signed in as alex@increaseroas.com), manager account 164-028-3674 "Increase Roas Inc."
aliases: google ads, adwords, ppc, search ads, google ad campaigns
index: Google Ads: Composio googleads via manager account 1640283674 (31 tools; conversions via INGEST_CONVERSION_EVENTS); spend follows the project's Spend approval line, unset = ask
tasks: creating or changing Google Ads campaigns, ad groups, ads, keywords, budgets, client ad accounts
updated: 2026-10-01
---
# Google Ads: one route, through the manager account

| What | Fact (tested 2026-10-01) |
|---|---|
| Reach | Manager account 1640283674. Its 9 client accounts: 7 cancelled, 1 suspended (7703852570), 1 closed (6704106048); no live client yet (read-only `LIST_SUB_ACCOUNTS` 2026-10-01 19:15Z, log_2vHynvsZfNXe; live test T4 saw the same 9: master-connector-repo `work/2026-10-01_setup-playbook/notes/transcripts/claude-conductor/T4.md`). Admins: alex@, franky@, Angel@increaseroas.com |
| Built-in tools (31, latest version, `GET /api/v3.1/tools?toolkit_slug=googleads`; 21 write) | Read: `SEARCH_STREAM_GAQL`, `GET_CAMPAIGN_BY_ID/NAME`, `LIST_ACCESSIBLE_CUSTOMERS`, `LIST_SUB_ACCOUNTS`, `GET_CUSTOMER_LISTS`, `GET_RMF_REPORT`. Campaigns: `MUTATE_CAMPAIGNS(_V2)`, `MUTATE_CAMPAIGN_BUDGETS` (spend), `MUTATE_BIDDING_STRATEGIES`, `MUTATE_PORTFOLIO_BIDDING_STRATEGIES`, `MUTATE_CAMPAIGN_CRITERIA`, `MUTATE_CAMPAIGN_LABELS`, `MUTATE_LABELS`. Ad groups and ads: `MUTATE_AD_GROUPS`, `MUTATE_AD_GROUP_ADS`, `MUTATE_AD_GROUP_CRITERIA` (keywords), `MUTATE_AD_GROUP_BID_MODIFIERS`, `MUTATE_ASSETS`, `MUTATE_AD_GROUP_ASSETS`, `MUTATE_CAMPAIGN_ASSETS`, `MUTATE_CUSTOMER_ASSETS`, `CREATE_CALLOUT_ASSET`. Audiences: `CREATE_CUSTOMER_LIST`, `ADD_OR_REMOVE_TO_CUSTOMER_LIST`. Conversions: `MUTATE_CONVERSION_ACTIONS`, `GET_CONVERSION_ACTION_TAG_SNIPPETS`, `LIST_DATA_MANAGER_CONVERSION_ACTIONS`, `INGEST_CONVERSION_EVENTS` (Data Manager upload; `validate_only` first), `GET_CONVERSION_INGESTION_STATUS` |
| Everything else | `composio proxy https://googleads.googleapis.com/v23/customers/<id>/googleAds:mutate --toolkit googleads -X POST -H "login-customer-id: 1640283674" -H "content-type: application/json" -d @body.json`. Composio adds its developer token. v23 and v22 answer; v21 and older are gone |
| Conversions back to Google | Since 2026-06-15 lead and offline conversion uploads go through Google's Data Manager API, not the Google Ads API. Use `INGEST_CONVERSION_EVENTS` (not proxy `uploadClickConversions`). `LIST_DATA_MANAGER_CONVERSION_ACTIONS` answered on 1640283674 (none there; they live in client accounts). Upload not yet proven: if Google refuses the scope, reconnect the login with the Data Manager scope |
| Proven power | `createCustomerClient` with `validateOnly: true` passed: it can open a new client account under the manager account. Campaign writes not yet proven on a live account |

## How to work
- Every write: send it with `"validateOnly": true` first, then for real. User invitations don't accept it.
- Launching, unpausing, or raising a budget spends money. Follow the client project's `Spend approval:` line (its AGENTS.md).
  If it's unset, ask Alex with account, campaign and daily amount, and remind him to set the line for that project.
  Change budgets only with `MUTATE_CAMPAIGN_BUDGETS`, never through `composio proxy` (proxy skips Composio's approval gate).
- New customer without an ad account: create it under the manager account (`createCustomerClient`). Billing needs a payment method added in the Google Ads screen by Alex or the client; never enter card numbers.
- Customer with an ad account: a link invite from the manager account (`customerClientLinks:mutate`) reaches the client, so ask Alex first; the client accepts in their Google Ads.
- Conversions: link the client's GA4 property to the ad account with `CUSTOM_GA4_ADMIN_CREATE_GOOGLE_ADS_LINK` (see `ga4.md`).
- Composio's developer token is shared with its other customers. If Google returns a quota error, report it; the fix is our own developer token from the manager account's API Center.
- Adding, removing or changing a user needs a second admin's approval (multi-party approval); the requester can't approve their own.
  The API returns `multiPartyAuthReview` instead of a result. Check with GAQL `FROM multi_party_auth_review`. Keep at least two admins.
- Never use the two expired Composio Google Ads logins (`googleads_fagara-tested`, `googleads_mile-gogo`).
