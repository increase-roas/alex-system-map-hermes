---
route: Composio toolkit custom_ga4_admin (login ca_RjAXt_4X2K28), acting as alex@increaseroas.com
aliases: google analytics, analytics, ga, google analytics 4, gtm, google tag manager, tracking, measurement id
index: GA4 + GTM: Composio custom_ga4_admin acting as alex@ (all 10 properties: reports, data streams, key events); GTM publish asks Alex
tasks: GA4 reports, adding GA4 or GTM tracking to a client website or funnel, data streams, key events, conversions
updated: 2026-10-02
---
# GA4: one route

Composio `custom_ga4_admin` is the GA4 route for reports and changes. It runs on Orgo My OpenClaw (hub route
`ga4-admin`) as the `tagging-admin@increaseroas-tagging` service account, acting as alex@increaseroas.com through
Workspace domain-wide delegation. It reaches every GA4 property Alex's Google account can.

| Fact | Tested 2026-10-01 |
|---|---|
| Reach | All 10 properties in 6 accounts: Natural Sanitation, GT Tree, Momentum School, Increaseroas (6), The Real Tree Co. APM Tree Service has none |
| Power | Created and deleted a key event on all 4 client accounts and on 550831897; created and deleted a web data stream (got its G- ID and snippet); client report on 256987299 |
| Tools (25; full list via `composio search --toolkits custom_ga4_admin`) | `GOOGLE_API_REQUEST` (Search Console, Data Manager conversion uploads, Business Profile, as Alex; needs those APIs enabled in project increaseroas-tagging), `ADMIN_API_REQUEST` (any GA4 Admin API GET/POST/PATCH as Alex: retention, enhanced measurement, Google signals), create/delete property, create web data stream, tracking snippet, measurement protocol secret, key events, custom dimensions and metrics, Google Ads links, run report, realtime report |

- Checklist standard (sources/2026-10-01_universal-site-master-checklist.md, Part 5): generate_lead = Key Event, event data
  retention 14 months (set 2026-10-01 on 9 properties; GT Tree restored to 2, not a client), user-provided data collection ON, link to Ads when Ads runs.
- Change only properties of current clients and Increase ROAS's own (master-connector-repo `knowledge/clients.md`).
  GT Tree Experts (309267716) is NOT a client: never change it.
- Install on a site or funnel: `CREATE_WEB_DATA_STREAM` returns the G- ID; `GET_TRACKING_SNIPPET` returns the code.
  Put it on the site through GTM (the same robot has GTM scopes) or into the GHL funnel through `ghl-command-builder`.
- Delegated scopes (Admin console, client ID 112417209265494842557, all 10 verified 2026-10-01): analytics.edit, analytics.readonly,
  analytics.manage.users.readonly (access bindings read works), datamanager, webmasters, business.manage, and tagmanager readonly,
  edit.containers, edit.containerversions, publish. Removing any one breaks every GA4 call (the health check alerts). Publishing GTM puts tags live: ask Alex first.
- GTM: Composio `custom_google_tag_manager` (hub route `gtm`) also acts as alex@ (switch `/opt/mcp-hub/gtm-act-as-alex.sh`,
  scopes limited to readonly, edit.containers, edit.containerversions, publish). Reaches GTM accounts 6316753028 and
  6359407641 only; no client GTM accounts sit under Alex. It can't delete workspaces or containers (not delegated).
- **Default GTM account: 6359407641 "Increase Roas (Official)"** (alex@ and the robot are admins; containers 261797676,
  263653513, 254693850). Build and publish only there. 6316753028 "Increase Roas" belongs to a contractor
  (analyticsevolutionpro@gmail.com is admin, alex@ read-only): read it, never build in it (Alex, 2026-10-02, GTM API readback).
- Switch and wrapper on the Orgo box: `/opt/mcp-hub/ga4-act-as-alex.sh`, `/opt/mcp-hub/ga4-admin-run.py`; old start
  script in `/opt/mcp-hub/backups/`.
- `custom_ga4_admin` sometimes returns 503. Retry once after a few seconds.
- Not GA4 routes: Composio `google_analytics` (read-only Google login; Composio's shared app can't get edit, Google
  shows "This app is blocked"), the removed local `ga4-mcp-server`, `analytics-mcp`, Cursor and Codex `ga4-admin`
  and `htl-ga4-analytics` (backup `~/Backups/ga4-cleanup-2026-10-01`), and `custom_htl_google_tracking`.
- Get a route's full tool list from `composio search` with create/update/delete queries, never from
  `~/.composio/tool_definitions` (that only caches tools already called).
