#!/usr/bin/env python3
"""Drift check for the one-home setup. Read-only. Exit 1 if anything needs attention.

  python3 check.py
Check 6 (named skills and vendored-skill dependencies) lives in skill_deps.py; run it alone with --lock to test a
staged vendor-lock.json. Check 7 (Codex plugins against decision D07, codex-plugins.json) lives in codex_plugins.py,
which also restores them (apply).
"""
import hashlib, os, re, stat, subprocess, sys

H = os.path.expanduser("~")
A, C, L = f"{H}/.agents/skills", f"{H}/.codex/skills", f"{H}/.claude/skills"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
problems, info = [], []

# 1. Codex's own folder should hold only its .system skills
extra = [n for n in os.listdir(C) if not n.startswith(".")] if os.path.isdir(C) else []
if extra:
    problems.append(f"{len(extra)} skill(s) installed into ~/.codex/skills (move to ~/.agents/skills): {', '.join(sorted(extra))}")

# 2. Claude links resolve; a real Claude folder must not shadow a ~/.agents skill (one copy, owner 2026-10-01, S10)
for n in sorted(os.listdir(L)) if os.path.isdir(L) else []:
    p = f"{L}/{n}"
    if os.path.islink(p) and not os.path.exists(p):
        problems.append(f"broken Claude link: {p} -> {os.readlink(p)}")
# synced/ (any capitalization) is Claude Code's reserved download folder for claude.ai skills (code.claude.com/docs/en/skills),
# not a skill of ours; check 6 (skill_deps.py) reads the skills inside it as a Claude Code source
real_claude = [n for n in os.listdir(L) if not n.startswith(".") and n.lower() != "synced" and os.path.isdir(f"{L}/{n}") and not os.path.islink(f"{L}/{n}")] if os.path.isdir(L) else []
SKIP_PARTS = {"__pycache__", ".DS_Store", ".git", "node_modules"}


def tree(d):
    """Relative path -> sha256 of every regular file. .env names, pipes, links and other special files are skipped, never opened."""
    out = {}
    for base, dirs, files in os.walk(d):
        dirs[:] = [x for x in dirs if x not in SKIP_PARTS]
        for f in files:
            fp = os.path.join(base, f)
            if f in SKIP_PARTS or f.startswith(".env") or f.endswith(".env") or re.search(r"\.(bak\d*|prev|orig)$", f):
                continue  # .env names may be 1Password FIFOs: never stat-follow, open or hash them
            st = os.lstat(fp)
            if not stat.S_ISREG(st.st_mode):
                continue
            out[os.path.relpath(fp, d)] = hashlib.sha256(open(fp, "rb").read()).hexdigest()
    return out


both = [n for n in real_claude if os.path.isdir(f"{A}/{n}")]
diverged = [n for n in both if tree(f"{L}/{n}") != tree(f"{A}/{n}")]
twins = [n for n in both if n not in diverged]
if diverged:
    problems.append(f"{len(diverged)} Claude skill folder(s) differ from the ~/.agents copy (merge into ~/.agents/skills, then link): {', '.join(sorted(diverged))}")
if twins:
    problems.append(f"{len(twins)} identical real Claude copies should be links (unify.py apply links them): {', '.join(sorted(twins))}")
claude_only = [n for n in real_claude if n not in both]
if claude_only:
    info.append(f"{len(claude_only)} Claude-only skills kept as real folders: {', '.join(sorted(claude_only))}")

# 3. Generated instruction files match their sources
try:
    import build_instructions as b
    if os.path.isdir(b.SRC):
        stale = b.plan(show=False)
        if stale:
            problems.append(f"instruction file(s) edited by hand or sources changed: {', '.join(stale)} (run build_instructions.py plan)")
    else:
        info.append("instructions not unified yet (~/.agents/instructions missing)")
except Exception as e:
    problems.append(f"instruction check failed: {e}")

# 4. Codex off-switches point at real files
cfg = f"{H}/.codex/config.toml"
paths = re.findall(r'path\s*=\s*"([^"]+)"', open(cfg).read()) if os.path.exists(cfg) else []
missing = [p for p in paths if not os.path.exists(p)]
if missing:
    problems.append(f"{len(missing)} Codex off-switch(es) point at missing files (stale after a move or plugin update): " + "; ".join(p.replace(H, "~") for p in missing[:8]))
info.append(f"{len(paths)} Codex off-switches, {len(os.listdir(A)) if os.path.isdir(A) else 0} canonical skills")

# 5. ~/.agents under version control and committed
g = subprocess.run(["git", "-C", f"{H}/.agents", "status", "--porcelain"], capture_output=True, text=True)
if g.returncode != 0:
    info.append("~/.agents is not a git repo yet")
elif g.stdout.strip():
    problems.append(f"~/.agents has {len(g.stdout.splitlines())} uncommitted change(s)")

# 6. Skills the Director and Conductor name, and every skill a vendored skill calls, load once and stay on (skill_deps.py)
try:
    import skill_deps
    p6, i6 = skill_deps.run()
    problems += p6
    info += i6
except Exception as e:
    problems.append(f"named-skill check failed: {e}")

# 7. Codex plugins match the agreed set (decision D07). The ChatGPT app update of 2026-10-02 switched 7 on and dropped
#    Messages without anyone deciding it; this makes the next one loud (the tune-up reports every FIX).
try:
    import codex_plugins
    p7, i7 = codex_plugins.check()
    if p7:
        problems.append(f"Codex plugins differ from the agreed set (D07): {'; '.join(p7)} "
                        "(restore: python3 ~/.agents/tools/unify/codex_plugins.py apply)")
    info += i7
except Exception as e:
    problems.append(f"Codex plugin check failed: {e}")

for i in info:
    print("info:", i)
for p in problems:
    print("FIX: ", p)
print("OK" if not problems else f"{len(problems)} thing(s) to fix")
sys.exit(1 if problems else 0)
