#!/usr/bin/env python3
"""One source for global instructions; each tool gets a generated file.

  python3 build_instructions.py init    # first time: split today's two files into ~/.agents/instructions/
  python3 build_instructions.py plan    # show what the generated files would change (default)
  python3 build_instructions.py apply   # back up and write ~/.codex/AGENTS.md, ~/.claude/CLAUDE.md, the styles
                                        # and the CODEX_SETTINGS keys in ~/.codex/config.toml

Sources (edit these, never the generated files):
  ~/.agents/instructions/shared.md        hard rules and tool routing for every agent (rule files)
  ~/.agents/instructions/claude.md        Claude-only rules
  ~/.agents/instructions/codex.md         Codex-only rules
  ~/.agents/instructions/shared-style.md  working style for every agent
  ~/.agents/instructions/claude-style.md  Claude voice and format -> output style ~/.claude/output-styles/alex-big-brother.md
  ~/.agents/instructions/codex-style.md   Codex voice and delegation -> developer_instructions in ~/.codex/config.toml;
                                          its APP_SECTIONS ("## Voice", "## Delegation and model routing") also
                                          -> the end of ~/.codex/AGENTS.md (see below)
  CODEX_SETTINGS below                    top-level ~/.codex/config.toml keys the build sets (talk length, progress notes)
Rules load as instructions; voice and working style load as system/developer instructions (Limits tab).
The Codex app never delivers config.toml developer_instructions to its chats (0 of 29 app threads vs 66 of 66
codex exec threads, 2026-10-01/02, master-connector-repo work/2026-10-02_codex-voice/notes/scan.md), so the
APP_SECTIONS of codex-style.md also go into ~/.codex/AGENTS.md, the one file every Codex surface reads: the Voice,
and since Alex 2026-10-02 ("i want the credit saver in codexs app chats") the model routing. The working style
(shared-style.md) stays out. Size: Limits tab row 3 (6,000 characters before the routing; 8,000 with it, a workbook
follow-up in work/2026-10-02_codex-voice/notes/round-2.md). Codex reads at most 32 KiB of AGENTS.md per chat
(project_doc_max_bytes), project files included.
Codex has no import syntax, so both files are generated the same way; check.py flags hand edits.
"""
import difflib, json, os, re, shutil, sys, time

H = os.path.expanduser("~")
SRC = os.environ.get("AGENTS_INSTR", f"{H}/.agents/instructions")
OUT = {"codex": f"{H}/.codex/AGENTS.md", "claude": f"{H}/.claude/CLAUDE.md",
       "claude_style": f"{H}/.claude/output-styles/alex-big-brother.md", "codex_config": f"{H}/.codex/config.toml"}
STYLE_HEAD = ("---\nname: Alex big brother\ndescription: Big-brother voice, explain-it-like-he's-5 answers, autonomous working style\n"
              "keep-coding-instructions: true\n---\n<!-- GENERATED from ~/.agents/instructions/ (claude-style.md + shared-style.md). Edit there, then rebuild. -->\n\n")
DEV_BEGIN, DEV_END = "# BEGIN generated developer_instructions (build_instructions.py)", "# END generated developer_instructions"
HEADER = "<!-- GENERATED from ~/.agents/instructions/ by build_instructions.py. Edit the sources there, then rebuild. -->\n\n"
SHARED_SECTIONS = ["Own the outcome", "Keep execution efficient"]
# Top-level ~/.codex/config.toml keys every rebuild sets (Alex, 2026-10-02; scan: work/2026-10-02_codex-voice).
CODEX_SETTINGS = {"model_verbosity": "medium",          # gpt-6.1-sol defaults to "low": one- or two-line answers
                  "model_reasoning_summary": "concise"}  # it defaults to "none": no visible progress while it thinks
# codex-style.md sections the Codex app chats also get, through ~/.codex/AGENTS.md (they never see developer_instructions)
APP_SECTIONS = ["Voice", "Delegation and model routing"]


def sections(text):
    parts = re.split(r"(?m)^(?=# )", text)
    return {p.splitlines()[0][2:].strip() if p.startswith("# ") else "_pre": p.rstrip() + "\n" for p in parts if p.strip()}


def init():
    if os.path.exists(f"{SRC}/shared.md"):
        sys.exit("sources already exist; edit them instead")
    os.makedirs(SRC, exist_ok=True)
    codex = open(OUT["codex"]).read().replace(HEADER, "")
    claude = open(OUT["claude"]).read().replace(HEADER, "")
    sec = sections(codex)
    shared = "\n".join(sec[s] for s in SHARED_SECTIONS if s in sec)
    only = "\n".join(v for k, v in sec.items() if k not in SHARED_SECTIONS)
    open(f"{SRC}/shared.md", "w").write(shared)
    open(f"{SRC}/codex.md", "w").write(only)
    open(f"{SRC}/claude.md", "w").write(claude.rstrip() + "\n")
    print("wrote", SRC, "(shared.md, codex.md, claude.md)")


def with_dev_instructions(config, text):
    """Put text into config.toml as developer_instructions, between markers, among the top-level keys."""
    if "'''" in text:
        sys.exit("codex-style.md / shared-style.md can't contain three single quotes")
    block = f"{DEV_BEGIN}\ndeveloper_instructions = '''\n{text.rstrip()}\n'''\n{DEV_END}\n"
    if DEV_BEGIN in config:
        a = config.index(DEV_BEGIN)
        if DEV_END in config[a:]:
            b = config.index(DEV_END, a) + len(DEV_END) + 1
        else:  # Codex can drop the END comment when it rewrites config.toml; end at the closing quotes instead
            j = config.index("developer_instructions = '''", a)
            b = config.index("\n'''\n", j) + 5
        return config[:a] + block + config[b:]
    m = re.search(r"(?m)^\[", config)  # top-level keys must come before the first [table]
    i = m.start() if m else len(config)
    return config[:i] + block + "\n" + config[i:]


def with_settings(config, settings):
    """Set each CODEX_SETTINGS key at the top level of config.toml: replace its line in place, or add it at the top.
    Lines inside the generated developer_instructions string and anything after the first [table] are never touched."""
    out, seen, in_block, top = [], set(), False, True
    for line in config.splitlines(keepends=True):
        s = line.strip()
        if in_block:
            in_block = s != "'''"
        elif s.startswith("developer_instructions = '''"):
            in_block = s.count("'''") == 1
        elif top and s.startswith("["):
            top = False
        elif top:
            m = re.match(r"([A-Za-z0-9_-]+)\s*=", s)
            if m and m.group(1) in settings:
                line = f"{m.group(1)} = {json.dumps(settings[m.group(1)])}\n"
                seen.add(m.group(1))
        out.append(line)
    return "".join(f"{k} = {json.dumps(v)}\n" for k, v in settings.items() if k not in seen) + "".join(out)


def app_sections(text):
    """The APP_SECTIONS of codex-style.md, in APP_SECTIONS order, as top-level '# ' sections for AGENTS.md.
    Only the heading level changes ('## Voice' -> '# Voice'); every line under a heading is copied as is."""
    parts = {p.splitlines()[0][3:].strip(): p for p in re.split(r"(?m)^(?=## )", text) if p.startswith("## ")}
    for s in APP_SECTIONS:
        if s not in parts:
            sys.exit(f"codex-style.md has no '## {s}' section")
    return "\n".join(parts[s][1:].rstrip() + "\n" for s in APP_SECTIONS)


def read_src(f):
    """App rules stay in the cards. The always-loaded file must not paste a card index."""
    path = f"{SRC}/{f}"
    if not os.path.exists(path):
        return ""
    text = open(path).read().rstrip() + "\n"
    if "{{CARD_INDEX}}" in text:
        sys.exit(f"{f} still has {{{{CARD_INDEX}}}}; put the rule in the card, not the always-loaded file")
    return text


def build():
    r = read_src
    cfg = open(OUT["codex_config"]).read() if os.path.exists(OUT["codex_config"]) else ""
    codex_style = r("codex-style.md") + "\n" + r("shared-style.md")
    return {"codex": HEADER + r("shared.md") + "\n" + r("codex.md") + "\n" + app_sections(r("codex-style.md")),
            "claude": HEADER + r("claude.md") + "\n" + r("shared.md"),
            "claude_style": STYLE_HEAD + r("claude-style.md") + "\n" + r("shared-style.md"),
            "codex_config": with_settings(with_dev_instructions(cfg, codex_style), CODEX_SETTINGS)}


def plan(show=True):
    new = build()
    changed = {}
    for k, path in OUT.items():
        old = open(path).read() if os.path.exists(path) else ""
        if old != new[k]:
            changed[k] = new[k]
            if show:
                d = difflib.unified_diff(old.splitlines(), new[k].splitlines(), path, path + " (generated)", lineterm="", n=1)
                print("\n".join(d))
    if show:
        print("\nno changes" if not changed else f"\n{len(changed)} file(s) would change: {', '.join(changed)}")
    return changed


def apply():
    changed = plan(show=False)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for k, text in changed.items():
        bak = os.path.join(H, "Backups", "unify-bak")  # backups stay out of the tools' folders
        os.makedirs(bak, exist_ok=True)
        if os.path.exists(OUT[k]):
            shutil.copy2(OUT[k], os.path.join(bak, os.path.basename(OUT[k]) + f".{k}.bak-{stamp}"))
        os.makedirs(os.path.dirname(OUT[k]), exist_ok=True)
        open(OUT[k], "w").write(text)
        print("wrote", OUT[k], "(backup in ~/Backups/unify-bak)")
    if not changed:
        print("already up to date")


if __name__ == "__main__":
    {"init": init, "plan": plan, "apply": apply}[sys.argv[1] if len(sys.argv) > 1 else "plan"]()
