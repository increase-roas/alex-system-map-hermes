#!/usr/bin/env python3
"""Codex adapter for the Composio guard (draft, 2026-10-01; notes/codex-guard.md).

A Codex PreToolUse hook. It reshapes Codex hook payloads into what composio_guard.decide()
expects, then prints Codex's deny shape. Codex honors "deny" and does not support "ask" (an
"ask" fails open), so the guard's deny-only design carries over unchanged.

What differs from Claude Code
  * Shell calls can arrive as Bash, shell, shell_command, exec_command or local_shell, with the
    command as a string or an argv list (["zsh", "-lc", "..."]).
  * Composio app tools are named mcp__codex_apps__composio_composio_<tool>; the guard expects
    COMPOSIO_<TOOL> after the last "__" (otherwise COMPOSIO_REMOTE_BASH_TOOL slips through).
  * Codex's own servers (codex_app, node_repl, cua_repl, 1password, computer use, browser,
    messages) never reach a business app and are skipped, so thread messages are not "sends".
  * Remote shells on other MCP servers (orgo_execute_bash and the like) are checked as shell.
  * Approvals: Codex transcripts carry no harness-written "typed by a human" marker, and other
    agents can start turns (codex exec, app-server, codex queue, automations). So there is no
    release path unless CODEX_GUARD_RELEASE=1; then only plain user.text turns in an
    interactive, non-subagent session count.
"""

import io
import json
import os
import re
import shlex
import sys

sys.dont_write_bytecode = True
GUARD_DIR = os.environ.get("COMPOSIO_GUARD_DIR") or os.path.expanduser("~/.agents/tools/guards")
sys.path.insert(0, GUARD_DIR)
import composio_guard as g  # noqa: E402

SHELL_TOOLS = {"Bash", "shell", "shell_command", "exec_command", "local_shell", "unified_exec"}
CODEX_LOCAL = re.compile(r"^mcp__(codex_app|node_repl|cua_repl|1password|computer[-_]use|"
                         r"unified[-_]computer[-_]use|browser|chrome|visualize|messages)__")
JS_REPL = re.compile(r"^mcp__(node_repl|cua_repl)__")
REMOTE_SHELL = re.compile(r"(execute_bash|remote_bash(_tool)?|run_command|run_shell|_bash)$", re.I)
INTERACTIVE_ORIGINATORS = {"codex_work_desktop", "Codex Desktop", "codex_cli_rs", "codex-tui"}


def shell_text(cmd):
    if isinstance(cmd, list):
        parts = [str(c) for c in cmd]
        if len(parts) >= 3 and os.path.basename(parts[0]) in g.SHELLS and \
                parts[1] in ("-c", "-lc", "-ic", "-lic"):
            return parts[2]
        return " ".join(shlex.quote(p) for p in parts)
    return str(cmd or "")


def normalize(payload):
    """A Claude-shaped payload for composio_guard.decide(), or None when the call is out of scope."""
    name = str(payload.get("tool_name") or "")
    ti = payload.get("tool_input")
    if name in SHELL_TOOLS:
        cmd = ti.get("command", ti.get("cmd")) if isinstance(ti, dict) else ti
        return dict(payload, tool_name="Bash", tool_input={"command": shell_text(cmd)})
    if not name.startswith("mcp__"):
        return None
    if CODEX_LOCAL.match(name):
        # Local JavaScript REPLs can shell out (child_process). Check only code that names composio.
        if JS_REPL.match(name) and isinstance(ti, dict) and "composio" in json.dumps(ti):
            code = "\n".join(v for v in ti.values() if isinstance(v, str))
            lits = re.findall(r"`([^`]*composio[^`]*)`|'([^'\n]*composio[^'\n]*)'|"
                              r"\"([^\"\n]*composio[^\"\n]*)\"", code)
            cmds = [a or b or c for a, b, c in lits]
            if g.SDK_IN_COMMAND.search(code):
                cmds.append(code)
            if cmds:
                return dict(payload, tool_name="Bash", tool_input={"command": "\n".join(cmds)})
        return None
    m = re.match(r"^mcp__codex_apps__composio_(composio_[a-z0-9_]+)$", name, re.I)
    if m:
        name = "mcp__composio__" + m.group(1).upper()
    last = name.split("__")[-1]
    if REMOTE_SHELL.search(last) and not last.upper().startswith("COMPOSIO_") and isinstance(ti, dict):
        cmd = ti.get("command", ti.get("cmd", ti.get("script")))
        if isinstance(cmd, (str, list)):
            return dict(payload, tool_name="Bash", tool_input={"command": shell_text(cmd)})
    return dict(payload, tool_name=name)


def _first_line_meta(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            e = json.loads(fh.readline())
        return e.get("payload") if e.get("type") == "session_meta" else None
    except Exception:
        return None


def scan_codex_transcript(path, prompt_id=None):
    """Same contract as composio_guard.scan_transcript, for a Codex rollout JSONL file."""
    if not path or not os.path.isfile(path):
        return None, "", False
    meta = _first_line_meta(path) or {}
    if meta.get("originator") not in INTERACTIVE_ORIGINATORS or not isinstance(meta.get("source"), str) \
            or meta.get("source") == "exec":
        return None, "", False                      # headless, exec or subagent: never a yes
    lines, _ = g.read_tail_lines(path, 32_000_000)
    events = []
    for line in lines:
        try:
            e = json.loads(line)
        except Exception:
            continue
        p = e.get("payload") if isinstance(e.get("payload"), dict) else {}
        if e.get("type") != "response_item" or p.get("type") != "message":
            continue
        text = " ".join(c.get("text", "") for c in p.get("content") or []
                        if isinstance(c, dict) and c.get("type") in ("input_text", "output_text"))
        if p.get("role") == "user":
            kinds = (p.get("internal_chat_message_metadata_passthrough") or {}).get(
                "content_item_kinds") or []
            if kinds and all(k == "user.text" for k in kinds) and not text.lstrip().startswith("<"):
                events.append(("human", p.get("id") or e.get("timestamp"), text))
        elif p.get("role") == "assistant" and text:
            events.append(("assistant", None, text))
    idx = next((k for k in range(len(events) - 1, -1, -1) if events[k][0] == "human"), None)
    if idx is None:
        return None, "", False
    ask = []
    for k in range(idx - 1, -1, -1):
        if events[k][0] == "human":
            break
        ask.append(events[k][2])
    ask.reverse()
    return {"id": events[idx][1], "text": events[idx][2]}, "\n".join(ask), False


def no_release(path, prompt_id=None):
    return None, "", False


CODEX_NOTE = ("\nCodex note: there is no release path in Codex yet. Report this stop to Alex; he can run "
              "it himself or approve it in Claude Code.")


def local_container_reason(payload):
    """Deny text when a local JavaScript REPL's code reaches into an app container (decision D09)."""
    name = str(payload.get("tool_name") or "")
    ti = payload.get("tool_input")
    if not JS_REPL.match(name) or not isinstance(ti, dict):
        return None
    code = "\n".join(v for v in ti.values() if isinstance(v, str))
    if not g.code_container_hit(code, backticks=True):
        return None
    del g.RULE_HITS[:]
    g.container_rule(name.split("__")[-1], "an app container")
    return "%s (a yes doesn't release these; change the call instead):\n- %s" % (g.RULE_HEAD, g.RULE_HITS[0][2])


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw or "{}")
    except Exception:
        return 0
    release = os.environ.get("CODEX_GUARD_RELEASE") == "1"
    g.scan_transcript = scan_codex_transcript if release else no_release
    try:
        reason = local_container_reason(payload)
    except Exception:
        reason = None
    if reason:
        g.log({"ts": g.now_iso(), "decision": "deny", "tool": payload.get("tool_name"),
               "rules": [{"rule": "container", "label": str(payload.get("tool_name"))[-40:]}]})
        print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse",
                                                 "permissionDecision": "deny",
                                                 "permissionDecisionReason": reason}}))
        return 0
    try:
        norm = normalize(payload)
    except Exception:
        norm = payload
    if norm is None:
        return 0
    sys.stdin = io.StringIO(json.dumps(norm))
    out = io.StringIO()
    real_stdout, sys.stdout = sys.stdout, out
    try:
        g.main()
    finally:
        sys.stdout = real_stdout
    text = out.getvalue().strip()
    if text:
        d = json.loads(text)
        # The note is about releasing a stop; rule denials are fixed by changing the call instead.
        if not release and g.APPROVAL_HEAD in d["hookSpecificOutput"]["permissionDecisionReason"]:
            d["hookSpecificOutput"]["permissionDecisionReason"] += CODEX_NOTE
        print(json.dumps(d))
    return 0


if __name__ == "__main__":
    sys.exit(main())
