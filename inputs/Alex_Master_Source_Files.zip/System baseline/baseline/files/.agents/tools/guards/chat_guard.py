#!/usr/bin/env python3
"""Chat guard: keeps long chats and agent work from crashing the Mac (Claude Code hooks).

Why (2026-10-02 crash, JetsamEvent-2026-10-02-204618): free memory hit 0.07 GiB; the biggest program was a
Python scan an agent started (8.69 GiB). Claude Code's own memory-pressure cleanup only stops leftover
background commands after 30 idle minutes with no agent running (code.claude.com/docs/en/env-vars,
CLAUDE_CODE_DISABLE_BG_SHELL_PRESSURE_REAP), so it couldn't touch it. Research and thresholds:
master-connector-repo work/2026-10-02_chat-guard/.

Least restrictive by design (Alex, 2026-10-02):
- Chat size never blocks anything. At 20 MB it saves a handoff snapshot and asks Alex once: fresh chat or
  keep going; after "keep going" it asks again every +15 MB.
- Memory acts only near the limit (under 10% available, or the OS says critical): no new agents until it
  recovers, and the biggest command this chat started (over 2 GB) is stopped. No memory notes above that.
- Every agent prompt gets one memory-safe line (no whole-home scans, stream big files).

Hook modes (argument 1): post (PostToolUse, all tools), pre (PreToolUse, Agent|Task|Workflow),
prompt (UserPromptSubmit), start (SessionStart). Always exits 0; errors go to the log, never to the chat.
Turn off: remove the chat_guard.py entries from ~/.claude/settings.json. Test: CHAT_GUARD_TEST_AVAIL=<percent>.
"""
import ctypes
import ctypes.util
import json
import os
import re
import signal
import subprocess
import sys
import time

HOME = os.path.expanduser("~")
RUN = os.path.join(HOME, ".agents", "runtime", "chat-guard")
SOFT_MB = 20.0          # first ask (4 of ~45 chats over 1 MB ever reached it)
STEP_MB = 15.0          # next ask after Alex keeps going
REMIND_MB = 5.0         # remind again if the ask went unanswered this much later
CRIT_PCT = 10           # act
RUNAWAY_MB = 2048       # one command this big, at critical memory, gets stopped (test: CHAT_GUARD_TEST_RUNAWAY_MB)
AGENT_LINE = ("\n\nMemory rule (chat guard): don't scan the whole home folder or other huge trees; search named "
              "folders, skip node_modules/.git/Library/caches, and stream any file over 50 MB instead of loading it.")
DIRECTOR_LINKS = ("[$alex-director](/Users/alexlobaito/.agents/skills/alex-director/SKILL.md) and "
                  "[$alex-workflow-conductor](/Users/alexlobaito/.agents/skills/alex-workflow-conductor/SKILL.md)")
SECRET_PATTERNS = [
    re.compile(r"(?i)\b(password|passwd|passcode|pin)\b(\s*(?:is|to|=|:|was)\s*|(?:\s+[^\s:=]+){1,3}?\s*(?:\bis\b|[=:])\s*)(\S+)"),
    re.compile(r"\b(sk-[A-Za-z0-9_\-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[abprs]-[A-Za-z0-9\-]{10,}"
               r"|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_\-]{30,}|ya29\.[0-9A-Za-z_\-]{20,}|ops_[A-Za-z0-9+/=_\-]{20,}"
               r"|eyJ[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{8,})\b"),
]
MIXED_LONG = re.compile(r"\b[A-Za-z0-9_\-]{24,}\b")
HEX_LONG = re.compile(r"(?<![0-9A-Za-z])[0-9a-fA-F]{32,}(?![0-9A-Za-z])")


def log(msg):
    try:
        os.makedirs(RUN, exist_ok=True)
        with open(os.path.join(RUN, "events.log"), "a") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%dT%H:%M:%S"), msg))
    except Exception:
        pass


def sysctl_int(name):
    try:
        try:
            libc = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
        except OSError:
            libc = ctypes.CDLL(ctypes.util.find_library("c"))
        val = ctypes.c_int(0)
        size = ctypes.c_size_t(ctypes.sizeof(val))
        if libc.sysctlbyname(name.encode(), ctypes.byref(val), ctypes.byref(size), None, 0) == 0:
            return val.value
    except Exception:
        pass
    return None


def memory():
    """(available percent, pressure level 1/2/4); None when unreadable."""
    test = os.environ.get("CHAT_GUARD_TEST_AVAIL")
    if test:
        return int(test), 1
    return sysctl_int("kern.memorystatus_level"), sysctl_int("kern.memorystatus_vm_pressure_level")


def critical(avail, pressure):
    return (avail is not None and avail < CRIT_PCT) or pressure == 4


def load_state(sid):
    try:
        with open(os.path.join(RUN, "sessions", sid + ".json")) as f:
            return json.load(f)
    except Exception:
        return {"next_ask_mb": SOFT_MB, "awaiting": False, "asked_mb": 0}


def save_state(sid, st):
    d = os.path.join(RUN, "sessions")
    os.makedirs(d, exist_ok=True)
    tmp = os.path.join(d, sid + ".tmp")
    with open(tmp, "w") as f:
        json.dump(st, f)
    os.replace(tmp, os.path.join(d, sid + ".json"))


def size_mb(path):
    try:
        return os.path.getsize(path) / 1048576.0
    except Exception:
        return 0.0


def redact(text):
    text = SECRET_PATTERNS[0].sub(lambda m: m.group(1) + m.group(2) + "[REDACTED]", text)
    text = SECRET_PATTERNS[1].sub("[REDACTED]", text)
    text = HEX_LONG.sub("[REDACTED]", text)
    return MIXED_LONG.sub(lambda m: "[REDACTED]" if (re.search(r"[a-z]", m.group(0)) and re.search(r"[A-Z]", m.group(0))
                                                    and re.search(r"[0-9]", m.group(0))) else m.group(0), text)


def strip_reminders(text):
    return re.sub(r"<system-reminder>.*?</system-reminder>", "", text, flags=re.S).strip()


def text_of(content):
    if isinstance(content, str):
        return content
    out = []
    for block in content or []:
        if isinstance(block, dict) and block.get("type") == "text":
            out.append(block.get("text", ""))
    return "\n".join(out)


def scan_transcript(path):
    """Newest compaction summary, Alex's messages after it, last assistant text, screenshot count."""
    last_off, off, images, compactions = 0, 0, 0, 0
    with open(path, "rb") as f:
        for line in f:
            if b'"type":"image"' in line:
                images += 1
            if b'"isCompactSummary":true' in line:
                last_off, compactions = off, compactions + 1
            off += len(line)
    summary, summary_ts, said, last_reply = "", "", [], ""
    with open(path, "rb") as f:
        f.seek(last_off)
        for line in f:
            if (b'"type":"user"' not in line and b'"type":"assistant"' not in line) or (
                    b'"tool_use_id"' in line and b'"isCompactSummary":true' not in line):
                continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            msg = e.get("message") or {}
            if e.get("isCompactSummary"):
                summary, summary_ts, said = text_of(msg.get("content")), e.get("timestamp", ""), []
            elif e.get("type") == "user" and not e.get("isMeta"):
                t = strip_reminders(text_of(msg.get("content")))
                if t.startswith("<command-"):  # a slash command: keep "/name args", drop the wrapper tags
                    t = " ".join(x.strip() for x in re.findall(r"<command-(?:name|args)>(.*?)</command-(?:name|args)>", t, re.S)
                                 if x.strip())
                if t and not t.startswith("<local-command"):
                    said.append((e.get("timestamp", "")[:16], t[:4000]))
            elif e.get("type") == "assistant":
                t = text_of(msg.get("content")).strip()
                if t:
                    last_reply = t[:3000]
    return summary, summary_ts, said, last_reply, images, compactions


def write_handoff(ev, mb):
    tp, cwd, sid = ev.get("transcript_path", ""), ev.get("cwd", ""), ev.get("session_id", "unknown")
    summary, summary_ts, said, last_reply, images, compactions = scan_transcript(tp)
    try:
        with open(tp, "rb") as f:
            director = b"alex-director" in f.read(4 << 20)
    except Exception:
        director = False
    project = os.path.basename(cwd.rstrip("/")) or "chat"
    d = os.path.join(RUN, "handoffs")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, "%s_%s_%s.md" % (time.strftime("%Y-%m-%d_%H%M"), project, sid[:8]))
    out = ["# Handoff snapshot: %s (%s)" % (project, time.strftime("%Y-%m-%d %H:%M")), "",
           "Saved automatically by the chat guard because this chat reached %.0f MB (%d screenshots, %d compactions). "
           "It's a mechanical copy, not a judged handoff: the newest compaction summary plus everything Alex said "
           "after it. Secrets are redacted. The files under Sources of truth win over anything here." % (mb, images, compactions),
           "", "## Start the new chat with", "",
           "Read %s and pick up where the old chat left off." % path, ""]
    if director:
        out += ["## Required skill activation — Alex's standing handoff instruction, September 29, 2026", "",
                DIRECTOR_LINKS, "", "Load both named skills before resuming; retain role: Director.", ""]
    out += ["## Sources of truth", ""]
    if os.path.exists(os.path.join(cwd, "STATUS.md")):
        out.append("- %s/STATUS.md" % cwd)
    if director:
        out.append("- ~/Alex-Director/DIRECTOR_STATE.md and ~/Alex-Director/mission-graphs/")
    out += ["- Old chat: %s (session %s)" % (tp, sid), "",
            "## Newest compaction summary (%s)" % (summary_ts[:16] or "none yet"), "", redact(summary) or "(no compaction yet)", "",
            "## Alex's messages since then (oldest first)", ""]
    out += ["- %s: %s" % (ts, redact(t.replace("\n", " "))) for ts, t in said] or ["(none)"]
    out += ["", "## Last thing the old chat said", "", redact(last_reply) or "(nothing yet)", ""]
    with open(path, "w") as f:
        f.write("\n".join(out))  # only the copied chat text was redacted; the guard's own lines and paths stay exact
    log("handoff %s %.1fMB %s" % (sid[:8], mb, path))
    return path


def proc_table():
    # 4 s cap: at critical memory a hung ps costs at most 8 s (stop + top users), well inside the 20 s hook limit
    out = subprocess.run(["ps", "-axo", "pid=,ppid=,rss=,comm="], capture_output=True, text=True, timeout=4).stdout
    procs = {}
    for line in out.splitlines():
        p = line.split(None, 3)
        if len(p) == 4 and p[0].isdigit():
            procs[int(p[0])] = (int(p[1]), int(p[2]), os.path.basename(p[3]))
    return procs


def stop_runaway():
    """Stop the biggest command this chat started (via a shell) if it is over RUNAWAY_MB. Returns a note or ''."""
    try:
        limit_mb = int(os.environ.get("CHAT_GUARD_TEST_RUNAWAY_MB", RUNAWAY_MB))
    except ValueError:
        limit_mb = RUNAWAY_MB
    procs = proc_table()
    mine, p = set(), os.getpid()
    while p in procs and p > 1:
        mine.add(p)
        if procs[p][2] == "claude":
            break
        p = procs[p][0]
    root = p if p in procs and procs[p][2] == "claude" else None
    if root is None:
        return ""
    best = None
    for pid, (ppid, rss, name) in procs.items():
        if pid in mine or name in ("zsh", "bash", "sh", "sandbox-exec", "claude") or re.search(r"mcp|server|npx|npm|uvx?$", name, re.I):
            continue
        a, via_shell = ppid, False
        while a in procs and a != root and a > 1:
            if procs[a][2] in ("claude", "codex"):  # belongs to a nested chat this one started, not to this chat
                break
            if procs[a][2] in ("zsh", "bash", "sh", "sandbox-exec"):
                via_shell = True
            a = procs[a][0]
        if a == root and via_shell and rss > limit_mb * 1024 and (best is None or rss > best[1]):
            best = (pid, rss, name)
    if not best:
        return ""
    pid, rss, name = best
    if os.environ.get("CHAT_GUARD_TEST_DRYRUN"):
        return "would stop %s pid %d %.0f MB" % (name, pid, rss / 1024.0)
    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(15):
            time.sleep(0.1)
            os.kill(pid, 0)
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    except Exception as e:
        log("stop failed %d %s" % (pid, e))
        return ""
    log("stopped runaway %s pid %d %.1fGB" % (name, pid, rss / 1048576.0))
    return "Stopped `%s` (pid %d, %.1f GB), a command this chat started, so the Mac doesn't run out of memory." % (
        name, pid, rss / 1048576.0)


def top_users(n=3):
    try:
        procs, groups = proc_table(), {}
        for _, (_, rss, name) in procs.items():
            key = re.sub(r" Helper.*| \(.*\)$", "", name)
            groups[key] = groups.get(key, 0) + rss
        top = sorted(groups.items(), key=lambda kv: -kv[1])[:n]
        return ", ".join("%s %.1f GB" % (k, v / 1048576.0) for k, v in top) or "unknown"
    except Exception:
        return "unknown"


def emit(event, context=None, user=None, extra=None):
    out = {}
    if user:
        out["systemMessage"] = user
    hso = dict(extra or {})
    if context:
        hso["additionalContext"] = context
    if hso:
        hso["hookEventName"] = event
        out["hookSpecificOutput"] = hso
    if out:
        print(json.dumps(out))


def ask_text(mb, path, first):
    lead = "This chat is now %.0f MB" % mb
    return ("%s (chat guard%s). A handoff snapshot is saved at %s. Finish the step you're on, don't start new "
            "agents or big jobs, then end your turn by asking Alex in one line: start a fresh chat from the handoff, "
            "or keep going here? If you're the Director, also write the proper handoff per "
            "references/handoff.md before asking." % (lead, "" if first else ", reminder", path))


def size_check(ev, st, sid, event):
    mb = size_mb(ev.get("transcript_path", ""))
    if not st["awaiting"] and mb >= st["next_ask_mb"]:
        path = write_handoff(ev, mb)
        st.update(awaiting=True, asked_mb=mb, handoff=path)
        save_state(sid, st)
        return ask_text(mb, path, True), "Chat is %.0f MB: handoff saved (%s). Claude will ask: fresh chat or keep going." % (mb, path)
    if st["awaiting"] and mb >= st["asked_mb"] + REMIND_MB:
        st["asked_mb"] = mb
        save_state(sid, st)
        return ask_text(mb, st.get("handoff", "(see earlier note)"), False), None
    return None, None


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "post"
    ev = json.load(sys.stdin)
    sid = ev.get("session_id") or "unknown"
    in_agent = bool(ev.get("agent_id"))
    st = load_state(sid)
    avail, pressure = memory()

    if mode == "pre":
        tool, inp = ev.get("tool_name", ""), dict(ev.get("tool_input") or {})
        if critical(avail, pressure):
            log("refused new %s at %s%% available" % (tool, avail))
            emit("PreToolUse", extra={"permissionDecision": "deny", "permissionDecisionReason":
                 "Mac memory is critical (%s%% available; biggest: %s). Not starting a new agent until it recovers; "
                 "finish or stop running work first, then retry." % (avail, top_users())})
        elif tool in ("Agent", "Task") and isinstance(inp.get("prompt"), str) and "Memory rule (chat guard)" not in inp["prompt"]:
            inp["prompt"] += AGENT_LINE
            emit("PreToolUse", extra={"permissionDecision": "allow", "updatedInput": inp})
        return

    if mode == "prompt":
        if st["awaiting"]:
            mb = size_mb(ev.get("transcript_path", ""))
            wants_fresh = re.search(r"\b(fresh|new chat|new session|start over)\b", ev.get("prompt", ""), re.I)
            st.update(awaiting=False, next_ask_mb=mb + STEP_MB)
            save_state(sid, st)
            if wants_fresh:
                emit("UserPromptSubmit", "Chat guard: Alex wants a fresh chat. Finish the handoff (%s) and help him "
                     "open the successor." % st.get("handoff", ""))
            else:
                emit("UserPromptSubmit", "Chat guard: Alex is continuing in this chat (%.0f MB). Next check at %.0f MB. "
                     "If his message didn't answer the fresh-chat question, mention the size once in a short line." % (mb, mb + STEP_MB))
        return

    if mode == "start":
        context, user = (None, None) if in_agent else size_check(ev, st, sid, "SessionStart")
        emit("SessionStart", context, user)
        return

    # post: memory first (main chat and agents), then chat size (main chat only)
    notes, user = [], None
    if critical(avail, pressure):
        try:
            stopped = stop_runaway()
        except Exception as e:
            log("stop error %s" % e)
            stopped = ""
        if stopped or time.time() - st.get("last_crit", 0) > 60:
            st["last_crit"] = time.time()
            save_state(sid, st)
            msg = "Mac memory is critical (%s%% available; biggest: %s)." % (avail, top_users())
            notes.append(msg + (" " + stopped if stopped else " Don't start agents or heavy commands until it recovers."))
            user = msg + (" " + stopped if stopped else "")
    if not in_agent:
        context, size_user = size_check(ev, st, sid, "PostToolUse")
        if context:
            notes.append(context)
        user = user or size_user
    emit("PostToolUse", " ".join(notes) or None, user)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("error %s: %s" % (type(e).__name__, e))
    sys.exit(0)
