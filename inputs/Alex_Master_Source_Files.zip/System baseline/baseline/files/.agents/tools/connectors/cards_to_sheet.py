#!/usr/bin/env python3
"""Rebuild the "Tool cards" tab of the connectors workbook from the card files, so the sheet never drifts.

  python3 cards_to_sheet.py [workbook.xlsx ...]

Cards are the source: ~/.agents/tools/cards/*.md (one per app, every project) and the connector repo's
tools/*.md. For each card the tab shows the app, its one route, when it was last tested, and which skills
mention it. Run it after adding or changing a card. Default workbooks: the repo copy, then ~/Documents.
A workbook whose tab already holds exactly these values, in its place before "Skills", is left alone: no save,
so commits that change nothing on the tab (the post-commit hook runs this) don't re-save the workbook. The
~/Documents copy is refreshed only when the repo copy was saved or the two differ (2026-10-02, batch 8).
"""
import glob, hashlib, os, re, shutil, sys

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

H = os.path.expanduser("~")
REPO = f"{H}/Projects/master-connector-repo"
BOOK = f"{REPO}/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx"
COPY = f"{H}/Documents/connectors-2026-09-30.xlsx"
TAB = "Tool cards"
NOTE = ("A tool card is one page per app: the one route to use, which login, what it reaches and can change (tested, with the "
        "date), and its rules, with the hazards and the asks first. A skill is a step-by-step job that uses one or more tools. How "
        "the cards reach every AI: (1) the always-loaded App rules block names every card and says to read it before the first "
        "call, plus the two cross-app rules (name the login; samples can send or spend, budgets ask Alex and never go through "
        "proxy) (blind split test 2026-10-01: work/2026-10-01_setup-playbook/notes/app-rules-redesign.md); (2) the hosted notes "
        "tool Composio CUSTOM_IR_NOTES_GET_APP_RULES returns a full card on any machine, and its description lists every card "
        "with its index line; (3) the card files themselves (~/.agents/tools/cards). Hard stops are also enforced by the guard "
        "hooks. Edit the card and commit ~/.agents: the hook updates the hosted notes, the instructions and this tab. Never "
        "edit the sheet by hand.")
COLS = [("app", 22), ("card file", 34), ("the one route", 60), ("last updated", 13), ("rules in the card", 11),
        ("skills that mention it", 40)]


def card(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    front = dict(re.findall(r"(?m)^([a-z_]+):\s*(.+)$", text.split("---")[1])) if text.startswith("---") else {}
    title = (re.search(r"(?m)^# (.+)$", text) or [None, os.path.basename(path)[:-3]])[1]
    rules = len(re.findall(r"(?m)^\s*- ", text))
    words = {os.path.basename(path)[:-3].replace("-", " "), os.path.basename(path)[:-3]}
    words |= set(re.findall(r"(?:custom_[a-z0-9_]+|ghl-[a-z-]+|googleads|google_analytics|mcp__[A-Za-z_]+)", text))
    words.add(title.split(":")[0])
    return title.split(":")[0], front.get("route", ""), front.get("updated", ""), rules, words


def skills_using(words):
    hits = []
    for f in sorted(glob.glob(f"{H}/.agents/skills/*/SKILL.md")):
        with open(f, encoding="utf-8", errors="replace") as fh:
            body = fh.read()
        # short names (Ref, Exa, GA4) must match their exact case; longer ones match any case
        if any(re.search(r"(?<![A-Za-z0-9_])" + re.escape(w) + r"(?![A-Za-z0-9_])", body, 0 if len(w) <= 4 else re.I)
               for w in words if len(w) >= 3):
            hits.append(os.path.basename(os.path.dirname(f)))
    return ", ".join(hits[:8]) + (f" (+{len(hits) - 8})" if len(hits) > 8 else "") or "none yet"


def card_paths():
    paths = sorted(glob.glob(f"{H}/.agents/tools/cards/*.md"))
    have = {os.path.basename(p) for p in paths}  # a global card wins over a repo copy or pointer with the same name
    return paths + sorted(p for p in glob.glob(f"{REPO}/tools/*.md")
                          if not os.path.basename(p).startswith(("_", "README")) and os.path.basename(p) not in have)


def tab_rows(paths):
    rows = []
    for p in paths:
        title, route, updated, rules, words = card(p)
        rows.append([title, p.replace(H, "~"), route, updated, rules, skills_using(words)])
    return rows


def grid(ws):
    """Every non-empty value of a sheet by (row, column); '' counts as empty, as openpyxl may read it back as None."""
    return {(c.row, c.column): c.value for row in ws.iter_rows() for c in row if c.value not in (None, "")}


def wanted(rows):
    want = {(1, 1): NOTE} | {(3, i): name for i, (name, _) in enumerate(COLS, 1)}
    want |= {(r, i): v for r, row in enumerate(rows, 4) for i, v in enumerate(row, 1)}
    return {k: v for k, v in want.items() if v not in (None, "")}


def in_place(wb):
    names = wb.sheetnames
    return names.index(TAB) + 1 == names.index("Skills") if "Skills" in names else names[-1] == TAB


def build(book, result=None):
    """Rebuild the tab in book and save it, unless the tab already holds exactly these values in its place. Returns the
    number of cards; result (a dict), when given, gets saved = True or False."""
    paths = card_paths()
    rows = tab_rows(paths)
    wb = openpyxl.load_workbook(book)
    if TAB in wb.sheetnames and in_place(wb) and grid(wb[TAB]) == wanted(rows):
        if result is not None:
            result["saved"] = False
        return len(paths)
    if TAB in wb.sheetnames:
        del wb[TAB]
    ws = wb.create_sheet(TAB, index=wb.sheetnames.index("Skills") if "Skills" in wb.sheetnames else None)
    ws["A1"] = NOTE
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLS))
    ws["A1"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[1].height = 110
    for i, (name, width) in enumerate(COLS, 1):
        c = ws.cell(row=3, column=i, value=name)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3864")
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = width
    for r, row in enumerate(rows, 4):
        for i, v in enumerate(row, 1):
            ws.cell(row=r, column=i, value=v).alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A4"
    wb.save(book)
    if result is not None:
        result["saved"] = True
    return len(paths)


def sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def refresh_copy(book, copy, saved):
    """Copy book to copy only when book was saved or the two differ; a refused copy (a sandbox) is reported, not raised."""
    if not saved and os.path.exists(copy) and sha256(book) == sha256(copy):
        return "copy already equal"
    try:
        shutil.copy2(book, copy)
        return f"copied to {copy}"
    except OSError as e:
        return f"could not copy to {copy}: {e.strerror}"


if __name__ == "__main__":
    books = sys.argv[1:] or [BOOK]
    saved = False
    for b in books:
        res = {}
        n = build(b, res)
        saved |= res["saved"]
        print(f"{b}: {n} cards" + ("" if res["saved"] else " (tab unchanged, not saved)"))
    if not sys.argv[1:] and os.path.exists(os.path.dirname(COPY)):
        print(refresh_copy(BOOK, COPY, saved))
