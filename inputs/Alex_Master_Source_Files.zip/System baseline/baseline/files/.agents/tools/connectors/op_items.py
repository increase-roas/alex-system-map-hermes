#!/usr/bin/env python3
"""Find a 1Password item's ID by its exact title in vault Connectors, with a known ID as the fallback.

A newcomer's fresh vault shares our item titles, not our IDs, so scripts look the title up first and fall back to
Alex's ID when no item has that title. The lookup lists item summaries (IDs and titles, never values), then the caller
reads by ID: 1Password secret references can't carry the em dashes and brackets in our titles ("Any part of a secret
reference that includes an unsupported character must be referred to by its unique identifier (ID)", 1Password
secret reference syntax docs). Two items with the same title: the fallback if it is one of them, otherwise stop.

  python3 op_items.py "<exact title>" <fallback id>    prints the ID (install_hub.sh; needs OP_SERVICE_ACCOUNT_TOKEN)

Robot calls on the Mac run inside `with robot_env(token) as env:` (spp-p49a, spp-p49b), so op never stalls on the
real HOME and one `op daemon` serves them all.
"""
import contextlib, json, os, subprocess, sys

VAULT = "Connectors"
# Git-ignored (runtime/). Holds op's config, the daemon's socket and pid file, and op's own encrypted session file
# (JWE, mode 0600); no plaintext secret and never the robot token (spp-p49b).
ROBOT_HOME = os.path.expanduser("~/.agents/runtime/op-robot")


@contextlib.contextmanager
def robot_env(token):
    """op's environment for a robot (service-account) call: HOME, OP_CONFIG_DIR and TMPDIR inside ROBOT_HOME, one
    persistent folder (mode 0700), so every robot call finds the same `op daemon` instead of starting its own.

    Under the real HOME, op 2.39.0 on Alex's MacBook stalls for minutes before any network step; with a private HOME
    it answers in about a second, and a robot call needs nothing from HOME (master-connector-repo mha-op1, spp-p49a).
    1Password documents no switch for it: developer.1password.com/docs/cli/environment-variables/ (read 2026-10-03)
    lists none, and OP_BIOMETRIC_UNLOCK_ENABLED=false and OP_CACHE=false alone don't stop it (github.com/1Password/
    op-js/issues/216, shell-plugins/issues/606, both open). op finds its home the go-homedir way, from HOME, and
    OP_CONFIG_DIR outranks it (developer.1password.com/docs/cli/config-directories/). op starts its daemon on every
    command when none is running; the daemon keeps its socket in OP_CONFIG_DIR, and its pid file in TMPDIR, or in
    XDG_RUNTIME_DIR when that is set (1Password staff, 1password.community thread 10218), so XDG_RUNTIME_DIR is dropped.
    A fresh folder per run left one daemon per run, each idle for up to 24 hours (`op daemon --help`; spp-p49a).
    OP_CACHE=false (developer.1password.com/docs/cli/reference/) keeps the daemon from holding cached vault data.
    """
    os.makedirs(ROBOT_HOME, mode=0o700, exist_ok=True)
    os.chmod(ROBOT_HOME, 0o700)  # makedirs leaves an existing folder's mode as it is
    tmp = os.path.join(ROBOT_HOME, "tmp")
    os.makedirs(tmp, mode=0o700, exist_ok=True)
    env = dict(os.environ, OP_SERVICE_ACCOUNT_TOKEN=token, OP_BIOMETRIC_UNLOCK_ENABLED="false", OP_CACHE="false",
               HOME=ROBOT_HOME, OP_CONFIG_DIR=os.path.join(ROBOT_HOME, ".config", "op"), TMPDIR=tmp)
    env.pop("XDG_RUNTIME_DIR", None)
    yield env


def pick(items, title, fallback):
    ids = [i["id"] for i in items if i.get("title") == title]
    if len(ids) == 1:
        return ids[0]
    if not ids or fallback in ids:
        return fallback
    sys.exit(f"op_items: {len(ids)} items in {VAULT} are titled {title!r}; keep one, or pass its ID")


def list_items(env=None, op="op"):
    r = subprocess.run([op, "item", "list", "--vault", VAULT, "--format", "json"], env=env, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("op_items: 1Password item list failed: " + r.stderr.strip()[:300])
    return json.loads(r.stdout)


def item_id(title, fallback, env=None, op="op"):
    return pick(list_items(env, op), title, fallback)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    print(item_id(sys.argv[1], sys.argv[2]))
