---
name: ad-audio-polish
description: Clean and master the audio of a talking-head ad or short (denoise, echo, EQ, loudness to -14 LUFS), lay a music bed under the voice, cut in b-roll with velocity-matched seams, and add captions/hook/CTA text, all on Alex's Mac with nothing uploaded. Use whenever he sends a video clip and says the audio sounds bad, quiet, echoey, "off", or asks to optimize audio, add music, add b-roll, add captions, make it sound or look like a viral clip, or prep an ad for TikTok/Reels/Shorts. Use it even if he only says "fix this" with an mp4 attached.
---

# Ad audio polish

All tools live in `/Users/alexlobaito/Documents/Ai Helper/tools/audio/` (the copies under `scripts/`
here are references; run the ones in `tools/audio` because the models and the Python env sit next to them).
Nothing leaves the machine. Never upload his clip anywhere (Descript, Riverside, Atlas upload, any web enhancer).

## Rules that came from real corrections (read first)

1. **Use the exact file he attached.** Never rebuild from raw sources or swap in an earlier cut of mine.
   If he sends `X.mp4`, the output is `X_<tag>.mp4` next to it, and his original is never overwritten.
2. **Do only what he asked, send one file, once.** No side-by-side variants, no "for comparison" copies,
   no captions/zooms/banners he did not ask for. Extra deliverables made him furious.
3. **Copy what you did not touch.** If he asks for music, copy the video stream. If he asks for b-roll,
   copy the audio stream. Verify with a stream hash (`ffmpeg -i f -map 0:a -c copy -f md5 -`).
4. **Music starts at second 0** on a short-form ad. Sources agree the music must land in the first 1–2 s.
   Do not invent timing theories (I once held it to 6.9 s "for the script's turn" and he called it horrible).
5. **Music for ads comes from a library cleared for ads**, not generic stock. On TikTok that is
   TikTok Studio → Royalty-free sounds → Trending (`https://www.tiktok.com/tiktokstudio/sound-library`).
   It needs his TikTok login in the browser pane; the download button does not fire in that pane, so pull
   the file from the page's own playlist feed (`/tiktok/v1/creator/music/unlimited/playlist/detail/`,
   POST `{"page_size":10,"page_num":N,"unlimited_playlist_id":ID}`, then `play_url.url_list[0]`).
   For Meta ads use Meta Sound Collection. TikTok library tracks are cleared for TikTok only.
6. **For continuous talking, the music sits at a static level (about 16 LU under the voice), not ducked.**
   Sidechain ducking on speech with no pauses pumps on every syllable. `--duck` exists for clips with pauses.
7. **Cap noise reduction (default 15 dB).** Full removal leaves dead digital silence between words.
8. **Master with one constant gain plus a safety limiter.** Never `loudnorm` on the final pass: when the gain
   would push peaks past the ceiling it silently switches to dynamic (AGC) mode and flattens the voice.
   ffmpeg `alimiter` must have `level=false` or it re-inflates peaks to 0 dBFS.
9. **Process the voice once.** Every extra pass is another lossy encode. If he re-cut a file I already
   mastered, use `--voice-done` so cleanup and limiting do not run again.
10. **The echo model (`--echo`) sounded robotic to him.** Leave it off unless he asks for it by name.
11. **Pixel offset check:** his edited files can start the video 2 frames after the audio. Any frame-level
    tool must keep that offset (make-seams.py does).

## Targets (from EBU R128 / R128 s2 and every short-form guide)

-14 LUFS integrated, peaks ≤ -1.5 dBTP before AAC, voice mono-centered, 48 kHz, AAC 256k, video copied.
Phone-speaker voice EQ: -2.5 dB @ 300 Hz, +3 dB @ 3 kHz, +1.5 dB shelf @ 10 kHz, HPF 80 Hz, de-ess,
compressor 2.5:1 / -22 dB / 20 ms / 150 ms.

## Tools

| Job | Command (run from `tools/audio/`) |
| --- | --- |
| Full pass on a raw clip | `python3 make-short.py [--remove "a-b,c-end"] [--music T.mp3 --music-from S] --out-tag NAME clip.mp4` |
| Music only, voice already mastered | `python3 make-short.py --voice-done --music T.mp3 --music-from S --music-at 0 --out-tag NAME clip.mp4` |
| Quick cleanup, no music | `./clean-audio.sh [--short] clip.mp4` |
| Word timings (local whisper) | `.venv/bin/python -c` whisper `small.en` with `word_timestamps=True` → save `{"words":[...],"segments":[...]}` |
| Captions / hook text / CTA / punch-ins | `.venv/bin/python make-visuals.py clip.mp4 words.json --hook "..." --cta "..." [--brand "..."] [--cta-from T] [--no-zoom]` (only when asked) |
| B-roll cutaways | ffmpeg overlay of scaled+cropped b-roll enabled `between(t,a,b)` per line, audio `-c:a copy`; time cuts to word timings; put one inside the first 3 s |
| Velocity-matched seams on cuts | `.venv/bin/python make-seams.py composite.mkv his_audio.mp4 out.mp4 --cuts t1,t2,...` (cut-the-curve: 12% slide, 0.92/1.08 pull, 9 px blur, power4 in/out) |
| Room echo (only if asked) | add `--echo` to make-short.py (resemble-enhance, ~3x real time, mono) |

`--music-from` = seconds into the track where its main groove starts; find it by measuring 2 s smoothed
energy and taking the first point at 85% of the strong level with 30 s of runway left.

## Verify before sending

- Loudness: `ffmpeg -i out -af loudnorm=print_format=json -f null -` → input_i near -14, input_tp ≤ -1.4.
- Untouched stream hash matches his file.
- Frame-grab a contact sheet at the cut points and look at it.
- File under 30 MB for SendUserFile; otherwise send a `-crf 23` preview and say the full file is local.

## Where things are

- Binaries/models: `tools/audio/deep-filter`, `tools/audio/.venv` (torch, whisper, resemble-enhance, librosa, Pillow).
- Downloaded music: `tools/audio/music/tiktok-trending/`, `tools/audio/music/candidates/` (Mixkit, allowed in online ads).
- Hot tub b-roll: `/Users/alexlobaito/Downloads/drive-download-20260919T014654Z-1-001/BROLL-0*.mov`,
  catalogued in `runs/2026-09-18-hot-tub-transcripts/CLIP-LIBRARY.md` (shirt rule: white = AD-13..31).
