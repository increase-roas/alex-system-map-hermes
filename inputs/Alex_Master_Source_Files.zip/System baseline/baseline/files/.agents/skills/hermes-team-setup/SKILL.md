---
name: hermes-team-setup
description: Use when setting up, resuming or repairing an Increase ROAS Hermes agent role from the Build project's team foundation. Checks each role's real platform; not every role runs on Orgo.
---

# Hermes role setup and recovery

Canonical project: `/Users/alexlobaito/Documents/ChatGPT/Build`; paths below are relative to it. This skill's one home is `~/.agents/skills/hermes-team-setup/`; the project's `docs/skills/hermes-team-setup/SKILL.md` points here. The skill supplies reusable operating knowledge, not additional authorization.

## Start at the missing outcome

Read current `AGENTS.md`, the top checkpoint in `BUILD_STATUS.md`, and the target role's current file/source map and acceptance gate. For Javar, start at `agents/ea/startup/INDEX.md`; the former Notion/Sheets records are historical moved notices. For another role, verify its documented platform, current owner and route rather than assuming Javar's layout or Orgo applies. Follow only the evidence linked for the current gate. Dated candidate instructions describe the state at that time; newer actual receipts supersede them. Do not restart the project audit or treat every historical NOT_PROVEN label as current.

Recover six facts: requested outcome, last verified checkpoint, settled decisions, current identity/host, remaining gap, next action. Distinguish an accepted past capability from current runtime health. Reuse passing proof unless relevant code, identity, scope or behavior changed. Read back live state when performing a mutation; do not claim current health from old proof.

Historical Javar project/gate identifiers remain in dated evidence. They are not Javar's active instruction owners and must not be restored over the file catalog.

## Reuse map

Before building anything, find the existing asset for each need (role foundation, identity, Slack app, shared tasks, customer GHL/RAG, ads reads, runtime and 1Password setup, team pilot, finance) and its limit in `references/reuse-map.md`.

## Materialize without cloning private state

Inspect `materialize.py` before use; its exact binding schema differs from some role binding templates. It requires `role_id`, `display_name`, `mission`, `customers`, `owner_slack_id`, `slack_team_id`, `owner_dm`, `hermes_home`, and permits optional `war_room`. Build a nonsecret input containing those fields only. Use a simple ASCII display name accepted by its validation. Use actual Slack IDs and an independently assigned home.

Run the existing materializer with that binding and a new output directory. Its accepted-source hashes must match; on mismatch, inspect the changed file and existing proof instead of removing or updating the hash guard just to proceed. Do not overwrite an existing serving home. Output includes task records and approval mechanics, not the runtime, credentials, model login, RAG grants or automatic sending.

Keep the same Hermes/Orgo/Slack/Cloudflare-vector/1Password architecture. Jeremy references guide genuinely unresolved Jeremy-specific decisions; don't query Ask Jeremy for settled installation details. Every role needs its documented identity and scope. Dedicated computers are the existing deployment choice, not a technical rule that all possible agent roles universally require a machine. Hunter already shares B2B/Setter; preserve documented assignments.

## Known rollout traps

- Buy capacity only when approved and actually needed. A workspace with no computers is not spare paid capacity. A capacity purchase does not itself create a computer. After uncertain responses, reconcile account limits and inventory before retrying a purchase/create.
- When the verified target uses Orgo, create/get responses may include desktop credentials. Filter tool output to ID, name, status and hardware before emitting it; never print raw responses or save them as evidence. Do not use this as a reason to move a non-Orgo role.
- Native Hermes authentication may save `shared/nous_auth.json` in addition to `auth.json`. Check actual destination and existing named-file approvals before provisioning. Never automate owner security-approval clicks.
- Keep gateway/provider/session identity distinct from Chrome profile/email identity. A signed-in browser alone does not prove the gateway can use its provider.
- For Javar, preserve the authorization and context-separation rules in `agents/ea/startup/AGENTS.md`. His terminal, file, search, and code tools use Hermes' native local backend as the unprivileged service user. Global sender access stays Alex-only; peer bot access is limited to the private war room. Do not grant peer agents Alex's inbox access.
- For Javar runtime updates and recovery, use `agents/ea/runtime-update/README.md` and its reviewed manifest; the accepted serving paths are listed in `agents/ea/startup/TOOLS.md`. Do not restore older copied-runtime paths or run a generic update over the reviewed residual seams.
- Use verified bot IDs and mention only the next assignee; progress messages should not summon every bot. Preserve customer identity across handoffs. Coordinator streaming caused duplicate processing in the recorded pilot; recover that fix rather than enabling it casually.
- Validate shared-task request ID/revision/evidence fields before credential access. Native provider rate-limit handling already exists; inspect the error/cooldown rather than creating a new retry daemon or changing models blindly.
- A process or Supervisor RUNNING state is not reboot-persistence proof. Use the actual role process, native gateway state and Slack connection; don't infer service health from a stale Supervisor socket.

## Fast completion

Prepare only the missing role bindings, connections and business outcome. Independent source preparation or documentation may overlap a live rollout, but one operator owns each runtime, app, credential set and shared configuration. Don't add an orchestration workflow just to invoke this skill.

Use one representative end-to-end acceptance for the changed gate; reuse accepted component proof. On failure fix and rerun that scenario only. Keep exact-message approvals, customer boundaries and credential protection from current policy. A new skill does not waive them.

For Javar, update the affected maintained source, installed file, and INDEX/TOOLS/WORKFLOWS pointer; store a concise sanitized receipt in the repository. Do not reactivate the retired Notion or Sheets records. For another role, update its verified current owner. Update a mutable current checkpoint when it changes; retain historical proof as history instead of creating competing current checklists. Stop at the user's requested outcome or a genuine missing decision/access approval.
