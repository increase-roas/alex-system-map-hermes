---
name: competitive-ads-extractor
description: >
  Extracts and analyzes competitors' ads from ad libraries (Facebook, LinkedIn, etc.) to understand what messaging, problems, and creative approaches are working. Helps inspire and improve your own ad campaigns.
---

# Competitive ads extractor

Pull ads from the live library or a provided export. Group by hook, problem, offer, creative format, and CTA.

## Output
- Table of ads: advertiser, hook, body, offer, format, dates if available
- Patterns that repeat
- Gaps the user can test
Do not invent ads that were not found.

