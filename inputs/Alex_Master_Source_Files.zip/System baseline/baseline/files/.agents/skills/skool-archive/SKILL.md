---
name: skool-archive
description: Archive an entire Skool community - every lesson, video transcript, comment thread and downloadable asset - using Apify. Use when asked to scrape, archive, back up or analyze a Skool classroom, course, group or community, or when working with skool.com URLs. Covers the full pipeline and the platform-specific traps that waste hours.
---

# Archiving a Skool community

Default group: **aimoney** (`https://www.skool.com/aimoney`) unless another slug is given.

## Order of operations

1. Scrape the classroom → get lessons + video URLs + comment counts
2. Save the written lessons (most people forget these; they are usually the bulk)
3. Branch videos by platform and transcribe
4. Pull comment threads
5. Resolve and download linked assets (see `drive-link-harvest`)

## 0. Cookies

Only `auth_token` is needed. Read it from `skool-cookies.local.json` in the
working directory. If missing, get it yourself — do not send the user to a
browser extension.

**Each actor wants a different shape for the same cookie:**

| Actor | Field | Shape |
|---|---|---|
| `dz_omar/skool-scraper-pro` | `cookies` | ARRAY of cookie objects |
| `memo23/skool-posts-with-comments-scraper` | `cookies` | ARRAY, and REQUIRED |
| `scrapersdelight/skool-classroom-scraper` | `skoolCookie` | bare STRING |

## 1. Classroom scrape

`dz_omar/skool-scraper-pro` (id `hB9IbHEVNb2Sf1PrJ`)

```json
{ "communityUrls": [{"url": "https://www.skool.com/SLUG/classroom"}],
  "maxItemsPerSection": 200, "skipLockedCourses": false,
  "extractCommunityFeed": false, "downloadResources": false,
  "downloadVideos": false, "cookies": [ ...auth_token only... ] }
```

- **`skipLockedCourses: false`** if the user is a paying member, or gated
  courses are silently skipped.
- **A big classroom takes 10+ minutes.** Poll `get-actor-run` until
  `status: SUCCEEDED`. Do NOT read an interim `itemCount` and report it as the
  total — it keeps climbing. This produced a wrong "357 lessons" when the real
  answer was 599.

### Faster survey alternative
`scrapersdelight/skool-classroom-scraper` does ~115 lessons in 19 seconds and
returns `media_type` + `media_url` per lesson. Use it to get the video
inventory fast. **Its `communities` field takes a community slug ONLY** — pass a
course URL and it silently ignores the course and starts from lesson 1, with no
error. To reach a course deep in the list, raise `maxItems` past its position.

Its `transcript` field only works on Skool-native (Mux) uploads. Almost every
community embeds YouTube, so expect `null`. Its real value is `media_url`.

## 2. Save the written lessons

The scrape returns `descriptionText` per lesson. Write each to its own file
grouped by course. This is normally the single biggest content body and the
easiest thing to forget.

Check `descriptionRaw` (HTML) for lessons where `descriptionText` is empty —
occasionally content hides there. Strip tags and keep anything over ~10 words.

## 3. Videos — branch by platform

Read `lessonVideo.url` and `hostedVideo.videoId` across ALL lessons first, then
branch. Never assume one platform.

| Platform | Tool | Cost | Notes |
|---|---|---|---|
| YouTube | `karamelo/youtube-transcripts` | $0.006 each | Takes `urls` array. ~20 per batch. Reliable. |
| Loom | `kaz_kakyo/media-url-transcriber` | ~$0.005 | Set `preferCaptions: true` |
| Vimeo | — | — | **Usually impossible, see below** |
| Mux (Skool-native) | `scrapersdelight/...` | per-lot | Its transcript field works here |

### Vimeo is usually a dead end
Skool-embedded Vimeo videos are typically **private / embed-restricted**. Every
attempt returns `errorCode: "private"`, HTTP 403. Vimeo validates a signed token
from the embedding domain — a spoofed `Referer` does NOT work, and the
`player.vimeo.com/video/{id}/config` endpoint refuses too.

Failed items are **not billed**, so testing costs nothing. Test one, and if it
returns `private`, stop. Do not build a workaround for the signing — the only
remaining route is the user screen-recording playback themselves.

### Verify coverage afterwards
Match classroom video IDs against transcripts on disk. Do not match on a
`Video ID:` header alone — files written in different passes have different
headers. Match on title-token overlap AND id. One video silently dropped from a
batch that returned "12 of 13" and went unnoticed.

## 4. Comments

Use `dz_omar/skool-scraper-pro` with `postUrls` (NOT the posts actor).
Get post URLs from the classroom scrape's `post.postUrl`, filtered to lessons
where `post.commentsCount > 0`.

```json
{ "postUrls": [{"url": "..."}, ...], "maxCommentsPerPost": 300,
  "downloadAttachments": false, "cookies": [...] }
```

**The output shape is the trap.** Each row is a POST, and its comments arrive as
a **LIST nested under the `comment` key** — not as separate rows.

```python
for row in items:
    for c in (row.get("comment") or []):
        ...  # c has commentId, parentId, rootId, depth, content, author, createdAt
```

Do NOT use a `fields=` projection with `comment.content` etc. — dot-notation
either returns empty objects or collapses `comment.content` into the post's own
`content` field, silently overwriting it. Fetch raw and parse locally.

Rebuild reply nesting from `parentId`; roots are comments whose `parentId` is
not itself a comment id.

Cost is far lower than it looks: comments ride along with their post, so ~1,160
comments across 20 threads cost about 3 cents.

## 5. Assets
See the `drive-link-harvest` skill.

## Known numbers for aimoney (2026-09)
599 lessons, 23 courses, 503 with real text, 68 YouTube videos, 7 Vimeo (all
locked), 1 Loom, ~4,330 comments across 118 posts.
