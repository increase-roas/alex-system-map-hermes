---
name: javar-add-tool
description: Use when adding, enabling or repairing a tool route for Javar on Hermes/Orgo. Reuses existing credentials, syncs his TOOLS.md and INDEX.md catalogs, and proves one real use.
---

# Add a tool to Javar

Make the requested tool usable quickly in Alex's private Javar conversation. Finish the connection, discovery route, pointers, and one representative use. Keep the change proportional to the request.

## Start with the existing route

Repository: `/Users/alexlobaito/Documents/ChatGPT/Build`. This skill's one home is `~/.agents/skills/javar-add-tool/`; the repository's `docs/skills/javar-add-tool/SKILL.md` points here. Read its current `AGENTS.md` for authorization and context-separation rules. This skill adds no approval requirements. Reuse accepted work and evidence; inspect only the requested tool and its dependencies.

Read `agents/ea/startup/TOOLS.md` and the relevant provider guide, then their installed copies. Read `1Password-Config.md` and `Composio.md` when connection or credential routing is involved. Verify the actual discovery/loader route. A tool already supported by a connected provider may need only discovery and pointer updates; do not invent a wrapper, task workflow, or new service for it.

Javar's assigned Orgo computer is `d9b475e2-47b2-46d4-b8eb-102564f93283`. Installed guides are under `/home/orgo/lil-smoove/home/agent-knowledge/01-Agency/agent-os/`; startup instructions are `/home/orgo/lil-smoove/workspace/AGENTS.md`. Confirm these against the current configuration before changing them.

## Make the smallest useful change

- Reuse the existing provider connection and protected 1Password gateway route. Inspect metadata and success/failure without exposing secret values. A scope denial is not proof of missing credentials. Do not add plaintext credential files or give task containers vault access.
- If the requested tool has no usable connection, establish the specific missing login, provider permission, or supported integration first. Complete independent setup, then give Alex the exact connection/authorization step that requires him. Never request secrets in chat. Stop retrying an unchanged authentication or permission failure; resume after the missing prerequisite changes. Report unsupported capabilities plainly instead of silently building a custom integration.
- Keep discovery lightweight: expose a short capability pointer and retrieve the requested tool's schema/instructions when needed. Do not preload every provider schema or copy a full tool catalog into startup instructions. Verify this behavior through the actual loader configuration.
- In Alex's private conversation, use standing owner access without manual task/customer bindings. Identify the selected account by name and ID before work; ask only when the target is ambiguous. Preserve team, delegated-task, customer-record, and Manny isolation.
- Installing a tool is not approval to send, publish, activate campaigns, spend or make consequential changes; those stay under the repository's approval rules. Do not bypass a provider denial or approval UI.
- For Composio, use the existing scoped CLI where supported; use the permitted native MCP route for known CLI limitations. Reconcile uncertain writes before retrying.
- Back up changed runtime files. Reload only when the change needs it. The existing gateway service is `lil-smoove-messaging-gateway`; confirm its current identity before using it. Do not start an old duplicate gateway.

## Update the pointers in the same session

Use Javar's existing `INDEX.md` and `TOOLS.md` catalogs. Amend the relevant tool entry and detailed installed guide; never create a duplicate registry. The former Company OS Pointer Registry and Build-Out Map are historical evidence surfaces and are not current maintenance targets.

Update the provider guide and affected `TOOLS.md` or `INDEX.md` entry in repository source and installed copies together. `TOOLS.md` is the one concise route catalog; do not recreate an intermediate catalog. Keep the route entry explicit about how Javar discovers the tool, the account scope, and the credential guide. Record verified connection status separately from approval status. Read back the edited source, catalog and installed files. Leave the retired external rows as historical moved notices.

## Verify once, then finish

Default acceptance is one harmless representative operation through Javar's actual available route. Combine retrieval of the updated instructions, discovery, account identification, and a bounded read into that check. Notify Javar through the authorized owner conversation and verify he retrieves/selects the route; a delivered message or direct provider API call alone is insufficient.

Reuse existing component proof. Add a focused boundary check only if scope, approval, credentials, or loader code changed. For approval repairs, verify the real owner-facing request and manual decision as required by repository policy; never click approval for Alex. Do not publish, spend, or contact customers as a test. If no safe acceptance exists, report the exact unverified behavior.

After a reload, confirm the process, serving status, and Slack/Telegram connections. Do not run unrelated provider regressions, full role setup, a broad audit, or a long model exercise for routine onboarding. If a check stalls, inspect the narrow failure and retry that scenario; do not restart all verification. Once the relevant checks pass, stop.

Finish with a short result: tool ready, how Alex asks for it, pointer synchronization status, and any concrete remaining limitation. Claim only observed behavior. Leave unsynchronized surfaces or untested approval behavior explicitly unfinished. A short receipt can record changed paths, the live result, and rollback location; do not build a new reporting system.
