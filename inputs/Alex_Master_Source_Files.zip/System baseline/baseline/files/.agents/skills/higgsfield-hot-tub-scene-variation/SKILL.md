---
name: higgsfield-hot-tub-scene-variation
description: Use for Higgsfield batches of the same hot tub in new scenes, like “same tub in California,” “10 of these,” new camera angles, showroom, patio or snowy backyard. Not for same-scene cleanup.
---

# Higgsfield Hot Tub Scene Variation

## Contract

Turn real reference photos of one hot tub into the requested quantity of new-scene images of that same product. Treat the references as the specification. Never substitute a similar tub or invent hidden features. Product fidelity beats scene variety and beauty.

Do not replace the exact-replica optimizer. If the user asks only to clean, sharpen, upscale, or reproduce the same photo in the same scene, route there and stop.

## Protect truth

- Never alter jet count/layout, seat/lounger geometry, shell/cabinet colors or patterns, headrests, logos, control panel, valves, lights, trim, seams, steps, rail, cover, or hardware.
- Never import people, SOLD signs, store branding, prices, event details, testimonials, military status, or customer claims from a style reference.
- Treat generated people as lifestyle actors, never real customers or testimonials.
- Treat generated delivery, installation, event, and SOLD scenes as illustrative, never proof.
- Preserve only real readable product text in authoritative references. Never invent marketing copy.
- Never certify a new angle when newly visible product surfaces lack a real matching-angle reference.

## Classify the request

Use one route:

1. `SAME-ANGLE SCENE SWAP`: Preserve product viewpoint and geometry; change environment, time, lighting, or people. This is highest fidelity.
2. `SUPPORTED NEW ANGLE`: Use only when supplied real photos cover every newly visible shell, cabinet, control, jet, and hardware surface.
3. `UNSUPPORTED NEW ANGLE`: Ask only for the missing real front/side/back/top photo and stop.
4. `MULTI-PRODUCT SHOWROOM`: Require one product pack per distinct tub. With one pack, repeat only that exact tub.

If no product image is available, ask for it and stop.

## Assign reference authority

Separate inputs:

- `PRODUCT REFERENCES`: authoritative. Prefer front 3/4, opposite 3/4, top/interior, control/logo close-up, and cabinet/accessory close-up.
- `STYLE REFERENCES`: non-authoritative. Use at most one per output. Borrow only candid phone feel, framing, ordinary clutter, human distance, location cues, and lighting.

Attach all product references to every generation. If references compete, remove the style reference first.

## Lock the fingerprint

Analyze every product reference and explicitly zoom into small details. Record:

- proportions, rim, corners, and cabinet/shell relationship;
- exact visible jets by seat/lounger, including ring shape/material/color;
- seating, footwell, filter/skimmer, shell color/pattern/texture/gloss;
- cabinet color, panel direction/texture, trim, seams, vents, fasteners, base, and badge;
- headrests and logos; control position/display/buttons; valves, lights, waterfall;
- steps, rails, cover, lifter, and other accessories;
- unknown details and supported camera sectors.

Never estimate unreadable text or hidden geometry. Mark it `UNKNOWN` and prohibit views that require inventing it. Save one canonical fingerprint per product; never replace it with one extracted from a generated image.

## Build the manifest

Expand the request into exactly the requested quantity. Each row specifies: output number, archetype, region cues, setting, camera position/height, time/light, people/action or none, selected style reference, and fidelity route.

Make meaningful variations. Keep the product fingerprint fixed.

For California, use one coherent ordinary subregion per image: modest stucco tract homes, block walls, redwood fences, pavers/concrete, dry lawns, drought-tolerant plants, citrus, foothill haze, marine layer, or simple pergolas. Do not stack ocean, desert, mountains, and palms into every scene.

## Enforce phone-photo realism

Request:

- modern phone main camera, about 24–28mm equivalent;
- automatic exposure/white balance, mild sharpening, restrained HDR, subtle sensor noise/JPEG texture;
- imperfect eye/chest-height framing and slightly off-center composition;
- real mixed light or hard sun appropriate to the scene;
- ordinary mid-distance people, natural posture/clothes;
- believable home/showroom/event clutter;
- no cinematic grade, portrait bokeh, studio softbox, luxury catalog styling, or excessive polish.

Require rigid straight cabinet seams; restrained acrylic gloss; environment-matched reflections; water below the rim; physically caused ripples; one light direction; full ground contact and contact shadow; aligned steps/rails; and real full-size scale.

## Generate

Use `seedream_v5_pro` as primary model. Use 1K for 1000×1000 Meta feed batches and calibration. Use 2K when the placement, crop room, or micro-detail review needs it. Use the requested ratio; default to 1:1 only when no placement or dimensions are supplied.

For same-angle swaps, preserve the tub as unchanged foreground subject and edit environment, people, and lighting around it. When masking is available, protect shell, cabinet, controls, steps, rail, cover, and accessories.

For supported new angles, state which real reference governs each newly visible surface.

Submit two calibration images first. QC them. If one passes, fold any precise correction into the remaining manifest and submit the rest asynchronously. One invocation owns the whole batch; never make the operator hand-build separate prompts.

Use this prompt:

```text
Create one candid, photorealistic phone photograph using the attached references.

REFERENCE AUTHORITY:
- Images [PRODUCT IDS] are PRODUCT REFERENCES. They define one exact real hot tub and are authoritative for all geometry, materials, colors, features, text, and accessories.
- Image [STYLE ID] is STYLE ONLY. Borrow only its candid phone-camera realism, framing looseness, lighting character, and ordinary-environment feel. Do not copy its product, people, signs, brands, prices, or claims.

PRODUCT LOCK:
[TUB FINGERPRINT]

Create [SHOT ARCHETYPE] in [REGION/LOCATION], specifically [SETTING], viewed from [ANGLE], at [TIME/LIGHTING]. [PEOPLE DIRECTION].

Show the SAME tub from the product references, not a similar spa. Preserve every visible and reference-covered jet, seat, headrest, control, valve, logo, shell feature, cabinet panel, seam, trim piece, step, rail, and cover component exactly. Do not add, remove, move, resize, recolor, relabel, or redesign anything.

PHONE-PHOTO REALISM:
Modern phone main-camera photo, 24–28mm equivalent, ordinary auto exposure and white balance, mild computational sharpening, restrained HDR, subtle sensor noise and JPEG texture, imperfect framing, believable full-size spa scale. Restrained acrylic gloss, environment-matched reflections, plausible waterline/ripples, straight rigid cabinet geometry, grounded base, correct contact shadow, one coherent light direction.

EXCLUSIONS:
No CGI, 3D render, luxury catalog styling, studio lighting, cinematic grading, extreme bokeh, wax skin, malformed hands, duplicate people, floating product, melted edges, warped cabinet seams, impossible water, extra/missing jets, altered logos, invented text, signs, prices, testimonials, or customer proof.
```

## Run mandatory QC

Poll job status. Analyze the candidate side by side with every product reference and zoom into small details. PASS only if all comparable details match:

- proportions, rim, corners, visible jets, seating, footwell;
- shell/cabinet color, pattern, material, panels, seams, trim, and base;
- headrests, control, valves, lights, skimmer/filter, logos/badge;
- cover, steps, rails, and accessories;
- requested scene, angle, region, light, scale, perspective, contact shadow, water, reflections, anatomy;
- no invented text, branding, offer, sign, or proof.

Any product mismatch is FAIL. “Close enough” and “same type” never pass.

## Correct within caps

Retry a failed image once by appending only the named mismatch:

```text
CORRECTION: Previous output added two jets to the front-left seat and changed the cabinet vent. Match Product Reference 2 exactly: restore the original front-left jet pattern and the single rectangular vent in its exact position. Change nothing else.
```

Caps:

- one retry per failed output;
- at most four retries per ten-image batch;
- at most two attempts per calibration image.

Never call a failed image approved. Deliver passes plus one compact exception line. If the product pack does not cover an angle, request only the missing real view.

## Deliver

Return numbered passing images in manifest order. Give one line per image: dimensions, scene, angle, `PRODUCT FIDELITY PASS`. Add an exception line only for a failed output or micro-detail requiring human review. Do not add theory, alternates, or an offer to create more.

## Hard rules

- Product references outrank style and aesthetics.
- Maximum one style reference per output.
- Never certify hidden geometry.
- Never use generated output as the canonical product reference.
- Never use synthetic customer/SOLD/event/delivery imagery as real proof.
- Never alter the replica optimizer.
- Never exceed retry caps.
- Seed control is unverified; do not claim seed reuse locks the product.
