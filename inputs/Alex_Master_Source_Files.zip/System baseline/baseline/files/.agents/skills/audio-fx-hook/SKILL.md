---
name: audio-fx-hook
description: Analyze the audio of any video (loudness, pauses, spectrogram, voice pitch over time) and apply a pitch-shifted "deep" or "squeaky" voice to just the hook of an ad, all with local ffmpeg — nothing gets uploaded. Use when Alex asks what audio effects a video uses, to "analyze the audio", to make a demon/chipmunk/deep/squeaky voice, to add a voice-effect hook to a Meta ad, or to check a video's loudness for Reels/Shorts.
---

# Audio FX Hook

Two jobs, both local. Never upload his media anywhere (see memory `no-media-uploads`).

## Job 1 — Analyze a video's audio

1. Get the file. If it's a URL, download it with `yt-dlp` (install into a scratch venv with `pip install yt-dlp`; needs sandbox bypass for network).
2. Run `scripts/analyze.sh <video>`. It writes into `<video>-audio/`:
   - `stats.txt` — integrated loudness (LUFS), loudness range, true peak, stereo width, silence gaps
   - `spec.png` — full spectrogram; `wave.png` — waveform
   - `pitch.txt` — voice pitch (Hz) per second
3. Read `spec.png` and `pitch.txt` and describe what you see in plain words. Always check the pitch track before saying "no pitch shifting" — on 2026-09-19 I missed an obvious deep/squeaky voice effect because I only looked at the spectrogram.

How to read the numbers:
- Normal adult male voice ≈ 100–125 Hz. Values stuck at 65–95 Hz = pitched down; 150–330 Hz = pitched up.
- Shorts/Reels target ≈ -14 LUFS. -23 is quiet.
- Side (L−R) level under -50 dB = mono.
- A burst of broadband noise + low-pass on the voice + a steady tone at 3–6 kHz = the "flashbang / ear ringing" gag.

## Job 2 — Put a voice effect on the hook of an ad

Rules (from research on 2026-09-19 — agency blogs, not Meta docs):
- Effect goes on the **hook line only**, inside the first 1.5–3 s. Offer, price and CTA stay in his natural voice so the buyer trusts him.
- Deep = down 6–8 semitones (`0.65`). Squeaky = up 6–8 semitones (`1.5`). Pick one per version; export each as its own whole ad and test them against a clean one.
- Cut back to natural on a hard cut, no crossfade.
- Work on the exact file he sent. Copy the video stream. Don't touch loudness.

Steps:
1. Find where the hook line ends: `scripts/hook_end.sh <video>` transcribes the first 10 s with local whisper-cli and prints word timings. Pick the end time of the last hook word.
2. Render: `scripts/hook_fx.sh <video> <hook_end_seconds> <factor> <label>`
   - e.g. `hook_fx.sh A.mp4 5.33 0.65 DEEP` and `hook_fx.sh A.mp4 5.33 1.5 SQUEAKY`
   - Output lands next to the input as `<name>_HOOK-<label>.mp4`.
3. Verify with `scripts/analyze.sh` on the output: pitch in the hook window moved, pitch after it unchanged, LUFS within 0.5 of the original, duration identical.
4. Send the files with SendUserFile. Fewest files, once.

## Gotchas
- Homebrew ffmpeg has no `rubberband` and no `drawtext`. Pitch shift uses `asetrate` + `atempo` (resample then retime); that keeps timing and gives the deliberately unnatural demon/chipmunk tone, which is the point.
- `whisper-cli` prints nothing under the sandbox; run it with the bypass. Model: `~/whisper/models/ggml-large-v3-turbo.bin`.
- Pitch tracking is autocorrelation in `scripts/pitch.py`; it needs the venv with numpy.
