---
name: analyzing-crm-conversations
description: Use when analyzing CRM exports, call transcripts, recorded calls, message threads or rep activity across an account or pipeline. Read-only; every finding cites its source.
---

# Analyzing CRM Conversations

## Core principle

Every material finding must trace to a source. Missing evidence is `NOT_PROVEN`, not a signal.

## Boundary

Analyze read-only unless the user authorizes a write or communication. “CRM-ready” means draft only. Omit unnecessary PII and long passages.

## Workflow

1. **Inventory coverage.** State account, date window, requested/found counts, channels, transcript records, unavailable records, issues, and speaker/timestamp availability.
2. **Separate sources.** Keep customer words, rep words, system fields, notes, and analysis distinct. CRM stage/value do not prove buyer intent.
3. **Build an evidence ledger.** Capture pain, outcome, fit, objections, urgency, budget, authority, decision process, competition, commitment, and next step. Cite conversation/contact ID plus timestamp, or a short quote.
4. **Label conclusions.** `VERIFIED` is source-explicit, `INFERRED` explains its basis, and `NOT_PROVEN` marks absent or inaccessible evidence. Surface CRM/transcript contradictions.
5. **Prioritize on momentum.** Rank from specificity of pain, urgency, stakeholder access, mutual commitments, and resolved blockers. Do not rank from stage, value, enthusiasm, or a one-sided follow-up alone. If primary conversation evidence is unavailable and the remaining note has weak provenance, place the record in `EVIDENCE HOLD` instead of assigning heat from CRM metadata.
6. **Synthesize.** Separate demand patterns, deal/service risks, stalled reasons, coaching, and a bounded action queue. Do not generalize beyond the sample.

For HighLevel exports, join `rows` and `transcripts` by `conversationId`; verify `count`, array lengths, and `issues` first.

## Required output

```markdown
## Coverage
[requested/found, window, sources, missing lanes, limitations]

## What is happening
[3-7 evidence-backed account-level findings]

## Priority view
| Conversation | Current CRM state | Momentum | Evidence | Risk or gap | Best next action |

## Conversation ledger
### [conversation/contact]
- VERIFIED: [fact + pointer]
- INFERRED: [interpretation + basis, or none]
- NOT_PROVEN: [material missing fact]
- Contradiction: [CRM vs conversation, or none]
- Draft CRM note / next step: [clearly marked draft]

## Coaching and patterns
[cross-conversation behaviors; distinguish rep from customer]

## Read-only status
No CRM write or customer communication was performed.
```

## Example judgment

Buyer says “finance has not reviewed it” while CRM says `Qualified`: budget approval is `NOT_PROVEN` and stage readiness is contradicted. “Send pricing” proves information interest, not purchase intent. An unavailable transcript proves neither a good nor bad call.

## Common mistakes

| Mistake | Correction |
|---|---|
| Blank field means no objection | Mark the dimension `NOT_PROVEN`. |
| Positive sentiment means commitment | Require buyer action, timing, or a mutual next step. |
| Inaccessible transcript still gets a heat rank | Use `EVIDENCE HOLD` until a trustworthy source supports momentum. |
| CRM note equals customer fact | Preserve its author/date and label provenance gaps. |
| One sample represents the account | State the bounded sample and avoid exhaustive claims. |
| Advice silently becomes a CRM update | Keep proposed text in the draft slot. |
