---
name: cloudflare
description: "Use for any Cloudflare work: Workers, Pages, KV, D1, R2, DNS, Zero Trust, Tunnel, AI or IaC. Account actions go through Composio custom_cloudflare_api; checks current docs first."
---

# Cloudflare Platform Skill

Consolidated skill for building on the Cloudflare platform. Find the product in `references/product-index.md`,
then read only that product's folder under `references/`.

## Route

Read the cloudflare card before the first call in a session (`~/.agents/tools/cards/cloudflare.md`; on another
machine Composio `CUSTOM_IR_NOTES_GET_APP_RULES`). Account and API work goes through Composio
`custom_cloudflare_api`: `CUSTOM_CLOUDFLARE_API_SEARCH` finds the endpoint, `CUSTOM_CLOUDFLARE_API_EXECUTE` runs it,
`CUSTOM_CLOUDFLARE_API_DOCS` reads the docs. A `wrangler` login on the Mac is not a route.

## Retrieval sources

Your knowledge of Cloudflare APIs, types, limits, and pricing may be outdated. **Prefer retrieval over
pre-training**: the references in this skill are starting points, not the source of truth. Fetch the latest
information before citing specific numbers, API signatures, or configuration options.

| Source | How to retrieve | Use for |
|--------|----------------|---------|
| Cloudflare docs | `CUSTOM_CLOUDFLARE_API_DOCS` or `https://developers.cloudflare.com/` | Limits, pricing, API reference, compatibility dates/flags |
| Workers types | `npm pack @cloudflare/workers-types` or check `node_modules` | Type signatures, binding shapes, handler types |
| Wrangler config schema | `node_modules/wrangler/config-schema.json` | Config fields, binding shapes, allowed values |
| Product changelogs | `https://developers.cloudflare.com/changelog/` | Recent changes to limits, features, deprecations |

When a reference file and the docs disagree, **trust the docs**. This is especially important for: numeric limits,
pricing tiers, type signatures, and configuration options.
