---
name: verify-before-done
description: Use when a task is about to be called done, sent to anyone or published. Checks the work against its brief, sources and numbers, with one negative check, and records the result.
metadata:
  version: "1.1"
  updated: "2026-10-01"
---

# verify-before-done

Proves the work matches its brief before anyone calls it done. Agents judge their own work
too kindly: in one study on coding tasks they predicted 73 to 77% success when 22 to 35% was
real. So the checks here are concrete, and high-stakes work gets a fresh checker.

## Steps
1. **Re-read `work/<job>/brief.md`**: goal, "done means", facts allowed, stakes.
2. **Size the checks to the stakes.**
   | Stakes | Checks |
   |---|---|
   | Low (internal note, quick answer) | the "done means" lines, plus one negative check |
   | Normal | all checks in step 3 that apply |
   | High (client-facing, published, prices, money, many records) | all checks, plus a fresh subagent verifier (step 5) |
   Don't bury a trivial task in checks. In one study of skill failures, too much mandatory
   procedure caused most of the wasted effort, and excessive verification was its largest part.
3. **Run the checks that apply.**
   - Each "done means" line: met or not, with where you looked.
   - Numbers: recompute totals, percentages and counts from the source, don't re-read them.
   - Links and citations: open each one and confirm it says what the work claims.
   - Names, prices, dates and claims: match each to `knowledge/` or `sources/`. Prices come
     only from `knowledge/offers.md`, within their valid dates.
   - Required sections and limits: present, in order, within character or word limits.
   - Records written to a tool: read each one back and compare with what was intended.
4. **Run one negative check**: something that should fail if the work were wrong. Examples:
   search the draft for any price not in `knowledge/offers.md`; look for a banned word from
   `knowledge/business.md`; confirm an expired offer isn't mentioned; check a claim you'd
   expect to be missing really is.
5. **High stakes: hand it to a fresh subagent verifier.** Give it only `work/<job>/brief.md`, the
   deliverable, the facts-allowed files, and explicit pass/fail criteria. Tell it to try to
   find errors, to check every criterion, and to include a negative check. A verifier that
   runs one or two checks and declares success is the common failure.
6. **Fix and re-check** anything that failed.
7. **Write `work/<job>/checks.md`** from `work/_template/checks.md`: each check, how, result,
   the negative check, and what couldn't be checked. No job folder (a chat app, or work outside a
   repo): put the same table in the reply.
8. **Report** in one short message: verdict, what was checked, and "couldn't check" items
   (rule 7 in `AGENTS.md`). "Done, except X" is the honest form.
9. **Finish "Done means"** from `AGENTS.md`: update `STATUS.md` and add a run-log line.
   Moving a file into `deliverables/` waits for the owner's approval.

## Before a send or publish
Verification comes first, then the approval request. Show the owner the exact message or
post, the recipient or channel, and the tool, then wait for a yes in chat (rule 1).

## Gotchas
- "Looks right" is not a check. Each check names what was compared with what.
- Don't grade your own work as the only check on high-stakes output. Use the fresh verifier.
- A verifier given the whole conversation inherits your blind spots. Give it the brief and
  the files only.
- Numbers copied from notes can carry an earlier mistake. Recompute from the source.
- A link that opens isn't enough; the page has to support the claim.
- Record reads you couldn't do (no access, tool down) under "couldn't check", never as passes.
- Checks don't replace approval. A passing `checks.md` still needs the owner's yes to send.
