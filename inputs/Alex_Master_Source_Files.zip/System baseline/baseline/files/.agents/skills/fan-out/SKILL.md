---
name: fan-out
description: Use when work splits into 3 or more independent read-only parts, like researching many companies or summarizing many files. Briefs 3 to 5 subagents and merges their notes.
metadata:
  version: "1.3"
  updated: "2026-10-01"
---

# fan-out

Runs independent parts of a job in parallel, each in its own subagent, and merges the results
into one deliverable written by you alone.

## First, decide whether to fan out
| If the work is... | Then | Why |
|---|---|---|
| 3 or more independent, read-only parts (N companies, N files, N vendors) | fan out, one part per subagent | Parallel reading is where multi-agent setups gain. |
| One fact or one part | one agent, 3 to 10 tool calls | Coordination costs more than it saves. |
| Steps that depend on earlier steps (read, decide, update, message) | one agent | In testing, splitting step-by-step work made results 39 to 70% worse. |
| One tool-heavy flow, or anything that writes to a tool | one agent; read-only helpers at most | Parallel writers make conflicting choices. |
| A side task that would flood the chat (long export, 50-page PDF) | one subagent returning a short summary and a file path | Keeps the main conversation clean. |
| Something one agent already does well | one agent | Extra agents add cost, not quality. |

Fan-out costs roughly 15 times the tokens of a chat. Use it when the job is worth that.

## Steps
1. **Check the job folder.** `work/<job>/brief.md` exists and has a goal and "done means".
2. **Split by context, not by role.** Each part is a slice of the material that one agent can
   handle alone: one company, one batch of files. Don't split into "researcher, writer,
   checker"; each handoff loses context.
3. **Size the team.** 3 to 5 subagents, never more than 8. Three focused subagents often
   beat five scattered ones, and above 10, timeouts are reportedly frequent.
4. **Write one brief per subagent** from
   this skill's `references/brief-template.md`. All 8 parts, every time. Subagents don't
   share your memory of the conversation; anything you don't write down, they don't know.
5. **Assign files.** Each subagent writes only `work/<job>/notes/<part-name>.md`. No two
   subagents share a file.
6. **Launch them together**, so they run in parallel.
7. **Read the files, not just the summaries.** The returned messages are pointers; the notes
   files hold the work.
8. **Resolve conflicts explicitly.** Where notes disagree, say which you kept and why, in
   the deliverable or in `work/<job>/research.md`. Don't silently pick one.
9. **Write the single deliverable yourself** in the job folder. Subagents never write it.
10. **Run `verify-before-done`.** For client-facing or high-stakes work, that includes a fresh
    subagent verifier.
11. **Log it.** One line in `system/run-log.md`: date | job | fan-out, N subagents | result.

## Budgets
- Per subagent: about 10 to 15 tool calls, with a stop condition in the brief.
- Returned message: 300 words or fewer, plus the file path and gaps.
- If a subagent returns nothing, run that part again once with a tighter brief, or do it
  yourself. Don't relaunch the whole fan-out.

## Gotchas
- Vague briefs cause duplicate searches and gaps. "Research the market" is not a brief.
- Subagents assume they share your context. They don't. Put the "as of" date, audience,
  definitions and decisions in every brief.
- Early research systems spawned 50 subagents for simple questions. Stick to the table above.
- Subagents are read-only: no sends, no deletes, no tool writes, no edits outside their file.
  A subagent reading outside content is exposed to injected text, so it gets no send power.
- If a usage limit hits mid fan-out, in-flight work is reportedly lost (a 2026 bug report).
  Briefs tell subagents to save findings to their file as they go.
- Many enabled connectors and skills reportedly inflate every subagent's prompt. Turn off
  what the job doesn't need.
- A same-model reviewer given a "manager" role tends to share the worker's blind spots. Real
  checking needs a fresh context and pass/fail criteria (see `verify-before-done`).
