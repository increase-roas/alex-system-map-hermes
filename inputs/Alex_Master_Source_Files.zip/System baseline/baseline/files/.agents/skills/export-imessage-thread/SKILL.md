---
name: export-imessage-thread
description: Export a specified Apple Messages or iMessage conversation over a date range into a local Markdown transcript, preserving senders, timestamps, and attachment descriptions. Use for saving message history to a file or repository.
---

# Export an iMessage conversation

Create a faithful local transcript of the requested conversation. This workflow reads Messages and writes the requested file; it does not authorize sending messages, changing sharing or device permissions, or committing/pushing the export.

## Identify the conversation and date range

Use the supplied contact name, phone number, group title, or participants. If the user identifies the first conversation, inspect the current list: its order can change. Match the title and available participant details before extracting. A group header showing “2 People” can refer to two other participants plus the account owner; confirm with participant details and sender labels rather than treating that number alone as proof.

Ask only for information that cannot be established from the request or the app. State the verified conversation in a progress update; no extra confirmation is needed when it matches unambiguously.

Resolve dates against the current date and local timezone. Unless the user specifies otherwise, interpret “last N days” as N calendar dates including today, ending at extraction time, and state the inclusive dates. Clarify an ambiguous cutoff direction (“to September 10” versus “since September 10”). Do not reuse dates, participant identities, or project paths from previous exports.

## Choose an available read path

Prefer an authorized connector or existing reliable export utility when available. A read-only local Messages database is an option only if it is accessible and message bodies can be decoded completely; a null plain-text field is not proof that a message has no text. On a permission denial, do not bypass protections or silently change Full Disk Access. Use the Messages UI or explain what access is missing.

For UI extraction, use the available supported computer-use tool and its returned API documentation. With CUA, select `com.apple.MobileSMS`. Do not substitute shell-based UI automation, clipboard scraping, or undocumented browser/native methods. Shell tools may write and validate text already obtained through supported reads. Give only one executor ownership of the Messages interface.

## Extract without gaps

- Inspect the selected conversation and latest visible date/time. Scroll through the transcript container, not the conversation list.
- Read fresh accessibility state after navigation. Capture visible sender, body, date separators, time, attachment descriptions, and reply/reaction context. If accessibility text truncates content, inspect the relevant bubble or supported Copy/export action. Use the exposed **Show Times** action when needed to reveal a timestamp; do not invent one.
- Save captured batches incrementally to local working files when the range is long. Keep overlap between adjacent views and track which dated boundary has been reached.
- Deduplicate overlapping views using sequence context, not text alone: two separate messages can have identical text, sender, and minute. Do not collapse intentional repeated messages or text-plus-attachment entries.
- Reach a dated section before the requested start, or the confirmed beginning of the conversation. A partial viewport or a jump to a search hit is not evidence of complete coverage. Check the newest endpoint as well.
- Preserve exact exposed message wording, including typos and line breaks. Separate reaction labels from the authored text where distinguishable. Keep reply context when available. Identify unresolved sender/date/time fields explicitly.
- Represent images, videos, PDFs, audio, stickers, and link previews with the descriptions actually exposed. A preview label is not the full URL; an attachment placeholder is not its content. Export attachment files only when requested and accessible.

If extraction repeatedly fails without new evidence, stop retrying the same action. Try a supported alternative or deliver a clearly marked partial transcript with the exact captured range and missing coverage. Never claim a complete export solely because scrolling stopped or a plausible message count was reached.

## Write the Markdown file

Use the user's destination. For a repository with no established convention, use `sources/messages/YYYY-MM-DD_YYYY-MM-DD-conversation-slug.md`. Preserve existing exports unless an update was requested.

Include a short provenance header with:

- Conversation title and confirmed participant labels
- Inclusive dates, timezone, extraction date/time, and source method
- Coverage evidence for both ends and any unresolved gaps
- A note explaining attachment placeholders and unavailable content

Group entries chronologically by date. A useful entry format is `- **9:45 AM — Sender:** Exact message text`. Indent multiline bodies so they remain part of the same entry. Label non-text entries, reactions, or uncertain fields clearly. Escape Markdown only as needed to preserve the visible wording.

## Verify and hand off

Read back the saved file. Check the requested range, chronological ordering, sender labels, overlapping-batch duplicates, UTF-8 text, and missing/truncated fields against captured evidence. Count exported entries deterministically and call them entries rather than messages if attachments or reactions are separate records. A count alone does not establish completeness.

Finish with the confirmed conversation, inclusive dates, entry count, clickable absolute file link, and any material limitation. Do not rerun the full extraction after successful validation without a concrete reason.
