---
name: xlsx
description: >
  Use this skill any time a spreadsheet file is the primary input or output. This means any task where the user wants to: open, read, edit, or fix an existing .xlsx, .xlsm, .csv, or .tsv file (e.g., adding columns, computing formulas, formatting, charting, cleaning messy data); create a new spreadsheet from scratch or from other data sources; or convert between tabular file formats. Trigger especially when the user references a spreadsheet file by name or path — even casually (like "the xlsx in my downloads") — and wants something done to it or produced from it. Also trigger for cleaning or restructuring messy tabular data files (malformed rows, misplaced headers, junk data) into proper spreadsheets. The deliverable must be a spreadsheet file. Do NOT trigger when the primary deliverable is a Word document, HTML report, standalone Python script, database pipeline, or Google Sheets API integration, even if tabular data is involved.
---

# xlsx

Work in a real spreadsheet file. The deliverable is the file, not a description of it.

## Rules
- Prefer pandas for analysis and bulk table work.
- Prefer openpyxl for formatting, formulas, charts, and Excel-specific features.
- Cell indices in openpyxl are 1-based.
- Do not open with `data_only=True` and then save. That permanently replaces formulas with values.
- Recalculate formulas when the user needs updated values.
- Keep generated Python short. Document assumptions in the spreadsheet, not in chatty comments.

## Formula checks
- Watch `#DIV/0!`, `#REF!`, and broken cross-sheet refs (`Sheet1!A1`).
- Test on a few cells before applying a formula broadly.

