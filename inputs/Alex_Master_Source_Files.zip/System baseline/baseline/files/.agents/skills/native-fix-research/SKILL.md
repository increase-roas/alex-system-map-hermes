---
name: "native-fix-research"
description: "Find the documented native fix for a bot/tool failure, plan it as a mission, fix it with parallel agents on the right route (Hermes app UI, live view, SSH, API; browser last), and supervise until verified live."
---

# Native fix research → mission plan → parallel fix → verify

Goal: every fix is something the tool's maker already built and documented, checked against what is configured today, carried out by agents on the right route, and proven on the real system.

Rank fixes by **least human involvement first**, then time saved, then money.

## 0. Freeze the mission

Write two lines before anything else and don't quietly shrink them later:
- **MISSION:** the business outcome Alex wants (e.g. "HTS funnel pages show only HTS branding, live").
- **DONE =** what a visitor/owner will see on the real system when it's finished.

## 1. Root causes from evidence, not memory

- Read the real session data (Hermes: `~/.hermes/state.db` sessions/messages, read-only). Count sessions, messages, tool calls by name, cost, wall time, human wait gaps, blocked/denied calls, repeat attempts at the same step.
- For each problem ask "why?" until you reach something a setting, tool, or skill could change. One line per root cause.
- Tag each with cost: minutes lost, $ lost, minutes a human had to act.

## 2. Find the documented fix (stop at the first documented answer)

1. **Latest Hermes docs from GitHub** (never the bot's installed copy — frozen at install):
   ```
   git clone --depth 1 --filter=blob:none --sparse https://github.com/NousResearch/hermes-agent.git hermes-docs && cd hermes-docs && git sparse-checkout set website/docs skills optional-skills
   ```
   grep `website/docs` for symptom words, config keys, tool names (`user-guide/configuration.md`, `reference/tools-reference.md`, `developer-guide/*`).
2. **GitHub issues/PRs** via Exa through Composio (`EXA_SEARCH`, "NousResearch hermes-agent github issue <symptom>"). Merged PR or maintainer comment = documented fix; open issue = known bug, no fix yet.
3. **Vendor docs** (GHL, Meta, Google) via the Composio docs readers then Exa, including ideas boards / API-docs issues — they tell you when an API route doesn't exist.
4. **Descriptions of tools the bot already has** — often the fix is an unused installed tool.

Confirm the installed version supports it (`hermes config get <key>` or the installed docs).

Rules: don't invent fixes. No source → write **"No native fix found"**; anything you still suggest is labeled **CUSTOM** with why. Every fix names its source and how its result will be verified — a tool's "success" is not proof. Separate settings (config) from behavior (skill text): behavior fixes go into the bot's own skill, written by the bot. Note when a vendor genuinely lacks a capability (e.g. no public write API) so nobody keeps searching. Why: invented fixes drift from the product and break on the next update; native ones get maintained for free.

## 3. Cross-reference the live setup (read-only)

For each fix, read the current value on each bot: ✅ set · ⚠️ wrong · ❌ missing.

## 4. Report (brief)

| # | Root cause | Cost (time / $ / human min) | Native fix + source | Current | Change | Route (§6) |
|---|---|---|---|---|---|---|

Then: **total wasted**, **new estimate** (time / $ / human min, with assumptions), **still unsolved**, and 3 options (lowest human effort first).

## 5. Plan: one node per fix

Turn the table into nodes. Each node: `ID · ACCEPTANCE (one checkable line) · DEPENDS_ON · ROUTE · STATUS`.
Status: `READY | ACTIVE | BLOCKED (name the node it waits on) | VERIFIED | FAILED | WAITING_ON_ALEX`.
- Nodes with no unmet dependency run in parallel.
- **Standing authorization:** everything except the HERMES-OPS §4 "Needs Alex's yes" list (spend, messaging real people, publishing workflows, DNS/Cloudflare changes, deleting) proceeds without asking. `WAITING_ON_ALEX` is only for those, a login only Alex holds, or a real business decision — then name the exact thing he must do.
- One blocked or sandbox-denied step parks **that node only**; keep dispatching other READY nodes.
- **Owner-facing nodes** (a page, doc, message a person sees): acceptance is written as what a visitor sees on the live target (live fetch / screenshot), never builder readback or counts the bot can satisfy alone. Surface the live link to Alex once when done.

## 6. Launch parallel controller agents — right route per fix

Spawn one agent per READY node in a single message (Agent tool, general-purpose). Every prompt names **route, tools, skills to load first, what not to do, and proof of done**. The browser is the last resort, not the default.

| Fix type | Route | Tools | Load first |
|---|---|---|---|
| Bot behavior, teaching the bot, stopping/approving runs | **Hermes app UI** on the MacBook — message the bot; the bot updates its own skill | computer use (`mcp__remote-devices__computer_*`) | `computer-use` |
| Need to see the bot's own screen (its Chrome, dialogs) | **Live view.** Mac mini: Screen Sharing.app on the MacBook → VNC `100.127.38.125:5900` over Tailscale, saved as `Sasha's Mac mini (sashairis).vncloc` (always on). Orgo EA: Orgo's live desktop view. Look, then act through the Hermes app. | computer use | `computer-use` |
| Files the bot already uses (config.yaml, its skills, AGENTS.md, memory) | **Edit on that machine**, then verify | Mac mini: SSH via Desktop Commander `start_process`; EA: `python3 ~/.agents/tools/connectors/orgo_op.py orgo computers bash EA -c` (root for config, then `chown javar:javar` + `chmod 600`) | `desktop-commander:terminal` |
| Config / restarts / service admin | Direct, then `hermes config get` + restart per HERMES-OPS | same | — |
| Research | Docs clone, Exa, Composio docs readers — not a browser | Bash, Composio `exa` (`EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`, `EXA_ANSWER`), Composio docs readers (`CUSTOM_CONTEXT7`, `CUSTOM_OPENAI_DOCS`, `CUSTOM_ASTRO_DOCS`, `CUSTOM_QT_DOCS`) | `research-with-sources` if broad |
| GHL checks | Read-only API | Composio `custom_ghl_oauth_crm` `ghl_execute_read_operation` (pass `locationId`) | — |
| GHL changes (pages, media, surveys) | **The bot does them** (GHL Command tools); you verify | message via Hermes app UI | — |
| Live page proof | curl / API first; browser only if it must render | Bash, GHL reads | — |
| Site with no API or connector | Browser | `built-in-browser` (preferred) or `chrome-browser` | that browser's skill |

Editing the bot's existing files is allowed; building new custom plugins, guards, scripts, services or add-ons is not without Alex's yes.

Controller prompt template:
```
Node: <ID> | Fix: <one line> | Source: <doc/PR/tool>
Route: <row> | Tools: <exact tools> | Load first: <skills>
Do not: do the bot's task yourself; use the browser if another route exists; build custom add-ons; delete anything or do §4 items without Alex's yes; type or reveal passwords.
Steps: <2-5 steps>
Done = <real-system proof: config get value, live curl count, screenshot of live page, bot's skill file contains X>
Return: STATUS (VERIFIED/FAILED/BLOCKED), the proof, and any blocker's root cause in one line.
```
When the instruction goes to a Hermes bot, name the bot skill it must load and the tool to prefer (e.g. "load ghl-builder-ops; use browser_snapshot + browser_click refs; check pending_dialogs first").

Parallel limits (why): one MacBook screen → **only one agent drives computer use / the Hermes app at a time**; others do SSH, research, read-only checks. Only one chat works on the bots at a time (HERMES-OPS). Don't send the same instruction again while the bot's run is still active. Don't kill a bot's run unless it's looping.

## 7. Supervise until done

- **Idle with remaining work is a failure.** Each check, first ask: *why is the bot/agent not moving?* Resume an idle one with one concrete next outcome; leave progressing ones alone.
- While bot jobs run, set one check-in (`send_later`, ~15 min) for this chat. On each check: read only new status, act if something changed, stay quiet if not, stop the check-in when all nodes are VERIFIED or waiting on Alex.
- **Loop breaker:** two failed fixes for the same symptom = the cause was never isolated. Stop fixing; the next step is one read-only probe that changes one variable and names which layer causes the symptom. Hard stop at 3 attempts per step (HERMES-OPS) and report the root cause.

## 8. Verify and record

- **Verify every "done" yourself on the real system** (never accept a bot's or agent's report alone — tonight's "saved" edits weren't). For bigger jobs use a separate agent that didn't do the work.
- Words: **GATE COMPLETE** (one acceptance passed) · **PHASE COMPLETE** (a group passed, more remains) · **MISSION COMPLETE** (only when DONE from §0 is proven live).
- After a bot finishes, have it update its own skill (or `/learn`).
- Update HERMES-OPS.md: bots table, open items, recent changes (last 5).
- Report to Alex: MISSION · DONE = (x/y nodes verified) · CURRENT REALITY · REMAINING · NEXT · NEED FROM ALEX (nothing unless §5 says so) · 3 options.