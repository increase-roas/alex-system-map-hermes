---
name: preserve-and-release-website
description: Use when revising or releasing an existing website whose styling must survive, or resuming a release after an upload failure or interruption. Not for a new-site design brief.
---

# Preserve and release an existing website

Improve the requested parts without replacing the owner's original site. Use the existing controller and release tooling; this skill adds no authority or orchestration layer.

## Establish the comparison

Recover the approved original URL, commit/archive and desktop/mobile screenshots. Record what must stay (branding, hero, typography, colors, section order, imagery, navigation) and the requested changes. Inspiration for product-page structure is not permission to redesign the homepage. If the original is ambiguous, show the smallest set of candidate references for selection.

Compare original and candidate side by side before calling it ready. Inspect shared layouts plus every materially changed page. Preserve the required full-route/link/asset/interaction checks; passing those does not prove visual fidelity. Owner rejection suspends publication of that candidate. Diagnose the differences before rebuilding.

## Establish release readiness early

Before acquiring a production write claim, recover exact account/project/environment/domains, tested artifact digest, prior deployment and authorization scope. Inspect the actual authenticated profile or structured route and its permissions. A signed-out alternate profile does not invalidate a working session. Browser local-file permission and action-time confirmation requirements belong in this preflight. Inspect permission metadata first; do not test attachment against production merely to diagnose access.

Changing folder packaging to ZIP cannot cure a file-access denial. Fix or obtain the missing permission through its supported mechanism before another attempt. Never read secrets to prove nonsecret capability.

## Resume by observed state

| Observed state | Next action |
|---|---|
| Same receipt and unchanged evidence | Reuse the accepted checkpoint; process only the new fact. |
| Package staged, claim active | Preserve the staged operation and claim; no re-upload or replacement. |
| Interrupted or ambiguous submission | Authoritative lookup; absence alone does not authorize retry. Preserve unresolved claim. |
| Terminal failed claim, prerequisite fixed | Verify the fix; use the existing authority/guard procedure for a new bounded play. Never replay the failed intent. |
| Required confirmation pending | Surface that exact boundary once; do not solicit a second business approval when only a tool confirmation remains. |

Approved artifact means unchanged bytes: no opportunistic rebuild. Staged files are not deployed; successful deployment is not public verification. Prove the expected artifact on the real domain, including MIME, images, links and desktop/mobile rendering. No rollback without its required authority.

## Keep the work inexpensive

After mandatory instruction reads, load only evidence relevant to the current gap. One compact receipt records changed state, proof pointer, remaining condition and next action. Reuse existing deterministic manifest/validation tools. Wait on the same native handle; an unchanged observation is not a new assignment. Controller selects models. Measure tokens, elapsed time, retries and acceptance failures when available; do not claim savings without measurements.
