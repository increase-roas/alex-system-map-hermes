---
name: meta-ads
description: "Use when inspecting or managing Meta, Facebook or Instagram ads: ad accounts, campaigns, ad sets, creatives, audiences, pixels or insights. Works through Composio metaads; creates stay paused."
---

# Meta Ads through Composio

Read the meta-ads card before the first call in a session (`~/.agents/tools/cards/meta-ads.md`; on another machine
Composio `CUSTOM_IR_NOTES_GET_APP_RULES`). It owns the route (Composio `metaads`, the system user), the spend rule and
the retired logins. Javar agents keep their fenced `javar_meta`. Not routes either: Meta's hosted MCP
(`mcp.facebook.com/ads`) and the ChatGPT "Increase ROAS — Meta Ads" app.

## Target

- `METAADS_GET_AD_ACCOUNTS` lists what the system user sees. Match the exact account name and ID.
- Pass the verified `ad_account_id` (`act_...`) on every call; there is no safe default account.

## Safety

- Inspect, list, paused or draft only, unless the operator names spend, unpause or go-live that day (spend rule: the
  card).
- Create campaigns, ad sets and ads with status `PAUSED`, and keep them paused. Change budgets only with the built-in
  tools, never through `composio proxy`.
- A create or update tool that Composio holds for approval or marks restricted on a surface is a denial: stop and
  report; never route around it through proxy or another Meta route.
- Reconcile an ambiguous write read-only, by exact name and ID, before retrying it.

## Read-only tools

| Job | Tool |
|---|---|
| Accounts | `METAADS_GET_AD_ACCOUNTS` |
| Campaigns | `METAADS_LIST_CAMPAIGNS` (`ad_account_id`) |
| Ad sets | `METAADS_READ_ADSETS` |
| Ads and creatives | `METAADS_LIST_ADS`, `METAADS_LIST_AD_CREATIVES`, `METAADS_GET_AD_CREATIVE` |
| Any object by ID | `METAADS_GET_OBJECT` |
| Insights | `METAADS_GET_INSIGHTS` (for example spend, impressions, ctr, cpc over `last_7d`) |
| Audiences and images | `METAADS_LIST_CUSTOM_AUDIENCES`, `METAADS_LIST_AD_IMAGES` |
| Anything else (reads) | `composio proxy` to the Graph API, as the card shows |

CLI form: `composio execute METAADS_LIST_CAMPAIGNS -d '{ ad_account_id: "act_..." }'`. Read a tool's inputs first
with `--get-schema`.
