---
name: ask-jeremy
description: Use when a project needs a bounded operating decision or implementation clarification from Jeremy AI, especially for Hermes, Orgo, Slack, GHL, agent roles, approvals, or customer workflows.
---

# Ask Jeremy

## Purpose

Get one source-attributed answer quickly without an unbounded design session. Jeremy is guidance; repo, runtime, and provider read-back are truth for what is configured or working.

## Fast path

1. **Recover context.** Read continuity files and the latest Jeremy log. State the exact agent, host/role, stack, and settled decisions; do not reopen them.
2. **Queue gaps.** Order unresolved questions by dependency and ask only the first.
3. **Use the existing Ask Jeremy AI surface.** Reuse the authenticated tab/chat. If unavailable, report the exact blocker; never invent an answer or request credentials.
4. **Send one bounded message.** Start courteously, give brief verified context, name the exact agent and stack, and ask one decision. Request exact inputs, outputs, ownership, permissions, failure behavior, and uncertainty labels.
5. **Wait for a visible answer.** One answer is one proof. Do not repeat, batch, or run a three-run ceremony.
6. **Thank him.** End with a short thanks: “Thanks, Jeremy — this will help us keep the build narrow and accurate.”
7. **Record immediately.** Append to `JEREMY-QUESTION-LOG.md` (or the project evidence log), preserving prior entries. Include timestamp, ID, exact question, answer, visible-chat verification, and `GUIDANCE_ONLY`.
8. **Reconcile.** Compare with repo/runtime evidence. Mark claims `VERIFIED`, `CONFIGURED`, `RUNNING`, `REACHABLE`, `AUTHENTICATED`, `FUNCTIONAL`, `ACCEPTANCE_PASS`, or `NOT_PROVEN`; never upgrade a status from Jeremy alone.

## Message template

```text
Hi Jeremy — we are narrowing the first practical version of [EXACT AGENT/ROLE] in [STACK: Orgo + Hermes + named channels/providers].

Verified context: [2–4 facts that affect this decision].
Already settled: [decisions not being reopened].

One question: [specific operating decision]. Please give the exact [inputs / outputs / owner / permission boundary / failure or retry behavior] and label anything unknown.

Thanks, Jeremy — this will help us keep the build narrow and accurate.
```

## High-value question shape

Prefer: “For **[agent]** on **[stack]**, what exact **input** should trigger this, what **output/receipt** should close it, who owns each step, what requires Alex approval, and what must fail closed?”

Avoid vague prompts such as “How should we build everything?” Do not ask Jeremy to edit Hermes configuration or provide passwords, API keys, OAuth tokens, phone numbers, or other secrets.

## Speed and safety rules

- Ask one decision at a time; sequence by dependency: runtime shape → role boundary → first behavior → approval → integrations.
- Use the smallest context that prevents a wrong answer. Include the exact agent and current stack every time.
- Reuse prior answers and log entries; follow up only for a material ambiguity.
- Never send customer-facing messages, create Slack apps, change permissions, alter Hermes/Orgo, or touch CRM data as part of this skill.
- Never infer live routing, authentication, tenant authority, tool access, or production behavior from a chat answer.
- If Jeremy conflicts with direct evidence, preserve both; prefer current authoritative read-back for implementation truth.
- Stop after the smallest answer that resolves the current blocker. Recommend exactly one next question or proof.

## Log entry template

```markdown
## [QUESTION-ID] — [short title]
- Asked: [timestamp, timezone]
- Agent/stack: [exact role and stack]
- Status before: [known status]
- Question: [exact text sent]
- Answer: [faithful summary; quote only short phrases when useful]
- Verification: visible answer in Ask Jeremy AI chat; no secrets; no external write
- Classification: `GUIDANCE_ONLY`
- Reconciliation: [matching evidence, contradiction, or `NOT_PROVEN`]
- Next smallest proof/question: [one item]
```
