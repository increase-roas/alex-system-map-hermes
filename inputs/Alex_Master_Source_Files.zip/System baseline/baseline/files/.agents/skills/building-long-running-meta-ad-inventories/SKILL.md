---
name: building-long-running-meta-ad-inventories
description: Use when compiling, expanding, validating, or ranking advertiser inventories from Meta Ad Library, Apify, or Foreplay where ads must be currently live for a minimum duration and advertiser identity or ad-count evidence may conflict.
---

# Building Long-Running Meta Ad Inventories

## Core principle

Apify discovers; Meta page ID establishes identity; Foreplay enriches. Partial or fuzzy reads never override stronger evidence.

## Workflow

1. Load the existing inventory and search manifest. Preserve verified records and skip reviewed page IDs and executed queries.
2. Before paid discovery, inspect Actor schema and pricing. Set its result limit and `maxTotalChargeUsd` within the approved dollar cap.
3. Discover active Meta ads with Apify. Filter by country and start-date cutoff. Deduplicate **strictly by Meta `pageId`**; names and domains support identity but are not keys.
4. Reject removal, rental, repair, maintenance, chemicals, accessories, financing-only, lodging, and unrelated profiles. Require ad evidence selling the complete product.
5. Compute complete runtime days client-side from the ad start timestamp and verification timestamp. Assign duration tiers from that computed value.

## Foreplay enrichment

- Call `get_user_usage` before a batch and after every ten validations.
- Lookup the exact Meta page ID first with `live=true`, `order=longest_running`, and `limit=1`.
- **Do not send `running_duration_min_days`.** It has produced false empty results. Evaluate `running_duration.days` client-side.
- If cached lookup is empty, repeat it once with `collect=true`. Empty or partial collection is not proof the Apify ad is inactive.
- Use brand-name search only as fallback. Accept only exact Meta page-ID equality; reject popular fuzzy matches.
- Preserve the oldest verified qualifying evidence. Never downgrade or remove it because Foreplay returns a newer ad, a different ad, zero indexed ads, or an empty response.

## Counts and ranking

| Evidence | Store as |
|---|---|
| Exact-page Foreplay `active_ads_count > 0` | `FOREPLAY_ACTIVE_TOTAL` |
| Foreplay total unavailable, or zero while same-date Apify proves active ads | `APIFY_QUERY_MINIMUM` |

Never present these count types as equivalent or convert unknown totals to zero. Rank descending, break ties alphabetically, and include `count_source`, `source_note`, and `verified_at`.

## Credit and stop rules

- One evidence ad per profile; validations in batches of ten.
- Stop before the next discovery-plus-validation cycle can exceed the approved cap.
- No repeated paid run, unbounded retry, or browser fallback without explicit authority.

## Required outputs

Persist CSV, Markdown, and manifest. Each accepted row needs Meta page ID, proven Foreplay brand ID, profile, market, ad count and source type, runtime, tier, hook, offer, CTA, ad ID, canonical URL, search term, status, verification time, and notes. Report additions, rejections, tier totals, credits/cost, searches, and stop reason.

## Common mistakes

- Merging local dealers by similar names or domains.
- Trusting Foreplay’s duration filter or fuzzy first result.
- Treating a one-ad collector response as the advertiser’s total.
- Downgrading older evidence when a partial source returns a newer ad.
- Reporting Apify query matches as total active ads.
- Treating a contradictory Foreplay zero as authoritative over same-date active evidence.
