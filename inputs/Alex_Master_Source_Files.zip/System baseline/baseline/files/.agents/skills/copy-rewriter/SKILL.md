---
name: copy-rewriter
description: >
  Reads copy from any source (URL, text, or file), audits it against the copywriting and landing page frameworks, and rewrites it using actual customer language (VoC). The rewrite is direct, confident, systems-focused, and free of corporate fluff or guru-cringe.
---

# Copy rewriter

Rewrite using the customer's words when you have them. Lead with the outcome. Cut fluff.

## Output
- The rewrite
- A short list of what changed and why
Do not invent testimonials or stats.

