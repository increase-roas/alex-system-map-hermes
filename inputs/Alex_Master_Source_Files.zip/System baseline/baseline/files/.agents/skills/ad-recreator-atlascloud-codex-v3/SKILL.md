---
name: ad-recreator-atlascloud-codex-v3
description: Recreate approved B2B ads or slides through Atlas Cloud, keeping the reference layout and swapping in the supplied avatar, apparel, logo and offer. Use for ad recreation or bulk creative rebuilds.
---

# Universal Winning Ad Recreator v3 — AtlasCloud through Composio

Rebuild approved B2B visuals through AtlasCloud. Treat each reference as a **composition brief** and the current-job assets as the **brand source of truth**.

> Preserve the conversion structure and the person’s recognizable identity. Replace incidental source branding, apparel treatment, and copy with the supplied brand direction.

## v3 operating updates

| Requirement | Rule |
| --- | --- |
| Generation provider | Use AtlasCloud through Composio `custom_atlas_cloud` (any AI); read the current model info before use because routes and fields are model-specific. |
| API key | None for Composio calls. The local script reads the key from 1Password for each run (section 3). Never hard-code, print, commit, attach, write to a file, or place the key in prompts. |
| Reference assets | Pass public https URLs, or let the local script upload local reference, avatar, logo, and product assets immediately before the job (section 3). Use returned temporary URLs only within that job. |
| No intake friction | Ask only for references, target avatar if applicable, own-brand asset(s), offer, CTA, and essential visual direction. Do not ask for ad IDs, authorization confirmations, proof, performance claims, or compliance questionnaires by default. |
| Identity versus brand | Preserve the target person’s face, hair, recognizable features, and requested pose. Treat visible apparel color, apparel cut, accessories, chest marks, and source-brand treatment as replaceable unless the user says to preserve them. |
| Logo meaning | Treat a supplied logo as an instruction for the ad’s brand system. Use it in a separate, readable logo zone; never let a source shirt color or a soft/generated shirt logo override it. |
| Missing content | Never invent missing supporting copy. Use the supplied offer and CTA only, or omit the missing element. |

## 1. Collect the minimum brief

Use this minimum brief. Do not request internal ad IDs; use the reference files in their supplied order and record only their filenames in the job manifest.

```text
Brand:
Offer / headline:
CTA:
Reference files:
Target-avatar files (if a person is required):
Logo / brand files:
Apparel direction (if visible):
Background: preserve / replace:
Essential visual direction:
```

If a person is present and the user supplies a logo but no apparel instruction, default visible clothing to the supplied palette or a clean neutral treatment with no conflicting source logo. Do not add branded apparel where no apparel is visible or where it weakens the composition.

## 2. Lock each recreation before generation

Create one concise composition lock per supplied reference. Estimate position values as percentages and state that they are estimates.

```json
{
  "reference_file": "01_reference.png",
  "aspect_ratio": "1:1",
  "focal": {"region": "right third", "x_pct": 65, "y_pct": 50, "frame_pct": 50},
  "headline": {"region": "left lower band", "x_pct": 4, "y_pct": 60, "w_pct": 54, "h_pct": 30},
  "cta": {"region": "bottom right"},
  "logo": {"region": "top left"},
  "reading_order": ["brand", "headline", "subject", "CTA"],
  "density": "medium"
}
```

For every person-led image, add this mini-lock before writing the prompt.

| Element | Record |
| --- | --- |
| Identity anchors | Face, hair, recognizable features, requested pose, and silhouette to preserve |
| Apparel | `preserve`, `replace`, or `N/A`; then specify color and style if visible |
| Shirt branding | `none`, `supplied logo`, or `leave clean`; never retain a conflicting source mark |
| Separate logo | Supplied logo asset and final placement zone |
| Background | Preserve only where it has no competing identity; otherwise rebuild a brand-aligned setting |

## 3. Use AtlasCloud safely

Route: Composio toolkit `custom_atlas_cloud`, the Atlas Cloud route for every AI. Image jobs go to `CUSTOM_ATLAS_CLOUD_ATLAS_GENERATE_IMAGE` (`model`, `params`, `dry_run`); poll `CUSTOM_ATLAS_CLOUD_ATLAS_GET_PREDICTION`; `CUSTOM_ATLAS_CLOUD_ATLAS_GET_MODEL_INFO` shows a model's fields and price. Inputs are URLs. `CUSTOM_ATLAS_CLOUD_ATLAS_UPLOAD_MEDIA` reads files on the Orgo hub that runs the route, not on this Mac (a Mac path fails with ENOENT, checked 2026-10-01), so pass public https URLs for reference assets.

Reference files that exist only on this Mac: use `scripts/atlas_generate_image.mjs` after reading its help. It uploads local reference assets, submits the job, polls until completion or failure, downloads the first returned output, and prints a non-secret manifest. Node 22 or newer is required. The script reads the Atlas key itself for that one run from 1Password ("Atlas Cloud API key" in the Connectors vault) with the read-only `connectors-sync` service account (token in the macOS Keychain), so run it outside the Claude Code sandbox (`op` can't reach 1Password inside it). Add `--dry-run` first: it checks the key read and prints the request without any upload, generation or charge.

```bash
node scripts/atlas_generate_image.mjs \
  --model google/nano-banana-2/text-to-image \
  --prompt-file /absolute/path/prompt.txt \
  --out /absolute/path/final.png \
  --reference-field image_url \
  --ref /absolute/path/reference_ad.png
```

Never write the key to a `.env` file, the skill folder, a prompt, a manifest or a log, and never print it. The script has no `.env` fallback (removed 2026-10-01): if `ATLAS_CLOUD_API_KEY` isn't set for the command and the 1Password read fails, it stops with an error; then use the Composio route above. The two 1Password named pipes that sat in this folder (`.env`, `.env.fifo-backup`) were moved unopened to `~/Backups/onepassword-pipes-2026-10-01/` on 2026-10-01: never open them, and never put a plaintext `.env` here.

Use `google/nano-banana-2/text-to-image` only as the default text-to-image baseline; AtlasCloud’s documentation identifies it in its prediction example.[2] Check the active model page for the exact route, reference-image field, accepted resolution, and aspect-ratio field before each new model family. **Do not guess that every model accepts `image_url` or the same parameter names.** For editing/reference-to-image work, choose the current AtlasCloud route specifically designed for that task and pass the field name with `--reference-field`.

Use `1:1` and `2k` for text-rich square paid-social images unless the brief specifies another placement. AtlasCloud documents Nano Banana 2 resolutions and aspect ratios separately; use only currently supported values.[4]

Do not submit test requests, inspect balances, or expose billing data unless the user asks. If the user asks for spend, retrieve the current model price from AtlasCloud’s pricing or model page rather than estimating.[5]

## 4. Build the prompt from the lock

Write a concrete prompt per output. Supply the reference image as a layout guide, not as text or brand source. Use exact user-approved copy only.

```text
Create a [aspect ratio] B2B marketing ad for [audience].
Composition: Preserve the supplied reference’s [headline zone], [CTA zone], [logo zone], [focal placement], and [reading order]. Do not preserve its logos, wording, signage, or other identity.
Avatar: Faithfully preserve [identity anchors] from the supplied target avatar.
Apparel: [preserve / replace / N/A]. If replace, use [color, style, and visible-logo decision]. Remove source-brand treatment.
Brand: Use the supplied [brand] logo separately in [final placement]; follow [palette].
Text to render exactly: Headline “[offer]”; CTA “[CTA]”; support “[only supplied support copy].”
Background: [preserve / rebuild direction].
Avoid: extra copy, source logos, wrong shirt color, unreadable or conflicting shirt branding, altered framing, moved CTA, garbled critical text, claims, statistics, prices, dates, testimonials, and signs.
```

For a focused edit, state the exact changed region and every preserved element. Example:

```text
Edit the provided image. Change only the bottom-right CTA into a solid red rounded button with the exact text “GET THE PLAYBOOK” and a separate right-arrow end cap. Preserve the person, face, hair, clothing, book, layout, lighting, and all non-target elements.
```

## 5. Execute and review

Generate a single test only when the creative direction is unproven. Once the user approves a direction, generate one output per requested reference. Keep source files, prompt files, output images, and a `manifest.json` inside a dedicated job folder.

Check each image once. Correct one material failure with one targeted re-generation or edit; do not turn delivery into open-ended iteration.

| Check | Pass condition |
| --- | --- |
| Structure | Correct aspect ratio, focal placement, hierarchy, CTA zone, and logo zone |
| Target person | Face, hairstyle, recognizable features, and requested pose match supplied target assets |
| Apparel | Mini-lock followed; no conflicting source-brand treatment remains; `N/A` when clothing is not visible |
| Logo | Supplied brand identity is present in the designated readable zone; do not depend on an unreadable generated shirt wordmark |
| Copy | Exact approved offer and CTA are legible; no unrequested words were added |
| File | Output downloaded successfully and listed in manifest with model, prediction ID, and source filename; never include the API key |

Deliver the requested files and the compact manifest. Stop after the requested set unless the user asks for another iteration.

## References

[1] [AtlasCloud Image Generation](https://atlascloud.ai/docs/en/models/image)

[2] [AtlasCloud Predictions](https://atlascloud.ai/docs/en/predictions)

[3] [AtlasCloud Upload Files](https://atlascloud.ai/docs/en/upload-files)

[4] [AtlasCloud Nano Banana 2 Text-to-Image](https://www.atlascloud.ai/models/google/nano-banana-2/text-to-image)

[5] [AtlasCloud API Pricing](https://atlascloud.ai/docs/en/models/price)
