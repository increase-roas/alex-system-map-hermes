---
name: fulfill-hot-tub-launch
description: Use for Hot Tub Launch fulfillment, such as paid funnels, retailer websites, GHL snapshot workflows, Sheets lead projection, Meta Pixel/CAPI dedup, launch gates and diagnosis. Not for Meta ads.
---

# Fulfill Hot Tub Launch

Operate the HTL website and GHL snapshot as two joined systems with different ownership:

```text
website / Cloudflare / D1
  owns retailer web experience, lead identity, durable lead record, attribution,
  website Lead conversion, Meta stage-event delivery, and Sheet projection

GHL snapshot
  owns contact conversation, pipeline, appointments, follow-up, staff alerts,
  opt-out execution, and AI-agent handoff signals

join key: lead_uuid
shared inbound boundary: authenticated /api/phone-lead and /api/lead-stage calls
```

Do not collapse these ownership boundaries. D1 is the durable lead source; GHL is not product truth; Sheets are not the database; GHL workflow state does not mint a second Meta identity.

## Route the request

- Simple paid landing/funnel: load [simple-paid-funnel.md](references/simple-paid-funnel.md) first. Google Sheets, D1, exact GHL delivery, and exact Meta browser/server deduplication are required; Voice AI and Conversation AI are out of scope.
- End-to-end retailer fulfillment or cross-system diagnosis: use this skill.
- Website-only work: load the website references and relevant runbook sections.
- GHL snapshot work: load the GHL contract, exact workflow extraction, defects, and gates.
- Website/GHL lead or event work: always load the handoff contract.
- Native GHL Voice AI or Conversation AI: use this skill for contract discovery, gap analysis, and GHL handoff; use current official APIs where verified and degrade only for uncovered settings.
- External voice/chat provider: use only after an explicit architecture decision or a verified native coverage gap; route provider creation to its dedicated skill and keep the GHL sync contract here.
- Meta ad strategy, copy, creative, campaign creation, or publishing: route to the approved ad skill. This skill may verify landing-page/message and conversion-contract alignment.

## Load only what the task needs

Always load [source-precedence.md](references/source-precedence.md) and [00-UNVERIFIED-DO-NOT-TREAT-AS-FACT.md](references/00-UNVERIFIED-DO-NOT-TREAT-AS-FACT.md) before customer-specific planning, generation, configuration, diagnosis, or completion claims. These two references are mandatory even when all other context is loaded selectively.

- Source identity, precedence, evidence labels, and release facts: [source-precedence.md](references/source-precedence.md)
- Mandatory uncertainty boundary and claims that cannot be treated as current facts: [00-UNVERIFIED-DO-NOT-TREAT-AS-FACT.md](references/00-UNVERIFIED-DO-NOT-TREAT-AS-FACT.md)
- Simple paid-funnel isolation, required connections, autonomous test, and subset definition of done: [simple-paid-funnel.md](references/simple-paid-funnel.md)
- Exact runtime/configuration classes, source-observed failure behavior, target joins, and preflight: [runtime-configuration-contract.md](references/runtime-configuration-contract.md)
- Retailer intake and configuration ownership: [retailer-intake.md](references/retailer-intake.md)
- Website, inventory, D1, Sheets, consent, GHL upsert, and Meta contracts: [website-contract.md](references/website-contract.md)
- GHL inventory, portability, AI surfaces, workflows, and current readiness: [ghl-snapshot-contract.md](references/ghl-snapshot-contract.md)
- Exact extracted workflow triggers/actions/message bodies: [ghl-workflows-extracted.md](references/ghl-workflows-extracted.md)
- Canonical website-to-GHL mappings and lead/event trajectories: [website-ghl-handoff.md](references/website-ghl-handoff.md)
- Voice/Conversation AI capability and external-provider boundary: [ai-agent-boundary.md](references/ai-agent-boundary.md)
- Offers, financing, reviews, claims, and content safety: [content-and-claims.md](references/content-and-claims.md)
- End-to-end website generation/build details: [website-build-runbook.md](references/website-build-runbook.md)
- Full coordinated fulfillment trajectory: [fulfillment-runbook.md](references/fulfillment-runbook.md)
- GHL defects, decisions, and release blockers: [known-defects.md](references/known-defects.md)
- Website release-specific gaps: [website-known-gaps.md](references/website-known-gaps.md)
- Production gates, approvals, evidence, and rollback: [production-gates.md](references/production-gates.md)
- Machine-readable exact mappings: [htl-system-contract.json](references/htl-system-contract.json)

For a simple paid funnel, use the dedicated subset path and do not expand into AI or unrelated snapshot fulfillment. For full new-retailer fulfillment, start with source precedence, retailer intake, the fulfillment runbook, production gates, and the machine contract. Load website, GHL, AI, defects, content, and exact-workflow references at the phase that needs them. Load `ghl-workflows-extracted.md` only when exact workflow logic or message copy is required.

## Fact authority and evidence

Use this order while recognizing that each source controls its own truth:

1. Current explicit user instruction and approval boundary
2. Approved retailer facts and approved business decisions
3. Read-only state from the exact resolved target account/resource
4. Current working source, schemas, migrations, generated manifests, and tests at the recorded commit
5. Curated references and machine contract in this skill
6. Exact raw extraction for action/message details
7. Historical exports, examples, defaults, comments, and unverified prose

Website source controls website behavior. Verified GHL target state controls current GHL configuration. Approved retailer data controls customer facts. If evidence at the same level conflicts, preserve both claims, label the conflict, and stop for a decision. Never use a different location, retailer, example, or default to fill missing truth.

Use only these evidence states: `VERIFIED_SOURCE_FILE`, `VERIFIED_LIVE_READ_ONLY`, `VERIFIED_UI_READ_ONLY`, `VERIFIED_TEST`, `UNVERIFIED`, `NOT_ACCESSIBLE`, `NOT_CONFIGURED`, `BLOCKED`. A structural check is not a behavioral test. Absence from an MCP response is not proof of absence when tool scope is incomplete.

The uncertainty register is negative authority, not evidence. An item does not become true because it appears in the skill, an archive, an example, or repeated prose. No `UNVERIFIED`, `NOT_ACCESSIBLE`, or `BLOCKED` material value may populate customer configuration, external bindings, customer-facing content, or a passed release gate.

## Capturable fulfillment trajectory

Execute every phase as an observable loop:

```text
requirement
→ success criteria and preconditions
→ concise operational plan
→ selected tool level and reason
→ redacted tool call
→ observation/evidence
→ compare with criteria
→ continue | revise | escalate | stop
→ next iteration or proven result
```

Record task, retailer, source/target identities, repository/commit, phase, iteration, approval state, redacted action, observation, evidence reference, result, and blocker/failure class. Preserve failed observations and corrections. Do not record hidden chain-of-thought, secrets, credentials, customer PII, private target IDs in portable output, or unredacted lead payloads.

## API Maximalism with Graceful Degradation

Use the first safe level that fully covers the operation:

1. Official documented API or a verified MCP tool backed by it
2. Verified undocumented/internal API only with explicit authorization, permitted use, inspected contract, narrow scope, and rollback controls
3. Playwright or equivalent DOM automation
4. Computer use with visual/coordinate interaction
5. Human in the loop for authentication, ambiguity, unsupported settings, or sensitive approval

Never default to browser automation when an official API covers the operation. Never invent an endpoint or assume an MCP has vendor-API parity. For incomplete APIs, use a hybrid: perform supported operations through the API, degrade only the uncovered steps, and record the exact boundary and observation. Skip undocumented APIs when authorization, terms, contract evidence, or safety controls are absent.

## Non-negotiable system invariants

1. Resolve the exact retailer, website repository/commit, GHL location, Cloudflare account/resources, Meta dataset, Sheet, and requested outcome before account-specific work. Similar names are insufficient.
2. Re-read and match the exact active GHL location immediately before every read batch and every mutation batch; the source extraction observed location drift. A prior read does not authorize a later write.
3. The website emits canonical entry tag `website-lead`; `new-lead` is an alternate GHL trigger, not a website output unless current website source proves otherwise.
4. Website payload keys are unprefixed; GHL custom-field identities use `contact.*`. Map by exact field key, never display name or imported object ID.
5. Preserve the website-owned `lead_uuid`. Do not call `/api/phone-lead` for a contact that already has it unless endpoint idempotency has been behaviorally proved for that identity.
6. Website lead order is D1 persistence, then GHL and Meta in parallel, then recorded outcomes, then Sheet projection. D1—not Sheets—provides the never-lose-a-lead guarantee.
7. Website `Lead` is fixed value `0`; GHL stage events are exactly `QualifiedLead`, `Schedule`, `Showed`, and `Purchase`. Purchase needs explicit approved economics; the current flat `10000` is nominal and unresolved, not a schema violation.
8. Never wire GHL `meta_event_id`; the website's stable event ID owns browser/server deduplication.
9. Scope tag collision rules to configurable/product `ghl_tags`; exempt canonical entry tag `website-lead`. Never allow product data to emit control/compliance/state tags.
10. Keep a new website in template mode and GHL workflows in draft/sandbox until all applicable release gates pass and a separate publication approval is recorded.
11. Do not export/install the GHL master while contaminated custom values or master IDs can travel. Resolve all target objects by name/key after install.
12. Do not call the current GHL calendar usable while its team is empty. An empty user result may be a scope limitation; the empty calendar team is proven.
13. Do not publish overlapping or contradictory paths: `00` vs `12`, `21` vs `09b`, or any opt-out path that leaves `04` sending reminders.
14. Re-saving trigger-keyed workflows can regenerate trigger IDs and silently break branches. Re-audit operands after every save/import.
15. Imported workflow actions may retain stale `workflowId` or foreign custom-field IDs. Audit and bind by current target IDs/field keys before activation.
16. GHL public APIs expose some Voice/Conversation AI operations, but neither full dashboard parity nor active MCP coverage is assumed. The supplied extraction could not read complete agent/provider configuration.
17. In `simple_paid_funnel` mode, Google Sheets is mandatory and Voice/Conversation AI are not applicable. Do not report completion until one approved controlled opt-in is autonomously verified in the exact D1 database, exact `All Leads` Sheet, exact GHL sub-account, and exact Meta dataset with Browser + Server `Lead` deduplicated.
18. Apply [runtime-configuration-contract.md](references/runtime-configuration-contract.md) before every customer launch. `identity.siteUrl`, deployed Worker origin, and GHL `site_base_url` must join exactly when stage reporting is enabled; `META_TEST_EVENT_CODE` is acceptance-only and forbidden in production; alerting is required by HTL production policy.

## Approval boundary

Local planning, read-only inspection, local edits, mocks, and local validation are allowed only when requested. Stop for explicit approval before:

- commit, push, pull request, or branch publication;
- dependency installation when not already authorized;
- Cloudflare Worker, D1, R2, DNS, domain, route, tunnel, or secret changes;
- GHL snapshot install/export, workflow/field/value/tag/pipeline/calendar/user/message/AI-agent changes, workflow publication, contact enrollment, opportunity movement, or sends;
- Meta/Zaraz/dataset/ad-account changes;
- Vapi, Retell, Bland, telephony, webhook, or external-provider changes;
- live form/test-lead submission, live call, SMS, email, appointment, or webhook;
- deployment, production traffic change, service restart/reload, destructive cleanup, or record deletion.

Before asking for approval, show exact targets, proposed actions, expected customer effects, evidence, test plan, secret names only, and rollback. Do not infer approval from access or credentials.

A generic request to “launch,” “publish,” “make it live,” or “finish” is not mutation-wave approval. Approval is valid only after the user sees the exact target, actions, customer-visible effects, tests, rollback, and cleanup for that wave and explicitly approves that packet.

## Required fulfillment path

For `simple_paid_funnel`, follow [simple-paid-funnel.md](references/simple-paid-funnel.md). Its subset trajectory and definition of done replace the full website+snapshot state machine. Do not require inventory, R2, calendar, phone, Voice AI, Conversation AI, or unrelated GHL workflow repair unless the user adds them. Do require customer-repository isolation, D1, Google Sheets, GHL intake delivery, Meta/Zaraz/CAPI tracking, autonomous approved live verification, and rollback evidence.

For a coordinated full website + snapshot fulfillment, use [fulfillment-runbook.md](references/fulfillment-runbook.md) and iterate through:

1. Resolve scope, sources, exact targets, status, and approval boundary.
2. Collect and approve retailer truth; distinguish required facts, defaults, derived fields, external bindings, secrets, and decisions.
3. Generate the retailer website locally—not merely an intake file—and keep it in template mode.
4. Build, render, observe, repair, and repeat until local criteria pass or a blocker is evidenced.
5. Prepare the GHL install/binding plan from portable names/keys; never reuse master IDs.
6. Reconcile the 19-field website upsert, tag contract, `lead_uuid`, pipeline stages, authenticated webhooks, consent, and Meta event ladder.
7. Resolve every blocking GHL defect and inaccessible AI/calendar dependency before activation.
8. Run deterministic local/mock tests and assemble a human approval packet.
9. In a separately approved task, make narrow staging/external changes, observe each result, and iterate or roll back.
10. Publish/cut over only after gates pass; run approved live proofs and hand off evidence.

Intake validation is not site generation. A JSON schema pass is not snapshot fulfillment. A workflow validation response is not proof that its trigger branches still point correctly. A 2xx website response is not proof of GHL enrollment or Meta deduplication.

## Definition of done

For `simple_paid_funnel`, use the dedicated subset definition of done. For coordinated full website + snapshot fulfillment, do not say complete unless all applicable criteria have direct evidence:

- approved retailer truth and no placeholders, cross-retailer values, or unresolved customer-facing claims;
- website generation, deterministic checks, desktop/mobile truth QA, D1/R2/runtime mapping, and rollback evidence;
- exact GHL portable object inventory resolved in the target by name/key, with no foreign IDs or contaminated values;
- all required workflows/actions/messages rebound and behaviorally tested in staging;
- calendar has verified users/team availability and every task has an approved assignee;
- compliance has one owner and suppresses every required outbound path;
- `lead_uuid` survives website→GHL→stage reporting without reminting;
- one approved lead proves D1, GHL, Sheet, and one deduplicated browser/server Meta `Lead` pair;
- approved GHL stage transitions prove the exact case-sensitive events and values;
- native/external AI configuration is either fully evidenced and tested or explicitly excluded;
- no temporary test code, number, trigger link, contact, or routing remains outside the approved cleanup policy;
- no required customer fact, target binding, runtime dependency, or behavioral claim remains `UNVERIFIED`, `NOT_ACCESSIBLE`, or `BLOCKED`; excluded items are explicitly marked not applicable with scope and reason;
- every unrun or blocked item is labeled, never converted to passed.
