---
name: meeting-insights-analyzer
description: >
  Analyzes meeting transcripts and recordings to uncover behavioral patterns, communication insights, and actionable feedback. Identifies when you avoid conflict, use filler words, dominate conversations, or miss opportunities to listen. Perfect for professionals seeking to improve their communication and leadership skills.
---

# Meeting insights analyzer

Read the transcript or notes first. Quote evidence. Do not invent moments that are not in the source.

## Output
- Patterns with timestamps or speaker turns
- What helped, what blocked decisions
- 3 to 7 concrete next behaviors, not generic advice

