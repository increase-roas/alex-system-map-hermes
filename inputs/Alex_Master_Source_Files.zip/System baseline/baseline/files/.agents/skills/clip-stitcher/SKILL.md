---
name: clip-stitcher
description: Turn a folder of raw talking-head or UGC video clips into a phrase-by-phrase clip library (CLIP-LIBRARY.md with timestamps, which video each line is in, and a Meta direct-response brief that can be pasted into any model), and build new ad videos from an edit list with surgically clean cuts measured from the audio. Use this whenever the user sends raw ad footage, a Drive or Downloads folder of videos, teleprompter takes, or an edit list like "AD-21 #1, #3, AD-22 #8-9b", or asks to transcribe clips, rename videos by content, rank or stitch ads, cut clips up, splice a hook onto another offer, make top-of-funnel or retargeting ads from existing footage, fix a bad cut, remove a gap or breath, or reorder lines in a cut. Use it even if they only say "make an edit for this" or "cut this tighter".
---

# Clip stitcher

Raw ad footage usually holds a better ad than any single take: the best hook is in one clip, the proof in
another, the offer in a third. This skill makes that footage searchable line by line, lets the user (or any
other model) write an edit as a short list, and builds that edit with cuts clean enough to run.

Everything runs locally with `ffmpeg` and `whisper-cli`, plus an optional breath model. Nothing is uploaded and nothing costs money.

## How to work with the user on this

These came from real corrections. They matter more than any technical detail below.

- **An edit list is an order, not a suggestion.** Build exactly those rows in exactly that order. Do not
  swap rows, add rows, or attach advice about what would convert better. They have often already tested the
  idea elsewhere and want to see it, not debate it. Give opinions only when asked for them.
- **The one exception is a defect, and it gets one line.** If the list makes the speaker say the same phrase
  twice, mixes outfits, or a word got clipped, say so in a sentence and fix it or ask. `cut.py` prints these
  warnings. A defect is something that sounds like a mistake, not something you would have done differently.
- **They edit by ear and give short notes** ("cut sooner after 'just looking'", "put 'this weekend only'
  before the 15k"). Treat each note as exact. Make that change, keep everything else identical, return a new
  version (`-b`, `-c`, `-d`), and say what moved and by how much.
- **Fix the cause, not the instance.** When a note exposes a flaw in how cuts are placed, fix the rule in
  `cut.py` so every cut benefits, and say which other cuts changed as a result.
- **When they ask what something says, paste it.** Do not describe a file they could be reading.
- **Say what you verified and what you did not.** You can re-transcribe a cut and compare every word. You
  cannot listen to it. Say both, every time.
- Rough cuts have no captions or music. Say so once, not every time.

## Stage 1: get the footage and see what it is

The Google Drive connector cannot read video files and may list a video folder as empty. Ask the user to
download the folder, then work from the local path. Inside Claude Code's sandbox two things fail in ways
that look like other problems: whisper crashes on the GPU (the scripts already pass `-ng` for CPU), and
writes to `~/Downloads` are blocked (renaming files there needs the sandbox bypass, which prompts the user).

1. Make a contact sheet and look at it:
   `python3 scripts/contact_sheet.py SRC sheet.jpg`
   You are looking for **groups**: who is on camera, what they are wearing, where they are. Two clips can only
   be joined on camera if they match, because a shirt changing mid-sentence gives the edit away. Also note
   which clips have no face (voiceover over footage) and which are silent b-roll. Do not assume one outfit
   because the first few frames match. Look at every clip.
2. If the user wants the files renamed by content, rename them `TYPE-NN_short-description.ext`
   (`AD-`, `UGC-`, `BROLL-`, `LEAD-`, `PHOTO-`) and save an old-to-new map as a TSV so it can be undone.
   Mark exact duplicates `_DUPLICATE`; the scripts skip them. Rename before building the library, because
   clip names become the row addresses.

## Stage 2: build the library

Write these small config files in a working folder (call it `lib/`), then build:

- `groups.json`: `{"AD-01": "plaid", "UGC-01": "no-face", "BROLL-01": "b-roll"}`. Keys are the clip prefix.
  Use `no-face` and `b-roll` exactly; any other value is an on-camera group name.
- `context.md`: a title, what the footage is, the clip types, and project notes (lines that need the client's
  approval before running publicly, lines risky under ad policy, profanity). Keep it factual. Do not put your
  own picks or rankings in it: the file is meant to be tested on other models and that would lead them.
- `instructions.md`: copy `assets/instructions-meta-direct-response.md` and fill in every `{{...}}`.
  Only include it when the user wants the file to carry a brief.
- `fixes.json`: mishearings to correct, `[["Chet's", "jets"]]`. Fill this in after the first build.

```
python3 scripts/build_library.py --src SRC --out lib --groups lib/groups.json \
  --context lib/context.md --instructions lib/instructions.md --fixes lib/fixes.json --sentences lib/sentences.json
```

The first run transcribes every clip (about 10 seconds each on CPU, so run it in the background). Word timings
are cached in `lib/word-timings.json`, so every rebuild after that takes seconds.

**Then read the output and repair it.** Whisper sometimes drops all punctuation from a clip, which collapses
it into one giant row. Find rows longer than about 14 seconds or clips with a single row. For each one, write
the sentences by hand into `sentences.json` (`{"AD-04": ["First sentence.", "Second sentence."]}`), using the
words actually spoken, and rebuild. The script aligns your sentences to the word timings. Do the same for any
clip where a row's text does not match what is said at its edges (a first word whisper never heard, a stray
sound transcribed as words at the end).

What the rows are, and why:
- One row per sentence, as spoken. Short rows ("Guys, stop." / "$47 billion?") are a feature. They let an
  editor or a model take a hook apart.
- A long sentence is split into lettered pieces (9a, 9b) only where there is 0.3 seconds or more of real
  silence at a comma. Splitting at every comma, or at any pause without a comma, produces fragments that
  cannot stand anywhere ("get a free" / "cover, lifter"). Never offer single words as units.
- Times in the file are approximate on purpose. The cutter measures the real cut points from the audio.

Send the user `CLIP-LIBRARY.md`. It is self-contained: context, column meanings, joining rules, every row
under a heading naming its video, and the brief at the end.

## Stage 3: build an edit

```
python3 scripts/cut.py --lib lib --out edits/EDIT-01.mp4 --verify \
  --edit 'AD-21 #1, "this weekend only", "$15,000 off, $19,000 off", #4, AD-22 #8-9, #11, AD-13 #5-6, #8'
```

- `#9` is a whole sentence, `#9a` one piece, `#8-9b` a run. A clip name carries forward.
- A quoted phrase picks exact spoken words from the current clip. Use it when the user wants to reorder or
  drop part of a sentence the speaker said without pausing, so no row boundary exists there.
- Read the warnings. `repeated phrase` means two rows say the same four words, usually two takes that both
  open with the business name. Tell the user in one line and drop one, or ask which. `mixes on-camera groups`
  means the outfit will change mid-ad; the fix is to run one side's audio over b-roll.
- `--verify` re-transcribes the result two ways and diffs it against the script word by word. A word counts as
  missing only when neither pass heard it. If the first or last word of a take is missing, the cutter prints
  `REPAIR`, moves that cut to the next gap, and rebuilds by itself (whisper often starts a last word early, so
  the first gap it finds can be the pause before that word). Anything still listed as missing after that, check:
  a real word means a clipped word, so fix it before sending. If it is at a row's edge, the row's text
  is wrong about what is spoken there, so correct that clip in `sentences.json`, rebuild the library, recut.
  Number formatting and known mishearings show up as harmless mismatches.
- **Framing.** Selfie footage usually puts the face mid-frame with a third of the picture empty above the head.
  Pull a few frames and look before sending a first cut. If the top of the hair sits lower than about 15% of the
  frame, add `--zoom 1.35` (it keeps the bottom of the frame, so the space above the head is what goes). Aim for
  hair near 10% from the top and eyes on the upper-third line, then check frames from every clip in the edit,
  because he moves and a tight crop can clip his hair. `--zoom-y` and `--zoom-x` shift the window. The source is
  only 720p, so past about 1.4x it goes visibly soft.
- Send the video, the length, and how many cuts it has. Compare the length to any figure the user gave:
  models that write edit lists add timestamps badly.

**Which detector decides what is "quiet".** `cut.py` prints `detector:` on its first line.
- `respiro` is preferred. It is Respiro-en, a model trained to find breaths, and the user picked its cuts by ear
  over the loudness cutter in a side by side test, even though the loudness cut measured slightly tighter. Their
  ear outranks the numbers. It lives in `~/.clip-stitcher` (about 1.2 GB) and is used automatically when present.
- If the first line says `loudness (breath model not installed...)`, offer once to install it with
  `scripts/setup_breath_model.sh`. It is a large download and must run outside the sandbox, so ask first. Until
  then the loudness detector works and needs nothing installed.
- Pass `--detector loudness` or `--detector respiro` to force one, for example to give the user both versions to compare.

How the cutter places cuts, so you can reason about a note instead of guessing. Whisper's word times drift
by up to half a second, start a clip's first word at 0.00 even when the speaker waits, and end a last word
after the breath that follows it. In a loud room the quiet dip inside a word ("fif-teen") looks like a pause.
So the cutter reads a 10ms loudness envelope and:
- puts the in point in the room-tone gap closest to the first word, 50ms before it starts, so nothing of the
  previous word rides along and the first sound is never clipped;
- looks for the out point from inside the last word and takes the first real gap, so a breath is never kept;
- leaves rows that are back to back in the source as one continuous take, since a cut there only adds a jump;
- trims dead air over 0.22s inside a take down to 0.09s, only where the gap sits on a word boundary;
- skips dead air at the start of a take but leaves 80ms, because soft first sounds (th, f, s) are quiet;
- never trims ends by loudness, because soft endings ("-ing") sit at room-tone level and get eaten;
- removes a breath between two sentences inside a take by frequency, not loudness: a breath has no energy in
  the low band where the voice's pitch lives and only soft hiss up high, while any voiced word ("We") lights up
  the low band. It leaves 120ms after the voice stops for a final consonant. In a loud room the low band never
  reaches its floor, so this rule finds nothing and changes nothing. That is the safe direction to fail.

Already tried and rejected, so do not retry them: finding breaths with a looser loudness threshold (it ate the
word "We"); Silero VAD (it scores a breath as over 90% speech, pads every edge, and came out looser than
loudness at every setting); and a hybrid where loudness places the cuts and Respiro only removes breaths at
commas inside a take (the word check stopped hearing a word next to one of those cuts). Untested: WhisperX
forced alignment for tighter word times.

When a note says a cut is early, late, or has a gap, the constants at the top of `cut.py` (`PRE`, `POST`,
`MAX_GAP`, `KEEP_GAP`) and the search windows in `bounds()` are where to adjust. Change the rule, rebuild,
and report every cut that moved.

## When the user asks for your picks

Only then. Judge a direct-response ad on: a hook that lands inside 3 seconds and does not open on the business
name; the problem or desire before the product; proof close to the ask; one specific offer; one call to action.
Cold ads run 25 to 40 seconds. Retargeting ads run 10 to 22 seconds, answer one objection each, skip the
introduction, and do not reuse the hook the viewer already saw. When testing hooks, keep the proof, offer and
close identical across versions so the hook is the only variable. If you searched for current guidance, say
what kind of sources you found; if you did not, say that.

Flag, do not decide: lines that make a guarantee or offer the client has not approved for public ads, and
lines that call out a viewer's health condition or promise a cure, which ad platforms tend to reject.
