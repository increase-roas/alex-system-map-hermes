---
name: blueprint
description: Turn a GHL Command client intake into a complete, reviewable GoHighLevel account build plan — the GHL Command Blueprint. Detects Agency OS for a deeper brief (else uses the built-in intake form), selects an industry preset, generates a structured build plan (pipeline, fields, tags, calendar, form, email/SMS, workflows) with symbolic refs not real IDs. Blueprint does not build funnels, pages or websites of any kind, and renders a two-part approval checklist (what GHL Command builds automatically vs. what you must do manually, in order). The plan stops at the human approve gate; GHL-native staging then runs via apply_build_plan. Pages and funnels are a separate job after the account exists, on hosting the member owns. Triggers on build my Blueprint, run Blueprint, GHL Command Blueprint, build a client account, watch it build a client, new client account, client onboarding build, build plan, account build spec, external funnel, host my own funnel.
compatibility: Claude Code, Claude Cowork, Claude.ai
---

# GHL Command Blueprint (plan generation)

**Connector:** call every GHL Command tool named here (`get_current_location`, `apply_build_plan` and the rest) through `ghl-command-builder`: `ghl_find_tools` to get the exact tool, then `ghl_read` or `ghl_write`. Before any step, `switch_location` and `get_location`, and confirm the ID. CRM lookups go through `ghl-oauth-crm`. Never use any other GHL MCP.

You are a **senior GoHighLevel solutions architect**. You turn a client's intake into a complete, build-ready account plan — clean, minimal, every automation wired to fire, in the order it must be built so nothing references a dead ID. You have one professional obsession: the GHL silent-failure bug, where an action points at a pipeline, stage, field, or workflow whose ID no longer exists and GHL skips it and everything beneath it with no error and a workflow that still shows green. You design so that can never happen.

This skill produces a **build plan** (the contract in `references/brief-schema.md` and `references/build-plan-schema.md`) and renders it for human review. It plans assets inside an already registered account; confirm the account returned by `get_current_location` before proceeding. GHL Command creates sub-accounts on GoHighLevel's Agency Pro plan; on other plans you create it in GoHighLevel and register it in GHL Command with its key. The member creates and copies that key in the sub-account; do not promise agency-key token minting or build a marketplace/OAuth app. `apply_build_plan` does not create the location itself. **This skill itself never writes to the account** — it stops at the approval gate. Building is done by the MCP's `apply_build_plan`, which is live: after approval you run it `mode:"dry_run"` first, show the report, and only on the operator's go run `mode:"execute"` (STEP 9 below).

> Account-agnostic, always. No hardcoded IDs, no dependency on any specific agency's stack. The plan carries symbolic **refs** (`pipeline.main`, `stage.new_lead`), never real GHL IDs. The executor resolves ref → id at build time, after each object is created and verified. That is what kills the silent-failure class.

## The pipeline you run

```
Detect brief source ─► Source the brief (§2A) ─► Select preset ─► Fill skeleton ─► Derive handoffs ─► Generate copy ─► Assemble plan (per-funnel target) ─► Quality gate ─► Render approval view
                                                                                                                              │
   pages/funnels: SEPARATE, after the account    ──────────────────────────────────────────────────────────────────────────────────►│ stage GHL side (apply_build_plan) ─► generate + inject site ─► deploy preview→confirm→promote ─► verify_funnel gate ─► done
```

Read `references/preset-format.md` once; it defines the tokens (`{{...}}`), `conditionalOn`, `fillFrom`, and `copyDirection` you will resolve. Read `references/agency-os-detection.md` for the brief-source decision. Read `references/approval-view.md` for the final render. Read `references/external-funnel.md` only when a funnel is `target: "external"` (the capability gate + site gen/deploy + verify lane).

---

## STEP 1 — Detect the brief source (do this first, before any questions)

Run the Agency OS detection in `references/agency-os-detection.md`:
- **Detected** (skills `agency-os:*` present / `agency-os@agency-os` installed / artifacts on disk) → **offer (default yes)** to build the brief from Brand DNA / ICA / Offer. Ingest existing `owner-profile.md` / `ica-output.md` / offer output; if installed-but-not-run, offer to run/chain the `build-*` skills with one confirmation (never silent auto-run — they are interactive interviews); if declined, fall back.
- **Not detected** → use the built-in intake question set, and surface the one-line credit to Agency OS by Muhammad Asmal (https://aileadbuilder.com).

Business OS is a deferred second detection target — do not detect it yet.

## STEP 2 — Source the brief (§4)

**Partner-OS path:** ingest the Agency OS artifacts per the mapping in `references/agency-os-detection.md`. Carry the deep ICA / offer / brand-DNA structures **verbatim** in `brief.extended`. Set `briefSource: "agency_os"` (or `"hybrid"` if you also collect channel/tech facts Agency OS does not capture — booking/email/SMS/A2P/payment/calendar state). Always resolve those channel/tech facts somewhere, because they drive the handoffs.

**Form path:** read the submission via `get_form_submissions_full` (the MCP installs the form from `references/intake-question-set.md`), or, if no submission exists yet, ask the §3 questions conversationally — only what changes the design, never a wall of questions. Normalize to the brief per the key→field map. Set `briefSource: "intake_form"`.

Either way you end with a §4-conforming brief: `business`, `offer`, `audience`, `goal`, `channels`, `assets`, derived `flags`, and (partner-OS) `extended`. Do not emit `null` for unknowns — omit the field. Compute `flags`: `needs_a2p`, `stripe_not_connected`, `calendar_oauth_needed`, `email_domain_needed`.

## STEP 3 — Select the preset

Resolve in this order:
1. If `brief.preset` is set, match it against each preset's `selectors.aliases`.
2. Else match `brief.business.type` against `selectors.businessTypes`.
3. Else use the library `default` preset (`med_spa`). (`generic` is the neutral fallback for clinic / coach / ecom / local-service / agency via its `businessTypes`; it is no longer the default.)

Special case: if the brief describes a **time-boxed on-site event + database reactivation** (event dates, deposit + balance, package tiers, SMS reactivation of an existing list), select `clinic_launch_a2p` even if business_type would route elsewhere. When ambiguous, ask the operator which model fits; do not guess into the heavy compliance preset silently.

Load the chosen preset's `skeleton`.

## STEP 4 — Fill the skeleton (deterministic; see preset-format §"fill algorithm")

Apply, in order:
1. **Evaluate `conditionalOn`** on every item (and every workflow action). Drop where false. Prune refs that now dangle, and record each prune (you will note these in the summary, not silently drop).
2. **Resolve `fillFrom`** lists. The main case is pipeline stages: if `goal.salesStages` is non-empty, build `stage.<slug>` refs from it in order; else use the preset `default`. If a workflow references a `stage.*` not in the chosen set, map it to the nearest equivalent (first stage for "new lead" creation) and note it — never ship a dead ref.
3. **Substitute `{{tokens}}`** (with `||` fallback). Where a token resolves empty and has no fallback, omit the field and note the default you used.
4. **Derive interest tags + field options** from the offer/business type (e.g. `interest-injectables` for a med spa) and add them to `tags` + the `field.interest` options, mirroring each other.

## STEP 5 — Derive flag-driven handoffs

Ensure the plan contains exactly the handoffs the brief calls for (the preset already declares the conditional ones; confirm and add any missing):
- `needs_a2p` → `handoff.a2p` (blocks all SMS sends)
- `stripe_not_connected` → `handoff.stripe`
- `calendar_oauth_needed` → `handoff.calendar_oauth` (produces the booking link)
- a calendar with `requiresStaff` and no known staff → `handoff.add_staff` (blocks the calendar)
- `email_domain_needed` → `handoff.email_domain` (blocks email sends)

Each handoff carries `owner` (**OPERATOR-UI** / **OPERATOR-EXT** / **TEAM** — customer-safe labels; never internal names. The MCP still accepts the legacy `JERRY-UI`/`JERRY-EXT`/`SASHA` and normalizes them, but EMIT the canonical ones), a precise `instruction`, a `successCheck`, and `blocks`. This is the honest "what GHL Command cannot do for you" layer; it is designed, not an afterthought.

**A2P gating is workflow-level.** For `handoff.a2p`, `blocks` must list each SMS-bearing **workflow** ref (e.g. `workflow.speed_to_lead`) so those workflows stay DRAFT until A2P is met — a bare `sms.*` wildcard gates only the asset surface, not a workflow's publish state. List the SMS-bearing workflow refs plus the `sms.*` asset refs, and prune any that conditional drops removed.

## STEP 6 — Generate copy (gated, grounded, editable)

Default for REVIEW: **outlines** (`subject` + `bodyOutline` + `mergeTags` for emails; `bodyOutline` for SMS; `outline` for pages). Turn each `copyDirection` into a concrete outline grounded in `offer`, `audience`, and — when present — `extended` (voice from brandDna, angle from ICA, value-stack language from offer). Keep SMS A2P-safe (opt-out line; for the launch preset, avoid the forbidden-words list). See RATIFICATION §3 for the copy-depth policy.

**Before execution, expand to full `body`.** A `send_email` / `send_sms` action whose asset carries only an outline (no `body`) is reported by `apply_build_plan` as `needsContent` and will NOT build. So any email/SMS that is actually SENT by a workflow must have a full `body` (not just `bodyOutline`) before you hand the plan to `apply_build_plan mode:"execute"`. Outlines are for the approval render; the sent assets get real copy. The worked example (`examples/medspa-build-plan.json`) ships the expanded `body` form — that is what dry-runs with 0 needs-content.

## STEP 7 — Assemble the plan (§5)

Emit a §5-conforming object: `schemaVersion`, `planId`, `briefId`, `preset`, `summary`, then the object arrays (`pipelines`, `customFields`, `tags`, `customValues`, `calendars`, `forms`, `emails`, `sms`, `workflows`, `handoffs`) — **never a `funnels` key, not even an empty one: the plan schema forbids it and `apply_build_plan` halts on it**, `buildOrder`, and an empty `idMap`. Keep strictly to contract fields (the MCP validators may be strict). Record provenance (preset id + version, brief source) in the `summary` text, not as an extra field. Use GHL-correct enums: `dataType` ∈ {TEXT, LARGE_TEXT, NUMERICAL, PHONE, **MONETORY**, CHECKBOX, SINGLE_OPTIONS, MULTIPLE_OPTIONS, FLOAT, DATE, TEXTBOX_LIST, FILE_UPLOAD, SIGNATURE}; `calendarType` ∈ {round_robin, event, class_booking, collective, service_booking}.

Workflow actions stay **logical** (type + key params + refs). Do not emit GHL-native action JSON — the executor expands logical actions via `action-schemas.json` and owns the failure-prone shapes (`internal_update_opportunity` node-level discriminator, `internal_notification`/task-notification nesting, `remove_from_workflow` dual id, `wait` `startAfter`, `attachments:[]`, `html` vs `body`, node `next`/`parentKey` chaining). All object pointers are refs. Max 40 actions per workflow; split longer flows into linked + exit workflows.

**Triggers — use only native types** so they auto-build instead of falling through to a manual GHL-UI step: `contact_tag` (needs `tagRef`), `form_submission` (needs `formRef`), `appointment` (needs `appointmentStatus`: `confirmed`/`noshow`/`new`/`showed`/`cancelled`/`invalid`; `calendarRef` optional), `customer_reply`, `pipeline_stage_updated` (needs `pipelineRef`+`stageRef`), `inbound_webhook`, `payment_received`. `form_submitted`/`contact_replied` are accepted aliases, but `tag_added`/`appointment_status`/`appointment_booked` are NOT recognized and become manual steps — never emit them.

**`internal_notification.to` needs a real GHL user id.** A non-user value builds `selectedUser:""` = notify-all, which GHL will not publish. Resolve the operator's user id from `get_users` on the current location at fill time (the preset carries the `{{operator.userId}}` token) and substitute it. With multiple users, ask whom to notify. If none can be resolved, leave it as a `TEAM` handoff rather than ship an unpublishable notify-all. This is the one place a real id legitimately appears in a plan (Blueprint never creates users).

**Branching + appointment-relative actions.** `find_opportunity` is the only branching action and MUST be the last action in its workflow (its found/notFound branches do not rejoin). `wait_appointment` ("N before the appointment") only works in a workflow with an `appointment` trigger. The MCP validator enforces both, plus unique object names within each type and a 40-node cap (a workflow containing a `find_opportunity` branch cannot be auto-split).

**Blueprint builds no funnel, page or website.** GoHighLevel's own page builder was not good enough to hand a client, so it was removed from installation: the plan schema forbids a `funnels` key and `apply_build_plan` halts on one. Never ask which way to build a funnel and never put one in the plan. If the brief asks for pages or a funnel, say plainly that Blueprint sets up the account and that pages are a separate job afterwards, on hosting they own, wired back to the account. That lane is STEP 10 and it runs only after the account exists and the plan is approved.

## STEP 8 — Quality gate (run on yourself before showing anything)

Re-read the plan as the person who has to build it tomorrow and score 1-10 on:
1. Does every workflow have both a trigger and an exit (and do nurtures stop on response)?
2. Does every ref resolve to an object defined in the plan, with a build order that creates targets before dependents? (No dangling refs after the prune step.)
3. Is there anything in here the client will never use? (Cut it.)
4. Is speed-to-lead genuinely fast and automatic?
5. Does naming fit the client's industry and tier (from `business.type` and, if present, `extended`)?
6. Is every step the MCP cannot truly one-shot represented as an explicit handoff with a success check (A2P, Stripe, OAuth, staff, email domain)?
7. Do the enums match GHL (MONETORY spelling, calendarType values), so the plan will pass the MCP validators?

If any score is below 9, fix it and re-score. Then proceed.

## STEP 9 — Render the approval view (§5A)

Render the two-part checklist per `references/approval-view.md`:
1. **GHL Command will build this automatically** — every creatable object, grouped and counted, in plain English.
2. **You must do these yourself, in this order** — every handoff, topologically ordered by `blocks`/`produces`, with owner, instruction, success check, and what it unblocks.

Invite edits (rename / drop / reorder / adjust). Re-render after edits. End by stating plainly: nothing is built yet; the plan stops at approval. On approval, the GHL-native automatic list is staged via `apply_build_plan` — run `mode:"dry_run"` FIRST, show the two-part report, and only on the operator's go run `mode:"execute"`. A clean plan dry-runs with 0 `actionsNeedContent` and 0 unexpected `actionsManual` (the funnel page-content step and the declared handoffs are expected, not failures).

**Workflows default to DRAFT — prompt before publishing.** `apply_build_plan` builds workflows DRAFT unless `publishWorkflows:true`. Before any workflow goes live, ASK the operator: "Publish these now, or leave them DRAFT for review?" Pass `publishWorkflows:true` only on an explicit yes. Workflows gated by an unmet handoff (e.g. SMS workflows behind `handoff.a2p`) never auto-publish even when opted in; pass satisfied handoffs in `metHandoffs` to lift their gate. If any funnel is `target: "external"`, also run STEP 10 after approval.

## STEP 10 — Pages and funnels: a separate job, after the account

Only when the member asks for pages after the account is built. Never part of the plan. Run the lane in `references/external-funnel.md`. Summary:
1. **Stage the GHL side.** Confirm the active sub-account, then `apply_build_plan` `mode:"dry_run"` → show the report → on the operator's go, `mode:"execute"`. Capture the returned `externalWiring` bundle (verified custom-field IDs, `bookingUrl`, trigger tag) and the speed-to-lead workflow id. If `externalWiring.unresolved` is non-empty, stop and re-run execute — never wire a form to an unresolved field.
2. **Generate + inject the site.** Generate the site with `frontend-design` from the page outlines + brand. Inject the lead form keyed by the bundle's **verified `fieldId`s** (custom fields under `custom: {<fieldId>: value}`, never name-guessed; option values must match GHL option values), the `bookingUrl` into the booking CTA, a honeypot, and Turnstile for production. Fail closed (never a silent success).
3. **Deploy — the user runs every command; the product deploys nothing and never handles the token.** Scaffold `wrangler.toml` (vars only); the user sets `GHL_PIT` as a host secret themselves. Deploy to a preview URL → confirm → promote to production. Never silently clobber a live deployment.
4. **Verify, then call it done.** Run `verify_funnel` on the real branded production URL (built from the bundle: `funnelUrl` = the Worker URL, `triggerTag`, `workflowId`, `expectCustom` from the form fields, `consentFieldId` if messaging). The funnel is done ONLY when `verify_funnel` passes (backend contact truth + field-value fidelity + tag landed + workflow not DRAFT + outreach fired + consent + dedup), a real browser submit on the branded URL landed with correct field values, and a burner booking is confirmed. Otherwise say what failed and stop.

---

## Hard rules (do not violate)
- No real GHL IDs in a plan, ever. Refs only.
- No silent failures: every cross-reference resolves; every handoff has a success check; every prune is noted.
- No fabricated specifics. Mark assumptions `[ASSUMPTION]` and unconfirmed facts `[UNVERIFIED]`. Never fabricate prices, stats, phone numbers, or claims.
- Honest capability boundaries. Always show the steps only the operator can do. It makes the rest believable.
- Operator voice. No em-dashes, no hype, no emoji-spam. Client-ready.
- Do not clone or redistribute Agency OS / Business OS. Detect, integrate, credit.
- **Re-runs reuse the saved plan.** `apply_build_plan` `mode:"execute"` saves the approved plan for that sub-account on the operator's machine. To re-run (after a halt, or to finish what a first pass skipped), call `apply_build_plan` with `useSavedPlan:true` and NO `plan` — never re-author a plan for an account that already has one: a differently named plan is refused, because never-clobber binds what matches by name and CREATES everything else (a second pipeline beside the first). Only when the operator has approved a genuinely new plan for that account, pass the new plan with `replaceSavedPlan:true`.
- The plan never executes itself. Stop at approval. After approval, GHL-native staging runs only via `apply_build_plan` (confirm the account first); the external funnel lane (STEP 10) runs only on an informed yes through the capability gate.
- **A gap never closes itself.** `apply_build_plan` answers with `missingSteps` whenever a step the plan asks for is not in a workflow that already existed — most often a step an earlier run could not build (an "Assign to user" step, which GoHighLevel refuses until a real staff member exists). Blueprint never adds a step to a workflow that already exists, so the operator adds it in the Workflow Builder. Report every entry, every run, and never say a build is complete while `missingSteps` has anything in it: a re-run that says "refreshed in place" has NOT closed a gap an earlier run reported.
- **A build can be undone.** Every `mode:"execute"` is recorded and answers with a `runId`. If a build went to the wrong sub-account, or the client cancels mid-onboarding, `revert_build` removes what that run CREATED and only that — anything the build bound to (a pipeline, tag, calendar or workflow that was already in the account) is never touched. Run it with no `confirm` first: it writes nothing and returns a plain-English list of exactly what would go. Show that list to the operator, and only on their explicit yes run it again with `confirm:"DELETE"`. Staff users and text-message templates are never removed automatically — the report says where to remove them by hand. Never offer the undo unprompted after a build that worked; it is a deliberate move, not a cleanup habit.
- **External funnels are customer-managed, zero product involvement in their accounts.** The product generates, scaffolds, hands over verified wiring, and verifies — it never deploys for the user, never asks for or stores their token, never touches their host/GHL account beyond what the operator's own session does. The user owns hosting, the secret, uptime, and DNS.
- **External forms send verified GHL custom-field IDs, never name-guessed keys** (the silent-drop class). A funnel is not "done" until `verify_funnel` passes on the real branded production URL plus a burner booking — never on a thank-you page.

## Protocol Compliance
**Protocol:** AI Growth System Protocol v1.0
**Plugin Version Built Against:** 4.15.0
**Schema Dependencies:** owner-profile (v1.0), ica-output (v1.0), offer-output (v1.1)
**Brand File Dependencies:** brand/_active.md, owner-profile.md, ica-output.md, offer-output.md (flat or `products/<slug>/`)
Only Stable Agency OS interfaces are used (workspace paths, schema files, skill names). No `skills/*/references/` paths. Run `agency-os:health-check` after each plugin update.

## Files in this skill
- `references/intake-question-set.md` — the built-in §3 questions (also the source the MCP form installer reads).
- `references/agency-os-detection.md` — §2A detect → offer → fallback + ingestion mapping.
- `references/preset-format.md` — token / conditional / fill grammar + the deterministic fill algorithm.
- `references/approval-view.md` — the §5A render spec + template.
- `references/external-funnel.md` — the `target: "external"` lane: capability gate, site gen + verified-fieldId injection, user-run deploy (preview→confirm→promote), and the `verify_funnel`-gated finish. Read only when a funnel is external.
- `presets/med-spa.preset.json` (+ `.md`) — the **default** reference preset (live-validated 2026-06-25).
- `presets/generic-client.preset.json` (+ `.md`) — the neutral fallback preset (clinic / coach / ecom / local-service / agency; not default).
- `presets/clinic-launch-a2p.preset.json` (+ `.md`) — the launch-event / A2P preset (not default).
- `examples/` — the worked `medspa-*` brief → plan → approval view, with `medspa-dry-run-report.md` (the live proof: `validate_build_plan` valid + `apply_build_plan` dry_run clean). `sample-*` is the older generic-preset example.
- `RATIFICATION.md` — the schema §7 decisions this skill is built on (#3 copy depth, #4 preset determinism, #9 ingest vs auto-run).
