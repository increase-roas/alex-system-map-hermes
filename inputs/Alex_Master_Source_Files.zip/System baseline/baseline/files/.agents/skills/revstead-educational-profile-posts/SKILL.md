---
name: revstead-educational-profile-posts
description: Create educational Facebook and Instagram profile-post visuals for Revstead Systems that teach fencing contractors practical scaling and operations principles. Use when the user asks for Revstead social posts, educational graphics, fencing-contractor content, organic Meta profile content, or a new post in the approved dark green grid visual system.
---

# Revstead Educational Profile Posts

Create **practical educational social graphics** for fencing contractors. The work is not a paid-ad recreation and not a generic B2B content factory. Teach one operational lesson at a time, using Revstead’s dark operations-system design language.

## Core Output Rule

Create **one final post visual at a time**, deliver it for approval, and stop. Do not generate a batch, extra variants, or the next post until the user explicitly approves or asks to continue.

Default format is **4:5 vertical** for Meta feed use. Use 1:1 only when the user asks or an established publishing requirement makes square preferable.

## Intake

Use the files and context the user already supplied. Ask only for information that materially affects correctness.

| Requirement | Default or action |
| --- | --- |
| Brand visual reference | Use the supplied Revstead dark-green website or post reference. If none exists, ask for one. |
| Logo | Use a supplied Revstead mark when available. Otherwise, use restrained “REVSTEAD SYSTEMS” text. |
| Topic | Use the user’s topic. If none is provided, propose one concrete fencing-operations lesson. |
| Post format | Default to 4:5 vertical. |
| Call to action | Use a soft save/comment prompt in the caption. Do not add lead-magnet, playbook, or booking CTAs unless requested. |

Do not ask the user to complete a large questionnaire. If the creative brief is already clear, begin with the first post.

## Brand System Lock

When using the approved Revstead reference, reproduce the **design system**, not the reference page or its browser chrome.

| Element | Direction |
| --- | --- |
| Background | Near-black forest green, typically `#06150F` or comparable. |
| Structure | Thin technical square grid, faint fence-plan linework, subtle dark-green glass panels. |
| Text | Warm off-white primary type; clear, bold sans-serif headline; compact monospaced utility labels. |
| Accent | Bright emerald green only, used for emphasis, checks, rules, or a single structural beam. |
| Hierarchy | One high-contrast headline, one short supporting line, one compact operational framework. |
| Branding | Keep the Revstead mark or wordmark small and secondary, usually in a footer zone. |

Do not use the calculator campaign’s white/black/yellow system for these posts unless the user explicitly asks to switch campaigns. Do not recreate a website navigation bar, browser bar, device shell, social-platform UI, comments, reactions, or other screenshot chrome.

## Educational Content Rules

Write like an operator who understands fencing businesses. Center the post on a real operational issue: estimating, margin control, lead qualification, follow-up, sales-to-install handoff, scheduling, capacity, standardization, or owner bottlenecks.

Use direct, contractor-specific language. Give one useful lesson, checklist, or process. Avoid broad motivational language, “AI” filler, fabricated performance claims, ROI figures, testimonials, fake data, awards, and invented customer stories.

### Strong content patterns

| Pattern | Example |
| --- | --- |
| Pricing discipline | “FAST QUOTES ARE GOOD. RUSHED PRICING IS EXPENSIVE.” |
| Margin-first estimating | “YOUR QUOTE SHOULD START WITH YOUR MARGIN.” |
| Lead qualification | “MORE LEADS DO NOT AUTOMATICALLY MEAN BETTER GROWTH.” |
| Follow-up | “A QUOTE IS NOT A FOLLOW-UP SYSTEM.” |
| Sales-to-install handoff | “A SOLD JOB IS NOT READY FOR THE CREW YET.” |
| Capacity planning | “DO NOT SCALE SALES FASTER THAN YOU CAN INSTALL.” |
| Standardization | “STANDARDIZE WHAT YOU SELL MOST.” |
| Owner dependency | “IF EVERYTHING WAITS ON THE OWNER, GROWTH STALLS.” |

## Copy Structure

Use this structure unless the topic clearly needs a different one:

1. A small monospaced category label, such as `FENCING OPERATIONS`.
2. A clear headline of 5–12 words. Give the key tension, mistake, or principle prominence in emerald green.
3. One short explanation line, if needed.
4. A three-to-five-step framework, checklist, or workflow panel.
5. A restrained footer: `REVSTEAD SYSTEMS` plus a short audience line such as `Built for fencing contractors.`

Keep the on-image copy short enough to read at mobile feed size. Write fuller teaching in the caption, not inside the graphic.

## Creation Workflow

1. **Select the lesson.** Make one specific operational point; do not combine pricing, hiring, sales, and production into the same graphic.
2. **Build the visual brief.** Define headline, one supporting line, framework labels, and a trade-specific background cue such as fence-plan linework, a job folder, an estimate sheet, or a crew-capacity flow.
3. **Generate the standalone image.** Use the supplied style reference when available. Keep it native to the target 4:5 or requested aspect ratio; never place it inside a phone or browser screenshot.
4. **Check only critical requirements.** Confirm the headline, framework labels, dark-green grid system, emerald accent, and absence of prohibited product/claim filler. Make one targeted correction only if a critical requirement fails.
5. **Deliver and stop.** Attach only the finished post and ask for approval or one correction. Do not create the next post until the user responds.

## Prompt Blueprint

Use this as a starting point and replace bracketed content:

```text
Create a polished [4:5 / requested ratio] educational social profile post for Revstead Systems, aimed at fencing contractors. This is a native standalone Facebook/Instagram feed graphic—no browser, social-media, phone, or website chrome.

Use the supplied Revstead reference only for the visual system: nearly black forest-green background, thin architectural square grid, subtle deep-green interface-panel shadows, warm off-white typography, and a single bright emerald-green accent. It should look like a premium fence-operations brand, not a generic SaaS template.

Text hierarchy and exact copy:
Small top label: “[CATEGORY LABEL]”
Large primary headline: “[HEADLINE]”
Supporting copy: “[ONE-LINE EXPLANATION]”
Framework labels: “[LABEL 1]”, “[LABEL 2]”, “[LABEL 3]”
Small footer: “REVSTEAD SYSTEMS” and “[AUDIENCE LINE]”

Composition: [headline zone] above [compact framework panel]. Include [trade-specific visual cue] as subtle background texture. Make the main tension or principle emerald green. Preserve mobile legibility and clean negative space.

Avoid yellow, blue, red, purple, people unless requested, stock photography, fake metrics, testimonials, fabricated outcomes, product promotion, AI/agent wording, lead-magnet CTA, and platform UI.
```

## Caption Pattern

Write a concise caption after the graphic is approved, unless the user asks for it before generation. Open with the operational tension, explain the lesson in two or three short paragraphs, then close with one natural question or save prompt. Do not add a hard product pitch to every educational post.

> Example ending: **Save this before your next estimate.**

## Edits

For a requested image revision, change only the requested copy, object, or layout area and preserve the approved background system, hierarchy, colors, grid, panel geometry, and all non-target content. If a text-only change cannot be made without regenerating the image, state that limitation before changing the composition.

## Delivery Standard

Attach the final PNG directly. State the post topic in one sentence, request approval or one correction, and stop. Do not upload, publish, schedule, or modify external social accounts unless the user explicitly requests it.
