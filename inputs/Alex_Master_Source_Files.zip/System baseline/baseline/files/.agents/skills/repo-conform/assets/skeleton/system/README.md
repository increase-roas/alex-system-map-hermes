# system

How this project learns without git: every task leaves a trace, lessons collect with
evidence, and once a week a tune-up proposes small, tested changes that the owner approves.

## The loop
1. **Every task**: one line in `system/run-log.md` (date | job | result | corrections).
2. **When the owner corrects Claude or a task fails**: `capture-lessons` adds or updates a
   candidate in `system/lessons.md`, with evidence.
3. **Weekly (scheduled)**: `weekly-tuneup` snapshots the control files, consolidates lessons,
   drafts edits for lessons seen twice or stated by the owner, tests them with golden tasks,
   checks tool drift and budgets, and writes `system/proposals/YYYY-MM-DD.md`.
4. **Owner approval**: the owner approves or rejects each item in chat.
5. **Apply**: approved items only, each logged in `system/CHANGELOG.md` with a restore path,
   and tracked in `system/rules-ledger.csv`.

## Why it works this way
- **Small edits, never rewrites.** In testing, a learnings file rewritten whole each step
  shrank from 18,282 tokens to 122 and lost accuracy. Entries with ids, edited one at a
  time, kept their detail.
- **Evidence before promotion.** Skills models wrote for themselves without feedback averaged
  1.3 points worse than none (SkillsBench). In coding tests, AI-written instruction files
  didn't raise success and added about 20% cost. Real corrections and failures are the signal.
- **A test before promotion.** Changes that seem helpful can break other tasks. The golden
  tasks in `system/evals/golden-tasks.md` catch that.
- **A human yes.** Every method that worked in research had feedback from outside the model:
  a test, a check, or a person. Agents rate their own work far too highly.
- **Retire, don't delete.** Retired rules keep their row, so a mistake can be undone.

## Control files
Changed only through this loop: `AGENTS.md`, `.agents/skills/`, `tools/README.md`. The weekly
snapshot also copies `knowledge/`, `system/lessons.md` and `system/rules-ledger.csv`, because
they shape behavior too.

## Budgets
| Item | Limit |
|---|---|
| `AGENTS.md` | 200 lines |
| Active lessons in `system/lessons.md` | 100 lines |
| Each `SKILL.md` | 150 lines |
| Skill description | 200 characters |

Over budget means merge or remove item by item. Thresholds live in
`~/.agents/skills/weekly-tuneup/references/promotion-and-pruning.md`.

## Versioning (two layers)
1. **Snapshots** in `system/snapshots/`: a dated copy before any control-file change. Keep the
   last 10 plus every known-good one. See `system/snapshots/README.md`.
2. **Your computer's version history** (Time Machine, Google Drive, Dropbox, OneDrive). Cloud
   history is often only 30 days, so it backs up the snapshots rather than replacing them.
   Retention details: `setup/02-app-settings.md`.

To roll back: copy the file from the snapshot named in `system/CHANGELOG.md` back into place,
and add a CHANGELOG line saying "rollback".

## Who approves
| Change | Who |
|---|---|
| Run log, lessons (candidates), incidents | Claude, any time |
| `knowledge/` | the owner, or Claude when the owner asks for a specific edit |
| `AGENTS.md`, `.agents/skills/`, `tools/README.md` | the owner, item by item, after a proposal |
| Deleting anything, including old snapshots | the owner only |

## Files here
- `system/run-log.md`: append-only task log.
- `system/lessons.md`: candidate lessons.
- `system/rules-ledger.csv`: every active rule, with evidence counts.
- `system/CHANGELOG.md`: every control-file change.
- `system/evals/`: golden tasks and how to grade them.
- `system/snapshots/`: dated copies of control files.
- `system/proposals/`: weekly proposals.

## Reading these files
The run log, lessons and changelog are history. Claude reads them as evidence during the
tune-up, not as instructions for the current task. Past entries copied as precedent can
repeat old mistakes.
