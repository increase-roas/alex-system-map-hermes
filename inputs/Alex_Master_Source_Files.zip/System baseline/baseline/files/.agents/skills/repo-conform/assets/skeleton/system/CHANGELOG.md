# CHANGELOG

<!-- Append only, newest at the bottom. One line per changed control file.
     Written when an approved change is applied (rule 5 in AGENTS.md). -->

Every change to a control file (`AGENTS.md`, `.agents/skills/`, `tools/README.md`) gets a line here.
Changes to `knowledge/` that came from a weekly proposal get one too.

- date: when it was applied, YYYY-MM-DD.
- file: the path that changed.
- change: what changed, in a few words, with lesson or rule ids (L-0xx, R-0xx).
- why: the evidence, or the owner's words.
- approved by: the owner's name, and "in chat YYYY-MM-DD".
- restore from: the snapshot copy, like `system/snapshots/YYYY-MM-DD_HHMM/AGENTS.md`.

To roll back: copy the "restore from" file back into place, then add a line with change
"rollback of [date] change" and why.

| date | file | change | why | approved by | restore from |
|---|---|---|---|---|---|
| 2026-09-29 | all files | initial blueprint | project created | [owner] | none (first version) |
