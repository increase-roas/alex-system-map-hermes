# .claude/skills

Claude Code reads project skills here. Each entry is a link to the real folder in
`.agents/skills/<name>/` (see `.agents/skills/README.md`). Never put a copy here.
