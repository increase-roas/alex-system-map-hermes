# evals

Golden tasks: small, saved tasks with pass criteria, used to check that the setup still works
after a change. Changes that look helpful can quietly break other tasks; in one benchmark,
16 of 84 tasks got worse even with curated skills.

## The task list
`system/evals/golden-tasks.md` holds 8 seeded tasks plus blank rows. Add a task whenever a
real mistake happens that must never happen again, and for each new skill.

Two kinds:
- **Regression**: should pass every time. A failure blocks the change that caused it.
- **Capability**: currently fails; a target to improve. It moves to regression once it
  passes reliably.

Aim for about 10 of each, growing toward 20 to 50 over time, drawn from real work.

## How to run
1. Run each task in a fresh conversation or a fresh subagent, so earlier chat doesn't help.
2. Use test inputs only: a test file in `inbox/`, a draft in a test job folder. Never real
   clients, real sends or real spends.
3. Save each output in `work/YYYY-MM-DD_golden-tasks/`, one file per task.
4. Run a task 2 or 3 times when results vary.
5. Clean up afterwards by moving test files to `_archive/`, not deleting them.

## How often
- On every change proposed by `weekly-tuneup`: the regression tasks plus the tasks the change
  targets, with and without the change where feasible.
- The full set weekly, as part of the tune-up.
- After any Claude model upgrade, including one run with each `AGENTS.md` rule left out.
- After editing `AGENTS.md` or re-uploading a skill, run `setup/03-first-run-test.md`.

## Grading rules
1. **Rule-based checks first.** File exists, section present, price matches
   `knowledge/offers.md`, nothing sent, `AGENTS.md` unchanged. Fast and objective.
2. **A separate grader for the rest.** A fresh subagent that didn't produce the output,
   with no write tools, gets the task, the pass criteria and the output only.
   - Score each criterion separately: pass, fail or unknown.
   - Ask it to look for failures, not to confirm success.
   - When comparing two outputs, swap their order and grade again; judges favor position.
3. **Grade the output, not the path.** A different route to a correct result is a pass.
4. **Calibrate.** For the first few weeks, the owner grades the same outputs. Where the owner
   and the grader disagree, fix the criteria wording.
5. **All-pass is a warning too.** If a task passes with and without a change, it doesn't
   test that change; write a harder one.

Record results in the weekly proposal: task, pass or fail, with and without the change.
