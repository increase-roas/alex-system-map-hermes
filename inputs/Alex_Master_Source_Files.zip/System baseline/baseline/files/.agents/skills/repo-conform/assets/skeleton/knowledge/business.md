---
topic: business profile, audience, voice, proof
updated: YYYY-MM-DD
source: [owner, in chat YYYY-MM-DD, or sources/...]
owner: [name]
---

# Business

## Who we are
- Business name: [legal and trading name]
- What we do, in one sentence: [sentence]
- Where we operate: [cities, regions, online]
- Website: [URL]

## Audience
| Segment | Who they are | What they want | What stops them buying |
|---|---|---|---|
| [primary] | [description] | [outcome] | [objection] |
| [secondary] | [description] | [outcome] | [objection] |

## Voice
- We sound: [3 to 5 words, like plain, warm, direct]
- We never sound: [like pushy, jokey, corporate]
- Spelling and style: [US or British spelling, date format, capitalization]
- Example of our voice at its best: [a sentence or short paragraph you've approved]

## Proof we can use
Only claims listed here, with a source, may appear in copy.
| Claim | Source | Can be used until |
|---|---|---|
| [like "4.9 stars from 312 reviews"] | [URL or sources/...] | [YYYY-MM-DD or "no end"] |

## Words to avoid
| Word or phrase | Why |
|---|---|
| [like "cheap"] | [off-brand, legal, or a competitor's term] |

## People and contacts
| Role | Name | Notes |
|---|---|---|
| [owner] | [name] | [what they approve] |
