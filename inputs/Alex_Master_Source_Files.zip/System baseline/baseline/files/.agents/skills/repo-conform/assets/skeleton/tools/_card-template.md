---
name: [tool family, like exa or crm-main]
route: [Composio toolkit slug, like custom_ghl_oauth_crm; or built-in / browser / computer use]
namespace_prefix: [only for a route outside Composio, like mcp__playwright__]
source: [Composio / connector / local MCP / plugin / built-in / browser / computer use]
account: [which login, workspace or sub-account this project uses]
jobs: [J1 to J8]
worst_tier: [T0 to T5]
approval: [the app settings, like "reads Always allow; sends Needs approval"]
cost: [per call or per month, or "included"]
rate_limits: [known limits, or "unknown"]
tool_count: [number]
last_verified: YYYY-MM-DD
verified_by: [tool-card run, or the owner]
vendor_docs: [URL, and the date it was checked]
---

# [Tool family]

<!-- Keep the top of this card self-sufficient (roughly the first 2 KB). Some apps cut long
     tool text, so the most important lines go first. Never put keys or passwords here. -->

## Purpose
[One line.]

## Use when / don't use when
- Use when: [job]
- Don't use when: [job] (use [other tool] instead)

## Key tools
| Full tool name | What it does | Tier | App setting |
|---|---|---|---|
| [tool slug exactly as `composio search` returns it, or mcp__Server__tool_name] | [one line] | [T0 to T5] | [Always allow / Needs approval / Blocked] |

## Workflow order
[Which call comes first, what IDs you need, how tools relate.]

## Names and IDs Claude can't guess
| Plain name | ID or value |
|---|---|
| [like "main pipeline"] | [ID] |

## Good example calls
Only for tools with tricky inputs; 1 to 5 examples.
- [example]

## Quirks
- [known behavior that surprises people]

## Failure and fix
| Symptom | Cause | Fix |
|---|---|---|
| [error or wrong result] | [why] | [what works] |

## Big outputs
[How to keep large results out of the conversation: filters, limits, save to a file, subagent.]

## Changelog
- YYYY-MM-DD: [what changed on this card and why]
