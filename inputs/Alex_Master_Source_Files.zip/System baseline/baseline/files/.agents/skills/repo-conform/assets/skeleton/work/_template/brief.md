# Brief: [job name]

<!-- Copy work/_template/ to work/YYYY-MM-DD_job-name/ and fill this in before starting.
     A complete brief up front matters: in tests, requirements drip-fed over many turns
     cut results by 39% on average. Anything marked [missing] is a question for the owner. -->

Job folder: work/YYYY-MM-DD_job-name/
Created: YYYY-MM-DD
Stakes: [low / normal / high: client-facing, published, money, or many records]

## Goal
[One or two sentences: what this job produces and why it matters.]

## Audience
[Who will read or use it. Link a segment in knowledge/business.md if there is one.]

## Done means
Each line must be checkable by someone who didn't do the work.
- [ ] [like "3 headline options, each 30 characters or fewer"]
- [ ] [like "every price matches knowledge/offers.md"]
- [ ] [like "saved as deliverables/YYYY-MM-DD_name_v01.docx after owner approval"]

## Facts allowed
Only these sources may supply prices, dates, numbers, claims and quotes.
- [knowledge/offers.md]
- [sources/...]
- [cited URLs found during research]

## Out of scope
- [what this job does not cover, so nobody drifts into it]

## Deadline
[YYYY-MM-DD, and any earlier review point]

## Approvals needed
List every send, publish, spend or delete this job may need. Sends, publishes and deletes need a
yes in chat at the moment they happen; spend follows the project's `Spend approval:` line in AGENTS.md
(unset means ask).
- [like "send the final email to the client from the CRM"]

## Open questions for the owner
- [missing]
