# App settings: the locks

Text in `AGENTS.md` guides Claude; these settings are what actually stop an action. Anthropic's
own docs say instruction files are context, not enforced configuration. Menu names are as
documented on 2026-09-29 and move often, so look for the nearest match.

## Project and folder
- [ ] One Claude Project per business or client. Project memory stays inside its project,
      so facts from one client can't leak into another.
- [ ] Connect only this folder. Never your home folder, Desktop or a whole drive.
- [ ] Folder access: read-write without delete, if your app offers it. Anthropic describes
      three mount modes: read-only, read-write and read-write-no-delete. On managed
      computers an admin may set them.
- [ ] Deleting a file always asks for approval in the app, whatever the mode. Leave it that way.
- [ ] Permission mode: Manual (the default) for now. Switch to Auto only after every golden
      task in `system/evals/golden-tasks.md` passes. Auto also uses more of your usage.

## Connectors: tier to setting
Customize > Connectors > pick a connector > set each tool. Tiers are defined in `tools/README.md`.
Gate T3 to T5 always, and T2 only until you trust the tool. In Anthropic's data, Claude Code
users approve 93 to 97% of permission prompts, so gating everything makes every gate a rubber
stamp.

| Tier | Setting | Example tool names (the CRM examples are from a GoHighLevel connector) |
|---|---|---|
| T0 read your own data | Always allow | `get_*`, `list_*`, `search_*`, `ghl_execute_read_operation` |
| T1 read outside content | Always allow | `EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`, the Composio docs readers, built-in web search |
| T2 reversible write | Needs approval, unless you trust the tool (then Always allow) | `create_*`, `update_*`, `add_*` |
| T3 bulk or destructive | Needs approval; bulk and whole-object deletes Blocked | `delete_*` (approval); `bulk_delete_contacts`, `delete_workflow_full` (Blocked) |
| T4 send or publish | Needs approval | `send_message`, `send_estimate`, `post_to_slack`, `create_social_post` |
| T5 spend money | Blocked until a task needs it, then Needs approval | `create_invoice`, `send_invoice`, `record_invoice_payment`, `void_invoice`, `sync_stripe` |

A tool's tier is its worst operation. A general "execute any operation" tool, such as
`ghl_execute_operation`, gets the tier of the riskiest thing it can do.

- [ ] `EXA_CREATE_AGENT_RUN`, Exa research and Websets cost money per run (agent $0.012 to $1.00
      by effort; `auto` capped at $5). They follow the project's `Spend approval:` line; keep
      effort at low (see `tools/exa.md`).
- [ ] After `tool-card` lists new T3 to T5 tools, set them here. Whether new tools inherit a
      category's setting isn't documented, so check each one.
- [ ] Browser and computer use: see `tools/browser-and-computer.md`. Computer use asks per app,
      not per tool. Block banking, health and password apps.
- [ ] Opening this folder in Claude Code? It has its own permission rules. Mirror the tiers
      there: deny for bulk and delete tools, ask for send and spend tools.

## Tool access and look-alikes
- [ ] With 10 or more connectors, set Tool access to "On demand" (+ menu > Connectors > Tool
      access). It reportedly resets to Auto in each new chat, so check it.
- [ ] Turn off connectors this project doesn't use. Fewer loaded tools means better picks.
- [ ] Look-alike tools: two connectors that do the same job confuse tool choice. Disable one,
      or write in the `AGENTS.md` routing table which one does what.

## Skills
- [ ] Upload the zips from `system/skill-zips/` and turn on skill-creator (`.agents/skills/README.md`).
      The 7 universal skills need uploading once per Claude account, not per project.
- [ ] Don't install third-party skills or plugins you haven't read end to end. Snyk found
      critical issues in 13.4% of about 4,000 public skills (Feb 2026).

## Backups and secrets
- [ ] Keep API keys, passwords and card numbers outside this folder. Use each connector's own
      sign-in or a password manager. Anything in the folder can be read and sent.
- [ ] Keep the folder where it has version history. Typical retention (check your plan):
  - Time Machine: hourly for 24 hours, daily for a month, weekly until the disk fills.
  - Google Drive: a version may go after 30 days or 100 newer versions; pin "Keep forever".
  - Dropbox: 30 days (Basic, Plus, Family), 180 days (Professional, Essentials, Business,
    Standard), 365 days (Business Plus, Advanced, Enterprise).
  - OneDrive personal: 30 days.
  - iCloud Drive: deleted files recoverable for 30 days; version history for other files unconfirmed.
- [ ] Snapshots in `system/snapshots/` are the first layer; this is the second.

## Weekly tune-up
- [ ] Run it once by hand ("Run weekly-tuneup") and check the proposal it writes. Anthropic
      Academy suggests doing a task once before scheduling it.
- [ ] Then schedule it weekly (/schedule or the Scheduled page) in this project, with this folder.
- [ ] It needs the desktop app open and this computer awake, because it reads a local folder.
      If the computer sleeps, the run is delayed or skipped (sources differ).

## Memory and account instructions
- [ ] Project memory is separate for each project. Use it for preferences, not work facts;
      facts go in `knowledge/`, where they have a source and a date. Review memory monthly.
- [ ] Instructions for Claude (Settings > General) apply to every conversation in every
      project. Keep only facts true about you everywhere; project facts go in this folder.
