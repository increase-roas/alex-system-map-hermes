# notes

One file per subagent part. When `fan-out` splits a job, each subagent writes only its own
file here and nothing else, because two agents writing the same file overwrite each other.

## Naming
`work/<job>/notes/<part-name>.md`, lowercase with hyphens. Examples: competitor-acme.md,
competitor-bolt.md, file-summaries-a-to-m.md.

## What each file holds
- The part's question and the date "as of".
- Findings, each marked as fact (with a source and date) or inference.
- Conflicts and gaps found.
- Sources used, with URLs or `sources/` paths.

The lead agent reads these files, resolves conflicts, and writes the single deliverable in
the job folder. Notes stay here as the record; they are not deliverables.
