# STATUS

<!-- Read first, update last. Keep under 60 lines: current state only.
     History goes in system/run-log.md; finished items move out of here. -->

Updated: YYYY-MM-DD

## Focus right now
- [the one outcome this week is about]

## In progress
| Job folder | State | Next step | Owner |
|---|---|---|---|
| work/YYYY-MM-DD_job-name/ | drafting | [next step] | Claude / [name] |

## Waiting on the owner
- [decisions, approvals, missing facts]

## Blockers
- [what's stuck and why]

## Recently done (last 5; older lines move to the run log)
- YYYY-MM-DD: [deliverable], saved in deliverables/
