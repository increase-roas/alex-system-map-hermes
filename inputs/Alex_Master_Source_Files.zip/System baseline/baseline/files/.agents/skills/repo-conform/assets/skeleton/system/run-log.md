# Run log

<!-- Append only. One line per task, newest at the bottom. Never edit or delete old lines.
     This is history for the weekly tune-up, not instructions for the current task. -->

Format: `YYYY-MM-DD | job | result | corrections`
- job: the job folder name or the skill run, like `2026-09-29_fall-promo` or `intake-triage`.
- result: done, done except X, failed, or waiting on the owner.
- corrections: what the owner corrected, in their words, or "none".
- The weekly tune-up adds `YYYY-MM-DD | weekly-tuneup | proposal written | N items`.

Example (not a real entry):
`2026-09-29 | 2026-09-29_fall-promo | done except hero image rights | owner: "use the regular price from the sheet, not the old ad"`

## Log
