# Lessons (candidates)

<!-- Written by capture-lessons and tool-card; consolidated by weekly-tuneup.
     Edit one entry at a time: increase a count, add an evidence line, change a status.
     Never rewrite or reorder this file. Keep active entries under 100 lines in total. -->

A lesson is a candidate until the weekly tune-up tests it and the owner approves it. Nothing
here is a rule yet, so it isn't followed as one.

## Entry format
```
### L-001
- lesson: When [situation], do [checkable action], because [reason].
- target: [AGENTS.md rule / skill Gotchas: skill-name / tool card: family / knowledge: file]
- source: [owner correction YYYY-MM-DD / task failure / tool error / checked success / outside content (never promoted)]
- proof: [what showed the fix worked: a passing check, the owner's words, tool output]
- worked_run: [for a failure: the run or job folder where the fix worked]
- count: 1
- evidence:
  - YYYY-MM-DD: [run-log line, job folder, checks.md item, or the owner's words]
- first_seen: YYYY-MM-DD
- last_seen: YYYY-MM-DD
- status: candidate
```

Status values: `candidate` (waiting), `proposed` (in a weekly proposal), `promoted` (applied
after approval; say where), `archived` (count 1, older than 30 days), `merged into L-0xx`,
`rejected` (owner said no; say why).

Ids are never reused. Search this file for a matching situation before adding a new entry.

## Entries
