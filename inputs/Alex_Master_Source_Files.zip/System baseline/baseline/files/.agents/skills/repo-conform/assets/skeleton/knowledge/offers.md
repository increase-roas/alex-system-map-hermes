---
topic: current offers and prices
updated: YYYY-MM-DD
source: [owner, in chat YYYY-MM-DD, or sources/...]
owner: [name]
---

# Offers

The only place prices live. Claude quotes a price from this table and names this file. If a
product or date isn't here, Claude asks instead of guessing, because a wrong price in an ad
or email can't be taken back.

## Current offers
| Product | Price | Regular-price proof | Valid from | Valid to | Source |
|---|---|---|---|---|---|
| [product name] | [$0.00] | [where the regular price is shown, for "was/now" claims] | [YYYY-MM-DD] | [YYYY-MM-DD or "ongoing"] | [sources/... or URL] |

## Rules for this table
- Update a row in place when a price changes, and change `updated:` above.
- Move expired offers to the table below rather than deleting them, so old campaigns can be
  checked later.
- "Was" or "regular" prices need proof in the regular-price column. Without it, don't claim a
  discount.

## Expired offers
| Product | Price | Valid from | Valid to | Source |
|---|---|---|---|---|
