# Start here: 30-minute setup

This folder gives Claude five things: a map (`AGENTS.md`), manuals (skills, tool cards,
`knowledge/`), locks (app settings), ledgers (status and logs) and a weekly learning loop.
Set it up once per business or client. Agents don't need anything in `setup/` after that.

## Before you start
- The Claude desktop app on macOS or Windows. Scheduled tasks need a paid plan.
- Skills work on every plan but need code execution turned on.
- This folder, unzipped. Menu names below are as documented on 2026-09-29; the app changes
  often, so look for the nearest match.

## Steps
1. **Place and name the folder (2 min).** Rename `claude-project` to the business name in
   lowercase with hyphens, like acme-roofing. Avoid spaces anywhere in the folder's path;
   paths with spaces have broken tools in reported bugs. Put it somewhere with version
   history (see "Backups and secrets" in `setup/02-app-settings.md`).
2. **Fill in the blanks (8 min).** Replace every [bracketed placeholder] in:
   - `AGENTS.md`: "What this project is", the owner, and one routing row per connected app.
   - `knowledge/business.md` and `knowledge/offers.md`.
   - `STATUS.md`: the focus for this week.

   Write these yourself. In tests on coding agents, human-written instruction files helped
   a little, while AI-written ones added about 20% cost without helping.
3. **Create the project (2 min).** In the Claude app, create a Project with "Use an existing
   folder" and pick this folder. Connect no other folder. A project made from a local
   folder stays on this computer.
4. **Paste the pointer (1 min).** Copy the text of `setup/01-project-instructions.txt` into
   the project's Instructions. The rules live in `AGENTS.md`; `CLAUDE.md` is one line,
   `@AGENTS.md`, which pulls them in for Claude. Codex and Cursor read `AGENTS.md` directly.
   Official docs don't say whether the app reads folder instructions, so this pointer is the backup.
5. **Upload the skills (4 min).** Follow `.agents/skills/README.md`: turn on code execution,
   build and upload the zips in `system/skill-zips/`, and turn on skill-creator. Claude Code,
   Codex and Cursor need no upload; they read the skill folders directly.
6. **Set the locks (5 min).** Work through `setup/02-app-settings.md`. These settings are
   what actually stop a send, a spend or a delete; text only guides.
7. **Card your tools (later, about 5 min per tool).** For each connected app, ask Claude:
   "Run tool-card for [connector name]." Cards for Exa, web search and the browser are
   already filled in `tools/`; app cards every AI reads are in `~/.agents/tools/cards/`.
8. **Test (5 min).** Open a new conversation in the project and run the six prompts in
   `setup/03-first-run-test.md`.
9. **First snapshot (1 min).** If the tests pass, ask: "Snapshot the control files into
   system/snapshots/, mark it known-good, and log it in system/CHANGELOG.md." This gives
   you a clean state to restore.
10. **Schedule the weekly tune-up (2 min).** See "Weekly tune-up" in `setup/02-app-settings.md`.

## Day to day
- Drop files in `inbox/` and say "file these". Claude runs `intake-triage`.
- Start a job with one sentence: "New job: [goal] for [audience], due [date]." Claude copies
  `work/_template/` and fills in the brief. Missing facts come back to you as questions.
- Approve sends, spends and deletes in chat only. Claude asks every time.
- Once a week, read the new file in `system/proposals/` and approve changes item by item.
- When the first message is a task, Claude reportedly sometimes skips its "read first"
  files. If it didn't mention `STATUS.md`, say "Read AGENTS.md and STATUS.md first."

## When something goes wrong
- Claude ignores the rules: see "If a test fails" in `setup/03-first-run-test.md`.
- A change made things worse: restore from a snapshot (`system/snapshots/README.md`).
- A tool misbehaves: "Run tool-card for [tool]", then check `tools/_incidents.md`.
