# deliverables

Approved finals only. A file lands here after two things: `verify-before-done` passed (its
`work/<job>/checks.md` exists) and the owner approved it in chat. Drafts stay in
`work/`, so nobody mistakes a draft for the version that went out.

## Naming
`deliverables/YYYY-MM-DD_name_v01.ext`, lowercase, hyphens inside the name, 50 characters
or fewer. Examples: 2026-09-29_fall-promo-email_v01.md, 2026-10-02_acme-proposal_v02.pdf.

## Rules
- A new version gets a new number (`_v02`). Don't overwrite an approved file; it is the
  record of what went out.
- Superseded versions move to `_archive/`, so only current finals sit here. Old copies next
  to new ones get quoted by mistake.
- Log each new deliverable in `system/run-log.md` and in "Recently done" in `STATUS.md`.

This README stays so the folder survives zipping.
