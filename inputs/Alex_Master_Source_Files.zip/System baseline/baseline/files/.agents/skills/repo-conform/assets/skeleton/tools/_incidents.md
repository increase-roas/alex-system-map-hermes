# Tool incidents

<!-- Append only, newest at the bottom. One row per incident. tool-card and any task that
     hits a tool failure add a row here. weekly-tuneup looks for incidents that repeat. -->

Log a row when a tool errors, returns junk, picks the wrong target, costs more than expected,
or when Claude picked the wrong tool. A fix that recurs moves into the tool's card, then
into a routing row in `AGENTS.md` (with approval), then into an app setting.

| Date | Tool (full name) | What failed | Why | Fix | Card updated? |
|---|---|---|---|---|---|
