# snapshots

Dated copies of the control files, made before any change, so any change can be undone
without git.

## When a snapshot is made
- By `weekly-tuneup`, at the start of every run.
- Before applying any approved change to a control file (rule 5 in `AGENTS.md`).
- By hand after setup passes its tests (step 9 in `setup/00-start-here.md`).

## What goes in
`AGENTS.md`, `.agents/skills/` (project skills), `tools/README.md`, `knowledge/`,
`system/lessons.md`, `system/rules-ledger.csv`. Keep their paths inside the snapshot, so a
file restores to the same place.

## Naming
`system/snapshots/YYYY-MM-DD_HHMM/`, using the local time, like 2026-09-29_1430.
- Mark a snapshot known-good after golden tasks pass on it: add a file
  `system/snapshots/YYYY-MM-DD_HHMM/known-good.md` with the date and the tasks that passed,
  and note it in `system/CHANGELOG.md`. Don't rename the folder, because CHANGELOG restore
  paths point to it.

## How many to keep
- The last 10, plus every known-good one.
- `weekly-tuneup` lists older snapshots for the owner. Pruning is the owner's job; Claude
  never deletes snapshots, because a deleted snapshot can't restore anything.

## Restore
1. Find the change in `system/CHANGELOG.md`; its "restore from" column names the snapshot.
2. Copy the file from the snapshot back into place. Copy, don't move, so the snapshot stays.
3. Add a CHANGELOG line: "rollback of [date] change", and why.
4. Run `setup/03-first-run-test.md` in a fresh conversation.
5. A restored skill needs re-zipping and re-uploading if the Claude app uses it (`.agents/skills/README.md`).

Snapshots are the first layer of history. The computer's own version history is the second
(`setup/02-app-settings.md`).
