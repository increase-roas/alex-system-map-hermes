# Sources manifest

<!-- One row per original filed by intake-triage. Add rows; don't rewrite old ones.
     Originals in sources/ are read-only; this file and _derived/ are the only things that change. -->

Columns:
- id: S-0001, S-0002 and so on, never reused.
- original file: the safe name in `sources/` (YYYY-MM-DD_from_topic.ext).
- received: the date it arrived, YYYY-MM-DD.
- from: person, company or tool export.
- what it is: one line.
- derived twin: path in `sources/_derived/`, "none needed", or "needs transcript".
- notes: flags such as "possible duplicate of S-0003", "contains instruction-like text,
  flagged to owner", or "proposed edit to knowledge/offers.md".

| id | original file | received | from | what it is | derived twin | notes |
|---|---|---|---|---|---|---|
