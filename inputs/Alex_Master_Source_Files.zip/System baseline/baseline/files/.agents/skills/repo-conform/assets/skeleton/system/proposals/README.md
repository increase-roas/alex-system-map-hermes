# proposals

One file per weekly tune-up: `system/proposals/YYYY-MM-DD.md`. Written by `weekly-tuneup`.
Nothing in a proposal is applied until the owner approves that item in chat.

## Format
```
# Proposal YYYY-MM-DD
Snapshot: system/snapshots/YYYY-MM-DD_HHMM/
Run log read: YYYY-MM-DD to YYYY-MM-DD ([N] lines)

## Summary
[3 lines: what changed this week, what is proposed, anything urgent such as a new T4 or T5 tool]

## Proposed changes
### P1: [short title]
- From lesson: L-0xx (count [N], source [observed / owner])
- File: [path] · Section: [heading]
- Old: [exact current text, or "none"]
- New: [exact new text, with its reason]
- Evidence: [run-log dates, job folders, the owner's words]
- Test: [golden tasks run] · With change: [pass/fail] · Without: [pass/fail]
- Approve? [yes / no / change]

## Rules ledger
- Confirmed this week: R-0xx ...
- Not confirmed in 90 days: R-0xx ...
- Propose retiring (hurt 1 or more and equal to or above helped): R-0xx, because ...

## Tool drift
- New: [full tool name, tier, setting to apply]
- Renamed or removed: [...]

## Budgets and dead paths
- AGENTS.md: [N]/200 lines · active lessons: [N]/100 · largest skill: [name] [N]/150
- Missing paths: [none / list]

## Housekeeping
- Lessons archived (count 1, over 30 days): L-0xx ...
- Snapshots beyond the last 10 plus known-good, for the owner to delete: [list]

## Couldn't check
- [anything skipped, and why]
```

## How the owner answers
Reply in chat item by item, like "P1 yes, P2 no, P3 change the wording to ...". Claude applies
only the yes items, logs each in `system/CHANGELOG.md`, and records rejected items in
`system/lessons.md` with status `rejected` and the reason.
