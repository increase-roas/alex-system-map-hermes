# sources/_derived

Readable copies of the originals in `sources/`. Claude reads these instead of the originals,
because markdown and plain text are cheaper and more reliable to read than PDFs, Office
files, audio or large images.

## What goes here
| Original | Twin |
|---|---|
| PDF, Word, PowerPoint, Excel | markdown (`.md`), or CSV for a table or sheet |
| Audio or video | transcript (same name, ending .transcript.md) if a transcription tool exists; otherwise the manifest says "needs transcript" |
| Image wider or taller than 2000 px | review copy at 2000 px or less on the long edge |

## Naming
Same name as the original, with a new ending. Examples:
- 2026-09-12_acme_discovery-call.mp3 becomes 2026-09-12_acme_discovery-call.transcript.md
- 2026-09-14_acme_price-list.pdf becomes 2026-09-14_acme_price-list.md
- 2026-09-15_acme_storefront.jpg becomes 2026-09-15_acme_storefront_2000px.jpg

## Each markdown twin starts with
```
---
source: sources/[original file name]
derived_with: [tool or method used]
derived: YYYY-MM-DD
checked: [yes, or what was not checked, such as tables or footnotes]
---
```

Conversions can drop tables, footnotes and scanned text, so spot-check them. If a twin is
wrong, make a new one; the original stays untouched. Every twin is listed in
`sources/_manifest.md`.
