# knowledge

Lasting facts about the business: offers, prices, audience, brand, proof, processes. Claude
takes facts from here, from `sources/`, or from a cited URL, and nowhere else (rule 4 in
`AGENTS.md`).

## How knowledge files are written
- One topic per file, named `knowledge/<topic>.md` in lowercase with hyphens, such as
  offers, audience or brand-voice. One place per fact means one place to update; copies
  drift apart.
- Update in place. These files describe what is true now; history goes in `system/run-log.md`.
- Keep each file short enough to read in one go. Split a file when it covers two topics.
- Prices, dates and claims carry their source, so anyone can check them.
- Keep volatile facts (prices, stock, staff) here, not in `AGENTS.md`.

## Frontmatter on every file
```
---
topic: [what this file covers]
updated: YYYY-MM-DD
source: [where the facts came from: sources/..., a URL, or "owner, in chat YYYY-MM-DD"]
owner: [who confirms these facts]
---
```

## Who changes these files
- The owner, any time.
- Claude, when the owner asks for a specific change in chat.
- When `intake-triage` or research finds a fact that would change a file here, Claude
  proposes the edit to the owner instead of applying it quietly. A wrong price here would
  spread into every deliverable.

## Starter files
- `knowledge/business.md`: who we are, audience, voice, proof, words to avoid.
- `knowledge/offers.md`: products, prices and the dates they are valid.
