# _archive

Finished, superseded or unused files move here. Nothing is deleted by Claude; deleting is the
owner's job, and the app asks for approval before any permanent delete.

## Why archive instead of delete
- A move can be undone. A delete often can't.
- Old drafts left next to current files get quoted by mistake. Moving them here keeps them
  out of the way while keeping the record.

## How to archive
- Keep the original folder structure under `_archive/`, so you can tell where a file came
  from. A finished job folder, for example, moves to `_archive/work/YYYY-MM-DD_job-name/`.
- Add one line to `system/run-log.md`: date | archived | what and why.
- When asked to "clean up", Claude shows the list of files it plans to move, moves them after
  a yes, and reports what moved. It deletes nothing.

Claude doesn't read `_archive/` for current work unless the owner asks, because archived
files are out of date by definition.
