# Checks: [job name]

<!-- Filled by verify-before-done. Size the checks to the stakes in brief.md:
     a short internal note needs a few lines, client-facing work needs the full set. -->

Checked: YYYY-MM-DD
Checked by: [this session / fresh subagent verifier]
Stakes: [low / normal / high, copied from brief.md]

## Checks
| # | What was checked | How | Result |
|---|---|---|---|
| 1 | [each "done means" line in brief.md] | [re-read against the brief] | [pass / fail / fixed] |
| 2 | [numbers] | [recomputed from sources/...] | [pass / fail / fixed] |
| 3 | [links and citations] | [opened each URL] | [pass / fail / fixed] |
| 4 | [names, prices, dates, claims] | [matched to knowledge/ or sources/] | [pass / fail / fixed] |
| 5 | [records written to a tool] | [read back after writing] | [pass / fail / n/a] |

## Negative check
Something that should fail if the work were wrong.
- [like "searched the draft for any price not in knowledge/offers.md: none found"]

## Couldn't check
- [what, and why: no access, no source, needs the owner]

## Verdict
[ready for owner review / ready except the items above / not ready]
