---
route: Composio toolkit exa; one way in for every AI. Claude's Exa connector and local exa servers are not routes
name: exa
namespace_prefix: EXA_ (Composio tool slugs)
source: Composio
account: [whose Exa API key in Composio, by its login word id from `composio` connections]; the key itself stays out of this folder
jobs: J1
worst_tier: T1 (agent runs, research and Websets cost money)
approval: search, answer and contents run freely; agent runs and research follow the project's Spend approval line
cost: search $7 per 1,000; contents $1 per 1,000 pages; Exa Agent $0.012 to $1.00 per run (see below)
rate_limits: unknown
tool_count: 20 (full list from Composio v3.1 API, 2026-10-01)
last_verified: 2026-10-01 (EXA_SEARCH answered through Composio)
verified_by: Claude Code, connector consolidation (re-run tool-card in a new project)
vendor_docs: github.com/exa-labs/exa-mcp-server (skills "search" and "exa-agent"), exa.ai/pricing, checked 2026-09-29
---

# Exa

## Purpose
Meaning-based web search and fetching, plus an agent that builds lists and tables from the web.

## Use when / don't use when
- Use when: any web search or page read (shared rule: web search is Exa): current facts and
  news, companies, people or pages "like X", niche topics, building a list.
- Don't use when: product or API docs (the Composio docs readers first; an Exa fetch only if no
  reader covers it); a login page (`tools/browser-and-computer.md`). If Exa fails, use
  built-in search (`tools/web-search.md`).

## Key tools
| Full tool name | What it does | Tier | App setting |
|---|---|---|---|
| `EXA_SEARCH` | semantic search with optional text, highlights or summary per result | T1 | runs freely |
| `EXA_GET_CONTENTS_ACTION` | reads the content of known URLs | T1 | runs freely |
| `EXA_ANSWER` | cited answer to a clear question | T1 | runs freely |
| `EXA_CREATE_AGENT_RUN` / `EXA_GET_AGENT_RUN` | Exa Agent: multi-step research or enrichment into rows (same agent as the old `agent_run`) | T1, paid | Spend approval line |
| `EXA_CREATE_RESEARCH` / `EXA_GET_RESEARCH` | async research report with sources | T1, paid | Spend approval line |
| `EXA_CREATE_WEBSET` and the Webset tools | saved, refreshable lists with enrichment and monitors | T1, paid | Spend approval line |

Why Composio: it has everything Claude's 3-tool Exa connector had, plus research and Websets, and every AI reaches it.

## Costs (Exa pricing page, Sept 2026)
- Search $7 per 1,000 requests. Contents $1 per 1,000 pages. Answer $5 per 1,000.
- Exa Agent per run: minimal $0.012, low $0.025, medium $0.10, high $0.50, xhigh $1.00.
  `auto` is metered with a $5 default cap; beta `max` has a $20 cap.
- New accounts get $20 in credits, plus $10 a month on the free tier.
- Claude's permissions have no spend cap, so per-call approval is the gate. Whether connector
  calls draw on your own Exa credits wasn't verified.

## Workflow order
1. Search with a descriptive sentence, not keywords: describe the page you want to find.
   Add a category (company, people, news, publication, personal site) when it fits.
2. Try 2 to 3 different angles, not synonyms of the same query.
3. Fetch the best hits with `EXA_GET_CONTENTS_ACTION` and verify them; results are similarity.
4. For a list or table: `EXA_CREATE_AGENT_RUN` with an output schema, then poll `EXA_GET_AGENT_RUN`. Leave effort out
   (it defaults to low) unless the owner approves more depth.
5. Hundreds of known rows to enrich: a script against the Exa API, not repeated calls.
6. Bulk searching runs in `fan-out` subagents (3 to 5 searches each), saved to `work/<job>/notes/`.

## Good example calls
- Search: "Hot tub dealers in Texas whose websites offer live chat", category company.
- Agent: "Find 20 roofing contractors in Ohio with website, phone and review count",
  output schema {name, website, phone, review_count, source_url}, effort left at default.

## Quirks
- Exa is embedding-based. Boolean operators and keyword lists work poorly.
- Don't quietly swap agent-shaped work (list building) to plain web search; say so if you do.
- Call agent results "best-effort discovery" unless coverage has been checked.
- Old notes may name the removed Exa connector tools (`web_search_exa`, `web_fetch_exa`,
  `agent_run` and older names). Use `EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION` and `EXA_CREATE_AGENT_RUN`.

## Failure and fix
| Symptom | Cause | Fix |
|---|---|---|
| `EXA_GET_CONTENTS_ACTION` fails on a page | blocked or dynamic page | use built-in web fetch, then the browser |
| Results look generic | keyword-style query | rewrite as a sentence describing the target page |
| Exa tools missing | Composio exa login not active | `composio link exa`, or tell the owner |

## Changelog
- 2026-09-29: card created from blueprint research.
- 2026-10-01: route moved to Composio exa (20 tools, includes the Exa Agent); local and connector copies removed.
- 2026-10-01: first choice for every web search and page read (shared rule); docs go to the Composio docs readers.
