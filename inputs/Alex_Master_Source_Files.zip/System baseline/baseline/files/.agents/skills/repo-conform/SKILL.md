---
name: repo-conform
description: Use when Alex asks to audit, fix or speed up a project folder, or its AI is slow or acts unlike his Director chat. Audits files, settings and recent chats, fixes what it can, then verifies.
metadata:
  version: "2.3"
  updated: "2026-10-02"
---

# repo-conform

Brings a project folder to the blueprint in `assets/skeleton/`, finds why its AI is slow or acts unlike a
good chat (one that answers first in plain words, works in parallel, checks the live thing and carries the
job to done), and leaves proof that it worked:
snapshot → audit → auto-fix → judgment fixes → verify → report. You do the fixes yourself;
the owner only gets the few steps that need their hands in an app.

Paths starting with `scripts/`, `assets/` or `references/` are inside this skill's folder.
`<repo>` is the project folder. The spec it implements: `references/checks.md` (top).

Each check ID (M, K, C, L, T, B, P, X, D, F, W, SP) and the failure it prevents: `references/checks.md`;
the speed checks: `references/speed-checks.md`.

## 0. Before touching anything
1. Confirm `<repo>` with the owner if more than one folder could be meant. If it is a coding
   repo rather than a business project, confirm the blueprint fits before going on.
2. If `<repo>` is a git repo, commit a checkpoint. The scripts never delete, but a checkpoint
   makes review easy.

## 1. Audit (read-only)
`python3 scripts/audit.py <repo> --out <repo>/system/YYYY-MM-DD_audit.md`
(create `<repo>/system/` first if missing). Any **X1 secret**: stop and tell the owner. Don't
move, copy or print it. The audit includes the speed pass (SP: AI files, settings, automations and
the last 2 days of chats, read-only); `scripts/speed.py <repo> --out <repo>/system/YYYY-MM-DD_speed.md`
saves its evidence.

## 2. Auto-fix
`python3 scripts/audit.py <repo> --fix` (`--only SP --fix` for just the speed fixes). It snapshots every
control file to `system/snapshots/<stamp>_pre-conform/` first, applies every finding marked Auto (what each
does: `references/checks.md`), repeats until none is left (one fix can expose the next), logs every change in
`system/CHANGELOG.md` and `system/repo-conform/<stamp>_fixes.json`, and prints what remains.

Then `python3 scripts/audit.py <repo> --scaffold` to create missing skeleton files. It never
overwrites, and it refuses to create AGENTS.md while CLAUDE.md still holds the rules.

## 3. Judgment fixes
Work what's left, Critical → High → Medium, using `references/fix-recipes.md` (one recipe per
check ID, plus the J-findings the script can't see). Ground rules:
- Move, never delete: `_archive/YYYY-MM-DD_repo-conform/` inside the repo, `~/Backups/` outside.
- Small edits, one rule per line. Never rewrite a whole file from memory; carry each real rule
  or fact to its one home: every-task rule → AGENTS.md, current state → STATUS.md, history →
  `system/run-log.md`, procedure → a skill, tool detail → `tools/<family>.md`, fact → `knowledge/`.
- A rule you remove on purpose (it conflicted with the global file, or was stale) goes in
  `system/repo-conform/allow.txt` as `rule text | reason`. Verify fails on any rule that vanished
  without a line there.
- SP findings: fix the project's own AI files with the SP recipes; the owner's run is his ask. Global
  files, a supervisor's skill or ledger, automations and per-chat settings get a proposal in the report
  (the exact line or click, the evidence, the minutes lost), never an edit.
- Owner-only facts (what the project is, names, prices) stay placeholders; list them.
- Log each change in `system/CHANGELOG.md`.

## 4. Verify (the gate)
1. `python3 scripts/verify.py <repo> --out <repo>/system/YYYY-MM-DD_verify.md`
   V1 no rule lost · V2 links resolve · V3 every skill visible to Codex, Cursor and Claude
   Code · V4 budgets · V5 zero Critical and High.
2. When subagents are available, give a fresh read-only one the before audit, the fixes log, the
   verify report and the snapshot path. Ask it to open AGENTS.md, CLAUDE.md, STATUS.md and three
   moved files and confirm each fix, rather than grading your own work.
3. Not passed: fix and re-run. Stop after 3 rounds and list what remains.

## 5. Report (five lines or fewer, plus owner steps)
Findings before → after, files moved or archived, what verify proved, the biggest SP time sinks in
minutes with their proposals, and only the steps that need the owner: renaming the Codex project,
recreating a task from a thread in the real folder, filling placeholders, uploading zips for the
Claude app (`audit.py <repo> --zips`).

## Options
- `--home DIR` (or `REPO_CONFORM_HOME`) points the scripts at a test home; use it with a copy
  of the repo to dry-run.
- For a large repo, `/ce:plan` can turn the audit into a task list first. Optional.
- `--only SP`, `--no-speed`, `--days N` (audit.py); `--director DIR` (speed.py) for a Director home elsewhere.

## Gotchas
- The map flip is the point: Claude Code reads AGENTS.md on its own only when no CLAUDE.md exists
  (v2.1.277+), and a "read AGENTS.md" sentence loads nothing. `@AGENTS.md` imports it once.
- `skills/` is invisible to every agent. Codex and Cursor read `.agents/skills`; Claude Code reads
  `.claude/skills` and ignores `.agents/`. One real folder plus one link, never two copies.
- Codex lists two skills with the same name side by side instead of merging them, so a project
  copy of a global skill makes picks worse even when identical.
- Don't edit `~/.codex/.codex-global-state.json` or Codex's sqlite: the app owns them and
  rewrites them while open. Project names and thread folders are owner steps in the app.
- Codex keeps each chat's effort and reasoning summary; a config change only seeds new chats (SP10).
- Keep the old link (like a `Documents/Codex/.../outputs/<project>` alias) until every thread and
  task using it is retired; deleting it breaks them.
- Model and delegation rules live in the global files (`~/.codex/AGENTS.md`, `~/.claude/CLAUDE.md`).
  A project copy is a future contradiction even when it matches today.
