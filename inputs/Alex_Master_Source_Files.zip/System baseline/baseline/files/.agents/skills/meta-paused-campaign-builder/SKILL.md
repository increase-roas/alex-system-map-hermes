---
name: meta-paused-campaign-builder
description: Use when staging, rebuilding, cloning or validating a Meta Ads campaign with several ad sets or reusable creatives through Composio metaads, kept unpublished (PAUSED) and duplicate-safe.
---

# Building Paused Meta Campaigns

## Overview

Build from one validated manifest. Reconcile exact names, prove one canary, reuse creative IDs, and finish with consolidated readback.

**REQUIRED SUB-SKILL:** `meta-ads` for the Composio `metaads` route, account scoping and safety.

## When to Use

Use for standard or DCO builds, cross-account recreations, multi-audience structures, creative batches, or paused QA. Not for activation, spend changes, or Instant Forms.

## Contract

1. Copy `templates/campaign-manifest.example.json` into the workspace and add verified IDs and asset paths.
2. Run `python3 scripts/validate_manifest.py MANIFEST.json`. Stop unless it returns `VALID` and the approved mutation/invocation caps (`max_cli_invocations` now caps Composio tool calls; the field name stays for the validator).
3. Read campaign/ad-set and ad/creative inventories (`METAADS_LIST_CAMPAIGNS`, `METAADS_READ_ADSETS`, `METAADS_LIST_ADS`, `METAADS_LIST_AD_CREATIVES`). Perform **exact-name reconciliation**; record matches and never duplicate blindly.
4. Freeze the execution ledger: object name, intended operation, expected ID source, mutation number, and stop condition.
5. Canary in this order: creative → readback → ad set → readback → ad → readback. Stop on the first failed tool call or incorrect readback.
6. Complete remaining objects with the verified call shape. Upload each asset once (`METAADS_UPLOAD_AD_IMAGE`, `METAADS_CREATE_AD_VIDEO`) and reuse its **creative ID**.
7. Verify all layers together (`METAADS_GET_OBJECT` per ID): names, PAUSED status, budget mode, targeting, placements, Page, pixel/event, URLs, CTA, and URL tags.
8. Write one receipt with IDs, mutation count, tool-call count, failures, remaining work, and activation boundary.

## Safety Invariants

- Every created campaign, ad set, and ad is explicitly `PAUSED`.
- Never use `ACTIVE`, publish, review/publish, archive, or delete in this workflow.
- Never retry an ambiguous write. Reconcile by exact name and ID first.
- Stop on the first failed tool call; do not continue a partial batch.
- If Composio holds a create tool for approval or marks it restricted on this surface, stop and report. Never route around it through `composio proxy` or another Meta route.
- DCO is chosen at ad-set creation and permits one ad template per ad set. Standard mode uses reusable single-asset creatives.
- Campaign budget and ad-set budgets are mutually exclusive. Budgets are cents.
- The manifest may contain IDs and paths, never tokens, secrets, or credentials.

## Tools

| Step | Composio `metaads` tool |
|---|---|
| Validate the manifest | `python3 ~/.agents/skills/meta-paused-campaign-builder/scripts/validate_manifest.py manifest.json` |
| Inventories | `METAADS_LIST_CAMPAIGNS`, `METAADS_READ_ADSETS`, `METAADS_LIST_ADS`, `METAADS_LIST_AD_CREATIVES` |
| Readback of one object | `METAADS_GET_OBJECT`, `METAADS_GET_AD_CREATIVE` |
| Assets | `METAADS_UPLOAD_AD_IMAGE`, `METAADS_CREATE_AD_VIDEO` |
| Creates (status `PAUSED`) | `METAADS_CREATE_AD_CREATIVE`, `METAADS_CREATE_CAMPAIGN`, `METAADS_CREATE_AD_SET`, `METAADS_CREATE_AD` |

Read each create tool's schema (`COMPOSIO_GET_TOOL_SCHEMAS`, or `composio execute <SLUG> --get-schema`) immediately before composing the call; the schema is the syntax authority.

## Common Mistakes

| Mistake | Correction |
|---|---|
| Rebuilding every audience from scratch | Prove one canary, then reuse the call shape and creative IDs. |
| Adding multiple ads to DCO | Use one DCO ad, or choose standard mode before ad-set creation. |
| Retrying after a timeout | Read by exact name and reconcile the returned ID. |
| Calling configured objects complete | Require authoritative paused readback for every layer. |
