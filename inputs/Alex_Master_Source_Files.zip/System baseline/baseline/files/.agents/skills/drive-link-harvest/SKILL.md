---
name: drive-link-harvest
description: Resolve shortener links and download Google Drive files and folders that the Drive API cannot see, including link-shared folders and files behind the virus-scan interstitial. Use when harvesting course resources, kits, or any batch of links from a document or scraped content.
---

# Harvesting links and Drive assets

## 1. Shortener links are often JS redirects

Services like `ity.so` return **HTTP 200 with the destination in JavaScript**,
not a 301. `curl -L` follows nothing and reports the shortener's own URL.

```bash
curl -sS "$URL" | grep -oE "window\.location\.href = '[^']+'" | head -1 | sed "s/.*= '//; s/'$//"
```

Resolve all of them before downloading anything, then sort by destination host.

## 2. Sort destinations before acting

A batch of "resource links" is usually four different things:

| Kind | What to do |
|---|---|
| GitHub releases / direct files | Download. Check the whole release via the API — there are often files not linked anywhere. |
| Google Drive / Docs | Download (see below) |
| **Affiliate / referral links** | **Not assets.** `fp_ref=`, `REFERRALCODE=`, `ref=`, `am_id=` in the URL. Report, do not download. |
| **Email opt-in funnels** | **Do not submit.** Getting the file means putting the user's email into someone's CRM. That is the user's decision. |

Check the GitHub release API for extra assets:
```bash
curl -sS "https://api.github.com/repos/OWNER/REPO/releases"
```

## 3. Google Drive files

Direct download:
```bash
curl -sSL -o out.bin "https://drive.google.com/uc?export=download&id=$ID"
```

**Virus-scan interstitial:** files over ~25 MB return a small HTML page titled
"Google Drive - Virus scan warning" instead of the file. Check the result — if
it is HTML and tiny, retry with a cookie jar and the confirm endpoint:

```bash
curl -sSL -c /tmp/ck -o /dev/null "https://drive.google.com/uc?export=download&id=$ID"
curl -sSL -b /tmp/ck -o out.bin \
  "https://drive.usercontent.google.com/download?id=$ID&export=download&confirm=t"
```

Always verify with `file -b` and set the extension from the real type. Names in
links lie.

**Google Slides / Docs export:**
```
https://docs.google.com/presentation/d/$ID/export/pptx
https://docs.google.com/document/d/$ID/export?format=docx
```

## 4. Link-shared FOLDERS — the hard one

Folders shared by link (not "shared with me") are **invisible to the Drive API**.
`search_files` with `parentId = '...'` returns `{}`. Scraping the folder HTML
also fails — Drive renders the file grid client-side, so the HTML contains only
Google's internal config.

**Solution: use a browser that already has the user's Google session.**

1. Navigate the browser tool to `https://drive.google.com/drive/folders/$ID`
2. Wait ~6 seconds for the grid to render
3. Extract file ids from the DOM:

```javascript
(()=>{const ids=new Set();
document.querySelectorAll('[data-id]').forEach(e=>{const v=e.getAttribute('data-id');
  if(v&&/^[A-Za-z0-9_-]{25,}$/.test(v))ids.add(v);});
const names=[...document.querySelectorAll('[data-tooltip],[aria-label]')]
  .map(e=>e.getAttribute('data-tooltip')||e.getAttribute('aria-label'))
  .filter(s=>s&&/\.(pdf|zip|docx?|md|vtt|pptx?)/i.test(s));
return {title:document.title, ids:[...ids], names:[...new Set(names)]};})()
```

4. Feed those ids to the direct-download command above.

**Check the page title first.** If it resolves to a real folder name rather than
a sign-in page, a Google session exists. Do not assume the browser is logged out
— check.

**Some ids are nested folders, not files.** A download returning 0 bytes on
every attempt is usually a subfolder. Navigate to it as a folder and repeat.

## 5. Verify before reporting

Re-check sizes after any large copy. A background `cp` of 150+ MB takes minutes;
reading the size mid-copy and reporting it as final is a real failure mode.
Wait for the process to exit, then measure.
