---
name: javar-website-only-audit-factory
description: Produce a branded Hot Tub Launch or Powersports Launch online-presence audit from one public lead website URL. Use when Javar is asked to audit a hot tub store or powersports dealership, create the client-ready audit PDF, assess website/ads/reviews/tracking/organic presence, or fulfil an audit without requesting GBP, social, business, or research links.
metadata:
  hermes:
    tags: [website-audit, lead-magnet, hot-tub, powersports, pagespeed, pdf]
    category: marketing-operations
---

# Javar Website-Only Audit Factory

## Outcome

Accept **one publicly reachable lead website URL**. Independently identify the business, select the vertical, research only identity-verified public sources, measure the funnel, write the audit, render the branded PDF, visually QA it, and deliver the PDF plus an internal evidence ledger. Do not request any additional prospect inputs.

This skill supports only **Hot Tub Launch** (independent hot tub stores) and **Powersports Launch** (independent powersports dealerships). It must not force either brand on an unsupported vertical.

## Hard Rules

1. Treat the lead website as the only operator input. Do not ask for a Google Business Profile link, Facebook/Instagram links, business name, location, screenshots, credentials, or manual research.
2. Use public discovery to find external profiles, but use an external profile only after the two-match identity test in `references/vertical-routing.md` passes.
3. Every printed metric or factual claim needs an evidence record with its source, time, value, and status. Follow `references/evidence-and-report-standard.md`.
4. If a signal cannot be verified after one allowed retry, omit it and the dependent leak. Continue and complete the audit. Never manufacture a number, a ranking, an ad, an install, a review count, or a spend claim.
5. Retrieve credentials only at runtime through the configured secret mechanism. Never print, save, or include credentials in chat, JSON, evidence, screenshots, or the PDF.
6. Do not send outreach or change CRM records through this skill. The standard deliverable is the audit PDF and internal evidence ledger/run log.

## Capability Check

Before research, confirm the available browser, filesystem, terminal, and PageSpeed capability. Use the agent's own Hermes-managed browser on its Orgo Computer for public web work. Use configured Apify access only when a browser cannot reliably extract a public record. Use configured SpyFu access only as contextual evidence; do not present an estimate as measured fact.

If PageSpeed credentials are unavailable, produce the report without speed/score metrics and omit the speed leak. Do not ask the operator to supply a key in the middle of a lead audit.

## Load Required References

1. Read `references/vertical-routing.md` to select the approved configuration and enforce identity matching.
2. Read `references/website-only-discovery.md` before collecting external evidence.
3. Read `references/evidence-and-report-standard.md` before scoring or writing.
4. Read `templates/leaks_library.md` before selecting leak language.
5. Use `configs/hot-tub-launch.json` or `configs/powersports-launch.json` after routing the vertical.

## End-to-End Procedure

### 1. Open the job

Create one folder per lead, named from the normalized domain. Save all working files there:

```text
<lead-domain>/
  evidence.json
  audit_data.json
  audit_final.json
  run_log.md
  output/
    audit_<business>.pdf
```

Normalize the supplied URL. Open the homepage, contact/about page, inventory/product page, and footer. Extract visible identity signals and select the vertical according to `references/vertical-routing.md`.

- Hot tubs / swim spas / saunas → use `configs/hot-tub-launch.json`.
- ATVs / UTVs / motorcycles / PWC / snowmobiles / powersports inventory → use `configs/powersports-launch.json`.
- Unsupported/ambiguous after website review → do not render. Return the internal exception specified in `vertical-routing.md`.

### 2. Discover and validate public profiles

Follow `references/website-only-discovery.md`. Start with on-site social/GBP links. Otherwise, search using established business identity. Validate GBP, Instagram, Facebook, and Meta Ad Library identity before using them. Record unsupported, unavailable, and ambiguous sources as omitted in `evidence.json`; do not treat absence of a discoverable profile as a reason to ask the operator for it.

### 3. Measure the website and market

Collect only evidence that changes the report.

| Area | Required check |
|---|---|
| Performance | Call Google PageSpeed Insights for mobile and desktop. Record phone performance score, desktop performance score, mobile interactive/load metric, and SEO score when available. |
| Tracking + stack | Run `python3 <skill-root>/scripts/detect_stack.py <lead-url> --page <representative-page> --out <lead-folder>/stack.json` and copy its `evidence_records` into `evidence.json`. It reports GTM, GA4 (installed and whether it fires), Facebook pixel, heatmaps, Google Ads tag, platform (Astro, WordPress, Wix, Shopify, GoHighLevel, dealer platforms), chat widget, forms and linked phones. Use its result instead of reading page source by hand. |
| Public signals | Run `python3 <skill-root>/scripts/public_signals.py --stack <lead-folder>/stack.json --name "<business name>" --city "<City, ST>" --out <lead-folder>/signals.json` and copy its `evidence_records` into `evidence.json`. It returns the identity-verified Google Business Profile (rating, review count; two-match test applied), active Meta ads tied to the site's Facebook page, the Google ads count for the domain, and SpyFu estimated search clicks and Google Ads spend (estimates; never print as actual). Use manual browser research only for items it returns as `omitted`. |
| Conversion | Record distinct visible/header `tel:` numbers, primary CTAs, competing CTA paths, mobile call behavior, and whether a tracking number is verifiable. |
| Trust/proof | Count reviews/testimonials shown on the site. Compare with identity-verified GBP review total/rating. Note real showroom, inventory, product, staff, customer, and trust proof shown or missing. |
| Message | Compare homepage and product/inventory language to the selected vertical's buyer situations. Identify generic/spec-only copy only if the live page supports it. |
| Social/ads | Review verified Instagram/Facebook cadence and proof. Check Meta Ad Library for the verified page. Use SpyFu only to contextualize search visibility or paid-search evidence; never state its estimates as actual spend. `public_signals.py` already pulls the Meta Ad Library, Google ads and SpyFu figures. |

Use browser or HTML-source evidence for the site. Use PageSpeed as the only source of performance scores. Use verified GBP for review/rating claims. Use Meta Ad Library for active Meta-ad claims.

### 4. Build the evidence ledger

Create `evidence.json` before drafting the audit. Include every prospective printed metric and claim, plus every omitted source that materially constrained the audit. Use the ledger format in `references/evidence-and-report-standard.md`.

### 5. Score and write

Apply the two headline grades from the selected config:

- **Ready to Scale**: whether more traffic currently makes or loses money, based on site speed, tracking, conversion route, message, and verified ad setup.
- **Getting Found**: organic discoverability, review base, local visibility evidence, social activity, and technical SEO score.

Scoreboard: add `Google Analytics (GA4)` and `Tag manager (GTM)` rows only when `detect_stack.py` measured them. Ten rows fit the scoreboard page (render-tested); do not exceed ten.

Use only triggered leak pages. Apply trigger thresholds and canonical direction in `references/evidence-and-report-standard.md` and `templates/leaks_library.md`. Write in the direct, specific house voice. Start with earned good news. Do not add a leak merely because the template has space for it.

Build `audit_data.json` to the shape of `schema/audit_data.schema.json`, then merge the chosen brand configuration:

```bash
python3 <skill-root>/scripts/assemble_audit.py \
  <lead-folder>/audit_data.json \
  <skill-root>/configs/<selected-config>.json \
  <lead-folder>/audit_final.json
```

### 6. Validate, render, and QA

Validate before rendering:

```bash
python3 <skill-root>/scripts/validate_audit.py \
  <lead-folder>/audit_final.json \
  --evidence <lead-folder>/evidence.json
```

Correct any validation failure. Then render with the bundled script, supplying an explicit output path:

```bash
python3 <skill-root>/scripts/render_audit.py \
  <lead-folder>/audit_final.json \
  <lead-folder>/output/audit_<business>.pdf
```

Visually inspect the rendered PDF before delivery. Confirm the cover identity and selected brand, both grades, scoreboard values, at least one leak page, page breaks, and absence of overflow, placeholders, secret values, or unsupported claims. If the report needs adjustments, fix it and render again.

### 7. Deliver

Deliver only:

1. The final branded PDF.
2. The internal `evidence.json` and `run_log.md` in the lead job folder.

The run log must state the selected vertical, evidence sources used, sources omitted, headline grades, triggered leaks, final PDF path, and QA result. Do not solicit a review or another link from the operator after a website-only job.

## Dependencies

The renderer requires Python 3, `jinja2`, and `weasyprint`. The validator requires `jsonschema`. `detect_stack.py` and `public_signals.py` use only the Python standard library; `public_signals.py` needs the Firecrawl CLI (logged in) and reads SpyFu through Composio `custom_spyfu` (tool `CUSTOM_SPYFU_GET_LATEST_DOMAIN_STATS`, run by the logged-in `composio` CLI; no SpyFu key or 1Password mount on the machine, and without the CLI the SpyFu step returns `omitted` with the reason); it uses the Firecrawl CLI for the rendered page when installed, and Node + Playwright (`npx -y -p playwright@1`) for the browser network check. Without them it still runs and says which layers it skipped. Install dependencies on Javar's Orgo Computer during one-time environment setup, not per lead:

```bash
pip install weasyprint jinja2 jsonschema
```

## Completion Standard

Mark the job complete only when the evidence ledger validates, the PDF exists, visual QA is complete, and the report contains no unverified quantitative claim. An evidence-limited audit with fewer leak pages is complete. A polished report containing invented evidence is not.
