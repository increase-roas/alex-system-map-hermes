---
name: atlas-drone-style-video
description: Make aerial drone-style video (reveal, orbit, flyover, top-down) through Composio Atlas Cloud. Use for drone shots, aerials, bird's-eye or establishing b-roll of a property, store, yard or landscape.
---

# Drone-style video (Atlas Cloud)

One paid step through Composio toolkit `custom_atlas_cloud`, the Atlas Cloud route for every AI. Nothing here needs a
shell API key or a new account. Slugs are `CUSTOM_ATLAS_CLOUD_` plus the tool name in capitals (`atlas_generate_video` ->
`CUSTOM_ATLAS_CLOUD_ATLAS_GENERATE_VIDEO`); a generate call takes `model`, `params` (the JSON below) and `dry_run`.
CLI: `composio execute <SLUG> -d @args.json`.

## Spend rules (the user is strict about wasted credits)

- Say the price in one line and wait for a yes before the paid call. A friendly tone is not approval.
- Run the call once with `dry_run: true` first. It validates the parameters and costs nothing.
- One generation at a time. No variations or retries without asking.
- Price checked 2026-09-19 (text-to-video re-checked 2026-10-01 through Composio): `google/veo3.1-fast/text-to-video`
  and `google/veo3.1-fast/image-to-video` are $0.08 per second, so 8s = $0.64, 6s = $0.48, 4s = $0.32. Re-check with `atlas_get_model_info` if it has been a while.
- The full `google/veo3.1/...` models exist for higher quality. Their price was not checked; look it up and
  quote it before using them.

## Inputs

| Name | Default | Notes |
|---|---|---|
| `location_or_subject` | none, ask for it | "a backyard hot tub on a deck at dusk", "the storefront and parking lot" |
| `shot_type` | reveal | reveal, orbit, flyover, top-down |
| `style` | golden hour, cinematic, ultra-detailed | "blue hour city lights", "misty morning" |
| `aspect_ratio` | 16:9 | Veo only accepts 16:9 or 9:16. Use 9:16 for Reels ads. |
| `duration` | 8 | 4, 6 or 8 |
| `reference_image` | none | a public https URL of a photo of the real place |

## Build the prompt

Pick the line for `shot_type`, then add the ending.

- **reveal:** `Drone camera starts low, slowly ascends and reveals {{location_or_subject}}, sweeping wide aerial perspective, {{style}}`
- **orbit:** `Drone camera orbits {{location_or_subject}} in a smooth circular arc, 360-degree aerial rotation, {{style}}`
- **flyover:** `Drone camera flies low and fast over {{location_or_subject}}, tracking forward momentum, depth of field, {{style}}`
- **top-down:** `Perfect overhead bird's eye view of {{location_or_subject}}, drone looking straight down, minimal distortion, {{style}}`

Ending for all of them: `DJI-quality drone footage, stabilized gimbal, no shake, cinematic color grade, photorealistic, no text, no watermark`

For architecture say "slow orbit to reveal the full building facade". For landscapes "magic hour lighting" works well.

## Generate

No reference photo, `atlas_generate_video` with model `google/veo3.1-fast/text-to-video`:

```json
{ "prompt": "<built prompt>", "aspect_ratio": "16:9", "duration": 8, "resolution": "720p", "generate_audio": false }
```

With a reference photo: pass its public https URL. `atlas_upload_media` reads files on the Orgo hub that runs this
route, not on this Mac (a Mac path fails with ENOENT, checked 2026-10-01), so a photo that is only on this Mac needs a
public URL first. Then model
`google/veo3.1-fast/image-to-video` with the same params plus `"image": "<that URL>"`. The video starts from
that exact frame, so use it when the shot has to look like the real place.

Set `generate_audio` true only if the user wants wind or ambient sound. For ad b-roll leave it off; the ad has its own audio.

Poll `atlas_get_prediction` until it completes, download the video URL into the project folder with `curl`,
and send the user that one file.

## Be straight about what this is

This is generated footage, not the real location. With text only it invents a place that matches the words.
For a real business, say so before spending: an invented storefront in an ad for a real store can mislead,
and the owner should approve it. A reference photo keeps it closer, but it is still synthetic.
