---
name: create-local-meta-ads
description: Use for Facebook or Instagram ads, Stories/Reels, UGC concepts, creative briefs, image or video prompts, ad copy, offer tests or creative audits for local service businesses and hot tub dealers.
---

# Create Local Meta Ads

Build conversion-focused creative that looks credible in-feed, communicates one offer immediately, and gives a local buyer a concrete next step.

## Load the right references

- Read [references/formats-and-concepts.md](references/formats-and-concepts.md) before choosing formats or art direction.
- Read [references/messaging-playbook.md](references/messaging-playbook.md) before writing hooks, on-image copy, scripts, headlines, or primary text.
- Read [references/review-checklist.md](references/review-checklist.md) before finalizing any deliverable or reviewing an existing ad.

## Build the campaign

1. Extract the known facts: business, offer, service or product, geography, audience, price or financing, proof, deadline, CTA, available assets, placement, and requested quantity.
2. Separate verified facts from assumptions. Never invent prices, discounts, inventory, reviews, savings, guarantees, credentials, customer outcomes, or event details. Mark missing decision-critical facts clearly; omit optional unknowns.
3. Identify the buying mechanism:
   - Local service: urgent problem, trustworthy operator, specific service area, fast estimate or booking.
   - Hot tub dealer: inventory or event, financing/payment accessibility, trust, lifestyle outcome, fast purchase path.
4. Choose one primary promise per ad. Do not stack several competing headlines.
5. Create a test matrix across distinct mechanisms, not cosmetic variations. Default to 3-5 concepts spanning offer, proof, local relevance, problem awareness, and native/organic presentation.
6. For each concept, specify: angle, audience awareness, hook, exact on-image copy, visual composition, asset needs, format, CTA, and why it differs from the other tests.
7. When production is requested, generate the requested asset or a production-ready prompt. Preserve supplied logos, people, products, and layouts exactly when asked; make only the requested edits.
8. Write placement-matched copy. Keep on-image text minimal. Put explanation, proof, and qualification in primary text.
9. Run the full review checklist. Revise before delivery when any blocking item fails.

## Default deliverable

Unless the user requests another structure, return:

- Campaign thesis in one sentence
- Creative test matrix
- Production-ready brief or prompt for each concept
- On-image copy, primary text, headline, and CTA for each concept
- Asset/spec list
- Review findings and any unverified claims that require confirmation

Keep the output easy to copy into image generation, video generation, or Meta Ads Manager.

## Operating rules

- Lead with the outcome or offer, not the company biography.
- Make the ad understandable in roughly two seconds.
- Prefer specificity: service, city/area, real price/payment, real proof, real deadline.
- Use urgency only when a real reason exists.
- Make each concept visually distinct enough to teach something from the test.
- Favor believable native content over excessive polish when the angle calls for UGC, a selfie, a Story, a phone screen, or an intentionally simple flyer.
- Avoid generic stock-photo layouts, tiny copy, decorative clutter, fake interface elements, and ungrounded superlatives.
- Preserve niche language rules in the messaging reference.
