---
name: atlas-talking-baby-video
description: Make a vertical video of a costumed baby who says a scripted line out loud, through Composio Atlas Cloud. Use for a talking baby, baby spokesperson or baby hook clip for an ad or social post.
---

# Talking baby video (Atlas Cloud)

Two paid steps: make the baby photo, then animate it speaking. Everything goes through Composio toolkit
`custom_atlas_cloud`, the Atlas Cloud route for every AI; nothing needs an API key in the shell or a new account.
Slugs are `CUSTOM_ATLAS_CLOUD_` plus the tool name in capitals (`atlas_generate_image` ->
`CUSTOM_ATLAS_CLOUD_ATLAS_GENERATE_IMAGE`); a generate call takes `model`, `params` (the JSON below) and `dry_run`.

## Spend rules (the user is strict about wasted credits)

- Before each paid call, say the price in one line and wait for a yes. A friendly tone is not approval.
- Run every call once with `dry_run: true` first. It validates the parameters and costs nothing.
- One generation at a time. No "a few options", no variations, no retries without asking.
- Prices checked 2026-09-19. Re-check with `atlas_get_model_info` if it has been a while:
  - baby photo, `google/nano-banana/text-to-image`: $0.038 per image
  - speaking clip, `google/veo3.1-fast/image-to-video`: $0.08 per second, so 8s = $0.64
  - one finished 8-second baby clip is about $0.68 total
- `atlas_get_balance` shows what is left. Check it before starting.

## Inputs

| Name | Default | Notes |
|---|---|---|
| `dialogue` | none, ask for it | The exact line the baby says. Never invent it for an ad. |
| `baby_costume` | a pilot uniform | doctor, chef, hot tub salesman in a tiny polo, etc. |
| `baby_description` | a cute 6 month old baby | keep it generic; never base it on a real child or a photo of one |
| `setting` | plain soft background | e.g. "sitting in front of a hot tub showroom" |

**Fit the line to the clip.** Veo clips are 4, 6 or 8 seconds. A baby-paced read is about 2 to 2.5 words per
second, so 8 seconds holds roughly 16 to 20 words. If the line is longer, split it into sentences, make one
8-second clip per part from the SAME photo, and join them locally with ffmpeg. Tell the user the clip count and
total price before starting.

## Step 1: the baby photo

`atlas_generate_image`, model `google/nano-banana/text-to-image`:

```json
{
  "prompt": "{{baby_description}} sitting upright and wearing {{baby_costume}}, {{setting}}. Looking at the camera, mouth closed, friendly expression. High-quality photography, soft natural lighting, detailed fabric textures, shallow depth of field, realistic with a little Pixar-like charm. Vertical framing, head and shoulders in the upper half, no text, no watermark.",
  "aspect_ratio": "9:16"
}
```

Poll `atlas_get_prediction` until it completes, show the user the image, and get a yes before step 2. A bad
photo costs 4 cents to redo; a bad video costs 64.

## Step 2: make it talk

`atlas_generate_video`, model `google/veo3.1-fast/image-to-video`. Audio is OFF by default on this model, so
`generate_audio` must be set or the baby will only move its mouth.

```json
{
  "image": "<image URL from step 1>",
  "prompt": "A viral-style talking baby video. The baby looks into the camera and says in a cute, clear toddler voice: \"{{dialogue}}\" The mouth movements match the words. Natural head movement, blinking, a small smile at the end. Camera locked off. No subtitles, no captions, no on-screen text, no music.",
  "aspect_ratio": "9:16",
  "duration": 8,
  "resolution": "720p",
  "generate_audio": true
}
```

- Put the line inside quotation marks after "says". That is what makes Veo speak it rather than describe it.
- "No subtitles, no captions" matters: Veo likes to burn in misspelled captions.
- Use `duration` 4 or 6 for a short line so there is no dead air.
- The `grok-imagine-video` model the original recipe used has no audio setting on Atlas. Do not use it for speech.

Poll `atlas_get_prediction`. When it completes, download the video URL into the project folder with `curl`
and send the user that one file.

## Check before calling it done

Transcribe the clip locally (whisper-cli, `-ng` inside the sandbox) and compare it with the line. AI speech
often drops or changes a word. Report exactly what it said. Do not regenerate without asking.

Not yet verified on this account: that Veo 3.1 Fast on Atlas returns spoken dialogue when `generate_audio`
is true. The first real run is the test. If the clip comes back silent or mumbling, say so, and the fallback
is a TTS voice (`atlas_list_models` with `kind: "tts"`) plus a lipsync model (Video type), which is a
different, two-call route.

## Using it in an ad

A baby clip is a hook, a few seconds long. Cut it onto the front of the real ad locally with ffmpeg and hard
cut to the real presenter for the offer. Match loudness (-14 LUFS) and keep the rest of the user's file untouched.
