---
name: open-claw-skill-hunter-and-developer
description: >
  Hunts, analyzes, transforms, and bundles OpenClaw skills from the ClawHub registry (52k+ skills) into Manus-compatible skill batches. Use when the user wants to find, convert, develop, or install OpenClaw/ClawHub skills for use in Manus.
---

# OpenClaw skill hunter and developer

Search ClawHub / OpenClaw for skills that match the user's job. Convert hits into Manus-compatible skill folders (`SKILL.md` plus optional `scripts/`, `references/`, `templates/`).

## Rules
- One capability per folder
- Keep SKILL.md under ~800 words
- Review scripts before telling the user they are safe

