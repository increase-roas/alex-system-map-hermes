#!/usr/bin/env python3
"""Tests for ledger_check.py. Usage: python3 test_ledger_check.py [path/to/ledger_check.py]
Runs in a temp folder; never touches a real ledger."""
import os, subprocess, sys, tempfile, time

SCRIPT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "ledger_check.py"))
HAS_LOCK = "take_lock" in open(SCRIPT).read()

A = "## Mission: A\nMISSION_ID: M-1\nNEXT_PLAY_ID: P-1\nSTATUS: ACTIVE\n"
B = "## Mission: B\nMISSION_ID: M-2\nNEXT_PLAY_ID: P-2\nSTATUS: ACTIVE\n"
C = "## Mission: C\nMISSION_ID: M-12\nNEXT_PLAY_ID: P-3\nSTATUS: ACTIVE\n"


def run(d, *args):
    p = subprocess.run([sys.executable, SCRIPT, *args], cwd=d, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr).strip().splitlines()[-1:] or [""]


def case(before, after, *verify):
    """Write `before`, backup, write `after`, verify. Returns True if verify passed."""
    with tempfile.TemporaryDirectory() as d:
        L = os.path.join(d, "L.md")
        open(L, "w").write(before)
        run(d, "backup", L, "--by", "test")
        open(L, "w").write(after)
        code, _ = run(d, "verify", L, *verify)
        return code == 0


EDIT = lambda n: ("--mode", "edit", "--mission", n)
TESTS = [
    # (name, should_pass, before, after, verify-args)
    ("S1 field after STATUS in another mission changed", False,
     A + "PENDING_REVIEW: x\n\n" + B, A + "PENDING_REVIEW: CHANGED\n\n" + B.replace("P-2", "P-9"), EDIT("B")),
    ("S2 mission without STATUS swallows the next; next changed", False,
     "## Mission: A\nMISSION_ID: M-1\n\n" + B, "## Mission: A\nMISSION_ID: M-1 edit\n\n" + B.replace("P-2", "P-9"), EDIT("A")),
    ("S3 bold STATUS in A; B changed while editing A", False,
     A.replace("STATUS:", "- **STATUS:**") + "\n" + B, A.replace("P-1", "P-5").replace("STATUS:", "- **STATUS:**") + "\n" + B.replace("P-2", "P-9"), EDIT("A")),
    ("S4 merge absorbs M-1 but lists only M-12", False,
     A + "\n" + C, C.replace("STATUS", "MERGED_MISSION_IDS: M-12\nSTATUS"), ("--mode", "merge", "--mission", "C", "--absorbed", "1")),
    ("S5 bold MISSION_COMPLETE without NEXT_PLAY_ID NONE", False,
     A, A.replace("STATUS: ACTIVE", "**STATUS:** MISSION_COMPLETE"), EDIT("A")),
    ("S6 duplicate heading appended", False,
     A + "\n" + B, A + "\n" + B + "\n" + B, ("--mode", "append", "--mission", "B")),
    ("S7 unrelated mission deleted", False,
     A + "\n" + B + "\n" + C, A + "\n" + C.replace("P-3", "P-4"), EDIT("C")),
    ("S8 target loses its STATUS line", False,
     A + "\n" + B, A + "\n" + B.replace("STATUS: ACTIVE", "NOTE: gone"), EDIT("B")),
    ("L1 normal edit of B", True,
     A + "\n" + B, A + "\n" + B.replace("P-2", "P-3"), EDIT("B")),
    ("L2 append C after a blank line", True,
     A + "\n" + B, A + "\n" + B + "\n" + C, ("--mode", "append", "--mission", "C")),
    ("L3 correct merge listing M-1", True,
     A + "\n" + C, C.replace("STATUS", "MERGED_MISSION_IDS: M-1\nSTATUS"), ("--mode", "merge", "--mission", "C", "--absorbed", "1")),
    ("L4 fenced example heading added inside A's notes", True,
     A + "\n" + B, A + "```\n## Mission: Example\n```\n\n" + B, EDIT("A")),
    ("L5 separate '## Notes' section after the last mission edited", True,
     A + "\n" + B + "\n## Notes\nold\n", A + "\n" + B.replace("P-2", "P-3") + "\n## Notes\nnew\n", EDIT("B")),
]


def lock_tests():
    out = []
    with tempfile.TemporaryDirectory() as d:
        L = os.path.join(d, "L.md")
        open(L, "w").write(A)
        out.append(("K1 second writer blocked while lock held", run(d, "backup", L, "--by", "one")[0] == 0 and run(d, "backup", L, "--by", "two")[0] != 0))
        out.append(("K2 verify OK releases lock", run(d, "verify", L, *EDIT("A"))[0] == 0 and not os.path.exists(L + ".lock")))
        out.append(("K3 verify without backup refused", run(d, "verify", L, *EDIT("A"))[0] != 0))
        run(d, "backup", L)
        old = time.time() - 700
        os.utime(L + ".lock", (old, old))
        out.append(("K4 abandoned lock (>10 min) taken over", run(d, "backup", L, "--by", "new")[0] == 0))
        open(L, "w").write(A.replace("STATUS: ACTIVE", "STATUS: MISSION_COMPLETE"))
        failed = run(d, "verify", L, *EDIT("A"))[0] != 0 and os.path.exists(L + ".lock")
        restored = run(d, "restore", L)[0] == 0 and open(L).read() == A and not os.path.exists(L + ".lock")
        out.append(("K5 failed verify keeps lock; restore reverts and releases", failed and restored))
        open(L, "w").write(A + "\n" + B)
        code = run(d, "restore", L)[0]
        out.append(("K6 restore without a lock refused; ledger untouched", code != 0 and open(L).read() == A + "\n" + B))
    return out


ok = True
print(f"Testing {SCRIPT}\n")
for name, should, before, after, args in TESTS:
    passed = case(before, after, *args)
    good = passed == should
    ok &= good
    print(f"{'PASS' if good else 'MISS'}  {name}  (verify {'OK' if passed else 'FAIL'}, expected {'OK' if should else 'FAIL'})")
if HAS_LOCK:
    for name, good in lock_tests():
        ok &= good
        print(f"{'PASS' if good else 'MISS'}  {name}")
else:
    print("SKIP  K1-K5 lock tests (this version has no lock)")
print("\nALL PASS" if ok else "\nSOME MISSED")
sys.exit(0 if ok else 1)
