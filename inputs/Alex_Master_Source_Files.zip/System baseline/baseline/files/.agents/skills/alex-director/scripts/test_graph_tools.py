#!/usr/bin/env python3
"""Tests for graph_edit.py, accept.py, graph_lint.py and the graph lint in ledger_check.py verify.
Usage: python3 test_graph_tools.py [scripts dir]
Runs in a temp folder on made-up graphs, run-logs and ledgers; never touches a real one."""
import json, os, re, subprocess, sys, tempfile
from datetime import datetime, timedelta, timezone

D = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(__file__))
MIGRATION = os.path.join(D, "migrations", "2026-10-02_add-receipt-columns.json")
ENV = dict(os.environ, TZ="UTC")  # run-log dates are local dates; UTC makes them match the stamps here
STAMP = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z$")

GRAPH = """# Mission graph: test
MISSION_ID: mission-test
PROJECT: {proj} (job folder work/x/)

| NODE_ID | REQUIRED | STATUS | DEPENDS_ON | ACCEPTANCE | EVIDENCE | NEXT_ACTION | OWNER_FACING |
|---|---|---|---|---|---|---|---|
| alpha | yes | ACTIVE | - | a works | notes/a.md | Alex's 'yes CG-AAAA' -> Director deletes the duplicate | no |
| beta | yes | ACTIVE | alpha | b works | - | after spp-p9a lands, run beta | no |
| gamma | yes | READY | - | c works | - | wait for spp-p8b; CG-CCCC optional | no |
| top-acceptance | yes | BLOCKED | all above | Alex approves | - | - | yes |

UPDATED_AT: 2026-10-01T10:00Z

## Node: alpha
Write fence for play x (the write guard counts this line).
"""
RUNLOG = """# Run log
Format: `YYYY-MM-DD | job | result | corrections`

2026-10-01 | spp-p9a beta prep (node beta) | VERIFIED: prep done | none
2026-10-02 | composio guard deletes (Director) | Alex sent "yes CG-AAAA CG-BBBB": both deleted, readback 404 | -
2026-10-02 | gamma check | waiting for spp-p8b; CG-CCCC waits on Alex's yes | none
"""
CHANGELOG = """# CHANGELOG

| date | file | change |
|---|---|---|
| 2026-09-30 | x.md | gamma first draft |

## 2026-10-02 11:00 local: gamma tweak, early
- changed gamma acceptance wording

## 2026-10-02 14:30 local: gamma tweak, late
- gamma evidence path moved
"""
MIGRATED_HEADER = ("| NODE_ID | REQUIRED | STATUS | DEPENDS_ON | ACCEPTANCE | EVIDENCE | LAST_RECEIPT | NEXT_ACTION"
                   " | UPDATED_AT | OWNER_FACING |")
MIGRATED_ALPHA = ("| alpha | yes | ACTIVE | - | a works | notes/a.md |  | Alex's 'yes CG-AAAA' -> Director deletes"
                  " the duplicate |  | no |")
BETA = "| beta | yes | ACTIVE | alpha | b works | - | after spp-p9a lands, run beta | no |"
TOP = "| top-acceptance | yes | BLOCKED | all above | Alex approves | - | - | yes |"


def run(script, *args):
    p = subprocess.run([sys.executable, os.path.join(D, script), *args], capture_output=True, text=True, env=ENV)
    return p.returncode, p.stdout + p.stderr


def read(p):
    return open(p, encoding="utf-8").read()


def write(p, text):
    with open(p, "w", encoding="utf-8") as f:
        f.write(text)


def setup(tmp, migrated=False):
    """A project with system/run-log.md and CHANGELOG.md, and a graph whose PROJECT line points at it."""
    proj = os.path.join(tmp, "proj")
    os.makedirs(os.path.join(proj, "system"))
    write(os.path.join(proj, "system", "run-log.md"), RUNLOG)
    write(os.path.join(proj, "system", "CHANGELOG.md"), CHANGELOG)
    os.makedirs(os.path.join(tmp, "graphs"))
    g = os.path.join(tmp, "graphs", "mission-test.md")
    write(g, GRAPH.replace("{proj}", proj))
    if migrated:
        code, out = run("graph_edit.py", "--graph", g, MIGRATION)
        assert code == 0, out
    return proj, g


def ops(tmp, lst):
    p = os.path.join(tmp, f"ops-{len(os.listdir(tmp))}.json")
    write(p, json.dumps(lst))
    return p


def cells(text, node):
    for line in text.split("\n"):
        if line.startswith("| " + node + " |"):
            return [c.strip() for c in line.strip()[1:-1].split(" | ")]
    return None


def refused(code, out):
    """A deliberate refusal, not a crash or a missing script."""
    return code != 0 and "REFUSED" in out and "Traceback" not in out


def warns(out):
    return [l for l in out.splitlines() if "WARN" in l]


def recent(stamp):
    t = datetime.strptime(stamp, "%Y-%m-%dT%H:%MZ").replace(tzinfo=timezone.utc)
    return abs(datetime.now(timezone.utc) - t) < timedelta(minutes=3)


# ---- graph_edit.py ----
def e1_refuses_pipe_and_newline():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        before = read(g)
        bad = [run("graph_edit.py", "--graph", g, ops(t, [{"op": "set", "node": "beta", "col": "EVIDENCE", "value": v}]))
               for v in ("notes/b.md | notes/c.md", "line one\nline two")]
        return all(refused(*r) for r in bad) and read(g) == before and not os.path.exists(g + ".bak")


def e2_add_after_refuses_pipe():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        before = read(g)
        r = run("graph_edit.py", "--graph", g, ops(t, [{"op": "add_after", "after": "gamma",
                "row": {"NODE_ID": "delta", "STATUS": "READY", "ACCEPTANCE": "x | y"}}]))
        return refused(*r) and read(g) == before


def e3_set_append_add_after_show():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t, migrated=True)
        before = read(g)
        code, out = run("graph_edit.py", "--graph", g, ops(t, [
            {"op": "set", "node": "gamma", "col": "STATUS", "value": "ACTIVE"},
            {"op": "append", "node": "alpha", "col": "EVIDENCE", "value": "notes/a2.md"},
            {"op": "append", "node": "gamma", "col": "EVIDENCE", "value": "notes/c.md"},
            {"op": "add_after", "after": "gamma", "row": {"NODE_ID": "delta", "REQUIRED": "yes", "STATUS": "READY",
                                                          "ACCEPTANCE": "d works"}},
            {"op": "show", "node": "delta"}]))
        after = read(g)
        a, c, d = cells(after, "alpha"), cells(after, "gamma"), cells(after, "delta")
        lines = after.split("\n")
        ok = code == 0 and read(g + ".bak") == before
        ok &= bool(a[:8] == ["alpha", "yes", "ACTIVE", "-", "a works", "notes/a.md; notes/a2.md", "",
                             "Alex's 'yes CG-AAAA' -> Director deletes the duplicate"] and STAMP.match(a[8]) and recent(a[8]))
        ok &= bool(c[2] == "ACTIVE" and c[5] == "notes/c.md" and STAMP.match(c[8]))
        ok &= bool(d[:8] == ["delta", "yes", "READY", "-", "d works", "-", "-", "-"] and STAMP.match(d[8]) and d[9] == "-")
        ok &= lines[lines.index(next(l for l in lines if l.startswith("| gamma |"))) + 1].startswith("| delta |")
        ok &= cells(before, "beta") == cells(after, "beta") and cells(before, "top-acceptance") == cells(after, "top-acceptance")
        file_stamp = next(l for l in lines if l.startswith("UPDATED_AT:")).split(":", 1)[1].strip()
        ok &= STAMP.match(file_stamp) is not None and file_stamp != "2026-10-01T10:00Z"
        ok &= '"NODE_ID": "delta"' in out
        return bool(ok)


def e4_batch_all_or_nothing():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        before = read(g)
        r = run("graph_edit.py", "--graph", g, ops(t, [
            {"op": "set", "node": "beta", "col": "STATUS", "value": "VERIFIED"},
            {"op": "set", "node": "no-such-node", "col": "STATUS", "value": "VERIFIED"}]))
        return refused(*r) and read(g) == before


def e5_migration_adds_empty_columns_once():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        before = read(g)
        code1, _ = run("graph_edit.py", "--graph", g, MIGRATION)
        once = read(g)
        code2, _ = run("graph_edit.py", "--graph", g, MIGRATION)
        b, o = before.split("\n"), once.split("\n")
        table = {i for i, l in enumerate(b) if l.startswith("|")}
        ok = code1 == 0 and code2 == 0 and read(g) == once and len(b) == len(o)
        ok &= MIGRATED_HEADER in o and MIGRATED_ALPHA in o and "|---|---|---|---|---|---|---|---|---|---|" in o
        ok &= all(len(cells(once, n)) == 10 and cells(once, n)[6] == "" and cells(once, n)[8] == ""
                  for n in ("alpha", "beta", "gamma", "top-acceptance"))
        ok &= all(b[i] == o[i] for i in range(len(b)) if i not in table)  # header lines, file stamp, fences untouched
        return bool(ok)


def e6_atomic_rename_no_leftovers():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        inode = os.stat(g).st_ino
        code, _ = run("graph_edit.py", "--graph", g, ops(t, [{"op": "set", "node": "beta", "col": "STATUS", "value": "READY"}]))
        return code == 0 and os.stat(g).st_ino != inode and sorted(os.listdir(os.path.dirname(g))) == [
            "mission-test.md", "mission-test.md.bak"]


# ---- accept.py ----
ACCEPT_BETA = ["--node", "beta", "--status", "VERIFIED", "--evidence", "notes/b.md",
               "--receipt", "agent a0123456789abcdef final message", "--next", "-",
               "--job", "spp-p10a beta run", "--result", "VERIFIED: b works (notes/b.md)"]


def a1_round_trip():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t, migrated=True)
        rl = os.path.join(proj, "system", "run-log.md")
        before, log_before = read(g), read(rl)
        code, out = run("accept.py", "--graph", g, *ACCEPT_BETA)  # run-log found through the graph's PROJECT line
        after, log_after = read(g), read(rl)
        b = cells(after, "beta")
        if code != 0 or b is None:
            return False
        s = b[8]
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        ok = bool(b == ["beta", "yes", "VERIFIED", "alpha", "b works", "notes/b.md", "agent a0123456789abcdef final message",
                        "-", s, "no"] and STAMP.match(s) and recent(s))
        ok &= log_after == log_before + (f"{today} | spp-p10a beta run | VERIFIED: b works (notes/b.md)"
                                         f" (graph mission-test/beta -> VERIFIED at {s}) | none\n")
        ok &= read(g + ".bak") == before
        ok &= all(cells(before, n) == cells(after, n) for n in ("alpha", "gamma", "top-acceptance"))
        again = [x if x != "notes/b.md" else "notes/b2.md" for x in ACCEPT_BETA]
        code2, _ = run("accept.py", "--graph", g, *again)
        ok &= code2 == 0 and cells(read(g), "beta")[5] == "notes/b.md; notes/b2.md"  # evidence kept, not replaced
        ok &= len(read(rl).splitlines()) == len(log_before.splitlines()) + 2
        return bool(ok)


def a2_neither_when_run_log_write_fails():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t, migrated=True)
        rl = os.path.join(proj, "system", "run-log.md")
        before, log_before = read(g), read(rl)
        os.chmod(rl, 0o444)
        try:
            code, out = run("accept.py", "--graph", g, *ACCEPT_BETA)
        finally:
            os.chmod(rl, 0o644)
        neither = code != 0 and "Traceback" not in out and read(g) == before and read(rl) == log_before
        retry, _ = run("accept.py", "--graph", g, *ACCEPT_BETA)  # same call works once the run-log is writable
        return neither and retry == 0 and read(rl) != log_before and read(g) != before


def a3_refuses_pipe():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t, migrated=True)
        rl = os.path.join(proj, "system", "run-log.md")
        before, log_before = read(g), read(rl)
        bad = ACCEPT_BETA[:-1] + ["VERIFIED | b works"]
        r1 = run("accept.py", "--graph", g, *bad)
        bad2 = [x if x != "-" else "next | step" for x in ACCEPT_BETA]
        r2 = run("accept.py", "--graph", g, *bad2)
        return refused(*r1) and refused(*r2) and read(g) == before and read(rl) == log_before


def a4_refuses_unmigrated_graph():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t)
        rl = os.path.join(proj, "system", "run-log.md")
        before, log_before = read(g), read(rl)
        r = run("accept.py", "--graph", g, *ACCEPT_BETA)
        return refused(*r) and read(g) == before and read(rl) == log_before


def a5_refuses_unknown_status():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t, migrated=True)
        rl = os.path.join(proj, "system", "run-log.md")
        before, log_before = read(g), read(rl)
        bad = [x if x != "VERIFIED" else "DONE" for x in ACCEPT_BETA]
        r = run("accept.py", "--graph", g, *bad)
        return refused(*r) and read(g) == before and read(rl) == log_before


# ---- graph_lint.py ----
def l1_used_code_and_finished_agent():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t)
        code, out = run("graph_lint.py", g)
        w = warns(out)
        ok = code == 0
        ok &= any("alpha" in l and "CG-AAAA" in l and "line 5" in l for l in w)
        ok &= any("beta" in l and "spp-p9a" in l and "line 4" in l for l in w)
        ok &= not any("CG-CCCC" in l or "spp-p8b" in l for l in w)  # only mentioned, never used or finished
        ok &= any("UPDATED_AT" in l and "column" in l for l in w)
        return bool(ok)


def l2_lists_nodes_without_updated_at():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t, migrated=True)
        run("graph_edit.py", "--graph", g, ops(t, [{"op": "set", "node": "top-acceptance", "col": "UPDATED_AT",
                                                     "value": "2026-10-02T09:00Z"}]))
        code, out = run("graph_lint.py", g)
        line = next((l for l in warns(out) if "no UPDATED_AT" in l), "")
        return code == 0 and all(n in line for n in ("alpha", "beta", "gamma")) and "top-acceptance" not in line


def l3_stale_against_run_log_and_changelog():
    with tempfile.TemporaryDirectory() as t:
        _, g = setup(t, migrated=True)
        run("graph_edit.py", "--graph", g, ops(t, [
            {"op": "set", "node": "alpha", "col": "UPDATED_AT", "value": "2026-10-03T00:00Z"},
            {"op": "set", "node": "beta", "col": "UPDATED_AT", "value": "2026-09-30T12:00Z"},
            {"op": "set", "node": "gamma", "col": "NEXT_ACTION", "value": "wait for spp-p8b; optional cleanup 'yes CG-BBBB'"},
            {"op": "set", "node": "gamma", "col": "UPDATED_AT", "value": "2026-10-02T12:00Z"},
            {"op": "set", "node": "top-acceptance", "col": "NEXT_ACTION", "value": "re-check after spp-p9a"},
            {"op": "set", "node": "top-acceptance", "col": "UPDATED_AT", "value": "2026-10-01T09:00Z"}]))
        code, out = run("graph_lint.py", g)
        stale = [l for l in warns(out) if "stale" in l]
        ok = code == 0
        ok &= any("beta" in l and "run-log line 4" in l for l in stale)  # a later day names beta
        ok &= any("gamma" in l and "CHANGELOG line 11" in l for l in stale)  # 14:30 after 12:00; 11:00 isn't
        ok &= not any(l.split("stale")[1].split(":")[0].strip() in ("alpha", "top-acceptance") for l in stale)
        ok &= not any("gamma" in l and "run-log line 6" in l for l in stale)  # same day, no accept line: unknown
        ok &= not any("alpha" in l and "CG-AAAA" in l for l in warns(out))  # alpha updated after the code was used
        ok &= any("top-acceptance" in l and "spp-p9a" in l for l in warns(out))  # same day: can't tell, so it warns
        ok &= any("gamma" in l and "CG-BBBB" in l for l in warns(out))  # used the same day as gamma's stamp
        return bool(ok)


def l4_result_after_accept_is_stale():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t, migrated=True)
        code, _ = run("accept.py", "--graph", g, *ACCEPT_BETA)
        _, out1 = run("graph_lint.py", g)
        rl = os.path.join(proj, "system", "run-log.md")
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        with open(rl, "a", encoding="utf-8") as f:
            f.write(f"{today} | spp-p11a beta follow-up (node beta) | VERIFIED: more | none\n")
        n = len(read(rl).rstrip("\n").split("\n"))
        code2, out2 = run("graph_lint.py", g)
        fresh = not any("stale" in l and "beta" in l for l in warns(out1))
        flagged = any("stale" in l and "beta" in l and f"run-log line {n}" in l for l in warns(out2))
        still = any("alpha" in l and "CG-AAAA" in l for l in warns(out2))
        return code == 0 and code2 == 0 and fresh and flagged and still


def l5_never_blocks():
    with tempfile.TemporaryDirectory() as t:
        c1, o1 = run("graph_lint.py", os.path.join(t, "missing.md"))
        g = os.path.join(t, "no-project.md")
        write(g, GRAPH.replace("{proj}", os.path.join(t, "nowhere")))
        c2, o2 = run("graph_lint.py", g)
        return c1 == 0 and c2 == 0 and bool(warns(o1))


def l6_ledger_verify_prints_lint_and_passes():
    with tempfile.TemporaryDirectory() as t:
        proj, g = setup(t)
        L = os.path.join(t, "L.md")
        block = (f"# Director State\n\n## Mission: T\nMISSION_ID: mission-test\nPROJECT: {proj}\n"
                 f"MISSION_GRAPH: {g}\nNEXT_PLAY_ID: P-1\nSTATUS: ACTIVE\n")
        write(L, block)
        run("ledger_check.py", "backup", L, "--by", "test")
        write(L, block.replace("P-1", "P-2"))
        code, out = run("ledger_check.py", "verify", L, "--mode", "edit", "--mission", "T")
        return code == 0 and "OK:" in out and any("CG-AAAA" in l for l in warns(out)) and not os.path.exists(L + ".lock")


def l7_block_format_graph():
    with tempfile.TemporaryDirectory() as t:
        g = os.path.join(t, "blocks.md")
        write(g, "# Mission graph\nUPDATED_AT: 2026-09-02T12:52:39Z\n\n## Node: n1\nREQUIRED: YES\nSTATUS: VERIFIED\n"
                 "NEXT_ACTION: NONE\nUPDATED_AT: 2026-09-02T11:36:00Z\n\n## Node: n2\nREQUIRED: YES\nSTATUS: READY\n"
                 "NEXT_ACTION: NONE\n")
        code, out = run("graph_lint.py", g)
        line = next((l for l in warns(out) if "no UPDATED_AT" in l), "")
        return code == 0 and "n2" in line and "n1" not in line


TESTS = [
    ("E1 graph_edit refuses ' | ' and a line break in a cell; nothing written", e1_refuses_pipe_and_newline),
    ("E2 graph_edit add_after refuses ' | ' in a new row", e2_add_after_refuses_pipe),
    ("E3 set, append, add_after, show land in the right cells; .bak = before; node and file stamped", e3_set_append_add_after_show),
    ("E4 a batch with one bad op writes nothing", e4_batch_all_or_nothing),
    ("E5 migration adds LAST_RECEIPT and UPDATED_AT, empty, once; second run changes nothing", e5_migration_adds_empty_columns_once),
    ("E6 write replaces the file by rename and leaves no temp files", e6_atomic_rename_no_leftovers),
    ("A1 accept.py round trip: 5 cells + the matching run-log line", a1_round_trip),
    ("A2 accept.py writes neither when the run-log append fails", a2_neither_when_run_log_write_fails),
    ("A3 accept.py refuses ' | ' in a run-log field or a cell", a3_refuses_pipe),
    ("A4 accept.py refuses a graph without the receipt columns", a4_refuses_unmigrated_graph),
    ("A5 accept.py refuses a status outside the allowed list", a5_refuses_unknown_status),
    ("L1 lint flags a used approval code and a finished play, not mere mentions", l1_used_code_and_finished_agent),
    ("L2 lint lists nodes with no UPDATED_AT", l2_lists_nodes_without_updated_at),
    ("L3 lint flags UPDATED_AT older than a run-log or CHANGELOG line naming the node", l3_stale_against_run_log_and_changelog),
    ("L4 a result logged after accept.py makes the node stale (same day, by line order)", l4_result_after_accept_is_stale),
    ("L5 lint never blocks: exit 0 on a missing graph or run-log", l5_never_blocks),
    ("L6 ledger_check verify prints the lint and still passes", l6_ledger_verify_prints_lint_and_passes),
    ("L7 lint reads block-format graphs (## Node sections)", l7_block_format_graph),
]

ok = True
print(f"Testing scripts in {D}\n")
for name, fn in TESTS:
    try:
        good = bool(fn())
    except Exception as e:  # a crash is a miss, not a pass
        good = False
        name += f"  [{type(e).__name__}: {e}]"
    ok &= good
    print(f"{'PASS' if good else 'MISS'}  {name}")
print("\nALL PASS" if ok else "\nSOME MISSED")
sys.exit(0 if ok else 1)
