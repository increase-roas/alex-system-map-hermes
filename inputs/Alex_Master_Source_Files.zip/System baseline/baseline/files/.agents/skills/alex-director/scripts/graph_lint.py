#!/usr/bin/env python3
"""Read-only staleness check for mission graphs. It only prints warnings and always exits 0: it never blocks.

  graph_lint.py GRAPH [GRAPH ...] [--run-log PATH] [--changelog PATH]

Default run-log and CHANGELOG: <PROJECT>/system/run-log.md and CHANGELOG.md (PROJECT from the graph header).
Warnings:
  1. nodes with no UPDATED_AT (or a node table with no UPDATED_AT column: run the migration in migrations/);
  2. stale: a node whose UPDATED_AT is older than a run-log or CHANGELOG line naming the node ID. Run-log lines
     carry a local date, so a later day counts, and the same day only below the node's own accept.py line;
     CHANGELOG lines take the time of the "## YYYY-MM-DD HH:MM" heading above them;
  3. NEXT_ACTION naming an approval code the run-log shows used ("yes CG-XXXX") or an agent or play the run-log
     shows finished (named in a line's job field: spp-p38a, a0123456789abcdef), unless that line is older than
     the node's UPDATED_AT.
ledger_check.py verify runs it on the mission's graph after an OK.
"""
import os, re, sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import graph_edit as ge  # noqa: E402

CODE = re.compile(r"\bCG-[A-Z0-9]{4}\b")
USED = re.compile(r"(?i:\byes\b)[\s'\"\u2018\u2019\u201c\u201d]*((?:CG-[A-Z0-9]{4}\s*(?:(?:,|\+|&|and)\s*)?)+)")
PLAY = re.compile(r"(?<![\w-])[a-z]{2,4}-[a-z]{1,2}\d{1,3}[a-z]{0,2}(?![\w-])")
AGENT = re.compile(r"(?<![\w-])a[0-9a-f]{16}(?![\w-])")
ANCHOR = re.compile(r"\(graph ([\w.-]+)/([\w.-]+) -> \S+ at (\S+?)\)")
TS = re.compile(r"(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?")
HEAD = re.compile(r"^#{2,3}\s+(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}):(\d{2}))?")
ROWDATE = re.compile(r"^(?:\|\s*|-\s+)(\d{4}-\d{2}-\d{2})\s*\|")
RLDATE = re.compile(r"^(\d{4}-\d{2}-\d{2}) \| ")
MIGRATION = "migrations/2026-10-02_add-receipt-columns.json"


def parse_ts(s):
    m = TS.search(s or "")
    if not m:
        return None
    d, hh, mm, ss, tz = m.groups()
    dt = datetime.strptime(f"{d} {hh}:{mm}:{ss or '00'}", "%Y-%m-%d %H:%M:%S")
    if tz and tz != "Z":
        offset = timedelta(hours=int(tz[1:3]), minutes=int(tz[-2:]))
        dt = dt - offset if tz[0] == "+" else dt + offset
    return dt.replace(tzinfo=timezone.utc)


def day(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def nodes_of(text, warns):
    """[(node_id, fields)] from the node table and from "## Node:" sections that carry STATUS or NODE_ID."""
    nodes, column = [], None
    try:
        t = ge.Table(text)
        column = "UPDATED_AT" in t.cols
        for i in t.rows():
            c = ge.parse_row(t.lines[i])
            if len(c) != len(t.cols):
                warns.append(f"WARN row {i + 1} ({c[0]}) has {len(c)} cells for {len(t.cols)} columns")
                continue
            nodes.append((c[0], dict(zip(t.cols, c))))
    except ge.Refused:
        pass
    seen, cur, blocks = {n for n, _ in nodes}, None, []
    for line in text.split("\n"):
        m = re.match(r"^##\s+Node:\s*(\S+)\s*$", line)
        if m:
            cur = (m.group(1), {})
            blocks.append(cur)
        elif line.startswith("#"):
            cur = None
        elif cur is not None:
            f = re.match(r"^([A-Z_]+):\s*(.*)$", line)
            if f:
                cur[1].setdefault(f.group(1), f.group(2).strip())
    nodes += [(n, f) for n, f in blocks if ("STATUS" in f or "NODE_ID" in f) and n not in seen]
    return nodes, column


def load_run_log(path):
    rows = []  # (line number, local date, job field, text)
    with open(path, encoding="utf-8", errors="replace") as f:
        for n, line in enumerate(f, 1):
            m = RLDATE.match(line)
            if m:
                parts = line.rstrip("\n").split(" | ")
                rows.append((n, day(m.group(1)), parts[1] if len(parts) > 1 else "", line.rstrip("\n")))
    return rows


def load_changelog(path):
    rows, when = [], (None, None)  # (line number, UTC time or None, local date or None, text)
    with open(path, encoding="utf-8", errors="replace") as f:
        for n, line in enumerate(f, 1):
            line = line.rstrip("\n")
            h, r = HEAD.match(line), ROWDATE.match(line)
            if h:
                d, hh, mm = h.groups()
                local = datetime.strptime(f"{d} {hh}:{mm}", "%Y-%m-%d %H:%M") if hh else None
                when = (local.astimezone(timezone.utc) if local else None, day(d))
            elif line.startswith("#"):
                when = (None, None)
            rows.append((n, None, day(r.group(1)), line) if r else (n, when[0], when[1], line))
    return rows


def where(hits):
    first, last = hits[0][0], hits[-1][0]
    return f"run-log line {first}" + (f", last named on line {last}" if last != first else "")


def lint(graph, run_log=None, changelog=None, project=None):
    """Warning lines for one graph. Never raises for bad input; never writes."""
    warns = []
    try:
        text = open(os.path.expanduser(graph), encoding="utf-8").read()
    except OSError as e:
        return [f"WARN cannot read {graph}: {e}"]
    lines = text.split("\n")
    nodes, column = nodes_of(text, warns)
    mission = ge.header_value(lines, "MISSION_ID") or os.path.splitext(os.path.basename(graph))[0]
    proj = ge.project_dir(lines) or project
    run_log = run_log or (proj and os.path.join(proj, "system", "run-log.md"))
    changelog = changelog or (proj and os.path.join(proj, "system", "CHANGELOG.md"))
    rl = load_run_log(run_log) if run_log and os.path.isfile(run_log) else None
    cl = load_changelog(changelog) if changelog and os.path.isfile(changelog) else []
    if rl is None:
        warns.append(f"NOTE no run-log found ({run_log or 'no PROJECT path'}): checks 2 and 3 skipped")
        rl = []

    if column is False:
        warns.append(f"WARN no UPDATED_AT column ({len(nodes)} nodes): run {MIGRATION} with graph_edit.py")
    missing = [n for n, f in nodes if not parse_ts(f.get("UPDATED_AT"))]
    if missing and column is not False:
        warns.append(f"WARN no UPDATED_AT ({len(missing)} nodes): " + ", ".join(missing))

    used, finished = {}, {}
    for n, d, job, line in rl:
        for m in USED.finditer(line):
            for code in CODE.findall(m.group(1)):
                used.setdefault(code, []).append((n, d))
        for pid in set(PLAY.findall(job)) | set(AGENT.findall(job)):
            finished.setdefault(pid, []).append((n, d))

    for nid, f in nodes:
        stamp_text = f.get("UPDATED_AT", "")
        ts = parse_ts(stamp_text)
        names = re.compile(r"(?<![\w-])" + re.escape(nid) + r"(?![\w-])")
        anchor = None
        for n, d, job, line in rl:
            if any(node == nid and stamp == stamp_text and mid == mission for mid, node, stamp in ANCHOR.findall(line)):
                anchor = n

        def rl_newer(n, d):
            if ts is None:
                return True
            if anchor is not None:
                return n > anchor
            nd = ts.astimezone().date()
            return True if d > nd else False if d < nd else None

        if ts is not None:
            hits = []
            for n, d, job, line in rl:
                other = any(node == nid and mid != mission for mid, node, _ in ANCHOR.findall(line))
                if names.search(line) and not other and rl_newer(n, d) is True:
                    hits.append(f"run-log line {n} ({d})")
            for n, dt, d, line in cl:
                if not names.search(line):
                    continue
                newer = dt > ts if dt else (d > ts.astimezone().date() if d else False)
                if newer:
                    hits.append(f"CHANGELOG line {n} ({dt.astimezone().strftime('%Y-%m-%d %H:%M') if dt else d} local)")
            if hits:
                newest = [h for h in hits if h.startswith("run-log")][-1:] + [h for h in hits if h.startswith("CHANGELOG")][-1:]
                more = f" (+{len(hits) - len(newest)} more)" if len(hits) > len(newest) else ""
                warns.append(f"WARN stale {nid}: UPDATED_AT {stamp_text} is older than {' and '.join(newest)}{more}")

        action = f.get("NEXT_ACTION", "")
        for code in sorted(set(CODE.findall(action))):
            if code in used and rl_newer(*used[code][-1]) is not False:
                warns.append(f"WARN {nid}: NEXT_ACTION names {code}, already used ({where(used[code])})")
        for pid in sorted(set(PLAY.findall(action)) | set(AGENT.findall(action))):
            if pid in finished and rl_newer(*finished[pid][-1]) is not False:
                warns.append(f"WARN {nid}: NEXT_ACTION names {pid}, which already finished ({where(finished[pid])})")
    return warns


def main():
    args = sys.argv[1:]
    opt = {}
    for k in ("--run-log", "--changelog"):
        if k in args:
            i = args.index(k)
            opt[k] = args[i + 1] if i + 1 < len(args) else None
            del args[i:i + 2]
    if not args:
        print(__doc__)
        return
    for graph in args:
        try:
            warns = lint(graph, opt.get("--run-log"), opt.get("--changelog"))
        except Exception as e:  # never block: a lint bug is a warning too
            warns = [f"WARN graph lint failed on {graph}: {type(e).__name__}: {e}"]
        print(f"graph_lint {graph}: {sum(w.startswith('WARN') for w in warns)} warnings (read-only; nothing blocked)")
        for w in warns:
            print(w)


if __name__ == "__main__":
    main()
