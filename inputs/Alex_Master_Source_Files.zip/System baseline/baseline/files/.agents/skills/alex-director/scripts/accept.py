#!/usr/bin/env python3
"""Close one accepted result in one command: the node's graph cells and its run-log line, both or neither.

  accept.py --graph GRAPH --node ID --status STATUS --evidence TEXT --receipt TEXT --next TEXT
            --job TEXT --result TEXT [--corrections TEXT] [--run-log PATH]

Sets STATUS, LAST_RECEIPT, NEXT_ACTION and UPDATED_AT (UTC, now), adds TEXT to EVIDENCE after "; ", then appends
  YYYY-MM-DD | job | result (graph MISSION/NODE -> STATUS at UPDATED_AT) | corrections
to the run-log (default <PROJECT>/system/run-log.md, PROJECT from the graph header; corrections default "none").
STATUS starts with READY, BLOCKED, ACTIVE, READY_FOR_OWNER, VERIFIED, FAILED or WAITING_ON_ALEX. No value may hold
" | " or a line break. The graph is written first (GRAPH.bak, temp file, rename); if the run-log append then fails,
the graph is put back. A graph without LAST_RECEIPT and UPDATED_AT columns is refused: run the migration in
migrations/ with graph_edit.py first. Other cell edits: graph_edit.py. Staleness check: graph_lint.py.
"""
import argparse, os, sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import graph_edit as ge  # noqa: E402

STATUSES = ("READY", "BLOCKED", "ACTIVE", "READY_FOR_OWNER", "VERIFIED", "FAILED", "WAITING_ON_ALEX")
MIGRATION = "migrations/2026-10-02_add-receipt-columns.json"


def prepare(a):
    """Everything is checked and built in memory before any write. Raises ge.Refused."""
    path = os.path.realpath(os.path.expanduser(a.graph))
    before = open(path, encoding="utf-8").read()
    t = ge.Table(before)
    for col in ("STATUS", "EVIDENCE", "LAST_RECEIPT", "NEXT_ACTION", "UPDATED_AT"):
        if col not in t.cols:
            raise ge.Refused(f"the graph has no {col} column; run {MIGRATION} with graph_edit.py first")
    status = ge.check_cell("STATUS", a.status)
    word = status.split()[0] if status else ""
    if word not in STATUSES:
        raise ge.Refused(f"STATUS {status!r} must start with one of {', '.join(STATUSES)}")
    i = t.find(a.node)
    c = t.cells(i)
    stamp = ge.now_stamp()
    evidence = ge.check_cell("EVIDENCE", a.evidence)
    k = t.col("EVIDENCE")
    c[k] = evidence if c[k] in ("", "-") else c[k] + "; " + evidence
    c[t.col("STATUS")] = status
    c[t.col("LAST_RECEIPT")] = ge.check_cell("LAST_RECEIPT", a.receipt)
    c[t.col("NEXT_ACTION")] = ge.check_cell("NEXT_ACTION", a.next)
    c[t.col("UPDATED_AT")] = stamp
    t.put(i, c)
    t.stamp_file(stamp)
    job, result, corrections = (ge.check_cell(n, v) for n, v in
                                (("job", a.job), ("result", a.result), ("corrections", a.corrections)))
    if not job or not result:
        raise ge.Refused("--job and --result can't be empty")
    run_log = a.run_log or (ge.project_dir(t.lines) and os.path.join(ge.project_dir(t.lines), "system", "run-log.md"))
    if not run_log:
        raise ge.Refused("no --run-log and no PROJECT path in the graph header")
    run_log = os.path.expanduser(run_log)
    if not os.path.isfile(run_log):
        raise ge.Refused(f"run-log not found: {run_log}")
    mission = ge.header_value(t.lines, "MISSION_ID") or os.path.splitext(os.path.basename(path))[0]
    line = (f"{datetime.now().strftime('%Y-%m-%d')} | {job} | {result} (graph {mission}/{a.node} -> {word} at {stamp})"
            f" | {corrections or 'none'}")
    return path, before, t.text(), run_log, line


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    for name in ("--graph", "--node", "--status", "--evidence", "--receipt", "--next", "--job", "--result"):
        ap.add_argument(name, required=True)
    ap.add_argument("--corrections", default="none")
    ap.add_argument("--run-log")
    a = ap.parse_args()
    try:
        path, before, after, run_log, line = prepare(a)
    except (ge.Refused, OSError) as e:
        print(f"REFUSED: {e}. Nothing written.")
        sys.exit(1)
    ge.backup(path)
    ge.write_atomic(path, after)
    try:
        ends_clean = True
        if os.path.getsize(run_log):
            with open(run_log, "rb") as f:
                f.seek(-1, os.SEEK_END)
                ends_clean = f.read(1) == b"\n"
        with open(run_log, "a", encoding="utf-8") as f:
            f.write(("" if ends_clean else "\n") + line + "\n")
    except OSError as e:
        ge.write_atomic(path, before)
        print(f"FAILED: run-log append failed ({e}); the graph is back as it was. Nothing written.")
        sys.exit(1)
    print(f"OK: {a.node} updated in {path} (backup {path}.bak)")
    print(f"run-log {run_log} +1 line: {line}")


if __name__ == "__main__":
    main()
