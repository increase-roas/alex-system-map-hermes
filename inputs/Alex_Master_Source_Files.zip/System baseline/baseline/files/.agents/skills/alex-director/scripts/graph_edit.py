#!/usr/bin/env python3
"""Edit a mission graph's node table safely (durable home of the old /tmp/claude-501/dir/graph_edit.py).

  graph_edit.py --graph GRAPH OPS.json        (or, as before: GRAPH=<path> graph_edit.py OPS.json)

OPS.json is a list of operations (or {"ops": [...]}), applied in order, all or nothing:
  {"op": "set",        "node": ID, "col": COL, "value": TEXT}  replace one cell
  {"op": "append",     "node": ID, "col": COL, "value": TEXT}  add to a cell after "; " (an empty or "-" cell is replaced)
  {"op": "add_after",  "after": ID, "row": {COL: TEXT, ...}}   insert a new node row; cells not given are "-"
  {"op": "add_column", "col": COL, "after": COL}              new column, empty in every row; skipped if already there
  {"op": "show",       "node": ID}                            print the row as JSON
A cell can't hold " | " or a line break (either one splits the table row): the batch is REFUSED, nothing written.
set, append and add_after stamp the node's UPDATED_AT cell (UTC) when the table has one, unless the op sets it, and
refresh the graph's own "UPDATED_AT:" line under the table.
Writes: GRAPH.bak first (like ledger_check.py), then a temp file in the same folder renamed over GRAPH.
Closing an accepted result: accept.py (it also writes the run-log line). Read-only staleness check: graph_lint.py.
"""
import json, os, re, shutil, sys, tempfile
from datetime import datetime, timezone

SEP = " | "


class Refused(Exception):
    pass


def now_stamp():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%MZ")


def parse_row(line):
    return [c.strip() for c in line.strip()[1:-1].split(SEP)]


def fmt_row(cells):
    return "| " + SEP.join(cells) + " |"


def check_cell(col, value):
    if not isinstance(value, str):
        raise Refused(f"{col}: the value must be text")
    if SEP in value:
        raise Refused(f'{col}: a cell can\'t contain " | " (it splits the table row); use "/" or ";" instead')
    if "\n" in value or "\r" in value:
        raise Refused(f"{col}: a cell can't contain a line break")
    return value.strip()


def header_value(lines, key):
    """A KEY: value line from the graph header (above the table and the first "## " section)."""
    for line in lines:
        if line.startswith("|") or line.startswith("## "):
            break
        m = re.match(rf"^{key}:\s*(.*)$", line)
        if m:
            return m.group(1).strip()
    return ""


def project_dir(lines):
    m = re.match(r"^[`*]*(~?/[^\s`*()]+)", header_value(lines, "PROJECT"))
    return os.path.expanduser(m.group(1)) if m else None


class Table:
    def __init__(self, text):
        self.lines = text.split("\n")
        self.hdr = next((i for i, l in enumerate(self.lines) if re.match(r"^\|\s*NODE_ID\s*\|", l)), None)
        if self.hdr is None:
            raise Refused("no node table (a '| NODE_ID | ...' header) in this graph")
        if self.hdr + 1 >= len(self.lines) or not re.match(r"^\|[\s:|-]+$", self.lines[self.hdr + 1]):
            raise Refused("no |---| separator row under the table header")
        self.cols = [c.strip() for c in self.lines[self.hdr].strip().strip("|").split("|")]
        self.end = self.hdr + 2
        while self.end < len(self.lines) and self.lines[self.end].startswith("|"):
            self.end += 1

    def rows(self):
        return range(self.hdr + 2, self.end)

    def find(self, node):
        hits = [i for i in self.rows() if parse_row(self.lines[i])[0] == node]
        if not hits:
            raise Refused(f"node not found: {node}")
        if len(hits) > 1:
            raise Refused(f"node {node} has {len(hits)} rows")
        return hits[0]

    def cells(self, i):
        c = parse_row(self.lines[i])
        if len(c) != len(self.cols):
            raise Refused(f"row {i + 1} ({c[0]}) has {len(c)} cells for {len(self.cols)} columns; fix that row first")
        return c

    def col(self, name):
        if name not in self.cols:
            raise Refused(f"no column {name} (columns: {', '.join(self.cols)})")
        return self.cols.index(name)

    def put(self, i, cells):
        line = fmt_row(cells)
        if parse_row(line) != cells:
            raise Refused(f"row {cells[0]} wouldn't read back as written (a cell starts or ends with '|')")
        self.lines[i] = line

    def stamp_node(self, cells, stamp):
        if "UPDATED_AT" in self.cols:
            cells[self.cols.index("UPDATED_AT")] = stamp

    def stamp_file(self, stamp):
        for i in range(self.end, len(self.lines)):
            if self.lines[i].startswith("## "):
                return
            if self.lines[i].startswith("UPDATED_AT:"):
                self.lines[i] = "UPDATED_AT: " + stamp
                return

    def add_column(self, col, after):
        if col in self.cols:
            return False
        k = self.col(after) + 1
        rows = [(i, self.cells(i)) for i in self.rows()]
        self.cols.insert(k, col)
        self.lines[self.hdr] = fmt_row(self.cols)
        self.lines[self.hdr + 1] = "|" + "---|" * len(self.cols)
        for i, c in rows:
            c.insert(k, "")
            self.put(i, c)
        return True

    def text(self):
        return "\n".join(self.lines)


def apply(table, ops, stamp):
    """Apply ops in memory. Returns (content_changed, schema_changed, printed lines). Raises Refused."""
    content = schema = False
    out = []
    for n, op in enumerate(ops, 1):
        kind = op.get("op") if isinstance(op, dict) else None
        try:
            if kind in ("set", "append"):
                i = table.find(op["node"])
                c = table.cells(i)
                k = table.col(op["col"])
                v = check_cell(op["col"], op["value"])
                c[k] = v if kind == "set" or c[k] in ("", "-") else c[k] + "; " + v
                if op["col"] != "UPDATED_AT":
                    table.stamp_node(c, stamp)
                table.put(i, c)
                content = True
            elif kind == "add_after":
                i = table.find(op["after"])
                row = op["row"]
                if not isinstance(row, dict):
                    raise Refused('"row" must be an object of COLUMN: text')
                unknown = sorted(set(row) - set(table.cols))
                if unknown:
                    raise Refused(f"unknown columns {unknown}")
                nid = check_cell("NODE_ID", row.get("NODE_ID", ""))
                if not nid:
                    raise Refused("the new row needs a NODE_ID")
                if any(parse_row(table.lines[j])[0] == nid for j in table.rows()):
                    raise Refused(f"node {nid} already exists")
                c = [check_cell(col, row[col]) if col in row else "-" for col in table.cols]
                c[0] = nid
                if "UPDATED_AT" not in row:
                    table.stamp_node(c, stamp)
                table.lines.insert(i + 1, "")
                table.end += 1
                table.put(i + 1, c)
                content = True
            elif kind == "add_column":
                col = check_cell("col", op["col"])
                if not re.match(r"^[A-Z][A-Z0-9_]*$", col):
                    raise Refused(f"column name {col!r}: use CAPITALS, digits and _")
                if table.add_column(col, op["after"]):
                    schema = True
                else:
                    out.append(f"skip: column {col} is already there")
            elif kind == "show":
                i = table.find(op["node"])
                out.append(json.dumps(dict(zip(table.cols, table.cells(i))), ensure_ascii=False))
            else:
                raise Refused(f"unknown op {kind!r} (set, append, add_after, add_column, show)")
        except KeyError as e:
            raise Refused(f"op {n} ({kind}): missing field {e}")
        except Refused as e:
            raise Refused(f"op {n} ({kind}): {e}")
    if content:
        table.stamp_file(stamp)
    return content, schema, out


def backup(path):
    shutil.copy2(path, path + ".bak")


def write_atomic(path, text):
    folder = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=folder, prefix="." + os.path.basename(path) + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        if os.path.exists(path):
            shutil.copymode(path, tmp)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def main():
    args = sys.argv[1:]
    graph = os.environ.get("GRAPH")
    if "--graph" in args:
        k = args.index("--graph")
        graph = args[k + 1] if k + 1 < len(args) else None
        del args[k:k + 2]
    if not graph or len(args) != 1:
        print(__doc__)
        sys.exit(2)
    path = os.path.realpath(os.path.expanduser(graph))
    try:
        data = json.load(open(args[0], encoding="utf-8"))
        ops = data["ops"] if isinstance(data, dict) else data
        if not isinstance(ops, list):
            raise Refused("the ops file must hold a list of ops")
        table = Table(open(path, encoding="utf-8").read())
        content, schema, out = apply(table, ops, now_stamp())
    except (Refused, OSError, ValueError, KeyError) as e:
        print(f"REFUSED: {e}. Nothing written.")
        sys.exit(1)
    for line in out:
        print(line)
    if content or schema:
        backup(path)
        write_atomic(path, table.text())
        print(f"OK: {len(ops)} ops applied to {path} (backup {path}.bak)")


if __name__ == "__main__":
    main()
