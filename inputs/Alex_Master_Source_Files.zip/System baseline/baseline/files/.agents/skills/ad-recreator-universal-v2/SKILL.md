---
name: ad-recreator-universal-v2
description: Recreate approved B2B marketing ads or slides while preserving the reference composition and replacing it with supplied avatar, brand, apparel, logo, and offer assets. Use for requests such as “recreate ads,” “clone winning ads,” “same structure,” “swap avatar and branding,” or “bulk recreate all.”
---

# Universal Winning Ad Recreator v2

Recreate approved B2B marketing visuals at scale. Treat the reference as a **layout brief** and the supplied assets as the **brand source of truth**.

> **Keep the conversion structure. Rebuild the creative with the supplied brand. Preserve the person; replace incidental source branding.**

## v2 updates

| Update | v2 operating rule |
| --- | --- |
| Avatar versus apparel | Preserve the person’s face, hair, recognizable features, and approved pose. Treat shirt color, apparel cut, chest branding, accessories, and other visible source-brand treatment as replaceable unless the user explicitly says to preserve them. |
| Logo is a visual instruction | When a logo is supplied, use it to establish brand identity in the creative. Do not let a source avatar’s shirt color or a soft/generated shirt logo override the supplied brand treatment. |
| Leaner intake | Request only the reference set, target avatar, own-brand assets, offer, CTA, and any essential visual direction. Do not turn routine ad recreation into a proof, performance, or authorization questionnaire. |
| Unknown content | Never invent missing copy. If supporting detail is absent, use only the supplied offer and CTA or omit that element. |
| Final check | Before delivery, check the shirt/apparel color, logo application, avatar identity, headline, CTA, and composition—not just the general aesthetic. |

## Scope

Create one standalone final image per requested reference. Do not create a deck, campaign system, contact sheet, or extra variants unless asked. Keep assets and copied facts within the current job.

| Retain from the reference | Rebuild with current-job assets | Never reuse by default |
| --- | --- | --- |
| Aspect ratio, focal region, subject scale, headroom, visual hierarchy, headline/CTA/logo zones, density, reading order, and safe areas | Target-avatar identity, apparel treatment, logo, palette, exact offer, CTA, and requested background | Competitor logos, other brands, proprietary reference wording, incidental signage, and unspecified details |

## 1. Collect the minimum brief

```text
Brand:
Offer:
CTA:
References to recreate:
Target-avatar files:
Logo file:
Color and apparel direction:
Background: preserve / replace:
```

When the user supplies a logo but does not state apparel treatment, default person-led ads to apparel that matches the supplied palette and has no conflicting visible source logo. Use a clean separate logo placement rather than relying on a generated shirt logo. Add branded apparel only when it improves the chosen reference composition or the user requests it.

## 2. Lock the structure, avatar, and brand

Create one concise composition lock per reference. Estimate position values as percentages; label them as estimates.

```json
{
  "reference_id": "ad-01",
  "aspect_ratio": "1:1",
  "focal": {"region": "right third", "x_pct": 65, "y_pct": 50, "frame_pct": 50, "headroom_pct": 8},
  "headline": {"region": "lower band", "x_pct": 3, "y_pct": 62, "w_pct": 76, "h_pct": 33},
  "devices": ["top-left label", "bottom-right CTA"],
  "logo": {"region": "bottom-left", "x_pct": 6, "y_pct": 92},
  "reading_order": ["label", "subject", "headline", "CTA", "logo"],
  "density": "medium",
  "confidence": 0.0
}
```

For every person-led reference, record this mini-lock before generation:

| Avatar element | Decision |
| --- | --- |
| Identity anchors | Face, hair, recognizable features, requested pose, and silhouette to preserve |
| Apparel | Explicit `preserve` or `replace`; list the required color and style |
| Shirt branding | `none`, `supplied logo`, or `leave clean`; never use a conflicting source logo |
| Separate logo | Supplied logo file and final placement zone |
| Background | Preserve only if it has no conflicting visual identity; otherwise replace with a brand-aligned setting |

Use the supplied logo as a reference for shape and color. Do not rely on generated typography for a precise wordmark when a separate logo placement can do the job.

## 3. Choose the production route

| Need | Route |
| --- | --- |
| Retain an approved scene and change only a limited region | Precise image edit. State the exact changed region and all preserved elements. |
| Use a new person scene or replace source branding/apparel/background | Image generation guided by the composition and mini-lock. |
| Compare a new creative direction | Generate a small approved test set, then scale only after direction approval. |

Before a paid run, state the image count, route, selected model, per-image price, and estimated total. Obtain an explicit approval of that stated total.

## 4. Prompt for person-led ads

```text
Create a [aspect ratio] B2B marketing image for [audience].
Composition: Preserve the supplied reference’s [headline zone], [CTA zone], [logo zone], [focal placement], and [reading order]. Do not retain its logos, text, signage, or other identity.
Avatar: Faithfully preserve [face, hair, physical features, and requested pose] from the supplied target avatar.
Apparel: Replace the source clothing with [required color, style, and visible-logo decision]. Remove any conflicting source-brand treatment.
Brand: Use the supplied [brand] logo in [separate final placement]. Follow [palette].
Text to render: Headline “[exact offer]”; CTA “[exact CTA]”; support “[only supplied support copy].”
Background: [preserve/rebuild instruction].
Avoid: extra logos, made-up copy, altered framing, wrong shirt color, visible conflicting shirt mark, moved CTA, and garbled critical text.
```

For a precise edit, state: `Edit the provided image. Change only [target]. Replace the apparel with [brand treatment] and remove any conflicting visible logo. Preserve the target person’s face, hair, pose, lighting, perspective, and all other non-target elements.`

## 5. Lightweight delivery check

Check each image once against its locks. Correct one critical failure with one focused regeneration or edit. Avoid open-ended refinement.

| Check | Pass condition |
| --- | --- |
| Composition | Correct aspect ratio, focal placement, hierarchy, and CTA/logo zones |
| Target avatar | Face, hairstyle, recognizable features, and selected pose are consistent with the supplied person |
| Apparel | Shirt color/style matches the mini-lock; no conflicting source-brand treatment remains |
| Logo | Supplied brand identity is present in the chosen logo zone; do not depend on an unreadable generated shirt logo |
| Copy | Exact visible offer and CTA; no unrequested text was added |

Deliver each final image with a compact record.

| Reference | Final image | Route / model | Apparel decision | Result |
| --- | --- | --- | --- | --- |
| ad-01 | [file or URL] | [edit/generate, model] | [preserve/replace] | pass / note |

State material limitations only. Stop after the requested set unless the user asks for another iteration.
