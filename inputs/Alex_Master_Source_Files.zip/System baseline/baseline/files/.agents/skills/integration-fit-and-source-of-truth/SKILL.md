---
name: integration-fit-and-source-of-truth
description: Use before building an API call, webhook, CRM connection or automation. Decides native vs custom, names one system of record per object, and lists the permissions and proof needed.
---

# Integration Fit and Source of Truth

Use this skill to decide **whether an integration should exist and what it must preserve** before attempting to configure or build it. This is a read-only assessment skill, not an implementation guide.

## Operating boundaries

Do not create accounts, install packages, configure applications, enable integrations, request or store credentials, register webhooks, send messages, write to external systems, modify repositories, or deploy code.

Use current official vendor documentation or authenticated read-only evidence for capability claims. Treat sales pages, search snippets, old chats, and third-party posts as leads—not proof. Keep every client, account, location, and system separate.

## Workflow

1. **Define the business outcome.** State the trigger, the desired visible result, the actor who needs it, and the smallest success condition. Do not start with an API or tool choice.

2. **Name the systems and boundaries.** Identify the proposed source system, destination system, relevant client/account/environment, and any current process that already achieves part of the outcome.

3. **Verify capabilities.** Check official current documentation and any available read-only account evidence. For each needed capability—trigger, read, write, identity mapping, history/context, status/receipt, error handling, and rate/permission requirements—record `Confirmed`, `Unverified`, or `Not supported`. Cite the evidence location.

4. **Compare the smallest options.** Consider only:
   - **Native configuration:** an existing product feature meets the outcome.
   - **Manual or operational process:** a controlled human step is sufficient for the current volume.
   - **Small extension:** one connector, webhook, script, or repository change fills a proven gap.
   - **Do not build yet:** the need, data, or proof is insufficient.

   Do not propose a replacement platform, new database, agent fleet, or custom middleware unless the smaller options fail against a stated requirement.

5. **Declare the system of record.** For each object that matters—contact, conversation, job, task, event, status, receipt, or metric—name exactly one current source of truth. State which system may read it, which may create/update it, and how conflicts are resolved. Preserve an existing approved system of record unless an owner explicitly decides otherwise.

6. **Map data and side effects.** Identify the minimum fields, identity key, direction of flow, retention need, duplicate/idempotency risk, failure outcome, and external side effects. Mark every field or API behavior that is not directly verified.

7. **Give a decision, not a vague roadmap.** Recommend the smallest truthful next action: `USE NATIVE`, `RUN A CONTROLLED PROOF`, `BUILD ONE NARROW EXTENSION`, or `DO NOT BUILD YET`. Ask only questions that block that decision.

## Required output

Return this report:

```markdown
# Integration Fit — [Workflow Name]

## Desired Outcome
[Trigger → visible result → owner]

## Systems and Scope
| Role | System | Client/account/environment | Evidence |
|---|---|---|---|
| Current source of truth | | | |
| Proposed source | | | |
| Proposed destination | | | |

## Capability Matrix
| Required capability | Native option | Small extension | Evidence | Status |
|---|---|---|---|---|

## Source-of-Truth and Data Rules
| Object | System of record | Identity key | Allowed flow | Conflict rule |
|---|---|---|---|---|

## Material Risks and Unknowns
| Item | Why it matters | Status | Smallest resolution |
|---|---|---|---|

## Decision
**[USE NATIVE / RUN A CONTROLLED PROOF / BUILD ONE NARROW EXTENSION / DO NOT BUILD YET]**

## Proposed Next Step
[One bounded action. State any approval required before configuration, credentials, webhooks, messages, or production changes.]
```

## Quality bar

A documented feature is not proof that it works for the named account, plan, environment, or required payload. Mark unknowns honestly. Prefer a native path when it meets the outcome, and prefer a controlled proof before an implementation when a single unverified field, permission, or side effect determines success.
