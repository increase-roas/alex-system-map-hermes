---
name: skool-apify-scraper
description: Scrape a Skool classroom or its posts and comments through Composio Apify. Use when Alex asks to scrape Skool or aimoney, or names dz_omar/skool-scraper-pro or memo23/skool-posts-with-comments-scraper
---

# Skool via Apify

Default group: **aimoney** (`https://www.skool.com/aimoney`).

Alex is a paying member. You get the cookies. You run the actor. Do not make him click Cookie-Editor.

## Inputs

| Name | Where |
|---|---|
| Cookies | `~/Downloads/skool-cookies.local.json`. Never inside a skill folder: `~/.agents` is a git repo. |
| Apify login | Composio toolkit `apify` (login `apify_ruby-asor`); no token in the shell |
| Slug | `aimoney` unless he names another |

If the cookie file is missing, get it yourself: computer-use on his logged-in Chrome, or read Chrome Profile 1 (alexx) cookies, then write the file. If computer-use is off, say he can turn it on and you will finish.

## Run

Composio `apify` (connector, or `composio execute <SLUG> --account apify_ruby-asor -d @args.json`):

1. `APIFY_GET_ACTOR` (`actorId`) for the actor's input schema and pricing, then run it.
2. Classroom → actor `dz_omar/skool-scraper-pro`. URL **must** be `https://www.skool.com/SLUG/classroom`. Cheap test: `maxItemsPerSection=3`, `skipLockedCourses=false`, downloads off.
3. Posts → actor `memo23/skool-posts-with-comments-scraper`. Bare URL `https://www.skool.com/SLUG`, `"tab":"classroom"`, `maxItems=10`. Cookies required.
4. Small test runs: `APIFY_RUN_ACTOR_SYNC_GET_DATASET_ITEMS` (`actorId`, `input`, `maxItems`, `maxTotalChargeUsd`). Longer runs: `APIFY_RUN_ACTOR` (`actorId`, `body`), then `APIFY_GET_RUN_DATASET_ITEMS` (`runId`, `limit`, `offset`) in pages. Large datasets go to disk (`apify-dataset-to-disk`).

Apify runs cost money: keep tests small and set `maxTotalChargeUsd`. A full scrape follows the project's `Spend approval:` line; unset means ask Alex first. If Composio `apify` fails, report the error; don't switch to another Apify route.

## Gotchas

- Wrong URL on scraper-pro (bare community, no `/classroom`) silently returns the post wall.
- memo23 rejects the run with no cookies.
- Skool email/password on the actor is dead. Cookies only.
- Empty dataset usually means expired cookies — re-export.
- `downloadVideos=true` is slow and expensive. Leave it off for tests.
