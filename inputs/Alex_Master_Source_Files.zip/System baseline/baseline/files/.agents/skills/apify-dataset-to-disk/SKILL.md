---
name: apify-dataset-to-disk
description: Get large Apify dataset results onto disk without blowing the context window, and avoid the field-projection traps that silently return empty or wrong data. Use whenever calling Apify actors via MCP, fetching dataset items, or when an actor result is too large to read.
---

# Apify results → disk, without wrecking context

MCP tool results land in the model's context, not on disk. A 500 KB dataset is
~130k tokens. This skill is how to move real volume safely.

## The persisted-file pattern (use this by default)

When a `get-dataset-items` result is too large, the harness **automatically
saves it to a file** and returns the path instead of the content. That is not a
failure — it is the fast path.

1. Call `get-dataset-items` with a high `limit` and let it overflow.
2. Read the path from the error/notice.
3. Parse it locally with a Python heredoc through Bash.
4. Write your own organized output files.

Never loop small `offset`/`limit` pages just to keep results small. You pay
context for every page and it is slower.

## Field projection traps

`fields=` looks helpful and causes three distinct silent failures.

### 1. Name collision
Projecting `comment.content` alongside post fields **collapses the dotted name
onto the bare one**, so `content` ends up holding the post body and the comment
body overwrite each other. You get plausible-looking, wrong data.

### 2. Empty objects
On some nested shapes, dot-notation projection returns `[{}, {}, {}, ...]` —
the right number of rows, all empty.

### 3. It hides the real structure
You cannot tell whether a field is a dict, a list of dicts, or a scalar until
you look at raw output.

**Rule: when a dataset has nested objects, fetch RAW (no `fields`) and parse
locally.** Use `fields=` only for flat scalar columns you are certain about,
like counting or listing titles.

### Diagnosing an unexpected shape
```python
i = items[0]
print(list(i.keys()))
print(type(i["suspect_key"]).__name__)   # dict? list? str?
print(json.dumps(i["suspect_key"], indent=1)[:800])
```
Do this FIRST when a parser returns zero rows. Three rewrites were wasted
assuming a dict where the data was a list.

## Polling runs to completion

`call-actor` with `waitSecs` returns while the run may still be RUNNING.
`itemCount` at that moment is a partial.

```
status: "RUNNING"   ->  keep polling get-actor-run
status: "SUCCEEDED" ->  now the count is real
```

Reporting an interim count as the total is an easy and embarrassing error.
Long runs legitimately take 10+ minutes.

## Direct-to-disk alternative (best when available)

With `APIFY_TOKEN` in the environment, bypass the model entirely:

```bash
curl -fsS "https://api.apify.com/v2/datasets/<DATASET_ID>/items?token=$APIFY_TOKEN&format=json" -o out/data.json
```

Without a token this returns HTTP 403. Suggest setting the token once when a
user will be pulling data repeatedly — it removes the context cost permanently.

## Cost sanity
Most actors are pay-per-event and far cheaper than they look. Check whether
child records (comments, replies) bill separately or ride along with the parent
before quoting a price. A "$20" estimate turned out to be 3 cents because
comments came bundled with their post.

Failed items are typically not billed. Testing one input costs nothing, so
**always test one before batching**.
