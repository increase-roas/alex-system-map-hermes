---
name: alex-workflow-conductor
description: Alex's workflow conductor, Claude app pointer. Read and follow ~/.agents/skills/alex-workflow-conductor/SKILL.md on Alex's MacBook. Use only when Alex names the conductor.
---

# Alex Workflow Conductor — Claude app pointer

This upload carries no policy or routes of its own, so it can't go stale. The canonical skill is
`~/.agents/skills/alex-workflow-conductor/SKILL.md` on Alex's MacBook. Read it from disk now and follow it exactly.
Its shared policy is in `~/.agents/skills/alex-director/references/`; read the section you need.

## How Claude reads the Mac files

| Where this runs | How |
|---|---|
| Claude Code on the MacBook (CLI or desktop) | the Read tool on the path |
| Claude app or a cloud session linked to the MacBook | Desktop Commander `read_file` (remote devices) |

## Claude transport (the canonical file covers Codex and Cursor)

- Parallel bounded work: the `Agent` tool, one node per agent, all independent ones in one message.
- A Claude agent's final message is its checkpoint for the lead or Director that started it. Everything else follows
  the canonical Report section.

## If the file can't be read

Say so in one line and make no live writes until it can be read. Keep these boundaries meanwhile: no real-person
contact except Alex's designated test; no spend without Alex's explicit approval; production, DNS or infrastructure
changes and destructive deletion need Alex's approval in this chat; every live write needs exact-target authorization,
deduplication and a readback.

Source of this upload: `~/.agents/skills/alex-workflow-conductor/claude-edition.md`, zipped as `SKILL.md` by
`~/Projects/master-connector-repo/work/2026-10-01_setup-playbook/zips/build_zips.py`. Re-upload only when this pointer
changes; canonical edits need no upload.
