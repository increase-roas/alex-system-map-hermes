---
name: credit-optimizer
description: >
  Automatically optimize AI agent credit usage by routing tasks to the most cost-efficient execution path. Use when you want to reduce AI API costs by 30-75% without quality loss, classify task complexity before execution, route simple tasks to free or low-cost models, split complex tasks into optimized sub-tasks, or detect vague prompts before wasting credits.
---

# Credit optimizer

Classify the task before spending.

- Lookups, formatting, and file moves: cheapest capable path
- Ambiguous asks: one clarifying question, then proceed
- Paid generations: quote the price and wait for a yes
Do not run variations or retries unless asked.

