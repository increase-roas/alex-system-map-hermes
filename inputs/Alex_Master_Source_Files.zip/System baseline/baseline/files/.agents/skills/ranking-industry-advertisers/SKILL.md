---
name: ranking-industry-advertisers
description: Use when finding or ranking the strongest advertisers or likely winning Meta ad creatives in an industry or local market, especially when ad activity, longevity, website traffic, creative evidence, paid-tool costs, or source conflicts must be auditable.
---

# Ranking Industry Advertisers

## Core principle

Separate advertiser strength from creative winner evidence. Ad volume, longevity, traffic, and repeated creative variants are observable proxies; none proves profitability. Define the market and evidence universe, preserve the raw evidence, and label conclusions “observed as of” the verification time.

## Scope contract

Before paid calls, set:

- industry inclusion/exclusion rules;
- geography and service-area proof;
- unit of analysis: Meta page/location by default;
- top-N target, snapshot time, and approved Foreplay credits, Apify dollars, and traffic lookups;
- whether historical ads are relevant. Default ranking uses currently live ads.

## Evidence workflow

1. Load any existing inventory and manifest. Skip reviewed Meta page IDs, domains, and executed queries.
2. Discover broadly with Apify when authorized; use Foreplay for brand resolution and creative evidence. If Apify is unavailable, use Foreplay discovery and record that the covered universe is narrower. Inspect the Apify Actor schema and pricing before running it; cap results and total charge.
3. Deduplicate by exact Meta page ID. Resolve the canonical domain and preserve aliases. Do not merge franchises or locations merely because names or domains resemble one another.
4. Verify industry fit from the landing page, ad copy, or company site. A local address alone does not prove the requested service area.
5. Measure live ads. Prefer a same-date Meta/Foreplay active total. When Apify only proves matching records, store the count as `APIFY_QUERY_MINIMUM`; never present it as the advertiser’s total.
6. Compute complete longevity days from the oldest verified currently live ad start timestamp. Keep the evidence ad and source timestamp.
7. Resolve website traffic with one provider and consistent country/device/month settings. Store the estimate, provider, data period, scope, and coverage. Traffic estimates are not analytics measurements.
8. Save verified, provisional, and excluded rows plus the exact rejection reason. Read [references/output-schema.md](references/output-schema.md) before creating outputs.

## Ranking contract

Rank only rows with verified identity, live-ad evidence, longevity, and a compatible traffic estimate. Keep incomplete rows below the ranking as provisional.

Default composite:

- 45% log-scaled live-ad count
- 25% longevity, capped at 365 days
- 30% log-scaled estimated monthly visits

Run `python3 scripts/rank_advertisers.py INPUT.csv OUTPUT.csv` for consistent scoring. Publish the component values, count source, weights, cohort, and verification date. If the user chooses different weights, record them and adapt the calculation transparently.

The script rejects duplicate Meta page IDs and requires the evidence fields in the schema, a total-count source, and one compatible traffic provider/period/scope across ranked rows. `APIFY_QUERY_MINIMUM`, missing traffic coverage, incomplete identity, and incomplete evidence remain provisional. It also reports rank spread under ads-heavy, longevity-heavy, and traffic-heavy weight sets. Review `sensitivity_flag`; explain unstable top-N rows instead of presenting the default ordering as robust.

## Winning picture-ad mode

After ranking advertisers, collect the eligible picture ads for the strongest companies. One evidence ad per company is not enough in this mode: enumerate the available live image ads within the approved credit cap.

There are two proof levels:

- `PROVEN_WINNER`: directly inspected, authorized first-party outcome data such as conversions, qualified leads, revenue, CPA, or ROAS supports the claim. Store the metric, value, measurement and attribution windows, source artifact, evidence URL, verification status, and timestamp. User-provided prose or an unsupported CSV claim is not verification.
- `MULTI_SIGNAL_WINNER_PROXY`: no outcome data exists, but the ad has persistent runtime, active sibling variants in the same creative family, and comes from a strong advertiser. Never shorten this label to “proven winner.”

Default picture format is a single static `image`. Include carousels or `multi_images` only when the request says to. Deduplicate exact ad IDs, then group clones and minor variations by a deterministic `creative_family_id` based on normalized hook, offer, and visual asset/hash. Present one representative per family with the family size.

Read [references/ad-output-schema.md](references/ad-output-schema.md), then run `python3 scripts/rank_ads.py ADS.csv advertisers-ranked.csv winning-picture-ads.csv`. The script resolves every ad to the current advertiser output, computes the family key and active family count from verified live rows, and rejects duplicate ad IDs. The proxy score is:

- 50% individual ad runtime, capped at 365 days;
- 30% log-scaled count of active variants in the same creative family;
- 20% verified advertiser strength.

An ad needs at least 30 live days and two active family variants to receive `MULTI_SIGNAL_WINNER_PROXY`. Otherwise it may remain ranked as observed evidence but is labeled `INSUFFICIENT_WINNER_SIGNALS`. `PROVEN_WINNER` additionally requires direct inspection of an authorized first-party artifact, complete performance fields, `verified_first_party`, a durable evidence pointer, and a verification timestamp. Without that verification, the label is `OUTCOME_EVIDENCE_UNVERIFIED`. Explain the hook, offer, format, CTA, and the exact signals behind every top ad. Review the ad-level `sensitivity_flag` before claiming the ordering is stable.

## Credit and stop rules

- Check account usage before and after paid batches.
- Use discovery results to create a deduplicated validation queue before per-company calls.
- Cache calls by provider, query/ID, filters, and date. Do not repeat an identical paid lookup.
- Validate one evidence ad per company unless a conflicting identity or count requires more.
- Stop when the budget is reached, pagination is exhausted, two consecutive discovery batches yield no new qualified page IDs, or remaining candidates cannot enter the requested top N.
- A failed or partial provider response stays unknown; it never becomes zero and never silently triggers an incompatible substitute.

## Required deliverables

Produce:

- ranked CSV with auditable components;
- `winning-picture-ads.csv` with one representative per creative family, proxy components, image/evidence URLs, hook, offer, CTA, and proof label;
- readable Markdown summary with the top advertisers and caveats;
- JSON manifest containing queries, raw-artifact pointers, exclusions, costs/credits, timestamps, and stop reason.

Use a stable run folder: `outputs/<industry-slug>/<market-slug>/<YYYY-MM-DD>/`. Name the files `advertisers-ranked.csv`, `winning-picture-ads.csv`, `summary.md`, `manifest.json`, and place provider responses under `raw/`. When requested, save selected image assets under `creatives/` or upload them to the requested Drive folder.

## Common mistakes

- Calling an advertiser or creative a “winner” without profitability data.
- Filling a top-ad list with duplicate IDs or near-identical creative variants.
- Ranking an ad from query position, current live status, or advertiser traffic alone.
- Ranking query matches as total live ads.
- Mixing traffic providers, months, countries, or device scopes without labeling them.
- Ranking missing traffic as zero.
- Double-counting a company because page names or tracking domains differ.
- Repeating paid discovery instead of resuming from the manifest.
