---
name: meta-hammer-them
description: "Build or template Alex's Hammer Them (Hammerhead) Meta strategy through Composio metaads: one video per ad set with its own 3-second-viewer exclusion, plus companion cold campaigns."
---

# Hammer Them and companion cold campaigns

Alex uses **Hammer Them** to mean a specific video-retargeting structure, not generic high-frequency retargeting. Recognize “Hammerhead videos” as this workflow when context supports it. Do not ask Alex to re-explain the strategy or reconfirm account/scope already settled in the task.

## Meaning and routing

- **Hammer Them campaign:** for each selected logical video, create one video-viewer audience, one ad set, and one ad showing that video. Exclude that video's audience from its ad set. The trigger is **at least 3 seconds watched**. Use a **365-day retention reference**, unless the task specifies otherwise; read back the actual new rule.
- **Cold + Hammer Them setup:** two distinct campaigns. Put the designated cold/top-of-funnel assets in the cold campaign using the validated prospecting reference structure. Put objection/retargeting assets in Hammer Them. Do not apply Hammer's one-video-per-ad-set shape to cold automatically.
- A request for Hammer Them alone does not authorize a new cold campaign. If the user requests the complete system, include both, and establish which destination audiences connect cold engagement/site activity to Hammer Them.
- Viewers become ineligible for a video after Meta reflects audience membership. Other unseen videos remain eligible. This is **unordered rotation**, not a guaranteed instant 1→2→3 sequence.

For installation or template preparation, read [build-workflow.md](references/build-workflow.md). For Paradise Spas or The Hot Tub Store, also read [paradise-hot-tub-reference.md](references/paradise-hot-tub-reference.md). That file separates dated evidence from reusable rules; refresh only facts material to the requested action.

## Essential invariants

1. Use Composio `metaads` and the `meta-ads` skill for account scoping and safety. Composio holds the token; never expose it. Prefer the built-in `METAADS_*` tools; report genuine capability gaps rather than disguising them as completed work. A create or update tool that Composio holds for approval or restricts is a denial: stop and report, never route around it.
2. Every Hammer input maps to its own ad, ad set and excluded custom audience. Audience source IDs must cover all delivery video IDs for that logical video, including placement variants, and no unrelated videos. Verify IDs and rules rather than trusting matching names.
3. Use **Finished video link**, not the raw Source link, when that distinction exists. Preserve row IDs. Separate supplied copy alternatives; never paste all variants into one standard ad.
4. A source campaign is a structural reference. Remap destination Page, Instagram identity, pixels/events, audience IDs, ZIPs, URLs, tracking and dates. Keep intentional structure and settings, and explicitly explain unavoidable adaptations. Never silently borrow another client's assets or geography.
5. Default every created campaign, ad set and ad to explicit `PAUSED`, and verify delivery status. Creative assets are different: on 2026-09-23 the Meta API rejected creative `PAUSED` and listed only `ACTIVE`, `IN_PROCESS`, `WITH_ISSUES`, and `DELETED`, despite the old CLI offering a PAUSED flag. An ACTIVE creative without an active ad does not deliver or spend. Record its actual asset status; do not claim it is paused or repeatedly retry an unsupported status. Installation and activation are separate. Do not spend, unpause or change live ad delivery without the user's applicable instruction.
6. Reconcile saved IDs and exact names before creation. Save returned IDs immediately. Reconcile ambiguous writes read-only before retrying. Stop the batch on a failed or incorrect write and report valid partial work.

When Alex has authorized an explicit PAUSED draft, finish a concrete reviewable draft with clearly labeled provisional configuration values where the platform requires them. Do not invent a second permission gate for a documented implementation choice or a provisional paused budget. A proposed value does not authorize activation or spend, and it does not independently authorize an optional additional campaign.

## Video-viewer audiences

On 2026-09-23 the Hot Tub Store build created nine viewer audiences through a `meta` CLI extension that is no longer a route. With Composio, create them with `METAADS_CREATE_CUSTOM_AUDIENCE` (not yet run through Composio: prove one on a paused build first). Official Graph rule: `subtype=ENGAGEMENT`, `retention_days=365`, `rule=[{"object_id":"PAGE_VIDEO_ID","event_name":"video_watched"}]`. Meta defines `video_watched` as at least three seconds or nearly the full video if shorter.

Account `/advideos` upload IDs can differ from the Page-video attachment target IDs required by this rule. Resolve an existing creative's `effective_object_story_id` to its attachment target using authorized Page context; do not guess IDs or re-upload. A successful system-user upload does not prove the same credential context can read Page posts. Never expose Page tokens. When final creatives create additional Page-video targets, audience coverage must include those delivery variants.

## Verified ODAX video-view contract (2026-09-24)

For `OUTCOME_ENGAGEMENT` with `THRUPLAY`, set the ad set's `destination_type=ON_VIDEO`; no Page `promoted_object` is required. The URL/LEARN_MORE action lives in the video creative and is distinct from this conversion location. In the Hot Tub Store build, `UNDEFINED` allowed paused set creation but failed ad creation; updating the existing set to `ON_VIDEO` preserved targeting/budget/optimization and allowed the actual paused ad to save. Page promoted-object repairs were invalid for this pairing. Do not switch to clicks merely to make an ad save.

Official ODAX mapping: https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-campaign-group#odax-mapping . A created set with correct-looking readback is not end-to-end proof: verify at least one actual paused ad attaches before batching the structure. Error messages from an invalid conversion-location configuration do not prove a general URL requirement for valid video-view ads.

## Choosing the best cold reference

When asked for the best-performing cold campaign, use a stated, consistent reporting period and the actual business outcome. Verify cold targeting from the ad sets, not just the campaign name. Compare spend, conversion/lead count, cost per result and sample size; use revenue or qualified outcomes if available. Treat overlapping Meta action types as alternative measurements, not additive leads. Separate differing objectives, attribution windows and conversion destinations. Do not equate cheapest views or clicks with best lead/sales performance.

Explain the winner and its limits. A high-volume historical winner and a recent winner can differ. “Same exact way” means reproduce the verified campaign mechanics with the user's destination inputs; it does not mean copy source budgets, ZIPs or business-specific IDs without checking their applicability. If the chosen source is DCO/automatic format but the destination plan uses standard ads, label that as an explicit adaptation and do not claim an exact clone. When the standard-ad shape is the documented implementation of the user's requested ad count, it may be staged in the authorized PAUSED draft without another ceremonial approval.

## What counts as done

- **Skill installed:** files are discoverable locally and pass the skill validator. This does not prove automatic triggering in an already-open task or working Meta automation.
- **Template prepared:** source findings, row mapping, settings and unresolved inputs are saved.
- **Campaign installed:** all intended Meta objects exist and relationships/settings/statuses pass authoritative readback.
- **Live:** separately authorized activation has occurred and delivery status is observed.

Keep the Google Sheet as the editable source for videos/copy/setup, Meta as the live configuration source, and one build receipt as the ID/recovery record. Do not create competing active input stores. No recurring monitoring is implied; report if ongoing checks still depend on the campaign owner.
