---
name: self-improvement
description: >
  Captures learnings, errors, and corrections to enable continuous improvement. Use when: (1) A command or operation fails unexpectedly, (2) User corrects Claude ('No, that's wrong...', 'Actually...'), (3) User requests a capability that doesn't exist, (4) An external API or tool fails, (5) Claude realizes its knowledge is outdated or incorrect, (6) A better approach is discovered for a recurring task. Also review learnings before major tasks.
---

# Self-improvement

When something fails or the user corrects you, write the lesson down in a durable note the next session can read.

## Capture
- What was tried
- What was wrong
- The rule to follow next time
Keep it one paragraph. Do not write a postmortem essay.

