# Concepts

Shared domain vocabulary for this project — entities, named processes, and status concepts with project-specific meaning. Seeded with core domain vocabulary, then accretes as ce-compound and ce-compound-refresh process learnings; direct edits are fine. Glossary only, not a spec or catch-all.

## Director control plane

### Director

The single supervisory Codex task that owns the mission ledger, judges controller results against frozen outcomes, and alone declares mission completion.

### Native Director heartbeat

The product-native scheduled turn attached to the Director that periodically reconciles every active mission; it is the control plane's sole periodic scheduler.

### Receipt wake

A foreground event-hook request that queues the existing Director when durable controller evidence needs prompt reconciliation; it is neither a second Director nor a periodic scheduler.
