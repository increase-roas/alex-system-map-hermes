# STACK — what you have and where it lives

**Owner:** Alex · **Updated:** 1 Oct 2026 · **Home:** `~/Alex-Director/STACK.md` (private repo `increase-roas/alex-director`); `~/STACK.md` is a symlink to it.
**Approvals:** `~/.agents/instructions/shared.md` for every AI (generated into each AI's instructions) and the Director's `references/gates.md` for missions. [`sop.md`](/Users/alexlobaito/sop.md) is historical (HTL factory deploys only).
**Routes:** the tool cards in `~/.agents/tools/cards/` and the connectors workbook win on how each app is reached; this file only points at them. [`STACK_DETAIL.md`](/Users/alexlobaito/Alex-Director/STACK_DETAIL.md) is a 2 Sep 2026 inventory kept for history. **No secrets in any of these files.**

## Roles (connectors workbook, AI apps tab, verdict column, 2026-10-01)

| AI app | Runs where | Verdict |
|--------|------------|---------|
| Claude Code (desktop + CLI) | Mac (cloud sessions possible) | KEEP: operator for connectors, infrastructure, browser and computer tasks |
| Codex | Mac + cloud tasks | KEEP: coding and cloud tasks (Alex sends work here) |
| Cursor | Mac | KEEP: IDE and coding (Alex sends work here) |
| Hermes / Javar (Orgo) | Cloud (Orgo) | KEEP: always-on agent |
| OpenClaw hub (Orgo) | Cloud (Orgo) | KEEP: hosting |
| Claude app (claude.ai / desktop chat) | Cloud + Mac app | REPLACE as a work surface: phone/chat only, Composio connector only |
| Claude Desktop legacy config | Mac | RETIRE the local config: remove both entries (flagged) |
| ChatGPT connectors (Increase ROAS GoHighLevel, Notion, Slack, Google Drive) | Cloud | RETIRE: Alex removes all 4 in ChatGPT |
| Manny's and Anthony's AI apps (contact@, anthony@) | not checked | SAME RULE: 1Password + Composio |
| Mac CLIs (meta, op, gcloud, orgo, composio; Parallel dropped) | Mac | MOVE jobs to Orgo |

Master copy of the workbook: `~/Projects/master-connector-repo/work/2026-09-30_composio-connect/connectors-2026-09-30.xlsx` (the copy in `~/Documents` is generated). Alex owns outcomes, money, protected clients and the yes for anything the approval rules reserve for him.

## Control plane (one, reuse it)

| Piece | Where |
|-------|-------|
| Global router | `~/.agents/instructions/` → `~/.agents/tools/unify/build_instructions.py` → `~/.codex/AGENTS.md` and `~/.claude/CLAUDE.md` (generated: edit the sources, never the generated files; still no `~/.zshrc` / LaunchAgents / `/etc`) |
| Director ledger | `~/Alex-Director/DIRECTOR_STATE.md` |
| Mission graphs | `~/Alex-Director/mission-graphs/` |
| Heartbeat | No standing Director heartbeat. Scoped check-ins are made per supervision request and listed in `~/.codex/automations/`. Other schedulers: Claude scheduled task `connector-repo-tuneup` (every 8 hours) and the connector health check on Orgo My OpenClaw (every 30 minutes, source `~/.agents/tools/connectors/health/`) |
| Director / conductor skills | `~/.agents/skills/alex-director`, `~/.agents/skills/alex-workflow-conductor` (mirror in `~/Alex-Director/skills/`; the Claude app gets thin pointer uploads) |
| Compound Engineering | Cursor plugin `compound-engineering` v3.21.0. Controllers use `ce-debug` / `ce-work` / `ce-compound` when those close the gap. Not a second Director. |
| One-Shot Builder | `~/Documents/One-Shot-Builder` (`increase-roas/one-shot-builder`) — rules, wizard, `WORKFLOW.md`. Live optimizer cycles write here. Agent OS Optimization artifacts are historical setup evidence only. |
| Secrets | 1Password (agent keys in the Connectors vault; scripts read them with the read-only `connectors-sync` service account). Never in files, Git, or chat. |

## Your computers

| Machine | What it is | What lives there |
|---------|------------|------------------|
| **MacBook Pro** | Daily laptop (`alexs-macbook-pro` on Tailscale) | Cursor, Codex / ChatGPT, **Hermes Cloud app**, Claude, Chrome, Slack, 1Password |
| **Orgo — Javar** (computer **EA**, `d9b475e2-47b2-46d4-b8eb-102564f93283`, Tailscale `javar-orgo`) | Cloud Linux box, **running**, always-on, `hermes-agent` terminal | **Main Hermes** lives here |
| **Orgo — IR Ops** (workspace **IR 1**) | Cloud Linux box, **frozen**, 3 members | Older ops desktop. Not the live Hermes. |
| **Orgo — B2B Sales Agent** | Cloud Linux box, **running**, also has `hermes-agent` | Separate sales Hermes. Do not mix with ops. |
| **Orgo — CSM** | Cloud Linux box, **running** | Customer-success box |
| **Orgo — fast-pulse** | Workspace only, **no computer** | Empty |
| **Mac mini** | On Tailscale as **`sashas-mac-mini`** | Home machine. Not the daily ads box. Do not send deploys here unless you name it. |

Also on Tailscale: this MacBook, the mini, your iPhone, another MacBook Air (not yours). Default host for command-center work is the **MacBook Pro**. Do not send ads or site deploys to Orgo or the mini unless you name that machine.

## Where each app is reached

Every AI reaches apps through Composio (`composio search "<task>"`, then `composio execute`; chat surfaces use the Composio connector or app). Before the first call to an app, read its card: `~/.agents/tools/cards/<name>.md`. The card index is generated into `~/.claude/CLAUDE.md` and `~/.codex/AGENTS.md`; on any other machine use Composio `CUSTOM_IR_NOTES_GET_APP_RULES`. The workbook's All connections tab lists every app.

| App | Route (from the card or the shared rules) |
|-----|-------------------------------------------|
| Cloudflare | Composio `custom_cloudflare_api` (whole API via SEARCH / EXECUTE / DOCS) — `cloudflare.md` |
| GA4 + GTM | Composio `custom_ga4_admin` acting as alex@; GTM publish asks Alex — `ga4.md` |
| GoHighLevel | Composio `custom_ghl_oauth_crm` for CRM (pass `locationId`); `custom_ghl_command_builder` only for workflows, funnels, forms, pipelines — `ghl.md` |
| GitHub | Composio `github`, account `github_lipase-modern` (increaseroasir) — `github.md` |
| Google Ads | Composio `googleads` via manager account 1640283674 — `google-ads.md` |
| Google Workspace | Composio `custom_google_robot` acting as any increaseroas.com user — `google-workspace.md` |
| Meta Ads | Composio `metaads` system user (57 ad accounts) — `meta-ads.md` |
| QuickBooks | Composio `quickbooks`, always name the company — `quickbooks.md` |
| Slack | Composio `slack`, account "Alex Slack Account"; clients, customers and Lone Star ask Alex — `slack.md` |
| Web search and page reads | Composio `exa` (`EXA_SEARCH`, `EXA_GET_CONTENTS_ACTION`) — `exa.md`; built-in search only as fallback — `web-search.md` |
| Official docs | Composio docs readers (Context7, OpenAI Docs, Astro Docs, Qt docs), else an Exa page fetch |
| Crawling or scraping a site | Firecrawl CLI |
| Alex's past material | AI Money archive (Cloudflare AI Search `aimoney-archive`) through Composio `custom_cloudflare_api` |
| Pages behind a login, desktop apps | one browser or computer-use route per job — `browser-and-computer.md` |
| Secrets | 1Password (`op`; scripts through `connectors-sync`) |
| Composio itself | quirks, REST calls, key mover; in Claude Code run the CLI outside the sandbox — `composio.md` |

Javar's agents keep their fenced routes (`javar_ghl`, `javar_meta`, `javar_propose_message`).

## Hermes — three places, one job

Hermes is a **small always-on assistant**: status, gold docs, Company-Ops vault. Not ads. Not GHL writes unless a separate card says so.

| Place | Use it for |
|-------|-----------|
| **Hermes on Orgo (Javar, `javar-orgo`)** | The real always-on brain |
| **Hermes Cloud on the MacBook Pro** | How you talk to Hermes from the laptop |
| **B2B Sales Hermes (Orgo)** | Sales only. Separate memory. Do not mix. |
| **Mac mini** (`sashas-mac-mini`) | Spare / vault / remote. Old SOP assumed Hermes lived here. |

**Do not** run two Hermes processes that share the same memory. Talk to Hermes like a brief: one outcome, one named gold file, one proof. Codex can *read* Hermes docs via `hermes-docs`; Codex does not *become* Hermes. Full rules: [`HERMES_SOP.md`](/Users/alexlobaito/HERMES_SOP.md).

## Repos and live sites

**Repos:** `31-htl-factory-control` (factory), `32-htl-website-template` (template), `40-client-sun-pool-spa` (protected), `increase-roas-os`, `paradise-spas-website`, `one-shot-builder`, `alex-director` (all under `github.com/increase-roas`, private).

**Live sites:** Cloudflare. Deploy only with `wrangler` from `dist-prod/` (secrets piped from 1Password); other Cloudflare API work goes through Composio `custom_cloudflare_api`. Proof is `/api/readiness` + a test lead — not "the page loaded."

## Hard stops

- No passwords or tokens in this file or in chat.
- Do not unpause ads or start spend unless you name the account that day.
- `sun-pool-spa` is protected. No agent writes without break-glass.
- GHL / Make / Supabase / Cloudflare **production writes** stay off until a phase card names the exact account + action.
- Hermes does not bid, does not write live Drive, does not become the ads tool.
- Meta Ads go through Composio `metaads` only: not the `meta` CLI and not Meta's hosted MCP (`mcp.facebook.com/ads`).
- One Director, one ledger, no standing heartbeat. New project ≠ new control plane.

## If you only remember four lines

1. **Claude Code** operates (connectors, infrastructure, browser and computer tasks). **Codex** codes and runs cloud tasks. **Cursor** is the IDE. **Hermes** is the always-on agent. The **Claude app** is phone and chat only.
2. Hermes **runs on Orgo (Javar, `javar-orgo`)**. You talk to it from the **Hermes Cloud app on the MacBook Pro**. Mini is `sashas-mac-mini` on Tailscale.
3. Every app goes **through Composio**; its rules are in `~/.agents/tools/cards/<app>.md`. Meta = Composio `metaads`.
4. Approvals live in `~/.agents/instructions/shared.md` and the Director's `gates.md`. Missions live in `~/Alex-Director/DIRECTOR_STATE.md`.
