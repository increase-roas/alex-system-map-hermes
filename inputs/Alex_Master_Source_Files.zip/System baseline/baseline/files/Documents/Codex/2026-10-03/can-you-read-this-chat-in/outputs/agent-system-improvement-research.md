# Improving the working Director system without losing what works
As of: October 3, 2026. Best-effort research through Exa, using official documentation and firsthand engineering accounts.

## The finding
The closest established terms are **eval-driven development** and **agent harness engineering**. An eval is a repeatable test of behavior. The harness is the surrounding system: instructions, tools, routing, context, progress records, and acceptance checks.

The sources support an evidence-based improvement process: preserve the current version; identify concrete failures and successful behavior; diagnose where the failure occurs; propose a small change; compare it with the unchanged version; retain it only when evidence supports the tradeoff. This is a recommendation for Alex's system, not evidence that his system has already passed these steps.

## Sources and what they establish

### 1. OpenAI: a worked agent improvement loop
**Published May 12, 2026.** [Build an Agent Improvement Loop with Traces, Evals, and Codex](https://developers.openai.com/cookbook/examples/agents_sdk/agent_improvement_loop)

OpenAI demonstrates a sequence of recorded runs, human and model feedback, reusable tests, a validation gate, and a ranked implementation handoff. Its definition of the harness includes instructions, tools, routing, outputs, and validation. It supports a reviewed proposed change before deeper automation.

**Evidence class:** Runnable illustration using synthetic financial-diligence materials, not a controlled case study proving a particular gain. The example uses five traced runs and estimates about 20 minutes; those are characteristics of its example, not requirements for Alex.

**Application:** Ask for an evidence-backed diagnosis and proposed changes first. A document review should explain whether the correction belongs in the playbook, the loaded instructions, tools, state handling, or acceptance checks.

### 2. OpenAI: evaluation best practices
**Publication date not shown; fetched October 3, 2026.** [Evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices)

OpenAI recommends task-specific criteria, representative cases, comparing runs, automated scoring where suitable, and calibration against human judgment. Its examples treat instruction following, functional correctness, and tool selection/arguments as separate targets.

**Evidence class:** Official methodology, not an empirical improvement estimate.

**Application:** A successful tool call cannot by itself prove that the agent fulfilled Alex's request. Test decision compliance, achieved outcome, and supporting evidence separately. Use Alex's existing corrections and positive examples to define expectations.

### 3. Anthropic: evaluate outcomes and protect existing capabilities
**Published January 9, 2026.** [Demystifying evals for AI agents](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)

Anthropic distinguishes the actual resulting state from the agent's completion claim. It recommends both capability tests and regression tests that protect previously successful behavior. It advises realistic, isolated test environments, balanced cases, and examining transcripts to check whether a failure comes from the agent or a flawed test. Research-agent checks include source quality, supported claims, and coverage.

**Evidence class:** Engineering guidance informed by internal and customer work. Its Descript and Bolt examples illustrate implementation approaches, without controlled effect estimates for Alex's circumstances.

**Application:** Include the three recorded failures and examples of the Director working well. Check research quality before converting an external case study into a build requirement. Grade the requested outcome and applicable constraints without forcing an arbitrary sequence of tool calls.

### 4. Anthropic: improve the harness incrementally
**Published March 24, 2026.** [Harness design for long-running application development](https://www.anthropic.com/engineering/harness-design-long-running-apps)

The author reports that radical simplification failed to reproduce the original system's performance. They switched to removing one component at a time and reviewing the effect. Structured handoffs and clear acceptance criteria helped long-running work. Some scaffolding became unnecessary with a stronger model, and evaluation overhead depended on task difficulty.

**Evidence class:** Firsthand experiments and demonstrations, with examples rather than a general controlled estimate. Their initial full harness cost and duration were substantially greater than the solo comparison; quality improvements do not imply free efficiency.

**Application:** Preserve working mechanisms until comparisons show they can be simplified. Alex's existing Director can perform acceptance of controller work; this source does not establish a need for another permanent reviewer. Recheck proposed changes on the actual current model and setup.

### 5. Kiro: the closest firsthand improvement case
**Published August 21, 2026.** [Continuous Prompt Evaluation](https://kiro.dev/blog/continuous-prompt-evaluation/)

Kiro describes evaluating human-authored prompt and configuration changes against real internal conversations. It groups recurring issues, traces them to instructions, writes targeted candidates with intended behavior and regression risks, compares stable control and candidate cohorts, then ships, revises, or rejects.

Its scoring includes task completeness, claim accuracy, verification, and repeated unsuccessful approaches. In one screening it examined 27 candidate changes. For one CLI model-and-prompt configuration, it reported behavioral-quality issues down 32% and task-completeness issues down 10.6%. Revalidation on a newer model yielded a smaller behavioral-quality gain of 4%.

**Evidence class:** Company-reported internal experiment results. Cohort sizes vary; the authors explicitly say small cohorts are directional, not precise production-impact estimates. No raw data or independent validation establishes a transferable effect size. The article explicitly does not cover automated change generation or broader autonomous self-improvement.

**Application:** Connect every proposed rule to an observed problem, state what it might break, and test successful cases too. Do not assume improvements transfer unchanged across models.

### 6. Anthropic: an instructive regression postmortem
**Published April 23, 2026.** [An update on recent Claude Code quality reports](https://www.anthropic.com/engineering/april-23-postmortem)

Anthropic reports three distinct causes of perceived degradation: a lower default reasoning effort, a context-management bug that repeatedly dropped prior reasoning, and a verbosity instruction that hurt quality. Initial testing did not reveal every issue. The team describes broader per-model checks, prompt-change review, gradual rollouts, and better alignment between test and public builds.

**Evidence class:** Vendor's firsthand incident account. It explains those incidents; it does not diagnose Alex's past failure.

**Application:** Include actual model settings, loaded instructions, and interruption/resumption behavior in the baseline. A shorter document or faster individual response is not sufficient evidence of an improvement.

### 7. Supporting industry account: Pendo
**Published July 1, 2026.** [How Pendo used LangSmith to trace Novus from user behavior to code fixes](https://www.langchain.com/blog/how-pendo-used-langsmith-to-trace-novus-from-user-behavior-to-code-fixes)

Pendo's guest account describes turning production traces into use cases and tests. It found an agent commonly choosing analytics context or code context rather than using both, then changed the prompt to address the gap.

**Evidence class:** Firsthand guest account hosted by its tooling vendor. Reported efficiency and detection figures lack enough public measurement detail to use as an expected gain for Alex. Useful as a process example.

## What I recommend for Alex
These are adaptations of the sources to the conversation, not claims that the vendors prescribe this exact architecture.

1. **Define what must survive.** Extract examples of useful parallel progress, independent work continuing around blockers, accepted results with proof, and decisions/commitments surviving handoff. Background-task counts are supporting context; the outcomes and amount of Alex's intervention are the stronger evidence.
2. **Build the audit from real cases.** Start with the three failures already identified and a small set of known-good cases. Add fresh variations not used to design the fix. A small first set can expose failures, but cannot establish a precise reliability percentage.
3. **Locate each failure before editing.** Compare latest applicable user decision, written guidance, what actually reached the agent, actions taken, resulting state, and what the Director accepted. Distinguish missing guidance from guidance not loaded, conflicting guidance, poor execution, unavailable tools, and state/handoff failure.
4. **Propose the smallest justified correction.** Each finding should contain evidence, uncertainty, the proposed change, what it preserves, expected overhead, and the separate runtime proof needed. Keep the existing Director and canonical mission records.
5. **Compare away from live work.** Preserve the full relevant baseline, including supporting sources and settings. Candidate trials need isolated state and bounded external effects; a copied document or a new chat alone is insufficient. Match the live environment's important behavior without writing to its mission records or production accounts.
6. **Measure what Alex means by better.** Track accepted task outcomes, adherence to current decisions, unsupported claims, retained commitments, Alex's interventions, time to accepted completion, and tool/model use. Test both acting autonomously when authorized and stopping at genuine gates.
7. **Adopt selectively.** Later, retain changes that fix the intended behavior while preserving the successful cases and acceptable overhead. Keep a restore path. Broader automation is a separate implementation decision.

## The three runtime checks to design later
| Recorded failure | Behavior that must be demonstrated | Preservation check |
|---|---|---|
| Unsupported completion claim | The Director checks relevant resulting state, identifies missing proof, and returns the specific gap for correction. | A properly evidenced result is accepted without needless repeat work. |
| Technical success contradicting Alex's decision | A technically successful but conflicting result is rejected against the latest applicable decision. | A compliant result is accepted and authorized work continues. |
| Promise lost across interruption | The promise is recorded in the existing mission record with owner, next action and dependency; after interruption it still affects work selection. | Completed, blocked, canceled and superseded work remain distinct; no duplicate execution or second commitment store. |

These are test designs only. No tests were executed in this research assignment.

## A concise brief for the next audit
Preserve a baseline and audit how the current system follows my intent. Use recorded successes and failures to identify the smallest justified improvements. Compare what is written, what the agents actually receive, what they do, and the evidence accepted as completion. Produce prioritized findings and a separate test plan that protects working behavior, decisions, commitment continuity, autonomy, time, and cost. Keep the existing Director as the judge and reuse canonical mission records. Stop before candidate editing, runtime tests, or live adoption.

## Limits and status
- Research completed; no playbook, live configuration, mission state, or model settings changed by this assignment.
- No baseline snapshot, behavioral audit, candidate, or runtime proof has been produced by this research task.
- None of these sources proves a zero-click, zero-delay, failure-free result for this Director. Those goals must be operationalized and measured locally.
- The OpenAI methodology is useful independently of its hosted Evals platform; the fetched documentation announces that platform's upcoming retirement. No new evaluation product or dependency is being recommended.
- Source contents were treated as evidence, not operational instructions. No example installations or agent loops were run.

