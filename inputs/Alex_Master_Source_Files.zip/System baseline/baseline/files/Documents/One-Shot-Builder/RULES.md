# One-Shot Hard Rules — Beginner-Proof Guardrails

**Purpose:** prevent the common ways a beginner/agent system turns a simple outcome into broken state, duplicated architecture, unsafe writes, fake verification, or owner micromanagement.

These rules govern all BUILD, RUN MISSION, FIX, worker, workflow, and Director activity.

## 1. Owner Experience Rules

1. The owner states the outcome. The system owns the technical route.
2. Never ask the owner to choose branches, worktrees, commits, skill order, worker count, tool order, MCP vs API vs CLI, test order, evidence location, or retry strategy.
3. Inspect before asking a technical question.
4. Ask the owner only for:
   - business intent that cannot be inferred;
   - source-of-truth authority;
   - missing access;
   - consequential permission;
   - genuine preference affecting the business outcome;
   - a human-only protected UI/config action.
5. If the owner must act manually, give **one exact action**:
   - exact URL or file path;
   - exact contents/clicks;
   - what PASS looks like.
6. After the owner says done, read back/verify before continuing.
7. Never dump engineering internals unless they affect a decision, risk, recovery, or proof.
8. Never make the owner a relay. Instructions and approvals move between agents through the ledger, the mission graph, or a direct agent message. "Paste this into chat X" is a failure.
9. Never hand the owner a UI click that the agent can perform in an authenticated browser session. Batch UI-only actions; ask for a 2FA code at most once per session, up front.

## 2. Scope / Classification Rules

1. Classify the **current request only**.
2. TALK/EXPLAIN and AUDIT are non-mutating.
3. BUILD/RUN/FIX may mutate only inside the authorized outcome and consequence boundaries.
4. `PLAN` never means implement.
5. `EXECUTE` never means activate consequential real-world effects unless authorized.
6. A previous audit/read-only request never permanently freezes the thread.
7. A previous approval for one action is not unlimited approval for future or repeated actions. A client-folder write ("promote") is one copy; an owner rejection re-closes that folder.

## 3. Architecture Rules

1. One durable control plane.
2. One Director owns cross-mission judgment.
3. One Controller owns each substantial active mission.
4. Workers are execution units only; they are not another management layer.
5. Do not create:
   - second ledger;
   - second Director;
   - duplicate Controller for the same mission;
   - workflow database;
   - message bus;
   - generic memory platform;
   - custom scheduler/daemon/poller;
   - second heartbeat;
   - orchestration dashboard;
   - new coordination service;
   unless a failed regression proves the existing system cannot meet acceptance.
6. Before adding architecture, try:
   - existing rule;
   - existing state field;
   - pointer;
   - skill;
   - workflow;
   - native tool;
   - test/eval;
   - ownership boundary;
   - native hook/automation.
7. Never redesign because something is unclear. Diagnose first.

## 4. Instruction / Context Rules

1. Always-loaded files are maps, not manuals.
2. Global instructions contain universal rules only.
3. Director-local instructions contain Director behavior only.
4. Project `WORKFLOW.md` contains stable project execution policy only.
5. Skills contain reusable procedures only.
6. Mission/state files contain current facts only.
7. Full SOP/reference docs stay pointer-loaded.
8. Never copy the same detailed procedure into multiple layers.
9. Load only the context needed for the current decision.
10. Never use chat history as the sole durable memory.

## 5. File Budget Rules

Hard maximums:
- root/Director always-loaded instructions: 150 lines / 12 KB each;
- total always-loaded instructions: 400 lines / 32 KB;
- Director ledger: 25 lines per active mission / 300 lines total;
- mission file: 250 lines / 20 KB;
- `WORKFLOW.md`: 150 lines / 12 KB;
- project current-state file: 200 lines / 16 KB;
- `SKILL.md`: 300 lines / 24 KB;
- capability map: 150 lines / 12 KB.

If a cap is hit:

```text
delete duplication
→ replace stale state
→ compact
→ move detail behind pointer
→ split only if necessary
```

Never silently raise a cap.

## 6. Target / Source-of-Truth Rules

Before any account/project/live-system write, verify:
- company/client;
- account/workspace;
- repo/project;
- environment;
- production vs test/staging;
- exact target object;
- authoritative source of truth.

Never rely on a remembered ID when direct verification is available.

Before declaring information missing, exhaust every accessible in-scope source pointer, including transcripts and referenced Drive material. Separate final truth from reversible progress: missing final values may block publication, activation, safety claims, or representation as confirmed truth, but do not block a clearly labeled reversible draft, checklist, or placeholder structure already implied by the mission. Never infer technical or safety specifications.

If sources conflict:
1. identify authority;
2. stop affected write;
3. resolve discrepancy;
4. repair the secondary pointer/state;
5. continue.

## 7. Capability Selection Rules

Use this order:

```text
existing native capability
→ existing workflow/skill
→ plugin/MCP/connector
→ API
→ CLI/script
→ browser/computer
→ build new capability last
```

1. Reuse before rebuild.
2. Structured/deterministic interfaces beat browser clicking when both can perform the job reliably.
3. Browser use is valid when the authenticated UI is the real required interface. When no API exists, the agent drives the browser; the owner is not the browser.
4. Do not install optional capabilities "just in case."
5. A missing capability must be proven before adding a new one.

## 8. Workflow Rules

1. `WORKFLOW.md` is optional.
2. Create/use one only when substantial/repeated work benefits from a stable execution contract.
3. It must define:
   - trigger;
   - target/source of truth;
   - resources;
   - preflight;
   - execution;
   - worker/parallel rules;
   - verification;
   - evidence;
   - recovery;
   - escalation;
   - stop condition.
4. It points to skills/docs; it does not duplicate them.
5. It does not store changing mission history.
6. Do not create five speculative workflows before one real workflow is proven.

## 9. Mission Rules

Every substantial mission freezes:

```text
OUTCOME
ACCEPTANCE
NON-GOALS
```

1. Acceptance must be observable.
2. Assignment complete != mission complete.
3. Gate complete != mission complete.
4. Worker complete != mission complete.
5. Only frozen acceptance can make the mission COMPLETE.
6. If acceptance changes materially, record a new owner-approved mission decision rather than silently moving the goalposts.
7. Stop when acceptance passes. Extra improvements become new work.
8. Implied leftover is `READY` only when current, traceable evidence in the frozen Goal, Source, or an unsuperseded in-scope receipt explicitly requires it. If that traceability or whether the work widens the frozen outcome is uncertain, perform read-only reconciliation. If uncertainty remains, use `WAITING_ON_ALEX`; uncertainty is not `READY`.

## 10. Worker Rules

Use workers only for:
- independent parallel work;
- specialization;
- independent review/evaluation;
- context isolation.

Every worker must receive:
- stable task ID;
- one bounded objective;
- exact resource ownership;
- `MUST NOT TOUCH`;
- minimum inputs;
- allowed/required tools;
- acceptance;
- required return contract.

Hard worker rules:
1. One bounded task/resource = one owner at a time.
2. No two workers silently write the same resource.
3. Shared-state writes must be serialized or explicitly owned.
4. For parallel code work, use isolated worktrees/workspaces when available.
5. Workers do not edit Director ledger/mission judgment state unless explicitly assigned that ownership.
6. Workers cannot declare the overall mission COMPLETE.
7. Worker `PASS` is not proof.
8. Controller drains and judges every child result before ending.
9. If concurrency causes collisions, reduce concurrency before adding coordination infrastructure.
10. Do not create uncontrolled worker-of-worker trees. A Controller remains accountable for every delegated result.
11. One live Controller chat per mission. A Controller registers its own chat/thread ID, human title, and workspace in the ledger on its first turn. Never re-root or "move" a live Controller chat: in Cursor that forks it into two live copies. If a fork happens, the owner's named chat is the Controller; the other copy finishes its current bounded step and stops.

## 11. Git / Durability Rules

1. Private Git owns accepted code/control artifacts when Git is the relevant durable system.
2. A local checkout is a working copy, not a competing source of truth.
3. Meaningful accepted checkpoint:

```text
verify
→ commit accepted scope
→ push
→ verify remote SHA/readback
```

4. Do not create heartbeat/runtime-churn commits.
5. Do not treat untracked files as durable accepted evidence.
6. Do not use `/tmp`, caches, `.wrangler`, `__pycache__`, backups, or scratch as sole mission proof.
7. Never stage or commit raw secrets.
8. Do not mix unrelated dirty changes into accepted mission evidence.
9. Do not create a feature branch as a prerequisite for a map, rule, or test edit. After a Git-isolation denial, apply the Section 14 safe-current-checkout preflight and leave unrelated dirty files untouched.

## 12. Secret Rules

1. 1Password or explicitly approved provider-managed secret storage is canonical.
2. Never persist raw keys, passwords, bearer tokens, OAuth secrets, recovery codes, or service-account secrets in:
   - Git;
   - mission/state files;
   - workflows;
   - skills;
   - SOPs;
   - receipts;
   - evidence;
   - chat output.
3. Prefer runtime injection/reference.
4. If a raw secret is discovered, report only:
   - path;
   - key/item name.
5. Never print the value to prove access.
6. Never create a custom secret store when the approved provider already solves it.

## 13. External Write / Real-World Consequence Rules

### Controller-managed protected-write fence

- Before a shared or live write, the controller must invoke the canonical `~/Alex-Director/scripts/controller-write-guard.py` and pass the exact requested action through `--action`; it must match `authorization_scope.action`. A prose preflight or ledger note is not execution.
- The exact ACTIVE mission must match `CONTROLLER_THREAD_ID`, `CONTROLLER_GENERATION`, `CONTROLLER_HOST_ID`, `NEXT_PLAY_ID`, `NEXT_PLAY_OUTCOME_HASH`, `AUTHORIZATION_REF`, and `AUTHORIZATION_SCOPE_HASH`. Controller identity never substitutes for permission on the exact account, action, resource, and consequence boundary.
- The guard derives a canonical resource key and deterministic write intent. Replaying a completed intent returns its target readback; replaying an ACTIVE or unresolved intent is non-mutating reconciliation. A controller cannot mint a replacement intent for the same assigned mutation.
- The Director must not rotate authority or hand off while that generation has an ACTIVE or unresolved claim. Stop the source, reconcile authoritative target state, and remain blocked without retry when uniqueness is not provable.
- Chat title, transcript modification time, prompt similarity, age, and self-report never grant ownership. The first release is same-host only; remote or unverified claim namespaces fail closed. Parallel live-system workers remain read-only.
- Without native idempotency, declare an immutable target-match predicate: zero matches may create once, one match reconciles, and multiple, ambiguous, or unsupported matches fail closed. If a target accepts mutation but response/readback is lost, authoritative lookup must prove exactly one result or the resource remains blocked without retry. Rotation or handoff requires a passing guard `can-rotate` readback. Failed attempts close through the guard's immutable `fail` receipt; the same intent remains denied, and a retry requires a new Director-issued next play and outcome while preserving the prior failure evidence.
- Completion readback is an evidence object whose top-level `target_id` exactly equals `--target-id`, with provider evidence beside it. Completed receipts preserve `RESOURCE_KEY`, `WRITE_INTENT_ID`, `TARGET_ID`, and authoritative `TARGET_READBACK`. Credentials come only from 1Password runtime injection and never enter claims or receipts.

Ask first for:
- spending/purchases;
- activating/unpausing ads;
- messages to real people;
- public publishing;
- consequential production deploy/DNS/infrastructure changes;
- destructive deletion without recovery;
- credential/authority expansion.

Before any repeated external mutation:
1. verify exact target;
2. set maximum count;
3. prove deduplication/idempotency;
4. define stop condition;
5. prefer one canary;
6. read it back;
7. only then repeat.

Never run an unbounded retry loop against a real external system.

## 14. Protected Boundary Rules

If sandbox, permissions, or host protection blocks a required action, first classify it.

A Git isolation denial (`.git/refs`, `git checkout -b`, `git switch -c`) is not an owner boundary and does not grant write authority. Continue only after a safe current checkout preflight proves the task is authorized there, offered dirty files do not conflict, no concurrent owner controls the same paths, and the checkout is not a protected branch requiring isolation. If isolation remains unsafe, stop before mutation, preserve state, report the checkout risk, and do not ask the owner to unlock Git metadata.

Owner-facing `STOPPED BY BOUNDARY` is only for spend, real messages, production/DNS, destructive delete, or a write the owner alone can unlock (`~/.zshrc`, LaunchAgents, host `/etc`, 1Password). A sandbox deny is not an owner boundary: park that write, continue other work, and allow one product-supported escalate. Owner-asked `~/.codex` edits in the executing thread are allowed. Then, only for a real owner gate, provide:
- exact blocked path/action;
- exact smallest config/UI action required;
- exact PASS condition.

Never:
- broaden to `danger-full-access` merely for convenience;
- relocate state to dodge the boundary;
- ask another agent to bypass it;
- create a workaround service;
- loop the exact same denied write;
- treat a Git branch-create deny or a sandbox deny as owner work.

## 15. Verification Rules

Configured != authenticated != reachable != executed != functioning != production-proven.

1. Define proof before substantial execution.
2. A successful command/write request is not proof by itself.
3. External writes require authoritative readback.
4. Software requires applicable tests/build/lint/types/CI/user-path checks.
5. Business systems require applicable safe test entity/dry-run/live-system checks.
6. Subjective outputs need a rubric when acceptance depends on quality/taste.
7. No evidence = no VERIFIED.
8. If processing cannot be proven after native readback + bounded diagnostics, use `NOT_PROVEN`.
9. Never upgrade `NOT_PROVEN` to success because the result is likely.
10. Anything a human will look at (doc, deck, page, site, client folder, message) is verified by that human, never by agent readback. Acceptance is written as what the owner sees next to the reference he named; the node stops at `READY_FOR_OWNER` with the link. An owner rejection is appended to the acceptance verbatim before rebuilding.

## 16. Readback Rules

Permanent order:

```text
native task/system readback
→ native turn/message/result surface
→ bounded diagnostic local history only if native projection is unexpectedly incomplete
→ NOT_PROVEN
```

Internal SQLite/log/rollout formats are diagnostic fallbacks only, never permanent runtime dependencies.

## 17. Retry / Failure Rules

When something fails:

```text
mission/acceptance
→ live evidence
→ existing workflow/skill
→ existing capability
→ canonical docs
→ specialist if routed
→ reproduce/isolate/hypothesis/falsify
→ smallest safe test
→ smallest fix
→ retest
```

1. Never respond to a failure by immediately rebuilding the system.
2. Never repeat the same failed mutation without new evidence.
3. Retries must be bounded.
4. Genuine owner/access boundaries become `WAITING_ON_OWNER`, not retry loops.
5. Contradictory evidence changes the plan.

## 18. Director Reconciliation Rules

Before Director waits or ends, for **every ACTIVE mission**:
1. read mission state;
2. read Controller status/unseen result;
3. drain terminal evidence;
4. judge against frozen acceptance;
5. if unfinished + idle, dispatch existing NEXT exactly once;
6. record sent vs processing distinctly;
7. prove processing/readback;
8. update current state;
9. do not auto-retry owner-blocked missions.

Remember:

```text
NEXT recorded != sent != processing != complete
```

The Director does not finish while an ACTIVE mission still requires supervision.

Cycle termination is derived across all missions, never from one lane:
- `MISSION_COMPLETE` with a leftover `NEXT_PLAY` is invalid; clear the leftover before ending.
- `SENT_NOT_PROCESSED` remains actionable until processing/readback is verified.
- Cursor parent-mismatch triggers one transport-only resume of the reported parent, then graph-header recovery; it is not an owner boundary or cycle end.
- A time-gated lane may wait, but it cannot end the cycle while another mission has actionable work or an active Controller.

## 19. Heartbeat Rules

If persistent supervision is needed and native automation is supported:
1. use exactly one owner-approved native Director heartbeat;
2. it may reconcile/read/dispatch existing idempotent NEXT actions;
3. it overwrites one current receipt;
4. it never creates dated receipt sprawl;
5. it never commits every cycle;
6. it never performs consequential live actions by itself;
7. it never becomes mission acceptance evidence;
8. it never becomes a second orchestrator.

If heartbeat is not needed, `NOT_NEEDED` is valid.

## 20. Recovery Rules

A setup is not one-shot-ready until a fresh turn can recover:
- owner outcome;
- mission;
- Controller;
- workflow if applicable;
- target;
- current state;
- durable evidence;
- NEXT;
- consequence boundaries.

Recovery must not depend on:
- chat archaeology;
- owner memory;
- temporary local files alone.

## 21. Beginner Safety Certification

Do not say `ONE_SHOT_READY: YES` because:
- files exist;
- config was saved;
- workers returned PASS;
- one turn succeeded.

Certify only when `checklists/ONE_SHOT_READINESS.md` passes behaviorally.

If a test fails:
1. name the exact failed invariant;
2. identify the smallest missing prerequisite;
3. repair only that;
4. rerun the failed test plus related regressions;
5. do not add architecture unless the failure proves it necessary.

## Final Rule

The beginner should be able to state the outcome and remain outside the technical control loop.

If the system repeatedly needs the beginner to choose technical mechanics, reconstruct context, interpret logs, decide worker routing, or verify the agent's work manually, the system is **not one-shot-ready**.
