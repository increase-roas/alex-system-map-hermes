# Start here: Increase ROAS agent knowledge

Owner: Alex. Maintainer: the agent completing an authorized knowledge audit.

- Last completed full build-context audit: 2026-10-07 23:36:11 UTC
- Audit ID: `build-context-2026-10-07`
- Auditor: Codex with four parallel source lanes and a separate independent verifier
- Audit scope: selected full safe configuration/AGENTS, accepted plans/build sources, procedures/supporting scripts/hooks, scoped GHL/Cloudflare readbacks, navigation, lessons and publication; earlier inventory remains dated
- Result: independent source/integration accepted;42-file shared Drive publication and human-guide links verified; final metadata bytes rechecked in the saved final receipt
- Audit receipt: [AUDIT_RECEIPT.json](AUDIT_RECEIPT.json)
- Remaining gaps: [GAPS.md](GAPS.md)

This entry point maps the knowledge. It does not certify current agent health. Publication dates, source-update dates and runtime verification dates remain separate.

## Fastest intake

For one-file orientation, read [AGENT_BRIEFING.md](AGENT_BRIEFING.md). It is generated from the maintained knowledge pages below and gives the team, account declarations, evidence states, access route, infrastructure boundaries, role summaries, skill/hook navigation, gaps and maintenance rules. Read a task's canonical skill and supporting resources before execution; the briefing is not a substitute for that procedure.

Before continuing or reconstructing a build, read [BUILD_READINESS.md](BUILD_READINESS.md) and its required configuration, implementation, procedure and service sources. Full safe source snapshots are dated evidence; the maintained source retains authority.

For focused intake, read [TEAM_MAP.md](TEAM_MAP.md), [CURRENT_STATE.md](CURRENT_STATE.md), [ACCESS_AND_TOOLS.md](ACCESS_AND_TOOLS.md), then the relevant role page. Use [source_registry.json](source_registry.json) to resolve logical filenames to published Drive file IDs and maintained local source pointers. On a remote agent, Mac paths are references, not accessible files by assumption.

Verify the checksum of a fetched Markdown response before relying on its text. If punctuation is garbled, use the guarded decoding procedure in [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md); [LESSONS.md](LESSONS.md) records the observed recovery.

## Where the facts live

| Need | Read |
|---|---|
| Build readiness, acceptance matrix and remaining build blockers | [BUILD_READINESS.md](BUILD_READINESS.md) |
| Full safe configuration/instruction sources and precedence | [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) · [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md) |
| Accepted plans, implementation and historical acceptance | [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) · [BUILD_IMPLEMENTATION_SOURCES.md](BUILD_IMPLEMENTATION_SOURCES.md) |
| Build-critical procedures, dependencies and full safe source text | [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md) · [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md) |
| GHL and Cloudflare implementation/dependency coverage | [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md) · [SERVICE_SOURCES.md](SERVICE_SOURCES.md) |
| Independent acceptance against the requested plan | [BUILD_ACCEPTANCE.md](BUILD_ACCEPTANCE.md) |
| Published build source coverage and exclusions | [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json) |
| Accepted build-context production plan | [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md) |
| Agent ownership, relationships and identity conflicts | [TEAM_MAP.md](TEAM_MAP.md) |
| Computers, workspaces, sizes and detailed workbook pointers | [INFRASTRUCTURE.md](INFRASTRUCTURE.md) |
| Personal plans, declared Hermes emails and54 saved connector records | [ACCOUNTS.md](ACCOUNTS.md) |
| Approved access route and credential-reference boundaries | [ACCESS_AND_TOOLS.md](ACCESS_AND_TOOLS.md) |
| Evidence freshness and what has actually been checked | [CURRENT_STATE.md](CURRENT_STATE.md) |
| Local canonical/system/pointer skill contents | [SKILLS.md](SKILLS.md) |
| Cached plugin skill contents and exposure limits | [PLUGIN_SKILLS.md](PLUGIN_SKILLS.md) |
| Hook definitions, configured events and execution limits | [HOOKS.md](HOOKS.md) |
| Unresolved questions and exact next evidence | [GAPS.md](GAPS.md) |
| Verified mistakes, fixes and prevention | [LESSONS.md](LESSONS.md) |
| Audit, enrichment, lessons and publication requirements | [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) |

## Agent pages

[Javar](agents/javar.md) · [Javante](agents/javante.md) · [Ops](agents/ops.md) · [Customer Success](agents/customer-success.md) · [Media](agents/media.md) · [Sales / Setter / Hunter](agents/sales.md) · [Finance](agents/finance.md)

## Coverage and authority

Build-context extension:31 configuration captures,209 full implementation texts,167 full procedure snapshots and19 service sources. Cross-lane overlap yields401 unique resolved safe source paths. [BUILD_ACCEPTANCE.md](BUILD_ACCEPTANCE.md) records independent scope acceptance and [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json) lists inclusions/exclusions. Previous documentation audit:2026-10-07 22:42:53 UTC. The earlier inventory counts below remain historical coverage, not a fresh fleet scan.

The source register accounts for34 selected setup files,23 workbook sheets,199 local skill-entry records and154 plugin-cache skill-entry records, with resolved-path deduplication. Local entries include174 regular canonical skills, one externally owned canonical exception,19 synced pointers and5 Codex system skills. These source classes are not a count of distinct available capabilities. Five safe hook sources and seven configured Claude hook entries were inspected. There are17 exact-content duplicate groups across39 source paths; these remain source/version records, not separate capability claims. Supporting skill resources, remote delivery, fresh runtime health and current billing have explicit limits in GAPS and the audit receipt.

Original workbooks, role documents and skills keep their maintained source homes. These pages are a dated readable knowledge layer. Keep procedures in canonical skills; keep raw logs in evidence files; keep keys out of this hub. Regenerate the briefing from these pages rather than maintaining an independent copy of the facts.

## Required update after every audit

Read and follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md). Future auditors must update this file's completed date/time, audit ID, scope, result, receipt and gap links after a verified completed audit, then regenerate the briefing and publish changed bytes to the same Drive IDs. A partial scan, failed check, upload or cosmetic edit cannot advance the completed-audit date.

When a problem is fixed, add its dated cause/fix/proof/prevention entry to [LESSONS.md](LESSONS.md), refresh the owning record and close only the supported part of the gap. Add new source-backed information during the audit; label owner declarations and unknowns explicitly. This is a written requirement; no enforcement hook or recurring audit has been installed.

## Mandatory final audit reminder

Before saying done, reread Alex's request and the accepted plan, then check what was delivered against what it was supposed to do. Use [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md), [BUILD_READINESS.md](BUILD_READINESS.md) and [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md). A separate verifier must check broad work; every partial or blocked requirement needs exact remaining evidence. Update the completed audit date only after acceptance, regenerate the briefing and registry, publish the same IDs and verify final bytes. This reminder is written here; no automatic enforcement or recurring job was installed.

## Shared locations

[Agent Builds & Setup hub](https://drive.google.com/drive/folders/1_gIjJUQZ9gXbJGctSRNVeDcImlcLu87w) · [Readable knowledge folder](https://drive.google.com/drive/folders/1ALxgupfhkkWjXtB51XjS4KYsWKQTDcex) · [Existing human Start Here guide](https://docs.google.com/document/d/1yYm-VGccTRUTVAtuSkTF9w1kABG9Jha5EyLexfTbOxc/edit)

Published source registry: https://drive.google.com/file/d/176hza_ZAB2ypsCLNUnEvwcsbqxNV2yw6/view?usp=drivesdk

<!-- master-operations-sdk:start -->
## Master Agent Operations SDK v1

Implementation: `/Users/alexlobaito/Documents/Codex/master-agent-operations-sdk`. Python and local MCP share the exact-target reviewed repair lifecycle.

- [SDK_USAGE.md](https://drive.google.com/file/d/1CPJ8vT9yBm2YiQWN-V4mcMDaE_Tl5E3a/view)
- [SDK_REPAIR_PACKETS.md](https://drive.google.com/file/d/1N-0DUwscsgdDT7PXjl511SVDRGAtjAX4/view)
- [SDK_REPAIR_PACKETS.json](https://drive.google.com/file/d/1nKUHWYInpIF9tG7Kta0JW6ttQGJlNbqP/view)
- [SDK_RUNTIME_TARGETS.json](https://drive.google.com/file/d/1p0FHztRNdkojAOdLSY8TKJXrmxrfEAkw/view)

Verified scope: SDK-owned stored-response repair, real stored Google Doc response, scoped GHL/Cloudflare configuration reads, local metadata and fixture-tested recovery. Remote installation and current Orgo/Hermes serving/profile acceptance remain NOT_PROVEN. GHL null stages remain BLOCKED; G23 requires reacceptance; G24 remains paused; G28 retains three missing-source owner decisions. Shared connector helper and infrastructure workbook remain unchanged.

Last completed SDK audit: 2026-10-08T04:31:08.841375+00:00; audit ID `master-ops-sdk-v1`. Independent implementation and publication acceptance: VERIFIED; this metadata update receives a separate final readback check. Permitted explicit residuals remain. Earlier build-context audit keeps its original scope/date.

Before a repair, read its owning source, canonical skill/card and LESSONS. After a proven fix, record cause, change, scope, evidence and prevention in LESSONS; refresh the owning record. Before saying done, reread the original request and plan and audit every promised outcome.
<!-- master-operations-sdk:end -->
