# Platform Integrations

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## apify-dataset-to-disk

[S009] Source: `/Users/alexlobaito/.agents/skills/apify-dataset-to-disk/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T19:03:51.852496+00:00. SHA-256: `f5b972fcb1926d4a261250d6579b9b9197f2ede125bdd9317d8c785a7dcc1f49`.

**Trigger/purpose:** Get large Apify dataset results onto disk without blowing the context window, and avoid the field-projection traps that silently return empty or wrong data. Use whenever calling Apify actors via MCP, fetching dataset items, or when an actor result is too large to read.

**Contents:** Apify results → disk, without wrecking context; The persisted-file pattern (use this by default); Field projection traps; 1. Name collision; 2. Empty objects; 3. It hides the real structure; Diagnosing an unexpected shape; Polling runs to completion; Direct-to-disk alternative (best when available); Cost sanity.

**Opening guidance (source excerpt):** MCP tool results land in the model's context, not on disk. A 500 KB dataset is ~130k tokens. This skill is how to move real volume safely.

**Procedure cues (source excerpts):** Call `get-dataset-items` with a high `limit` and let it overflow.; Read the path from the error/notice.; Parse it locally with a Python heredoc through Bash.; Write your own organized output files.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## cloudflare

[S047] Source: `/Users/alexlobaito/.agents/skills/cloudflare/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:49:32.718850+00:00. SHA-256: `601186fdd75980ef68fffaf9bd4622edbf8943be516d6f3d136435febf6fe404`.

**Trigger/purpose:** Use for any Cloudflare work: Workers, Pages, KV, D1, R2, DNS, Zero Trust, Tunnel, AI or IaC. Account actions go through Composio custom_cloudflare_api; checks current docs first.

**Contents:** Cloudflare Platform Skill; Route; Retrieval sources.

**Opening guidance (source excerpt):** Consolidated skill for building on the Cloudflare platform. Find the product in `references/product-index.md`, then read only that product's folder under `references/`.

**Resources:** references/ (320 files; metadata only).

## cloudflare-one

[S049] Source: `/Users/alexlobaito/.agents/skills/cloudflare-one/SKILL.md`; kind: canonical. Modified UTC: 2026-08-28T18:03:29.919388+00:00. SHA-256: `605336f84979367b6235a57da8ea43e4f3b856a97efd2c95d9e7f90e41bf17ec`.

**Trigger/purpose:** Guides Cloudflare One Zero Trust and SASE work across Access, Gateway, WARP, Tunnel, Cloudflare WAN, DLP, CASB, device posture, and identity. Use when designing, configuring, troubleshooting, or reviewing Cloudflare One deployments. Retrieval-first: use current Cloudflare docs/API schemas instead of embedded product docs.

**Contents:** Cloudflare One; Workflow; Assessment Prompts; Architecture and Current State; Access and SaaS Federation; Tunnel and Private Networking; Gateway, TLS, and DLP; CASB, Device Posture, and Risk; Cloudflare WAN / Site Connectivity; Guardrails; Identity and Access; Device Client Deployment; Private Networking; Gateway, TLS, and DLP; CASB, Risk, and Operations; Infrastructure Access; Logs, Analytics, and DEX; Cloudflare WAN / Site Connectivity; Output Defaults; Validation Prompts; API Safety.

**Opening guidance (source excerpt):** Before citing limits, settings, API fields, category IDs, or exact UI paths, retrieve current information from the [Cloudflare One docs](https://developers.cloudflare.com/cloudflare-one/), the Cloudflare docs MCP server, or the Cloudflare API schema.

**Procedure cues (source excerpts):** Classify the ask: architecture, configuration, troubleshooting, migration, or review.; Gather context: account ID, users/sites/apps, identity provider, SCIM/group sync, device management, traffic path, compliance constraints, and rollout blast radius.; Retrieve only the current docs needed for the products involved: Access, Gateway, WARP/device client, Tunnel/Mesh, Cloudflare WAN, DLP, CASB, device posture, or identity.; If account access is available, inspect existing resources before proposing or making changes: Access apps/policies/groups/IdPs, Gateway rules/lists/categories, device profiles/posture checks, tunnels/routes, DNS/resolver settings, and locations/sites.; Propose the change set with prerequisites, validation, and rollback. For risky changes, stage disabled or scoped to a pilot group/site unless the user explicitly asks otherwise.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## cloudflare-one-migrations

[S050] Source: `/Users/alexlobaito/.agents/skills/cloudflare-one-migrations/SKILL.md`; kind: canonical. Modified UTC: 2026-08-28T18:03:29.922250+00:00. SHA-256: `50ed246b92a3f82c7afac864201093269fad8de24e4ce7ea18929103a26adad8`.

**Trigger/purpose:** Plans migrations from Zscaler ZIA/ZPA, Palo Alto, legacy VPN, SWG, or SASE stacks to Cloudflare One. Use for migration assessments, policy mapping, rollout plans, and parity/gap analysis.

**Contents:** Cloudflare One Migrations; Workflow; Exports To Ask For; Mapping Heuristics; Migration Assessment Prompts; Source-Specific Traps; Zscaler ZIA / SWG; Zscaler ZPA / Private Access; Palo Alto / Prisma / NGFW; Gotchas; Validation Gates; Assessment Template; Migration Assessment.

**Opening guidance (source excerpt):** Retrieve current Cloudflare docs, Cloudflare API schemas, and source-vendor export docs before generating exact configuration.

**Procedure cues (source excerpts):** Identify the source stack: Zscaler ZIA, Zscaler ZPA, Palo Alto NGFW/Prisma/GlobalProtect, legacy VPN/SWG/SD-WAN, or other.; Request exports and logs before mapping. Prefer structured exports over screenshots or prose summaries.; Build an inventory: identities, groups, apps, destinations, connectors/tunnels, DNS/URL/firewall/DLP/TLS policies, objects/lists, locations/sites, exceptions, hit counts, and compliance logging.; Produce a mapping plan: source object, Cloudflare One target resource, confidence, prerequisites, unsupported/partial mappings, and manual decisions.; Create dependencies first: identity/[SCIM](https://developers.cloudflare.com/cloudflare-one/team-and-resources/users/scim/), connectors/on-ramps, routes/DNS, lists/objects, TLS bypasses, Access apps/policies, Gateway policies, DLP/CASB, logging.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## composio-cli

[S053] Source: `/Users/alexlobaito/.agents/skills/composio-cli/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:44:40.834755+00:00. SHA-256: `52d6a7843c3a4b58db1dd39180f3940895378afb695a74a7eece47f523b97225`.

**Trigger/purpose:** Use when running or troubleshooting the composio command: finding a tool slug, linking an account, reading a schema, executing tools, proxy API calls or composio run scripts.

**Contents:** Composio CLI; Default Workflow; `execute` - Run A Tool; `search` - Find The Slug; `link` - Connect An Account; `proxy` - Raw API Access; `run` - Scripting, LLMs, and Programmatic Workflows; Auth; Escalate Only When Needed.

**Opening guidance (source excerpt):** 1. Start with `composio execute <slug>` whenever the slug is known. 2. If several independent tool calls must happen at once, use `composio execute -p/--parallel` with repeated `<slug> -d <json>` groups. 3. If `execute` says the toolkit is not connected, run `composio link <toolkit>` and retry. 4. If the arguments are unclear, run `composio execute <slug> --get-schema` or `--dry-run` before guessing. 5. Reach for `composio search "<task>"` only when the slug is unknown. `search` accepts one or more queries, so batch related discovery work into a single command when useful.

**Procedure cues (source excerpts):** Start with `composio execute <slug>` whenever the slug is known.; If several independent tool calls must happen at once, use `composio execute -p/--parallel` with repeated `<slug> -d <json>` groups.; If `execute` says the toolkit is not connected, run `composio link <toolkit>` and retry.; If the arguments are unclear, run `composio execute <slug> --get-schema` or `--dry-run` before guessing.; Reach for `composio search "<task>"` only when the slug is unknown. `search` accepts one or more queries, so batch related discovery work into a single command when useful.

**Resources:** references/ (3 files; metadata only).

## composio-custom-mcp

[S054] Source: `/Users/alexlobaito/.agents/skills/composio-custom-mcp/SKILL.md`; kind: canonical. Modified UTC: 2026-10-07T21:07:40.417861+00:00. SHA-256: `e3232ee6beaf8cb1eeb264746989727359d7c6b4e504e14047563536eeaf4b45`.

**Trigger/purpose:** Connect, add, improve, or repair an app or service in Composio. Select the strongest proven native or vendor route, build or extend a custom MCP when needed, verify the project and agent identity, and prove the intended agent can discover and use it. Use for ordinary requests such as connect this app to Composio; routine execution through an existing connection follows its app card.

**Contents:** Custom Composio MCP; Authority and sources; 1. Recover the job and checkpoint; 2. Choose the strongest route; 3. Set the project and agent contract; 4. Build and connect; 5. Prove the complete path; 6. Publish and report.

**Opening guidance (source excerpt):** Deliver the most capable **proven** connector for the requested business jobs, through Composio and inside the intended account/role boundary. Tool count alone is not power. A successful server test or saved connection alone is not an operational connector.

**Resources:** references/ (2 files; metadata only).

## durable-objects

[S066] Source: `/Users/alexlobaito/.agents/skills/durable-objects/SKILL.md`; kind: canonical. Modified UTC: 2026-08-29T02:40:08.767615+00:00. SHA-256: `cd6797cb18f3ae8f721dfd2e5cb27b73a0aa8636683f1a38163dab2fd51a8dfb`.

**Trigger/purpose:** Create and review Cloudflare Durable Objects. Use when building stateful coordination (chat rooms, multiplayer games, booking systems), implementing RPC methods, SQLite storage, alarms, WebSockets, or reviewing DO code for best practices. Covers Workers integration, wrangler config, and testing with Vitest. Biases towards retrieval from Cloudflare docs over pre-trained knowledge.

**Contents:** Durable Objects; Retrieval Sources; When to Use; Reference Documentation; Core Principles; Use Durable Objects For; Do NOT Use For; Quick Reference; Wrangler Configuration; Basic Durable Object Pattern; Critical Rules; Anti-Patterns (NEVER); Stub Creation; Storage Operations; Alarms; Testing Quick Start.

**Opening guidance (source excerpt):** Build stateful, coordinated applications on Cloudflare's edge using Durable Objects.

**Procedure cues (source excerpts):** **Model around coordination atoms** - One DO per chat room/game/user, not one global DO; **Use `getByName()` for deterministic routing** - Same input = same DO instance; **Use SQLite storage** - Configure `new_sqlite_classes` in migrations; **Initialize in constructor** - Use `blockConcurrencyWhile()` for schema setup only; **Use RPC methods** - Not fetch() handler (compatibility date >= 2024-04-03)

**Resources:** references/ (3 files; metadata only).

## manus-api

[S113] Source: `/Users/alexlobaito/.agents/skills/manus-api/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:54.953892+00:00. SHA-256: `12a37deb313582112911b2ab1742661d6d5b25d61c9c289b50f025a3f4b0f933`.

**Trigger/purpose:** Manage tasks, projects, and other data through the Manus API; build OAuth2 Open Apps and third-party integrations; or create Manus tasks programmatically for services and workflows that need agentic capabilities.

**Contents:** Manus API Integration Guide; 1. Documentation Routing; 2. Endpoint Map; 3. Core Integration Decisions; 4. Structured Output Guidance; 5. Operational Limits; 6. Minimal Implementation Pattern; References.

**Opening guidance (source excerpt):** Use this skill when building or troubleshooting integrations that call the Manus API, automate Manus agents, retrieve generated results, manage projects/files/webhooks/connectors/agents/usage, request structured JSON outputs, publish websites created by Manus tasks, or implement OAuth2 authorization for third-party apps.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## sandbox-sdk

[S139] Source: `/Users/alexlobaito/.agents/skills/sandbox-sdk/SKILL.md`; kind: canonical. Modified UTC: 2026-08-29T02:40:08.768694+00:00. SHA-256: `0f3501e6510921401be3f54bcb24d2a432a1b5c63af8f719eded3a087ad88ea9`.

**Trigger/purpose:** Build sandboxed applications for secure code execution. Load when building AI code execution, code interpreters, CI/CD systems, interactive dev environments, or executing untrusted code. Covers Sandbox SDK lifecycle, commands, files, code interpreter, and preview URLs. Biases towards retrieval from Cloudflare docs over pre-trained knowledge.

**Contents:** Cloudflare Sandbox SDK; FIRST: Verify Installation; Retrieval Sources; Required Configuration; Quick Reference; Core Patterns; Execute Commands; Code Interpreter (Recommended for AI); File Operations; When to Use What; Extending the Dockerfile; Python packages; Node packages (global); System packages; Preview URLs (Port Exposure); OpenAI Agents SDK Integration; Sandbox Lifecycle; Anti-Patterns; Detailed References.

**Opening guidance (source excerpt):** Build secure, isolated code execution environments on Cloudflare Workers.

**Resources:** references/ (2 files; metadata only).

## scrapling

[S140] Source: `/Users/alexlobaito/.agents/skills/scrapling/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T09:29:27.320752+00:00. SHA-256: `5be2707ed7dd50fd6b9d6f40cfcf8559ac24cd4a0491d0e9631819d12188ceba`.

**Trigger/purpose:** \| 使用 scrapling 进行网页抓取和数据提取。根据目标网站特征自动选择最佳 Fetcher， 生成并执行 Python 脚本完成任务。Use when: (1) 抓取/爬取网页内容或数据（scrape, crawl, fetch page, extract data） (2) 需要绕过 Cloudflare/WAF 等反爬保护 (3) 登录后抓取受保护页面 (4) 解析已有 HTML 提取结构化数据 (5) 用户提供 URL 并要求获取页面内容或特定元素 (6) 批量采集多个页面

**Contents:** Scrapling 网页抓取 Skill; 步骤 0：检查版本; 步骤 1：安全预检与 quick path; 步骤 2：选择 Fetcher; 步骤 3：执行工作流; Guardrails; Cookie 格式速查; 超时单位速查; 模板索引; References 索引.

**Opening guidance (source excerpt):** 按项目使用的包管理器执行（pip / uv 等价命令见 `references/maintenance.md`）：

**Procedure cues (source excerpts):** 检查版本（步骤 0）; 安全预检（步骤 1）; 查阅 references/site-patterns.md；如果存在 references/site-patterns.local.md，也先查本地 overlay; 简单抽取 → 优先 CLI quick path + --ai-targeted; 复杂流程 → 用决策树选择 Fetcher，读取对应模板，替换参数，生成完整脚本

**Resources:** references/ (7 files; metadata only); templates/ (4 files; metadata only).

## skool-apify-scraper

[S147] Source: `/Users/alexlobaito/.agents/skills/skool-apify-scraper/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T18:14:36.536411+00:00. SHA-256: `a3e6c847c25afcf82ec51a1014770ac5ad9158b8278e8c3791d346b7da53d62f`.

**Trigger/purpose:** Scrape a Skool classroom or its posts and comments through Composio Apify. Use when Alex asks to scrape Skool or aimoney, or names dz_omar/skool-scraper-pro or memo23/skool-posts-with-comments-scraper

**Contents:** Skool via Apify; Inputs; Run; Gotchas.

**Opening guidance (source excerpt):** Default group: **aimoney** (`https://www.skool.com/aimoney`).

**Procedure cues (source excerpts):** `APIFY_GET_ACTOR` (`actorId`) for the actor's input schema and pricing, then run it.; Classroom → actor `dz_omar/skool-scraper-pro`. URL **must** be `https://www.skool.com/SLUG/classroom`. Cheap test: `maxItemsPerSection=3`, `skipLockedCourses=false`, downloads off.; Posts → actor `memo23/skool-posts-with-comments-scraper`. Bare URL `https://www.skool.com/SLUG`, `"tab":"classroom"`, `maxItems=10`. Cookies required.; Small test runs: `APIFY_RUN_ACTOR_SYNC_GET_DATASET_ITEMS` (`actorId`, `input`, `maxItems`, `maxTotalChargeUsd`). Longer runs: `APIFY_RUN_ACTOR` (`actorId`, `body`), then `APIFY_GET_RUN_DATASET_ITEMS` (`runId`, `limit`, `offset`) in pages. Large datasets go to disk (`apify-dataset-to-disk`).

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## tool-card

[S157] Source: `/Users/alexlobaito/.agents/skills/tool-card/SKILL.md`; kind: canonical. Modified UTC: 2026-10-07T21:07:40.418500+00:00. SHA-256: `3c02375ee6c80b7671212690ae310bc43b61bcd69387cd8a0343dd596fbe8795`.

**Trigger/purpose:** Use when a connector, tool or API key is added, changed or fails. Saves the key to 1Password, picks the strongest route, proves reach and power, tiers each tool and writes its card.

**Contents:** tool-card; Checklist; Gotchas.

**Opening guidance (source excerpt):** Publishes the records for one added, changed or repaired connector: the key provenance, one proven route, every tool tiered, and a card every intended AI can read. For onboarding or route/power changes, `composio-custom-mcp` owns route choice and project/principal/runtime proof; use its result instead of repeating that work. Copy the checklist into your notes and tick it off. Skip a step only when it can't apply, and say why. Each step names the `references/` file that holds its detail.

**Procedure cues (source excerpts):** **Key**, if the app needs one: reuse its verified 1Password item. Only a genuinely missing new key needs Alex to copy it and say "copied"; one; **Route decision.** Reuse the checked `composio-custom-mcp` comparison for this family and scope. If no comparison exists and onboarding/route choice is required, use that skill first. A missing native toolkit can require a custom build, not an automatic stop.; **Composio login.** Explicit project/principal: `push_key_to_composio.py --project <id> --user-id <principal> --item "<title>" --toolkit <slug>`; a new auth config gets the; **Coverage and retirement.** Record proven jobs and counts from the route decision; do not create every candidate connection just to compare. Retire a duplicate only after replacement/dependencies/backup and current authorization are proven; stop at a guard code.; **CLI only if needed** (a job Composio can't do): isolated install, a `<tool>_op.py` wrapper with tests first, any

**Resources:** references/ (5 files; metadata only).

## turnstile-spin

[S160] Source: `/Users/alexlobaito/.agents/skills/turnstile-spin/SKILL.md`; kind: canonical. Modified UTC: 2026-08-28T18:16:03.483956+00:00. SHA-256: `7b6632b9d8643f38f258d42e2f08bed7f9507d41d7947ba96ef8aff16db46a2d`.

**Trigger/purpose:** Set up Cloudflare Turnstile end-to-end in a project. Scan the codebase, create the widget via the Cloudflare API, embed it where user requests need bot verification (form submissions, SPA actions, API endpoints, download links, comment or vote submissions, etc.), wire canonical server-side siteverify in the customer's existing backend, validate, and persist the skill. Load this when a user asks to add Turnstile, set up CAPTCHA, protect a form or endpoint from bots, or fix a Turnstile integration. Mirrors developers.cloudflare.com/turnstile/spin.

**Contents:** Turnstile Spin skill; When to load this skill; Choose the flow before responding; Conversation flow; Things you must NOT do; Hard scope boundary: DO NOT ask the user about; Existing-widget flow: retrieve and store the secret without chat; The frontend-edit contract; Migrating from another CAPTCHA; Edge cases.

**Opening guidance (source excerpt):** Turns the prompt "set up Turnstile" into a working end-to-end integration: a widget, frontend snippets at every chosen insertion point, canonical server-side siteverify in the customer's existing backend, and a real validation pass before reporting success.

**Procedure cues (source excerpts):** **Brief acknowledge.** One sentence: "I'll run Turnstile setup end to end. That's: check auth, scan the codebase, create the widget, embed it where visitor requests need verification, wire server-side siteverify, validate. Proceed?" **[wait for user]** Do NOT present a plan yet. Auth + scan come first.; **CLI check.** Spin's helper scripts use `curl` against `api.cloudflare.com`. Account enumeration requires either an explicit `$CLOUDFLARE_ACCOUNT_ID` or a user-approved canonical absolute `WRANGLER_BIN` outside the project with exact `WRANGLER_VERSION`. Never use `npx`, `pnpm exec`, a package script, a project-local binary, or an unapproved executable for a credential-bearing command. Never install Wrangler automatically during the flow.; **Auth + scope probe (FIRST irreversible action).** Run `scripts/auth-probe.sh`. If account enumeration needs Wrangler, set `PROJECT_ROOT`, approved canonical `WRANGLER_BIN`, and exact `WRANGLER_VERSION` first. Branch on `status`:; **Export + relaunch** (token enters neither chat nor shell history): `read -rsp 'Cloudflare API token: ' token; echo; export CLOUDFLARE_API_TOKEN="$token"; unset token`, then restart the agent from that terminal.; **Save to file** (token in a user-only file): `umask 077; read -rsp 'Cloudflare API token: ' token; echo; printf '%s' "$token" > ~/.cf-turnstile-token; unset token`, then load it without printing it.

**Resources:** references/ (6 files; metadata only); scripts/ (4 files; metadata only).

## workers-best-practices

[S171] Source: `/Users/alexlobaito/.agents/skills/workers-best-practices/SKILL.md`; kind: canonical. Modified UTC: 2026-08-29T02:40:08.770380+00:00. SHA-256: `099432ff265ff6080327ef0b392c118b835d2a5bda98a7de07e1afd115ed6458`.

**Trigger/purpose:** Reviews and authors Cloudflare Workers code against production best practices. Load when writing new Workers, reviewing Worker code, configuring wrangler.jsonc, or checking for common Workers anti-patterns (streaming, floating promises, global state, secrets, bindings, observability). Biases towards retrieval from Cloudflare docs over pre-trained knowledge.

**Contents:** Retrieval Sources; FIRST: Fetch Latest References; Fetch latest workers types; Types at /tmp/workers-types-latest/package/index.d.ts; Reference Documentation; Rules Quick Reference; Configuration; Request & Response Handling; Architecture; Observability; Code Patterns; Security; Anti-Patterns to Flag; Review Workflow; Scope; Principles.

**Opening guidance (source excerpt):** Your knowledge of Cloudflare Workers APIs, types, and configuration may be outdated. **Prefer retrieval over pre-training** for any Workers code task — writing or reviewing.

**Procedure cues (source excerpts):** **Retrieve** — fetch latest best practices page, workers types, and wrangler schema; **Read full files** — not just diffs; context matters for binding access patterns; **Check types** — binding access, handler signatures, no `any`, no unsafe casts (see `references/review.md`); **Check config** — compatibility_date, nodejs_compat, observability, secrets, binding-code consistency; **Check patterns** — streaming, floating promises, global state, serialization boundaries

**Resources:** references/ (2 files; metadata only).

## wrangler

[S172] Source: `/Users/alexlobaito/.agents/skills/wrangler/SKILL.md`; kind: canonical. Modified UTC: 2026-08-29T02:40:08.770994+00:00. SHA-256: `42abe11ba6c0cb0c135deed1d591d844838fe0b61fc8c6d675a832435508a61b`.

**Trigger/purpose:** Cloudflare Workers CLI for deploying, developing, and managing Workers, KV, R2, D1, Vectorize, Hyperdrive, Workers AI, Containers, Queues, Workflows, Pipelines, and Secrets Store. Load before running wrangler commands to ensure correct syntax and best practices. Biases towards retrieval from Cloudflare docs over pre-trained knowledge.

**Contents:** Wrangler CLI; Retrieval Sources; FIRST: Check if Wrangler is installed, and if not, install it; Key Guidelines; Quick Start: New Worker; Initialize new project; Or with a framework; Quick Reference: Core Commands; Configuration (wrangler.jsonc); Minimal Config; Full Config with Bindings; Generate Types from Config; Generate worker-configuration.d.ts; Custom output path; Check types are up to date (CI); Local Development; Start Dev Server; Local mode (default) - uses local storage simulation; With specific environment; Force local-only (disable remote bindings); Remote mode - runs on Cloudflare edge (legacy); Custom port.

**Opening guidance (source excerpt):** Your knowledge of Wrangler CLI flags, config fields, and subcommands may be outdated. **Prefer retrieval over pre-training** for any Wrangler task.

**Procedure cues (source excerpts):** **Version control `wrangler.jsonc`**: Treat as source of truth for Worker config.; **Use automatic provisioning**: Omit resource IDs for auto-creation on deploy.; **Run `wrangler types` in CI**: Add to build step to catch binding mismatches.; **Use environments**: Separate staging/production with `env.staging`, `env.production`.; **Set `compatibility_date`**: Update quarterly to get new runtime features.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..
