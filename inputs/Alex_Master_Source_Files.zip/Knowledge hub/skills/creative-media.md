# Creative Media

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## ad-audio-polish

[S001] Source: `/Users/alexlobaito/.agents/skills/ad-audio-polish/SKILL.md`; kind: canonical. Modified UTC: 2026-09-22T21:36:04.984030+00:00. SHA-256: `6313ddb3f9fbb85a46a4d51307dfafa954b684f90281473af4f1ed5fd6075308`.

**Trigger/purpose:** Clean and master the audio of a talking-head ad or short (denoise, echo, EQ, loudness to -14 LUFS), lay a music bed under the voice, cut in b-roll with velocity-matched seams, and add captions/hook/CTA text, all on Alex's Mac with nothing uploaded. Use whenever he sends a video clip and says the audio sounds bad, quiet, echoey, "off", or asks to optimize audio, add music, add b-roll, add captions, make it sound or look like a viral clip, or prep an ad for TikTok/Reels/Shorts. Use it even if he only says "fix this" with an mp4 attached.

**Contents:** Ad audio polish; Rules that came from real corrections (read first); Targets (from EBU R128 / R128 s2 and every short-form guide); Tools; Verify before sending; Where things are.

**Opening guidance (source excerpt):** All tools live in `/Users/alexlobaito/Documents/Ai Helper/tools/audio/` (the copies under `scripts/` here are references; run the ones in `tools/audio` because the models and the Python env sit next to them). Nothing leaves the machine. Never upload his clip anywhere (Descript, Riverside, Atlas upload, any web enhancer).

**Procedure cues (source excerpts):** **Use the exact file he attached.** Never rebuild from raw sources or swap in an earlier cut of mine.; **Do only what he asked, send one file, once.** No side-by-side variants, no "for comparison" copies,; **Copy what you did not touch.** If he asks for music, copy the video stream. If he asks for b-roll,; **Music starts at second 0** on a short-form ad. Sources agree the music must land in the first 1–2 s.; **Music for ads comes from a library cleared for ads**, not generic stock. On TikTok that is

**Resources:** scripts/ (5 files; metadata only).

## ad-recreator-atlascloud-codex-v3

[S002] Source: `/Users/alexlobaito/.agents/skills/ad-recreator-atlascloud-codex-v3/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:59:37.693389+00:00. SHA-256: `39437ac6dab5d9c085111bbc83f005464fb80d3c29d603053ace380bbb078a3e`.

**Trigger/purpose:** Recreate approved B2B ads or slides through Atlas Cloud, keeping the reference layout and swapping in the supplied avatar, apparel, logo and offer. Use for ad recreation or bulk creative rebuilds.

**Contents:** Universal Winning Ad Recreator v3 — AtlasCloud through Composio; v3 operating updates; 1. Collect the minimum brief; 2. Lock each recreation before generation; 3. Use AtlasCloud safely; 4. Build the prompt from the lock; 5. Execute and review; References.

**Opening guidance (source excerpt):** Rebuild approved B2B visuals through AtlasCloud. Treat each reference as a **composition brief** and the current-job assets as the **brand source of truth**.

**Resources:** references/ (1 files; metadata only); scripts/ (1 files; metadata only).

## atlas-drone-style-video

[S012] Source: `/Users/alexlobaito/.agents/skills/atlas-drone-style-video/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T18:10:10.526381+00:00. SHA-256: `22f48560d682d868b2b9232a8f59863a4d0de00ad2e4339bfb83eb887fe7f34c`.

**Trigger/purpose:** Make aerial drone-style video (reveal, orbit, flyover, top-down) through Composio Atlas Cloud. Use for drone shots, aerials, bird's-eye or establishing b-roll of a property, store, yard or landscape.

**Contents:** Drone-style video (Atlas Cloud); Spend rules (the user is strict about wasted credits); Inputs; Build the prompt; Generate; Be straight about what this is.

**Opening guidance (source excerpt):** One paid step through Composio toolkit `custom_atlas_cloud`, the Atlas Cloud route for every AI. Nothing here needs a shell API key or a new account. Slugs are `CUSTOM_ATLAS_CLOUD_` plus the tool name in capitals (`atlas_generate_video` -> `CUSTOM_ATLAS_CLOUD_ATLAS_GENERATE_VIDEO`); a generate call takes `model`, `params` (the JSON below) and `dry_run`. CLI: `composio execute <SLUG> -d @args.json`.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## atlas-talking-baby-video

[S013] Source: `/Users/alexlobaito/.agents/skills/atlas-talking-baby-video/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T18:10:10.526821+00:00. SHA-256: `1031e593e7bc286163585e64c0a9cff83164b016a71f8dba2a8b4467fc816b71`.

**Trigger/purpose:** Make a vertical video of a costumed baby who says a scripted line out loud, through Composio Atlas Cloud. Use for a talking baby, baby spokesperson or baby hook clip for an ad or social post.

**Contents:** Talking baby video (Atlas Cloud); Spend rules (the user is strict about wasted credits); Inputs; Step 1: the baby photo; Step 2: make it talk; Check before calling it done; Using it in an ad.

**Opening guidance (source excerpt):** Two paid steps: make the baby photo, then animate it speaking. Everything goes through Composio toolkit `custom_atlas_cloud`, the Atlas Cloud route for every AI; nothing needs an API key in the shell or a new account. Slugs are `CUSTOM_ATLAS_CLOUD_` plus the tool name in capitals (`atlas_generate_image` -> `CUSTOM_ATLAS_CLOUD_ATLAS_GENERATE_IMAGE`); a generate call takes `model`, `params` (the JSON below) and `dry_run`.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## audio-fx-hook

[S014] Source: `/Users/alexlobaito/.agents/skills/audio-fx-hook/SKILL.md`; kind: canonical. Modified UTC: 2026-09-22T21:35:38.162185+00:00. SHA-256: `0d48a9740a188133110287b8f2237291f277310bd4495c85f582ff335b78d90e`.

**Trigger/purpose:** Analyze the audio of any video (loudness, pauses, spectrogram, voice pitch over time) and apply a pitch-shifted "deep" or "squeaky" voice to just the hook of an ad, all with local ffmpeg — nothing gets uploaded. Use when Alex asks what audio effects a video uses, to "analyze the audio", to make a demon/chipmunk/deep/squeaky voice, to add a voice-effect hook to a Meta ad, or to check a video's loudness for Reels/Shorts.

**Contents:** Audio FX Hook; Job 1 — Analyze a video's audio; Job 2 — Put a voice effect on the hook of an ad; Gotchas.

**Opening guidance (source excerpt):** Two jobs, both local. Never upload his media anywhere (see memory `no-media-uploads`).

**Procedure cues (source excerpts):** Get the file. If it's a URL, download it with `yt-dlp` (install into a scratch venv with `pip install yt-dlp`; needs sandbox bypass for network).; Run `scripts/analyze.sh <video>`. It writes into `<video>-audio/`:; Read `spec.png` and `pitch.txt` and describe what you see in plain words. Always check the pitch track before saying "no pitch shifting" — on 2026-09-19 I missed an obvious deep/squeaky voice effect because I only looked at the spectrogram.; Find where the hook line ends: `scripts/hook_end.sh <video>` transcribes the first 10 s with local whisper-cli and prints word timings. Pick the end time of the last hook word.; Render: `scripts/hook_fx.sh <video> <hook_end_seconds> <factor> <label>`

**Resources:** scripts/ (4 files; metadata only).

## clip-stitcher

[S045] Source: `/Users/alexlobaito/.agents/skills/clip-stitcher/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T09:03:19.623481+00:00. SHA-256: `695d5b473fc78219e61e15c9ed6d84fa08c6859bdcf155d0643c8157f1d2255e`.

**Trigger/purpose:** Turn a folder of raw talking-head or UGC video clips into a phrase-by-phrase clip library (CLIP-LIBRARY.md with timestamps, which video each line is in, and a Meta direct-response brief that can be pasted into any model), and build new ad videos from an edit list with surgically clean cuts measured from the audio. Use this whenever the user sends raw ad footage, a Drive or Downloads folder of videos, teleprompter takes, or an edit list like "AD-21 #1, #3, AD-22 #8-9b", or asks to transcribe clips, rename videos by content, rank or stitch ads, cut clips up, splice a hook onto another offer, make top-of-funnel or retargeting ads from existing footage, fix a bad cut, remove a gap or breath, or reorder lines in a cut. Use it even if they only say "make an edit for this" or "cut this tighter".

**Contents:** Clip stitcher; How to work with the user on this; Stage 1: get the footage and see what it is; Stage 2: build the library; Stage 3: build an edit; When the user asks for your picks.

**Opening guidance (source excerpt):** Raw ad footage usually holds a better ad than any single take: the best hook is in one clip, the proof in another, the offer in a third. This skill makes that footage searchable line by line, lets the user (or any other model) write an edit as a short list, and builds that edit with cuts clean enough to run.

**Procedure cues (source excerpts):** Make a contact sheet and look at it:; If the user wants the files renamed by content, rename them `TYPE-NN_short-description.ext`

**Resources:** scripts/ (5 files; metadata only); assets/ (2 files; metadata only).

## embedded-captions

[S070] Source: `/Users/alexlobaito/.agents/skills/embedded-captions/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.880560+00:00. SHA-256: `761d9cd5e03fc10cc7f09faf8a47c56aa3a67ab558123e6c59a06c52872664eb`.

**Trigger/purpose:** Add captions or subtitles to an existing single-subject talking-head video without editing the footage. Use for plain verbatim captions, cinematic captions embedded behind the subject, VFX captions, “炸/特效/酷炫字幕,” or a named identity from the 35-style catalog. Route by visual identity, not by backend engine. The quiet `anchor` rail is the default; embed every word only when the user explicitly wants a fully cinematic treatment. The workflow runs locally end to end, including transcription and subject matting; split multi-shot footage before applying it.

**Contents:** Embedded Captions; Runtime prerequisites; Operational flow (TL;DR); Caption model — rail + embed; Step 0 — pick ONE identity from the CATALOG; Decision gate — RUN FIRST; Pre-flight probes (cost nothing, prevent the worst failures); Pipeline — 5 steps; Step 3 — Cinematic mode (pure embed); Step 3 — Theme mode (themed constitution); Visual QA — preview BEFORE you render; The DNA registry — ten visual languages (replaces the template catalog); Aesthetic decision — tone × shot × platform (input to the catalog shortlist, NOT a second router); Composition craft (embed track) — read before embedding; Shared knowledge; Non-negotiables; Dependencies.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **Decision gate** (refuse bad clips) → **pick ONE identity from [CATALOG.md](/Users/alexlobaito/.agents/skills/embedded-captions/CATALOG.md)** (35 identities; engine/compiler derived by lookup — never surface a mode/category question); `hyperframes init` (skip it if the project dir already exists with the video inside — `matte.cjs`/`transcribe.cjs` adopt any video in the dir as source.mp4) → **`bash scripts/prepare.sh <project>`** (matte ∥ transcribe ∥ audio-envelope in parallel, then safe-zones v2 with scene palette/optics/lighting — one command, nothing forgotten); **author a small JSON of creative choices** (read `safe-zones.json` first): Cinematic → `plan.json` → `fill-timings.cjs` → `fit-fonts.cjs` → `make-composition.cjs`; Theme → `theme.json` → `make-theme.cjs` (rail/panel/poem/takeover paradigms; `anchor` is the quiet rail default); **Visual QA**: `node scripts/preview-frames.cjs <project>` → faithful composite previews in ~2s/frame (no render). Check § Visual QA before paying for a render.; `render-and-composite.sh` → gates (timing / occlusion+hero / overflow / hand-off) → `final.mp4`

**Resources:** references/ (16 files; metadata only); scripts/ (27 files; metadata only); assets/ (3 files; metadata only).

## excalidraw-diagram

[S072] Source: `/Users/alexlobaito/.agents/skills/excalidraw-diagram/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T09:29:27.390758+00:00. SHA-256: `54bd1cd5cc9935f3729fa18dad25c71400e041f0a4c37bb808296eb766d4372d`.

**Trigger/purpose:** Generate Excalidraw diagrams from text content. Supports three output modes - Obsidian (.md), Standard (.excalidraw), and Animated (.excalidraw with animation order). Triggers on "Excalidraw", "画图", "流程图", "思维导图", "可视化", "diagram", "标准Excalidraw", "standard excalidraw", "Excalidraw动画", "动画图", "animate".

**Contents:** Excalidraw Diagram Generator; Output Modes; Workflow; Output Formats; Mode 1: Obsidian Format (Default); Excalidraw Data; Text Elements; Drawing; Mode 2: Standard Excalidraw Format; Mode 3: Animated Excalidraw Format; Diagram Types & Selection Guide; Design Rules; Text & Format; Layout & Design; Color Palette; JSON Structure; Element Template; Additional Technical Requirements; Text Elements 处理; 坐标与布局; Required Fields for All Elements; Text-Specific Properties.

**Opening guidance (source excerpt):** Create Excalidraw diagrams from text content with multiple output formats.

**Procedure cues (source excerpts):** **Detect output mode** from trigger words (see Output Modes table above); Analyze content - identify concepts, relationships, hierarchy; Choose diagram type (see Diagram Types below); Generate Excalidraw JSON (add animation order if Animated mode); Output in correct format based on mode

**Resources:** references/ (1 files; metadata only).

## faceless-explainer

[S076] Source: `/Users/alexlobaito/.agents/skills/faceless-explainer/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.901335+00:00. SHA-256: `8745992c08b21e767e8f972d9c19f7457800c8481a5f70ba02a8fc575eb62e21`.

**Trigger/purpose:** Turn arbitrary text — an article, notes, a topic, a brief — into a faceless explainer video: there is no site or footage to capture, so the visuals are invented per scene (typography, abstract graphics, diagrams, data-viz). Use for topic explainers, concept breakdowns, how-tos, listicles. Not a video built from a website (/product-launch-video — promo or tour). Unclear → /hyperframes.

**Contents:** Faceless Explainer to HyperFrames; Step 0: Setup; Step 1: Brief (no capture); Step 2: Design System; Step 3: Storyboard and Script; Step 3.1: Audio; Step 4: Frame Visual Design; Step 5: Build Frames; Step 6: Finalize; Quick Reference.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (4 files; metadata only); scripts/ (21 files; metadata only).

## general-video

[S087] Source: `/Users/alexlobaito/.agents/skills/general-video/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.906682+00:00. SHA-256: `4d7c52972a800c1413c222a107891cbee9c43f3bed5fa3c09157d5442bf65efe`.

**Trigger/purpose:** Author or edit a custom HyperFrames composition when no specialized workflow fits, or when BRIEF.md sets flow: companion. Use for longer or multi-scene pieces, brand and sizzle reels, montages, static loops, static title cards, footage remixes, and freeform builds. Use motion-graphics instead for a short unnarrated motion-first unit, including an animated title. Route fresh creation through hyperframes before using this skill.

**Contents:** General video; 1. Apply cross-cutting source adapters; 2. Start from project state; 3. Interpret the run shape; Companion flow; 4. Load required knowledge before each stage; 5. Execute the composition; 6. Gates that always apply; Keep scope exact; Establish design before HTML; Preserve the composition contract; Borrow workflows safely; 7. Done.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **Plan.** State the viewer arc, structure, rhythm, and duration driver. Use one file for a short single scene; use sub-compositions for three or more hard scene cuts or any reused scene. Read `/hyperframes-creative` → `references/story-spine.md` for narrated arcs, `references/beat-direction.md` for rhythm, and `/hyperframes-core` → `references/composition-patterns.md` for structure. For an open-ended multi-scene brief, expand the prompt through `/hyperframes-creative` → `references/prompt-expansion.md`. A multi-scene plan cites each scene's shape: a blueprint id from `/hyperframes-animation` → `blueprints-index.md` when one fits, or the named rules it composes from `rules-index.md` when none does — motion names come from those indexes, never invented. Story truth decides which scenes exist; the citation dresses them. **Search the live catalog before you plan to build any named look yourself**: for every look, effect, treatment or transition the brief names — "CRT scanlines", "glitch", "film grain", "shimmer sweep", "confetti burst" — run `npx hyperframes catalog --query "<the look, in plain English>" --json` and read the top results before the plan names how that look gets built. The search needs **nothing installed**: no project, no prior `add`, no account. It ranks the whole hosted registry (~400 blocks and components) from any directory, so it also applies to a look the user asks for mid-build. Blocks the plan names are installed at stage 3; hand-author a look only after a search for it came back with nothing that fits. A multi-scene plan is also recorded as the dispatch artifact: one `## Frame N` block per scene in `STORYBOARD.md` — `status: outline`, a declared `src:`, the blueprint/rules citation, and the beat text — **even when `storyboard: no`**. The block is the dispatch unit; the storyboard sheet is only the review surface.; **Review the plan when requested.** For `storyboard: yes`, run the shared review loop over those blocks. For `storyboard: no`, continue without a plan pause or sketch sheet. When a plan pause happens anyway, fold the sub-agent delegation grant (needed by codex for step 4's dispatch) into that pause rather than stopping again later.; **Resolve dependencies.** Install registry blocks before parallel work. Stage user assets, adopt existing media, and resolve only what the brief requires. Start audio early when its timings drive duration.; **Build scenes.** For a short single-scene piece, implement the scene at its most visible moment before adding motion (the confirmed wireframe, when present, is that end state and must not be redrawn), then animate from its cited blueprint or rules — read the full recipe body (`/hyperframes-animation` → `blueprints/<id>.md`, `rules/<id>.md`) before writing motion.; **Merge motion sidecars.** Collect the workers' `compositions/<frame_id>.motion.json` files and carry their durations and exit/entry vectors into assembly; where the doctrine chain (`/motion-doctrine`) is installed, translate them into the project ledger before stamping seams.

**Resources:** scripts/ (3 files; metadata only).

## higgsfield-hot-tub-scene-variation

[S091] Source: `/Users/alexlobaito/.agents/skills/higgsfield-hot-tub-scene-variation/SKILL.md`; kind: canonical. Modified UTC: 2026-10-02T01:40:30.657823+00:00. SHA-256: `f611af86b3198cc46b8e5c61b1604b9303474ea9a676c1e990ed774a2f4ffdbc`.

**Trigger/purpose:** Use for Higgsfield batches of the same hot tub in new scenes, like “same tub in California,” “10 of these,” new camera angles, showroom, patio or snowy backyard. Not for same-scene cleanup.

**Contents:** Higgsfield Hot Tub Scene Variation; Contract; Protect truth; Classify the request; Assign reference authority; Lock the fingerprint; Build the manifest; Enforce phone-photo realism; Generate; Run mandatory QC; Correct within caps; Deliver; Hard rules.

**Opening guidance (source excerpt):** Turn real reference photos of one hot tub into the requested quantity of new-scene images of that same product. Treat the references as the specification. Never substitute a similar tub or invent hidden features. Product fidelity beats scene variety and beauty.

**Procedure cues (source excerpts):** `SAME-ANGLE SCENE SWAP`: Preserve product viewpoint and geometry; change environment, time, lighting, or people. This is highest fidelity.; `SUPPORTED NEW ANGLE`: Use only when supplied real photos cover every newly visible shell, cabinet, control, jet, and hardware surface.; `UNSUPPORTED NEW ANGLE`: Ask only for the missing real front/side/back/top photo and stop.; `MULTI-PRODUCT SHOWROOM`: Require one product pack per distinct tub. With one pack, repeat only that exact tub.

**Resources:** assets/ (1 files; metadata only).

## hyperframes

[S093] Source: `/Users/alexlobaito/.agents/skills/hyperframes/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.911398+00:00. SHA-256: `ce542b8e03b4b9268bcda0f95790b1cf869b4ff9b3faf803c2abf816fd51c54c`.

**Trigger/purpose:** Mandatory entry point: read this first for any request to make, create, edit, animate, or render a video, animation, or motion graphic, including a promo, explainer, captioned clip, title card, overlay, slideshow or interactive deck, Remotion port, or any HyperFrames HTML composition. Also use it to inspect, diagnose, validate, preview, publish, or batch-render an existing HyperFrames project. Inputs may be a website URL, GitHub PR, Figma design or URL, text or brief, existing footage, or music. It resumes project state, captures intent when applicable, selects and installs the owning workflow, and routes domain capabilities. HyperFrames is the default output framework unless the user explicitly chooses another framework for the deliverable or asks only to record a browser session.

**Contents:** HyperFrames entry point; 1. Start from project state; Keep the project's CLI current; 2. Route fresh creation; Resolve common ambiguities; 3. Route once, then leave; 4. Install and enter the workflow; 5. Load domain skills on demand.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (25 files; metadata only); scripts/ (3 files; metadata only).

## hyperframes-animation

[S094] Source: `/Users/alexlobaito/.agents/skills/hyperframes-animation/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.936877+00:00. SHA-256: `c16fed4153a9ec22b3de51a40bf1b3d756dde1835b32534291565259a413d4ad`.

**Trigger/purpose:** All animation knowledge for HyperFrames — atomic motion rules, multi-phase scene blueprints, scene transitions, broader motion-design techniques, AND the seven runtime adapters (GSAP default, plus Lottie, Three.js, Anime.js, CSS keyframes, Web Animations API, TypeGPU). Use for any motion or animation task: pick 2-4 rules and compose, or load a blueprint, or look up runtime-specific API (e.g. GSAP eases / Lottie player / Three.js mixer). Also covers auditing an existing composition's choreography (animation map) and 24 named text-animation effects. HyperFrames-native: single paused timeline, seek-safe, deterministic.

**Contents:** HyperFrames Animation; Default: compose atomic rules; Load a blueprint when; Routing; Picking a runtime; Critical Constraints; Scripts; See Also.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (1 files; metadata only); scripts/ (6 files; metadata only); examples/ (13 files; metadata only).

## hyperframes-audio

[S095] Source: `/Users/alexlobaito/.agents/skills/hyperframes-audio/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.963915+00:00. SHA-256: `70fedc7b32e6fe1dd1076c932d8853775271d9a29d03b97340c695a4d391c397`.

**Trigger/purpose:** Use when audio already placed in a HyperFrames composition needs to be mixed: fade-in/fade-out, crossfade, track gain or volume, volume automation, ducking, a music bed that fights a voiceover (voiceover carve), effects on a track (EQ, compressor, limiter, gate, saturation, delay, reverb, chorus, phaser, bitcrush), automation envelopes drawn on a track's volume or any effect parameter, or one submix bus carrying a chain, a fader and an automation clock for several tracks at once (`<hf-audio-group>`). Don't use for sourcing or generating audio — finding BGM, SFX, or making a voiceover is `/media-use`. Don't use for clip timing or track layout, which is `/hyperframes-core`.

**Contents:** HyperFrames Audio; How it fits together; First, work out what is wrong; Start from the symptom; Reach for a family by the problem, not the name; Voiceover carve; One bus for many tracks; Automation; Verify.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (4 files; metadata only); scripts/ (2 files; metadata only).

## hyperframes-cli

[S096] Source: `/Users/alexlobaito/.agents/skills/hyperframes-cli/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.971982+00:00. SHA-256: `f94a4c7f11fae1d2af70330e83ceb9f13e1d0ff5cec3ee113184fb089038356f`.

**Trigger/purpose:** Use the HyperFrames CLI development loop: init, add, catalog, capture, lint, check, snapshot, compare, grade-compare, preview, play, present, beats, keyframes, single or batch render, publish, cloud, cloudrun, feedback, lambda, doctor, browser, info, upgrade, skills, compositions, timeline, history, clean, docs, benchmark, telemetry, transcribe, auth, tts, and remove-background. Also use when diagnosing build or render failures. validate, inspect, and layout are deprecated aliases; use check. Covers local, HeyGen-hosted cloud, AWS Lambda, and Google Cloud Run rendering.

**Contents:** HyperFrames CLI; Development loop; Project history in your turn; Mandatory creator-edit cross-references; Fast iteration check; repeat while authoring as needed.; Required final gate; includes lint.; Preview before render; Sub-composition smoke test; Agent conventions; Studio-directed edits; Render choices; Read the matching reference before running a command; Commands you should not run.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **Scaffold:** `npx hyperframes init <project>` (centered blank). Or capture a site. Pass `--example=<name>` only to start from a named example.; **Find the move:** if the request names an asset, sound, image, voice or fast visual edit, resolve it through `/media-use` before proposing a plan. Otherwise, before authoring motion by hand, search for a primitive that already does it: `npx hyperframes catalog --query "reveal a headline one line at a time"`. Ask for the effect you want rather than the mechanism you have in mind. Install with `npx hyperframes add <name>` (see `/hyperframes-registry`). Author by hand only once nothing fits.; **Author:** write the composition using `/hyperframes-core`. To know what is on a project's timeline (tracks, clips, starts, ends, what plays), run `npx hyperframes timeline --json` instead of reading `index.html` and every sub-composition file: nested rows carry absolute main-timeline `absStart`/`absEnd` and their owning `file`, not just their local, per-sub-composition time. Prefer `--json` over the text form; it costs fewer tokens for the same or better correctness. See `references/upgrade-info-misc.md` for one-liners that answer common questions without reading the whole output.; **Get fast feedback while editing:** run `npx hyperframes lint` after the first HTML pass and after structural changes.; **Run the final gate:** run `npx hyperframes check`; it reruns lint before opening the browser. Do not prepend a redundant standalone lint invocation. Add `--snapshots` for annotated overview frames and finding crops.

**Resources:** references/ (10 files; metadata only).

## hyperframes-core

[S097] Source: `/Users/alexlobaito/.agents/skills/hyperframes-core/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:38.984925+00:00. SHA-256: `c232a83c0cae2c7fc789fb25b85c3bf9f59f5be402bca3fd63a1ad18c6ed62c9`.

**Trigger/purpose:** The HyperFrames composition contract — build one renderable project. Use for composition structure, the `data-*` timing attributes, `class="clip"`, tracks, sub-compositions, variables, framework-owned media playback, deterministic-render rules, and validation. Read before writing composition HTML.

**Contents:** HyperFrames Core; References; Building a composition; Two root forms (not interchangeable); Root must be sized (silent layout bug); One paused timeline; First-pass lint gotchas (a guaranteed first build failure); Non-negotiable rules (silent bugs automated gates may miss); Editing existing compositions; Validation.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (10 files; metadata only).

## hyperframes-creative

[S098] Source: `/Users/alexlobaito/.agents/skills/hyperframes-creative/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.039212+00:00. SHA-256: `3ea9a6108ad547ba52742520281ad61e15edd7b969f3829072e3eb70e1c06cec`.

**Trigger/purpose:** Non-animation creative direction for HyperFrames videos. Use for design spec (frame.md / design.md) handling, palettes, typography, narration, beat planning, audio-reactive visuals, composition patterns, and brand / style decisions. For atomic motion patterns and scene blueprints, use `hyperframes-animation`.

**Contents:** HyperFrames Creative; Workflow; Routing; Scripts; Boundaries.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** If a project has a design spec, **read it first** and treat its frontmatter tokens as brand truth (colors, fonts, spacing, tone, constraints). Which file to read (precedence `frame.md` → `design.md` → `DESIGN.md`) and how to parse it (frontmatter = normative, prose = context) are defined once in [`references/design-spec.md`](/Users/alexlobaito/.agents/skills/hyperframes-creative/references/design-spec.md) — resolve and load per that doc.; If no design spec exists and the user asks for visual direction, choose a route:; For multi-scene work, plan beats and rhythm before writing HTML → `references/beat-direction.md`. For scene transitions, jump to `hyperframes-animation/transitions/`.; For motion-heavy work, read `references/motion-principles.md` (high-level guardrails), then go to `hyperframes-animation` for atomic rules.

**Resources:** references/ (16 files; metadata only); scripts/ (4 files; metadata only); templates/ (1 files; metadata only).

## hyperframes-keyframes

[S099] Source: `/Users/alexlobaito/.agents/skills/hyperframes-keyframes/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.057113+00:00. SHA-256: `6356d2f77036c19e8773bf940dccb917d05f00c2dabda1cbf08894eecf54625a`.

**Trigger/purpose:** Use when a HyperFrames composition needs a punch-in, punch-out, zoom, reframe, Ken Burns treatment, camera move, visual match/whip handoff, or other seek-safe 2D/3D keyframes; also for GSAP, CSS keyframes, Anime.js, WAAPI, FLIP, paths, masks, SVG morph/draw, text trails, 3D depth, or `hyperframes keyframes` diagnostics. Don't use for broad scene strategy, brand design, media sourcing, captions, or general video planning.

**Contents:** HyperFrames Keyframes; Creator editing boundary; Procedure; Contract; Runtime Rules; GSAP Skeleton; Keyframe Forms; Channels; Mechanism Choice; Timing; Text; SVG; 3D; Canvas / WebGL; CLI Proof; Diagnostic Reading; Error Handling; Done.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** Identify the animated subject, visible states, final state, and runtime.; Choose the smallest mechanism that proves the prompt. Read `references/keyframe-patterns.md` only if the mechanism is unclear.; Author seek-safe keyframes in the declared runtime. Build synchronously and register the runtime instance.; Verify with `hyperframes lint`, `hyperframes check`, `hyperframes keyframes`, one focused `--shot`, and snapshots at proof times.; If proof fails, fix the source keyframes and rerun the smallest failing diagnostic before rendering.

**Resources:** references/ (1 files; metadata only).

## hyperframes-registry

[S100] Source: `/Users/alexlobaito/.agents/skills/hyperframes-registry/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.069503+00:00. SHA-256: `5c0fa72f016897b78d1bb7589179eb44eed5572813fd044df94fa09ec52ad4ee`.

**Trigger/purpose:** Search, install, and wire registry blocks and components into HyperFrames compositions. Use BEFORE hand-building any named visual — whenever a brief, a user, or a storyboard names a look, effect, treatment, or transition such as CRT scanlines, glitch, chromatic aberration, film grain, a shimmer sweep, a chart, a code or terminal window, a map, or a confetti burst — because roughly 400 hosted items already cover many of them and the search ranks all of them with nothing installed, no project, and no account. Also use when running hyperframes add or hyperframes catalog, installing one item or every block matching a tag, wiring an installed item into index.html, or working with hyperframes.json. Covers discovery, install locations, block sub-composition wiring, component snippet merging, and authoring a new block or component to contribute upstream (idea → scaffold → validate → PR).

**Contents:** HyperFrames Registry; Quick reference; Install locations; Wiring blocks; Wiring components; Discovery; Rank the whole catalog against what the beat should do; Report what the catalog does not have; Contributing a new block or component.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** Read the installed file (e.g., `compositions/components/grain-overlay.html`); Copy the HTML elements into your composition's `<div data-composition-id="...">`; Copy the `<style>` block into your composition's styles; Copy any `<script>` content into your composition's script (before your timeline code); If the component exposes GSAP timeline integration (see the comment block in the snippet), add those calls to your timeline

**Resources:** references/ (9 files; metadata only); examples/ (2 files; metadata only).

## hyperframes-studio

[S101] Source: `/Users/alexlobaito/.agents/skills/hyperframes-studio/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.077046+00:00. SHA-256: `948c745b0ad9640f0feb3dd46ac589533276e051f545cf1b039c0907d467bc0c`.

**Trigger/purpose:** Use when working with a person on a HyperFrames project in Studio: first, whether their message asks for a change at all (questions, loose ideas and "don't change anything" get an answer and a plan, not an edit); for a new film, the plan, storyboard and build order that the HyperFrames launch films follow; and how the timeline should be laid out so it reads well (one caption track, one element kind per track, every scene a sub-composition) and where captions and key content may sit (safe zones). Don't use for how to perform an individual edit (split, trim, retime, volume, copy, swap): that is `creator-editing-recipes.md` in `/hyperframes-core`.

**Contents:** HyperFrames Studio conventions; 0. Talk before you build; 1. Every scene is a sub-composition; 2. One caption track; 3. One element kind per track; 4. Safe zones; 5. A new film: plan, storyboard, build; Checking your work.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## image

[S102] Source: `/Users/alexlobaito/.agents/skills/image/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.467125+00:00. SHA-256: `c34b67e249e558410ee960043d0de3c1d188dc3b6ba36d7714c16ec6f1fad46e`.

**Trigger/purpose:** When the user wants to create, generate, edit, or optimize images for marketing — blog heroes, social graphics, product mockups, profile banners, listing visuals, or brand assets. Also use when the user mentions 'AI image generation,' 'generate an image,' 'create a graphic,' 'product mockup,' 'hero image,' 'social media graphic,' 'banner image,' 'cover photo,' 'profile banner,' 'listing screenshot,' 'Flux,' 'Flux Kontext,' 'Midjourney,' 'DALL-E,' 'GPT Image,' 'ChatGPT Images,' 'Ideogram,' 'Gemini image,' 'Nano Banana,' 'Recraft,' 'Stable Diffusion,' 'Canva,' 'Figma,' 'image optimization,' 'compress images,' 'WebP,' or 'OG image.' Use this for general-purpose marketing image creation and optimization. For paid ad image creative and platform-specific ad specs, see ad-creative. For video production, see video.

**Contents:** Image; Before Starting; 1. Image Goal; 2. Production Approach; 3. Technical Context; Choosing Your Approach; AI Image Generation; Model Comparison; When to Use Which; Prompting Basics; Design Tools; Canva; Figma; When to Use Design Tools vs. AI Generation; Marketing Image Workflows; Blog & Article Hero Images; Social Media Graphics; Product Mockups & Screenshots; Profile & Listing Banners; Brand Assets; Image Optimization; Format Guide.

**Opening guidance (source excerpt):** You are an expert visual content producer who helps create marketing images using AI generation models, design tools, and optimization best practices. Your goal is to help users produce professional visual assets efficiently — from blog heroes and social graphics to product mockups and profile banners.

**Procedure cues (source excerpts):** **Define the concept** — what visual metaphor represents the topic?; **Generate with AI** — use Flux or Gemini for photorealistic, Ideogram if text needed; **Specify 1200x630** (works for both hero and OG image) or **1920x1080** for full-width; **Optimize** — compress to <200KB, serve as WebP with JPEG fallback; Create the hero concept at highest resolution needed

**Resources:** references/ (1 files; metadata only).

## manim-animator

[S112] Source: `/Users/alexlobaito/.agents/skills/manim-animator/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:56.274428+00:00. SHA-256: `9911c3b280628a01c2c3158254115f0691bff73ad8c8660946d0ad98bd4aafe2`.

**Trigger/purpose:** Generate code-driven explanatory animation videos and precise vector graphics using the Manim engine. Use when the user requests mathematical visualizations, algorithm walkthroughs, scientific concept explanations, step-by-step derivations with LaTeX equations, or animations in the style of 3Blue1Brown — or explicitly mentions Manim, ManimCE, or ManimGL. Do not use for photorealistic AI video generation or standard timeline editing.

**Contents:** Manim Skill; Seven-stage workflow; File map; Key invariants (never violate); Working with Manus-native media tools.

**Opening guidance (source excerpt):** Manim is a Python engine for code-driven vector animation, created by 3Blue1Brown and forked into a community edition. This skill turns a user's idea into a final MP4 through seven stages. Most of the specialized knowledge lives in the `references/` tree and is loaded only when a stage needs it; keep this SKILL.md as the navigation map and workflow spine.

**Resources:** references/ (154 files; metadata only); scripts/ (5 files; metadata only); templates/ (1 files; metadata only).

## media-use

[S115] Source: `/Users/alexlobaito/.agents/skills/media-use/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.101905+00:00. SHA-256: `6baf869f1e33bbe8d15ad1e7fc5db182899bdf5ccf42a05fb452c42b61e32d52`.

**Trigger/purpose:** Agent Media OS, the single skill for every media need in a HyperFrames project. Resolve BGM, SFX, image, icon, brand logo, voice, color grade, or LUT into a frozen local file or paste-ready block + ledger record (one verb, `resolve`); generate via TTS / music / image models when the catalog misses; produce voiceover, transcription, captions, and background removal through one shared audio engine; operate on media (cut / reframe / transform); and reuse assets across projects. Also use for vague feedback that real footage looks dark, flat, boring, should feel retro/camcorder/print/ASCII, needs privacy, or needs a media reveal.

**Contents:** media-use; Resolve — the one verb; Treat broad visual feedback as media intent; Be proactive — run a media opportunity pass; Where to look — read only the file your task needs.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (10 files; metadata only); scripts/ (28 files; metadata only).

## motion-graphics

[S121] Source: `/Users/alexlobaito/.agents/skills/motion-graphics/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.132563+00:00. SHA-256: `d2139f2b6e56e94ee320546c8353aa3ceae84b20c335f6c2096474e89d5241e2`.

**Trigger/purpose:** A short, design-led motion graphic where motion is the message — kinetic typography, stat count-up, chart/data-viz hit, logo sting / brand lockup, lower-third / callout / social overlay, animated map (highlight regions, connect places, zoom to a location), animated tweet / news-article / headline, webpage / UI animation (scroll, cursor, callouts), or fusing a real image's geometry into a chart. Usually under 10s (up to ~30s), no narration or live-action subject; renders to MP4 or transparent overlay. Longer / narrated / multi-scene → /general-video. Unclear → /hyperframes.

**Contents:** motion-graphics — dispatch entry; Categories — split by the search decision; Prerequisites; Flow; Step 0 — Initialize; Step 1 — Plan (subagent: Director Part 1); Step 2 — Source ◇ (Bash: media-use, conditional); illustrative — see phases/source/guide.md; Step 3 — Design (subagent: Director Part 2); Step 4 — Build (subagent: Builder, reuse-first); Step 5 — Verify (Bash → repair subagent on failure); Step 6 — Approve and render (Bash); transparent overlay variant: --format webm (or mov); Resume table; Design notes (maintainers — execution does not read this).

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **Decide: does this need a search?** (the first fork); Write a draft `shot-plan.json` (envelope + chosen form category _or_ search intent + `asset_needs` + a one-paragraph shot brief). Schema: `references/shot-plan-ir.md`.

**Resources:** references/ (3 files; metadata only).

## music-prompter

[S122] Source: `/Users/alexlobaito/.agents/skills/music-prompter/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:54.458519+00:00. SHA-256: `a302bf1296f09a2a581968e10266afd8d0c6d88fe3580ad5992c935ff5a01b45`.

**Trigger/purpose:** MUST read this skill BEFORE entering generate mode for music tasks. Covers prompt crafting framework, structure syntax, and multi-clip strategy.

**Contents:** Music Generation Prompt Guide; 1. Duration Awareness; 2. The 9-Dimension Framework; 3. Standard Prompt Structure; 4. Detailed Structure Example; 5. In-Text Negative Prompting; 6. Emulating Advanced Controls; 7. Multi-Clip Continuity Strategy (Duration > 184s); Step 1: The Arrangement Plan; Step 2: Categorize the 9 Dimensions; Step 3: Clip Transition Design (Precise State Alignment); Step 4: Post-Processing.

**Opening guidance (source excerpt):** When crafting music generation prompts, adopt the mindset of a **world-class music arranger and producer**. Think holistically about the entire piece — its emotional arc, sonic palette, and structural flow — before writing the prompt. Your goal is to translate the user's vision into a single, cohesive musical blueprint that the model can execute in one take whenever possible.

**Procedure cues (source excerpts):** **Genre & Style**: The primary musical category and stylistic characteristics.; **Tempo & Rhythm**: The pace and rhythmic character.; **Key & Scale**: The harmonic foundation.; **Mood & Emotion**: The desired feeling the music should evoke.; **Instrumentation**: Key instruments you want to hear.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## music-to-video

[S123] Source: `/Users/alexlobaito/.agents/skills/music-to-video/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.179135+00:00. SHA-256: `4a5ac7feeb6e0298e2a2ab3d9714cd27520ccc67f15d036c13cc85326dbf915a`.

**Trigger/purpose:** Turn a music track (an audio file, a video to pull audio from, or a track generated from a mood brief) into a beat-synced video — lyric video, slideshow, or kinetic promo. The music drives all pacing; any user-supplied images/videos are cut onto the same beat grid, and a complete video needs zero assets. Narrated pieces → the input-matched workflow (see /hyperframes). Unclear → /hyperframes.

**Contents:** music-to-video — one music-grounded, beat-synced video workflow; Two ideas that shape everything; Step 0: Setup, BGM, and inputs; only if the user gave you images/videos:; Step 1: Analyze the music; Step 2: Frame skeleton (structure only); Step 3: Fill the plan (user-gated); Step 4: Build frames from the plan; Step 5: Assemble; Step 6: Verify and render; Resume table; Quick Reference; Directory layout.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **Pick the brand.** Choose one preset from `../hyperframes-creative/frame-presets/` using the table in `../hyperframes-creative/references/design-spec.md` (match the track's mood; **only its fonts and colors matter** — templates own composition). Copy it into `frame.md` **unmodified** and fill the frontmatter `style` (font + a ≤4–6 swatch palette) from it.; **Fill every frame.** Decide its groups and give each a treatment: a matched template from the catalog (with bound params and real audiomap anchors), a free-compose from the primitive catalog, or an asset treatment that **obeys `pacing`**. **Before you free-compose a named look, search the live catalog for it**: for every look, effect, treatment or transition the user asked for — "CRT scanlines", "glitch", "film grain", "shimmer sweep" — run `npx hyperframes catalog --query "<the look, in plain English>" --json` and read the top results. `template-catalog.md` and `motion-primitive-catalog.md` list only this skill's own local materials; the search ranks the whole hosted registry (~400 blocks and components) and needs **nothing installed** — no project, no prior `add`, no account. Free-compose a look only after a search for it came back with nothing that fits. Write the copy. You own WHAT (template / primitives + content + anchors); the frame-worker owns HOW — **never write millisecond tweens into the storyboard**.

**Resources:** references/ (162 files; metadata only); scripts/ (5 files; metadata only).

## product-launch-video

[S131] Source: `/Users/alexlobaito/.agents/skills/product-launch-video/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.236547+00:00. SHA-256: `5ef06256aa75ca544fdd9fccc4b16b92e45a945ee7438b2aa28b18e27a647448`.

**Trigger/purpose:** Turn a product or marketing URL, pasted script, or brief into a product launch / promo video — SaaS promos, feature reveals, product demos, app and company launches. Use when the user wants to market, launch, promote, or reveal a product; the default for any commercial URL. Site tours / showcases of a website route here too — the brief carries the show-it-as-is intent. Unclear → /hyperframes.

**Contents:** Product Launch to HyperFrames; Step 0: Setup; Step 1: Capture assets; Step 2: Design System; Step 3: Storyboard and Script; Step 3.1: Audio; Step 4: Frame Visual Design; Step 5: Build Frames; Step 6: Finalize; Quick Reference.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Resources:** references/ (4 files; metadata only); scripts/ (28 files; metadata only).

## talking-head-recut

[S155] Source: `/Users/alexlobaito/.agents/skills/talking-head-recut/SKILL.md`; kind: canonical. Modified UTC: 2026-09-30T05:53:39.283236+00:00. SHA-256: `a3b6084b4be1e23be6bc04e8b98bb96d073badf335a3c02befd91fa808e644a4`.

**Trigger/purpose:** Package an existing talking-head / interview / podcast video with timed, designed GRAPHIC OVERLAY cards — kinetic titles, lower-thirds, data callouts, quotes, side panels, picture-in-picture — synced to the transcript, on a 16:9 / 9:16 / 4:5 canvas of your choice; the clip plays untouched underneath. Trigger on "graphic overlays", "on-screen graphics", "package / dress up my video". Not plain subtitles (/embedded-captions). Unclear → /hyperframes.

**Contents:** Talking Head Recut; CLI Resolution; hyperframes — transcription (local Whisper) + rendering the assembled HTML to MP4; Workflow; 1. Check Environment; confirm bundled assets:; 2. Create a Work Directory; 3. Extract Audio and Metadata; metadata — duration / width / height / fps; audio; 4. Transcribe; 5. Correct Transcript; 6. Draft a Lightweight Storyboard (in chat); 7. Decide Render Strategy; Confirm Visual Direction with User (DO THIS FIRST); Render Strategy Inputs; Visual Design Library (<SKILL_DIR>/references/); Layout Compositions (Card + Video); Storyboard Render Contract; 8. Write Each Card's HTML; Card HTML Contract; Card Sizing — Mobile-First in Portrait.

**Opening guidance (source excerpt):** **Plugin installs:** Before setup or freshness commands, follow [plugin execution rules](/Users/alexlobaito/.agents/skills/hyperframes/references/plugin-installation.md) when this skill is inside a HyperFrames plugin. Standalone installs keep the update instructions below.

**Procedure cues (source excerpts):** **`recommendedRatio`** from the source video's aspect ratio; **`autoCount`** from Step 6 (`max(5, round(videoSec / (basePace ×; **Native clarification tool** — use the structured 4-question call below.; **Other native clarification tool** (e.g. `ask_question`,; **No native tool** (Codex CLI, plain text-only runtimes) — **ask

**Resources:** references/ (18 files; metadata only); assets/ (7 files; metadata only).

## tts-prompter

[S159] Source: `/Users/alexlobaito/.agents/skills/tts-prompter/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:56.847075+00:00. SHA-256: `884068463fe99a73de05f03b97cfc869e1fae80cbbbb2a347d60685b51d11804`.

**Trigger/purpose:** MUST read this skill BEFORE entering generate mode for text-to-speech (TTS) tasks. Covers prompt crafting framework, separating spoken text from style instructions, and using markup tags vs natural language for emotions and non-speech sounds.

**Contents:** TTS Prompter; 1. The Ultimate TTS Formula; Multi-speaker Conversations; 2. Part 1: Style Instructions (Before the Colon); 2.1 Controlling Language, Emotion, Tone & Accent; 2.2 Emotion & Tone; 2.3 Pacing & Volume; 3. Part 2: Spoken Text (After the Colon); 3.1 Using Markup Tags; DO Use Tags For:; DO NOT Use Tags For:; 4. Duration vs Faithfulness; 5. References: Voice & Language Selection; 5.1 Voice Catalog; 5.2 Supported Languages.

**Opening guidance (source excerpt):** This skill provides the definitive framework for crafting high-quality Text-to-Speech (TTS) prompts. You MUST follow these guidelines when generating speech to ensure natural, expressive, and predictable audio output.

**Procedure cues (source excerpts):** **Non-speech sounds:** `[sigh]`, `[laughing]`, `[uhm]`, `[cough]`, `[gasp]`, `[snorts]`; **Local style shifts:** `[shouting]`, `[whispering]`, `[extremely fast]`, `[sarcasm]`, `[asmr]`; **Pacing and pauses:** `[short pause]` (~250ms), `[medium pause]` (~500ms), `[long pause]` (~1000ms+)

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## typst-pdf-maker

[S161] Source: `/Users/alexlobaito/.agents/skills/typst-pdf-maker/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T14:45:31.966603+00:00. SHA-256: `bf368da916f2644e179261b90b99e2396b59360cc51e75e341950c93f6f28f0c`.

**Trigger/purpose:** Generate professional, high-quality PDF documents with Typst. Use for reports, academic papers, resumes, structured documents, mathematical typesetting, code-rich documents, precise layouts, and CJK typography when Markdown-to-PDF is insufficient. Select one skill-owned asset or compatible Typst Universe base before adding packages. Route ordinary presentation requests to Manus Slides/PPTX unless the user explicitly requires Typst-generated PDF slides.

**Contents:** Typst PDF Maker; Local paths; Prerequisite; Routing workflow; How to locate and execute the selected base; Native professional report; Existing Markdown source; Existing Typst project or Universe base; Best practices; Default delivery scope; Verification checklist; Bundled resources.

**Opening guidance (source excerpt):** `SKILL_DIR` is the directory that contains this `SKILL.md`. Resolve it from the skill path you just opened. Never call `/home/ubuntu/...`. Write outputs in the current workspace (`./my-report`, `./keyword_research.xlsx`), not under `/home/ubuntu`.

**Procedure cues (source excerpts):** Build a compact **content manifest** and save it as `.typst-content-manifest.json` in the working directory. Complete it before planning: inspect the source and acceptance criteria once, and record every observable package-triggering feature. Do not run the planner with a partial manifest. Use the planner's real keys rather than inventing synonyms:; Run the deterministic planner once after the manifest is complete. This is the normal way to find templates and packages: it reads `references/routing-catalog.json` without loading the entire catalog into conversational context. Freeze the resulting plan when base initialization or authoring begins. Rerun only to resolve the plan's recorded `ambiguous` or `needs-confirmation` question, after a user or publication hard constraint changes, or after an explicitly recorded blocked/patch-required condition changes. A late optional visual idea is not a rerouting reason.; If the output plan has `reused: true`, continue without rescanning the ecosystem. The planner reuses a plan only when the content manifest, Typst version, and catalog version produce the same fingerprint.; If the plan redirects ordinary presentation, slide, PPT, or PPTX work, exit this skill and use Manus Slides/PPTX. Continue here only for explicit Typst, PDF slides, or a named Typst slide engine.; Follow the selected base exactly. The planner chooses one existing project, one required Universe template, or one skill-owned built-in asset before choosing enhancements.

**Resources:** references/ (4 files; metadata only); scripts/ (5 files; metadata only); assets/ (3 files; metadata only).

## video-generator

[S165] Source: `/Users/alexlobaito/.agents/skills/video-generator/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:54.362556+00:00. SHA-256: `37d161c8bcbbbb0b7a0c8af65efc0217acc2851f5ecd407cb2507c1be6709726`.

**Trigger/purpose:** Professional AI video production workflow. Use when creating videos, short films, commercials, or any video content using AI generation tools.

**Contents:** Video Generation; Workflow Overview; Critical Rules (MUST Follow); Image Generation Tools; Phase 1: Initial; Gather Information; Five-Dimension Expert Framework; Phase 2: Global Definitions (Text Only); Visual Style Specification; Recurring Elements; Voice Profiles; BGM Source Decision; Phase 3: Clip & BGM Planning; Segmentation Rules; Per-Clip Specification; Field Dependencies; transition_description Requirements; transition_description Examples; Physical Consistency Check; Narration Planning; [MANDATORY] Reference Image Requirements; [MANDATORY FINAL STEP] BGM Emotional Arc Blueprint.

**Opening guidance (source excerpt):** 1. **Phase 1: Initial** → Gather requirements, STOP for user confirmation 2. **Phase 2: Global Definitions** → Define style, characters, voices, BGM (text only, no images) 3. **Phase 3: Clip & BGM Planning** → Segment into clips, plan each clip, and create the final BGM blueprint 4. **Phase 4: Reference Images** → Generate reference images (MANDATORY before Phase 5) 5. **Phase 5: Execution** → Purely execute the blueprint: generate first keyframes, videos, and all audio assets

**Procedure cues (source excerpts):** **Phase 1: Initial** → Gather requirements, STOP for user confirmation; **Phase 2: Global Definitions** → Define style, characters, voices, BGM (text only, no images); **Phase 3: Clip & BGM Planning** → Segment into clips, plan each clip, and create the final BGM blueprint; **Phase 4: Reference Images** → Generate reference images (MANDATORY before Phase 5); **Phase 5: Execution** → Purely execute the blueprint: generate first keyframes, videos, and all audio assets

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## youtube-video-research

[S175] Source: `/Users/alexlobaito/.agents/skills/youtube-video-research/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:56.722813+00:00. SHA-256: `95dfb03b78cd5a1eb8960f0aab1c4addc8f697517480f1956f2c2f5f3cc1c5f0`.

**Trigger/purpose:** Enhance any deep research task with first-hand YouTube video evidence via manus-analyze-video. Highly recommended whenever the task involves deep research, investigation, report writing, industry analysis, competitive intelligence, market research, technology trends, cultural analysis, policy research, or any information-gathering task that would benefit from expert talks, interviews, keynotes, panels, documentaries, product demos, vlogs, or conference presentations on YouTube. Also use when the user explicitly mentions YouTube, video sources, or asks for first-hand evidence. YouTube contains unfiltered first-person insights (CEO interviews, expert panels, practitioner vlogs, conference talks, earnings calls) unavailable in text articles, making it a critical primary source for virtually any research topic.

**Contents:** YouTube Video Research; Trigger Guidance; Core Tools; Core Workflow; Step 1: Theme-Based Video Discovery; Step 2: Select and Prioritize Videos; Step 3: Analyze Videos with manus-analyze-video; Critical: High-Density Prompt Engineering; Optional: Two-Pass Strategy for Maximum Fidelity; Step 4: Cross-Validate with Web Search; Step 5: Synthesize into a Quote-Rich, Detail-Dense Report; Rule 1: Direct Quotes Are Mandatory; Rule 2: Detail Expansion Is Mandatory; Rule 3: Multi-Source Triangulation; Rule 4: Structured Source Attribution; Output Structure; [Research Title]; Executive Summary; [Theme 1 Title]; [Theme 2 Title]; [Additional themes...]; Source Videos Analyzed.

**Opening guidance (source excerpt):** Leverage YouTube as a **primary source of first-hand information** for research tasks. YouTube hosts CEO interviews, founder keynotes, earnings calls, expert panels, conference talks, product demos, practitioner vlogs, cultural documentaries, policy discussions, technical deep-dives, and educational content that contain unfiltered, first-person insights unavailable in text articles. This skill orchestrates video discovery, analysis, and synthesis into a structured research workflow.

**Procedure cues (source excerpts):** Identify 4-6 research themes from the user's request (e.g., for a company investment analysis: "industry background", "business model & technology", "financial data & valuation", "customer & partnerships", "bull case & growth catalysts", "bear case & risk factors").; For each theme, run 1-2 targeted YouTube search calls.; Select **2-3 videos per theme** to ensure multiple perspectives on each dimension.; Total target: **12-20 videos** for deep research, **8-12** for standard research. The power of this workflow lies in **high video volume** across diverse themes.; **NEVER use generic prompts** like "summarize this video" or "what are the key points". These produce thin, quote-free summaries.

**Resources:** references/ (4 files; metadata only).
