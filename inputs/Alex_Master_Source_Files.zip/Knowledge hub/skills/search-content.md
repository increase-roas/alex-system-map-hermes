# Search Content

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## alternative-blog-writer

[S008] Source: `/Users/alexlobaito/.agents/skills/alternative-blog-writer/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:58.144541+00:00. SHA-256: `011dbeb27b1bac01c57e5fa8603d85cdcd0287d215bae669a6f97e1c0aa9fd23`.

**Trigger/purpose:** Write informative, simple, and highly SEO-optimized "alternative" or "competitor comparison" blog articles designed to capture organic search traffic for high-volume keywords. Use when the user asks to write a blog post like "Best [Competitor] Alternatives," "[Product] vs [Competitor]," or a roundup of options in a specific category. The skill guides through intake, keyword research, SERP analysis, and structured drafting with GEO/AEO optimization built in.

**Contents:** Alternative Blog Writer; Step 1: Collect the intake brief (do this FIRST); A. The Core Comparison (Required); B. Audience & Purpose (Required); C. SEO & Keyword Research (Required); D. Angle & Source Material (Recommended); Step 2: Keyword Research, SERP Analysis & FACT VERIFICATION (BEFORE writing); Step 3: Write the Article; Step 4: GEO/AEO Optimization (Crucial for AI Search); Step 5: Deliver and Refine.

**Opening guidance (source excerpt):** Write high-converting, SEO-optimized blog articles that compare alternatives and help readers make informed decisions. This skill is specifically designed to target high search volume keywords like "[Competitor] alternatives" or "[Tool A] vs [Tool B]" while keeping the content simple, scannable, and optimized for AI overviews (GEO/AEO).

**Procedure cues (source excerpts):** **What are we comparing?** Exact names of the main product/competitor and the alternatives.; **What category/type are they?** (e.g., SEO tools, project management apps).; **Format:** Is this a singular alternative ("X Alternative"), a plural roundup ("Best X Alternatives"), or a direct head-to-head ("X vs Y")?; **Who is the reader?** (e.g., small-business owners, beginners, enterprise buyers).; **What is their main pain point with the original product?** (e.g., too expensive, too complex, missing a specific feature).

**Resources:** references/ (1 files; metadata only).

## backlink-analysis

[S015] Source: `/Users/alexlobaito/.agents/skills/backlink-analysis/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:57.400959+00:00. SHA-256: `4890bb21344ed94f6a02e78e53dcadfb64c90c1deffc327f482fab058cf10b9e`.

**Trigger/purpose:** Produce a practitioner-grade backlink profile audit report for any target domain using Ahrefs, Semrush, DataForSEO, Similarweb, or user-uploaded tool exports. Use this skill whenever the user asks for a backlink audit, link profile analysis, toxic link review, link quality assessment, disavow review, or referring domain analysis, even if they just say "audit the backlinks for X". Always confirm the data source first (MCP, API, or uploaded files), then ask whether to include the two competitor sections (Competitor Benchmarking and Competitor Backlink Comparison for Link Gaps and Opportunities), noting they cost extra API credits; include both only if the user agrees, otherwise omit them. Reports link growth and loss over the last 3 months. Covers data source selection, data collection, risk scoring, optional competitor link-gap analysis, and a fixed report format. The Executive Summary is a two-paragraph brief under 150 words. No action plan or improvement plan sections.

**Contents:** Backlink Profile Audit Report; Step 0: Confirm the data source (ask the user first); Step 0.1: Ask whether to include the competitor sections (ask the user second); Step 1: Pull the data (Ahrefs API v3 Site Explorer); Step 2: Run the analysis (in this order); Step 3: Write the report (exactly these sections); Executive Summary: Logic Flow; Section headline rule; Section contracts (each claim lives in exactly one place); Step 4: Produce the deliverables; Step 5: Verify before delivering.

**Opening guidance (source excerpt):** You produce a backlink profile audit for a target domain using Ahrefs data. The output is a report a senior SEO practitioner would sign off on: conclusion-first, evidence-backed, built around decisions rather than data description.

**Procedure cues (source excerpts):** **Connect a tool via MCP.** If the user uses Ahrefs, Semrush, DataForSEO, or Similarweb, they can connect their account to Manus through MCP. This is the preferred option because it lets the skill pull data directly and reliably.; **Connect via API.** If their backlink tool does not have an MCP integration, ask them to check whether it can be connected via API instead, and to provide the API access if so.; **Upload files.** If neither MCP nor API is available, ask the user to upload whatever exports they have from their tools (e.g., referring domains, backlinks, anchors, competitor exports as CSV/XLSX). Encourage them to upload as much as possible so the report produces the most accurate output.; **Executive Summary** (no subsections; see logic flow below); **Total Referring Domains, Backlinks, and Domain Authority**

**Resources:** references/ (1 files; metadata only).

## comparison-article-writer

[S051] Source: `/Users/alexlobaito/.agents/skills/comparison-article-writer/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:57.505173+00:00. SHA-256: `a3bd3892c55906ee8854b83b7784eb49ed7814a947c6b6974e2529ed3680c399`.

**Trigger/purpose:** Write high-quality, research-backed "X vs Y" comparison blog articles (products, tools, services, brands, methods, or concepts). Use when the user asks to write, draft, or outline a comparison post, a "vs" article, an "alternatives" roundup, a "which is better" piece, or a buyer's-guide-style head-to-head. The skill first collects a structured intake brief, then runs keyword research (via a connected SEO tool like Ahrefs/Semrush if available, otherwise public SERP research), analyzes the top 10 ranking Google articles to match the winning content pattern, verifies all facts, and writes a balanced, decision-driven article with a 5-8 feature comparison table including pricing. Every finished article also includes 3-4 relevant images (a hero image, a custom comparison infographic, a data chart, and a supporting photo) embedded with captions and descriptive alt text.

**Contents:** Comparison Article Writer; Step 1: Collect the intake brief (do this FIRST); A. The core comparison (required); B. Audience & purpose (required); C. Comparison criteria (required); D. SEO & keyword research (required — ASK THIS EXPLICITLY); E. Your angle & verdict (strongly recommended); F. Source material (strongly recommended); G. Format & constraints (optional); Minimum to start; Step 2: Keyword research + SERP analysis (do this BEFORE writing); 2a. Keyword research; 2b. Analyze the top 10 ranking Google articles; 2c. Verify all facts; Step 3: Write the article; Step 4: Add images (mandatory — 3-4 per article); Required image set (default 3-4); Routing rules (consult the `imagegen` skill if unsure); Placement, captions, and alt text; Step 5: Deliver.

**Opening guidance (source excerpt):** Write blog articles that compare two or more options and help the reader decide. This covers product/tool comparisons (e.g., "Notion vs Obsidian"), service or plan comparisons, brand head-to-heads, multi-option roundups ("5 best X alternatives"), and concept comparisons ("REST vs GraphQL").

**Procedure cues (source excerpts):** **What are we comparing?** Exact names of the 2+ options (e.g., "Ahrefs vs Semrush"). Include URLs if available.; **What category/type are they?** (e.g., SEO tools, project management apps, running shoes, programming frameworks).; **How many options?** Head-to-head (2) or roundup (3+)? If a roundup, is there a clear "main" pick?; **Who is the reader?** (e.g., small-business owners, senior developers, beginners, enterprise buyers). Their expertise level and what they care about.; **What decision are they trying to make?** (e.g., "which tool to buy", "which to migrate to", "which to learn first").

**Resources:** references/ (1 files; metadata only).

## content-gap-analysis

[S055] Source: `/Users/alexlobaito/.agents/skills/content-gap-analysis/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:57.647902+00:00. SHA-256: `c3617335e7012b9331e5a6097fad63c17e3c4c2e082ec826e82bf8bf6d140f60`.

**Trigger/purpose:** Identify and prioritize content gaps for a website by comparing it against competitors and search demand. Use when asked to run a content gap analysis, keyword gap analysis, find missing topics, find topics competitors rank for but the target does not, profile traffic concentration by page type, find near-winner pages already ranking positions 4-15, audit thin or underperforming pages, map content to the buyer journey, analyze topic-cluster momentum/trend direction, deep-dive the top competitor traffic cluster to see which pages win it and what pages the target should create, tear down a competitor's winning page into a buildable refresh brief, benchmark content velocity/resourcing, or turn gaps into a prioritized list of content opportunities with supporting charts. Works with Ahrefs/Semrush/GSC/GA4 exports or, when no tools are available, with public SERP research.

**Contents:** Content Gap Analysis; What a Content Gap Is; Required Inputs; Workflow; Competitor Discovery; Traffic Concentration Profile; Near-Winner Quick Wins (Target's Own Pages); Cluster Momentum; Top-Cluster Deep-Dive (Finding 1); Live Page Teardown (Depth & Quality Gaps); Content Velocity; Prioritization; Deliverables; Writing & Quality Rules; Fallback (No SEO Tools); Resources; Scripts (use these; do not re-derive the math by hand).

**Opening guidance (source excerpt):** Use this skill to find the **content a target site should create or improve** to win more organic search traffic, then turn those findings into a **prioritized, action-ready list of opportunities**. The goal is not a raw keyword dump; it is a short list of well-reasoned opportunities, each tied to evidence, a target page, an intent, and a recommended action.

**Procedure cues (source excerpts):** **Scope.** Confirm target, competitors, market, language, business model, and priority topics. Define what "success" means (traffic, conversions).; **Pick competitors.** Use the provided list, or discover 3–5 true *organic* competitors (domains that recur in the SERPs for target topics, even if they sell something different). See "Competitor Discovery" below.; **Collect data.** Pull keyword overlap / missing-keyword data, competitor top pages, and target's existing pages. Capture search volume, keyword difficulty (KD), current positions, intent, and estimated traffic. With exports, normalize into one table. Without tools, sample 20–60 representative queries.; **Profile traffic concentration.** Before hunting gaps, compute **total estimated organic traffic** and **traffic by page type** for each domain (see "Traffic Concentration Profile" below). This frames the whole report: a target can lead on total traffic yet still be missing an entire editorial/awareness layer the competitor owns. Build the traffic-by-page-type chart here.; **Find topic & keyword gaps (domain-level).** List topics/keywords competitors rank for that the target does not. Exclude competitor-branded and irrelevant terms. Prioritize **high-volume, lower-KD, business-relevant** opportunities.

**Resources:** references/ (0 files; metadata only); scripts/ (7 files; metadata only); templates/ (2 files; metadata only).

## keyword-research

[S108] Source: `/Users/alexlobaito/.agents/skills/keyword-research/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T14:45:31.964768+00:00. SHA-256: `9244866d9d7bfd4dabd637f8c566fe6db94578f5d345391673baf32d438f11ea`.

**Trigger/purpose:** Conduct keyword research and generate a strictly formatted three-tab Excel workbook containing a Topic Cluster Summary, 300 priority keywords, and a competitor gap analysis. Use when the user asks to "conduct keyword research for [keyword]", "create a keyword research excel", or provides a keyword and needs a structured priority list and competitor gaps.

**Contents:** Keyword Research; Local paths; The Keyword Research Workflow; Step 0: Confirm Target Country & Data Source (Ask First); Step 1: Data Gathering & Analysis; Step 2: Excel Generation; Step 3: Deliverable Review; Locked-In Deliverable Structure; Tab 1: Topic Cluster Summary (Auto-Generated); Tab 2: Priority Keyword Targets (300 Keywords); Tab 3: Competitor Keyword Gaps & Landscape.

**Opening guidance (source excerpt):** `SKILL_DIR` is the directory that contains this `SKILL.md`. Resolve it from the skill path you just opened. Never call `/home/ubuntu/...`. Write outputs in the current workspace (`./my-report`, `./keyword_research.xlsx`), not under `/home/ubuntu`.

**Procedure cues (source excerpts):** **Understand the Seed:** Analyze the user's input keyword to determine the core topic, target audience, and primary search intent.; **Keyword Expansion (300 Keywords):** Use your knowledge and available search tools to generate exactly 300 relevant keywords.; **Competitor Analysis:** Identify the top 20 organic competitors for this topic.; Ensure the output file is an `.xlsx` workbook.; Verify the volume columns reflect the country/worldwide scope the user selected in Step 0a, and that the deliverable notes the volume scope clearly.

**Resources:** references/ (1 files; metadata only); scripts/ (1 files; metadata only).

## listicle-blog-writer

[S111] Source: `/Users/alexlobaito/.agents/skills/listicle-blog-writer/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:58.035757+00:00. SHA-256: `efcba49ca89108e7c4eb057504f7bb6982090ee7bcdfb7c1c8c38bf5c101890d`.

**Trigger/purpose:** Write "best X tools/products" listicle blog articles optimized for SEO and GEO/AEO (AI engine citation by ChatGPT, Perplexity, Google AI Overviews). Use when the user asks for a listicle, comparison article, "best tools" post, roundup article, "top 10 X" blog, or any content meant to rank on Google and earn AI citations. Also trigger when the user mentions optimizing content for LLM citation, answer engines, or wants their own product featured in a comparison article.

**Contents:** Listicle Blog Writer; Step 0: Gather inputs; Step 1: Research; Step 2: Article structure; Step 3: Per-tool section format (strict); {N}. {Tool} — `{tool_url}` (template/unresolved; relative to `/Users/alexlobaito/.agents/skills/listicle-blog-writer`); Step 4: SEO and GEO optimization checklist; Step 5: Anti-AI-writing pass; Step 6: Deliver and iterate.

**Opening guidance (source excerpt):** Produce a "best X tools" listicle that (a) ranks well on Google, (b) maximizes the chance of being cited by AI answer engines, and (c) positions the user's own product favorably without being dishonest.

**Procedure cues (source excerpts):** **The user's product** (the one to feature as #1). Check memory/context first. If the user has no product to feature, rank tools by objective merit and skip the "{CLIENT} vs. the rest" section.; **Number of tools** (default 10).; **Categories** (e.g., everyday tasks, developers, enterprise). Each tool must occupy a distinct niche so "best for" labels don't overlap.; **House style** if known.; **Review style** — Ask: "Is this a review article? If so, will you be reviewing the tools yourself, or should I pull other people's experiences as reviews?" Based on the answer:

**Resources:** references/ (1 files; metadata only).

## ranking-industry-advertisers

[S132] Source: `/Users/alexlobaito/.agents/skills/ranking-industry-advertisers/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T15:33:22.527767+00:00. SHA-256: `4e14c1551b70a0716e667191690d40feb700b88ac5f61703c54aae3030def58a`.

**Trigger/purpose:** Use when finding or ranking the strongest advertisers or likely winning Meta ad creatives in an industry or local market, especially when ad activity, longevity, website traffic, creative evidence, paid-tool costs, or source conflicts must be auditable.

**Contents:** Ranking Industry Advertisers; Core principle; Scope contract; Evidence workflow; Ranking contract; Winning picture-ad mode; Credit and stop rules; Required deliverables; Common mistakes.

**Opening guidance (source excerpt):** Separate advertiser strength from creative winner evidence. Ad volume, longevity, traffic, and repeated creative variants are observable proxies; none proves profitability. Define the market and evidence universe, preserve the raw evidence, and label conclusions “observed as of” the verification time.

**Procedure cues (source excerpts):** Load any existing inventory and manifest. Skip reviewed Meta page IDs, domains, and executed queries.; Discover broadly with Apify when authorized; use Foreplay for brand resolution and creative evidence. If Apify is unavailable, use Foreplay discovery and record that the covered universe is narrower. Inspect the Apify Actor schema and pricing before running it; cap results and total charge.; Deduplicate by exact Meta page ID. Resolve the canonical domain and preserve aliases. Do not merge franchises or locations merely because names or domains resemble one another.; Verify industry fit from the landing page, ad copy, or company site. A local address alone does not prove the requested service area.; Measure live ads. Prefer a same-date Meta/Foreplay active total. When Apify only proves matching records, store the count as `APIFY_QUERY_MINIMUM`; never present it as the advertiser’s total.

**Resources:** references/ (2 files; metadata only); scripts/ (4 files; metadata only).

## seo-audit

[S143] Source: `/Users/alexlobaito/.agents/skills/seo-audit/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T14:45:31.964423+00:00. SHA-256: `4a547d13cd692cb43be456c87d31eb412ade5eb616b932c54da9bf4aa90836b1`.

**Trigger/purpose:** Create plain-language, evidence-led SEO audit reports using the structure developed with the user. Use when asked to create, revise, or standardize an SEO audit report, SEO audit mockup, organic search audit, backlink-focused SEO audit, business-style report, or sample-modeled audit where the output must rely strictly on report data, avoid hallucinations, use a 150–200 word one-paragraph executive summary, explain organic traffic and market drivers, exclude standalone Content Quality Audit and On-Page SEO sections by default, end with a concise ordered problem/fix prioritization list instead of a roadmap, and use direct insight-and-action language.

**Contents:** SEO Audit; Local paths; Purpose; Core workflow; Required report structure; Standard chart-generation workflow; Executive summary rules; Section-specific standards; Organic Traffic Trend; Top Organic Countries; Page Type Analysis; Branded vs Non-Branded Search Terms; Keyword Portfolio; SEO Content Analysis; Site Architecture; Backlink Analysis; Final Prioritization; Writing style; Evidence standards; Backlink analysis standards; Quality checks before delivery; Bundled resources.

**Opening guidance (source excerpt):** `SKILL_DIR` is the directory that contains this `SKILL.md`. Resolve it from the skill path you just opened. Never call `/home/ubuntu/...`. Write outputs in the current workspace (`./my-report`, `./keyword_research.xlsx`), not under `/home/ubuntu`.

**Procedure cues (source excerpts):** Confirm the data basis internally. Identify available datasets and missing datasets before writing. State data limitations only where needed; do not include a standalone **Scope and Data Used** section unless the user asks for it.; If important datasets are missing, tell the user in the report’s data note or affected section what is lacking and what data would be needed for a fuller analysis, such as GSC/GA traffic exports, keyword/top-page exports, crawl exports, backlink exports, internal-link exports, sitemap data, or Lighthouse/Core Web Vitals data.; Build evidence tables and charts before writing. Extract the numerical facts needed for organic traffic trend, country drivers, top pages, branded versus non-branded terms, keyword concentration, content clusters, multilingual pages, backlinks, technical issues, site architecture, and page experience. When any supported chart data exists, normalize it into `chart_data/*.csv` inputs and run `scripts/generate_seo_audit_charts.py` so charts use the fixed report style and filenames.; Write findings only after the evidence exists. Each finding must connect to a number, table, chart, observed page issue, or explicitly stated data limitation.; Prioritize insight over raw metrics. Do not list platform overview numbers unless they explain growth, decline, concentration risk, market fit, content strategy, or a concrete action.

**Resources:** references/ (0 files; metadata only); scripts/ (2 files; metadata only); templates/ (1 files; metadata only).

## seo-competitor-analysis

[S144] Source: `/Users/alexlobaito/.agents/skills/seo-competitor-analysis/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T14:45:31.963913+00:00. SHA-256: `342454e30ecd54b0773c8635c672c156d53952ba4672a07f24dacc519d996b41`.

**Trigger/purpose:** Create simplified, target-first SEO organic competitor reports modeled on the approved example report style. Use for `/seo-competitor-analysis`, simplified SEO reports, organic visibility diagnosis, country traffic trend reports, Ahrefs/Semrush/Similarweb/GSC organic data analysis, page-type SEO analysis, branded versus non-branded keyword review, and backlink strategy analysis. Always generate supporting charts from normalized data before writing the report. This report is written from the perspective of someone competing against the target domain — it explains the domain's strategy, not how to improve it.

**Contents:** SEO Competitor Analysis; Local paths; Core Output Standard; Mandatory Workflow; Standard Report Structure; SEO Competitor Report: [target.com]; Executive Narrative; Part 1: Organic Search Performance; 1. Business Context and SEO Footprint; 2. Page Type Analysis: Where Organic Demand Lands; 3. Organic Visibility by Country; 4. Traffic Trend: Is Organic Search Growing or Declining?; 5. Branded vs Non-Branded Search; Part 2: Backlink Strategy Evidence; 6. Backlinks: How Is [target] Building Links?; Part 3: Strategic Assessment; 7. Key Dependencies and Vulnerabilities; References; Section Writing Rules; Mandatory Charts and Graphs; Citation and Evidence Rules; References.

**Opening guidance (source excerpt):** `SKILL_DIR` is the directory that contains this `SKILL.md`. Resolve it from the skill path you just opened. Never call `/home/ubuntu/...`. Write outputs in the current workspace (`./my-report`, `./keyword_research.xlsx`), not under `/home/ubuntu`.

**Procedure cues (source excerpts):** **Collect source data.** Pull the best available organic search data from Ahrefs, Semrush, Similarweb, GSC, GA4, sitemap/robots.txt, and public pages depending on user access. If the user specifically asks to use Ahrefs, prioritize Ahrefs exports and state where other data is unavailable or only directional.; **Normalize analysis tables.** Save CSV files in the project directory using the names in `references/data_dictionary.md` whenever possible.; **Generate charts before writing.** Run:; **Use the chart manifest.** Review `/path/to/project/charts/asset_manifest.md` and embed relevant chart snippets in the final report. If a critical chart cannot be generated, add an explicit data limitation instead of inventing values.; **Write the report.** Follow the report structure below. Preserve the style example's direct narrative style. Remember: no recommendations — only analysis of the target's strategy.

**Resources:** references/ (2 files; metadata only); scripts/ (2 files; metadata only).

## similarweb-analytics

[S145] Source: `/Users/alexlobaito/.agents/skills/similarweb-analytics/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:56.619618+00:00. SHA-256: `81e1c6c8f61d17ada7c09f28e2ee462ad00a71e96ac8a0c9f0de97f69d9b16d2`.

**Trigger/purpose:** Analyze websites and domains using SimilarWeb traffic data. Get traffic metrics, engagement stats, global rankings, traffic sources, and geographic distribution for comprehensive website research.

**Contents:** SimilarWeb Analytics; Core Capabilities; API Usage; Get Global Rank; Get Website Visits Total; Get Unique Visit; Get Bounce Rate; Get Traffic Sources - Desktop; Get Traffic Sources - Mobile; Get Total Traffic by Country; When to Use; Data Limitations; Important: Save Data to Files.

**Opening guidance (source excerpt):** Comprehensive website and domain analysis using SimilarWeb traffic data.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## website-traffic-checker

[S169] Source: `/Users/alexlobaito/.agents/skills/website-traffic-checker/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:57.290879+00:00. SHA-256: `5f71dbe5d197ca9caaf4574f8add99ebe88b387c63fb810efaefdd8773654297`.

**Trigger/purpose:** Comprehensive website traffic analysis workflow. Use when the user asks to analyze a website's traffic, check competitor traffic, analyze best-performing content, see keywords driving traffic, or assess page performance. Supports Similarweb, Ahrefs (via MCP), Semrush (via API), DataForSEO (via MCP), and user-uploaded data exports (CSV/XLSX from GSC, GA4, Ahrefs, Semrush, etc.).

**Contents:** Website Traffic Checker; Critical First Step; Data Volume Constraints (MANDATORY); Core Writing Principles; The Analytical Framework; 1. Traffic Performance & Inflection Points; 2. Keyword & Search Performance; 3. Landing Pages & Content Performance; Workflow Phases; Required Tools & Connectors; References and Templates; Final Deliverable.

**Opening guidance (source excerpt):** Use this skill to conduct a comprehensive analysis of a website's traffic, traffic sources, top-performing content, and keyword drivers. It integrates data from Similarweb, Ahrefs (via MCP), Semrush (via API), DataForSEO (via MCP), or the user's own uploaded data exports to provide a complete, narrative-driven picture of a site's performance.

**Procedure cues (source excerpts):** **Traffic Overview Metrics AND the 12-Month Organic Traffic Trend MUST use global/worldwide traffic.** Both the headline overview metrics (Organic Traffic, Keywords Ranked) and the trend MUST represent global/worldwide organic traffic, never a single country (not US-only or any other region). For tools that only expose per-database (per-country) data such as Semrush, build the global figure by summing across all regional databases for the snapshot, and by summing the largest regional databases month-by-month for the trend (state the coverage, e.g., "top 12 markets representing ~X of total global desktop traffic"). For tools with a native worldwide scope (e.g., DataForSEO `location_name: "World"`, Ahrefs all-countries, Similarweb worldwide), use that scope directly. The trend line graph and MoM table must represent global organic traffic.; **Keyword analysis sample size is capped at 500 keywords.** When pulling ranked/organic keywords (branded vs non-branded, intent, top keywords, near-winners), request at most 500 keywords total. Do not exceed this limit.; **Page type / concentration / underperformer analysis is capped at 1,000 URLs.** When pulling top/landing pages for page-type efficiency, concentration, and underperforming-page analysis, request at most 1,000 URLs total.; **Geography Distribution analysis MUST use the top 2,000 URLs by traffic.** When inferring geographic/locale penetration from URL patterns (e.g., `/es/`, `/zh_CN/`), pull the top 2,000 URLs ranked by overall traffic (a separate, larger pull than the 1,000-URL page-type analysis) so the locale breakdown reflects the broadest possible footprint.; **Executive Narrative Format**: The Executive Narrative MUST be EXACTLY 2 paragraphs, each strictly capped at 150 words. Paragraph 1 covers growth trajectory, scale, dominant channel, engagement quality, and geographic footprint. Paragraph 2 covers the biggest structural risk/opportunity and the highest-ROI growth lever with specific data.

**Resources:** references/ (1 files; metadata only); templates/ (1 files; metadata only).
