# Marketing Delivery

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## ad-recreator-universal-v2

[S003] Source: `/Users/alexlobaito/.agents/skills/ad-recreator-universal-v2/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:58.358220+00:00. SHA-256: `c008d9594c92c4ebc1c50326a6283afbdeaecfcc4034a589b586f9b905c98f74`.

**Trigger/purpose:** Recreate approved B2B marketing ads or slides while preserving the reference composition and replacing it with supplied avatar, brand, apparel, logo, and offer assets. Use for requests such as “recreate ads,” “clone winning ads,” “same structure,” “swap avatar and branding,” or “bulk recreate all.”

**Contents:** Universal Winning Ad Recreator v2; v2 updates; Scope; 1. Collect the minimum brief; 2. Lock the structure, avatar, and brand; 3. Choose the production route; 4. Prompt for person-led ads; 5. Lightweight delivery check.

**Opening guidance (source excerpt):** Recreate approved B2B marketing visuals at scale. Treat the reference as a **layout brief** and the supplied assets as the **brand source of truth**.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## applying-brand-guidelines

[S010] Source: `/Users/alexlobaito/.agents/skills/applying-brand-guidelines/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T09:29:27.377166+00:00. SHA-256: `6db648c228eefa92d73a47676de68c6b1925e15ba6e6d8144aa079495771e59b`.

**Trigger/purpose:** This skill applies consistent corporate branding and styling to all generated documents including colors, fonts, layouts, and messaging

**Contents:** Corporate Brand Guidelines Skill; Brand Identity; Company: Acme Corporation; Visual Standards; Color Palette; Typography; Logo Usage; Document Standards; PowerPoint Presentations; Excel Spreadsheets; PDF Documents; Content Guidelines; Tone of Voice; Standard Phrases; Data Presentation; Quality Standards; Before Finalizing; Prohibited Elements; Application Instructions; Scripts; Notes.

**Opening guidance (source excerpt):** This skill ensures all generated documents adhere to corporate brand standards for consistent, professional communication.

**Procedure cues (source excerpts):** **Title Slide**: Company logo, presentation title, date, presenter; **Section Divider**: Section title with blue background; **Content Slide**: Title bar with blue background, white content area; **Data Slide**: For charts/graphs, maintain color palette; Logo is properly placed and sized

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## building-long-running-meta-ad-inventories

[S019] Source: `/Users/alexlobaito/.agents/skills/building-long-running-meta-ad-inventories/SKILL.md`; kind: canonical. Modified UTC: 2026-08-31T16:03:14.097334+00:00. SHA-256: `7a4833c02fac68f8c2fa18bea578988bc677ba0738aea62fb6f1665a5056972b`.

**Trigger/purpose:** Use when compiling, expanding, validating, or ranking advertiser inventories from Meta Ad Library, Apify, or Foreplay where ads must be currently live for a minimum duration and advertiser identity or ad-count evidence may conflict.

**Contents:** Building Long-Running Meta Ad Inventories; Core principle; Workflow; Foreplay enrichment; Counts and ranking; Credit and stop rules; Required outputs; Common mistakes.

**Opening guidance (source excerpt):** Apify discovers; Meta page ID establishes identity; Foreplay enriches. Partial or fuzzy reads never override stronger evidence.

**Procedure cues (source excerpts):** Load the existing inventory and search manifest. Preserve verified records and skip reviewed page IDs and executed queries.; Before paid discovery, inspect Actor schema and pricing. Set its result limit and `maxTotalChargeUsd` within the approved dollar cap.; Discover active Meta ads with Apify. Filter by country and start-date cutoff. Deduplicate **strictly by Meta `pageId`**; names and domains support identity but are not keys.; Reject removal, rental, repair, maintenance, chemicals, accessories, financing-only, lodging, and unrelated profiles. Require ad evidence selling the complete product.; Compute complete runtime days client-side from the ad start timestamp and verification timestamp. Assign duration tiers from that computed value.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## cloudflare-email-service

[S048] Source: `/Users/alexlobaito/.agents/skills/cloudflare-email-service/SKILL.md`; kind: canonical. Modified UTC: 2026-08-28T18:03:29.916227+00:00. SHA-256: `a62531900a08f9f6c352061d42e8b10a35009f5e1c6f91bbf18752feedad5a79`.

**Trigger/purpose:** Send and receive transactional emails with Cloudflare Email Service (Email Sending + Email Routing). Use when building email sending (Workers binding or REST API), email routing, Agents SDK email handling, or integrating email into any app — Workers, Node.js, Python, Go, etc. Also use for email deliverability, SPF/DKIM/DMARC, wrangler email setup, MCP email tools, or when a coding agent needs to send emails. Even for simple requests like "add email to my Worker" — this skill has critical config details.

**Contents:** Cloudflare Email Service; Retrieval Sources; FIRST: Check Prerequisites; What Do You Need?; Quick Start — Workers Binding; Quick Start — REST API; Common Mistakes; References.

**Opening guidance (source excerpt):** Your knowledge of the Cloudflare Email Service, Email Routing or Email Sending may be outdated. **Prefer retrieval over pre-training** for any Cloudflare Email Service task.

**Procedure cues (source excerpts):** **Domain onboarded?** Run `npx wrangler email sending list` to see which domains have email sending enabled. If the domain isn't listed, run `npx wrangler email sending enable userdomain.com` or see [cli-and-mcp.md](/Users/alexlobaito/.agents/skills/cloudflare-email-service/references/cli-and-mcp.md) for full setup instructions.; **Binding configured?** Look for `send_email` in `wrangler.jsonc` (for Workers); **postal-mime installed?** Run `npm ls postal-mime` (only needed for receiving/parsing emails)

**Resources:** references/ (5 files; metadata only).

## competitive-ads-extractor

[S052] Source: `/Users/alexlobaito/.agents/skills/competitive-ads-extractor/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:12:08.635211+00:00. SHA-256: `0ec3e0b3ee57073d502e5e0d3c07c17bc888e8cabb886b9abf0cc6007226ecdb`.

**Trigger/purpose:** Extracts and analyzes competitors' ads from ad libraries (Facebook, LinkedIn, etc.) to understand what messaging, problems, and creative approaches are working. Helps inspire and improve your own ad campaigns.

**Contents:** Competitive ads extractor; Output.

**Opening guidance (source excerpt):** Pull ads from the live library or a provided export. Group by hook, problem, offer, creative format, and CTA.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## copy-editing

[S056] Source: `/Users/alexlobaito/.agents/skills/copy-editing/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.446270+00:00. SHA-256: `9b5a20be3dc5513c8f0b4f4c4960857e4d28ed83698a5b33c8dde9dc75a47bf6`.

**Trigger/purpose:** When the user wants to edit, review, or improve existing marketing copy, or refresh outdated content. Also use when the user mentions 'edit this copy,' 'review my copy,' 'copy feedback,' 'proofread,' 'polish this,' 'make this better,' 'copy sweep,' 'tighten this up,' 'this reads awkwardly,' 'clean up this text,' 'too wordy,' 'sharpen the messaging,' 'refresh this content,' 'update this page,' 'this content is outdated,' or 'content audit.' Use this when the user already has copy and wants it improved or refreshed rather than rewritten from scratch. For writing new copy, see copywriting.

**Contents:** Copy Editing; Core Philosophy; The Seven Sweeps Framework; Sweep 1: Clarity; Sweep 2: Voice and Tone; Sweep 3: So What; Sweep 4: Prove It; Sweep 5: Specificity; Sweep 6: Heightened Emotion; Sweep 7: Zero Risk; Expert Panel Scoring; How It Works; Recommended Expert Panels; Scoring Rubric; When to Use; Quick-Pass Editing Checks; Word-Level Checks; Sentence-Level Checks; Paragraph-Level Checks; Copy Editing Checklist; Common Copy Problems & Fixes; Problem: Wall of Features.

**Opening guidance (source excerpt):** You are an expert copy editor specializing in marketing and conversion copy. Your goal is to systematically improve existing copy through focused editing passes while preserving the core message.

**Procedure cues (source excerpts):** Read through quickly, highlighting unclear parts; Don't correct yet—just note problem areas; After marking issues, recommend specific edits; Verify edits maintain the original intent; Read aloud to hear inconsistencies

**Resources:** references/ (3 files; metadata only).

## copy-rewriter

[S057] Source: `/Users/alexlobaito/.agents/skills/copy-rewriter/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:12:08.639820+00:00. SHA-256: `5f7d8f3ae1be93e6138075304f5095eed674094c47210488b9a3cf104aa8c12e`.

**Trigger/purpose:** Reads copy from any source (URL, text, or file), audits it against the copywriting and landing page frameworks, and rewrites it using actual customer language (VoC). The rewrite is direct, confident, systems-focused, and free of corporate fluff or guru-cringe.

**Contents:** Copy rewriter; Output.

**Opening guidance (source excerpt):** Rewrite using the customer's words when you have them. Lead with the outcome. Cut fluff.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## copywriting

[S058] Source: `/Users/alexlobaito/.agents/skills/copywriting/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.451301+00:00. SHA-256: `ce18137ae31ab37f261078501431649865ab6b403054d97490754e82acb002d8`.

**Trigger/purpose:** When the user wants to write, rewrite, or improve marketing copy for any page — including homepage, landing pages, pricing pages, feature pages, about pages, or product pages. Also use when the user says "write copy for," "improve this copy," "rewrite this page," "marketing copy," "headline help," "CTA copy," "value proposition," "tagline," "subheadline," "hero section copy," "above the fold," "this copy is weak," "make this more compelling," or "help me describe my product." Use this whenever someone is working on website text that needs to persuade or convert. For email copy, see emails. For popup copy, see popups. For editing existing copy, see copy-editing. For the offer underneath the copy (bonuses, guarantees, value framing), see offers.

**Contents:** Copywriting; Before Writing; 1. Page Purpose; 2. Audience; 3. Product/Offer; 4. Context; Copywriting Principles; Clarity Over Cleverness; Benefits Over Features; Specificity Over Vagueness; Customer Language Over Company Language; One Idea Per Section; Writing Style Rules; Core Principles; Quick Quality Check; Best Practices; Be Direct; Use Rhetorical Questions; Use Analogies When Helpful; Pepper in Humor (When Appropriate); Page Structure Framework; Above the Fold.

**Opening guidance (source excerpt):** You are an expert conversion copywriter. Your goal is to write marketing copy that is clear, compelling, and drives action.

**Procedure cues (source excerpts):** **Simple over complex** — "Use" not "utilize," "help" not "facilitate"; **Specific over vague** — Avoid "streamline," "optimize," "innovative"; **Active over passive** — "We generate reports" not "Reports are generated"; **Confident over qualified** — Remove "almost," "very," "really"; **Show over tell** — Describe the outcome instead of using adverbs

**Resources:** references/ (2 files; metadata only).

## create-local-meta-ads

[S059] Source: `/Users/alexlobaito/.agents/skills/create-local-meta-ads/SKILL.md`; kind: canonical. Modified UTC: 2026-10-02T01:40:30.650701+00:00. SHA-256: `e737e98bfe564179fc530b5f0f355ebf12c634f8a4343231bb7ab842895e2bff`.

**Trigger/purpose:** Use for Facebook or Instagram ads, Stories/Reels, UGC concepts, creative briefs, image or video prompts, ad copy, offer tests or creative audits for local service businesses and hot tub dealers.

**Contents:** Create Local Meta Ads; Load the right references; Build the campaign; Default deliverable; Operating rules.

**Opening guidance (source excerpt):** Build conversion-focused creative that looks credible in-feed, communicates one offer immediately, and gives a local buyer a concrete next step.

**Procedure cues (source excerpts):** Extract the known facts: business, offer, service or product, geography, audience, price or financing, proof, deadline, CTA, available assets, placement, and requested quantity.; Separate verified facts from assumptions. Never invent prices, discounts, inventory, reviews, savings, guarantees, credentials, customer outcomes, or event details. Mark missing decision-critical facts clearly; omit optional unknowns.; Identify the buying mechanism:; Choose one primary promise per ad. Do not stack several competing headlines.; Create a test matrix across distinct mechanisms, not cosmetic variations. Default to 3-5 concepts spanning offer, proof, local relevance, problem awareness, and native/organic presentation.

**Resources:** references/ (3 files; metadata only).

## cro

[S062] Source: `/Users/alexlobaito/.agents/skills/cro/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.459124+00:00. SHA-256: `199016bec3b44bc6a7507b111b6028f6550cc852cd54c7d0df789f15d6f814c4`.

**Trigger/purpose:** When the user wants to optimize, improve, or increase conversions on any marketing page or form — including homepage, landing pages, pricing pages, feature pages, lead capture forms, or contact forms. Also use when the user says 'CRO,' 'conversion rate optimization,' 'this page isn't converting,' 'improve conversions,' 'why isn't this page working,' 'my landing page sucks,' 'form abandonment,' 'nobody's converting,' 'low conversion rate,' or 'this page needs work.' Use this even if the user just shares a URL and asks for feedback. For signup/registration flows, see signup. For post-signup activation, see onboarding. For popups/modals, see popups.

**Contents:** Conversion Rate Optimization (CRO); Initial Assessment; CRO Analysis Framework; 1. Value Proposition Clarity (Highest Impact); 2. Headline Effectiveness; 3. CTA Placement, Copy, and Hierarchy; 4. Visual Hierarchy and Scannability; 5. Trust Signals and Social Proof; 6. Objection Handling; 7. Friction Points; Output Format; Quick Wins (Implement Now); High-Impact Changes (Prioritize); Test Ideas; Copy Alternatives; Page-Specific Frameworks; Homepage CRO; Landing Page CRO; Pricing Page CRO; Feature Page CRO; Blog Post CRO; Experiment Ideas.

**Opening guidance (source excerpt):** You are a conversion rate optimization expert. Your goal is to analyze marketing pages and provide actionable recommendations to improve conversion rates.

**Procedure cues (source excerpts):** **Page Type**: Homepage, landing page, pricing, feature, blog, about, other; **Primary Conversion Goal**: Sign up, request demo, purchase, subscribe, download, contact sales; **Traffic Context**: Where are visitors coming from? (organic, paid, email, social); What's your current conversion rate and goal?; Where is traffic coming from?

**Resources:** references/ (2 files; metadata only).

## email-sending-setup

[S067] Source: `/Users/alexlobaito/.agents/skills/email-sending-setup/SKILL.md`; kind: canonical. Modified UTC: 2026-10-07T13:57:46.153422+00:00. SHA-256: `7222d433fe5d8eb28bed6e5977d740dff242e1fcca1e46fcd2ae446a1bff5a1e`.

**Trigger/purpose:** End-to-end email deliverability setup and inbox placement optimization for domains using Mailgun and GoHighLevel (GHL). Use for: configuring DNS authentication records (SPF, DKIM, DMARC, BIMI), setting up Mailgun sending domains, warming up IPs and subdomains, cleaning email lists, diagnosing spam folder issues, removing domains from blacklists, ensuring CAN-SPAM compliance, and building GHL workflows for bounce/complaint/unsubscribe management. Also use when a user asks why their emails are going to spam, how to improve deliverability, or how to set up a new domain for email sending. ALSO use when writing any email copy, follow-up sequences, or GHL email workflows to ensure spam trigger words are avoided and plain-text copy rules are followed.

**Contents:** Email Sending Setup; When to Use This Skill; Bundled Reference Files; Setup Execution Order; Step 1: DNS Authentication (Do First); Step 2: Mailgun Domain Configuration; Step 3: GHL Configuration; Step 4: List Cleaning; Step 5: Domain and IP Warmup; Step 6: Pre-Campaign Testing; Step 7: Pre-Campaign 5-5-5 Engagement Hack; Step 8: Google Postmaster Tools; Step 9: BIMI Setup (Optional but Recommended); Ongoing Maintenance; Key Thresholds to Monitor; Common Deliverability Problems and Fixes; Important Notes; Required fields, spacing, and acceptance.

**Opening guidance (source excerpt):** This skill provides a complete, step-by-step system for configuring a domain to land in the inbox rather than the spam folder. It is based on the FromSpamToInbox methodology, Mailgun documentation, GHL best practices, and FTC CAN-SPAM compliance requirements.

**Procedure cues (source excerpts):** **SPF** — Authorizes Mailgun to send on behalf of the domain. One record per domain; merge if one already exists.; **DKIM** — Copy the exact record from Mailgun -> Sending -> Domains -> DNS Records.; **DMARC** — Start with `p=none` for 2–4 weeks to collect reports, then move to `p=quarantine` or `p=reject`.; Create a sending subdomain (e.g., `mail.yourdomain.com`) — never send from the root domain.; Set the From address format for all campaigns: `prefix@mail.yourdomain.com`.

**Resources:** references/ (7 files; metadata only).

## email-spam-audit

[S068] Source: `/Users/alexlobaito/.agents/skills/email-spam-audit/SKILL.md`; kind: canonical. Modified UTC: 2026-10-07T13:53:10.424814+00:00. SHA-256: `5956d4dd4ac773197fb160d06cf9c52386a0f5b7adb582ebd4feb033da144298`.

**Trigger/purpose:** Full workflow for auditing and cleaning email sequences using Mailmeteor spam checker. Use for: running bulk email sequences through Mailmeteor to identify spam triggers, extracting exact flagged words from the DOM, rewriting emails to achieve Great score, batch-verifying all emails via Selenium, and compiling a fully verified clean sequence. Use when asked to spam-check, clean, or audit any email nurture sequence, drip campaign, or follow-up series.

**Contents:** Email Spam Audit Workflow; Overview; Known Spam Trigger Words; Workflow; Step 1: Extract Emails to JSON; Step 2: Batch Test All Emails; Step 3: Iterative Rewrite Passes; Step 4: Verify Every Email: Great with Zero Flags; Step 5: Spot Check; Step 6: Compile Final File; Scripts; Notes; Required fields, spacing, and acceptance.

**Opening guidance (source excerpt):** Audits email sequences against Mailmeteor's spam checker and rewrites flagged emails until every email scores green **Great with zero flags**. Uses Selenium to automate batch testing and DOM extraction of exact flagged words.

**Resources:** references/ (1 files; metadata only); scripts/ (2 files; metadata only).

## emails

[S069] Source: `/Users/alexlobaito/.agents/skills/emails/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.463420+00:00. SHA-256: `1fbd54df4c59f48408057e7db0dfb1a53c033e6a4ca5cd1927a47c51ec28d8f1`.

**Trigger/purpose:** When the user wants to create or optimize an email sequence, drip campaign, automated email flow, or lifecycle email program. Also use when the user mentions "email sequence," "drip campaign," "nurture sequence," "onboarding emails," "welcome sequence," "re-engagement emails," "email automation," "lifecycle emails," "trigger-based emails," "email funnel," "email workflow," "what emails should I send," "welcome series," or "email cadence." Use this for any multi-email automated flow. For cold outreach emails, see cold-email. For in-app onboarding, see onboarding.

**Contents:** Email Sequence Design; Initial Assessment; Core Principles; 1. One Email, One Job; 2. Value Before Ask; 3. Relevance Over Volume; 4. Clear Path Forward; Email Sequence Strategy; Sequence Length; Timing/Delays; Subject Line Strategy; Preview Text; Sequence Types Overview; Welcome Sequence (Post-Signup); Lead Nurture Sequence (Pre-Sale); Re-Engagement Sequence; Onboarding Sequence (Product Users); Email Types by Category; Onboarding Emails; Retention Emails; Billing Emails; Usage Emails.

**Opening guidance (source excerpt):** You are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion.

**Procedure cues (source excerpts):** **Sequence Type**; **Audience Context**; **Goals**; Welcome + deliver promised value (immediate); Quick win (day 1-2)

**Resources:** references/ (3 files; metadata only).

## fulfill-hot-tub-launch

[S085] Source: `/Users/alexlobaito/.agents/skills/fulfill-hot-tub-launch/SKILL.md`; kind: canonical. Modified UTC: 2026-10-02T01:40:30.652676+00:00. SHA-256: `a1ca6c134b3a7d5307f1ed5e42bf8ffb7c76a6a6beee5d1958b8f51b4b4654d6`.

**Trigger/purpose:** Use for Hot Tub Launch fulfillment, such as paid funnels, retailer websites, GHL snapshot workflows, Sheets lead projection, Meta Pixel/CAPI dedup, launch gates and diagnosis. Not for Meta ads.

**Contents:** Fulfill Hot Tub Launch; Route the request; Load only what the task needs; Fact authority and evidence; Capturable fulfillment trajectory; API Maximalism with Graceful Degradation; Non-negotiable system invariants; Approval boundary; Required fulfillment path; Definition of done.

**Opening guidance (source excerpt):** Operate the HTL website and GHL snapshot as two joined systems with different ownership:

**Procedure cues (source excerpts):** Current explicit user instruction and approval boundary; Approved retailer facts and approved business decisions; Read-only state from the exact resolved target account/resource; Current working source, schemas, migrations, generated manifests, and tests at the recorded commit; Curated references and machine contract in this skill

**Resources:** references/ (17 files; metadata only); assets/ (1 files; metadata only).

## marketing-psychology

[S114] Source: `/Users/alexlobaito/.agents/skills/marketing-psychology/SKILL.md`; kind: canonical. Modified UTC: 2026-09-21T15:05:57.454949+00:00. SHA-256: `573bbe4f6e300e7fb75299e314f56e26382d284782caa2ae0e0f33eb2e646548`.

**Trigger/purpose:** When the user wants to apply psychological principles, mental models, or behavioral science to marketing. Also use when the user mentions 'psychology,' 'mental models,' 'cognitive bias,' 'persuasion,' 'behavioral science,' 'why people buy,' 'decision-making,' 'consumer behavior,' 'anchoring,' 'social proof,' 'scarcity,' 'loss aversion,' 'framing,' or 'nudge.' Use this whenever someone wants to understand or leverage how people think and make decisions in a marketing context. For applying psychology to specific pages, see cro; for pricing tactics, see pricing; for copy framing, see copywriting.

**Contents:** Marketing Psychology & Mental Models; How to Use This Skill; Foundational Thinking Models; First Principles; Jobs to Be Done; Circle of Competence; Inversion; Occam's Razor; Pareto Principle (80/20 Rule); Local vs. Global Optima; Theory of Constraints; Opportunity Cost; Law of Diminishing Returns; Second-Order Thinking; Map ≠ Territory; Probabilistic Thinking; Barbell Strategy; Understanding Buyers & Human Psychology; Fundamental Attribution Error; Mere Exposure Effect; Availability Heuristic; Confirmation Bias.

**Opening guidance (source excerpt):** You are an expert in applying psychological principles and mental models to marketing. Your goal is to help users understand why people buy, how to influence behavior ethically, and how to make better marketing decisions.

**Procedure cues (source excerpts):** Identify which mental models apply to their situation; Explain the psychology behind the model; Provide specific marketing applications; Suggest how to implement ethically; What specific behavior are you trying to influence?

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## meta-ads

[S117] Source: `/Users/alexlobaito/.agents/skills/meta-ads/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:46:34.741626+00:00. SHA-256: `8c7857d46450c7dbf175f969db6ccc39cbcfcbf8c34e52394075126a6a987d9b`.

**Trigger/purpose:** Use when inspecting or managing Meta, Facebook or Instagram ads: ad accounts, campaigns, ad sets, creatives, audiences, pixels or insights. Works through Composio metaads; creates stay paused.

**Contents:** Meta Ads through Composio; Target; Safety; Read-only tools.

**Opening guidance (source excerpt):** Read the meta-ads card before the first call in a session (`~/.agents/tools/cards/meta-ads.md`; on another machine Composio `CUSTOM_IR_NOTES_GET_APP_RULES`). It owns the route (Composio `metaads`, the system user), the spend rule and the retired logins. Javar agents keep their fenced `javar_meta`. Not routes either: Meta's hosted MCP (`mcp.facebook.com/ads`) and the ChatGPT "Increase ROAS — Meta Ads" app.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## meta-hammer-them

[S118] Source: `/Users/alexlobaito/.agents/skills/meta-hammer-them/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:46:34.759692+00:00. SHA-256: `e5049c58182fadc6b6c33633cd8ae0c25bd63e5200076f7d93e364da6d90cd17`.

**Trigger/purpose:** Build or template Alex's Hammer Them (Hammerhead) Meta strategy through Composio metaads: one video per ad set with its own 3-second-viewer exclusion, plus companion cold campaigns.

**Contents:** Hammer Them and companion cold campaigns; Meaning and routing; Essential invariants; Video-viewer audiences; Verified ODAX video-view contract (2026-09-24); Choosing the best cold reference; What counts as done.

**Opening guidance (source excerpt):** Alex uses **Hammer Them** to mean a specific video-retargeting structure, not generic high-frequency retargeting. Recognize “Hammerhead videos” as this workflow when context supports it. Do not ask Alex to re-explain the strategy or reconfirm account/scope already settled in the task.

**Procedure cues (source excerpts):** Use Composio `metaads` and the `meta-ads` skill for account scoping and safety. Composio holds the token; never expose it. Prefer the built-in `METAADS_*` tools; report genuine capability gaps rather than disguising them as completed work. A create or update tool that Composio holds for approval or restricts is a denial: stop and report, never route around it.; Every Hammer input maps to its own ad, ad set and excluded custom audience. Audience source IDs must cover all delivery video IDs for that logical video, including placement variants, and no unrelated videos. Verify IDs and rules rather than trusting matching names.; Use **Finished video link**, not the raw Source link, when that distinction exists. Preserve row IDs. Separate supplied copy alternatives; never paste all variants into one standard ad.; A source campaign is a structural reference. Remap destination Page, Instagram identity, pixels/events, audience IDs, ZIPs, URLs, tracking and dates. Keep intentional structure and settings, and explicitly explain unavoidable adaptations. Never silently borrow another client's assets or geography.; Default every created campaign, ad set and ad to explicit `PAUSED`, and verify delivery status. Creative assets are different: on 2026-09-23 the Meta API rejected creative `PAUSED` and listed only `ACTIVE`, `IN_PROCESS`, `WITH_ISSUES`, and `DELETED`, despite the old CLI offering a PAUSED flag. An ACTIVE creative without an active ad does not deliver or spend. Record its actual asset status; do not claim it is paused or repeatedly retry an unsupported status. Installation and activation are separate. Do not spend, unpause or change live ad delivery without the user's applicable instruction.

**Resources:** references/ (2 files; metadata only).

## meta-paused-campaign-builder

[S119] Source: `/Users/alexlobaito/.agents/skills/meta-paused-campaign-builder/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:46:34.759898+00:00. SHA-256: `65b81efeedefb83753e48e9b3751799e2f5e1ae0150dc4866ca29cace9dbe9ba`.

**Trigger/purpose:** Use when staging, rebuilding, cloning or validating a Meta Ads campaign with several ad sets or reusable creatives through Composio metaads, kept unpublished (PAUSED) and duplicate-safe.

**Contents:** Building Paused Meta Campaigns; Overview; When to Use; Contract; Safety Invariants; Tools; Common Mistakes.

**Opening guidance (source excerpt):** Build from one validated manifest. Reconcile exact names, prove one canary, reuse creative IDs, and finish with consolidated readback.

**Procedure cues (source excerpts):** Copy `templates/campaign-manifest.example.json` into the workspace and add verified IDs and asset paths.; Run `python3 scripts/validate_manifest.py MANIFEST.json`. Stop unless it returns `VALID` and the approved mutation/invocation caps (`max_cli_invocations` now caps Composio tool calls; the field name stays for the validator).; Read campaign/ad-set and ad/creative inventories (`METAADS_LIST_CAMPAIGNS`, `METAADS_READ_ADSETS`, `METAADS_LIST_ADS`, `METAADS_LIST_AD_CREATIVES`). Perform **exact-name reconciliation**; record matches and never duplicate blindly.; Freeze the execution ledger: object name, intended operation, expected ID source, mutation number, and stop condition.; Canary in this order: creative → readback → ad set → readback → ad → readback. Stop on the first failed tool call or incorrect readback.

**Resources:** scripts/ (2 files; metadata only); templates/ (1 files; metadata only).

## niche-ad-farming

[S125] Source: `/Users/alexlobaito/.agents/skills/niche-ad-farming/SKILL.md`; kind: canonical. Modified UTC: 2026-10-06T21:18:46.924697+00:00. SHA-256: `50e3d75888674732e05112198645a309e86f12605c83bf23ff84bb20750ca0c9`.

**Trigger/purpose:** Build or refresh a niche advertiser and ad library in Google Sheets using Apify, Facebook page likes, and SpyFu search-traffic estimates. Use for farming advertisers and their ads across a specified niche and geography, not managing campaigns.

**Contents:** Niche Ad Farming; Outcome and inputs; Tool preflight; 1. Choose and pilot Apify; 2. Discover and qualify cheaply; 3. Enrich qualified pages; 4. Farm ads and publish; Ranking and refresh; Start prompt.

**Opening guidance (source excerpt):** Create a reusable, source-linked Google Sheet of real niche advertisers with **at least 4 distinct currently active Meta ads**, their Facebook page likes/followers, website, SpyFu search-traffic evidence, and collected ad links. Foreplay is not a validator or required dependency.

**Resources:** references/ (1 files; metadata only).

## persuasion-recreator

[S128] Source: `/Users/alexlobaito/.agents/skills/persuasion-recreator/SKILL.md`; kind: canonical. Modified UTC: 2026-09-29T14:05:08.879653+00:00. SHA-256: `647798906804664a46b8a4588e949a18d6162067eb530c562f6e414d8e20378e`.

**Trigger/purpose:** Create a readable Excel comparison with a separate tab per requested product. Each tab lists every original marketing-page element beside faithful and stronger replacements, using existing conversation context and the source's persuasion mechanisms. Export CSV only when requested. This is a copy-planning deliverable, not a page build.

**Contents:** Persuasion Recreator; Match the requested stage and format first; Carry forward the brief; Inspect and segment the source; Decode before drafting; Write both versions for every target product; A — Faithful recreation; B — Challenger designed to beat it; Separate offer design from factual status; Present a reviewable comparison; Final self-check and stopping point.

**Opening guidance (source excerpt):** Recreate the selling mechanism, not merely the subject or layout. A yellow banner containing urgency + a numerical discount + an action must not become a pleasant lifestyle slogan. Let the operator see the original, understand why it sells, inspect the product-specific recreation, and compare a stronger challenger.

**Procedure cues (source excerpts):** **Literal components:** what is actually present—deadline, number, percentage, bonus, proof, outcome, objection, command.; **Persuasion formula:** the ordered combination, such as `time pressure + quantified saving + imperative CTA`.; **Buyer movement:** the belief, emotion, or action it tries to change at this point in the funnel.; **Visible support:** supporting evidence, or what the source asserts without evidence. Intended effect is a hypothesis; an impressive reference is not proof of conversion performance.

**Resources:** references/ (5 files; metadata only); scripts/ (1 files; metadata only).

## revstead-educational-profile-posts

[S136] Source: `/Users/alexlobaito/.agents/skills/revstead-educational-profile-posts/SKILL.md`; kind: canonical. Modified UTC: 2026-09-19T10:11:58.356827+00:00. SHA-256: `540490d8fc24c74b73f94f7fa0025831d8f19b336ef3f8da9dbe0d740106a7fa`.

**Trigger/purpose:** Create educational Facebook and Instagram profile-post visuals for Revstead Systems that teach fencing contractors practical scaling and operations principles. Use when the user asks for Revstead social posts, educational graphics, fencing-contractor content, organic Meta profile content, or a new post in the approved dark green grid visual system.

**Contents:** Revstead Educational Profile Posts; Core Output Rule; Intake; Brand System Lock; Educational Content Rules; Strong content patterns; Copy Structure; Creation Workflow; Prompt Blueprint; Caption Pattern; Edits; Delivery Standard.

**Opening guidance (source excerpt):** Create **practical educational social graphics** for fencing contractors. The work is not a paid-ad recreation and not a generic B2B content factory. Teach one operational lesson at a time, using Revstead’s dark operations-system design language.

**Procedure cues (source excerpts):** A small monospaced category label, such as `FENCING OPERATIONS`.; A clear headline of 5–12 words. Give the key tension, mistake, or principle prominence in emerald green.; One short explanation line, if needed.; A three-to-five-step framework, checklist, or workflow panel.; A restrained footer: `REVSTEAD SYSTEMS` plus a short audience line such as `Built for fencing contractors.`

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## spam-checker-workflow

[S149] Source: `/Users/alexlobaito/.agents/skills/spam-checker-workflow/SKILL.md`; kind: canonical. Modified UTC: 2026-10-07T13:53:10.425588+00:00. SHA-256: `c701b67c398a7b93ee9a019a76830c08bdcb0c53c210e43a8b88aa616b85408f`.

**Trigger/purpose:** Workflow for writing, auditing, and verifying spam-clean emails using the Mailmeteor spam checker. Use when asked to check emails for spam triggers, verify inbox placement, or run email copy through a spam checker tool.

**Contents:** Spam Checker Workflow; Core Principles; Copywriting Rules for Inbox Placement; The Verification Process; Summary of the Verification Loop:; Delivery Format; Required fields, spacing, and acceptance.

**Opening guidance (source excerpt):** This skill codifies the exact process for auditing and verifying email copy to ensure maximum inbox placement, using the Mailmeteor Spam Checker as the source of truth.

**Procedure cues (source excerpts):** **Verification is Mandatory:** Do not guess if an email is clean. Run it through the checker.; **"Great" is the Standard:** Every email must achieve a "Great" score with zero flags before delivery.; **Conversational Tone:** Plain text, conversational emails (like a text from a friend) perform best.; Navigate to `https://mailmeteor.com/spam-checker`; Use `browser_console_exec` to inject the email content and trigger the SPA evaluation (see reference file for the exact JavaScript payload).

**Resources:** references/ (2 files; metadata only).
