# Synced Pointers

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## alex-director

[S176] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/alex-director/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.711023+00:00. SHA-256: `76f5f558810269081dbf992c596e34d64dd720e5e1e5e6940b9765c8b6d7361c`.

**Trigger/purpose:** Alex's Director, Codex app pointer. Read and follow ~/.agents/skills/alex-director/SKILL.md and ~/Alex-Director/AGENTS.md on Alex's MacBook. Use when acting as Alex's Director.

**Contents:** Alex Director — Codex app pointer; How Codex reads and writes the Mac files; Codex transport (the canonical files cover Codex and Cursor controllers); If the files can't be read.

**Opening guidance (source excerpt):** This upload carries no policy or routes of its own, so it can't go stale. On every Director turn, read these from Alex's MacBook and follow them exactly: 1. `~/.agents/skills/alex-director/SKILL.md`, the canonical Director skill. Its "Where things are" table says which `references/` file each job needs. 2. `~/Alex-Director/AGENTS.md`, the role card and read table.

**Procedure cues (source excerpts):** `~/.agents/skills/alex-director/SKILL.md`, the canonical Director skill. Its "Where things are" table says which; `~/Alex-Director/AGENTS.md`, the role card and read table.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## alex-workflow-conductor

[S177] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/alex-workflow-conductor/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.732677+00:00. SHA-256: `960d8c19ed824f8a448b0519c53024bb93d64cb838a5c0ab3ad6e5559622225a`.

**Trigger/purpose:** Alex's workflow conductor, Codex app pointer. Read and follow ~/.agents/skills/alex-workflow-conductor/SKILL.md on Alex's MacBook. Use only when Alex names the conductor.

**Contents:** Alex Workflow Conductor — Codex app pointer; How Codex reads the Mac files; Codex transport (the canonical file covers Codex and Cursor); If the file can't be read.

**Opening guidance (source excerpt):** This upload carries no policy or routes of its own, so it can't go stale. The canonical skill is `~/.agents/skills/alex-workflow-conductor/SKILL.md` on Alex's MacBook. Read it from disk now and follow it exactly. Its shared policy is in `~/.agents/skills/alex-director/references/`; read the section you need.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## built-in-browser

[S178] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/built-in-browser/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.731634+00:00. SHA-256: `878ae449414042b04a5d18729523124173c710df1268a89da8685854edaadf38`.

**Trigger/purpose:** Read this skill before the first step that uses the built-in browser, the browser pane inside the Codex desktop app (also called the in-app browser, the browser pane, Codex's browser, or \"your own browser\"), whose tools are named mcp__Claude_Browser__* when the session runs in the desktop app and mcp__remote-devices__Claude_Browser__* when a cloud session is linked to the person's computer; before those tools are turned on there may be a single enable__mcp__remote-devices__Claude_Browser tool instead. It covers the pane's persistent sign-ins, tabs and preview_start, reading pages as text, site approvals, what the pane cannot open, and what to do when it cannot be reached. It is not for Codex in Chrome (mcp__claude-in-chrome__* tools), which has its own skill, and it does not decide which browser to use.

**Contents:** Built-in browser; What the person can see; Sign-ins persist, and they are the person's; Tabs; Loading via ToolSearch; Reading pages; Site approvals, blocked sites, and request_access; What the built-in browser cannot open; When the built-in browser cannot be reached.

**Opening guidance (source excerpt):** The built-in browser is a real browser pane inside the Codex desktop app, separate from the person's Chrome. Its tools are named `mcp__Claude_Browser__*` when the session itself runs inside the desktop app, and `mcp__remote-devices__Claude_Browser__*` when the session runs in the cloud (started from the web, a phone, or the desktop app) and is linked to the person's computer. The names after the prefix are the same either way, Codex uses whichever prefix is actually present, and this skill refers to the tools by the part after the prefix.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## chrome-browser

[S179] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/chrome-browser/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.730981+00:00. SHA-256: `00d5488dbb85e7237e07a4c25c497c533702c004bc523d53510c7dbf35d64d7f`.

**Trigger/purpose:** Read this skill before the first step that uses Codex in Chrome, the browser extension whose tools are named mcp__claude-in-chrome__* (also called Chrome, the browser extension, or the external browser) and which acts in the person's real Chrome with their own sign-ins; before those tools are turned on there may be a single enable__mcp__claude-in-chrome tool instead. It covers loading the tools in one ToolSearch call, checking the person's open tabs and working in a new tab, site permissions, GIF recordings, console logs, dialogs to avoid, and when to stop and ask. It is not for the built-in browser (mcp__Claude_Browser__* or mcp__remote-devices__Claude_Browser__* tools), which has its own skill, and it does not decide which browser to use.

**Contents:** Codex in Chrome; Loading the tools; Starting a session: tab context first, then a new tab; Site permissions; Recording a GIF; Reading console output; Alerts and dialogs; Staying on task, and when to stop.

**Opening guidance (source excerpt):** Codex in Chrome is a browser extension. Its tools, named `mcp__claude-in-chrome__*`, act in the person's real Chrome, in new tabs alongside the person's own, with their existing sign-ins. Codex in Chrome is available only while the person's Chrome is running with the extension connected; if its tool calls report that the extension is not connected or get no response, Codex says so rather than retrying, and follows the session's browser guidance on whether to continue with the other browser or ask first.

**Procedure cues (source excerpts):** Codex reuses an existing tab only when the person explicitly asks to work with it.; Otherwise Codex opens a new tab with `mcp__claude-in-chrome__tabs_create_mcp` and works there, and, unless the person wants them kept, closes the tabs it created before finishing.; Codex never reuses tab IDs remembered from an earlier or different session. If a tool reports that a tab does not exist or is invalid, or the person closes a tab, or a navigation error occurs, Codex calls `tabs_context_mcp` again for fresh tab IDs.; Codex avoids clicking elements likely to raise a confirmation dialog (for example a "Delete" button) unless necessary.; If it must interact with such an element, Codex warns the person first that this may interrupt the session.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## computer-use

[S180] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/computer-use/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.732182+00:00. SHA-256: `ef5968dcb537266d6a3e18dd953372e43d780dc5e20effed276cafd68d751276`.

**Trigger/purpose:** Read this skill before the first step of any request to do something in an app on the person's own computer (Notes, Finder, System Settings, any desktop app), to look at their screen, or for \"computer use\". Computer use (desktop control) lets Codex take screenshots of the person's desktop and control it with clicks, typing and scrolling through the Codex desktop app; its tools are named mcp__computer-use__* when the session runs in the desktop app and mcp__remote-devices__computer_* when a cloud session is linked to the person's computer; before computer use is turned on for a conversation there may be no such tools, only an enable__mcp__remote-devices__computer tool, which turns it on. It covers turning it on, picking the right tool, the access flow, and the safety rules for tiered apps, links and financial actions. It is not for websites, which go through Codex in Chrome or the built-in browser and their own skills.

**Contents:** Computer use (desktop control); Turning computer use on from a chat; Separate filesystems; Pick the right tool for the app; Look before asserting; Loading via ToolSearch; Access flow; Tiered apps; Link safety; Financial actions.

**Opening guidance (source excerpt):** Computer use lets Codex take screenshots of the person's desktop and control it with mouse clicks, keyboard input, and scrolling, through the Codex desktop app. Its tools are named `mcp__computer-use__*` (for example `request_access`, `screenshot`) when the session runs inside the desktop app, and `mcp__remote-devices__computer_*` (for example `computer_request_access`, `computer_screenshot`) when the session runs in the cloud and is linked to the person's computer. Computer use works only while Computer use is turned on in the Codex desktop app (Settings → Desktop app → Computer use; it is off by default).

**Procedure cues (source excerpts):** **Computer-use tools are present.** Codex goes straight to the access flow below.; **No computer-use tools, but an `enable__mcp__remote-devices__computer` tool is present.** Codex calls that tool once, before any other step of the task, with the task in its `task` field. When the call goes through, the `mcp__remote-devices__computer_*` tools arrive with it and Codex starts with the access flow below; there is no second enable step. If it does not go through, Codex relays the reason in one line and carries on with what it can do in the conversation.; **Neither.** Computer use is not available in this conversation as it stands, and Codex says so plainly without diagnosing why: in general Codex can use apps on a computer where the Codex desktop app is installed and signed in with Computer use turned on, and on Codex.ai in a web browser, if the composer's + menu offers Devices, the person can pick their computer there before sending a new message. Codex does not pretend to act.; **Dedicated MCP for the app**: if the task is in an app that has its own MCP (Slack, Gmail, Calendar, Linear, etc.) and that MCP is connected, Codex uses it. API-backed tools are fast and precise.; **Browser tools**: if the target is a web app and there's no dedicated MCP for it, Codex uses a browser: Codex in Chrome (tools named `mcp__claude-in-chrome__*`) or the built-in browser (tools named `mcp__Claude_Browser__*` in the desktop app, `mcp__remote-devices__Claude_Browser__*` when a cloud session is linked to the person's computer). Both are DOM-aware, much faster than clicking pixels. If this prompt has a `<browsers>` section, Codex follows it on which browser to use; otherwise it uses whichever one is connected. If neither is connected, Codex asks the person to connect one rather than falling through to computer use.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## docs

[S181] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/docs/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.711484+00:00. SHA-256: `d35db4eaeb32be04086884008fc07aa1c120fe2065fcf518e93eddd5c8776f39`.

**Trigger/purpose:** docs (editable docs people share and comment on; the default for any document, named as a doc or not: a document, report, proposal, resume, cover letter, letter, contract, policy, form, template, worksheet, essay, handbook, guide, how-to, cheat sheet, SOP or other writing to keep, share, collaborate on, send, submit, print or sign; a doc exports to Word, PDF, Markdown or Google Docs, so needing a file to send, attach, upload, submit or print is no reason to pick Word, and a file nobody asked for is a doc, not Word; a plan, comparison, summary or notes asked in chat stays in chat; a pasted Codex.ai artifact link may be a doc: check with docs tools first; Word or another file format named, tracked changes wanted, or a .docx to change or use as a template → that format''s skill): making one → if no docs-connector instructions are in context, call its `guide` (topic.instructions) first; then create the doc (headings only, no body) before any search, file read or plan, even with files attached.

**Contents:** No Markdown headings..

**Opening guidance (source excerpt):** Everything about docs is served by the docs connector — follow its instructions (they say what to call first). If no docs tools are present (they may be listed as pages tools on some accounts), say so.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## docx

[S182] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/docx/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.745715+00:00. SHA-256: `41373257a5b614ef482d9a56df681fdedc67f5d8c93794a7fe8881d0a6a7a807`.

**Trigger/purpose:** Use this skill whenever the user wants to create, read, edit, or manipulate Word documents (.docx) or Word templates (.dotx). Triggers include: any mention of Microsoft Word Documents, such as 'Word doc', 'word document', '.docx', '.dotx', 'microsoft doc'. Also use when extracting or reorganizing content from .docx or .dotx files, inserting or replacing images in documents, find-and-replace in Word files, working with tracked changes or comments, or converting content into a polished Word document. If the user asks for a deliverable as a Word or .docx file (to download, email or print), use this skill. However, if they ask for a document, page, report, memo, or notes WITHOUT naming a file format and the session offers Codex's own dedicated document or page skill or connector, use that instead, even if they will email or print it. Do NOT use for PDFs, spreadsheets, Google Docs, or coding unrelated to document generation.

**Contents:** DOCX creation, editing, and analysis; Creating with docx-js — gotchas; Verify the output; Editing existing documents; edit unpacked/word/document.xml in place — do NOT reformat or pretty-print; redlining? add --author "<the name you redlined under>" to check every edit is tracked; Comments; Against an already-unpacked directory (preferred when also placing markers); Against a .docx directly; Dependencies.

**Opening guidance (source excerpt):** If you are about to make a new document and this session offers Codex's own docs (a Docs connector, docs skill or Docs artifact type), and the user has neither named Word/.docx/.dotx, asked for tracked changes, nor supplied a .docx/.dotx file to change or use as a template, make the document there instead. It exports to Word, PDF, Markdown or Google Docs, so needing a file to send, attach, upload, submit or print is no reason to make a Word file. A .docx/.dotx given only as source material does not count as supplied. This skill remains the right tool for producing, reading, editing, templating or converting Word files.

**Resources:** scripts/ (59 files; metadata only).

## first-principles-speed-analyzer

[S183] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/first-principles-speed-analyzer/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.746271+00:00. SHA-256: `24ccfb17a19bd0b0f6464ece022a77df0979cbfa77e207fab47fff751b037a13`.

**Trigger/purpose:** Use before planning a multi-step project where speed and scope matter. Picks the smallest evidence-backed first proof, the existing assets to extend, and the first blockers.

**Contents:** First-Principles Speed Analyzer; Operating boundaries; Workflow; Required Output; First-Principles Speed Analysis — [Project / Outcome]; Outcome; Evidence Coverage; What Must Be True Once; Fastest First Proof; First-Proof Blockers; KEEP / CUT / SIMPLIFY / LATER; Build Now — One Item Only; Next Action; Quality bar.

**Opening guidance (source excerpt):** Use this skill to decide **what to build first and why**. It is a read-only planning skill, not an implementation agent.

**Procedure cues (source excerpts):** **State the actual outcome.** Define the user-visible or operator-visible behavior that matters, not an implementation slogan. Name the actor, trigger, successful result, and success condition.; **Inventory the evidence.** Record the named source set and distinguish:; **Reason from first principles.** Ask what must be true for the desired behavior to occur once; which existing repository, runtime, data store, schema, workflow, or tool already supplies each requirement; what exact link is missing between trigger and observable result; and what smallest safe test distinguishes a real capability from a claim.; **Select one first proof.** Define a minimal end-to-end scenario with a controlled input, one expected output, a receipt or readback where relevant, and a safe failure path. Prefer a synthetic, local, or staging proof over live customer or production activity.; **Find only first-proof blockers.** Classify each as:

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## google-workspace

[S184] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/google-workspace/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.729931+00:00. SHA-256: `26f118315a2afb011abcdb75a7bc6db3417e50a7fc07c783c31d286c1de32309`.

**Trigger/purpose:** Read this before the first Google Drive, Docs, Sheets or Slides connector call whenever the task creates or changes a Google file. Use this skill whenever the user wants to create or change a Google Doc, Sheet or Slides file in their Google Drive. Triggers include: a request that names Google Docs, Sheets, Slides or Drive and asks to make, edit, format, copy or rename a file; a docs.google.com link with a request to change that file, even a one-line fix or suggested edits; and any follow-up change to a Google file from earlier in the chat, even \"change it\" or \"add a tab\". Includes helper scripts for document positions, cell ranges and slide layout. However, if the user asks for a doc, deck or spreadsheet without naming Google, or gives a Google file only as source material for something new, use Codex's own output type instead. Do NOT use for read-only questions about a Google file, or for Word, Excel, PowerPoint or PDF files.

**Contents:** Google Docs, Sheets, and Slides; Read the reference before you touch the file; 1. Check the connectors before you start; 2. Rules for every file; 3. Drive, for all three apps; 4. Helper scripts; 5. Common failures across apps; 6. What the connectors can't do.

**Opening guidance (source excerpt):** The Google connectors are thin wrappers over Google's raw APIs, with almost no guidance of their own. This skill supplies that guidance: which connector does what, the rules that keep edits in the user's file, and, in one reference file per app, how each API really behaves. Most of the app-specific rules in the references were tested against Google's Docs, Sheets and Slides APIs; the rest were seen through the connectors, and a few have not been checked yet.

**Procedure cues (source excerpts):** Check which Google tools are available in this conversation. On surfaces where tools are deferred, search for and load the tools you need first, such as "google sheets update". Tool names differ by surface, so use the names your surface lists. If a search returns nothing, list all available tools before deciding the connector is missing, because the tool may exist under a different name.; If the editor tools are missing, tell the user. When you can list the conversation's connectors, say which case it is: a connector that is set up but turned off in this chat (ask them to turn it on in the chat's connector settings, then continue), or one that isn't connected at all (tell them which connector to add and what it enables).; With an editor connector missing, a request to create a new file continues with Drive. A change to an existing file stops and asks. See the missing-connector rule in section 2.; If the user asks only for a new file, create it with Drive. If the editor connector is off, add one line saying edits will need it.

**Resources:** references/ (4 files; metadata only); scripts/ (4 files; metadata only).

## hermes-boss-director

[S185] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/hermes-boss-director/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.746790+00:00. SHA-256: `cbea68b6667642d7270fda4a143c6a6bd7d52a68acb87c30f1bf37a4ddd4c7b0`.

**Trigger/purpose:** Hermes controller playbook for Javante/Javar under the Director and Conductor: native-fix research, right-route dispatch, live verification.

**Contents:** Hermes Boss Director; 0. Operating rules (always on); 1. Mission; 2. Root cause from evidence; 3. Parallel research — find the documented fix; Existing skill found? Audit it first; 4. Cross-reference the live setup; 5. Report; 6. Plan; 7. Dispatch — right route per fix; 8. Supervise and verify; 9. Record and improve.

**Opening guidance (source excerpt):** Find the fix the tool's maker already built, prove it against the live setup, get it done on the right route with the least human involvement, and verify it on the real system.

**Procedure cues (source excerpts):** **Hermes docs + changelog** — pull latest docs from GitHub (never the bot's installed copy):; **GitHub issues/PRs** — Exa: "NousResearch hermes-agent github issue <symptom>". Merged PR/maintainer comment = documented fix; open issue = known bug.; **Vendor docs** (GHL, Meta, Google, Cloudflare) — Ref, then Exa; include ideas boards / API-docs issues to learn when an API doesn't exist.; **AI Money archive** (Alex's private Cloudflare AI Search) — account `a3f549867f040e13df33e5bd18f785f4`, namespace `default`, instance `aimoney-archive`, via the Cloudflare connector:; **Existing tools/skills** — descriptions of tools the bot already has; Hermes bundled/optional skills; the skills hub.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## integration-fit-and-source-of-truth

[S186] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/integration-fit-and-source-of-truth/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.712058+00:00. SHA-256: `5c8b66ead4b0f49d79628a2fafdefcea638219db1a7f79369d78efad029809b8`.

**Trigger/purpose:** Use before building an API call, webhook, CRM connection or automation. Decides native vs custom, names one system of record per object, and lists the permissions and proof needed.

**Contents:** Integration Fit and Source of Truth; Operating boundaries; Workflow; Required output; Integration Fit — [Workflow Name]; Desired Outcome; Systems and Scope; Capability Matrix; Source-of-Truth and Data Rules; Material Risks and Unknowns; Decision; Proposed Next Step; Quality bar.

**Opening guidance (source excerpt):** Use this skill to decide **whether an integration should exist and what it must preserve** before attempting to configure or build it. This is a read-only assessment skill, not an implementation guide.

**Procedure cues (source excerpts):** **Define the business outcome.** State the trigger, the desired visible result, the actor who needs it, and the smallest success condition. Do not start with an API or tool choice.; **Name the systems and boundaries.** Identify the proposed source system, destination system, relevant client/account/environment, and any current process that already achieves part of the outcome.; **Verify capabilities.** Check official current documentation and any available read-only account evidence. For each needed capability—trigger, read, write, identity mapping, history/context, status/receipt, error handling, and rate/permission requirements—record `Confirmed`, `Unverified`, or `Not supported`. Cite the evidence location.; **Compare the smallest options.** Consider only:; **Declare the system of record.** For each object that matters—contact, conversation, job, task, event, status, receipt, or metric—name exactly one current source of truth. State which system may read it, which may create/update it, and how conflicts are resolved. Preserve an existing approved system of record unless an owner explicitly decides otherwise.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## mission-intake-and-approval-gate

[S187] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/mission-intake-and-approval-gate/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.730453+00:00. SHA-256: `8527b49884964b63a6c6b8573dc6b649704cfdd99eec7c42b3abe0b0034f1bbb`.

**Trigger/purpose:** Use before consequential, multi-client, source-heavy or cross-system work. Read-only gate: checks client, mission, sources, environment, scope and approval, then gives one decision.

**Contents:** Mission Intake and Approval Gate; Operating boundaries; Workflow; Required output; Mission Intake Gate — [Mission Name]; Requested Outcome; Verified Identity; Authoritative Source Manifest; Prerequisites and Approval; Excluded or Conflicting Material; Gate Decision; Smallest Next Action; Quality bar.

**Opening guidance (source excerpt):** Use this skill **before execution**, not as permission to execute. It is a read-only gate that prevents work from starting under the wrong client, source set, environment, or approval state.

**Procedure cues (source excerpts):** **State the mission.** Record the requested outcome in one sentence. Name the client/project, repository or workspace, target environment, and requested change or decision. If any is absent, mark it unknown rather than infer it.; **Map the authoritative sources.** Identify the exact source files, links, repository paths, task IDs, or documents that govern this mission. Separate them from reference material, historical material, duplicate copies, and unverified notes.; **Verify accessibility and identity.** Confirm that each required source is reachable, readable, and belongs to the named mission. Record missing, inaccessible, conflicting, or duplicated sources. Never claim a source was reviewed if it was not accessible.; **Check prerequisites.** Inspect only the stated approval, recovery, dependency, and current-state evidence. Confirm exact status values from the source; do not invent an approval flag or assume that a plan, document, or past chat equals implementation proof.; **Check for contamination.** List every file. Mark in-scope vs excluded (foreign client / other mission). In-scope = files that state the Goal's client, contract, IDs, or outcome. Exclude foreign files from the working set unless the user explicitly authorizes combining them.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## native-fix-research

[S188] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/native-fix-research/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.717108+00:00. SHA-256: `99f5c16ec602bc7b35b445345d019d528a3f962a062b9c2185e6b4461d541550`.

**Trigger/purpose:** Find the documented native fix for a bot/tool failure, plan it as a mission, fix it with parallel agents on the right route (Hermes app UI, live view, SSH, API; browser last), and supervise until verified live.

**Contents:** Native fix research → mission plan → parallel fix → verify; 0. Freeze the mission; 1. Root causes from evidence, not memory; 2. Find the documented fix (stop at the first documented answer); 3. Cross-reference the live setup (read-only); 4. Report (brief); 5. Plan: one node per fix; 6. Launch parallel controller agents — right route per fix; 7. Supervise until done; 8. Verify and record.

**Opening guidance (source excerpt):** Goal: every fix is something the tool's maker already built and documented, checked against what is configured today, carried out by agents on the right route, and proven on the real system.

**Procedure cues (source excerpts):** **Latest Hermes docs from GitHub** (never the bot's installed copy — frozen at install):; **GitHub issues/PRs** via Exa (`web_search_exa`, "NousResearch hermes-agent github issue <symptom>"). Merged PR or maintainer comment = documented fix; open issue = known bug, no fix yet.; **Vendor docs** (GHL, Meta, Google) via Ref (`ref_search_documentation`) then Exa, including ideas boards / API-docs issues — they tell you when an API route doesn't exist.; **Descriptions of tools the bot already has** — often the fix is an unused installed tool.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## pdf

[S189] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/pdf/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.710388+00:00. SHA-256: `9f78b8359fbd4943ad260a7a1e436e5a96503406d6c34e99f69223d647d85b9c`.

**Trigger/purpose:** Use this skill whenever the user wants to do anything with PDF files. This includes reading or extracting text/tables from PDFs, combining or merging multiple PDFs into one, splitting PDFs apart, rotating pages, adding watermarks, creating new PDFs, filling PDF forms, encrypting/decrypting PDFs, extracting images, and OCR on scanned PDFs to make them searchable. If the user mentions a .pdf file or asks to produce one, use this skill.

**Contents:** PDF Processing Guide; Overview; Quick Start; Read a PDF; Extract text; Python Libraries; pypdf - Basic Operations; Merge PDFs; Split PDF; Extract Metadata; Rotate Pages; pdfplumber - Text and Table Extraction; Extract Text with Layout; Extract Tables; Advanced Table Extraction; Combine all tables; reportlab - Create PDFs; Basic PDF Creation; Add text; Add a line; Save; Create PDF with Multiple Pages.

**Opening guidance (source excerpt):** This guide covers essential PDF processing operations using Python libraries and command-line tools. For advanced features, JavaScript libraries, and detailed examples, see REFERENCE.md. If you need to fill out a PDF form, read FORMS.md and follow its instructions.

**Resources:** scripts/ (8 files; metadata only).

## plain-english-repo-explainer

[S190] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/plain-english-repo-explainer/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.688596+00:00. SHA-256: `49ca0719b7132abf243c47ac99c2b835d916321cc5c6d76263d47a6b5db18104`.

**Trigger/purpose:** Use before changing an unfamiliar repository, or when Alex asks what a codebase does. Explains it in plain English, separates facts from assumptions, and names one next action.

**Contents:** Plain-English Repository Explainer; Safety boundary; Inspection workflow; Owner-facing output.

**Opening guidance (source excerpt):** Inspect the repository as evidence and explain it without changing it.

**Procedure cues (source excerpts):** Read the README and existing architecture, setup, handoff, and operational documents.; Identify the stack from manifests, lockfiles, build configuration, and deployment configuration.; Map the top-level directories and identify the main application entry points, routes, APIs, data models, background processes, integrations, tests, and build/deployment surfaces that are relevant to the user's question.; Trace the smallest relevant end-to-end flow through the codebase. Prefer direct source evidence over descriptions in old documents.; Inspect Git status and recent history when available. Treat uncommitted work as pre-existing and do not alter it.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## pptx

[S191] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/pptx/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.727820+00:00. SHA-256: `e696cb77c693430b7c75b3c729eaf93ed2c0eac2301e6779b1a4a8122660e219`.

**Trigger/purpose:** Use this skill any time a .pptx or .potx file is involved in any way — as input, output, or both. This includes: creating slide decks, pitch decks, or presentations as PowerPoint (.pptx) files; reading, parsing, or extracting text from any .pptx or .potx file (even if the extracted content will be used elsewhere, like in an email, summary, or creating a different type of slide deck); editing, modifying, or updating existing presentations; combining or splitting slide files; working with templates (.potx), layouts, speaker notes, or comments. Trigger whenever the user asks for a PowerPoint or .pptx file, or references a .pptx or .potx filename, regardless of what they plan to do with the content afterward. However, when the user asks for a deck, slides, a slide deck, or a presentation without naming a file format, default to using a dedicated slide-deck artifact type or a separate slides skill if this session offers one; otherwise, use this skill.

**Contents:** PPTX creation, editing, and analysis; Scripts; Creating with pptxgenjs — gotchas; Structured decks; Editing existing decks and templates; reorder / delete slides = edit <p:sldIdLst> in ppt/presentation.xml; edit slide content in ppt/slides/slideN.xml; Design Ideas; Before Starting; Color Palettes; For Each Slide; Typography; Spacing; Avoid (Common Mistakes); QA (Required); Content QA; File QA (required); Visual QA; Converting to Images; Dependencies.

**Opening guidance (source excerpt):** If this session offers a dedicated slide-deck artifact type or a separate slides skill, and the user has neither asked for a PowerPoint/.pptx file nor supplied a .pptx/.potx file to edit, fill in, or convert, build the deck with that type or skill instead. A .pptx/.potx file given only as source material or as an example for a new deck ("make another deck like this one") does not count as supplied: read it with this skill, then build the new deck with that type or skill. This skill remains the right tool for producing .pptx files and for reading, editing, templating, or converting existing .pptx/.potx files.

**Procedure cues (source excerpts):** **Theme first:** `const THEME = { name, headFontFace, bodyFontFace, colors: { dk1, lt1, dk2, lt2, accent1 … accent6, hlink, folHlink } }`, colors in hex. `pres.theme` takes the two fonts and nothing else. Name no font after that — titles get the heading font, other text the body font — except on chart text, which is hard-coded Arial: give its `*FontFace` options `"+mn-lt"` (theme body font; `"+mj-lt"` is the heading font).; **`const C = pres.SchemeColor` for every color** — `C.text1`/`C.text2` are `dk1`/`dk2`, `C.background1`/`C.background2` are `lt1`/`lt2`. These take hex only, read from `THEME`: `valGridLine.color`, `catGridLine.color`, `shadow.color`, and on a one-series bar chart `invertedColors` or more than one `chartColors`. A scheme color there is written as `<a:srgbClr val="bg2"/>` without complaint, and being hex, these will not follow a later change of theme.; **Sections:** `pres.addSection({ title })` just before that section's first slide, then `sectionTitle` on every `addSlide`. A slide without one — or, when sections are all declared up front, a table's auto-paged continuation slides — lands in a stray "Default-N" section.; **One layout per slide frame** (`defineSlideMaster()`): title, section divider, title only, chart + commentary, table; dark and light variants if the design alternates. Text regions are named placeholders carrying position, size, weight and `color` — chart, image and table placeholders need a `color` too, or prompt text and arrays of runs come out hard-coded `000000`. Footer text, logo and `slideNumber` go on the layout, never on a slide.; **Fill by name:** `addSlide({ masterName, sectionTitle })`, then `addText("…", { placeholder: "title" })` with no position, size or color — the placeholder's own options win, and anything it doesn't set (italic, `align`, `fontFace`) still applies; style one run with `[{ text, options }]`. A misspelt `placeholder` or `masterName` fails silently (a stray text box at 0,0; the blank layout). Only `title`, `body` and `chart` placeholders fill by name alone: `addImage({ placeholder })` takes the placeholder's x and y but not its size (a 1" × 1" picture) — pass `w`/`h` too. `addTable({ placeholder })` takes its x and y only — always pass `w`; when it auto-pages it ignores the placeholder and runs off the slide, so also pass `x`, `y` and `autoPageSlideStartY` (same as `y`, or continuation pages are laid out from the top margin), give the layout a `margin` whose bottom clears the footer, and fill the continuation slides' titles through `slide.newAutoPagedSlides`.

**Resources:** scripts/ (55 files; metadata only).

## skill-creator

[S192] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/skill-creator/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.715521+00:00. SHA-256: `614cc82a45173d04a481eb7e2a3c78d060a6c9ce13dfe4234212aeb23aae5b63`.

**Trigger/purpose:** Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, edit, or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.

**Contents:** Skill Creator; Communicating with the user; Creating a skill; Capture Intent; Interview and Research; Write the SKILL.md; Skill Writing Guide; Anatomy of a Skill; Progressive Disclosure; Principle of Lack of Surprise; Writing Patterns; Report structure; [Title]; Executive summary; Key findings; Recommendations; Commit message format; Writing Style; Test Cases; Running and evaluating test cases; Step 1: Spawn all runs (with-skill AND baseline) in the same turn; Step 2: While runs are in progress, draft assertions.

**Opening guidance (source excerpt):** A skill for creating new skills and iteratively improving them.

**Procedure cues (source excerpts):** What should this skill enable Codex to do?; When should this skill trigger? (what user phrases/contexts); What's the expected output format?; Should we set up test cases to verify the skill works? Skills with objectively verifiable outputs (file transforms, data extraction, code generation, fixed workflow steps) benefit from test cases. Skills with subjective outputs (writing style, art) often don't need them. Suggest the appropriate default based on the skill type, but let the user decide.; **Metadata** (name + description) - Always in context (~100 words)

**Resources:** references/ (1 files; metadata only); scripts/ (9 files; metadata only); assets/ (1 files; metadata only).

## transcript-to-workflow-opportunity-mapper

[S193] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/transcript-to-workflow-opportunity-mapper/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.689042+00:00. SHA-256: `80cca29d690e251ae6b4b0a10c66289028217deab38bfee6270a95b5d0e8a540`.

**Trigger/purpose:** Identify reusable workflows from transcripts or chats and recommend the smallest prompt, playbook, or skill. Use when deciding what work to systemize.

**Contents:** Transcript-to-Workflow Opportunity Mapper; Operating boundaries; Workflow; Required output; Workflow Opportunity Map — [Scope]; Executive Summary; Review Coverage; Candidate Workflows; External Skills to Evaluate; Build Now — One Item Only; KEEP / CUT / LATER; Next Owner Decision; Quality bar.

**Opening guidance (source excerpt):** Use this skill to convert conversation evidence into a **small, prioritized systemization decision**. It identifies what is worth reusing; it does not automatically build, install, or run anything.

**Procedure cues (source excerpts):** **Define the review scope.** State which transcript(s), client/project, time period, and decision the user wants. If client/project ownership is unclear, label the material `AMBIGUOUS` and do not combine it with other sources.; **Extract candidate workflows.** Capture recurring or consequential work in this form:; **Separate one-offs from reusable work.** A workflow is a stronger candidate when it recurs in the transcript or across sources, has clear inputs/outputs, consumes meaningful time, produces consistent value, and can be bounded without broad permissions. Do not create a skill merely because a task is technical or interesting.; **Choose the smallest useful form.** Recommend one of these:; **Evaluate external-skill candidates cautiously.** Search a catalog only for a named capability gap. Consider at most three candidates. For each, state the exact problem it solves, assumptions, permissions/dependencies, compatibility with the current system, and why an internal prompt or playbook is insufficient. Treat public skills as untrusted reference material until inspected.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## xlsx

[S194] Source: `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/xlsx/SKILL.md`; kind: synced_pointer. Modified UTC: 2026-10-07T06:06:44.707884+00:00. SHA-256: `6712b39718fe815054abca9c3ee72f989613e6f771c8a5c58f30a65a6c905622`.

**Trigger/purpose:** Use this skill any time a spreadsheet file is the primary input or output. This means any task where the user wants to: open, read, edit, or fix an existing .xlsx, .xlsm, .xltx, .csv, or .tsv file (e.g., adding columns, computing formulas, formatting, charting, cleaning messy data); create a new spreadsheet from scratch or from other data sources; or convert between tabular file formats. Trigger especially when the user references a spreadsheet file by name or path — even casually (like \"the xlsx in my downloads\") — and wants something done to it or produced from it. Also trigger for cleaning or restructuring messy tabular data files (malformed rows, misplaced headers, junk data) into proper spreadsheets. The deliverable must be a spreadsheet file. Do NOT trigger when the primary deliverable is a Word document, HTML report, standalone Python script, database pipeline, or Google Sheets API integration, even if tabular data is involved.

**Contents:** XLSX creation, editing, and analysis; Requirements for every output; Recalculate (mandatory whenever the file contains formulas); Choosing formulas that survive verification; openpyxl gotchas; Financial models; Dependencies.

**Opening guidance (source excerpt):** > `openpyxl`, `pandas`, and `markitdown` are preinstalled — do not run `pip install` first; write the script and import directly. Only if an import fails (or the `markitdown` command is missing): `pip install` the missing package.

**Resources:** scripts/ (51 files; metadata only).
