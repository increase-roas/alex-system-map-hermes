# Platform System

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## imagegen

[S195] Source: `/Users/alexlobaito/.codex/skills/.system/imagegen/SKILL.md`; kind: codex_system. Modified UTC: 2026-10-01T21:35:53.177255+00:00. SHA-256: `681ddb4ad6d06a2acc78a3535b583f8d0c1ea800ecda3d56370d3310fd2cd4ba`.

**Trigger/purpose:** Generate or edit raster images when the task benefits from AI-created bitmap visuals such as photos, illustrations, textures, sprites, mockups, or transparent-background cutouts. Use when Codex should create a brand-new image, transform an existing image, or derive visual variants from references, and the output should be a bitmap asset rather than repo-native code or vector. Do not use when the task is better handled by editing existing SVG/vector/code-native assets, extending an established icon or logo system, or building the visual directly in HTML/CSS/canvas.

**Contents:** Image Generation Skill; Top-level modes and rules; When to use; When not to use; Decision tree; Workflow; Transparent image requests; Prompt augmentation; Specificity policy; Use-case taxonomy (exact slugs); Shared prompt schema; Examples; Generation example (hero image); Edit example (invariants); Prompting best practices; Guidance by asset type; gpt-image-2 guidance for CLI fallback; Fallback CLI mode only; Temp and output conventions; Dependencies; Environment; Script-mode notes.

**Opening guidance (source excerpt):** Generates or edits images for the current project (for example website assets, game assets, UI mockups, product mockups, wireframes, logo design, photorealistic images, or infographics).

**Procedure cues (source excerpts):** If the user names a destination, move or copy the selected output there.; If the image is meant for the current project, move or copy the final selected image into the workspace before finishing.; If the image is only for preview or brainstorming, render it inline; the underlying file can remain at the default `$CODEX_HOME/*` path.; **Intent:** is this a new image or an edit of an existing image?; **Execution strategy:** is this one asset or many assets/variants?

**Resources:** references/ (5 files; metadata only); scripts/ (2 files; metadata only); assets/ (2 files; metadata only).

## openai-docs

[S196] Source: `/Users/alexlobaito/.codex/skills/.system/openai-docs/SKILL.md`; kind: codex_system. Modified UTC: 2026-10-01T21:35:53.178267+00:00. SHA-256: `aa6829e21df2223167c85d2e49b6337a7345c84c1033f1ec10182c7882b36d45`.

**Trigger/purpose:** Use for Codex models/pricing, scheduled tasks, skills, settings, setup, troubleshooting, customization, automations, and self-knowledge—including 'you,' 'your,' 'this app,' or 'this coding agent' when they refer to Codex—and for OpenAI APIs/products and ChatGPT Work. Also use for model choice/migration, prompting, SDKs, Responses, Realtime, agents, evals, and Chat/Work/Codex comparisons. Do not use for generic app/software tasks that merely mention Codex.

**Contents:** OpenAI Docs; Choose one primary route; Source and execution boundaries.

**Opening guidance (source excerpt):** Provide current, cited OpenAI product, API, model, and Codex guidance. Read zero or one primary reference.

**Resources:** references/ (9 files; metadata only); scripts/ (3 files; metadata only); assets/ (2 files; metadata only).

## review-agent

[S197] Source: `/Users/alexlobaito/.codex/skills/.system/review-agent/SKILL.md`; kind: codex_system. Modified UTC: 2026-10-01T21:35:53.179698+00:00. SHA-256: `07079efd0dc76f05fade424e5dfb048dce1de2df7626e1a4f56292a4f3f92228`.

**Trigger/purpose:** Perform a read-only, defect-first review of a specified code change and return every actionable finding. Use when another agent delegates review of uncommitted changes, a base-branch diff, a commit, or custom review instructions.

**Contents:** Review Agent; Review the change; Write the result.

**Opening guidance (source excerpt):** Inspect the requested target directly and return every finding that the author would likely fix. Do not modify files, create commits, push branches, post review comments, or delegate the review to another agent.

**Procedure cues (source excerpts):** Read the applicable `AGENTS.md` instructions.; Inspect the complete diff for the requested target and enough surrounding code to understand; Identify concrete regressions introduced by the change. Continue through the whole diff after; Check the relevant tests and call sites to confirm that each finding is real and actionable.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## skill-creator

[S198] Source: `/Users/alexlobaito/.codex/skills/.system/skill-creator/SKILL.md`; kind: codex_system. Modified UTC: 2026-10-01T21:35:53.180000+00:00. SHA-256: `6656e54755638e8efcf275a472b9672eaa8a9a1b9e59dc210e275b03b59e1e66`.

**Trigger/purpose:** Create or update a Codex skill with appropriately scoped instructions and any needed supporting resources.

**Contents:** Skill Creator; Core Principles; Anatomy of a Skill; SKILL.md; Scripts; References; Assets; UI Metadata and Invocation Policy; What Not to Include; Progressive Disclosure in Practice; Documents; Create or Update a Skill; Naming; Initialize a New Skill; Write the Instructions; Validate and Iterate; Independent Forward-Testing.

**Opening guidance (source excerpt):** Create skills that give Codex useful, non-obvious guidance without constraining unrelated work.

**Procedure cues (source excerpts):** **Name and description:** Available during skill selection, so keep them concise and discriminating.; **SKILL.md body:** Loaded when the skill applies, so keep its instructions relevant to that task.; **Supporting resources:** Read or execute only when the current task actually needs them.

**Resources:** references/ (1 files; metadata only); scripts/ (3 files; metadata only); assets/ (2 files; metadata only).

## skill-installer

[S199] Source: `/Users/alexlobaito/.codex/skills/.system/skill-installer/SKILL.md`; kind: codex_system. Modified UTC: 2026-10-01T21:35:53.181631+00:00. SHA-256: `d68b77e5bbb34dedab89d134da52855f140fc4b4299b80104f534e3b9e98f8ee`.

**Trigger/purpose:** Install Codex skills into $CODEX_HOME/skills from a curated list or a GitHub repo path. Use when a user asks to list installable skills, install a curated skill, or install a skill from another repo (including private repos).

**Contents:** Skill Installer; Communication; Scripts; Behavior and Options; Notes.

**Opening guidance (source excerpt):** Helps install skills. By default these are from https://github.com/openai/skills/tree/main/skills/.curated, but users can also provide other locations. Experimental skills live in https://github.com/openai/skills/tree/main/skills/.experimental and can be installed the same way.

**Procedure cues (source excerpts):** skill-1; skill-2 (already installed); ...

**Resources:** scripts/ (3 files; metadata only); assets/ (2 files; metadata only).
