# Engineering Execution

Checked 2026-10-07. Reference summaries of actual SKILL.md reads; canonical procedures remain at their source. Supporting-resource counts are metadata, not contents audits.

## agents-sdk

[S004] Source: `/Users/alexlobaito/.agents/skills/agents-sdk/SKILL.md`; kind: canonical. Modified UTC: 2026-08-29T02:40:08.641759+00:00. SHA-256: `a05244d3cfb23330daff956ec28a990241f5dbbe489cd7fd6489c8f76bb60877`.

**Trigger/purpose:** Build AI agents on Cloudflare Workers using the Agents SDK. Load when creating stateful agents, durable workflows, real-time WebSocket apps, scheduled tasks, MCP servers, chat applications, voice agents, or browser automation. Covers Agent class, state management, callable RPC, Workflows, durable execution, queues, retries, observability, and React hooks. Biases towards retrieval from Cloudflare docs over pre-trained knowledge.

**Contents:** Cloudflare Agents SDK; Retrieval Sources; Capabilities; FIRST: Verify Installation; Wrangler Configuration; Agent Class; Routing; Core APIs; React Client; References; Core; Chat & Streaming; Background Processing; Integrations; Experimental.

**Opening guidance (source excerpt):** Your knowledge of the Agents SDK may be outdated. **Prefer retrieval over pre-training** for any Agents SDK task.

**Resources:** references/ (19 files; metadata only).

## brainstorming

[S017] Source: `/Users/alexlobaito/.agents/skills/brainstorming/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `a32d2255354775aa124855aa7100cf276bea096fff4ebb3a0edf57be216e6c72`.

**Trigger/purpose:** You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.

**Contents:** Brainstorming Ideas Into Designs; Establish Shared Understanding; Three Paths; Anti-Pattern: "Too Simple To Need Approval"; Red Flags; Checklist; Process Flow; The Process; After the Design (architectural path); Visual Companion.

**Opening guidance (source excerpt):** Help turn ideas into fully formed designs and specs through natural collaborative dialogue.

**Procedure cues (source excerpts):** **Discover intent.** Use the request and available context to identify; **Write back your understanding.** Summarize the intended outcome,; **Carry intent into the design.** Preserve the agreed understanding in; **Explore project context** — enough to frame the probe; **Present question + probe plan** — 2-3 sentences

**Resources:** scripts/ (5 files; metadata only).

## ce-babysit-pr

[S021] Source: `/Users/alexlobaito/.agents/skills/ce-babysit-pr/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.623712+00:00. SHA-256: `532502a07fcd22e7f30f3efadb1bcde44ea5941d81d088a55af51763f6f506c1`.

**Trigger/purpose:** Use when asked to watch a PR over time — not for one-shot comment resolution or one CI failure. Babysits an open GitHub PR until merge-ready. GitHub (incl. Enterprise) only.

**Contents:** Babysit a PR; Posture (one value per run); Non-negotiable boundaries; Step 1: Resolve and arm; Step 2: One tick (ordering invariant); Step 3: Stop conditions; Step 4: Report.

**Opening guidance (source excerpt):** Keep an open PR moving toward merge by reacting to three streams as each arrives: review comments (handed to `ce-resolve-pr-feedback`), CI failures (handed to `ce-debug`), and branch-currency items the snapshot flags.

**Procedure cues (source excerpts):** `gh repo view` must succeed, else say GitHub-only, stop.; Resolve the PR from the argument or current branch (`references/setup.md`); none → report, stop.; Chain classification comes from the snapshot, never the user; resolve posture before semantic work.; **Checkout must be the PR's head branch with matching upstream** before any delegated mutation; default `gh pr checkout <ref>`; no push access or dirty checkout → stop, say so.; **Sustain mode** (`references/watch-loop.md`): Keep monitoring in the current session until a stop condition is met. Use checkpoint mode only when the user requests it or the harness cannot keep the session active while waiting for the watcher's output. The default self-sustaining in-session watch uses `pr-snapshot watch` and runs one tick per `BABYSIT_WAKE`; never collapse the loop into a script. In checkpoint mode, run one tick and report paused monitoring with the resume invocation from `references/setup.md`. **Pipeline** (`mode:pipeline`): bounded synchronous ticks, structured return (`references/pipeline.md`).

**Resources:** references/ (10 files; metadata only); scripts/ (1 files; metadata only).

## ce-bakeoff

[S022] Source: `/Users/alexlobaito/.agents/skills/ce-bakeoff/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.647434+00:00. SHA-256: `0d2d6aa85fbc4eea3f911956afe11966433e2034d0c5239727055eb02bed1121`.

**Trigger/purpose:** Use when choosing well requires developing alternatives beyond their current form. Develop independent competing solutions to a defined brief, compare them, and synthesize a winning approach. Use ce-pov to judge developed material and ce-ideate to discover opportunities.

**Contents:** Bake-off; Frame and authority; Announce and develop; Compare and select; Return.

**Opening guidance (source excerpt):** Develop concrete competing solutions and return the strongest coherent approach to the user or calling skill. You do the generation, comparison, selection, synthesis, and verification. The caller decides adoption and does the subsequent work. Done means at least two usable independent candidates received an independent assessment, the coordinator reconciled it with its own comparison, the final artifact was verified against evidence and the brief, and the complete decision reached its consumer; otherwise return an explicit incomplete or unresolved result. The purpose is exploration before commitment, not a larger option count.

**Resources:** references/ (4 files; metadata only).

## ce-brainstorm

[S023] Source: `/Users/alexlobaito/.agents/skills/ce-brainstorm/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.676758+00:00. SHA-256: `219d6025c011acbb33e2dd74c7c02dcb2f1c84636cd0ac36337f8b52380b511a`.

**Trigger/purpose:** Use when the user wants to brainstorm or scope what to build. Explore vague or ambitious ideas into a right-sized requirements-only unified plan. Not for executing already-specified work. Use ce-pov for a verdict on adopting a named external technology.

**Contents:** Brainstorm a Feature or Improvement; Artifact Root; Execution Flow.

**Opening guidance (source excerpt):** Brainstorming answers **WHAT** to build through dialogue; `ce-plan` then enriches the same unified plan artifact with **HOW**. This skill does not implement code. **The current year is 2026**, for dating the artifact.

**Resources:** references/ (21 files; metadata only); scripts/ (4 files; metadata only).

## ce-code-review

[S024] Source: `/Users/alexlobaito/.agents/skills/ce-code-review/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.705845+00:00. SHA-256: `05dc7f6aad2887ec83f566c20d3e880673f4b7b6b084de0b03f6bedfb07eeb75`.

**Trigger/purpose:** Use when asked to review code or when a shipping skill needs a review receipt. Review a named diff or PR for bugs, regressions, tests, and standards. Use when asked to apply this review's findings locally. Use ce-resolve-pr-feedback for feedback already left on a PR.

**Contents:** Code Review; Artifact Root; Execution spine; Operating principles.

**Opening guidance (source excerpt):** Help the caller deliver a correct change within the agreed scope. Find defects and improvements whose consequences justify action; judge the code against its intended behavior and project requirements, not a preferred rewrite. Serious defects remain important even when the diff is small. An adequate change needs no findings.

**Procedure cues (source excerpts):** Read `references/modes-and-output.md` first. It settles arguments, conflicts, the quick-review short-circuit, the Review depth gate, and what this invocation returns.; **Stage 1.** Read `references/scope.md` and resolve the reviewed diff, the scope mode, and the deterministic scope signals. Then apply that Review depth gate before Stage 2. Lite ends the run without the later spine references; lite and focused each run from this context by `references/depth-paths.md`.; **Stage 2.** Read `references/intent-and-plan.md`, write the intent summary every reviewer receives, and discover the plan Stage 6 verifies requirements against.; **Stage 3.** Read `references/persona-catalog.md` and `references/select-and-route.md`, then select the reviewers the change's risks call for, find the applicable standards files, and decide how the adversarial review will run.; **Stage 3d.** When adversarial is selected for a local reviewed tree, start and persist the sanctioned cross-model job that `references/cross-model-review.md` defines, **before any local persona dispatch**. Invoking this skill is itself the authorization for its configured or allowlisted peer route, once you have made the required disclosure of the recipient and of the code that leaves the machine. Do not ask the user to confirm a second time, and do not skip the peer because the user did not repeat that authorization. An explicit user prohibition on external review overrides it, as does a checkout that sets `cross_model_review_mode: off` with no live opt-in; both are resolved before you bind a route. A started peer replaces the local adversarial persona at this stage, and only a real failure to scope, allowlist, reach, authenticate, or start it leaves the local fallback in the roster; a later stage may still restore the local reviewer under the conditions that reference states.

**Resources:** references/ (33 files; metadata only); scripts/ (6 files; metadata only).

## ce-commit

[S025] Source: `/Users/alexlobaito/.agents/skills/ce-commit/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.723409+00:00. SHA-256: `1b1d39a65bec793e6f2e739d2f33e72ec8f5788e39f0ae531dde17119f782765`.

**Trigger/purpose:** Use when the user asks to commit/save staged or unstaged changes with a repo-appropriate message. Create a git commit with a clear, value-communicating message.

**Contents:** Git Commit; Context; Workflow.

**Opening guidance (source excerpt):** Create well-crafted local commit(s) from the current working tree. No push, no PR — use `ce-commit-push-pr` for the full ship flow.

**Procedure cues (source excerpts):** **Gather** — run every Context command above (own shell call each), then continue.; **Nothing to commit** — if `git status` shows no staged, modified, or untracked files, report that and stop. Do not use `git diff HEAD` alone as cleanliness (it misses untracked files).; **Branch first** — if detached HEAD, or on the default branch (`main` / `master` / the bare default name above), create a feature branch from the change content (`git checkout -b <name>`), then re-read `git branch --show-current`. Do not ask — commit-only still must not leave work only on a detached HEAD or the default branch. If the derived name exists, pick a non-conflicting suffix.; **Convention** — match project commit conventions already in context; else match the recent log pattern; else conventional commits (`type(scope): description`). When using conventional commits and `fix`/`feat` both fit, default to `fix:` (remedying broken or missing behavior); reserve `feat:` for new capabilities. User override wins.; **Logical commits** — if changed files clearly split into distinct concerns, make separate commits (file level only, 2–3 max, no `git add -p`). If ambiguous, one commit.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## ce-commit-push-pr

[S026] Source: `/Users/alexlobaito/.agents/skills/ce-commit-push-pr/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.741077+00:00. SHA-256: `cf7cd5a6a2d391089a542509b4a03ca3ac0ef699b2a707b6a99169362610f439`.

**Trigger/purpose:** Use when asked to ship/open a PR, or for PR-description-only flows like writing, rewriting, or describing a PR body. Commit, push, and open a PR.

**Contents:** Git Commit, Push, and PR; Mode; Stack mode (opt-in); Context; Artifact Root; Step 3: Commit and push; Step 4: Compose the PR title and body; Step 5: Apply and report.

**Opening guidance (source excerpt):** **Asking the user:** use the host's blocking question tool already in the current tool list (match by capability, not by a host-specific name). Presence in the current tool list is proof the tool exists; never call a user-facing question tool to discover whether it exists. If a matching tool is listed but unloaded, use the host's tool-discovery primitive to load that capability — do not search for another host's tool name. Fall back to asking in chat only when no such tool is in the list or a real question call errors, and never silently skip the question.

**Resources:** references/ (8 files; metadata only).

## ce-compound

[S027] Source: `/Users/alexlobaito/.agents/skills/ce-compound/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.759264+00:00. SHA-256: `951669e685c804a16138736c4bf132ee5f6ed9bbee3e3ccd5cbb096dd253b5d6`.

**Trigger/purpose:** Document a solved problem as a durable repo learning. Use when verified work produced non-obvious reasoning absent from its final code, tests, or existing docs; avoid routine fixes whose artifacts already explain the lesson.

**Contents:** /ce-compound; Preconditions; Mode Detection; Artifact Root; Write boundary; Choosing the path; Full Mode.

**Opening guidance (source excerpt):** **Outcome:** one qualifying solved problem is written as a durable learning under `<root>/solutions/`, grounded against the current tree, discoverable by the next agent.

**Procedure cues (source excerpts):** **Research** — read `references/research.md`.; **Session history** — read `references/session-history.md`, and start it *after* dispatching the Related Docs Finder so it overlaps your drafting rather than serializing. Session history is the final Phase 1 input, not a workflow stop. When it returns, including with "no relevant prior sessions", go straight to assembly without pausing or summarizing.; **Assembly and write** — wait for every Phase 1 input, then read `references/assembly.md`.; **Refresh check and discoverability** — read `references/refresh-and-discoverability.md`.; **Optional enhancement** — read `references/enhancement.md`. Interactive only.

**Resources:** references/ (19 files; metadata only); scripts/ (7 files; metadata only); assets/ (1 files; metadata only).

## ce-compound-refresh

[S028] Source: `/Users/alexlobaito/.agents/skills/ce-compound-refresh/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.785414+00:00. SHA-256: `4ff8ac72bb010d26336dbec3c6a8ece38cec603ed53bea409cb26dadd9e0e665`.

**Trigger/purpose:** Use when auditing stale, overlapping, superseded, or drifted learnings; avoid general refactor, debugging, or code review unless the learnings store is explicit. Refresh the repo's captured learnings against the current codebase.

**Contents:** Compound Refresh; Mode; Worth lens; Artifact Root; Scope; Investigate; Classify; Execute; Vocabulary Capture; Report; Commit; Discoverability Check.

**Opening guidance (source excerpt):** Audit the learnings under `<root>/solutions/` against the current codebase, apply the maintenance actions the evidence supports, and deliver a complete per-doc report plus committed changes. The report and the corrected document set are the deliverables. The store only compounds value if every doc can be trusted.

**Procedure cues (source excerpts):** Delete or shorten docs the codebase already explains. A doc goes when a test, a code comment, or the instructions file states the same reasoning, and every cut quotes that file. Drift is fixed too. Scope: <scope>.; Fix drift only. Stale paths and links, duplicate docs, and guidance the code no longer supports. Nothing accurate is deleted.

**Resources:** references/ (12 files; metadata only); scripts/ (2 files; metadata only); assets/ (1 files; metadata only).

## ce-debug

[S029] Source: `/Users/alexlobaito/.agents/skills/ce-debug/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.801759+00:00. SHA-256: `82540da83cbe42ff462a75557752b5f4313e5fe0fa89d5bb047c29eec6de5a80`.

**Trigger/purpose:** Diagnosis loop for bugs and failing behavior. Use when asked to debug or fix failing or slow behavior.

**Contents:** Debug and Fix; Mode; Blocking questions; Secrets in evidence; Artifact Root; Execution Flow; Phase 2 gate: present, then ask; Phase 3: Fix; Phase 4: Handoff; Debug Summary; Routing.

**Opening guidance (source excerpt):** Find the root cause of a failure, then — when the user chooses to — fix it with test-first discipline.

**Procedure cues (source excerpts):** **Fix it now** — proceed to Phase 3; **Diagnosis only — I'll take it from here** — skip the fix, write Phase 4's summary, end the skill; **Rethink the design** (`ce-brainstorm`) — only when the bug cannot be fixed within the current design: the root cause is a wrong responsibility or interface rather than wrong logic, the requirements themselves are wrong, or every candidate fix is a workaround around an assumption that no longer holds. Size alone is not a design problem.

**Resources:** references/ (8 files; metadata only).

## ce-doc-review

[S030] Source: `/Users/alexlobaito/.agents/skills/ce-doc-review/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.825564+00:00. SHA-256: `ad949ba02994edcf33942814b743a6f2efc2eeb4229219046b57624f8c821c1e`.

**Trigger/purpose:** Use when the user wants to improve an existing planning document. Review requirements, plans, or specs with role-specific lenses.

**Contents:** Document Review; Interactive mode rules; Artifact Root; Phase 1: Get and Analyze Document; Phase 2: Announce and Dispatch Personas; Cross-Model Judgment Pass; Phases 3-5: Synthesis, Presentation, and Next Action.

**Opening guidance (source excerpt):** Help the author finish a sound document they can use to carry out the agreed work. Find problems that would change that work's outcome or materially hinder execution, and resolve them within the authority already given. Judge the document by whether it guides correct work, not by how much detail it contains. Serious consequences warrant attention even when the defect is small. An adequate document needs no changes.

**Resources:** references/ (22 files; metadata only); scripts/ (3 files; metadata only).

## ce-explain

[S031] Source: `/Users/alexlobaito/.agents/skills/ce-explain/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.845332+00:00. SHA-256: `5ccecd7fddc68447df69a5da0e8282e4a053d9c2712a689d1ba8dd3c74936e9a`.

**Trigger/purpose:** Use when the user asks for an explanation. Explain how and why something has its current shape, or what happened over a window of work, grounded in evidence. Use ce-pov for a judgment or recommendation.

**Contents:** Explain How and Why; Consumer and interaction; Artifact Root; Execution Flow; Phase 1: Establish the question and use; Phase 2: Ground; Phase 3: Compose the explanation; Phase 4: Deliver; Boundaries.

**Opening guidance (source excerpt):** Produce an explanation that answers the scoped question and gives its consumer enough understanding for the intended use. The subject and purpose come from the request and available context, whether a person or another workflow supplied them. Ground project behavior in source evidence; distinguish documented rationale, inference, and unknowns.

**Resources:** references/ (8 files; metadata only).

## ce-handoff

[S032] Source: `/Users/alexlobaito/.agents/skills/ce-handoff/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.861327+00:00. SHA-256: `3fb19a18d8ee00594254d8b495da51c6847563ce23124e8639edc8953f1c62bb`.

**Trigger/purpose:** Create a session handoff for another agent, or resume, find, and read any user-selected continuity source. Use when work or conversation must continue without access to the current session history.

**Contents:** Handoff; Route the invocation; Create; Resume.

**Opening guidance (source excerpt):** Preserve enough session context for a fresh agent to orient quickly, then keep the user in control of what happens next.

**Resources:** references/ (2 files; metadata only).

## ce-noslop

[S033] Source: `/Users/alexlobaito/.agents/skills/ce-noslop/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.879299+00:00. SHA-256: `aa94199578b283ef387b6fd7d8f70c116894f357407f922112116edecaf0a0cd`.

**Trigger/purpose:** Use when asked to make writing plainer or free of those tells, to check writing for them, or when drafting from supplied content. Rewrite, check, or draft prose so it carries no AI writing tells, reads plainly on the first read, and keeps every source fact. Use ce-promote for channel-specific marketing copy.

**Contents:** Write without slop; Mode; Register; The tests.

**Opening guidance (source excerpt):** Prose that carries no AI tells and that a reader understands on the first read, with every fact the source stated still there. Both goals hold at once: text that is free of tells but still dense has failed, and text that is plain but drops a qualifier has failed.

**Procedure cues (source excerpts):** **Mechanism.** Does the sentence say what the thing does, or how it feels? Replace the feeling with the fact it displaced, or cut the sentence.; **Portability.** Could the sentence move to another project unchanged? Then it carries no fact about this one.; **Actor.** Who does the verb? Name them when the source says who. Keep the passive when the actor is unknown or naming it adds nothing.; **One idea.** Would the reader have to reread to hold the sentence? Split it. A sentence the reader gets on the first pass stays, however long.; **Density.** One device proves nothing. Three or more distinct patterns in a passage, or one repeated across passages, is a finding.

**Resources:** references/ (2 files; metadata only).

## ce-plan

[S034] Source: `/Users/alexlobaito/.agents/skills/ce-plan/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.897505+00:00. SHA-256: `6c5842bfc91a9aad65fcdf83669f86ef499a9b40dc99f9340c5981d2bc6f1720`.

**Trigger/purpose:** Create structured plans for multi-step work, including software and non-software tasks. Use when asked to plan, break down implementation, plan from requirements, or deepen an existing plan; prefer ce-brainstorm for exploratory framing.

**Contents:** Create Technical Plan; Mandatory Completion Contract; Interaction Method; Output Contract; Workflow; Phase 0: Output, Resume, and Scope; Phases 1-4: Research and Compose; Phase 5: Review, Write, Deepen, and Hand Off.

**Opening guidance (source excerpt):** **The current year is 2026.**

**Procedure cues (source excerpts):** **Output first.** Read `references/output-mode.md` before interpreting any phase. It defines token parsing, output and confirmation precedence, renderer selection, artifact location, and when a repository may be resolved.; **Resume, deepen, approach, and domain.** Read `references/resume.md` before acting. It defines resuming an existing plan, enriching a requirements-only plan, deepening, approach-level planning, and the software/non-software split. Follow any terminal route it selects; otherwise continue.; **Source and scope.** Read `references/intake.md` before Phase 0.2 and follow it through Phase 0.7. It defines finding and preserving the upstream artifact, routing out to bootstrap work, blocking questions, depth, named resources, and the scoping synthesis; the Output Contract decision above happens inside it. Do not pass a decision point that has not resolved.; Read `references/research.md` before gathering context.; Read `references/structure.md` before resolving questions or structuring the plan.

**Resources:** references/ (32 files; metadata only); scripts/ (3 files; metadata only).

## ce-pov

[S035] Source: `/Users/alexlobaito/.agents/skills/ce-pov/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.923786+00:00. SHA-256: `7547de4749bcbf92183ab1b4c523f7b87051a7cd07bb05343fb9cdeb96ca168c`.

**Trigger/purpose:** Use when assessing an external-adoption question, a holistic take on a document, or a supplied approach set. Judge a supplied subject against the project's evidence and constraints. Use for an oracle panel to consult other models and reconcile their opinions. Use ce-explain for understanding and ce-doc-review for findings review.

**Contents:** Form a Point of View; Grounding is not optional; Consumer and interaction; Identify the question and return the result; Artifact Root; Phase 0: Frame and Classify; Phase 1: Ground; Phase 2: Verify Grounding; Phase 3: Point of View; Phase 4: Deliver and return.

**Opening guidance (source excerpt):** Produce a decisive, project-grounded point of view in the subject's own shape: a **graded verdict** on an external-adoption question, a **holistic take** on a document, or a **position** on a supplied approach set. The subject is whatever this skill was invoked with, in the prompt or the conversation. Stay read-only while forming and reconciling the POV. You are done when the POV is delivered with its attribution and required disclosure, or when an explicit blocker is returned. Use `ce-bakeoff` to develop competing solutions, `ce-ideate` to explore opportunities, or `ce-brainstorm` to establish goals. **The year is 2026**, for source recency.

**Resources:** references/ (13 files; metadata only); scripts/ (2 files; metadata only).

## ce-proof

[S036] Source: `/Users/alexlobaito/.agents/skills/ce-proof/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.939841+00:00. SHA-256: `248ca0619d9686cc60d79445853a2d64f19ec0bf4e8a6fa46976d99dff9060c7`.

**Trigger/purpose:** Use for Proof links, sharing specs/plans/drafts, or publish handoffs from planning workflows; avoid proofread, math, evidence, or proof-of-concept meanings. Publish, read, comment on, or edit markdown in Proof.

**Contents:** Proof - Collaborative Markdown Editor; Identity; Credentials and boundaries; Publish mode; Editing.

**Opening guidance (source excerpt):** Proof is a collaborative document editor for humans and agents. It is reached through the hosted web API at `https://www.proofeditor.ai`, over HTTP from `Bash`.

**Resources:** references/ (2 files; metadata only).

## ce-prototype

[S037] Source: `/Users/alexlobaito/.agents/skills/ce-prototype/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.957726+00:00. SHA-256: `87c6b245e33b680db24092ae936eb74e295b2cb5ca74deaabbda2b62e26f30b4`.

**Trigger/purpose:** Use when committing the wrong answer would be expensive to unravel and a cheap sketch cannot settle it. Build a throwaway prototype to answer how something should work, feel, or read. Not a rough visual probe during brainstorming, not for deciding what to build, not polishing a feature that already works, not implementing the real thing.

**Contents:** Prototype; Scope the question; Build it; Keep the decisions; Apply or continue.

**Opening guidance (source excerpt):** Build a throwaway prototype at the fidelity that can answer this question, before committing an approach later work will treat as given. Then apply the decisions or hand off.

**Resources:** references/ (6 files; metadata only); scripts/ (1 files; metadata only); assets/ (2 files; metadata only).

## ce-resolve-pr-feedback

[S038] Source: `/Users/alexlobaito/.agents/skills/ce-resolve-pr-feedback/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.975304+00:00. SHA-256: `ec00ba4e6b8bc0cea43f80d6306eff948720d122060ab51968ade1d439e1ada1`.

**Trigger/purpose:** Use when addressing feedback already left on a PR. Resolve PR review feedback. Not for reviewing the code before feedback exists; that is ce-code-review.

**Contents:** Resolve PR Review Feedback; Security; Platform; Mode Detection; Success Criteria.

**Opening guidance (source excerpt):** Evaluate and fix PR review feedback, then reply and resolve threads. You, as the orchestrator, judge every item centrally, deciding whether each one is legitimate. Then you dispatch generic subagents, each seeded with the fixer prompt bundled in this skill, only for the items you approved for a fix.

**Resources:** references/ (5 files; metadata only); scripts/ (4 files; metadata only).

## ce-setup

[S039] Source: `/Users/alexlobaito/.agents/skills/ce-setup/SKILL.md`; kind: canonical. Modified UTC: 2026-10-06T11:44:36.377577+00:00. SHA-256: `e0a785b8623a2cbf2714b1300ffb09111fd26d26adc11790df4bf2d8037be72d`.

**Trigger/purpose:** Check Compound Engineering health and repo-local config, or scaffold a Compound Pack with `pack:<id>`.

**Contents:** Compound Engineering Setup; Interaction Method; Pack Scaffold; Artifact Root Resolution; Phase 1: Diagnose; Step 1: Determine Plugin Version; Step 2: Run the Health Check; Step 3: Decide Whether Fixes Are Needed; Phase 2: Fix Repo-Local Issues; Phase 3: Summary.

**Opening guidance (source excerpt):** Ask each question below using the host's blocking question tool already in the current tool list (match by capability, not by a host-specific name). Presence in the current tool list is proof the tool exists; never call a user-facing question tool to discover whether it exists. If a matching tool is listed but unloaded, use the host's tool-discovery primitive to load that capability — do not search for another host's tool name. Fall back to a numbered list on the host's user-visible chat surface only when no such tool is in the list or a real question call errors. Never silently skip or auto-configure.

**Resources:** references/ (4 files; metadata only); scripts/ (2 files; metadata only); assets/ (3 files; metadata only).

## ce-simplify-code

[S040] Source: `/Users/alexlobaito/.agents/skills/ce-simplify-code/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:02.991217+00:00. SHA-256: `136e1ea946b99f5397c265f98da088aad823c3f111ec89fa982f67f97685dfbc`.

**Trigger/purpose:** Use after implementation and before review; use ce-debug for bugs. Simplify settled, recently changed code for clarity, reuse, quality, and efficiency while preserving behavior.

**Contents:** Step 1: Identify scope; Step 2: Launch 3 review agents in parallel; Step 3: Fix issues; Step 4: Verify behavior is preserved; Step 5: Summarize.

**Opening guidance (source excerpt):** Simplify recently changed code for clarity, reuse, quality, and efficiency while preserving exact behavior. Prioritize readable, explicit code over compact code — fewer lines is not the goal.

**Procedure cues (source excerpts):** **User-named scope** is authoritative; do not widen it.; **Otherwise, in git**, use the current branch versus its base. Without a usable base, use staged and unstaged changes (`git diff HEAD`).; **Outside git or without a diff**, use files the user named or that were edited earlier in the conversation.

**Resources:** references/ (3 files; metadata only).

## ce-test-browser

[S041] Source: `/Users/alexlobaito/.agents/skills/ce-test-browser/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.006572+00:00. SHA-256: `9bd5b20025f0c7f01d0946eadf34f520241fefe5328bae43e807c048a7302cc2`.

**Trigger/purpose:** Use when asked to run or check browser tests for the current change. Run browser tests for pages affected by the current branch or PR.

**Contents:** Browser Test Skill; Modes; Browser Driver Policy; Workflow; Driver Reference.

**Opening guidance (source excerpt):** Run end-to-end browser tests on pages affected by a PR or branch using the best approved browser driver available in the active harness.

**Procedure cues (source excerpts):** **Prefer a host-native integrated browser.** Use a browser-control surface embedded in or directly owned by the active harness when it can navigate local URLs, inspect rendered and interactive state, click/fill/press, capture screenshots, and inspect console errors. A separately configured browser extension or integration is not host-native. Load and follow the selected capability's own instructions before browser work.; **Otherwise fall back to `agent-browser`.** Read `references/agent-browser-driver.md` before running any command.; **Do not introduce a third browser stack.** Never install or substitute standalone Playwright, Puppeteer, a separately configured browser extension or MCP, or other ad hoc browser automation. A Playwright API exposed inside the selected host-native browser remains host-native; it is not standalone Playwright.; **Select the driver** per the policy above and record it. This also requires a git repository with changes to test.; **Determine test scope** from the argument: a PR number → `gh pr view [number] --json files -q '.files[].path'`; `current` or empty → `git diff --name-only main...HEAD`; a branch name → `git diff --name-only main...[branch]`.

**Resources:** references/ (3 files; metadata only); scripts/ (1 files; metadata only).

## ce-work

[S042] Source: `/Users/alexlobaito/.agents/skills/ce-work/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.023467+00:00. SHA-256: `c9b392620e8ae856882cd5a493b1f0e5941aa06935a73578846e703e0f00ce00`.

**Trigger/purpose:** Execute a plan or concrete work prompt end-to-end. Use when implementing from a plan document, a spec path, or a clear build request; use ce-debug for open-ended bugs. Use when an outer orchestrator needs implementation and local verification only, without the shipping tail.

**Contents:** Work Execution Command; Outcome; Execution Workflow; Phase 0: Input Triage; Phase 1: Quick Start; Phase 2: Execute; Phase 3-4: Quality Check and Finishing Work; Return-to-Caller Mode.

**Opening guidance (source excerpt):** - **Result:** A fully implemented, locally verified change set from a plan, specification, or concrete work prompt. - **Next consumer:** In standalone use, the shipping workflow takes the verified change through review and delivery. In Return-to-Caller Mode, the invoking workflow receives the structured implementation and verification result and owns its remaining gates. - **Done:** Every in-scope task is complete, required verification evidence is recorded, relevant checks pass, and the run reaches either its owned shipping handoff (with a code-review receipt or explicit skip phrase — see Phase 3-4), a complete return result, or an explicit 

**Procedure cues (source excerpts):** **Establish the workspace.** Before moving branches, editing, dispatching, or committing, read `references/workspace-setup.md`. It decides the writable checkout, plan clarification, branch placement, the pre-work inventory, already-dirty files, and task setup. Never write without a writable canonical checkout, and never write on the real default branch unless the user explicitly directed that in this session.; **Resolve the engine, then strategy.** After bounded plan intake and task derivation, but before selecting a unit for execution, writing, dispatching, or committing, read `references/execution-engines.md` and complete its route selection. It applies with or without a typed binding; native execution is eligible only when that reference selects it or exhausts an allowed fallback. The engine choice never changes which reference governs how the run ends.

**Resources:** references/ (15 files; metadata only); scripts/ (9 files; metadata only).

## ce-worktree

[S043] Source: `/Users/alexlobaito/.agents/skills/ce-worktree/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.045044+00:00. SHA-256: `49f16d5ed409e300c17154f7ec126d34290fec91e1572ef8141521a81a90a5ae`.

**Trigger/purpose:** Use when starting isolated work or isolating an existing ref. Set up isolated git worktrees — create a new branch for fresh work, or attach a worktree to an existing branch, PR, or commit.

**Contents:** Worktree Isolation; Step 0: Detect existing isolation; Step 1: Prefer the harness's native worktree tool; Step 2: Git fallback.

**Opening guidance (source excerpt):** Ensure the current work happens in an isolated workspace, without disturbing the user's main checkout. Most coding harnesses now create a worktree by default at session start, so the common case is that **isolation already exists**.

**Procedure cues (source excerpts):** **Run from the repo root:** `cd "$(git rev-parse --show-toplevel)"`. The paths below are repo-root-relative, but the skill runs from the user's current directory — without this, `.worktrees/<branch>` and the `.gitignore` edit land in a subdirectory (e.g. `src/.worktrees/...`).; Choose a meaningful branch name from the work description (e.g. `feat/login`, `fix/email-validation`) — never an opaque auto-generated one. Base: origin's default branch, else `main`.; **Ensure `.worktrees/` is gitignored before creating anything:** `git check-ignore -q .worktrees/` — **with the trailing slash**, so an existing directory-only `.worktrees/` rule is honored even before the directory exists (without the slash the probe misses it and dirties a correctly-configured repo). Not ignored -> add a `.worktrees/` line to `.gitignore`.; Refresh the base with `git fetch origin <from-branch>`. This is **non-fatal** — no `origin` remote, a differently-named remote, or a local-only branch is not an abort; continue with the local ref.; Create the worktree, per mode:

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## dispatching-parallel-agents

[S064] Source: `/Users/alexlobaito/.agents/skills/dispatching-parallel-agents/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `1968923066f3b707eb01d1992cdf4c42284c3855f70253b9cd5000ff45fca13c`.

**Trigger/purpose:** Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies

**Contents:** Dispatching Parallel Agents; Overview; When to Use; The Pattern; 1. Identify Independent Domains; 2. Create Focused Agent Tasks; 3. Dispatch in Parallel; All three run concurrently.; 4. Review and Integrate; Agent Prompt Structure; Common Mistakes; When NOT to Use; Real Example from Session; Verification.

**Opening guidance (source excerpt):** You delegate tasks to specialized agents with isolated context. By precisely crafting their instructions and context, you ensure they stay focused and succeed at their task. They should never inherit your session's context or history — you construct exactly what they need. This also preserves your own context for coordination work.

**Procedure cues (source excerpts):** **Focused** - One clear problem domain; **Self-contained** - All context needed to understand the problem; **Specific about output** - What should the agent return?; "should abort tool with partial output capture" - expects 'interrupted at' in message; "should handle mixed completed and aborted tools" - fast tool aborted instead of completed

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## executing-plans

[S074] Source: `/Users/alexlobaito/.agents/skills/executing-plans/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.048792+00:00. SHA-256: `fda988f826ca0f49a39f92699681c7a62a4347abb56ed217fa530bf24a67b1aa`.

**Trigger/purpose:** Use when executing an implementation plan in the current session as the implementer yourself — your human partner chose inline execution, or no subagent tool is available

**Contents:** Executing Plans; When to Use; The Process; Setup; The Task Loop; 1. Take the task; 2. Work the steps; 3. The completion contract; 4. Complete the task; Final Review; Finish; Common Rationalizations; Example Workflow.

**Opening guidance (source excerpt):** Execute the plan yourself, task by task, in this session: no implementer subagent per task, no reviewer per task. One fresh-context review of the whole branch at the end.

**Resources:** scripts/ (2 files; metadata only).

## fan-out

[S077] Source: `/Users/alexlobaito/.agents/skills/fan-out/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T19:47:28.326964+00:00. SHA-256: `d107cac34660cdc71da6337251ccf6fbd7e63c1278bc71dd5761afaefc4ebf66`.

**Trigger/purpose:** Use when work splits into 3 or more independent read-only parts, like researching many companies or summarizing many files. Briefs 3 to 5 subagents and merges their notes.

**Contents:** fan-out; First, decide whether to fan out; Steps; Budgets; Gotchas.

**Opening guidance (source excerpt):** Runs independent parts of a job in parallel, each in its own subagent, and merges the results into one deliverable written by you alone.

**Procedure cues (source excerpts):** **Check the job folder.** `work/<job>/brief.md` exists and has a goal and "done means".; **Split by context, not by role.** Each part is a slice of the material that one agent can; **Size the team.** 3 to 5 subagents, never more than 8. Three focused subagents often; **Write one brief per subagent** from; **Assign files.** Each subagent writes only `work/<job>/notes/<part-name>.md`. No two

**Resources:** references/ (1 files; metadata only).

## finishing-a-development-branch

[S079] Source: `/Users/alexlobaito/.agents/skills/finishing-a-development-branch/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `8db5a922b242dd4e1bf824cb91c13b3e8d8e8a86d6ceaf7f0774eb9cce909d65`.

**Trigger/purpose:** Use when implementation is complete, all tests pass, and you need to decide how to integrate the work

**Contents:** Finishing a Development Branch; Overview; Step 1: Verify Tests; Step 2: Detect Environment; Capture now, while still inside the workspace — Step 5 changes directory; before cleanup (Step 6) needs this value; Step 3: Determine Base Branch; Step 4: Present Options; Step 5: Execute Choice; Option 1: Merge Locally; Get main repo root for CWD safety; Merge first — verify success before removing anything; Verify tests on merged result; Option 2: Push and Create PR; From a detached HEAD, name the new branch on the remote:; git push origin HEAD:refs/heads/<new-branch>; Option 3: Keep As-Is; If your human partner asks to discard the work; Step 6: Cleanup Workspace; Quick Reference; Common Rationalizations.

**Opening guidance (source excerpt):** **Core principle:** Verify tests → Detect environment → Present options → Execute choice → Clean up.

**Procedure cues (source excerpts):** Merge back to <base-branch> locally; Push and create a Pull Request; Keep the branch as-is (I'll handle it later); Push as new branch and create a Pull Request; Keep as-is (I'll handle it later)

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## requesting-code-review

[S134] Source: `/Users/alexlobaito/.agents/skills/requesting-code-review/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `cfcee1b06774e7c0517f1e09be1a11f2d5680257072723e709ddbcf7e08b795a`.

**Trigger/purpose:** Use when completing tasks, implementing major features, or before merging to verify work meets requirements

**Contents:** Requesting Code Review; When to Request Review; How to Request; Example; Common Rationalizations; Red Flags.

**Opening guidance (source excerpt):** Dispatch a code reviewer subagent to catch issues before they cascade. The reviewer gets precisely crafted context for evaluation — never your session's history.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## subagent-driven-development

[S152] Source: `/Users/alexlobaito/.agents/skills/subagent-driven-development/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.073899+00:00. SHA-256: `b8dcb953234326f2d0796336f98bfe7f42e212b5fb2655523bed0532a6750e41`.

**Trigger/purpose:** Use when executing implementation plans with independent tasks in the current session

**Contents:** Subagent-Driven Development; When to Use; The Process; Setup; Model Selection; The Task Loop; 1. Dispatch the implementer; 2. Handle the report; 3. Review the task; 4. The fix loop; 5. Complete the task; Final Review; Finish; Common Rationalizations; Example Workflow.

**Opening guidance (source excerpt):** Execute plan by dispatching a fresh implementer subagent per task, a task review (spec compliance + code quality) after each, and a broad whole-branch review at the end.

**Procedure cues (source excerpts):** If it's a context problem, provide more context and re-dispatch with the same model; If the task requires more reasoning, re-dispatch with a more capable model; If the task is too large, break it into smaller pieces; If the plan itself is wrong, rule on the correction, ledger it, and re-dispatch with the ruling carried in the dispatch

**Resources:** scripts/ (3 files; metadata only).

## systematic-debugging

[S153] Source: `/Users/alexlobaito/.agents/skills/systematic-debugging/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.079024+00:00. SHA-256: `df3f6451b43f4b5115b4599e17ece202fe8d8283f1ff5a40a6584ad2e44710fe`.

**Trigger/purpose:** Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes

**Contents:** Systematic Debugging; Overview; The Iron Law; When to Use; The Four Phases; Phase 1: Root Cause Investigation; Phase 2: Pattern Analysis; Phase 3: Hypothesis and Testing; Phase 4: Implementation; Red Flags - STOP and Follow Process; your human partner's Signals You're Doing It Wrong; Common Rationalizations; Quick Reference; When Process Reveals "No Root Cause"; Supporting Techniques.

**Opening guidance (source excerpt):** **Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

**Procedure cues (source excerpts):** **Read Error Messages Carefully**; **Reproduce Consistently**; **Check Recent Changes**; **Gather Evidence in Multi-Component Systems**; **Trace Data Flow**

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## test-driven-development

[S156] Source: `/Users/alexlobaito/.agents/skills/test-driven-development/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `64b03fce4aee5a97a93160cea8111f3ba13a17b7c001db4bd5836d67fd10705d`.

**Trigger/purpose:** Use when implementing any feature or bugfix, before writing implementation code

**Contents:** Test-Driven Development (TDD); Overview; When to Use; The Iron Law; Red-Green-Refactor; RED - Write Failing Test; Verify RED - Watch It Fail; GREEN - Minimal Code; Verify GREEN - Watch It Pass; REFACTOR - Clean Up; Repeat; Good Tests; Common Rationalizations; Red Flags - STOP and Start Over; Example: Bug Fix; Verification Checklist; When Stuck; Debugging Integration; Final Rule.

**Opening guidance (source excerpt):** Write the test first. Watch it fail. Write minimal code to pass.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## using-git-worktrees

[S162] Source: `/Users/alexlobaito/.agents/skills/using-git-worktrees/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `8cfb86f121269e8f7f12361e6795c4f6738828340e28964c9229d365666c9edd`.

**Trigger/purpose:** Use when starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace exists via native tools or git worktree fallback

**Contents:** Using Git Worktrees; Overview; Step 0: Detect Existing Isolation; If this returns a path, you're in a submodule, not a worktree — treat as normal repo; Step 1: Create Isolated Workspace; 1a. Native Worktree Tools (preferred); 1b. Git Worktree Fallback; Directory Selection; Safety Verification (project-local directories only); Create the Worktree; Determine path based on chosen location; Step 2: Project Setup; Node.js; Rust; Python; Go; Step 3: Verify Clean Baseline; Use project-appropriate command; Report; Quick Reference; Common Rationalizations.

**Opening guidance (source excerpt):** Ensure work happens in an isolated workspace. Prefer your platform's native worktree tools. Fall back to manual git worktrees only when no native tool is available.

**Procedure cues (source excerpts):** **Check your instructions for a declared worktree directory preference.** If the user has already specified one, use it without asking.; **Check for an existing project-local worktree directory:**; **If there is no other guidance available**, default to `.worktrees/` at the project root.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## verification-before-completion

[S163] Source: `/Users/alexlobaito/.agents/skills/verification-before-completion/SKILL.md`; kind: canonical. Modified UTC: 1970-01-01T00:00:01+00:00. SHA-256: `2befe7fc55bcadaa3d97dd9e8efeb633d2561c0ebe74c5a8b17c4d9e7e4520b3`.

**Trigger/purpose:** Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always

**Contents:** Verification Before Completion; Overview; The Iron Law; The Gate Function; Common Failures; Red Flags - STOP; Rationalization Prevention; Key Patterns; When To Apply.

**Opening guidance (source excerpt):** **Core principle:** Evidence before claims, always.

**Procedure cues (source excerpts):** IDENTIFY: What command proves this claim?; RUN: Execute the FULL command (fresh, complete); READ: Full output, check exit code, count failures; VERIFY: Does output confirm the claim?; ONLY THEN: Make the claim

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..

## verify-before-done

[S164] Source: `/Users/alexlobaito/.agents/skills/verify-before-done/SKILL.md`; kind: canonical. Modified UTC: 2026-10-06T09:04:18.090574+00:00. SHA-256: `bf30a7ad6b86796273f475658b8faedb50e654d80a327efc3645f993457f81e1`.

**Trigger/purpose:** Use when a task is about to be called done, sent to anyone or published. Checks the work against its brief, sources and numbers, with one negative check, and records the result.

**Contents:** verify-before-done; Steps; Before a send or publish; Gotchas.

**Opening guidance (source excerpt):** Proves the work matches its brief before anyone calls it done. Agents judge their own work too kindly: in one study on coding tasks they predicted 73 to 77% success when 22 to 35% was real. So the checks here are concrete, and high-stakes work gets a fresh checker.

**Procedure cues (source excerpts):** **Re-read `work/<job>/brief.md`**: goal, "done means", facts allowed, stakes.; **Size the checks to the stakes.**; **Run the checks that apply.**; **Run one negative check**: something that should fail if the work were wrong. Examples:; **High stakes: hand it to a fresh subagent verifier.** Give it only `work/<job>/brief.md`, the

**Resources:** scripts/ (1 files; metadata only).

## writing-plans

[S173] Source: `/Users/alexlobaito/.agents/skills/writing-plans/SKILL.md`; kind: canonical. Modified UTC: 2026-10-01T20:12:03.084606+00:00. SHA-256: `6d476f62d4c961a363e96ef25da05d3305405362e93e011cd37743e5eb8054a3`.

**Trigger/purpose:** Use when you have a spec or requirements for a multi-step task, before touching code

**Contents:** Writing Plans; Overview; Scope Check; File Structure; Task Right-Sizing; Step Granularity; Plan Document Header; [Feature Name] Implementation Plan; Global Constraints; Review Focus; Task Structure; Task N: [Component Name]; What a Step Contains; Self-Review; Execution Handoff.

**Opening guidance (source excerpt):** Write implementation plans for an engineer who has not seen this codebase or this spec. Assume they write idiomatic code in the project's language once they know the exact interface and the exact test, and that they will make a reasonable choice wherever the plan leaves one open. What they cannot know is what you decided: which files, which names and signatures, which values from the spec, which tests prove each task. Document those. Give them the whole plan as bite-sized tasks. DRY. YAGNI. TDD. Frequent commits.

**Resources:** No references/scripts/templates/examples/assets subdirectories observed..
