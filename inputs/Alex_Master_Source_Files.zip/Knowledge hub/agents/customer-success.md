# CSM — Customer onboarding, health and delivery follow-through

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Handles one explicitly assigned increase_roas customer, separating procedure from provider facts. Produces an onboarding or issue brief with actual owner, next action, supported deadline and evidence, then hands to Ops/Javar. Does not infer promises from templates. [Source set: E13, E14, E15, E16]

## Computer, workspace and Hermes identity

No active computer/home/profile mapping is proven by the four maintained sources. Binding/runtime JSON are placeholders (`EXAMPLE_NOT_LIVE`) and must not become identity facts. October 6 inventory lists CSM workspace `6cda999c-708e-4121-8531-383640f97290` and SPARE-CSM computer `7cedbb4b-0610-4241-907e-edc19b45cf57`; no Hermes home was found in two checked locations. This establishes inventory membership, not current CSM placement. [Source set: E13, E14, E15, E16; inventory: E4]

## Setup, start and recovery pointers

csm/README directs reuse through the shared materializer, isolated home and independently verified fields. Its current-state preface says later CSM pilot/coordinated evidence supersedes initial non-live/blank-host statements and points to Build/docs/PRIVATE-MATERIAL.md anchors a02 and p07. Those linked private records are not included here. [Source set: E13, E14, E15, E16]

## Tools and skills pointers

Role tools must bind read-only provider/customer and RAG scopes separately; generated foundation alone supplies local tasks/reminders. Binding template names scope increase_roas. Runtime example describes fields and named-file references only, not actual installed configuration. [Source set: E13, E14, E15, E16]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

The maintained README reports later accepted pilot evidence. The runtime example says one customer-issue intake and durable handoff accepted while the complaint remained unresolved; because it is EXAMPLE_NOT_LIVE this is not an independent runtime receipt. No current customer facts were read. [Source set: E13, E14, E15, E16; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Actual host, Hermes account/profile, owner DM, Slack identity, live tool bindings and present pilot health require private current evidence. Do not equate the spare or synthetic model settings with the serving CSM agent. [Source set: E13, E14, E15, E16; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E13] [csm/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/README.md) — modified `2026-09-14T18:58:47.228905+00:00`; source SHA-256 `649a12f2e9dcc437ba6deec2dd583a2cdfa19eb6a50dfe32f8ae0e3d0b587b12`.
- [E14] [csm/SOUL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/SOUL.md) — modified `2026-09-14T18:58:47.229085+00:00`; source SHA-256 `c966a5b0738798c347e533f8e0f6f5c5858a89e04d6222b8b4c9b8b41edf9fdc`.
- [E15] [csm/binding.template.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/binding.template.json) — modified `2026-09-14T18:53:47.718899+00:00`; source SHA-256 `3d9798610ff0748746343d1caf75520dc7db2279f4874469c81d5815bfc977d9`.
- [E16] [csm/runtime-config.example.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/runtime-config.example.json) — modified `2026-09-14T19:00:00.036682+00:00`; source SHA-256 `3f40bddb25f9066df2d225fce161f8aa059c3ee87133ab31475cb02deca76155`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1Bs1yXS5x8FU8WwYXvUFL_sGlwSirFcYC). Folder link is a recorded pointer, not current access proof.
