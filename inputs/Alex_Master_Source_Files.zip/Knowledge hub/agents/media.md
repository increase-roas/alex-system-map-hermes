# Media — Advertising analysis and creative briefs

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Analyzes scoped advertising performance and creative lineage; produces cited decisions and briefs with period, customer scope, assumptions and approval status. Read/draft/propose is the documented first slice; a draft does not prove performance improvement. [Source set: E17, E18, E19, E20, E21]

## Computer, workspace and Hermes identity

No active home/profile/computer binding is proven by these five source files. Examples are EXAMPLE_NOT_LIVE with synthetic customer identifiers. October 6 inventory lists Media workspace `d4e5f8db-c4c1-4727-8fc0-c876a4602e52` and SPARE-Media computer `c8aed3e5-6228-449e-b744-9d02466669c1`; no Hermes home was found in two checked locations. Spare metadata does not establish current Media runtime placement. [Source set: E17, E18, E19, E20, E21; inventory: E4]

## Setup, start and recovery pointers

media/README points to `source-plan.json` and the team materializer. Its current-state preface says later deliverable/coordinated evidence supersedes initial non-live statements, pointing to Build/docs/PRIVATE-MATERIAL.md#p07 and current Notion registry. Exact active recovery receipt/home remains outside this source set. [Source set: E17, E18, E19, E20, E21]

## Tools and skills pointers

read-plugin/README documents a fail-closed, scoped candidate exposing Meta campaigns/insights, pinned-contact GHL reads and customer RAG queries. customer-scope.example distinguishes customer and provider timezones and disallows writes. Binding placeholders require independent verification before any activation. [Source set: E17, E18, E19, E20, E21]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

SOUL documents an accepted read-only Martinez Meta/GHL evidence, reference retrieval and decision/brief slice. This is dated source reporting; underlying current runtime/provider receipts were not read. Image generation, publication and broader customer scope remain unproven in that source. [Source set: E17, E18, E19, E20, E21; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Exact live role identity, customer/provider/RAG bindings and tool registration remain unknown. customer-scope.example was read from its checksum-verified archived bytes after maintained-file reading stalled; see coverage. No customer performance or current access was checked. [Source set: E17, E18, E19, E20, E21; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E17] [media/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/README.md) — modified `2026-09-14T18:58:47.233278+00:00`; source SHA-256 `cf6961c7bb23fd4b8d4b208e49a1a0e8c47c69e5e704ce8f6e220b20aff8a00b`.
- [E18] [media/SOUL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/SOUL.md) — modified `2026-09-14T18:58:47.233491+00:00`; source SHA-256 `852b912f1d7c98e68b37f09bae20a6aa32e43b2362bd76df1ec618d4735f0929`.
- [E19] [media/binding.template.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/binding.template.json) — modified `2026-09-14T18:53:47.722830+00:00`; source SHA-256 `57a37beccacb42970b16dc4387780983fae8aae0fda067b8782a9a0f50d6487a`.
- [E20] [media/customer-scope.example.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/customer-scope.example.json) — modified `2026-09-14T19:00:00.042799+00:00`; source SHA-256 `bdda9387dfd6b3fa46737337fcf441df5b90f82c2bff4d2002df6b8cbcfa6d2b`.
- [E21] [media/read-plugin/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/read-plugin/README.md) — modified `2026-09-14T19:00:00.058754+00:00`; source SHA-256 `d3abfd4febc17ed49828afeda75119aec013815b209497d2f37c7cc2055a302e`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1yBDRbbEFHOBKZCkaEGLPdUDy4Q77dyvM). Folder link is a recorded pointer, not current access proof.
