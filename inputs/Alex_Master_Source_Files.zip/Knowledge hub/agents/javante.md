# Javante — Mac mini creative and technical executor

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Owns a separate identity, context and history, with ad/video and Mac workflow responsibilities. Maintained setup is recovery material; evolving live knowledge and checkpoints belong to the serving home. [Source set: E32, E33, E34, E35, E36, E37, E38, E39]

## Computer, workspace and Hermes identity

DOCUMENTED mapping: `Sashas-Mac-mini.local`, live Hermes default home `/Users/sashairis/.hermes`; September 22 ACCEPTANCE identifies that host. October 5 inventory also maps `SASHA IR MAC MINI - JAVANTE` to the same home. TOOLS records Chrome `AGENT MINI` / `agent@increaseroas.com` with basic browser Drive read observed in its historical acceptance. This browser session does not prove all Google scopes or current authentication. Working-directory identity beyond the documented home is unknown. [Source set: E32, E33, E34, E35, E36, E37, E38, E39; inventory: E4]

## Setup, start and recovery pointers

INDEX owns navigation. README separates initial migration and reviewed-setup recovery from ordinary source updates. RECOVERY points to timestamped private backups and release receipts; recover only the intended checkpoint. A2A and Telegram routes must be checked live; old acceptance is not delivery proof. [Source set: E32, E33, E34, E35, E36, E37, E38, E39]

## Tools and skills pointers

TOOLS/WORKFLOWS point to computer-use, Hermes skill authoring, copywriting plugin, audit factory, Google Workspace CLI, Meta CLI, 1Password CLI and GHL workflow skill. GHL Command is documented on Javar’s EA Orgo cloud host, with the full 330-tool catalog at acceptance; OpenClaw is a separate ChatGPT connector. Catalog size is a historical observation, not a current count. [Source set: E32, E33, E34, E35, E36, E37, E38, E39]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

ACCEPTANCE records September 22 catalog, reliability plugin, checkpoint priority, scheduler and Telegram/A2A checks. README records clean upstream Hermes 0.21.4 at tag v2026.9.21; the October 5 workbook later records installed 0.21.5 and explicitly leaves serving health untested. These versions describe different dated observations. Reliability schedules are documented as active historically, not rechecked today. [Source set: E32, E33, E34, E35, E36, E37, E38, E39; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Current serving release and active scheduler state are unknown. The historical Google CLI had no stored OAuth client/account, while browser Drive read worked; canonical audit Drive-file sharing remained pending in TOOLS. Service-account renewal is a manual owner operation described in RECOVERY, not a completed task here. [Source set: E32, E33, E34, E35, E36, E37, E38, E39; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E32] [javante/setup/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/README.md) — modified `2026-09-24T00:42:44.442985+00:00`; source SHA-256 `10621f909ad7a9b7293225ba46730491055aafe198242f0deadf4f534d88cf73`.
- [E33] [javante/setup/INDEX.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/INDEX.md) — modified `2026-09-22T23:24:07.684664+00:00`; source SHA-256 `1d7c5e0da39ac5570d64431fd0bedcc50e975dc026918873c280acfe943c858b`.
- [E34] [javante/setup/IDENTITY.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/IDENTITY.md) — modified `2026-09-22T23:21:57.785726+00:00`; source SHA-256 `730e38193e01557bb7971fb4d3d9f6369e62d98c3d91307d31d3c50f38e74151`.
- [E35] [javante/setup/SOUL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/SOUL.md) — modified `2026-09-22T23:22:04.652603+00:00`; source SHA-256 `9890d967a74ffdeecaaa09eda7703599f0ecdadf060173e186f2976e935284e5`.
- [E36] [javante/setup/TOOLS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/TOOLS.md) — modified `2026-09-24T00:42:44.442234+00:00`; source SHA-256 `5d6f1c21fe0a35d42319651d5feb1ca093382695877a0d61414414b30dd819a8`.
- [E37] [javante/setup/WORKFLOWS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/WORKFLOWS.md) — modified `2026-09-24T00:42:44.442319+00:00`; source SHA-256 `c4433ff1156c959ed7c1fa4300f73a9e39f5b89ff575d4e4bdd2a36aa94f7a6a`.
- [E38] [javante/setup/RECOVERY.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/RECOVERY.md) — modified `2026-09-24T00:42:44.442847+00:00`; source SHA-256 `8947d30bdd8ec0876575ee1a8fac6cc8c53e29ecbee07d5e3bae8846afe17249`.
- [E39] [javante/setup/ACCEPTANCE.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/ACCEPTANCE.md) — modified `2026-09-23T00:11:59.344228+00:00`; source SHA-256 `c71e9f7dd76c9d6df2372886bea43188fbd6a61b3fb54c7e088b0144c7edd236`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1CLT-jas1qZd33-rNCHsCBpnZZJykauJj). Folder link is a recorded pointer, not current access proof.
