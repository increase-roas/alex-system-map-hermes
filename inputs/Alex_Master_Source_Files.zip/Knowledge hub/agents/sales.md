# Sales / Hunter / Setter — Hunter research and Setter qualification

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Hunter is a function within the existing B2B Revenue Agent/Setter lane; Setter retains qualification and the existing persona/identity/ledger. Hunter researches new Increase ROAS agency prospects and prepares cards or audit research; Media renders audit PDFs and Setter drafts outreach. [Source set: E22, E23, E24, E25, E26]

## Computer, workspace and Hermes identity

hunter/README documents existing `/root/.hermes` and sanitized Orgo/bot/app identifiers; hunter/SKILL explicitly rejects a separate Hunter runtime or machine. October 6 workbook identifies B2B Sales Agent computer `2472bdb6-ae8f-4417-a4d0-103df5618d60` in B2B Agent (Sales) workspace `87d53061-ba01-4ff0-94c7-67057700af27`, with /root/.hermes found; default profile was recorded October 5. This corroborates the B2B lane without inventing a separate Hunter identity. [Source set: E22, E23, E24, E25, E26; inventory: E4]

## Setup, start and recovery pointers

hunter/README owns activation/reuse and rollback of the hunter-outbound skill/pointer only. It points to Build/docs/playbooks/b2b-lead-audit.md for audit mode. Existing identity and task records are preserved. Setter binding JSON are template/example states, not active credentials or grants. [Source set: E22, E23, E24, E25, E26]

## Tools and skills pointers

hunter/SKILL names native public research, `setter_knowledge_query` for procedure and `setter_ghl_read` for CRM facts. setter/plugin.yaml declares the two read tools at version 0.1.0; declaration does not prove live registration. Procedure remains at the source skill instead of being copied here. [Source set: E22, E23, E24, E25, E26]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

README reports September 10 bounded prospect research and durable handoff accepted, with no outreach. September 11 audit skill installation/hash is historical evidence; its end-to-end real-contact audit remained awaiting acceptance in that record. Sanitized proof URLs are not working source receipts. [Source set: E22, E23, E24, E25, E26; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Current B2B runtime/provider readiness, full duplicate/suppression lookup and outreach eligibility are unverified. No outreach, booking or audit acceptance is proved by this knowledge page. [Source set: E22, E23, E24, E25, E26; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E22] [hunter/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/hunter/README.md) — modified `2026-09-14T19:00:00.048432+00:00`; source SHA-256 `421c75a808f42e3afcfadf61106a498a0804acf88ff7606df538c00c613d46cd`.
- [E23] [hunter/SKILL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/hunter/SKILL.md) — modified `2026-09-14T18:58:47.233041+00:00`; source SHA-256 `1e5acfffc99f58fecfdc5f8494ea5ef18ff48e1ec0d02e13c780e92ffdc5f0b4`.
- [E24] [setter/knowledge-binding.template.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/setter/knowledge-binding.template.json) — modified `2026-09-14T19:05:19.049381+00:00`; source SHA-256 `b52c7e891a4425406fbaa91114a804ce7a1e30a44c3d28de81181a026330fea9`.
- [E25] [setter/knowledge-binding.example.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/setter/knowledge-binding.example.json) — modified `2026-09-14T19:00:00.035444+00:00`; source SHA-256 `9cfa30d456d5f842052aa172af492101e744fa5f1478c7d4d7cb00ce21f809d2`.
- [E26] [setter/plugin.yaml](/Users/alexlobaito/Documents/ChatGPT/Build/agents/setter/plugin.yaml) — modified `2026-09-09T19:36:32.187545+00:00`; source SHA-256 `e5dfe1a7ed195b0431ed1bdd1e7f0697702da5b97b33dfe255a789f4fede5f55`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1hD81_y-8rq9MML6eSEBA9eAuJEm8lwem). Folder link is a recorded pointer, not current access proof.
- [E5] [Hermes Agent Sales Sources](https://drive.google.com/file/d/1iAqaKbeIqv71toPNim0ITTmxFuV-Z-A4/view) — recorded existing shortcut target; contents not inspected here.
- [E5] [B2B Sales Research Archive](https://drive.google.com/file/d/1LZCJno7jw6JgutqU6OsKP_cf0nLFqZEU/view) — recorded existing shortcut target; contents not inspected here.
