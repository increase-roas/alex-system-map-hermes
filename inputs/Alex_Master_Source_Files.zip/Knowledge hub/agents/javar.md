# Javar — Executive assistant and operating catalog

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Executes Alex’s requested work directly by default; maintains one catalog and customer-scoped checkpoints. Business providers own live facts; on-demand workflow packages own procedures. Handoffs are explicit assignments, not automatic delegation. [Source set: E6, E7, E8, E9, E10]

## Computer, workspace and Hermes identity

DOCUMENTED mapping: EA Orgo computer `d9b475e2-47b2-46d4-b8eb-102564f93283`; Hermes home `/home/orgo/lil-smoove/home/.hermes`; working directory `/home/orgo/lil-smoove/workspace`; catalog `/home/orgo/lil-smoove/home/agent-knowledge/INDEX.md` (ea/startup/TOOLS.md). Inventory corroborates EA membership in workspace `EA (Javar)` / `b4d13606-19d3-4802-9f5c-82819995129a` on October 6. The October 5 saved profile is main default; other root, Manny and canary profiles are separate entries, not substitute Javar identities. Account email for this role is not established by these 34 sources. [Source set: E6, E7, E8, E9, E10; inventory: E4]

## Setup, start and recovery pointers

Start with the installed INDEX, then TOOLS or WORKFLOWS for the task. `ea/runtime-update/README.md` owns the reviewed prepare/switch update and receipt-driven rollback route; do not execute it from this reference page. `javar_checkpoint` owns scoped task resume. Heartbeat recovery references are named in INDEX but were outside this snapshot. [Source set: E6, E7, E8, E9, E10]

## Tools and skills pointers

TOOLS names deferred `javar_capabilities` discovery through native `tool_call` and provider topic guides. WORKFLOWS points to `clients/client-info`, `agent-operations/javar-skill-builder`, website audit factory and the customer toolbox `/home/orgo/lil-smoove/home/.hermes/customer-toolboxes/increase_roas/`. These are pointers, not an inventory of everything currently installed. [Source set: E6, E7, E8, E9, E10]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

The source documents a reviewed Hermes 0.21.4 native runtime and clean pinned upstream update boundary. September 24 route notes report prior Composio/Cloudflare 401 errors; current authentication was not tested. Native local tools provide host visibility rather than a per-task filesystem sandbox. Reply-to-send correlation was not registered in the documented clean-upstream release. [Source set: E6, E7, E8, E9, E10; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Current runtime version, gateway health, provider access and scheduler behavior require a new bounded runtime receipt. October 5 inventory configurations do not prove serving use. Do not treat retired Sheets/Notion instructions as a second current authority. [Source set: E6, E7, E8, E9, E10; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E6] [ea/startup/INDEX.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/INDEX.md) — modified `2026-09-24T14:29:51.043804+00:00`; source SHA-256 `02a0bf8bd368291fdad71c5aab4a8e809a81624f81c55a88706d9a346d06326f`.
- [E7] [ea/startup/AGENTS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/AGENTS.md) — modified `2026-09-24T14:29:49.897644+00:00`; source SHA-256 `8449806a42264d7cb28d808cc3ca1d65b5774d897945fb9bcfafdee3541d7f05`.
- [E8] [ea/startup/TOOLS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/TOOLS.md) — modified `2026-09-25T21:29:23.878827+00:00`; source SHA-256 `74f5b1a9e789658a51c03c60afb84931941bcc81ea57208e4765adc181f25e02`.
- [E9] [ea/startup/WORKFLOWS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/WORKFLOWS.md) — modified `2026-09-24T12:49:12.224648+00:00`; source SHA-256 `adb3c0f986752cd53ea40aa4963b73faa5d823063454adb8203f2e85811ef0ac`.
- [E10] [ea/runtime-update/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/README.md) — modified `2026-09-23T21:50:02.514344+00:00`; source SHA-256 `18090466c2a724078bd65c722cbb61324b10d9731ed4de187defd2edf7621c6e`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/163WibPA7SUK14PnQz5SKdi8Uj27rb0x_). Folder link is a recorded pointer, not current access proof.
- [E5] [Javar Build Gameplan](https://drive.google.com/file/d/1pSehqwtrTzhIRgk06lDPd2UBJXDob2nW/view) — recorded existing shortcut target; contents not inspected here.
- [E5] [Javar Gameplan Notes](https://drive.google.com/file/d/1llvA0h0NnQGULWW-JnlXonZkKSH2YIZ3/view) — recorded existing shortcut target; contents not inspected here.
