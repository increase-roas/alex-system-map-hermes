# Finance — Company-scoped accounting review preparation

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Prepares source-linked accounting review recommendations separately for each company, period, currency and reporting basis. Recurring charges are review candidates; margins require attributable revenue and costs. Unknown allocation stays unknown. [Source set: E27, E28, E29, E30, E31]

## Computer, workspace and Hermes identity

Finance binding.template is UNBOUND, with null home/computer/Slack/company realm fields. README reports no live identity. QUICKBOOKS says a purchased assigned Finance computer exists but sanitizes its ID. October 6 inventory does not establish that host. Exact active computer, workspace, Hermes account/profile and QuickBooks company are unknown; no role-based mapping is inferred. [Source set: E27, E28, E29, E30, E31; inventory: E4]

## Setup, start and recovery pointers

finance/README points to the team setup method, report seam and Build/docs/FINANCE-ROLLOUT-PREP.md. QUICKBOOKS owns the remaining OAuth/storage/registration/sandbox/live monthly-review requirements. Its preparation acceptance commands are source pointers, not commands executed in this job. [Source set: E27, E28, E29, E30, E31]

## Tools and skills pointers

QUICKBOOKS documents native Intuit OAuth client and fixed-host company/report reads, restricted to CompanyInfo and dated P&L, BalanceSheet, CashFlow or VendorExpenses. requirements pins intuit-oauth==1.2.7; installation is distinct from authorization. README says only deterministic fixture registration existed in its preparation record. [Source set: E27, E28, E29, E30, E31]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

September 10 offline SDK/OAuth/report-adapter scenario is reported as passed. It used substituted responses, in-memory storage and synthetic transport; it proves neither real consent nor durable storage or live company totals. The OAuth grant itself is broader than the restricted read-tool boundary. [Source set: E27, E28, E29, E30, E31; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Live company/realm/basis/currency, credential destination, owner interface, durable storage/recovery, registered tool and actual report reconciliation remain unproven. No payments, ledger mutation or customer financial records were accessed. [Source set: E27, E28, E29, E30, E31; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E27] [finance/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/README.md) — modified `2026-09-14T18:58:47.231261+00:00`; source SHA-256 `9e0b1338ced6cc192544c1069f5698df35391900a373fda38ef32bcb5864ea3e`.
- [E28] [finance/SOUL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/SOUL.md) — modified `2026-09-14T18:58:47.231421+00:00`; source SHA-256 `732f36ada5f370c1b9c68b67db52a3a47360e639ac388bc1327c0d30acae74c5`.
- [E29] [finance/QUICKBOOKS.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/QUICKBOOKS.md) — modified `2026-09-14T18:58:47.231066+00:00`; source SHA-256 `6d1ebe3efba9afb3067a122c35cd212491b8e336bcbb3d1be4a31f471d116b89`.
- [E30] [finance/binding.template.json](/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/binding.template.json) — modified `2026-09-14T19:05:19.048557+00:00`; source SHA-256 `0f92c4e3d68df1ceb16fa3f08848db7e74829979e1c60ce7a80fe5414cabedaf`.
- [E31] [finance/requirements-quickbooks.txt](/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/requirements-quickbooks.txt) — modified `2026-09-10T10:11:50.153975+00:00`; source SHA-256 `44426394284f2484990bd2d37e8959f6fc15e950e1254f0f1edcdbd0d26e45fd`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1cCOAGSdHVlya5vVsVs44BOhNKcq9oTzf). Folder link is a recorded pointer, not current access proof.
