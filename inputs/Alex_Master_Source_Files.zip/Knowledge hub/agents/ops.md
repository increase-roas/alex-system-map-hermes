# Ops — Operational coordination

Build-context extension: read [BUILD_IMPLEMENTATION.md](../BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](../BUILD_READINESS.md) for later accepted plans, removed/replacement host observations and continuation blockers. This page retains its selected-source snapshot dates; historical installation/acceptance is not current serving proof.

[Start here](../START_HERE.md) · [Team map](../TEAM_MAP.md) · [Lessons and maintenance](../LESSONS.md)

Knowledge review: 2026-10-07. Evidence level: **DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED**. Source modified dates below describe filesystem metadata, never a runtime update. Historical approvals/instructions grant no new authority.

## Purpose and ownership

Coordinates task ownership, next actions, deadlines, blockers and durable handoffs under Javar. Shared coordination belongs to the accepted Ops service; local task records are not shared orchestration authority. A worker completion still needs Javar verification. [Source set: E11, E12]

## Computer, workspace and Hermes identity

DOCUMENTED historical role mapping: team-template/README names Ops computer `9899abd2-57b0-4b76-a59a-1f0ba7ee538f`, Slack app `A0C0MKF8CMA`, Increase ROAS workspace `T0BGV107N3T` and Nous/deepseek-v4-flash. Exact Hermes home/profile is not supplied in the two sources. Separately, October 6 inventory lists workspace `Ops — Increase ROAS` / `c523a888-eec5-4501-b25d-b6d591a3a90a` with `SPARE-Ops` / `47a4ba7c-9908-44f7-aa32-b7da8e18ac85`; no Hermes home was found in two checked locations. That spare is not proven to host the accepted Ops agent. [Source set: E11, E12; inventory: E4]

## Setup, start and recovery pointers

team-template/README owns role materialization from accepted hashes and directs new roles to `Build/docs/skills/hermes-team-setup/SKILL.md`. It requires independent role bindings and preserves EA state. Rollback guidance removes only the candidate and retains receipts. Follow current checkpoint/private completion evidence before reusing old pending language. [Source set: E11, E12]

## Tools and skills pointers

Foundation names task records, owner reminders, one-use approval store, scoped team plugin/client and role-specific service bindings. SOUL names team_task dispatch and worker checkpoint/model evidence checks. These documents do not prove that every named tool is currently registered. [Source set: E11, E12]

Use the hub’s [skills register](../SKILLS.md) and [hooks register](../HOOKS.md) for the wider evidence limits. Linked dependencies named in source were not automatically read or executed.

## Verification status and dates

Historical isolated task acceptance is named as `t_58bd5ca4` with a September 9 Slack receipt. The README’s current-state preface says later bounded team handoff receipts supersede its older pending coordination text. Those private completion receipts were not opened in this bounded job. [Source set: E11, E12; inventory: E4]

The prior package-verification receipt is VERIFIED at `2026-10-07T16:44:23.195272+00:00`, for curated local ZIPs only (E2). This page’s content was read from those archived source bytes and ZIP/manifest hashes checked. Direct maintained-file attempts were incomplete; this is an as-of snapshot audit, not fresh maintained-source content verification. Current provider/host execution, remote installation and full backups are **NOT_CHECKED**.

## Gaps

Current Ops host, Hermes profile, provider account, gateway and shared-task health are unverified. Current coordination acceptance must be read from the referenced checkpoint rather than restarting the historical gate. [Source set: E11, E12; inventory: E4]

## Maintained sources and Drive pointers

Source home: `/Users/alexlobaito/Documents/ChatGPT/Build/agents`. Keep procedure changes there or in the actual owning skill; update these pointers and [LESSONS](../LESSONS.md) through [START_HERE](../START_HERE.md)’s future update procedure.

- [E11] [team-template/README.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/README.md) — modified `2026-09-21T14:30:14.746965+00:00`; source SHA-256 `26ce7ca89b025fbbad378f648032e3ff8c8786f2c7bc8426e2f5f5478be818ce`.
- [E12] [team-template/ops-candidate/SOUL.md](/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/SOUL.md) — modified `2026-09-14T18:58:47.234548+00:00`; source SHA-256 `b922d975a5730ca2ef01337899331da85dea62ca755a421b3c09b690007d415c`.

- [E1] Snapshot allowlist: `work/agent-build-hub-local-manifest.json`.
- [E2] Package receipt: `work/agent-build-hub/package-verification.json`.
- [E3] Date receipt: `work/agent-build-hub/source-update-dates.json`.
- [E4] Inventory: `outputs/AI_Infrastructure_Gameplan.xlsx`, Computers / Orgo Workspaces / Hermes Configurations / Hermes by Computer, dated October 5–6, 2026.
- [E5] Existing Drive metadata: `work/agent-build-hub/drive-state.json`; [role folder](https://drive.google.com/drive/folders/1Bwsivycz4Xp2rg9AN7hlmVJ6JW8D-nYb). Folder link is a recorded pointer, not current access proof.
- [E5] [Ops Build Requirements](https://drive.google.com/file/d/1cSs2yWcxlLSFZQ685bmr69kF00PxVGon/view) — recorded existing shortcut target; contents not inspected here.
- [E5] [Existing Ops Records](https://drive.google.com/file/d/1d-bybId07i_Hm6CXJ7DjbNnsmTtLcgZG/view) — recorded existing shortcut target; contents not inspected here.
