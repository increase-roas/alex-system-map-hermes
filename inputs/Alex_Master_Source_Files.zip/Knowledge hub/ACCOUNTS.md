# Accounts and permitted routes

[Start here](START_HERE.md) · [Lessons and updates](LESSONS.md) · [Infrastructure](INFRASTRUCTURE.md) · [Accounts](ACCOUNTS.md)

Prepared 2026-10-07 from saved October 5–6 evidence. This is a readable derivative; the source workbook remains the detailed inventory. No provider was contacted in this extraction.

Evidence states: **DECLARED** means Alex supplied the statement in the current brief; **READ_VERIFIED** means the saved exact read/list/probe succeeded within its stated scope; **CONFIGURED** means saved settings/account metadata; **HISTORICAL** means workbook STALE, dated evidence without a current re-read; **UNKNOWN** means evidence absent. None establishes current service health, billing, permissions, or an active serving agent.

## Declared plans and identities

| Surface | Exact statement | State | Login/profile or billing proof limit |
| --- | --- | --- | --- |
| Cursor | personal $200/month | DECLARED | UNKNOWN |
| Claude | personal $200/month | DECLARED | UNKNOWN |
| Codex/ChatGPT | personal $200/month; one declared subscription | DECLARED | UNKNOWN |
| Grokbot | plan unknown | DECLARED / UNKNOWN | UNKNOWN |
| Manus | studio 2.09 | DECLARED; exact text, meaning unverified | UNKNOWN |
| Hermes | alex@increaseroas.com | DECLARED | Not linked to a specific saved profile |
| Hermes | agent@increaseroas.com | DECLARED | Not linked to a specific saved profile |

Source [E3]. The three priced declarations total $600/month as declared arithmetic, not verified invoices; Codex and ChatGPT are counted once. No Manus currency, billing interval, product edition, or version is inferred from “studio 2.09”. No declared Hermes identity is automatically assigned to a profile below.

## Connected-account register

The following 54 entries are **CONFIGURED**, dated 2026-10-06, source [E1] `Composio Accounts` rows 2–55. Names label the saved connection; they do not establish the actual email principal. Each call must explicitly select the connection ID and follow its app card. Saved ACTIVE is metadata, not a successful runtime test. The two saved consumer principal groups are distinct; membership is available in workbook column C. No connector credential value is copied here.

| Connection name | Exact connection ID | Toolkit / saved route | Saved status | Pointer |
| --- | --- | --- | --- | --- |
| Javar Google Docs | ca_bzGSns1UmedY | googledocs_dug-blet | ACTIVE | Workbook `Composio Accounts` row 2 |
| Javar Google Sheets | ca_scLcTvfsqros | googlesheets_kriton-wull | ACTIVE | Workbook `Composio Accounts` row 3 |
| Javar Google Drive | ca_SccVNLDGgXDk | googledrive_riding-slavey | ACTIVE | Workbook `Composio Accounts` row 4 |
| Javar Gmail | ca_sqo2IZ38tbvS | gmail_ibex-dying | ACTIVE | Workbook `Composio Accounts` row 5 |
| Javar Cloudflare audit | ca_4khqvee17CY8 | custom_cloudflare_api_matron-roble | ACTIVE | Workbook `Composio Accounts` row 6 |
| fireworks_ai_warly-reckon | ca_WRcKA-TYB_OP | fireworks_ai_warly-reckon | EXPIRED | Workbook `Composio Accounts` row 7 |
| manus_gum-dub | ca_rqLSFAGY4UHY | manus_gum-dub | ACTIVE | Workbook `Composio Accounts` row 8 |
| custom_wavv_single-rolled | ca_NnFf-aNmK5b8 | custom_wavv_single-rolled | ACTIVE | Workbook `Composio Accounts` row 9 |
| hugging_face_pricer-drongo | ca_LT97uOiNLDhk | hugging_face_pricer-drongo | ACTIVE | Workbook `Composio Accounts` row 10 |
| firecrawl_che-aday | ca_s4u_SyGN6QGq | firecrawl_che-aday | ACTIVE | Workbook `Composio Accounts` row 11 |
| tailscale_eaved-netter | ca_Qr4XRwIDafoq | tailscale_eaved-netter | ACTIVE | Workbook `Composio Accounts` row 12 |
| custom_foreplay_sain-cogue | ca_Ewk5F5TGN7Yg | custom_foreplay_sain-cogue | ACTIVE | Workbook `Composio Accounts` row 13 |
| make_gerbe-ashake | ca_nkMxaCSYt2gD | make_gerbe-ashake | ACTIVE | Workbook `Composio Accounts` row 14 |
| higgsfield_belout-embus | ca_yDkZXqXVoUUy | higgsfield_belout-embus | ACTIVE | Workbook `Composio Accounts` row 15 |
| custom_atlas_cloud_gash-tights | ca_lc_OOuJPDa_0 | custom_atlas_cloud_gash-tights | ACTIVE | Workbook `Composio Accounts` row 16 |
| sentry_venada-dama | ca_S-viSC950kAZ | sentry_venada-dama | ACTIVE | Workbook `Composio Accounts` row 17 |
| linear_flap-urtica | ca_-3kNQV1b0-xq | linear_flap-urtica | ACTIVE | Workbook `Composio Accounts` row 18 |
| Notion full workspace | ca_hq3X8KNk3nWe | notion_lepas-limbie | ACTIVE | Workbook `Composio Accounts` row 19 |
| custom_google_robot_fenter-snork | ca_vm6rcasgNEIk | custom_google_robot_fenter-snork | ACTIVE | Workbook `Composio Accounts` row 20 |
| custom_cloudflare_api_sari-sud | ca_IUuu0MrmsQya | custom_cloudflare_api_sari-sud | ACTIVE | Workbook `Composio Accounts` row 21 |
| metaads_daub-putage | ca_7i7CdMbStKc9 | metaads_daub-putage | ACTIVE | Workbook `Composio Accounts` row 22 |
| custom_ir_notes_privy-bulse | ca_zTNUL9d6xZDl | custom_ir_notes_privy-bulse | ACTIVE | Workbook `Composio Accounts` row 23 |
| custom_ghl_oauth_crm_ransom-adiate | ca_OIfo_F6scXwN | custom_ghl_oauth_crm_ransom-adiate | ACTIVE | Workbook `Composio Accounts` row 24 |
| custom_ghl_command_builder_dimble-genian | ca_o1-FA70PbU3x | custom_ghl_command_builder_dimble-genian | ACTIVE | Workbook `Composio Accounts` row 25 |
| googleads_maned-sprack | ca_IuXZo5FP9x3_ | googleads_maned-sprack | ACTIVE | Workbook `Composio Accounts` row 26 |
| prime-increaseroas | ca_ev--jZjkn41E | custom_prime_intellect_lave-outact | ACTIVE | Workbook `Composio Accounts` row 27 |
| spyfu-increaseroas | ca_-fHucw9xAqkE | custom_spyfu_crural-myaria | ACTIVE | Workbook `Composio Accounts` row 28 |
| xai-increaseroas | ca_xmSIwBg2NqDS | custom_xai_research_mir-borgh | ACTIVE | Workbook `Composio Accounts` row 29 |
| increaseroas-tagging | ca_RjAXt_4X2K28 | custom_ga4_admin_arundo-sower | ACTIVE | Workbook `Composio Accounts` row 30 |
| increaseroas-tagging | ca_Z9l2oNsyCPgI | custom_google_tag_manager_bardel-serau | ACTIVE | Workbook `Composio Accounts` row 31 |
| jobber_clunk-fient | ca_M2arjPS9EG0- | jobber_clunk-fient | ACTIVE | Workbook `Composio Accounts` row 32 |
| JAVANTE GITHUB | ca_R9YYC0dOQqYk | github_tina-inwit | ACTIVE | Workbook `Composio Accounts` row 33 |
| Javar's Google Docs | ca_90JRFV8L3jLU | googledocs_defer-knar | ACTIVE | Workbook `Composio Accounts` row 34 |
| Javante's Google Docs | ca_KQGDNMqA0QmY | googledocs_tabby-phosis | ACTIVE | Workbook `Composio Accounts` row 35 |
| Javante's Google sheet | ca_741StayzGqrI | googlesheets_paga-swure | ACTIVE | Workbook `Composio Accounts` row 36 |
| Javante Google drive | ca_KDX1yseZDi4q | googledrive_gaily-perit | ACTIVE | Workbook `Composio Accounts` row 37 |
| Javante's Work email | ca_SWpjsthnejVb | gmail_redry-illeck | ACTIVE | Workbook `Composio Accounts` row 38 |
| Javar Work Email | ca_rKbhdRSZGe44 | gmail_ziffs-thoric | ACTIVE | Workbook `Composio Accounts` row 39 |
| Lonestar Slack Account | ca_XZFQvKnTJNU7 | slack_east-reps | ACTIVE | Workbook `Composio Accounts` row 40 |
| Javar's Google Drive | ca_jFHZTx1ohS3S | googledrive_prover-wore | ACTIVE | Workbook `Composio Accounts` row 41 |
| Javar's Google Sheets | ca_kD46RTVVTy4- | googlesheets_incur-aghan | ACTIVE | Workbook `Composio Accounts` row 42 |
| Increase Roas (partnership, Phoenix) | ca_p-2iG6dDdXF_ | quickbooks_genre-lapsed | ACTIVE | Workbook `Composio Accounts` row 43 |
| SSA - Start Scale Automate (personal brand, S-Corp) | ca_hX6MOzV-O7CS | quickbooks_arris-bigamy | ACTIVE | Workbook `Composio Accounts` row 44 |
| fireflies_kiyi-agaze | ca_Cuo1gQO7hSUg | fireflies_kiyi-agaze | ACTIVE | Workbook `Composio Accounts` row 45 |
| apify_ruby-asor | ca_SCIY8G-H9N-d | apify_ruby-asor | ACTIVE | Workbook `Composio Accounts` row 46 |
| alexheygen account | ca_0EvyaWB1qwnb | heygen_plower-ceiler | ACTIVE | Workbook `Composio Accounts` row 47 |
| retellai_testes-devil | ca_XFvXxm4MwNRc | retellai_testes-devil | ACTIVE | Workbook `Composio Accounts` row 48 |
| asana_logie-fratch | ca_lLZHW9-EBay3 | asana_logie-fratch | ACTIVE | Workbook `Composio Accounts` row 49 |
| elevenlabs_rangle-malo | ca_1-y78e716xtk | elevenlabs_rangle-malo | ACTIVE | Workbook `Composio Accounts` row 50 |
| discord_brainy-haired | ca_H5J9aateJf_I | discord_brainy-haired | ACTIVE | Workbook `Composio Accounts` row 51 |
| zoom_dour-dusk | ca_qyzawGrrjiAA | zoom_dour-dusk | ACTIVE | Workbook `Composio Accounts` row 52 |
| exa_beode-vain | ca_2vgF0f84i2xJ | exa_beode-vain | ACTIVE | Workbook `Composio Accounts` row 53 |
| Alex Slack Account | ca_ioyaOJLKDEUK | slack_rehood-hinney | ACTIVE | Workbook `Composio Accounts` row 54 |
| GITHUB | ca_O_g-WhWXwO9d | github_lipase-modern | ACTIVE | Workbook `Composio Accounts` row 55 |

The final saved workbook-upload receipt specifically names `alex@increaseroas.com` through `custom_google_robot`, connection `ca_vm6rcasgNEIk` [E2]; this is READ_VERIFIED receipt identity for that upload/readback, not a general principal mapping for every connection. Javar/Javante labels are kept distinct. The saved Fireworks connection is EXPIRED; it has no current acceptance proof.

## Credential references

These nine **HISTORICAL** references identify where the saved record says a credential or vault lives. They are pointers only; no values, new credential retrieval, or runtime-provider acceptance. Source [E1].

| Reference title | Container | Saved route | Evidence date | Pointer |
| --- | --- | --- | --- | --- |
| Agent — JAVAR-LAB | UNKNOWN | 1Password saved runtime-account read | 2026-10-06T01:12:00Z | Workbook `Credential References` row 2 |
| JAVAR-LAB — Runtime | Agent — JAVAR-LAB | 1Password | 2026-10-06T01:12:00Z | Workbook `Credential References` row 3 |
| Service Account — JAVAR-LAB Runtime — 2026-10-06 | Local Vault | 1Password operator route | 2026-10-06T01:12:00Z | Workbook `Credential References` row 4 |
| OpenRouter API key - javar-prod | Connectors vault | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 5 |
| OpenRouter API key - sales-prod | Connectors vault | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 6 |
| OpenRouter API key - javar-research | Connectors vault | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 7 |
| OpenRouter API key - javar-lab | Connectors vault | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 8 |
| Fireworks API key - javar-lab | Connectors vault | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 9 |
| Orgo API key | UNKNOWN | 1Password operator route | 2026-10-05 | Workbook `Credential References` row 10 |

The saved JAVAR-LAB runtime vault observation is one visible vault and zero items at 2026-10-06 01:12Z (`Credential References` rows 2–4); this proves the historical read scope only. Nous / Hermes has a historical existing-provider connection, but exact credential title is UNKNOWN (`Access Routes` row 16).

## Saved surfaces and profile mapping

Source [E1] `Access Routes` rows 2–16: two CONFIGURED local MCP projections (`node_repl`, `director-observatory`), twelve HISTORICAL surface/route references, and one HISTORICAL Nous connection. Surface references may group several tools. Exact per-surface built-ins belong to the referenced canonical AI apps tab; this extraction does not independently verify their installation.

| Saved Hermes configuration | Host | Safe profile/model pointer | State |
| --- | --- | --- | --- |
| EA / ea-javar-canary | EA | Workbook `Hermes Configurations` row 2 | HISTORICAL, Oct5; serving untested |
| EA / ea-javar-cloudflare-rag-canary | EA | Workbook `Hermes Configurations` row 3 | HISTORICAL, Oct5; serving untested |
| EA / Javar main default | EA | Workbook `Hermes Configurations` row 4 | HISTORICAL, Oct5; serving untested |
| EA / manny-business | EA | Workbook `Hermes Configurations` row 5 | HISTORICAL, Oct5; serving untested |
| EA / root default | EA | Workbook `Hermes Configurations` row 6 | HISTORICAL, Oct5; serving untested |
| B2B Sales Agent / default | B2B Sales Agent | Workbook `Hermes Configurations` row 7 | HISTORICAL, Oct5; serving untested |
| SASHA IR MAC MINI - JAVANTE / default | SASHA IR MAC MINI - JAVANTE | Workbook `Hermes Configurations` row 8 | HISTORICAL, Oct5; serving untested |
| Alex’s MacBook Pro / default | Alex’s MacBook Pro | Workbook `Hermes Configurations` row 9 | HISTORICAL, Oct5; serving untested |

See Infrastructure for exact host and profile paths. Permissions, subscription invoices, actual authenticated principals behind most connector labels, and bindings between declared Hermes emails and these saved profiles remain UNKNOWN.

[E1] [Inventory workbook on Drive](https://docs.google.com/spreadsheets/d/1Jinfgxakdq06FS6IN_QCQcq3TSioFbGn/edit) ([local workbook](../AI_Infrastructure_Gameplan.xlsx)), final saved SHA-256 `a4edbad6d5d088d6a6dd13584446f6b1f1d63112623bbe8fc2c7468eb99ac303`.

[E2] [Inventory verification](../inventory-verification.json), 2026-10-06; [audit details](../inventory-audit-details.json), 2026-10-06; [final saved publication receipt](../drive-verification-receipt.json). The audit's earlier Drive mismatch is superseded by this final matching saved receipt. This extraction verifies local bytes against it, not current remote bytes.

[E3] Current declaration record: `work/agent-knowledge/brief.json` (2026-10-07). [E4] Saved safe metadata: `work/orgo-metadata.json` and allowlisted OS-only parsing of `work/orgo-profiles.json` (Oct6); no raw probe output or secret values reproduced.
