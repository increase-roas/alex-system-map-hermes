# Current evidence state

Knowledge audit: 2026-10-07. This file describes evidence freshness, not a fleet-health check. Read [GAPS.md](GAPS.md) and [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) before acting.

| Area | Evidence | What it proves |
|---|---|---|
| Infrastructure and connected accounts | October 5–6 inventory; 23 workbook sheets | Saved resource/account/configuration metadata with per-row state and dates |
| Current Drive workbook identity | `work/agent-knowledge/workbook-live-metadata.json`, 2026-10-07 | Original Drive workbook ID still reports the SHA-256 matching the verified local workbook; this is not a new provider inventory |
| Build/setup sources | Seven dated ZIPs; 34 exact source files; independent package receipt | Curated documentation as verified at snapshot time; current maintained-source reads may be limited |
| Local skills | Complete SKILL.md reads on 2026-10-07; exact coverage/hash register | Entry-file contents, source placement and scoped discovery metadata; supporting-resource execution and runtime selection not proved |
| Hooks | Selected safe hook source/config reads on 2026-10-07 | Source presence and selected configured hook entries; execution not exercised |
| Personal subscriptions and Hermes emails | Alex's current chat declarations, 2026-10-07 | Declared facts, not invoices or a serving-profile identity check |
| Knowledge publication | Initial30-file batch verified2026-10-07; final-byte receipt in `work/agent-knowledge/drive-publication.json` | Each publication is accepted only when its saved remote size/SHA-256 readback matches the final local bytes. Consult the latest receipt after updates |

## Build-context extension

The October 7 extension reads actual instruction/configuration sources, accepted build records, supporting procedure code and selected service configuration. Use [BUILD_READINESS.md](BUILD_READINESS.md) for requirement-level acceptance and [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json) for safe source/omission records. The full safe configuration and procedure snapshots are dated evidence copies; maintained sources retain ownership.

Provider reads are scoped and dated in [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md). They do not refresh every workbook row or prove current fleet health. Build status, source completeness, current loading, configured resources and observed execution remain separate. Consult the extension audit receipt before treating its delivery as accepted.

## Dates mean different things

The seven ZIPs were published October 7. Source-file modification times do not become October 7 just because their snapshots were uploaded. The last source timestamp observed for Javar was September 25, Javante September 23 (Detroit timezone), Ops September 21, and CSM/Media/Sales/Finance September 14. Some files have Git dates; others do not. File modification time can reflect a copy or filesystem operation and does not prove a semantic update or running-agent update. Exact observations: `work/agent-build-hub/source-update-dates.json`.

The START_HERE completed-audit date covers this knowledge audit only. Runtime updates, current disk use, active principal/profile mappings, plugin selection, current billing and remote skill distribution need their own evidence. Record them as UNKNOWN/NOT_PROVEN until checked, then enrich the owning record with its exact source and date.

## Source authority

Source workbook and canonical skills retain their existing homes. Role documentation stays in the maintained Build project. This hub contains a readable, dated interpretation with pointers. The generated one-shot briefing is a view of these knowledge files and must be regenerated, never independently edited. Conflicting new observations should be dated and reconciled against the maintained source before replacing a claim.

After a verified fix, write [LESSONS.md](LESSONS.md). Before claiming a completed audit, follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) and update [START_HERE.md](START_HERE.md).
