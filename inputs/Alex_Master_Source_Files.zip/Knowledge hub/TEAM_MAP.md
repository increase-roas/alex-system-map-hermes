# Team map

For continuing a build, read [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](BUILD_READINESS.md). The extension reads the full maintained role contracts, linked implementation and the byte-matched Javar Gameplan/Notes. Later removed/replacement-host evidence is recorded there; the selected snapshots below retain their original dates.

[Start here](START_HERE.md) · [Lessons and maintenance](LESSONS.md)

Reviewed 2026-10-07. Seven role pages summarize 34 allowlisted maintained source files. The professional standard used here is traceable source ownership: one current procedure owner, explicit evidence state, dates and recoverable pointers. This is a knowledge layer, not a runtime deployment.

| Agent / function | Ownership | Source files | Evidence state |
| --- | --- | ---: | --- |
| [Javar](agents/javar.md) | Executive assistant and operating catalog | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Ops](agents/ops.md) | Operational coordination | 2 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [CSM](agents/customer-success.md) | Customer onboarding, health and delivery follow-through | 4 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Media](agents/media.md) | Advertising analysis and creative briefs | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Sales / Hunter / Setter](agents/sales.md) | Hunter research and Setter qualification | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Finance](agents/finance.md) | Company-scoped accounting review preparation | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Javante](agents/javante.md) | Mac mini creative and technical executor | 8 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |

## Proven mapping and unresolved identity

- **Javar:** maintained TOOLS names EA Orgo and its home/work directory; inventory corroborates its computer/workspace metadata. The inventory’s multiple EA profiles remain distinct.
- **Javante:** maintained acceptance maps Sashas-Mac-mini.local to /Users/sashairis/.hermes. Source release 0.21.4 and later October 5 installed-version 0.21.5 observations are dated evidence, not current serving proof.
- **Ops:** historical foundation names an accepted computer. The October 6 SPARE-Ops is a different computer; current Ops placement is unresolved.
- **Customer Success and Media:** inventory proves spare computer/workspace membership only. Placeholder homes and model settings do not prove the serving role identity.
- **Sales:** Hunter is a function in the existing B2B/Setter lane, not a separate runtime. Inventory identifies that lane and /root/.hermes; serving behavior is untested.
- **Finance:** unbound examples and a sanitized purchased-host reference do not establish the actual host/profile/company.

The detail and exact identity evidence are in each role page. Sources: [E1] `work/agent-build-hub-local-manifest.json`; [E2] `work/agent-build-hub/package-verification.json`; [E3] `work/agent-build-hub/source-update-dates.json`; [E4] `outputs/AI_Infrastructure_Gameplan.xlsx`; each role page lists its complete numbered source set.

## Handoff and authority boundaries

Source documents describe Alex → Javar direct execution, explicit delegation → Ops coordination, and role-scoped worker handoffs. Javante preserves a separate Mac identity and receives compact briefs/Drive pointers. Sales audit preparation names Hunter research → Media PDF → Setter draft, with Ops/Javar keeping task evidence. These are documented operating relationships, not a test of present routes. A notification or local task record alone is not completion. Historical source approvals do not authorize this audit to execute any workflow.

## Maintenance and coverage

Use [START_HERE](START_HERE.md) for future audit/update procedure and [LESSONS](LESSONS.md) for corrections and ownership rules. Keep repeatable HOW in the maintained skill/procedure; this map contains only summaries and pointers. Complete source classification/hashes are in `work/agent-knowledge/roles-coverage.json`. Referenced private completion records, source plans, implementations, remote mutable memory/configuration and full role installations were not opened just because these 34 files link to them.

Existing [Agent Builds & Setup hub](https://drive.google.com/drive/folders/1_gIjJUQZ9gXbJGctSRNVeDcImlcLu87w) is recorded by [E5] `work/agent-build-hub/drive-state.json`; role pages preserve its folder/shortcut pointers. Links are recorded metadata, not a fresh access check.
