# Procedures and dependency closure

Audit scope: lane3 of `docs/plans/2026-10-07-build-context-completion-plan.md`, read-only local source capture on 2026-10-07. **PARTIAL dependency closure; selected source delivery verified separately.** Full safe source text is in [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md). Canonical paths below retain ownership; this snapshot is evidence and must not become a competing procedure store.

[E1] `work/build-context/procedures/coverage.json` — exact source IDs, resolved paths, source modification time, actual read timestamp, bytes and SHA-256. [E2] `work/build-context/procedures/dependency-closure.json` — every captured literal file reference plus explicit package/runtime/publication dependencies. [E3] `work/build-context/procedures/materializer-hash-check.json` — read-only accepted-source comparison. No procedure, hook, installer, credential retrieval, model call, runtime command or service was run.

## WORKING_LAYER_SUMMARY

**Written/source-observed:** 167 full safe source snapshots, including the eight configured Codex/Claude/Cursor hook scripts and maintained `agents/ea/capability-discovery/1Password-Config.md`. Hook declarations remain owned by [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md); source presence and declared command linkage do not prove execution.

**Configured/seen-working:** no hook, guard, materializer, scheduler, updater or connector was invoked by this lane. Actual runtime loading, guard coverage, serving profile, scheduled delivery and remote source access remain NOT_PROVEN.

**Build dependency blockers:** three accepted materializer source hashes disagree; historical generated Notion wording conflicts with current file catalogs; stock update-package paths and native setup-check paths need serving-state reconciliation. These are static/source findings, not procedure execution results.

**Verifier corrections:** P036 skill-routes.json was recaptured from current bytes; P079/P080 are explicitly historical pre-integration register snapshots. Command operands now resolve to captured executables (including P094 tuneup.py); template/output/project/external references have explicit non-file dispositions. `verifier-corrections.json` records exact new source hashes and dates.

**Maintenance route:** current app card and authorization first; canonical source plus support next; then only the focused real-runtime acceptance for the changed gate. Preserve credentials, failed-attempt history, existing scheduler and remote receipts. Do not convert this documentation package into execution authority.

## Scope and ownership

The existing 353-path catalogue is a source inventory, not a capability count. Full reads here close selected support gaps; they do not prove installed selection, behavior or remote availability. `SKILLS.md`, `HOOKS.md` and `ACCESS_AND_TOOLS.md` were reread as existing registers. Their previous runtime observations remain dated history; this lane performs no fresh provider/runtime refresh.

App cards take precedence over generic skill details. In particular the Composio card requires a named account and schema review; generic CLI examples without an account, mixed send examples, raw proxy examples and auto-link advice are source examples only. Current chat authority and target app gates control any future action. A coded stop must not be routed around.

## Procedure matrix

| Procedure / canonical owner | Inspected support | Result and remaining evidence |
|---|---|---|
| Hermes role setup — `.agents/skills/hermes-team-setup` | reuse map; materializer; baseline; actual guarded inbox files; team client/plugin/package/binding examples | PARTIAL: schema and guards inspected; actual role deployment, Slack binding, native discovery and representative business acceptance not tested. Current accepted-source hashes disagree for three guarded files. |
| Javar tool onboarding — `.agents/skills/javar-add-tool` | startup INDEX/TOOLS/AGENTS/WORKFLOWS; maintained Composio and 1Password guides; app cards | PARTIAL: pointer and smallest-change procedure captured. Installed Orgo guides, actual loader, harmless native operation and owner conversation readback uninspected. |
| Hermes controller — synced Hermes Boss Director source | full local menu/source; current setup/recovery and cards for precedence | PARTIAL: copied controller describes historical app/tool/host routes. Its referenced HERMES-OPS and actual bot session/cost/runtime state are uninspected; do not execute old route commands as current truth. |
| Composio execution/onboarding — `.agents/skills/composio-cli` and `composio-custom-mcp` | CLI troubleshooting/power-user/dev refs; build/connect and acceptance refs; provisioning standard; current card; hub README | SOURCE VERIFIED; behavior NOT_PROVEN: no named-principal execution, connection refresh, key move, login or hosted schema was tested. |
| Connector records — `.agents/skills/tool-card` | all local references; card template; tiers source; publication sync scripts | PARTIAL: publication sequence inspected; credential wrappers/mover, platform APIs, hosted readback and workbook upload receipts excluded/uninspected. |
| Shared lifecycle — `.agents/tools/unify/skill-lifecycle.md` | manifest/checker; instruction builder; unify/dependency/plugin drift tools; git setup; pre/post commit sources | SOURCE VERIFIED; configured versus effective selection still separate. No lifecycle command, build/apply, setup, commit hook or target invocation performed. Configuration source ownership belongs to configuration lane. |
| Update/rollback — Build `agents/ea/runtime-update` | README; manifest; update_runtime.py; selected package plugin/profile markdown assets | PARTIAL: reviewed source and dependencies captured. Credential launcher/raw profile config, remote upstream checkout/venv/backup/service state, pinned upstream tests and installed runtime are uninspected. |
| Startup/scheduler/recovery — Build `agents/ea/startup`, `setup-check`, `maintenance` | heartbeat troubleshooting; setup-check SOP/checker/intended-state; upkeep entry/implementation; instruction consistency source | SOURCE VERIFIED; scheduled behavior NOT_PROVEN: job registry, last result, streak, delivery, pending packets and installed instruction hashes require remote collection and local combine. A direct script success or running supervisor does not prove delivery/reboot persistence. |
| Handoff and maintenance — `.agents/skills/ce-handoff`, `weekly-tuneup` | create/resume refs; tuneup refs and script | SOURCE VERIFIED; no handoff workflow or tuneup executed. Held-out grader material intentionally remains unread. No recurring job created. |

## Concrete conflicts and constraints

1. **BLOCKED (goal_not_met_yet): materializer guard.** Three source hashes disagree with the accepted baseline: `__init__.py`, `tasks.py`, `plugin.yaml`; `knowledge.py` and `approval_store.py` match. The script refuses any mismatch before writing a candidate. [E3] proves this read-only comparison; it is not a materializer execution result. Recover the accepted source or review changed source and obtain new component acceptance before refreshing the guard. Do not remove the guard.
2. The materializer generated SOUL text still says build status belongs to Notion, while current `hermes-team-setup` and `javar-add-tool` use file INDEX/TOOLS and retain retired records only as history. This is a source conflict, not authorization to repair it in this lane.
3. The update package manifest names `hermes-agent-javar-0.21.4-stock` / `venv-0.21.4-py311-stock`, while setup-check operator instructions collect with `venv-0.21.4-py311-native`. The manifest is a package target, not fresh serving identity proof. Resolve the exact installed role/profile and reviewed active path before a switch.
4. The update manifest pins upstream tag `v2026.9.21`, commit `d337b736aa1e8ebecfab043842d13e4a2d2f48a3`, Python `3.11.15` and SQLite minimum `3.51.3`; this lane records source declarations, not installed versions.
5. The setup checker combines a remote report with maintained source only after validating exact manifest hash, freshness, schema and completeness. It separates deployment/source/gap status and cannot prove model acceptance, tool execution, cost caps or instruction reading. Its trusted transport is consistency evidence, not cryptographic attestation.
6. Post-commit dispatch starts asynchronously. Skills-only changes invoke local lifecycle acceptance; cards/instructions trigger sync_notes then instruction apply then cards_to_sheet only after prior success. A successful commit or launched process is not publication completion. No hook was run.
7. Knowledge upkeep recovery resumes a pending packet with bounded retries; instruction consistency reuses the existing daily digest. Do not reset cursors, regenerate intended-state from drifted deployment, or add replacement schedulers to hide an error.

## Configured hook source linkage

The configuration lane captured safe declarations in `.codex/hooks.json`, `.claude/settings.json`, `.cursor/hooks.json` and safe Codex configuration. This lane now captures full safe implementations for Codex/Claude/Cursor Herdr session hooks, Codex/Cursor Composio adapters, shared Composio/chat guards and Cursor `hooks/deny-fast-subagent.sh` (P131–P138). The guards import `composio_guard.py`; source imports are captured. No guard was imported or run by these capture scripts.

Herdr implementations are managed socket-state publishers whose environment prerequisites and payloads remain source evidence. Codex/Cursor adapters reshape native payloads for the common Composio guard; Cursor has no approval release path, while Codex source limits release to its explicit environment-controlled interactive transcript path. The chat guard handles chat/memory growth and handoff gating. Cursor fast-subagent source tests the exact model identifier `fast`, not arbitrary names containing those letters. These descriptions explain code only; no functional guard coverage or hook effectiveness is claimed.

The maintained 1Password guide P139 was read at its actual capability-discovery path. It contains reference paths and dated historical access/repair claims, not secret values. It does not prove current vault access, current connection status or another role’s permission. The prior incorrect Build-root lookups remain failed discovery history and are superseded for documentation by P093 and P139.

## Implementation-linked procedure closure

[E5] `work/build-context/procedures/implementation-deferred-closure.json` closes all 23 incoming references across 15 unique paths: 21 reference rows have full safe procedure captures, one is an existing configuration-lane capture of Build AGENTS, and one is **MISSING_LOCAL_SOURCE** at `agents/javante/setup/skills/productivity/javante-ghl/SKILL.md`. The unavailable exact path is retained; it is not silently replaced by a different skill. No reference remains deferred to an unnamed owner.

The new sources include Javante GHL workflow, Meta and Google procedures with business-access/cloud-bridge support; EA Native/GHL/Meta and on-demand route guides; the sales-agent core and its data/safety/runtime references; safe dataset/guard/send-hook/simulation/skill/config templates; synthetic scenario fixtures; and the dataset builder’s actual contract-module dependency. Direct source support is captured or cross-linked without reopening raw client data or hidden holdouts. System review-agent remains provider-owned and was read only; no review workflow or helper was invoked.

All dated access, authentication, catalog counts and acceptance narratives inside these guides remain historical source claims. Javante’s shared GHL Command cloud installation and company OAuth gateway are distinct; local source does not prove either current connection. Google browser access does not establish Google CLI OAuth. Sales templates remain shadow/log delivery examples requiring current runtime-key verification and actual schema/data adaptation before use. The dataset builder hardcodes example source/output paths and imports the recorded sales_contract module; its script was not run.

**BLOCKED (missing_evidence):** the exact Javante productivity GHL skill path is absent. **Outside this documentation scope:** raw conversation exports, buyer labels, live credential state, held-out cases, installed loaders and current provider probes. These exclusions do not prevent source delivery, but they prevent claiming a ready sales runtime or current business access.

Hash check label in [E3]: `MISMATCH_OR_MISSING` versus `MATCH`.
[E4] `work/build-context/procedures/runtime-package-hash-check.json`: 34 captured package hashes match the runtime manifest; four members remain UNINSPECTED (credential launcher, gateway launcher, raw Manny profile config and empty marker). This comparison does not run verify_package or prove installed bytes.
## Exact source coverage

| ID | Canonical/read path | Group | State | Bytes |
|---|---|---|---|---|
| P001 | `/Users/alexlobaito/.agents/skills/hermes-team-setup/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 6726 |
| P002 | `/Users/alexlobaito/.agents/skills/javar-add-tool/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 5865 |
| P003 | `/Users/alexlobaito/.agents/skills/composio-cli/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 5939 |
| P004 | `/Users/alexlobaito/.agents/skills/composio-custom-mcp/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 8493 |
| P005 | `/Users/alexlobaito/.agents/skills/tool-card/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 3569 |
| P006 | `/Users/alexlobaito/.agents/skills/ce-handoff/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 6198 |
| P007 | `/Users/alexlobaito/.agents/skills/weekly-tuneup/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 7528 |
| P008 | `/Users/alexlobaito/.agents/skills/verify-before-done/SKILL.md` | core procedure | READ_FULL_SAFE_TEXT | 4386 |
| P009 | `/Users/alexlobaito/.agents/skills/synced/b9a4d135-f5b9-4e7a-9206-aa19c0f16762_9128974b-7478-4108-a088-7310e0ed93c7/hermes-boss-director/SKILL.md` | core pointer procedure | READ_FULL_SAFE_TEXT | 14262 |
| P010 | `/Users/alexlobaito/.agents/tools/unify/skill-lifecycle.md` | core lifecycle | READ_FULL_SAFE_TEXT | 8480 |
| P011 | `/Users/alexlobaito/.agents/tools/cards/composio.md` | app card | READ_FULL_SAFE_TEXT | 4993 |
| P012 | `/Users/alexlobaito/.agents/tools/cards/google-workspace.md` | app card | READ_FULL_SAFE_TEXT | 5941 |
| P013 | `/Users/alexlobaito/.agents/tools/cards/ghl.md` | app card | READ_FULL_SAFE_TEXT | 3150 |
| P014 | `/Users/alexlobaito/.agents/tools/cards/cloudflare.md` | app card | READ_FULL_SAFE_TEXT | 2265 |
| P015 | `/Users/alexlobaito/.agents/tools/cards/slack.md` | app card | READ_FULL_SAFE_TEXT | 1771 |
| P016 | `/Users/alexlobaito/.agents/tools/cards/browser-and-computer.md` | app card | READ_FULL_SAFE_TEXT | 3006 |
| P017 | `/Users/alexlobaito/.agents/tools/cards/exa.md` | app card | READ_FULL_SAFE_TEXT | 3565 |
| P018 | `/Users/alexlobaito/.agents/tools/cards/firecrawl.md` | app card | READ_FULL_SAFE_TEXT | 4466 |
| P019 | `/Users/alexlobaito/.agents/skills/hermes-team-setup/references/reuse-map.md` | procedure support | READ_FULL_SAFE_TEXT | 2133 |
| P020 | `/Users/alexlobaito/.agents/skills/composio-cli/references/composio-dev.md` | procedure support | READ_FULL_SAFE_TEXT | 1916 |
| P021 | `/Users/alexlobaito/.agents/skills/composio-cli/references/power-user-examples.md` | procedure support | READ_FULL_SAFE_TEXT | 3842 |
| P022 | `/Users/alexlobaito/.agents/skills/composio-cli/references/troubleshooting.md` | procedure support | READ_FULL_SAFE_TEXT | 3689 |
| P023 | `/Users/alexlobaito/.agents/skills/composio-custom-mcp/references/acceptance.md` | procedure support | READ_FULL_SAFE_TEXT | 5441 |
| P024 | `/Users/alexlobaito/.agents/skills/composio-custom-mcp/references/build-and-connect.md` | procedure support | READ_FULL_SAFE_TEXT | 9152 |
| P025 | `/Users/alexlobaito/.agents/skills/tool-card/references/card-and-logs.md` | procedure support | READ_FULL_SAFE_TEXT | 6062 |
| P026 | `/Users/alexlobaito/.agents/skills/tool-card/references/cli-wrapper.md` | procedure support | READ_FULL_SAFE_TEXT | 4352 |
| P027 | `/Users/alexlobaito/.agents/skills/tool-card/references/key-capture.md` | procedure support | READ_FULL_SAFE_TEXT | 8648 |
| P028 | `/Users/alexlobaito/.agents/skills/tool-card/references/route-compare.md` | procedure support | READ_FULL_SAFE_TEXT | 6165 |
| P029 | `/Users/alexlobaito/.agents/skills/tool-card/references/tools-and-tiers.md` | procedure support | READ_FULL_SAFE_TEXT | 2552 |
| P030 | `/Users/alexlobaito/.agents/skills/ce-handoff/references/create.md` | procedure support | READ_FULL_SAFE_TEXT | 7199 |
| P031 | `/Users/alexlobaito/.agents/skills/ce-handoff/references/resume.md` | procedure support | READ_FULL_SAFE_TEXT | 6526 |
| P032 | `/Users/alexlobaito/.agents/skills/weekly-tuneup/references/after-approval.md` | procedure support | READ_FULL_SAFE_TEXT | 1280 |
| P033 | `/Users/alexlobaito/.agents/skills/weekly-tuneup/references/promotion-and-pruning.md` | procedure support | READ_FULL_SAFE_TEXT | 3387 |
| P034 | `/Users/alexlobaito/.agents/tools/unify/build_instructions.py` | local tooling support | READ_FULL_SAFE_TEXT | 10426 |
| P035 | `/Users/alexlobaito/.agents/tools/unify/skill_lifecycle.py` | local tooling support | READ_FULL_SAFE_TEXT | 11180 |
| P036 | `/Users/alexlobaito/.agents/tools/unify/skill-routes.json` | local tooling support | READ_FULL_SAFE_TEXT | 3135 |
| P037 | `/Users/alexlobaito/.agents/tools/unify/skill_deps.py` | local tooling support | READ_FULL_SAFE_TEXT | 16516 |
| P038 | `/Users/alexlobaito/.agents/tools/unify/check.py` | local tooling support | READ_FULL_SAFE_TEXT | 6006 |
| P039 | `/Users/alexlobaito/.agents/tools/unify/unify.py` | local tooling support | READ_FULL_SAFE_TEXT | 9523 |
| P040 | `/Users/alexlobaito/.agents/tools/unify/codex_plugins.py` | local tooling support | READ_FULL_SAFE_TEXT | 9821 |
| P041 | `/Users/alexlobaito/.agents/tools/unify/codex-plugins.json` | local tooling support | READ_FULL_SAFE_TEXT | 1467 |
| P042 | `/Users/alexlobaito/.agents/tools/unify/git_setup.sh` | local tooling support | READ_FULL_SAFE_TEXT | 2848 |
| P043 | `/Users/alexlobaito/.agents/tools/unify/hooks/pre-commit` | hook source | READ_FULL_SAFE_TEXT | 5776 |
| P044 | `/Users/alexlobaito/.agents/tools/unify/hooks/post-commit` | hook source | READ_FULL_SAFE_TEXT | 2869 |
| P045 | `/Users/alexlobaito/.agents/tools/connectors/ir_notes/sync_notes.py` | publication support | READ_FULL_SAFE_TEXT | 4009 |
| P046 | `/Users/alexlobaito/.agents/tools/connectors/cards_to_sheet.py` | publication support | READ_FULL_SAFE_TEXT | 7274 |
| P047 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/README.md` | role setup support | READ_FULL_SAFE_TEXT | 4284 |
| P048 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/materialize.py` | role setup support | READ_FULL_SAFE_TEXT | 8613 |
| P049 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team_client.py` | role setup support | READ_FULL_SAFE_TEXT | 10815 |
| P050 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/package-team-plugin.py` | role setup support | READ_FULL_SAFE_TEXT | 1550 |
| P051 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/package-worker-plugin.py` | role setup support | READ_FULL_SAFE_TEXT | 1036 |
| P052 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team_dispatch.py` | role setup support | READ_FULL_SAFE_TEXT | 1223 |
| P053 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/delegated_worker.py` | role setup support | READ_FULL_SAFE_TEXT | 8658 |
| P054 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/war-room-auth-overlay.md` | role setup support | READ_FULL_SAFE_TEXT | 1836 |
| P055 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-binding.example.json` | role setup support | READ_FULL_SAFE_TEXT | 647 |
| P056 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/worker-registry.example.json` | role setup support | READ_FULL_SAFE_TEXT | 793 |
| P057 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/plugins/agency-foundation/__init__.py` | materializer support | READ_FULL_SAFE_TEXT | 2493 |
| P058 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/plugins/agency-foundation/tasks.py` | materializer support | READ_FULL_SAFE_TEXT | 7592 |
| P059 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/plugins/agency-foundation/approval_store.py` | materializer support | READ_FULL_SAFE_TEXT | 4435 |
| P060 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/plugins/agency-foundation/plugin.yaml` | materializer support | READ_FULL_SAFE_TEXT | 125 |
| P061 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/ops-candidate/plugins/agency-foundation/binding.example.json` | materializer support | READ_FULL_SAFE_TEXT | 613 |
| P062 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team-plugin/__init__.py` | team plugin support | READ_FULL_SAFE_TEXT | 11981 |
| P063 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team-plugin/__pycache__` | team plugin support | UNINSPECTED | — |
| P064 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team-plugin/plugin.yaml` | team plugin support | READ_FULL_SAFE_TEXT | 183 |
| P065 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team-bindings/ea_javar.example.json` | team binding template | READ_FULL_SAFE_TEXT | 539 |
| P066 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/team-template/team-bindings/ops_orchestration.example.json` | team binding template | READ_FULL_SAFE_TEXT | 444 |
| P067 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/accepted-baseline.json` | accepted-source guard | READ_FULL_SAFE_TEXT | 2260 |
| P068 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/README.md` | runtime recovery support | READ_FULL_SAFE_TEXT | 2966 |
| P069 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/manifest.json` | runtime recovery support | READ_FULL_SAFE_TEXT | 9149 |
| P070 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/update_runtime.py` | runtime recovery support | READ_FULL_SAFE_TEXT | 21616 |
| P071 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/AGENTS.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 8688 |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/INDEX.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 5838 |
| P073 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/TOOLS.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 7717 |
| P074 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/WORKFLOWS.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 5870 |
| P075 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/HEARTBEAT.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 1652 |
| P076 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/HEARTBEAT-TROUBLESHOOTING.md` | startup scheduler support | READ_FULL_SAFE_TEXT | 3241 |
| P077 | `/Users/alexlobaito/Documents/ChatGPT/Build/Composio.md` | connection documentation | UNINSPECTED | — |
| P078 | `/Users/alexlobaito/Documents/ChatGPT/Build/1Password-Config.md` | connection documentation | UNINSPECTED | — |
| P079 | `/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-knowledge/SKILLS.md` | existing register | READ_FULL_SAFE_TEXT | 9364 |
| P080 | `/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-knowledge/HOOKS.md` | existing register | READ_FULL_SAFE_TEXT | 6772 |
| P081 | `/Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering/outputs/agent-knowledge/ACCESS_AND_TOOLS.md` | existing register | READ_FULL_SAFE_TEXT | 4336 |
| P082 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/hermes-inbox/tasks.py` | accepted materializer source | READ_FULL_SAFE_TEXT | 10437 |
| P083 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/hermes-inbox/knowledge.py` | accepted materializer source | READ_FULL_SAFE_TEXT | 2567 |
| P084 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/hermes-inbox/approval_store.py` | accepted materializer source | READ_FULL_SAFE_TEXT | 4435 |
| P085 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/hermes-inbox/__init__.py` | accepted materializer source | READ_FULL_SAFE_TEXT | 84499 |
| P086 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/hermes-inbox/plugin.yaml` | accepted materializer source | READ_FULL_SAFE_TEXT | 351 |
| P087 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/setup-check/javar_setup_check.py` | linked critical support | READ_FULL_SAFE_TEXT | 33621 |
| P088 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/setup-check/intended-state.json` | linked critical support | READ_FULL_SAFE_TEXT | 19747 |
| P089 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/sops/JAVAR-SETUP-CHECK.md` | linked critical support | READ_FULL_SAFE_TEXT | 6503 |
| P090 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/maintenance/instruction_consistency.py` | linked critical support | READ_FULL_SAFE_TEXT | 7155 |
| P091 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/maintenance/knowledge_upkeep.py` | linked critical support | READ_FULL_SAFE_TEXT | 9720 |
| P092 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/maintenance/knowledge_upkeep_job.py` | linked critical support | READ_FULL_SAFE_TEXT | 363 |
| P093 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Composio.md` | linked critical support | READ_FULL_SAFE_TEXT | 4568 |
| P094 | `/Users/alexlobaito/.agents/skills/weekly-tuneup/scripts/tuneup.py` | linked critical support | READ_FULL_SAFE_TEXT | 11983 |
| P095 | `/Users/alexlobaito/Projects/master-connector-repo/knowledge/connector-provisioning.md` | linked critical support | READ_FULL_SAFE_TEXT | 6393 |
| P096 | `/Users/alexlobaito/.agents/tools/connectors/hub/README.md` | linked critical support | READ_FULL_SAFE_TEXT | 3969 |
| P097 | `/Users/alexlobaito/Projects/master-connector-repo/work/2026-10-01_setup-playbook/candidates/app-rules/card-template.md` | linked critical support | READ_FULL_SAFE_TEXT | 2149 |
| P098 | `/Users/alexlobaito/.agents/skills/repo-conform/assets/skeleton/tools/README.md` | linked critical support | READ_FULL_SAFE_TEXT | 8297 |
| P099 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/__init__.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 79707 |
| P100 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/approval_store.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 4435 |
| P101 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/checkpoints.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 12044 |
| P102 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/colleague_access.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 10971 |
| P103 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/coordination.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 4598 |
| P104 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/delegation_recovery.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 1626 |
| P105 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/delegation_returns.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 6282 |
| P106 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/execution_scope.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 14698 |
| P107 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/__init__.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 316 |
| P108 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/authority.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 1263 |
| P109 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/bindings.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 4868 |
| P110 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/bootstrap.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 2531 |
| P111 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/catalog.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 3511 |
| P112 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/composio_mcp.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 18276 |
| P113 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/composio_upload.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 6131 |
| P114 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/discovery.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 5268 |
| P115 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/dynamic_composio.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 13094 |
| P116 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/ghl_adapter.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 16424 |
| P117 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/meta_adapter.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 24530 |
| P118 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/meta_cli_runner.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 8609 |
| P119 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/providers.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 4218 |
| P120 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/request_scope.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 3705 |
| P121 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/source_adapter.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 3478 |
| P122 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/toolbox.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 11287 |
| P123 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/javar_isolation/visual_review.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 2357 |
| P124 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/knowledge.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 2567 |
| P125 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/plugin.yaml` | runtime manifest asset | READ_FULL_SAFE_TEXT | 351 |
| P126 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/rag_approval.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 1872 |
| P127 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/javar-inbox/tasks.py` | runtime manifest asset | READ_FULL_SAFE_TEXT | 10437 |
| P128 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/manny-profile/AGENTS.md` | runtime manifest asset | READ_FULL_SAFE_TEXT | 604 |
| P129 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/manny-profile/CONTINUITY.md` | runtime manifest asset | READ_FULL_SAFE_TEXT | 387 |
| P130 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/manny-profile/SOUL.md` | runtime manifest asset | READ_FULL_SAFE_TEXT | 705 |
| P131 | `/Users/alexlobaito/.codex/herdr-agent-state.sh` | configured hook support | READ_FULL_SAFE_TEXT | 2965 |
| P132 | `/Users/alexlobaito/.agents/tools/guards/codex_composio_guard.py` | configured hook support | READ_FULL_SAFE_TEXT | 8783 |
| P133 | `/Users/alexlobaito/.claude/hooks/herdr-agent-state.sh` | configured hook support | READ_FULL_SAFE_TEXT | 3070 |
| P134 | `/Users/alexlobaito/.agents/tools/guards/chat_guard.py` | configured hook support | READ_FULL_SAFE_TEXT | 18242 |
| P135 | `/Users/alexlobaito/.agents/tools/guards/composio_guard.py` | configured hook support | READ_FULL_SAFE_TEXT | 87543 |
| P136 | `/Users/alexlobaito/.cursor/herdr-agent-state.sh` | configured hook support | READ_FULL_SAFE_TEXT | 1520 |
| P137 | `/Users/alexlobaito/.agents/tools/guards/cursor_composio_guard.py` | configured hook support | READ_FULL_SAFE_TEXT | 7905 |
| P138 | `/Users/alexlobaito/.cursor/hooks/deny-fast-subagent.sh` | configured hook support | READ_FULL_SAFE_TEXT | 609 |
| P139 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/1Password-Config.md` | maintained credential-route documentation | READ_FULL_SAFE_TEXT | 9338 |
| P140 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/skills/hermes-team-setup/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 360 |
| P141 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/marketing-operations/javante-ghl-workflows/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 2835 |
| P142 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/GHL-Route.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 13989 |
| P143 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Meta-CLI.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 7891 |
| P144 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/marketing-operations/javante-meta-ads-cli/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 1773 |
| P145 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/productivity/javante-ghl/SKILL.md` | implementation-deferred core procedure | UNINSPECTED | — |
| P146 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/productivity/javante-google-workspace-cli/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 2209 |
| P147 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Native-Routes.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 7283 |
| P148 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/README.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 3471 |
| P149 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 8710 |
| P150 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/references/data-pipeline.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 3659 |
| P151 | `/Users/alexlobaito/.codex/skills/.system/review-agent/SKILL.md` | implementation-deferred core procedure | READ_FULL_SAFE_TEXT | 2661 |
| P152 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Analytics.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 1308 |
| P153 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/GTM-Route.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 1259 |
| P154 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/GA4-Admin-Route.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 879 |
| P155 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Cloudflare-Route.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 6023 |
| P156 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/GoogleAds-Route.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 583 |
| P157 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/capability-discovery/Manny-Access.md` | EA on-demand route support | READ_FULL_SAFE_TEXT | 4225 |
| P158 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/references/runtime-hermes.md` | sales procedure support | READ_FULL_SAFE_TEXT | 2724 |
| P159 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/references/safety-and-evals.md` | sales procedure support | READ_FULL_SAFE_TEXT | 3434 |
| P160 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/references/sources.md` | sales procedure support | READ_FULL_SAFE_TEXT | 2116 |
| P161 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/build_sales_dataset.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 20590 |
| P162 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/charts.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 8144 |
| P163 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/core-skill.SKILL.md.example` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 4119 |
| P164 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/guard.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 6664 |
| P165 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/offer-facts.SKILL.md.example` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 2895 |
| P166 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/profile-config.yaml` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 4038 |
| P167 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/scenarios.jsonl` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 4082 |
| P168 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/send_guard_hook.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 5506 |
| P169 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/simulate.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 8312 |
| P170 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/test_guard.py` | sales procedural template or synthetic scenario fixture | READ_FULL_SAFE_TEXT | 3504 |
| P171 | `/Users/alexlobaito/Documents/Codex/2026-10-03/openai-director/outputs/javar-gameplan-v1/sales-contract/sales_contract.py` | dataset builder required contract import | READ_FULL_SAFE_TEXT | 27792 |

## Dependency register and exclusions

Every captured backtick file reference and every manifest package member has a row in [E2]. Literal references include output examples, historical pointers and dynamic paths; they are retained without claiming all are prerequisites. The register resolves obvious home/Build-relative references, records exact owner IDs and observed read states, and classifies ambiguous project/basename references without manufacturing filesystem targets. Source-code standard-library imports are runtime prerequisites, not separate captured files. Deep plugin implementation and all role/provider source recursion are outside this selected procedure lane; their source facts belong to implementation/services lanes.

| Owner | Required target | Disposition | Reason / evidence |
|---|---|---|---|
| P001 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P001 | `/Users/alexlobaito/Documents/ChatGPT/Build/BUILD_STATUS.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P001 | `auth.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P001 | `shared/nous_auth.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P002 | `/home/orgo/lil-smoove/workspace/AGENTS.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P002 | `1Password-Config.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P002 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P002 | `Composio.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P002 | `INDEX.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P002 | `TOOLS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P002 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/skills/javar-add-tool/SKILL.md` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P005 | `<tool>_op.py` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P005 | `system/lessons.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `STATUS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/evals/README.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/evals/golden-tasks.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/evals/held-out.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/lessons.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/proposals/README.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/proposals/YYYY-MM-DD.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `system/run-log.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `tools/_fingerprints.json` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `tools/_fingerprints.new.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `tools/_incidents.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P007 | `tools/_inventory.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `STATUS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `checks.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `knowledge/business.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `knowledge/offers.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `work/<job>/brief.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `work/<job>/checks.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P008 | `work/_template/checks.md` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P010 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P010 | `CLAUDE.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P010 | `SKILL.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P010 | `/Users/alexlobaito/.agents/instructions/shared.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P010 | `~/.agents/tools/cards/<app>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P010 | `/Users/alexlobaito/.codex/skills/.system/skill-creator/SKILL.md` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P012 | `/Users/alexlobaito/Projects/master-connector-repo/knowledge/workbook-drive.json` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P012 | `2026-10-03/do/work/drive-resumable-fix/archive-upload-receipt.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P016 | `tools/_incidents.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P018 | `firecrawl_op.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P018 | `work/2026-10-01_setup-playbook/notes/firecrawl-connector.md` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P019 | `agents/<role>/SOUL.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P019 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/knowledge.py` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P019 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/finance/QUICKBOOKS.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P019 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/media/meta-safe.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P019 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/FINANCE-ROLLOUT-PREP.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P019 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/evidence/runs/2026-09-10-core-completion-finance-prep.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P025 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `server.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `system/run-log.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `tools/<family>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `tools/<name>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `tools/_card-template.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `workbook-updates.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P025 | `/Users/alexlobaito/.agents/instructions/shared.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P025 | `~/.agents/tools/cards/<name>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P026 | `/Users/alexlobaito/.agents/tools/connectors/test_fresh_vault.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P026 | `~/.agents/tools/connectors/<tool>_op.py` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P026 | `~/.agents/tools/connectors/test_<tool>_op.py` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P029 | `setup/02-app-settings.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P029 | `tools/_incidents.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P029 | `tools/_inventory.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P030 | `$HANDOFF_DIR/<topic>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P032 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P032 | `system/CHANGELOG.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P032 | `system/snapshots/README.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P033 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P033 | `SKILL.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P033 | `system/lessons.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P047 | `/Users/alexlobaito/Documents/ChatGPT/Build/.local-preserved/archive/agents/ea/accepted-baseline.json` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P068 | `config.yaml` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P071 | `/home/orgo/lil-smoove/home/agent-knowledge/INDEX.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P071 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/KNOWLEDGE.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P071 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/SOUL.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P071 | `credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P071 | `start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P072 | `.hermes/memories/MEMORY.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `/home/orgo/lil-smoove/home/.hermes/AGENTS.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P072 | `/home/orgo/lil-smoove/home/.hermes/SOUL.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P072 | `/home/orgo/lil-smoove/home/.hermes/memories/MEMORY.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P072 | `/home/orgo/lil-smoove/home/.hermes/memories/USER.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P072 | `01-Agency/agent-os/JAVAR-SETUP-CHECK.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/DISCORD-SERVERS.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/IDENTITY.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/KNOWLEDGE.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P072 | `MEMORY.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/SOUL.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P072 | `USER.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/SOUL.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P072 | `memory/YYYY-MM-DD.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `memory/archive/2026-09-22-external-javar-history.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `notes/areas/capability-wishlist.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `notes/areas/outcome-journal.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `notes/areas/proactive-ideas.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `notes/areas/recurring-patterns.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `workspace/AGENTS.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/DISCORD-SERVERS.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/HEARTBEAT-TROUBLESHOOTING.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/HEARTBEAT.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/IDENTITY.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/INDEX.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/KNOWLEDGE.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/TOOLS.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P072 | `~/agent-knowledge/WORKFLOWS.md` | ROLE_HOME_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `/home/orgo/lil-smoove/home/agent-knowledge/INDEX.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P073 | `01-Agency/agent-os/1Password-Config.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Analytics.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Cloudflare-Route.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Composio.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/GA4-Admin-Route.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/GHL-Route.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/GTM-Route.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/GoogleAds-Route.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Manny-Access.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Meta-CLI.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `01-Agency/agent-os/Native-Routes.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `Composio.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P073 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/KNOWLEDGE.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P074 | `.hermes/scripts/daily-digest/instruction_consistency.py` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P074 | `.hermes/scripts/knowledge-upkeep/knowledge_upkeep.py` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P074 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/startup/KNOWLEDGE.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P074 | `memory/*.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P074 | `notes/areas/*.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P075 | `/home/orgo/lil-smoove/home/.hermes/cron/jobs.json` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P076 | `.hermes/cron/instruction-consistency-state.json` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P076 | `.hermes/knowledge-upkeep/state.json` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P076 | `01-Agency/agent-os/JAVAR-SETUP-CHECK.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P079 | `work/agent-knowledge/skill-content-overlap.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P079 | `work/agent-knowledge/skills-hooks-coverage.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P080 | `/Users/alexlobaito/.claude/settings.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P080 | `/Users/alexlobaito/.claude/settings.local.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P080 | `/Users/alexlobaito/.cursor/settings.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P080 | `work/agent-knowledge/skills-hooks-coverage.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P081 | `/Users/alexlobaito/.agents/tools/cards/<app>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P081 | `/Users/alexlobaito/.agents/tools/connectors/google_robot/drive_upload_file.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P081 | `/Users/alexlobaito/Projects/master-connector-repo/knowledge/workbook-drive.json` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P081 | `work/agent-knowledge/route-events.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `/tmp/javar-setup-observed.json` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `1Password-Config.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `INDEX.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `TOOLS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `WORKFLOWS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `config.yaml` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P089 | `credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P089 | `start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P095 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P095 | `work/2026-10-06_connector-provisioning-standard/proposed-changes.md` | OUTPUT_EXAMPLE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `/Users/alexlobaito/.agents/tools/connectors/op_items.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P096 | `/Users/alexlobaito/.agents/tools/connectors/orgo_op.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P096 | `/root/.cloudflared/<tunnel>.json` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `VERSIONS.json` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `capture_hub.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `cf/config.yml` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `config.json` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `ga4-admin-run.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `google_robot/server.py` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `health/health_check.py` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `health/loop.sh` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `health/state.json` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `install_hub.sh` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `rebuild_hub.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `routes.json` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `tools/*.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `tools/cards/*.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P096 | `tools/connectors/ir_notes/server.py` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `.agents/skills/README.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `setup/02-app-settings.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/<family>.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/_card-template.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/_incidents.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/_inventory.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/browser-and-computer.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/exa.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P098 | `tools/web-search.md` | PROJECT_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P139 | `mcp-servers/ghl-command/credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P139 | `reply-alert-health.py` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P139 | `start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P141 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/tools/ghl-command-cloud/README.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P142 | `.ghl-tokens.json` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P142 | `credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P142 | `/Users/alexlobaito/Documents/ChatGPT/Build/docs/sops/chatgpt-ghl-plugin-talks-to-orgo.md` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P142 | `start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P144 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/tools/business-access/README.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P146 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/tools/business-access/README.md` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| P147 | `.hermes/mcp-servers/ghl-command/credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P147 | `.hermes/start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P147 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P147 | `SOUL.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P147 | `config.yaml` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `/home/orgo/lil-smoove/home/agent-knowledge/TOOLS.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| P148 | `1password→1Password-Config.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `SOUL.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `analytics→Analytics.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `cloudflare→Cloudflare-Route.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `composio→Composio.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `credentials.json` | SAFETY_EXCLUDED | Credential/auth/.env source: not opened or hashed |
| P148 | `ga4-admin→GA4-Admin-Route.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `ghl→GHL-Route.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `google-ads→GoogleAds-Route.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `gtm→GTM-Route.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `javar-setup-intended-state.json` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `meta→Meta-CLI.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `native→Native-Routes.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `routing→TOOLS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P148 | `start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| P149 | `.work/<task>-notes.md` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P151 | `AGENTS.md` | UNRESOLVED_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P158 | `$HERMES_HOME/data/<name>-ledger/<session>.json` | TEMPLATE_REFERENCE | Literal template/output/example/external or unresolved project reference retained without manufacturing a filesystem target; not a claimed missing file |
| P163 | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations/templates/dynamite-example/scripts/guard.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| P165 | `/Users/alexlobaito/dynamite-lighting/BUSINESS.md` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| configured hook linkage | `/Users/alexlobaito/.codex/hooks.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| configured hook linkage | `/Users/alexlobaito/.claude/settings.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| configured hook linkage | `/Users/alexlobaito/.cursor/hooks.json` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| configured hook linkage | `/Users/alexlobaito/.codex/config.toml` | CROSS_LANE_CAPTURE | Safe snapshot is owned by implementation/configuration lane; source presence and effective behavior are different evidence |
| I421 | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/productivity/javante-ghl/SKILL.md` | MISSING_LOCAL_SOURCE | [Errno 2] No such file or directory: '/Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/skills/productivity/javante-ghl/SKILL.md' |
| I760 | `/Users/alexlobaito/Documents/ChatGPT/Build/AGENTS.md` | CROSS_LANE_CAPTURE | Existing safe capture owned by implementation/configuration lane; not reread |
| sales data pipeline source | `lighting-conversation-library raw CRM/messages/contact exports` | DATA_EXCLUDED | No client archive, buyer labels, hidden holdout or auth state read; adaptation still needs actual approved data sources |
| sales data pipeline source | `lighting-conversations-categorized buyer labels` | DATA_EXCLUDED | No client archive, buyer labels, hidden holdout or auth state read; adaptation still needs actual approved data sources |
| sales data pipeline source | `salesbench hidden holdout cases` | DATA_EXCLUDED | No client archive, buyer labels, hidden holdout or auth state read; adaptation still needs actual approved data sources |
| sales data pipeline source | `runtime/auth credential state and files` | DATA_EXCLUDED | No client archive, buyer labels, hidden holdout or auth state read; adaptation still needs actual approved data sources |
| runtime-update/manifest.json | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/manny-profile/.no-bundled-skills` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| runtime-update/manifest.json | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/manny-profile/config.yaml` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| runtime-update/manifest.json | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/messaging-gateway-run.sh` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| runtime-update/manifest.json | `/Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/runtime-update/assets/start-with-secrets.py` | SAFETY_EXCLUDED | Credential launcher or raw profile configuration excluded from export; exact manifest reference retained |
| remote procedure dependency | `/home/orgo/lil-smoove/workspace/AGENTS.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/home/agent-knowledge/01-Agency/agent-os/1Password-Config.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/home/agent-knowledge/01-Agency/agent-os/Native-Routes.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/home/.hermes/cron/jobs.json` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/home/.hermes/knowledge-upkeep/state.json` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/home/.hermes/cron/instruction-consistency-state.json` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/ACTIVE_RUNTIME.md` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| remote procedure dependency | `/home/orgo/lil-smoove/backups/*/receipt.json` | REMOTE_NOT_INSPECTED | Mac local file access is not remote access; no remote runtime probe, message, scheduler action or service execution authorized in this lane |
| local publication/credential route | `/Users/alexlobaito/.agents/tools/connectors/orgo_op.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/.agents/tools/connectors/ir_notes/server.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/.agents/tools/connectors/push_key_to_composio.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/.agents/tools/connectors/op_items.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/.agents/tools/connectors/google_robot/drive_upload_file.py` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/Projects/master-connector-repo/knowledge/workbook-drive.json` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |
| local publication/credential route | `/Users/alexlobaito/.agents/runtime/notes-sync.log` | UNINSPECTED | Not opened in this bounded local procedure inspection; needs scoped follow-up before claiming closure |

Credential values, auth stores, .env files, named pipes, live config/state databases, secret-bearing response bodies and clipboard/keychain content are safety exclusions: none opened, copied or hashed. Raw runtime config and credential launcher content omitted from package snapshots are explicitly listed above. Local path existence never establishes access on Orgo, Mac mini, hosted Claude/ChatGPT/Manus or another machine.

## Acceptance and next audit

Documentation uses the local lifecycle one-home standard dated 2026-10-07 and the plan requirement to preserve full safe procedural text and actual dependency dispositions. All source statements are written/source-observed only; effective configuration and seen-working claims require their own dated evidence.

The primary verifier must run the following check-form items and inspect the semantic residuals before publication:

```text
file:outputs/agent-knowledge/PROCEDURE_SOURCES.md non-empty
file:outputs/agent-knowledge/PROCEDURES_AND_DEPENDENCIES.md non-empty
json:work/build-context/procedures/coverage.json
json:work/build-context/procedures/dependency-closure.json
json:work/build-context/procedures/materializer-hash-check.json
contains:outputs/agent-knowledge/PROCEDURES_AND_DEPENDENCIES.md::App cards take precedence
contains:outputs/agent-knowledge/PROCEDURES_AND_DEPENDENCIES.md::REMOTE_NOT_INSPECTED
contains:outputs/agent-knowledge/PROCEDURES_AND_DEPENDENCIES.md::MISMATCH
cmd:python3 work/build-context/procedures/check_capture.py
```

Mandatory final reminder: reread the completion plan and compare every requested procedure/support requirement with [E1]/[E2]. A source snapshot or helper self-report is not acceptance. Retain exact omitted dependencies, correct changed source hashes and dates, and require actual remote readback/execution receipts before advancing a runtime claim. Publication and independent acceptance belong to the primary; this lane creates no publication claim.
