# Infrastructure inventory and boundaries

[Start here](START_HERE.md) · [Lessons and updates](LESSONS.md) · [Infrastructure](INFRASTRUCTURE.md) · [Accounts](ACCOUNTS.md)

Prepared 2026-10-07 from saved October 5–6 evidence. This is a readable derivative; the source workbook remains the detailed inventory. No provider was contacted in this extraction.

Evidence states: **DECLARED** means Alex supplied the statement in the current brief; **READ_VERIFIED** means the saved exact read/list/probe succeeded within its stated scope; **CONFIGURED** means saved settings/account metadata; **HISTORICAL** means workbook STALE, dated evidence without a current re-read; **UNKNOWN** means evidence absent. None establishes current service health, billing, permissions, or an active serving agent.

## Inventory scope

The workbook has **883 inventory records**, not 883 distinct owned assets. Those include resources, connected accounts, route references, historical observations, and two collection-count summaries. Its 23 sheets also contain derived views and configuration records outside that count [E1, E2].

| Workbook sheet | Data rows (header excluded) | Exact Excel rows | Coverage class |
| --- | --- | --- | --- |
| Inventory Index | 23 | 2:24 | derived_view_or_coverage |
| Orgo by Workspace | 8 | 2:9 | derived_view_or_coverage |
| Google Workspace | 35 | 2:36 | inventory_records |
| GitHub | 67 | 2:68 | inventory_records |
| Cloudflare | 115 | 2:116 | inventory_records |
| Composio Accounts | 54 | 2:55 | inventory_records |
| Access Routes | 15 | 2:16 | inventory_records |
| GHL Locations | 303 | 2:304 | inventory_records |
| Advertising | 67 | 2:68 | inventory_records |
| Analytics | 25 | 2:26 | inventory_records |
| Slack | 22 | 2:23 | inventory_records |
| Business Systems | 131 | 2:132 | inventory_records |
| Orgo Workspaces | 8 | 2:9 | inventory_records |
| Computers | 9 | 2:10 | inventory_records |
| Network Access | 7 | 2:8 | inventory_records |
| Host Observations | 8 | 2:9 | inventory_records |
| Credential References | 9 | 2:10 | inventory_records |
| Hermes Configurations | 8 | 2:9 | inventory_records |
| Hermes by Computer | 9 | 2:10 | derived_view_or_coverage |
| Relationships | 59 | 2:60 | relationship_records |
| Worker Binding Fields | 201 | 2:202 | binding_field_records |
| Tunnel Fallback Rules | 4 | 2:5 | fallback_rule_records |
| Coverage & Sources | 23 | 2:24 | derived_view_or_coverage |

## Actual machines and containers

There are **9 actual machines: 7 Orgo computers and 2 Macs**. The **8 Orgo workspaces** are containers. Seven Tailscale registrations are network records, not seven extra machines. Historical host observations and eight saved Hermes model configurations are separate records [E1] `Coverage & Sources` row 5.

| Orgo machine | Computer ID | Workspace | CPU allocation (source units) | RAM GB | Saved status | Pointer |
| --- | --- | --- | --- | --- | --- | --- |
| My OpenClaw | 6fbffd8c-65b1-4f2e-993e-f283532109bf | IR 1 | 1 | 8 | running (Oct6) | Workbook `Computers` row 2 |
| EA | d9b475e2-47b2-46d4-b8eb-102564f93283 | EA (Javar) | 4 | 16 | running (Oct6) | Workbook `Computers` row 3 |
| B2B Sales Agent | 2472bdb6-ae8f-4417-a4d0-103df5618d60 | B2B Agent (Sales) | 2 | 4 | running (Oct6) | Workbook `Computers` row 4 |
| SPARE-CSM | 7cedbb4b-0610-4241-907e-edc19b45cf57 | CSM | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 5 |
| SPARE-Media | c8aed3e5-6228-449e-b744-9d02466669c1 | Media | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 6 |
| SPARE-Ops | 47a4ba7c-9908-44f7-aa32-b7da8e18ac85 | Ops — Increase ROAS | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 7 |
| JAVAR-LAB | 0c1ce74e-176b-48f1-bf80-c38139036164 | Increase Roas - Max | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 8 |

| Mac | Hardware and memory | OS observation | State | Pointer |
| --- | --- | --- | --- | --- |
| Alex’s MacBook Pro | Apple M4 Pro; Mac16,7; 24 GB RAM; processor field proc 14:10:4:0 | 26.6.2 | READ_VERIFIED Oct6 metadata | Workbook `Computers` row 9 |
| SASHA IR MAC MINI - JAVANTE | Apple M4; 16 GB RAM | macOS 26.3.2 | HISTORICAL Oct5 | Workbook `Computers` row 10 |

| Workspace | Workspace ID | Machine returned | Pointer |
| --- | --- | --- | --- |
| IR 1 | 3cc5025d-98d3-4b0e-bde3-cd45cd062b85 | My OpenClaw | Workbook `Orgo Workspaces` row 2 |
| EA (Javar) | b4d13606-19d3-4802-9f5c-82819995129a | EA | Workbook `Orgo Workspaces` row 3 |
| B2B Agent (Sales) | 87d53061-ba01-4ff0-94c7-67057700af27 | B2B Sales Agent | Workbook `Orgo Workspaces` row 4 |
| CSM | 6cda999c-708e-4121-8531-383640f97290 | SPARE-CSM | Workbook `Orgo Workspaces` row 5 |
| Media | d4e5f8db-c4c1-4727-8fc0-c876a4602e52 | SPARE-Media | Workbook `Orgo Workspaces` row 6 |
| Ops — Increase ROAS | c523a888-eec5-4501-b25d-b6d591a3a90a | SPARE-Ops | Workbook `Orgo Workspaces` row 7 |
| Increase Roas - Max | 87ba4c76-bc3a-4d2c-84d6-c26f2f1b3117 | JAVAR-LAB | Workbook `Orgo Workspaces` row 8 |
| bold-spark | b6dd4d5b-d7da-46bf-bbf1-20be39e34b8c | No computer returned | Workbook `Orgo Workspaces` row 9 |

Workspace metadata itself has no CPU/RAM fields; allocation belongs to its computer. `bold-spark` returned no computer. CPU values are copied without converting fractional allocations into physical core counts. The safe Oct6 guest probe returned Linux-6.1.102-x86_64-with-glibc2.39 for all seven Orgo computers, exit code 0 [E4]; that proves the probe only.

## Disk and Hermes boundaries

Disk was not measured in the Oct6 bounded probe. Latest disk size/free space is UNKNOWN; retain the following as **HISTORICAL Oct5**, and distinguish allocated GB from measured filesystem GiB [E1].

| Machine | Historical disk observation | Pointer |
| --- | --- | --- |
| My OpenClaw | 39.26 GiB total<br>31.40 GiB free | Workbook `Computers` row 2 |
| EA | 49.10 GiB total<br>15.95 GiB free | Workbook `Computers` row 3 |
| B2B Sales Agent | 7.78 GiB total<br>0.69 GiB free | Workbook `Computers` row 4 |
| SPARE-CSM | 40 GB allocated; filesystem total/free UNKNOWN | Workbook `Computers` row 5 |
| SPARE-Media | 40 GB allocated; filesystem total/free UNKNOWN | Workbook `Computers` row 6 |
| SPARE-Ops | 40 GB allocated; filesystem total/free UNKNOWN | Workbook `Computers` row 7 |
| JAVAR-LAB | 40 GB allocated; filesystem total/free UNKNOWN | Workbook `Computers` row 8 |
| Alex’s MacBook Pro | 460.43 GiB total<br>29.51 GiB free | Workbook `Computers` row 9 |
| SASHA IR MAC MINI - JAVANTE | 228.27 GiB total<br>88.05 GiB free | Workbook `Computers` row 10 |

| Machine | Hermes directory/profile observation | Pointer |
| --- | --- | --- |
| My OpenClaw | No Hermes home found in the two checked locations; connector host | Workbook `Hermes by Computer` row 2 |
| EA | Javar main default; root default; manny-business; ea-javar-canary; ea-javar-cloudflare-rag-canary (saved Oct5 configurations; active use untested) | Workbook `Hermes by Computer` row 3 |
| B2B Sales Agent | default at /root/.hermes (saved Oct5 configuration; home found Oct6) | Workbook `Hermes by Computer` row 4 |
| SPARE-CSM | No Hermes home found in the two checked locations | Workbook `Hermes by Computer` row 5 |
| SPARE-Media | No Hermes home found in the two checked locations | Workbook `Hermes by Computer` row 6 |
| SPARE-Ops | No Hermes home found in the two checked locations | Workbook `Hermes by Computer` row 7 |
| JAVAR-LAB | Hermes home /home/orgo/.hermes found Oct6; no named profiles found; active provider untested | Workbook `Hermes by Computer` row 8 |
| Alex’s MacBook Pro | default at /Users/alexlobaito/.hermes (saved Oct5 configuration; active use untested) | Workbook `Hermes by Computer` row 9 |
| SASHA IR MAC MINI - JAVANTE | default at /Users/sashairis/.hermes (saved Oct5 configuration; active use untested) | Workbook `Hermes by Computer` row 10 |

Eight saved configuration records are **HISTORICAL Oct5**; installed Hermes, directory presence, configured model, and serving runtime are different facts. No running-agent count is inferred.

| Configuration | Saved path | Saved model.default | Saved model.provider | Pointer |
| --- | --- | --- | --- | --- |
| EA / ea-javar-canary | /home/orgo/lil-smoove/canary/home/.hermes/profiles/ea-javar-canary | deepseek/deepseek-v4-flash | nous | Workbook `Hermes Configurations` row 2 |
| EA / ea-javar-cloudflare-rag-canary | /home/orgo/lil-smoove/canary/home/.hermes/profiles/ea-javar-cloudflare-rag-canary | deepseek/deepseek-v4-flash | nous | Workbook `Hermes Configurations` row 3 |
| EA / Javar main default | /home/orgo/lil-smoove/home/.hermes | z-ai/glm-5.2 | nous-api-key | Workbook `Hermes Configurations` row 4 |
| EA / manny-business | /home/orgo/lil-smoove/home/.hermes/profiles/manny-business | deepseek/deepseek-v4-flash | nous | Workbook `Hermes Configurations` row 5 |
| EA / root default | /root/.hermes | anthropic/claude-opus-4.6 | auto | Workbook `Hermes Configurations` row 6 |
| B2B Sales Agent / default | /root/.hermes | anthropic/claude-opus-4.6 | auto | Workbook `Hermes Configurations` row 7 |
| SASHA IR MAC MINI - JAVANTE / default | /Users/sashairis/.hermes | z-ai/glm-5.2 | nous | Workbook `Hermes Configurations` row 8 |
| Alex’s MacBook Pro / default | /Users/alexlobaito/.hermes | moonshotai/kimi-k2.6 | nous | Workbook `Hermes Configurations` row 9 |

## Resources, routes, and detailed coverage

These are saved read counts within the supplied accounts [E1, E2]: Google Workspace 3 shared drives, 16 directory users and 16 selected folders; GitHub 67 repository metadata records; Cloudflare 115 inventory records; GHL 303 locations; advertising 57 Meta ad accounts and 10 Google Ads customers; analytics 6 GA4 accounts, 10 properties, 2 GTM accounts and 7 containers; Slack 22 channel metadata records. The Business Systems sheet has 131 records including 2 QuickBooks company labels (not proven realm IDs), 62 Notion items, 35 Asana items, 1 Linear team, 2 Sentry records, 3 Make records, 23 Apify actors, 1 Hugging Face identity and 2 count summaries. See the corresponding sheet row ranges above rather than infer content or permissions from names.

Cloudflare consists of 1 account, 2 Access applications, 3 AI Search instances, 16 D1 databases, 1 Durable Object namespace, 9 KV namespaces, 18 Pages projects, 2 queues, 6 R2 buckets, 4 tunnels, 13 DNS zones, 30 Workers, 5 Worker custom domains and 5 Worker zone routes. Successful zero lists for Vectorize and Workflows are coverage evidence, not missing invented resources (`Coverage & Sources` row 3). AI Search completed item-list counts were 6, 540 and 739 (`Coverage & Sources` row 2); original local upload filenames and live retrieval behavior remain UNKNOWN.

**59 exposed target relationships**, **201 target-unexposed Worker binding fields**, and **4 tunnel fallback response rules** preserve all 264 original configuration records. Field names do not reveal hidden targets. The 201 unexposed target values remain UNKNOWN. Localhost tunnel origins are local to the tunnel host, whose exact machine mapping is not proven. Source [E1] `Relationships` rows 2–60, `Worker Binding Fields` rows 2–202, `Tunnel Fallback Rules` rows 2–5 and `Coverage & Sources` row 23.

## Coverage exclusions and update boundary

| Coverage item | Saved limitation | Exact pointer |
| --- | --- | --- |
| Cloudflare routing and AI Search | 5 custom domains; 5 zone routes across all 13 zones; account Worker subdomain increase-roas. AI Search uploaded-item counts:6/540/739 from completed1/11/15-page lists. Runtime serving untested; original local upload filenames unknown. | Workbook `Coverage & Sources` row 2 |
| Cloudflare | Successful read-only lists: access_apps=2, accounts=1, ai_search=3, d1=16, durable_objects=1, kv=9, pages=18, queues=2, r2=6, tunnels=4, vectorize=0, workers=30, workflows=0, zones=13. All returned pages captured; runtime requests untested. | Workbook `Coverage & Sources` row 3 |
| GA4 accounts/85177518 | No properties returned by successful query | Workbook `Coverage & Sources` row 4 |
| Computer and Hermes counting | 9 actual computers = 7 Orgo machines + 2 Macs. Orgo Workspaces contains 8 containers, not machines. Host Observations preserves dated details and directories, not extra machines. Hermes Configurations contains 8 saved model-config records, not verified running agents. Hermes by Computer maps the same 9 machines without adding inventory assets. | Workbook `Coverage & Sources` row 5 |
| Google Workspace | 198 My Drive root folders counted; only 3 selected business roots included. Shared-drive root folders only; file contents uninspected. | Workbook `Coverage & Sources` row 6 |
| Account boundary | Only supplied evidence accounts inspected. Other connected SaaS resource contents may be uninspected; configured connections are not runtime proof. No client records or message content read. | Workbook `Coverage & Sources` row 7 |
| Freshness | READ VERIFIED means the exact read/list/probe in Proven scope succeeded, not that the service runtime works. CONFIGURED is settings/account metadata only. STALE is historical evidence at the row’s recorded date, without a current re-read. UNKNOWN means evidence absent. | Workbook `Coverage & Sources` row 8 |
| Evidence location | Relative work/ paths in this workbook resolve under: /Users/alexlobaito/Documents/Codex/2026-10-06/ce-handoff-resume-tmp-compound-engineering. Raw provider replies remain local in work/; this workbook contains resource metadata and concise coverage only. | Workbook `Coverage & Sources` row 9 |
| Google Workspace list depth | 16 directory users; 3 shared drives; 16 selected folder containers. Directory and drive pagination completed; only root folders listed. No documents/file contents read. | Workbook `Coverage & Sources` row 10 |
| GitHub list depth | 29 organization repositories and 38 accessible-account repositories listed; repository metadata only, contents uninspected. Named authenticated identity: increaseroasir. | Workbook `Coverage & Sources` row 11 |
| notion / notion_lepas-limbie | Returned counts: pages=54, databases=8. Pagination: has_more=false, next_cursor=null; 62 returned items. Boundary: Integration-accessible scope only; workspace identity/name not exposed by list; no content fetched | Workbook `Coverage & Sources` row 12 |
| asana / asana_logie-fratch | Returned counts: workspaces=1, projects=34. Pagination: next_page=null on both lists. Boundary: Visibility only for connected account; tasks/content not inspected | Workbook `Coverage & Sources` row 13 |
| linear / linear_flap-urtica | Returned counts: teams=1, projects=0. Pagination: hasNextPage=false on both lists. Boundary: first=250 teams failed complexity; first=50 succeeded; project-empty may reflect visibility/scopes | Workbook `Coverage & Sources` row 14 |
| sentry / sentry_venada-dama | Returned counts: organizations_returned=1, projects_returned=1. Pagination: BOUNDARY: wrapper exposes no cursor or Link headers. Boundary: Global completeness NOT_PROVEN; returned list only; no issues/events/content inspected | Workbook `Coverage & Sources` row 15 |
| make / make_gerbe-ashake | Returned counts: organizations=1, teams=1, scenarios=1. Pagination: Org/scenario offset=1 returned empty; team 1<10000 page limit. Boundary: Scenario metadata only; no blueprint, logs or execution fetched | Workbook `Coverage & Sources` row 16 |
| apify / apify_ruby-asor | Returned counts: listed_actors=23, datasets=0. Pagination: actor count=total=23; dataset count=total=0; dataset unnamed=true. Boundary: Ownership NOT_PROVEN; vendor usernames despite my=true; no runs, task inputs or dataset items fetched | Workbook `Coverage & Sources` row 17 |
| hugging_face / hugging_face_pricer-drongo | Returned counts: identity=1, organizations=0, models=0, datasets=0, spaces=0. Pagination: Own author-filtered repository lists returned [] (limit=1000). Boundary: Repos lists via card-authorized Composio proxy GET; metadata only | Workbook `Coverage & Sources` row 18 |
| heygen / heygen_plower-ceiler | Returned counts: videos=203. Pagination: HeyGen pages 100+100+3, final cursor null. Boundary: Counts only; no assets/content retained; no generation | Workbook `Coverage & Sources` row 19 |
| elevenlabs / elevenlabs_rangle-malo | Returned counts: voices=52. Pagination: GET_VOICES non-paginated list count=52. Boundary: Counts only; no assets/content retained; no generation | Workbook `Coverage & Sources` row 20 |
| higgsfield / higgsfield_belout-embus | Returned counts: . Pagination: Not attempted. Boundary: Lower priority media provider beyond tested counts scope; no generation | Workbook `Coverage & Sources` row 21 |
| Inventory row counting | 883 inventory records include resources, accounts, routes, references, observations and two collection-count summaries. This is not a count of 883 distinct owned assets. AI surface references may group tools; QuickBooks local record labels are not company realm IDs. | Workbook `Coverage & Sources` row 22 |
| Relationship counting | 59 configured target links/references; 201 target-unexposed binding fields and 4 tunnel fallback response rules are separate. All 264 original configuration records preserved. A listed field is not a proven service connection; localhost origins are local to the tunnel host, whose machine mapping was not proven. | Workbook `Coverage & Sources` row 23 |
| Historical disk measurements | The Oct6 bounded probe did not measure disk. Oct5 original disk records are preserved in Computers notes and Orgo by Workspace; allocated GB and measured filesystem GiB are different measures. Historical free space is not current free space. | Workbook `Coverage & Sources` row 24 |

Any refresh must preserve source dates, distinguish snapshot reads from runtime acceptance, and reconcile this sheet registry before updating these derivatives. Record corrections through [LESSONS](LESSONS.md) and the maintenance procedure in [START_HERE](START_HERE.md). Current endpoint liveness, write/admin permissions, serving versions, restore success, provider billing, and current disk/free space are UNKNOWN.

[E1] [Inventory workbook on Drive](https://docs.google.com/spreadsheets/d/1Jinfgxakdq06FS6IN_QCQcq3TSioFbGn/edit) ([local workbook](../AI_Infrastructure_Gameplan.xlsx)), final saved SHA-256 `a4edbad6d5d088d6a6dd13584446f6b1f1d63112623bbe8fc2c7468eb99ac303`.

[E2] [Inventory verification](../inventory-verification.json), 2026-10-06; [audit details](../inventory-audit-details.json), 2026-10-06; [final saved publication receipt](../drive-verification-receipt.json). The audit's earlier Drive mismatch is superseded by this final matching saved receipt. This extraction verifies local bytes against it, not current remote bytes.

[E3] Current declaration record: `work/agent-knowledge/brief.json` (2026-10-07). [E4] Saved safe metadata: `work/orgo-metadata.json` and allowlisted OS-only parsing of `work/orgo-profiles.json` (Oct6); no raw probe output or secret values reproduced.
