# Audit and maintenance protocol

Owner: Alex / Increase ROAS. Procedure version: 2026-10-07.

This is a knowledge-maintenance procedure. It does not authorize spending, customer contact, security changes, runtime deployment, shared-skill installation, or a recurring job.

## Required reading

Read [START_HERE.md](START_HERE.md), [CURRENT_STATE.md](CURRENT_STATE.md), [GAPS.md](GAPS.md), and [LESSONS.md](LESSONS.md). Read the relevant agent, account, skill, and hook records before touching the associated system. Consult the current app card before an app call. Local paths are pointers for agents on Alex's Mac; remote agents must use the published Drive resources or their approved access route.

## Audit workflow

1. Record audit ID, auditor, start time, intended scope, and exact source set. Back up any existing knowledge file before updating it.
2. Enumerate sources before summarizing. Reconcile the enumerated sources against the coverage register. Record every source as read, summarized, linked, excluded with a reason, or inaccessible. Do not silently drop inconvenient sources.
3. Read maintained sources and inspect relevant current metadata through approved routes. Keep observed dates, source-file modification dates, audit dates, and publication dates separate.
4. Enrich records only with source-backed findings or clearly labeled owner declarations. Add exact paths, stable Drive IDs, evidence dates, and the meaning of each status. An account email does not prove a runtime-profile binding; a directory does not prove a skill was selected; a hook definition does not prove it ran.
5. Reconcile contradictions. Retain both dated observations until the current authoritative source resolves them. Track unresolved questions in [GAPS.md](GAPS.md), including owner, evidence needed, and next permitted check.
6. When a problem is fixed, write the verified cause, fix, proof, and prevention in [LESSONS.md](LESSONS.md). A proposed fix stays explicitly unverified. If the lesson belongs in a maintained skill, follow the shared skill lifecycle before changing that skill; this knowledge hub is a pointer, not a second skill source.
7. Check navigation links, source coverage, counts, status labels, secrets exclusions, and publication integrity. Use a separate verifier for a broad multi-source audit. Include a negative check, such as rejecting a changed checksum or a fabricated runtime claim.
8. Update START_HERE's audit ID, auditor, completed date/time, scope, result, coverage, receipt link, and remaining-gap link only after those checks pass. Never advance the completed-audit date for an upload, cosmetic edit, partial scan, failed check, or unverified fix. Record a partial attempt separately.
9. Regenerate [AGENT_BRIEFING.md](AGENT_BRIEFING.md) from the maintained knowledge files; do not hand-edit its copied facts. Update the source/publication register. Publish changed files to their existing Drive IDs and verify their final bytes against saved receipts.
10. Report exactly what was written, published and verified, plus any runtime or access checks that remain unproven. Do not claim that instructions mechanically enforce future compliance; no enforcement hook is installed by this document.

## Required audit record

- Audit ID and auditor
- Started/completed time and timezone
- Scope and exclusions
- Source enumeration and coverage counts
- Verified findings, declared facts and unresolved gaps
- Local verification receipt and Drive publication receipt
- Changed knowledge files and source revision/hash pointers
- Lessons added and source-skill follow-up, if applicable

The entry point must always link this protocol and LESSONS. Future agents are required by this procedure to update them when applicable; current runtime adoption must be proved separately.

## Mandatory final audit against the intended work

Before reporting completion, reread Alex's current request and the accepted plan. Map every promised outcome to an actual delivered source, inspected content, verification result and published file. Have a separate verifier check the matrix for broad work. A helper report, source pointer, configured setting or successful upload cannot substitute for this acceptance check.

For the build-context extension, use [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md) and [BUILD_READINESS.md](BUILD_READINESS.md). Every requirement must end VERIFIED, PARTIAL or BLOCKED with its exact remaining evidence/action. Audit instructions/configuration, accepted plans and implementation, identities/customer bindings, supporting procedures/app cards, startup/hooks/schedulers, service dependencies and acceptance/recovery. Retain the distinction between source presence and actual loading/execution. Fix supported documentation defects, republish the same IDs, and recheck final bytes before marking the delivery complete.

This is an end-of-run reminder and written acceptance requirement, not a scheduled reminder or installed enforcement hook.

## Verify text decoding before using a read

A 2026-10-07 `CUSTOM_GOOGLE_ROBOT_DRIVE_READ` of ACCOUNTS returned UTF-8 content represented as Latin-1 characters. Drive's stored checksum was correct. Strictly re-encoding that returned string as Latin-1, then decoding it as UTF-8, recovered the exact source bytes and checksum. Evidence: local `work/agent-knowledge/readability-receipt.json` and `account-readable-readback.json`.

Use a current Drive SHA-256 or the corresponding verified source-register hash as the expected checksum. First hash the returned text encoded as UTF-8. If it matches, use it unchanged. If it does not match and the text appears incorrectly decoded, try the strict Latin-1-to-UTF-8 recovery once. Accept the recovered text only when its bytes match the expected checksum. Never ignore decoding errors or blindly replace punctuation. If neither candidate matches, record the read as unverified and follow the approved source/access route.

This is a verified read-time recovery for one observed file, not a deployed connector-service fix or proof that all readers have the problem. Record any recurrence and successful fix in [LESSONS.md](LESSONS.md); the connector owner must approve and verify any service change separately.
