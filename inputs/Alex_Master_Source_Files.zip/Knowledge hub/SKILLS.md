# Skills register

## Selected supporting-source extension

The build-context extension reads selected build-critical supporting scripts, references, templates and app cards. See [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md), [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md) and [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json). This closes selected source gaps only; the original complete entry-file catalogue does not become a complete all-skill supporting-resource or remote-delivery audit.

Audit date: 2026-10-07. Local reference catalogue, generated from complete SKILL.md reads. Exact source hashes, dates and read coverage are in `work/agent-knowledge/skills-hooks-coverage.json`. These summaries point to procedures; they do not become new procedure homes.

## Coverage

| Source class | Read count |
|---|---:|
| canonical | 174 |
| external_canonical_exception | 1 |
| synced_pointer | 19 |
| codex_system | 5 |

The one external canonical exception is `.agents/skills/one-shot-builder`, linked to the Cursor-owned source. Synced entries are pointer copies and are excluded from the canonical count. Each supporting-resource count is path metadata only; supporting script behavior was not generally audited.

## Browse by contents

- [Creative Media](skills/creative-media.md): 32 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Engineering Execution](skills/engineering-execution.md): 37 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Marketing Delivery](skills/marketing-delivery.md): 22 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Operations Research](skills/operations-research.md): 58 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Platform Integrations](skills/platform-integrations.md): 15 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Platform System](skills/platform-system.md): 5 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Search Content](skills/search-content.md): 11 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Synced Pointers](skills/synced-pointers.md): 19 entries, with purpose, headings, procedure cues, resource metadata and source hash.

## Cached plugin skills

[PLUGIN_SKILLS.md](PLUGIN_SKILLS.md) adds 154 fully read cached plugin SKILL.md entries across24 provider/plugin/version groups. Cached content is separate from enablement, runtime selection and remote delivery. Do not sum catalogue classes as distinct installed capabilities; source_registry.json records resolved paths and overlaps.

## Installation and runtime limits

[L1] `/Users/alexlobaito/.agents/tools/unify/skill-lifecycle.md` (checked 2026-10-07) owns shared placement and publication: shared skills stay in `.agents/skills`; registered Claude Code and Cursor targets use links; Codex `.system` remains platform-owned. Local links prove configured paths. No fresh target-runtime selection or remote upload/readback was performed in this audit. Hosted Claude/Cowork, ChatGPT, Manus, Hermes and other-machine delivery is NOT_PROVEN.

## Configured discovery surfaces

| Platform | Path | Resolved target | Type | SKILL.md |
|---|---|---|---|---|
| claude | `/Users/alexlobaito/.claude/skills/aimoney-search` | `/Users/alexlobaito/.agents/skills/aimoney-search` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/alex-director` | `/Users/alexlobaito/.agents/skills/alex-director` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/alex-workflow-conductor` | `/Users/alexlobaito/.agents/skills/alex-workflow-conductor` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/brainstorming` | `/Users/alexlobaito/.agents/skills/brainstorming` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/build-ghl-systems` | `/Users/alexlobaito/.agents/skills/build-ghl-systems` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/capture-lessons` | `/Users/alexlobaito/.agents/skills/capture-lessons` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/ce-handoff` | `/Users/alexlobaito/.agents/skills/ce-handoff` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/cloudflare` | `/Users/alexlobaito/.agents/skills/cloudflare` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/composio-cli` | `/Users/alexlobaito/.agents/skills/composio-cli` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/composio-custom-mcp` | `/Users/alexlobaito/.agents/skills/composio-custom-mcp` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/dispatching-parallel-agents` | `/Users/alexlobaito/.agents/skills/dispatching-parallel-agents` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/executing-plans` | `/Users/alexlobaito/.agents/skills/executing-plans` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/fan-out` | `/Users/alexlobaito/.agents/skills/fan-out` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/finishing-a-development-branch` | `/Users/alexlobaito/.agents/skills/finishing-a-development-branch` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/first-principles-project-auditor` | `/Users/alexlobaito/.agents/skills/first-principles-project-auditor` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/hermes-team-setup` | `/Users/alexlobaito/.agents/skills/hermes-team-setup` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/intake-triage` | `/Users/alexlobaito/.agents/skills/intake-triage` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/javar-add-tool` | `/Users/alexlobaito/.agents/skills/javar-add-tool` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/meta-ads` | `/Users/alexlobaito/.agents/skills/meta-ads` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/preserve-and-release-website` | `/Users/alexlobaito/.agents/skills/preserve-and-release-website` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/repo-conform` | `/Users/alexlobaito/.agents/skills/repo-conform` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/requesting-code-review` | `/Users/alexlobaito/.agents/skills/requesting-code-review` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/research-with-sources` | `/Users/alexlobaito/.agents/skills/research-with-sources` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/sales-agent-from-conversations` | `/Users/alexlobaito/.agents/skills/sales-agent-from-conversations` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/search-past-work` | `/Users/alexlobaito/.agents/skills/search-past-work` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/subagent-driven-development` | `/Users/alexlobaito/.agents/skills/subagent-driven-development` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/synced` | `/Users/alexlobaito/.claude/skills/synced` | directory | False |
| claude | `/Users/alexlobaito/.claude/skills/systematic-debugging` | `/Users/alexlobaito/.agents/skills/systematic-debugging` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/talk-with-alex` | `/Users/alexlobaito/.agents/skills/talk-with-alex` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/test-driven-development` | `/Users/alexlobaito/.agents/skills/test-driven-development` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/tool-card` | `/Users/alexlobaito/.agents/skills/tool-card` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/using-git-worktrees` | `/Users/alexlobaito/.agents/skills/using-git-worktrees` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/verification-before-completion` | `/Users/alexlobaito/.agents/skills/verification-before-completion` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/verify-before-done` | `/Users/alexlobaito/.agents/skills/verify-before-done` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/weekly-tuneup` | `/Users/alexlobaito/.agents/skills/weekly-tuneup` | link | True |
| claude | `/Users/alexlobaito/.claude/skills/writing-plans` | `/Users/alexlobaito/.agents/skills/writing-plans` | link | True |
| cursor | `/Users/alexlobaito/.cursor/skills/composio-custom-mcp` | `/Users/alexlobaito/.agents/skills/composio-custom-mcp` | link | True |
| cursor | `/Users/alexlobaito/.cursor/skills/one-shot-builder` | `/Users/alexlobaito/.cursor/skills/one-shot-builder` | directory | True |
| cursor | `/Users/alexlobaito/.cursor/skills/tool-card` | `/Users/alexlobaito/.agents/skills/tool-card` | link | True |

These are local directory metadata observations, not an assertion that each app exposed or selected every skill. Session-injected plugin catalogues are outside this canonical inventory.

## Required future update

When a skill source, pointer, runtime version or discovery path changes: reread the affected source, refresh its hash/date/contents summary and coverage JSON, preserve its canonical home, and add a structured evidence entry to [LESSONS](LESSONS.md). Update [START_HERE](START_HERE.md) with the completed audit date, scope, verification receipt and remaining gaps only after the new audit is accepted. Follow the lifecycle for any separately authorized installation; this catalogue update authorizes none.

## Exact-content overlap

Across the199 local and154 cached plugin source records,353 resolved paths contain331 distinct byte hashes. Seventeen identical-content groups cover39 paths. This is an exact-byte comparison, not a semantic capability count or authorization to remove copies. Evidence: `work/agent-knowledge/skill-content-overlap.json`; ownership reconciliation remains G20 in [GAPS.md](GAPS.md).
