# Increase ROAS agent briefing

Generated orientation from maintained knowledge pages. Read full sources only for the task at hand. Resolve logical filenames and exact published bytes using [source_registry.json](https://drive.google.com/file/d/176hza_ZAB2ypsCLNUnEvwcsbqxNV2yw6/view). This briefing is an intake aid; it does not prove current runtime health.

---

<!-- source: START_HERE.md -->

# Start here: Increase ROAS agent knowledge

Owner: Alex. Maintainer: the agent completing an authorized knowledge audit.

- Last completed knowledge audit: 2026-10-07 23:36:11 UTC
- Audit ID: `build-context-2026-10-07`
- Auditor: Codex with four parallel source lanes and a separate independent verifier
- Audit scope: selected full safe configuration/AGENTS, accepted plans/build sources, procedures/supporting scripts/hooks, scoped GHL/Cloudflare readbacks, navigation, lessons and publication; earlier inventory remains dated
- Result: independent source/integration accepted;42-file shared Drive publication and human-guide links verified; final metadata bytes rechecked in the saved final receipt
- Audit receipt: [AUDIT_RECEIPT.json](AUDIT_RECEIPT.json)
- Remaining gaps: [GAPS.md](GAPS.md)

This entry point maps the knowledge. It does not certify current agent health. Publication dates, source-update dates and runtime verification dates remain separate.

## Fastest intake

For one-file orientation, read [AGENT_BRIEFING.md](AGENT_BRIEFING.md). It is generated from the maintained knowledge pages below and gives the team, account declarations, evidence states, access route, infrastructure boundaries, role summaries, skill/hook navigation, gaps and maintenance rules. Read a task's canonical skill and supporting resources before execution; the briefing is not a substitute for that procedure.

Before continuing or reconstructing a build, read [BUILD_READINESS.md](BUILD_READINESS.md) and its required configuration, implementation, procedure and service sources. Full safe source snapshots are dated evidence; the maintained source retains authority.

For focused intake, read [TEAM_MAP.md](TEAM_MAP.md), [CURRENT_STATE.md](CURRENT_STATE.md), [ACCESS_AND_TOOLS.md](ACCESS_AND_TOOLS.md), then the relevant role page. Use [source_registry.json](source_registry.json) to resolve logical filenames to published Drive file IDs and maintained local source pointers. On a remote agent, Mac paths are references, not accessible files by assumption.

Verify the checksum of a fetched Markdown response before relying on its text. If punctuation is garbled, use the guarded decoding procedure in [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md); [LESSONS.md](LESSONS.md) records the observed recovery.

## Where the facts live

| Need | Read |
|---|---|
| Build readiness, acceptance matrix and remaining build blockers | [BUILD_READINESS.md](BUILD_READINESS.md) |
| Full safe configuration/instruction sources and precedence | [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) · [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md) |
| Accepted plans, implementation and historical acceptance | [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) · [BUILD_IMPLEMENTATION_SOURCES.md](BUILD_IMPLEMENTATION_SOURCES.md) |
| Build-critical procedures, dependencies and full safe source text | [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md) · [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md) |
| GHL and Cloudflare implementation/dependency coverage | [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md) · [SERVICE_SOURCES.md](SERVICE_SOURCES.md) |
| Independent acceptance against the requested plan | [BUILD_ACCEPTANCE.md](BUILD_ACCEPTANCE.md) |
| Published build source coverage and exclusions | [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json) |
| Accepted build-context production plan | [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md) |
| Agent ownership, relationships and identity conflicts | [TEAM_MAP.md](TEAM_MAP.md) |
| Computers, workspaces, sizes and detailed workbook pointers | [INFRASTRUCTURE.md](INFRASTRUCTURE.md) |
| Personal plans, declared Hermes emails and54 saved connector records | [ACCOUNTS.md](ACCOUNTS.md) |
| Approved access route and credential-reference boundaries | [ACCESS_AND_TOOLS.md](ACCESS_AND_TOOLS.md) |
| Evidence freshness and what has actually been checked | [CURRENT_STATE.md](CURRENT_STATE.md) |
| Local canonical/system/pointer skill contents | [SKILLS.md](SKILLS.md) |
| Cached plugin skill contents and exposure limits | [PLUGIN_SKILLS.md](PLUGIN_SKILLS.md) |
| Hook definitions, configured events and execution limits | [HOOKS.md](HOOKS.md) |
| Unresolved questions and exact next evidence | [GAPS.md](GAPS.md) |
| Verified mistakes, fixes and prevention | [LESSONS.md](LESSONS.md) |
| Audit, enrichment, lessons and publication requirements | [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) |

## Agent pages

[Javar](agents/javar.md) · [Javante](agents/javante.md) · [Ops](agents/ops.md) · [Customer Success](agents/customer-success.md) · [Media](agents/media.md) · [Sales / Setter / Hunter](agents/sales.md) · [Finance](agents/finance.md)


Read [START_HERE.md](START_HERE.md) for the remaining details and source evidence.

---

<!-- source: BUILD_READINESS.md -->

# Build readiness and acceptance

Audit: build-context-2026-10-07. State: VERIFIED_DOCUMENTATION_DELIVERY; runtime build gates retain PARTIAL/BLOCKED states. This page evaluates the documentation available to continue a build. It does not certify deployment, customer bindings, billing or fleet health.

## Read before continuing a build

1. Read [START_HERE.md](START_HERE.md), [CURRENT_STATE.md](CURRENT_STATE.md) and this page.
2. Read [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) and the applicable full safe text in [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md). Check the current maintained sources before changing a runtime. A saved setting is not proof it loads.
3. Read [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) to distinguish intended, accepted, implemented and observed-working behavior. Pick the actual owning repo/profile/customer scope before editing.
4. Follow [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md), then load the selected canonical skill and supporting resources. [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md) is dated source evidence, not a separately maintained procedure.
5. Read [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md) before changing GHL or Cloudflare integrations. Check exact accounts, dependencies and uninspected targets.
6. Resolve the task's relevant gaps before acting. Do not wait on unrelated unknowns, and do not infer unavailable facts.

## Requirement-by-requirement acceptance

The accepted scope and final reminder are in [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md). Independent source/integration verification accepted the selected documentation scope. Each row retains its actual residuals.

| Requirement | Documentation state | Evidence | Remaining build proof |
|---|---|---|---|
| Effective instructions and configuration | Full safe selected source capture; runtime loading PARTIAL | CONFIGURATION_AND_INSTRUCTIONS; CONFIGURATION_SOURCES; BUILD_SOURCE_COVERAGE configuration lane:31 captures,42 absent candidates,8 omissions; all five generator outputs match | Effective loader/managed/cloud/state-only surfaces and current vendor conflict order need credential-blind exports or controlled traces; global disk defaults do not establish this chat's permissions |
| Accepted plans and implementation | Full selected safe corpus captured; operational gates BLOCKED | BUILD_IMPLEMENTATION and BUILD_IMPLEMENTATION_SOURCES:209 full safe reads, all34 maintained role contracts, byte-matched current Javar Gameplan/Notes, all13 workbook tabs/comments;211 source records | Mission remains paused with G1–G4 blocked. Private originals/whole-repo state excluded; two documented files are missing. No resume authority from this audit |
| Current host/profile/customer identity | Dated host changes reconciled; serving proof PARTIAL | BUILD_IMPLEMENTATION role matrix; current-file Notes distinguish removed Ops/CSM/Media/Finance hosts from replacement metadata | Replacement role installation/home/profile/customer/credentials, current Javar/Javante serving release and exact Hermes email/profile binding remain unproven; Finance's old replacement is now Lab with no connected model in dated notes |
| Procedures and supporting dependencies | Selected full safe sources captured; complete runtime dependency closure PARTIAL | PROCEDURES_AND_DEPENDENCIES and PROCEDURE_SOURCES:167 full snapshots;393 reference dispositions; all23 incoming implementation references reconciled | Three materializer baseline mismatches, one missing exact Javante skill path, remote installed/state/credential exclusions, remaining literal/example/support-reference dispositions. Do not refresh baseline hashes without component review |
| Startup/hooks/background behavior | Actual configured declarations and selected implementations captured; execution NOT_PROVEN | CONFIGURATION_SOURCES; PROCEDURE_SOURCES includes eight previously omitted configured hook implementations plus setup-check/maintenance/update sources | Current scheduler registry/results/delivery, effective hooks and exact stock/native serving path need current acceptance; no hook or procedure was executed |
| Service implementation/dependencies | Full19 selected sources plus scoped live settings captured; fleet/behavior PARTIAL | SERVICE_BUILD_CONTEXT and SERVICE_SOURCES; independent same-route readback:16 safe Worker binding objects,25 returned B2B workflows,2 calendars,1 pipeline | Other29 Workers/deployed-code equality/imported JSON/identity maps/index discrepancy uninspected; GHL full workflow/settings/pagination unproven; seven connector stage objects have null IDs/names, so stage mapping BLOCKED |
| Acceptance/recovery | Actual historical/source receipts available; current working acceptance PARTIAL | BUILD_IMPLEMENTATION_SOURCES; PROCEDURE_SOURCES; SERVICE_SOURCES preserve acceptance versions/dates and failure boundaries | Current meaningful model/tool/customer acceptance, reboot/delivery/restore and reviewed rollback behavior need exact target proof. Historical receipts and source checks cannot substitute |
| Future maintenance and final reminder | VERIFIED written maintenance requirements | START_HERE; AUDIT_PROTOCOL; LESSONS; BUILD_CONTEXT_PLAN | Required final audit against request/plan is embedded; no recurring audit/reminder or enforcement hook installed |
| Publication integrity | VERIFIED selected publication; final metadata byte receipt rechecked | Same-file primary publisher and independent final verifier | Exact final bytes, source registry, existing IDs, shared parents/MIME and human guide links must pass before delivery is complete |

## Build blockers requiring their own authorized work

- Javar's Gameplan mission is paused; its gate state is not changed by documentation collection.
- Accepted materializer hashes disagree with three current plugin files. Static source logic is designed to stop on drift; it was not executed here.
- Replacement role hosts have control-plane evidence without current guest/profile/provider/customer acceptance.
- GHL pipeline stage IDs/names are unavailable in the verified connector reply; underlying API-versus-connector cause is not proven.
- Three exact documented local source paths are missing, and current loading, installed identities, scheduler delivery, service behavior and recovery remain unproven. [GAPS.md](GAPS.md) names the owners and next evidence.

The documentation/source delivery may be accepted with these explicit residuals. It must not be described as all build gates resolved or a working-runtime certification.

## Mandatory end-of-run reminder

Before saying done, reread the original request and the accepted plan. Audit every promised outcome against inspected sources, actual deliverables, final verification and publication. Use a separate verifier for a broad audit. Record PARTIAL and BLOCKED rows with exact evidence needed; an unknown is not a completed check. Update the completed audit metadata only after acceptance, regenerate the briefing and source register, publish to the same IDs and verify final bytes.

This is a written requirement. No automatic audit, recurring reminder or enforcement hook is installed by this delivery.

---

<!-- source: CONFIGURATION_AND_INSTRUCTIONS.md -->

# Instructions and configuration build context

This lane inspected local instruction and settings files on Alex's Mac on 2026-10-07. It wrote a documentation snapshot and made no runtime, provider, instruction-source or settings changes. Complete safe source text is in [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md); path, modification time, byte size, safe hash, absence and exclusions are in [coverage.json](../../work/build-context/configuration/coverage.json). These observations apply to this Mac and the named maintained Build checkout, not to remote Hermes homes or other machines.

## Evidence and source ownership

- **[E1]** [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md): full safe text for 31 captured sources, including all six instruction generator inputs, the generator, global Codex/Claude instructions, Cursor rules, maintained Build instructions, settings and hook declarations.
- **[E2]** [coverage.json](../../work/build-context/configuration/coverage.json): 81 candidate/exclusion records: 31 captured, 42 absent and 8 omitted. Records preserve exact capture and file modification dates. Counts include explicitly named absent candidates; they are not a capability count.
- **[E3]** [capture.py](../../work/build-context/configuration/capture.py): the bounded read-only capture procedure and in-memory sanitization policy. It does not run the generator's `plan`, `apply` or `init`, or invoke configured hooks/MCP servers.
- **[E4]** [checks.md](../../work/build-context/configuration/checks.md): machine checks and negative checks. Independent review/publication remain the primary's responsibility.

The owning instruction inputs are `/Users/alexlobaito/.agents/instructions/`. The generated files are outputs, not editable replacements for those inputs. Configuration snapshots here are dated archival evidence copies, not a second maintained configuration authority. Each snapshot section in E1 supplies the exact source modification date and safe SHA-256; formatting/comments are omitted from parsed JSON/TOML configuration snapshots, while all parsed keys remain represented. Secret-bearing values are explicitly replaced rather than silently missing.

## Codex: actual source and configured behavior

`~/.codex/AGENTS.md` is captured in full. The generator composes it from `shared.md`, then `codex.md`, then the Voice and Delegation and model routing sections from `codex-style.md`. `shared-style.md` remains outside this generated AGENTS file. The generator builds `developer_instructions` in `~/.codex/config.toml` from `codex-style.md` plus `shared-style.md`, and sets `model_verbosity=medium` and `model_reasoning_summary=concise`. These relationships are proven by the captured generator and inputs, not inferred from similarly named files. All five generator outputs exactly matched their generated candidates during the read-only comparison: Codex AGENTS, Claude CLAUDE, Claude output style, Codex config and Cursor routing. [E1, E2]

The generator contains historical observations that Codex app chats did not receive config `developer_instructions` while CLI `codex exec` did in its 2026-10-01/02 scan. That is a dated source claim; this lane did not reread the underlying 29/66-thread scan or prove the current app's loader. The Voice and Delegation sections are nevertheless present in the global AGENTS file now. A file matching generated output proves synchronization, not delivery to every active session. [E1, E2]

The safe global Codex configuration preserves the entire parsed data tree, including model, features, 126 project records, MCP declarations, plugin/marketplace settings, disabled skills, shell-environment filters, hook trust hashes and desktop preferences. File settings include model `gpt-6.1-sol`, reasoning `medium`, `sandbox_mode=danger-full-access`, `approval_policy=never`, `approvals_reviewer=user`, and live web search. At the source lane’s capture, the task’s injected environment declared workspace-write restrictions, restricted network and automatic approval review. Later in this same chat, an explicit environment override changed the active sandbox to danger-full-access with enabled network and automatic approval review; the underlying captured configuration sources were not edited. Effective session permissions can therefore change after a dated source capture. Thus global disk defaults do not establish this task's effective permissions. No broader access is claimed from those defaults. [E1; observed task environment and later injected override, 2026-10-07]

Configured Codex MCP names are `node_repl`, `director-observatory`, `research_github`, `research_exa`, `research_huggingface`, `playwright` and `codex-bridge`. Their commands/settings are captured safely; this lane made no connection or health calls. Feature flags and disabled-skill records are configuration evidence only. `~/.codex/hooks.json` declares SessionStart and PreToolUse commands; their execution and guard coverage are NOT_PROVEN here. Supporting hook/guard implementation belongs to the procedures lane. [E1]

The current documentation workspace and the ancestor chain from `/Users/alexlobaito` through its working directory contain no named `AGENTS.md`, `AGENTS.override.md`, `CLAUDE.md` or `.cursorrules` candidates. Named ancestor/project settings candidates are also enumerated in E2. The session includes user-supplied AGENTS text; that injection is a separate observation and is not an on-disk project source. The maintained `/Users/alexlobaito/Documents/ChatGPT/Build/AGENTS.md` and `CLAUDE.md` are both captured. Three nested maintained role AGENTS sources (EA startup, Javante setup and Manny profile asset) are also captured as runtime instruction sources; they are not ancestor instructions for this documentation workspace. Build's `.codex/config.toml` contains `default_permissions=":workspace"`; this lane did not launch a Build session to test it. [E1, E2]

## Claude: analogous sources and boundaries

`~/.claude/CLAUDE.md` is the generated global instruction source: `claude.md` followed by `shared.md`. The generated `~/.claude/output-styles/alex-big-brother.md` combines `claude-style.md` and `shared-style.md`; global settings select output style `Alex big brother`. Global `settings.json`, `settings.local.json` and Claude Desktop's `claude_desktop_config.json` are captured safely. The Desktop configuration declares `director-observatory` and `codex-bridge`, plus Cowork/preferences data. Desktop and Claude Code are distinct configuration surfaces; their presence does not prove shared loading. [E1, E2]

Claude Code settings declare permissions, sandbox options, plugins and SessionStart, PostToolUse, UserPromptSubmit and PreToolUse hook commands. The local permission list also contains historical command allowances referencing `.env.local` and DSN files. Those are text in the settings snapshot: neither those files nor the referenced values were opened. They do not override this run's no-secret/no-env boundary. Build's `CLAUDE.md` explicitly points to its adjacent AGENTS file rather than duplicating Javar's policies. [E1]

`~/.claude.json` and `~/.claude/.credentials.json` are excluded in full because they may hold account/authentication state or credentials. Their contents and existence were not checked. No Claude global rules files were returned by the scoped discovery; that observation does not assert that every possible managed instruction surface is empty. Project settings candidates in the documentation workspace and maintained Build checkout are listed as absent where applicable. Claude effective permissions, memory loading, MCP startup and hooks remain NOT_PROVEN. [E2]

## Cursor: analogous sources and boundaries

Three global `.mdc` rule files are captured: generated `agent-routing.mdc`, `observatory-first.mdc` and `grok-bot-standing.mdc`. The first two declare `alwaysApply: true`; Grok Bot declares `alwaysApply: false` and a narrow scope. The Observatory rule explicitly says its referenced routing paragraph wins if the pointer differs. These are file-declared activation/precedence instructions, not a live Cursor session trace. The referenced procedural text belongs to the procedures dependency register; this lane does not expand unrelated Grok Bot source material. [E1]

Cursor's global `settings.json`, `cli-config.json`, `mcp.json`, `hooks.json`, `argv.json` and IDE User settings are captured. Maintained Build's `.cursor/settings.json` is `{}`. CLI settings declare Composer 2.5, allowlist approval and enabled sandbox configuration. Global MCP settings declare `orgo` and `director-observatory`; hooks declare session start, fast-subagent rejection and shell/MCP guards. These declarations establish configured commands only. No Cursor launch, tool availability, deny test or hook execution was performed. Auth-related fields in CLI settings are redacted as a whole. [E1]

`~/.cursor/agent-cli-state.json`, the IDE globalStorage state database and recursive project caches are excluded because they can contain account state, credentials or session data. User rules that exist only inside the state database are therefore unexported; a complete Cursor effective-instruction export is NOT_PROVEN. `.cursorrules` and project MCP candidates are enumerated rather than assumed present. [E2]

## Precedence evidence and unproven loading

| Relationship | Evidence | What it proves / remaining boundary |
|---|---|---|
| Generator input → generated global rules/style/config | Full generator and six inputs; five exact comparisons | VERIFIED composition and synchronization at capture time; generator historical loader comments remain historical |
| Shared rules → Codex/Claude/Cursor copies | Exact source composition in `build()` | VERIFIED ownership and composition; does not establish runtime conflict resolution |
| Build CLAUDE → adjacent Build AGENTS | Full CLAUDE text | VERIFIED instruction pointer; loading in an actual Claude Build session untested |
| Build AGENTS → older Build policy files | AGENTS explicitly supersedes named older blanket bans | VERIFIED maintained policy declaration; not authority for this read-only lane |
| Cursor Observatory pointer → canonical routing paragraph | Full rule says paragraph wins | VERIFIED source-declared precedence; dependency text/behavior handled in procedures lane |
| Disk defaults → task effective restrictions | Safe disk config differs from injected task environment | VERIFIED distinction; actual task restrictions control this run |
| Global/project/override/managed/CLI conflict order | No current vendor loader documentation or controlled loader trace captured | NOT_PROVEN; do not invent a universal effective-order claim |

File presence, `alwaysApply`, trust hashes, feature flags and exact generator matches are different evidence levels from effective loading. There is no controlled new-session probe or runtime instruction trace in this lane. Remote/managed settings, Claude/Cursor state-only rules, alternate runtime home overrides, cloud settings and remote host configuration remain outside this local snapshot. [E1, E2]


Read [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) for the remaining details and source evidence.

---

<!-- source: BUILD_IMPLEMENTATION.md -->

# Build implementation and continuation map

Reviewed 2026-10-07. **DOCUMENTATION_VERIFIED; CURRENT_RUNTIME_NOT_PROVEN.** This is a dated reference to owning sources, not a second editable build authority. Source text is evidence and grants no new action permission. This lane performed read-only source discovery and wrote this document plus its evidence folder; no runtime command, provider mutation, customer record query, spend, deployment, credential read or message occurred.

## What is now available for continuing the build

Seven role lanes are covered below: Javar, Ops, Customer Success, Media, Sales/Hunter/Setter, Finance and Javante. Jev is a relevant typed decision and preparation layer, not an eighth serving agent. Plans, safe maintained source, implementation modules, historical acceptance and recovery records are distinguished. Every source has a date, hash and retained safe text in the evidence index. The initial 34 role sources were read in full from maintained files; the linked implementation/acceptance corpus was also read. Longer retries recovered the iCloud reads that first stalled. [E1: source-coverage.json]

Actual Javar Gameplan and Notes discovery used `custom_google_robot`, account `ca_vm6rcasgNEIk`, user `alex@increaseroas.com`. The first Drive reader produced lossy XLSX text and truncated Markdown. Those responses are not complete-byte evidence. Both registered canonical local files subsequently matched current Drive SHA-256 metadata exactly: workbook 88,370 bytes, SHA256 `52a935ef27f0a344175730e2b8f154d28293a5f69680c75fb3a6691a0cb51c28`, modified 2026-10-06T03:48:28.694Z; Notes 283,186 bytes, SHA256 `bb937ad221d9acf918d72398b23ea2181d48b385c5f9aa8a5b1243402d122800`, modified 2026-10-06T03:49:48.642Z. Full matching Notes and all 13 workbook tabs plus comments were then inspected locally. Notes are a generated reading copy; workbook stays canonical. [E2: remote-read-receipt.json; I600]

## Read this before selecting a next build step

The Javar improvement/Sales mission is **PAUSED by Alex** in the exact current checkpoint, and all G1–G4 acceptance gates remain incomplete. Documentation discovery does not resume it. Existing Director retains canonical ownership; recovery candidates are idle and unenrolled. The private loader and baseline have accepted local reviews with execution disabled; the native guard remains returned design, not an implemented operational guard. The Cloudflare permission correction is **NOT_WRITTEN**. StateEntity proposal remains draft. No mission writer/reader issuance or append→durable→Observatory proof exists. No historical SalesBench/hidden-holdout, measured production improvement or live no-send shadow acceptance exists. [I601, I602; E2 workbook DEFINITION OF DONE]

Safe continuation after a separately authorized resume: recover `CURRENT_MISSION_STATE.md` and `mission-graphs/javar-gameplan-v1.md`; use the current ownership map; resolve Lab design, permission-package corrections and owner StateEntity proposal in their existing owners' areas. Do not activate idle recovery chats or recreate resources from old labels. This sequence comes from the saved checkpoint, not a new execution instruction. [I601]

## Role continuation matrix

| Role | Accepted or observed historical evidence | Implemented source / continuation owner | Current binding and precise limit |
|---|---|---|---|
| Javar | September 22–24 source/installed acceptance, native routing/skill-save and normal owner Telegram turn. September 14 worker handoff reached revision19. | `agents/ea/startup`, capability discovery, setup checker, reviewed runtime updater; `javar_isolation` and team client preserve scoped mechanics. Direct execution is current guidance; handoffs require explicit request. [I001–I005, I422, I461, I472, I492, I511, I521–I524] | EA computer `d9b475e2-47b2-46d4-b8eb-102564f93283`; home `/home/orgo/lil-smoove/home/.hermes`; workspace `/home/orgo/lil-smoove/workspace`; Nous DeepSeek V4 Flash in dated serving record. October inventory separates main/root/Manny/canary profiles. No fresh serving probe here. |
| Ops | Isolated foundation accepted September9; September10 core packet revision5 independently verified; September14 bounded delegated run revision19. | `team_client.py`, materializer, team dispatch/worker source, Ops contract bridge and reconciliation harness. Local role tasks are not shared state authority. [I006–I007, I472, I479, I500–I501, I518–I520] | Old accepted host `9899abd2-57b0-4b76-a59a-1f0ba7ee538f` was removed October5. Replacement SPARE-Ops `47a4ba7c-9908-44f7-aa32-b7da8e18ac85`, workspace `c523a888-eec5-4501-b25d-b6d591a3a90a`, control-plane running only. Reinstallation/home/model/customer binding and startup/reboot persistence are NOT_PROVEN. [E2] |
| Customer Success | README points to accepted customer-issue intake and coordinated packet; issue remained unresolved. No current client records inspected. | `csm/knowledge.py`, scoped GHL read seam; SOUL separates method from live customer truth; binding/runtime files are templates/examples. [I008–I011, I505, I479] | Former host `41e29019-a1a2-456d-83f5-91ec206848fe` removed. Replacement SPARE-CSM `7cedbb4b-0610-4241-907e-edc19b45cf57`, workspace `6cda999c-708e-4121-8531-383640f97290`. Running VM is not CSM placement/serving proof; exact live home/profile/provider mapping unknown. [E2] |
| Media | September10 HOLD/no-change core packet supported three live reference reads; 92 catalog entries remained discovery-only. No performance improvement acceptance. | Scoped read-plugin Meta/GHL/RAG adapters, customer binding/runtime templates. Candidate handlers fail closed until actual identity, credential references, RAG and adapters are bound. [I012–I016, I506–I508, I479] | Former host `5dac6fd0-833b-43e0-8492-63462bb965e4` removed. Replacement SPARE-Media `c8aed3e5-6228-449e-b744-9d02466669c1`, workspace `d4e5f8db-c4c1-4727-8fc0-c876a4602e52`. Guest/runtime/tool acceptance unknown. [E2] |
| Sales / Hunter / Setter | September10 bounded public-prospect research and durable handoff accepted; duplicate/suppression and channel-eligibility review remained open. Audit workflow installation is not real-contact end-to-end acceptance. | Hunter is a function in existing B2B/Setter lane, no separate machine. Setter plugin declares `setter_knowledge_query` and `setter_ghl_read`, version0.1.0; playbook/knowledge code are inspected source. [I017–I021, I446, I493, I509, I515] | B2B Sales Agent computer `2472bdb6-ae8f-4417-a4d0-103df5618d60`, workspace `87d53061-ba01-4ff0-94c7-67057700af27`, `/root/.hermes` dated inventory. Provider/customer grants and suppression/outreach eligibility require new scoped readback; no live sends or booking proof. [E2] |
| Finance | Offline two-company scenario accepted September10; later rollout preface records native Nous consent and Supervisor running, accounting tools still disabled. | `report.py`, `quickbooks_read.py`, run_acceptance; fixed-host GET-only CompanyInfo/P&L/BalanceSheet/CashFlow/VendorExpenses contract. Credential lifecycle/owner registration remain activation work. [I022–I026, I502–I504, I514, I479] | September10 purchased Finance host `8274a62e-a552-409d-82c4-7c233f2c04d7` and `/home/finance/.hermes` are historical; host removed October5, replacement now JAVAR-LAB `0c1ce74e-176b-48f1-bf80-c38139036164`, workspace `87ba4c76-bc3a-4d2c-84d6-c26f2f1b3117`. Lab Hermes0.21.5 installed but model NOT CONNECTED. No present Finance placement or real company/realm report proof. [E2] |
| Javante | September22 clean setup/checkpoint/reliability/scheduler acceptance; September23 native business-access recovery source records Telegram/A2A preserved. | `javante/setup` owns reviewed recovery; evolving live knowledge remains live-home owned. Scheduler checks distinguish protected hash expectations from mutable USER/KNOWLEDGE/MEMORY. [I027–I034, I455] | `Sashas-Mac-mini.local`, `/Users/sashairis/.hermes`; Chrome AGENT MINI / agent@ identity historically observed. Source accepted0.21.4; October5 installed metadata0.21.5. Current serving version, scheduler, login and A2A health untested. [E2, I027–I034] |

## Accepted decisions and implementation boundaries

**One home per fact.** Javar INDEX is first navigation. Protected setup/route source belongs to Build; installed copies are deployment artifacts. Current September24 AGENTS/INDEX retire Javar Sheets/Notion as instruction stores. The September15 repository inventory and September22 instruction-ownership receipt have older wording that still calls Notion status/decision authority; retain them as chronology, not current precedence. Ops/Media recipes also retain historical Notion pointers and therefore need current-source reconciliation before reuse. [I001–I004, I419, I492]

**Customer isolation has multiple contracts.** Role templates require independent role/home/owner-DM/customer scope. Materializer rejects `ea_javar`, `alex_private`, Javar's serving home and unexpected binding fields; verifies accepted baseline hashes; emits a candidate with knowledge, sends, delegation and provider writes disabled until bound. This is source behavior, not executed acceptance in this lane. Existing accepted-baseline guard may stop newer source and must not be silently refreshed from live drift. Installed September15 reader additions are outside the older canonical builder; using that builder as a full current installer would omit accepted functionality. [I500, I416, I419]

**Delegation is bounded and optional.** Source Ops contract carries task revision/request IDs, worker model, constraints, checkpoint and resume action; Javar independently verifies. September14 receipt supports one assisted run through actual gated recovery and final revision19, not autonomous fleet completion. Javar's September24 operating guidance says direct work by default and explicit requested handoff. The older September11 B2B playbook says Javar assigns multiple specialists by default; that conflicts with later direct-execution guidance. Do not treat the old playbook as current auto-delegation authority. [I002, I007, I472, I515]

**Finance is further along than the role README, but no longer on its old host.** The rollout preface supersedes older no-host/no-auth statements: Finance Slack installed, native Nous authorized and historical Supervisor started; QuickBooks still unbound. The October5 removal/replacement note supersedes that host availability. Offline tests validate company/realm/currency/basis separation and withheld margins with missing allocation; they do not prove consent, persistent secret storage, live accounting totals or monthly report delivery. [I514, I479, E2]

**Native runtime changes supersede older isolation architecture.** September22 receipt records Hermes0.21.4 reviewed residual patch and `javar_isolated` provider. The maintained updater README describes the later clean-native route: terminal backend `local` as unprivileged javar, explicitly host-visible rather than per-task filesystem sandbox; business routes/approval/profile checks remain public plugin boundaries. Do not restore the older sandbox/provider architecture from a dated receipt. Reply alerts are notification-only under the later native contract; historical post-delivery correlation is not proof of currently registered correlation. [I005, I461]

**Version evidence is not a single number.** Javar September22–23 accepted0.21.4 and reviewed tagv2026.9.21, exact commit `d337b736aa1e8ebecfab043842d13e4a2d2f48a3`; Javante setup records0.21.4 but October5 package metadata0.21.5; Lab replacement installed0.21.5+7498.gebadb54. Historical audit factory v2.0.2 in September15 inventory versus current Javante WORKFLOWS v2.0.3 is dated source evolution, not a reason to overwrite installed packages. Current serving release requires appropriate host proof. [I419, I461, I005, I027, I032, E2]

## Jev boundary and continuation

Jev uses structured questions/answers, state and probabilities to grade supplied CRM evidence or a prepared draft. It does not retrieve CRM, write messages/code, own control flow or perform side effects. Surrounding code owns consent/privacy review, evidence gathering, deterministic gates, persistence and delivery. A speaking model still writes responses; a probability is not action permission or measured sales benefit. October7 guide names `typesafe/jev-1.13` through System One/decision API, and describes hold/unknown behavior, human calibration and hidden holdouts. These are saved research findings, not reverified vendor facts today. [I603]

The October7 independent verification supports written prompt/SOP/toolkit and tested local preparation behavior; no API request, paid inference, customer contact, CRM write, training or deployment occurred in that acceptance. Automatic new-session discovery, actual API behavior, privacy review, human rubric calibration and deployed effectiveness remained unverified. A separate later exploratory actual-Jev result corpus exists; it contains conversation-derived data and was excluded from this no-client-content lane, so this map does not claim that no later API calls exist. Actual production integration or accepted sales lift remains NOT_PROVEN by selected evidence. [I604–I605]

## Evidence closure and exact residuals

The source register records selected maintained role documents, all current `docs/plans/*.md`, safe historical run receipts, targeted implementation modules and Javar mission graph/checkpoint. Full safe bytes are retained with SHA256/date; relevant sections below are embedded so a build continuation reader does not need to guess content from a filename. Recursion is bounded by subject: role build contract → local linked plan/implementation/acceptance/recovery; procedural/configuration/service dependencies belong to their owning parallel lanes. Tests were read by historical receipt rather than executed. Live runtime paths, client-bearing originals, credential stores, historical raw customer messages and exploratory Jev case data are excluded. This is not a whole repository/fleet audit. [E1, E3]

Every parsed Markdown/path link from this source corpus is enumerated in `linked-source-closure.json`: READ, EXCLUDED with reason, DEFERRED_OWNER, or NOT_INSPECTED. NOT_INSPECTED is a precise residual, never implicit closure. Exact private originals behind sanitized receipts were excluded because they may include client data/secret-bearing readbacks; sanitized source does not independently prove those private receipts' bytes or runtime behavior. The Gameplan's linked private worktrees/raw sales recheck data and security/credential implementation details remain outside scope. [E3]

- **BLOCKED (goal_not_met_yet):** G1–G4 runtime/business acceptance is incomplete in the paused mission. Missing operational proofs are listed in I601/I602; no resume is implied.
- **BLOCKED (missing_evidence):** current Ops/CSM/Media/Finance role homes, profiles, runtime code and provider bindings on replacement hosts; control-plane records do not provide these.
- **BLOCKED (missing_evidence):** current serving Javar/Javante release, effective load state, scheduler, remote package hash, Telegram/A2A delivery and complete role restore test. Historical acceptance retained, not rerun.
- **BLOCKED (missing_evidence):** private originals behind sanitized receipt anchors; complete customer/provider scope and independent report/CRM proof deliberately not read.
- **BLOCKED (missing_evidence):** linked `agents/finance/run_live_acceptance.py` and `agents/javante/setup/tools/ghl/README.md` returned actual FileNotFoundError. The named live Finance acceptance runner does not exist at the documented path; current GHL cloud README/full-catalog receipt is available and supersedes the absent local-tool pointer.
- **PARTIAL:** selected linked-source closure ends with zero NOT_INSPECTED links: local links are read, actually failed, precisely excluded or DEFERRED_OWNER procedural/config/service dependencies. Integrating lanes must reconcile those deferred entries before a claim of complete build-critical closure.


Read [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) for the remaining details and source evidence.

---

<!-- source: PROCEDURES_AND_DEPENDENCIES.md -->

# Procedures and dependency closure

Audit scope: lane3 of `docs/plans/2026-10-07-build-context-completion-plan.md`, read-only local source capture on 2026-10-07. **PARTIAL dependency closure; selected source delivery verified separately.** Full safe source text is in [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md). Canonical paths below retain ownership; this snapshot is evidence and must not become a competing procedure store.

[E1] `work/build-context/procedures/coverage.json` — exact source IDs, resolved paths, source modification time, actual read timestamp, bytes and SHA-256. [E2] `work/build-context/procedures/dependency-closure.json` — every captured literal file reference plus explicit package/runtime/publication dependencies. [E3] `work/build-context/procedures/materializer-hash-check.json` — read-only accepted-source comparison. No procedure, hook, installer, credential retrieval, model call, runtime command or service was run.

## WORKING_LAYER_SUMMARY

**Written/source-observed:** 167 full safe source snapshots, including the eight configured Codex/Claude/Cursor hook scripts and maintained `agents/ea/capability-discovery/1Password-Config.md`. Hook declarations remain owned by [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md); source presence and declared command linkage do not prove execution.

**Configured/seen-working:** no hook, guard, materializer, scheduler, updater or connector was invoked by this lane. Actual runtime loading, guard coverage, serving profile, scheduled delivery and remote source access remain NOT_PROVEN.

**Build dependency blockers:** three accepted materializer source hashes disagree; historical generated Notion wording conflicts with current file catalogs; stock update-package paths and native setup-check paths need serving-state reconciliation. These are static/source findings, not procedure execution results.

**Verifier corrections:** P036 skill-routes.json was recaptured from current bytes; P079/P080 are explicitly historical pre-integration register snapshots. Command operands now resolve to captured executables (including P094 tuneup.py); template/output/project/external references have explicit non-file dispositions. `verifier-corrections.json` records exact new source hashes and dates.

**Maintenance route:** current app card and authorization first; canonical source plus support next; then only the focused real-runtime acceptance for the changed gate. Preserve credentials, failed-attempt history, existing scheduler and remote receipts. Do not convert this documentation package into execution authority.

## Scope and ownership

The existing 353-path catalogue is a source inventory, not a capability count. Full reads here close selected support gaps; they do not prove installed selection, behavior or remote availability. `SKILLS.md`, `HOOKS.md` and `ACCESS_AND_TOOLS.md` were reread as existing registers. Their previous runtime observations remain dated history; this lane performs no fresh provider/runtime refresh.

App cards take precedence over generic skill details. In particular the Composio card requires a named account and schema review; generic CLI examples without an account, mixed send examples, raw proxy examples and auto-link advice are source examples only. Current chat authority and target app gates control any future action. A coded stop must not be routed around.

## Procedure matrix

| Procedure / canonical owner | Inspected support | Result and remaining evidence |
|---|---|---|
| Hermes role setup — `.agents/skills/hermes-team-setup` | reuse map; materializer; baseline; actual guarded inbox files; team client/plugin/package/binding examples | PARTIAL: schema and guards inspected; actual role deployment, Slack binding, native discovery and representative business acceptance not tested. Current accepted-source hashes disagree for three guarded files. |
| Javar tool onboarding — `.agents/skills/javar-add-tool` | startup INDEX/TOOLS/AGENTS/WORKFLOWS; maintained Composio and 1Password guides; app cards | PARTIAL: pointer and smallest-change procedure captured. Installed Orgo guides, actual loader, harmless native operation and owner conversation readback uninspected. |
| Hermes controller — synced Hermes Boss Director source | full local menu/source; current setup/recovery and cards for precedence | PARTIAL: copied controller describes historical app/tool/host routes. Its referenced HERMES-OPS and actual bot session/cost/runtime state are uninspected; do not execute old route commands as current truth. |
| Composio execution/onboarding — `.agents/skills/composio-cli` and `composio-custom-mcp` | CLI troubleshooting/power-user/dev refs; build/connect and acceptance refs; provisioning standard; current card; hub README | SOURCE VERIFIED; behavior NOT_PROVEN: no named-principal execution, connection refresh, key move, login or hosted schema was tested. |
| Connector records — `.agents/skills/tool-card` | all local references; card template; tiers source; publication sync scripts | PARTIAL: publication sequence inspected; credential wrappers/mover, platform APIs, hosted readback and workbook upload receipts excluded/uninspected. |
| Shared lifecycle — `.agents/tools/unify/skill-lifecycle.md` | manifest/checker; instruction builder; unify/dependency/plugin drift tools; git setup; pre/post commit sources | SOURCE VERIFIED; configured versus effective selection still separate. No lifecycle command, build/apply, setup, commit hook or target invocation performed. Configuration source ownership belongs to configuration lane. |
| Update/rollback — Build `agents/ea/runtime-update` | README; manifest; update_runtime.py; selected package plugin/profile markdown assets | PARTIAL: reviewed source and dependencies captured. Credential launcher/raw profile config, remote upstream checkout/venv/backup/service state, pinned upstream tests and installed runtime are uninspected. |
| Startup/scheduler/recovery — Build `agents/ea/startup`, `setup-check`, `maintenance` | heartbeat troubleshooting; setup-check SOP/checker/intended-state; upkeep entry/implementation; instruction consistency source | SOURCE VERIFIED; scheduled behavior NOT_PROVEN: job registry, last result, streak, delivery, pending packets and installed instruction hashes require remote collection and local combine. A direct script success or running supervisor does not prove delivery/reboot persistence. |
| Handoff and maintenance — `.agents/skills/ce-handoff`, `weekly-tuneup` | create/resume refs; tuneup refs and script | SOURCE VERIFIED; no handoff workflow or tuneup executed. Held-out grader material intentionally remains unread. No recurring job created. |

## Concrete conflicts and constraints

1. **BLOCKED (goal_not_met_yet): materializer guard.** Three source hashes disagree with the accepted baseline: `__init__.py`, `tasks.py`, `plugin.yaml`; `knowledge.py` and `approval_store.py` match. The script refuses any mismatch before writing a candidate. [E3] proves this read-only comparison; it is not a materializer execution result. Recover the accepted source or review changed source and obtain new component acceptance before refreshing the guard. Do not remove the guard.
2. The materializer generated SOUL text still says build status belongs to Notion, while current `hermes-team-setup` and `javar-add-tool` use file INDEX/TOOLS and retain retired records only as history. This is a source conflict, not authorization to repair it in this lane.
3. The update package manifest names `hermes-agent-javar-0.21.4-stock` / `venv-0.21.4-py311-stock`, while setup-check operator instructions collect with `venv-0.21.4-py311-native`. The manifest is a package target, not fresh serving identity proof. Resolve the exact installed role/profile and reviewed active path before a switch.
4. The update manifest pins upstream tag `v2026.9.21`, commit `d337b736aa1e8ebecfab043842d13e4a2d2f48a3`, Python `3.11.15` and SQLite minimum `3.51.3`; this lane records source declarations, not installed versions.
5. The setup checker combines a remote report with maintained source only after validating exact manifest hash, freshness, schema and completeness. It separates deployment/source/gap status and cannot prove model acceptance, tool execution, cost caps or instruction reading. Its trusted transport is consistency evidence, not cryptographic attestation.
6. Post-commit dispatch starts asynchronously. Skills-only changes invoke local lifecycle acceptance; cards/instructions trigger sync_notes then instruction apply then cards_to_sheet only after prior success. A successful commit or launched process is not publication completion. No hook was run.
7. Knowledge upkeep recovery resumes a pending packet with bounded retries; instruction consistency reuses the existing daily digest. Do not reset cursors, regenerate intended-state from drifted deployment, or add replacement schedulers to hide an error.

## Configured hook source linkage

The configuration lane captured safe declarations in `.codex/hooks.json`, `.claude/settings.json`, `.cursor/hooks.json` and safe Codex configuration. This lane now captures full safe implementations for Codex/Claude/Cursor Herdr session hooks, Codex/Cursor Composio adapters, shared Composio/chat guards and Cursor `hooks/deny-fast-subagent.sh` (P131–P138). The guards import `composio_guard.py`; source imports are captured. No guard was imported or run by these capture scripts.

Herdr implementations are managed socket-state publishers whose environment prerequisites and payloads remain source evidence. Codex/Cursor adapters reshape native payloads for the common Composio guard; Cursor has no approval release path, while Codex source limits release to its explicit environment-controlled interactive transcript path. The chat guard handles chat/memory growth and handoff gating. Cursor fast-subagent source tests the exact model identifier `fast`, not arbitrary names containing those letters. These descriptions explain code only; no functional guard coverage or hook effectiveness is claimed.

The maintained 1Password guide P139 was read at its actual capability-discovery path. It contains reference paths and dated historical access/repair claims, not secret values. It does not prove current vault access, current connection status or another role’s permission. The prior incorrect Build-root lookups remain failed discovery history and are superseded for documentation by P093 and P139.

## Implementation-linked procedure closure

[E5] `work/build-context/procedures/implementation-deferred-closure.json` closes all 23 incoming references across 15 unique paths: 21 reference rows have full safe procedure captures, one is an existing configuration-lane capture of Build AGENTS, and one is **MISSING_LOCAL_SOURCE** at `agents/javante/setup/skills/productivity/javante-ghl/SKILL.md`. The unavailable exact path is retained; it is not silently replaced by a different skill. No reference remains deferred to an unnamed owner.

The new sources include Javante GHL workflow, Meta and Google procedures with business-access/cloud-bridge support; EA Native/GHL/Meta and on-demand route guides; the sales-agent core and its data/safety/runtime references; safe dataset/guard/send-hook/simulation/skill/config templates; synthetic scenario fixtures; and the dataset builder’s actual contract-module dependency. Direct source support is captured or cross-linked without reopening raw client data or hidden holdouts. System review-agent remains provider-owned and was read only; no review workflow or helper was invoked.

All dated access, authentication, catalog counts and acceptance narratives inside these guides remain historical source claims. Javante’s shared GHL Command cloud installation and company OAuth gateway are distinct; local source does not prove either current connection. Google browser access does not establish Google CLI OAuth. Sales templates remain shadow/log delivery examples requiring current runtime-key verification and actual schema/data adaptation before use. The dataset builder hardcodes example source/output paths and imports the recorded sales_contract module; its script was not run.

**BLOCKED (missing_evidence):** the exact Javante productivity GHL skill path is absent. **Outside this documentation scope:** raw conversation exports, buyer labels, live credential state, held-out cases, installed loaders and current provider probes. These exclusions do not prevent source delivery, but they prevent claiming a ready sales runtime or current business access.

Hash check label in [E3]: `MISMATCH_OR_MISSING` versus `MATCH`.
[E4] `work/build-context/procedures/runtime-package-hash-check.json`: 34 captured package hashes match the runtime manifest; four members remain UNINSPECTED (credential launcher, gateway launcher, raw Manny profile config and empty marker). This comparison does not run verify_package or prove installed bytes.

For the full source/dependency registers, read [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md) and [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md).

---

<!-- source: SERVICE_BUILD_CONTEXT.md -->

# Service build context

Prepared 2026-10-07. [Start here](START_HERE.md) · [Implementation](BUILD_IMPLEMENTATION.md) · [Procedures](PROCEDURES_AND_DEPENDENCIES.md) · [Infrastructure](INFRASTRUCTURE.md) · [Service sources](SERVICE_SOURCES.md)

This adds implementation and configuration context to the October 5–6 inventory. It covers selected maintained service sources, one live Cloudflare Worker settings read, and three live configuration operations plus one stage-shape recheck in one GHL location. **It is not a complete fleet, service-health, workflow-behavior, customer-data or recovery audit.** The professional standard used here is an explicit dependency register with dated evidence, exact identifiers, safe source snapshots, and a separate boundary for provider metadata versus runtime acceptance. [E1–E8]

## Evidence and freshness

| Evidence | Source | What it establishes |
|---|---|---|
| E1 | `outputs/AI_Infrastructure_Gameplan.xlsx`, saved SHA-256 `a4edbad6d5d088d6a6dd13584446f6b1f1d63112623bbe8fc2c7468eb99ac303` | October 5–6 inventory and saved read scope; no new health acceptance |
| E2 | `work/build-context/services/saved-resource-map.json` | Exact selected workbook rows, all 30 Worker names, 59 relationships, 201 target-unexposed binding fields, and selected host/configuration metadata; captured Oct7 |
| E3 | `work/build-context/services/source-coverage.json` and `customer-policy-retry.json` | 19 maintained source/example/schema/receipt files read; paths, hashes, sizes, dates, imports and schema facts. Customer policy first timed out, then succeeded within a second bounded read |
| E4 | `work/build-context/services/cloudflare-dev-rag-settings.json`, `log_DlhC6IKukuNz` | Oct7 GET settings for exactly `dev-rag-worker`, with secret/plain-text values suppressed before returning |
| E5 | `work/build-context/services/ghl-b2b-configuration.json`, `log_vUeobAin238-`, `log_ixjRlVLKmV9E`, `log_WkbvY82ga1xa`, plus `ghl-pipeline-shape.json` / `log_YQmW5L_IDzKc` | Oct7 configuration-only reads in exactly Hot Tub Launch B2B; no events, contacts, messages or customer records |
| E6 | `work/build-context/services/provider-route-events.json` and `cloudflare-settings-payload.json` | Approved routes, discovery, named accounts, exact GET and response projection; network/schema transient failures retained |
| E7 | `work/build-context/services/checks.md` and `acceptance.txt` | Local deliverable checks only; independent integration/publication acceptance belongs to the primary verifier |
| E8 | [SERVICE_SOURCES.md](SERVICE_SOURCES.md) (local capture `work/build-context/services/SOURCE_SNAPSHOT.md`) | Full safe text of the 19 allowlisted maintained service sources, examples, schema and historical receipts, keyed to E3 hashes; no remote runtime configuration or customer content copied |

E2–E7 are local evidence pointers; E8 contains the full safe source text and current provider projections in the publishable package. The primary owns publication. Safe full source snapshots do not replace canonical ownership. All claims about local implementation are SOURCE_ONLY, unless a dated historical receipt or current provider read is explicitly named.

## Accounts and approved doors

Cloudflare's maintained card (updated Oct1) selects Composio `custom_cloudflare_api`, login `ca_IUuu0MrmsQya`, account `a3f549867f040e13df33e5bd18f785f4`. The account is named `Alex@increaseroas.com's Account` in the workbook. This run explicitly selected that login and account; it did not use a local Wrangler login, retrieve credentials, or change settings. The other saved Javar Cloudflare audit login is not substituted for it. [E1 Cloudflare row2; E4; E6; `/Users/alexlobaito/.agents/tools/cards/cloudflare.md`]

GHL's maintained card (updated Oct2) permits only `custom_ghl_oauth_crm` for CRM/configuration reads and `custom_ghl_command_builder` for builds/workflow audits. The saved CRM connection is `ca_OIfo_F6scXwN`; the saved builder connection is `ca_o1-FA70PbU3x`. The CRM operations catalogue read succeeded with the named CRM connection, and the exact B2B configuration calls succeeded. This establishes usable configuration reads in that location, not another principal's permissions or the builder runtime's health. [E5–E6; `/Users/alexlobaito/.agents/tools/cards/ghl.md`; ACCOUNTS.md]

Builder selection is shared state under the current card. Its required `switch_location` then `get_location`, exact-ID verification and restoration of the previous default were not invoked in this parallel lane. No conclusion about builder denial or builder availability is based on its `execution.taskSupport` metadata. Runtime execution and remote host probing were outside scope. [GHL card; E6]

## Cloudflare: implementation that can actually guide a build

The maintained `Build/agents/ea/rag/worker.mjs` is an implemented RAG/state/task service, not merely a resource name. E3 records its SHA-256 `3c83f7e5ab412550e02f892c46aa50f7ae11191315e1f70e8f43389668f39b13`, 860 lines and Sept23 canonical mtime. E8 retains its full safe source. The `wrangler.example.json` is explicitly an offline example named `hermes-offline-example`, not the live deployment configuration. Its `main=worker.mjs`, Aug25 compatibility date, `nodejs_compat`, `STATE/StateEntity`, `VECTOR_INDEX/dev-rag-knowledge`, SQLite Durable Object export, and disabled workers.dev/preview URLs describe an example contract. The live Oct7 settings read matches compatibility date/flag and exposes the same binding names/targets, but deployed-code equality, workers.dev enablement and actual retrieval remain NOT_PROVEN. [E3–E4; E8]

| Implementation surface | Source behavior and dependency | Build consequence / remaining proof |
|---|---|---|
| Authentication | Worker verifies RS256 Access assertion using issuer certificates, maps identities, and issues/verifies HMAC agent tokens; requires issuer/audience and server-side identity maps | Match exact serving identity and grants before acting. Names/types of identity fields were read; their values were intentionally excluded. Do not guess mappings from role names |
| `/query` | Customer policy requires an explicit permitted customer, query-only identity, 384 finite embedding values, registered source namespace/tenant/role filters, matching chunk text hash, and current source publication revision | This is source-controlled retrieval logic. Customer/source JSON imports and current index contents are uninspected; no retrieval request was run |
| `/state` | Durable Object-backed event/state operations; authentication and grants checked | SQLite state is designed in code; no live event rows or schema migration/state acceptance was read |
| `/team/task` | Server-side `TEAM_TASK_IDENTITIES` and `TEAM_WORKERS`; only Increase ROAS customer; task owner, lease/fence, worker capability, customer, approved model and actual acceptance/checkpoint requirements | Durable delegation exists in source. Serving worker registrations, assigned models and active leases remain unknown |
| `/knowledge/notes` | Query-only Javar identity plus server-side customer allowlist; bounded approved notes stored by customer | Source permits an approved-note store; this does not prove approval delivery or active notes |
| `/sources/publish`, `/withdraw`, `/stale`, `/status`, `/restore` | Source-specific identity/customer/Drive policy; snapshot/chunk hashes and Vectorize readback/retrieval verification; durable publication receipts and revision compare-and-set | Publication behavior exists in code. Restore requires fresh evidence and a separate source-specific, unexpired server-side grant matching the exact withdrawal. No publish, withdraw, restore or status call was run |
| `/health`, `/token`, `/ingest`, `/delete` | Routes exist in source; health reports binding presence, ingest/delete enforce authorization | No health endpoint or write-like route was executed. A future health response alone would not prove source retrieval or customer isolation |

[E3, E8: `worker.mjs`, `customer-policy.mjs`, `team-tasks.mjs`, `team-workers.mjs`, `source-maintenance-policy.mjs`, `source-publication.mjs`, `source-serving.mjs`]

The SQL implementation is concrete: Worker `events` contains ordered sequence, unique event ID/hash, schema/date, actor/client/session/entity metadata, payload and previous-event ID; `manifests` contains source version/chunk IDs/status/repository/ref/ingest run/date, with an event-hash index. Other maintained modules initialize `team_task`, `team_task_receipts`, `approved_notes`, `note_receipts`, `source_publications` and `source_publication_receipts`. Publication receipts use source/run identity and atomic revision checks; serving resolution fails closed when source state cannot be read, is denied/stale, or changes during retrieval. These are code-defined tables, not proven current remote table state. [E3; E8]

### Exact live binding/routing coverage

Oct7 live settings returned 16 binding names/types. `STATE` is Durable Object class `StateEntity`, namespace `d8302b544d8047bd8c63bed5e37c4783`; `VECTOR_INDEX` explicitly targets `dev-rag-knowledge`. The remaining 14 fields are `ACCESS_AUDIENCE`, `ACCESS_IDENTITY_MAP`, `ACCESS_ISSUER`, `DEV_ACCESS_IDENTITY_MAP`, `DEV_JWT_HMAC_SECRET`, `ENVIRONMENT`, `JWT_AUDIENCE`, `JWT_HMAC_SECRET`, `JWT_ISSUER`, `RAG_NOTE_IDENTITIES`, `ROLE_KNOWLEDGE_IDENTITIES`, `SOURCE_SYNC_IDENTITIES`, `TEAM_TASK_IDENTITIES` and `TEAM_WORKERS`. All their values were excluded; field presence does not identify customer or serving principal. [E4]

This resolves the target of **one saved target-unexposed field** (`dev-rag-worker` / `VECTOR_INDEX`) without rewriting the workbook's historical 201-field count. The Oct6 successful Vectorize list returned zero indexes. The Oct7 binding name therefore identifies the expected target but does **not** reconcile the discrepancy or prove index existence/access. Next evidence: a bounded approved metadata GET for that exact index, plus a separately authorized retrieval/identity acceptance probe. No index enumeration or probe was performed here. [E1 Coverage & Sources row3; E2; E4]

Saved Oct6 routing maps `dev-rag.increaseroas.com` and `dev-rag.increaseroas.ai` to `dev-rag-worker`; other custom domains map `increaseroasai.com` to `website-hot-tub-store-8` and both Professional Tree Surgeons hostnames to `pts-quote-funnel`. Saved routes map the Hot Tub Launch root/www domains to `hottublaunch-main`, funnel subdomain to `htl-practice-funnel`, and Professional Tree Surgeons root/www to `pts-quote-funnel`. These are routing metadata, not successful requests. Localhost tunnel origins remain relative to unproven tunnel host identities. [E2 relationships; E1]

### Dependency closure and precise omissions

The Worker imports eight modules/configurations: approved notes, customer policy, team tasks, source registry, source serving, source publication, publication storage and maintenance policy. The code modules were fully read and captured. `team-tasks.mjs` imports `team-workers.mjs`, also fully read. **`source-registry.json` was not read**: current canonical source/customer/Drive grants must be reconciled separately, with a safe configuration projection. Its structural schema was read in full: requires schema version, source ID/canonical location/customer/permitted roles/snapshots, and execution customer/alias/role mappings; it explicitly says no deployment authorization. [E3; E8]

Customer policy additionally imports these uninspected data/configuration dependencies: `customer-source.json`, `agency-source.json`, `csm-source.json`, `setter-source.json`, `csm-role-source.json`, `../../media/rag-candidates/weekly-client-check-in.json`, `../../media/rag-candidates/media-buyer-sop.json`, `../../media/rag-candidates/lead-quality-optimization.json`. No snapshot contents, customer records or embeddings were recursively fetched. E3 lists their exact paths. The deployed Worker source/version, dependency bundle and runtime registry were not downloaded. [E3; E8]

Only `dev-rag-worker` was mapped to inspected maintained Worker implementation; the other **29 saved Workers remain uninspected for code/schema/deployment parity**. E2 enumerates all 30 names and their saved bindings/relationships, including `increase-roas-oauth-gateway`, `ghl-command-universal`, `increase-roas-b2b-worker`, website/funnel/tracking/alert/MCP Workers. A similarly named local file or known purpose is not sufficient to bind their deployed implementations. D1 IDs, KV namespace IDs, R2 bucket targets and SELF service links exposed in the saved relationship sheet are preserved in E2; their schemas/content, queues, Pages builds, Access policy values, DNS serving behavior and tunnel host mappings were not inspected. There are no guessed targets. [E2]


Read [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md) for the remaining details and source evidence.

---

<!-- source: TEAM_MAP.md -->

# Team map

For continuing a build, read [BUILD_IMPLEMENTATION.md](BUILD_IMPLEMENTATION.md) and [BUILD_READINESS.md](BUILD_READINESS.md). The extension reads the full maintained role contracts, linked implementation and the byte-matched Javar Gameplan/Notes. Later removed/replacement-host evidence is recorded there; the selected snapshots below retain their original dates.

[Start here](START_HERE.md) · [Lessons and maintenance](LESSONS.md)

Reviewed 2026-10-07. Seven role pages summarize 34 allowlisted maintained source files. The professional standard used here is traceable source ownership: one current procedure owner, explicit evidence state, dates and recoverable pointers. This is a knowledge layer, not a runtime deployment.

| Agent / function | Ownership | Source files | Evidence state |
| --- | --- | ---: | --- |
| [Javar](agents/javar.md) | Executive assistant and operating catalog | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Ops](agents/ops.md) | Operational coordination | 2 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [CSM](agents/customer-success.md) | Customer onboarding, health and delivery follow-through | 4 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Media](agents/media.md) | Advertising analysis and creative briefs | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Sales / Hunter / Setter](agents/sales.md) | Hunter research and Setter qualification | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Finance](agents/finance.md) | Company-scoped accounting review preparation | 5 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |
| [Javante](agents/javante.md) | Mac mini creative and technical executor | 8 | DOCUMENTATION_VERIFIED; LIVE_HEALTH_NOT_CHECKED |

## Proven mapping and unresolved identity

- **Javar:** maintained TOOLS names EA Orgo and its home/work directory; inventory corroborates its computer/workspace metadata. The inventory’s multiple EA profiles remain distinct.
- **Javante:** maintained acceptance maps Sashas-Mac-mini.local to /Users/sashairis/.hermes. Source release 0.21.4 and later October 5 installed-version 0.21.5 observations are dated evidence, not current serving proof.
- **Ops:** historical foundation names an accepted computer. The October 6 SPARE-Ops is a different computer; current Ops placement is unresolved.
- **Customer Success and Media:** inventory proves spare computer/workspace membership only. Placeholder homes and model settings do not prove the serving role identity.
- **Sales:** Hunter is a function in the existing B2B/Setter lane, not a separate runtime. Inventory identifies that lane and /root/.hermes; serving behavior is untested.
- **Finance:** unbound examples and a sanitized purchased-host reference do not establish the actual host/profile/company.

The detail and exact identity evidence are in each role page. Sources: [E1] `work/agent-build-hub-local-manifest.json`; [E2] `work/agent-build-hub/package-verification.json`; [E3] `work/agent-build-hub/source-update-dates.json`; [E4] `outputs/AI_Infrastructure_Gameplan.xlsx`; each role page lists its complete numbered source set.

## Handoff and authority boundaries

Source documents describe Alex → Javar direct execution, explicit delegation → Ops coordination, and role-scoped worker handoffs. Javante preserves a separate Mac identity and receives compact briefs/Drive pointers. Sales audit preparation names Hunter research → Media PDF → Setter draft, with Ops/Javar keeping task evidence. These are documented operating relationships, not a test of present routes. A notification or local task record alone is not completion. Historical source approvals do not authorize this audit to execute any workflow.

## Maintenance and coverage

Use [START_HERE](START_HERE.md) for future audit/update procedure and [LESSONS](LESSONS.md) for corrections and ownership rules. Keep repeatable HOW in the maintained skill/procedure; this map contains only summaries and pointers. Complete source classification/hashes are in `work/agent-knowledge/roles-coverage.json`. Referenced private completion records, source plans, implementations, remote mutable memory/configuration and full role installations were not opened just because these 34 files link to them.

Existing [Agent Builds & Setup hub](https://drive.google.com/drive/folders/1_gIjJUQZ9gXbJGctSRNVeDcImlcLu87w) is recorded by [E5] `work/agent-build-hub/drive-state.json`; role pages preserve its folder/shortcut pointers. Links are recorded metadata, not a fresh access check.

---

<!-- source: ACCESS_AND_TOOLS.md -->

# Access and tools

Knowledge audit: 2026-10-07. Start with [START_HERE.md](START_HERE.md), then read [ACCOUNTS.md](ACCOUNTS.md) for saved connection IDs and declared personal plans. Those IDs are an inventory, not a recommendation to use every connection.

## Route selection

Alex's current chat instructions require Composio first. Where a terminal is available, discover tools with `composio search` and execute the returned tool with an explicitly named `--account`. Search does not accept `--account` in the observed CLI; login selection belongs on execution. Where no terminal is available, use the official Composio app's search and execution tools with an explicit principal/account. Read the app card before the first app call. Do not copy a search result's sample call without checking its effect and schema.

The maintained cards live at `/Users/alexlobaito/.agents/tools/cards/<app>.md` on Alex's Mac. Other machines use the approved IR Notes `CUSTOM_IR_NOTES_GET_APP_RULES` route with `app=<card>` when available. A local path is not proof that a remote agent can read it. If the card or route cannot be read, record the limitation rather than inventing permissions.

## Google Workspace

The current card `/Users/alexlobaito/.agents/tools/cards/google-workspace.md` (updated 2026-10-03) selects `custom_google_robot`, connection `ca_vm6rcasgNEIk`, and `user=alex@increaseroas.com` by default. The robot's named-user parameter determines the Google principal. Existing Gmail/Docs/Sheets/Drive connections in ACCOUNTS belong to agents and must not be treated as Alex's default routes.

The knowledge publication task uses this robot as Alex. Registered workbooks remain at their registered IDs; updates use the maintained upload helper and must match the final local bytes. The registry is `/Users/alexlobaito/Projects/master-connector-repo/knowledge/workbook-drive.json`. Helper: `/Users/alexlobaito/.agents/tools/connectors/google_robot/drive_upload_file.py`. Never create a replacement registered workbook to work around a failed update.

## Credentials and identities

Credentials remain outside this knowledge layer. Refer to their approved Composio/1Password route, without copying values into Markdown, a registry, chat, URLs, screenshots, or logs. Claude Code and Codex use the approved op CLI/connectors-sync route where configured; hosted Claude/ChatGPT receive keys only through Composio under Alex's current rule. Saved credential titles in ACCOUNTS are historical pointers, not newly verified retrieval paths.

Declared `alex@increaseroas.com` and `agent@increaseroas.com` Hermes identities have not been bound to specific serving profiles by this audit. Read [GAPS.md](GAPS.md) before making that assignment.

## Actions and maintenance

This document grants no new spend, client contact, deletion, security-setting change, deployment, or recurring automation. Follow current chat authorization and the exact app card. Never change route to bypass a rejected call. A connector marked ACTIVE, a saved login, a hook source or a successful configuration check does not prove live service behavior.

A public-page Exa fetch in this chat was rejected by automatic approval review as spending without approval, although the local Exa card describes ordinary fetches as freely runnable. It was not retried through another route. That policy/approval mismatch is a recorded gap, not evidence that all web access is unavailable.

After a route/account correction, update its maintained card or registry only within authorization, then refresh this reference and follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md). Add a verified lesson to [LESSONS.md](LESSONS.md); update START_HERE's completed audit metadata only after verification and publication checks pass.

Route-event evidence: local `work/agent-knowledge/route-events.json` and `search-help.txt`, captured 2026-10-07. The Exa item is a recorded current-chat approval-review response; it is not a fresh policy acceptance test.

For a Markdown read, compare the returned text against the verified stored checksum. One robot read returned incorrectly decoded punctuation; [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) contains the exact checksum-guarded recovery, and [LESSONS.md](LESSONS.md) records the proof. Stored Drive bytes were correct; no service fix was deployed.

---

<!-- source: CURRENT_STATE.md -->

# Current evidence state

Knowledge audit: 2026-10-07. This file describes evidence freshness, not a fleet-health check. Read [GAPS.md](GAPS.md) and [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) before acting.

| Area | Evidence | What it proves |
|---|---|---|
| Infrastructure and connected accounts | October 5–6 inventory; 23 workbook sheets | Saved resource/account/configuration metadata with per-row state and dates |
| Current Drive workbook identity | `work/agent-knowledge/workbook-live-metadata.json`, 2026-10-07 | Original Drive workbook ID still reports the SHA-256 matching the verified local workbook; this is not a new provider inventory |
| Build/setup sources | Seven dated ZIPs; 34 exact source files; independent package receipt | Curated documentation as verified at snapshot time; current maintained-source reads may be limited |
| Local skills | Complete SKILL.md reads on 2026-10-07; exact coverage/hash register | Entry-file contents, source placement and scoped discovery metadata; supporting-resource execution and runtime selection not proved |
| Hooks | Selected safe hook source/config reads on 2026-10-07 | Source presence and selected configured hook entries; execution not exercised |
| Personal subscriptions and Hermes emails | Alex's current chat declarations, 2026-10-07 | Declared facts, not invoices or a serving-profile identity check |
| Knowledge publication | Initial30-file batch verified2026-10-07; final-byte receipt in `work/agent-knowledge/drive-publication.json` | Each publication is accepted only when its saved remote size/SHA-256 readback matches the final local bytes. Consult the latest receipt after updates |

## Build-context extension

The October 7 extension reads actual instruction/configuration sources, accepted build records, supporting procedure code and selected service configuration. Use [BUILD_READINESS.md](BUILD_READINESS.md) for requirement-level acceptance and [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json) for safe source/omission records. The full safe configuration and procedure snapshots are dated evidence copies; maintained sources retain ownership.

Provider reads are scoped and dated in [SERVICE_BUILD_CONTEXT.md](SERVICE_BUILD_CONTEXT.md). They do not refresh every workbook row or prove current fleet health. Build status, source completeness, current loading, configured resources and observed execution remain separate. Consult the extension audit receipt before treating its delivery as accepted.

## Dates mean different things

The seven ZIPs were published October 7. Source-file modification times do not become October 7 just because their snapshots were uploaded. The last source timestamp observed for Javar was September 25, Javante September 23 (Detroit timezone), Ops September 21, and CSM/Media/Sales/Finance September 14. Some files have Git dates; others do not. File modification time can reflect a copy or filesystem operation and does not prove a semantic update or running-agent update. Exact observations: `work/agent-build-hub/source-update-dates.json`.

The START_HERE completed-audit date covers this knowledge audit only. Runtime updates, current disk use, active principal/profile mappings, plugin selection, current billing and remote skill distribution need their own evidence. Record them as UNKNOWN/NOT_PROVEN until checked, then enrich the owning record with its exact source and date.

## Source authority

Source workbook and canonical skills retain their existing homes. Role documentation stays in the maintained Build project. This hub contains a readable, dated interpretation with pointers. The generated one-shot briefing is a view of these knowledge files and must be regenerated, never independently edited. Conflicting new observations should be dated and reconciled against the maintained source before replacing a claim.

After a verified fix, write [LESSONS.md](LESSONS.md). Before claiming a completed audit, follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) and update [START_HERE.md](START_HERE.md).

---

<!-- source: ACCOUNTS.md -->

# Accounts and permitted routes

[Start here](START_HERE.md) · [Lessons and updates](LESSONS.md) · [Infrastructure](INFRASTRUCTURE.md) · [Accounts](ACCOUNTS.md)

Prepared 2026-10-07 from saved October 5–6 evidence. This is a readable derivative; the source workbook remains the detailed inventory. No provider was contacted in this extraction.

Evidence states: **DECLARED** means Alex supplied the statement in the current brief; **READ_VERIFIED** means the saved exact read/list/probe succeeded within its stated scope; **CONFIGURED** means saved settings/account metadata; **HISTORICAL** means workbook STALE, dated evidence without a current re-read; **UNKNOWN** means evidence absent. None establishes current service health, billing, permissions, or an active serving agent.

## Declared plans and identities

| Surface | Exact statement | State | Login/profile or billing proof limit |
| --- | --- | --- | --- |
| Cursor | personal $200/month | DECLARED | UNKNOWN |
| Claude | personal $200/month | DECLARED | UNKNOWN |
| Codex/ChatGPT | personal $200/month; one declared subscription | DECLARED | UNKNOWN |
| Grokbot | plan unknown | DECLARED / UNKNOWN | UNKNOWN |
| Manus | studio 2.09 | DECLARED; exact text, meaning unverified | UNKNOWN |
| Hermes | alex@increaseroas.com | DECLARED | Not linked to a specific saved profile |
| Hermes | agent@increaseroas.com | DECLARED | Not linked to a specific saved profile |

Source [E3]. The three priced declarations total $600/month as declared arithmetic, not verified invoices; Codex and ChatGPT are counted once. No Manus currency, billing interval, product edition, or version is inferred from “studio 2.09”. No declared Hermes identity is automatically assigned to a profile below.


Read [ACCOUNTS.md](ACCOUNTS.md) for the remaining details and source evidence.

---

<!-- source: INFRASTRUCTURE.md -->

# Infrastructure inventory and boundaries

[Start here](START_HERE.md) · [Lessons and updates](LESSONS.md) · [Infrastructure](INFRASTRUCTURE.md) · [Accounts](ACCOUNTS.md)

Prepared 2026-10-07 from saved October 5–6 evidence. This is a readable derivative; the source workbook remains the detailed inventory. No provider was contacted in this extraction.

Evidence states: **DECLARED** means Alex supplied the statement in the current brief; **READ_VERIFIED** means the saved exact read/list/probe succeeded within its stated scope; **CONFIGURED** means saved settings/account metadata; **HISTORICAL** means workbook STALE, dated evidence without a current re-read; **UNKNOWN** means evidence absent. None establishes current service health, billing, permissions, or an active serving agent.

## Inventory scope

The workbook has **883 inventory records**, not 883 distinct owned assets. Those include resources, connected accounts, route references, historical observations, and two collection-count summaries. Its 23 sheets also contain derived views and configuration records outside that count [E1, E2].

| Workbook sheet | Data rows (header excluded) | Exact Excel rows | Coverage class |
| --- | --- | --- | --- |
| Inventory Index | 23 | 2:24 | derived_view_or_coverage |
| Orgo by Workspace | 8 | 2:9 | derived_view_or_coverage |
| Google Workspace | 35 | 2:36 | inventory_records |
| GitHub | 67 | 2:68 | inventory_records |
| Cloudflare | 115 | 2:116 | inventory_records |
| Composio Accounts | 54 | 2:55 | inventory_records |
| Access Routes | 15 | 2:16 | inventory_records |
| GHL Locations | 303 | 2:304 | inventory_records |
| Advertising | 67 | 2:68 | inventory_records |
| Analytics | 25 | 2:26 | inventory_records |
| Slack | 22 | 2:23 | inventory_records |
| Business Systems | 131 | 2:132 | inventory_records |
| Orgo Workspaces | 8 | 2:9 | inventory_records |
| Computers | 9 | 2:10 | inventory_records |
| Network Access | 7 | 2:8 | inventory_records |
| Host Observations | 8 | 2:9 | inventory_records |
| Credential References | 9 | 2:10 | inventory_records |
| Hermes Configurations | 8 | 2:9 | inventory_records |
| Hermes by Computer | 9 | 2:10 | derived_view_or_coverage |
| Relationships | 59 | 2:60 | relationship_records |
| Worker Binding Fields | 201 | 2:202 | binding_field_records |
| Tunnel Fallback Rules | 4 | 2:5 | fallback_rule_records |
| Coverage & Sources | 23 | 2:24 | derived_view_or_coverage |

## Actual machines and containers

There are **9 actual machines: 7 Orgo computers and 2 Macs**. The **8 Orgo workspaces** are containers. Seven Tailscale registrations are network records, not seven extra machines. Historical host observations and eight saved Hermes model configurations are separate records [E1] `Coverage & Sources` row 5.

| Orgo machine | Computer ID | Workspace | CPU allocation (source units) | RAM GB | Saved status | Pointer |
| --- | --- | --- | --- | --- | --- | --- |
| My OpenClaw | 6fbffd8c-65b1-4f2e-993e-f283532109bf | IR 1 | 1 | 8 | running (Oct6) | Workbook `Computers` row 2 |
| EA | d9b475e2-47b2-46d4-b8eb-102564f93283 | EA (Javar) | 4 | 16 | running (Oct6) | Workbook `Computers` row 3 |
| B2B Sales Agent | 2472bdb6-ae8f-4417-a4d0-103df5618d60 | B2B Agent (Sales) | 2 | 4 | running (Oct6) | Workbook `Computers` row 4 |
| SPARE-CSM | 7cedbb4b-0610-4241-907e-edc19b45cf57 | CSM | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 5 |
| SPARE-Media | c8aed3e5-6228-449e-b744-9d02466669c1 | Media | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 6 |
| SPARE-Ops | 47a4ba7c-9908-44f7-aa32-b7da8e18ac85 | Ops — Increase ROAS | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 7 |
| JAVAR-LAB | 0c1ce74e-176b-48f1-bf80-c38139036164 | Increase Roas - Max | 0.5 | 8 | running (Oct6) | Workbook `Computers` row 8 |

| Mac | Hardware and memory | OS observation | State | Pointer |
| --- | --- | --- | --- | --- |
| Alex’s MacBook Pro | Apple M4 Pro; Mac16,7; 24 GB RAM; processor field proc 14:10:4:0 | 26.6.2 | READ_VERIFIED Oct6 metadata | Workbook `Computers` row 9 |
| SASHA IR MAC MINI - JAVANTE | Apple M4; 16 GB RAM | macOS 26.3.2 | HISTORICAL Oct5 | Workbook `Computers` row 10 |

| Workspace | Workspace ID | Machine returned | Pointer |
| --- | --- | --- | --- |
| IR 1 | 3cc5025d-98d3-4b0e-bde3-cd45cd062b85 | My OpenClaw | Workbook `Orgo Workspaces` row 2 |
| EA (Javar) | b4d13606-19d3-4802-9f5c-82819995129a | EA | Workbook `Orgo Workspaces` row 3 |
| B2B Agent (Sales) | 87d53061-ba01-4ff0-94c7-67057700af27 | B2B Sales Agent | Workbook `Orgo Workspaces` row 4 |
| CSM | 6cda999c-708e-4121-8531-383640f97290 | SPARE-CSM | Workbook `Orgo Workspaces` row 5 |
| Media | d4e5f8db-c4c1-4727-8fc0-c876a4602e52 | SPARE-Media | Workbook `Orgo Workspaces` row 6 |
| Ops — Increase ROAS | c523a888-eec5-4501-b25d-b6d591a3a90a | SPARE-Ops | Workbook `Orgo Workspaces` row 7 |
| Increase Roas - Max | 87ba4c76-bc3a-4d2c-84d6-c26f2f1b3117 | JAVAR-LAB | Workbook `Orgo Workspaces` row 8 |
| bold-spark | b6dd4d5b-d7da-46bf-bbf1-20be39e34b8c | No computer returned | Workbook `Orgo Workspaces` row 9 |

Workspace metadata itself has no CPU/RAM fields; allocation belongs to its computer. `bold-spark` returned no computer. CPU values are copied without converting fractional allocations into physical core counts. The safe Oct6 guest probe returned Linux-6.1.102-x86_64-with-glibc2.39 for all seven Orgo computers, exit code 0 [E4]; that proves the probe only.


Read [INFRASTRUCTURE.md](INFRASTRUCTURE.md) for the remaining details and source evidence.

---

<!-- source: SKILLS.md -->

# Skills register

## Selected supporting-source extension

The build-context extension reads selected build-critical supporting scripts, references, templates and app cards. See [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md), [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md) and [BUILD_SOURCE_COVERAGE.json](BUILD_SOURCE_COVERAGE.json). This closes selected source gaps only; the original complete entry-file catalogue does not become a complete all-skill supporting-resource or remote-delivery audit.

Audit date: 2026-10-07. Local reference catalogue, generated from complete SKILL.md reads. Exact source hashes, dates and read coverage are in `work/agent-knowledge/skills-hooks-coverage.json`. These summaries point to procedures; they do not become new procedure homes.

## Coverage

| Source class | Read count |
|---|---:|
| canonical | 174 |
| external_canonical_exception | 1 |
| synced_pointer | 19 |
| codex_system | 5 |

The one external canonical exception is `.agents/skills/one-shot-builder`, linked to the Cursor-owned source. Synced entries are pointer copies and are excluded from the canonical count. Each supporting-resource count is path metadata only; supporting script behavior was not generally audited.

## Browse by contents

- [Creative Media](skills/creative-media.md): 32 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Engineering Execution](skills/engineering-execution.md): 37 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Marketing Delivery](skills/marketing-delivery.md): 22 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Operations Research](skills/operations-research.md): 58 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Platform Integrations](skills/platform-integrations.md): 15 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Platform System](skills/platform-system.md): 5 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Search Content](skills/search-content.md): 11 entries, with purpose, headings, procedure cues, resource metadata and source hash.
- [Synced Pointers](skills/synced-pointers.md): 19 entries, with purpose, headings, procedure cues, resource metadata and source hash.

## Cached plugin skills

[PLUGIN_SKILLS.md](PLUGIN_SKILLS.md) adds 154 fully read cached plugin SKILL.md entries across24 provider/plugin/version groups. Cached content is separate from enablement, runtime selection and remote delivery. Do not sum catalogue classes as distinct installed capabilities; source_registry.json records resolved paths and overlaps.

## Installation and runtime limits

[L1] `/Users/alexlobaito/.agents/tools/unify/skill-lifecycle.md` (checked 2026-10-07) owns shared placement and publication: shared skills stay in `.agents/skills`; registered Claude Code and Cursor targets use links; Codex `.system` remains platform-owned. Local links prove configured paths. No fresh target-runtime selection or remote upload/readback was performed in this audit. Hosted Claude/Cowork, ChatGPT, Manus, Hermes and other-machine delivery is NOT_PROVEN.


Read [SKILLS.md](SKILLS.md) for the remaining details and source evidence.

---

<!-- source: HOOKS.md -->

# Hooks register

## Build-context extension

The configuration extension captures safe Codex, Claude and Cursor hook declarations; the procedure extension captures selected hook/guard and scheduler support. See [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) and [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md). The counts below retain the earlier scoped audit; source/configuration capture does not prove hook execution.

Audit date: 2026-10-07. Hook sources were read; no hook was executed, installed or changed. **Configured/source-present** and **seen working** are separate. This audit proves source presence and selected configuration only; observed runtime execution is NOT_PROVEN.

## Safe source inventory

### pre-commit

[H1] Source: `/Users/alexlobaito/.agents/tools/unify/hooks/pre-commit`; SHA-256: `2b4ee2513cf8b2552c571f0153d0f0c21d5a28ac2d4247c8fbff67c73521a48b`; 5776 bytes; full source read on 2026-10-07.

Local commit hygiene gate. Checks non-ignored untracked paths, rejects staged generated/secrets-like artifacts, parses staged Python/JSON/JSONL/YAML/JavaScript/shell blobs when their parsers exist, and invokes vendor integrity checks when locked skill content changes. The untracked acknowledgement does not bypass artifact or parse checks.

### post-commit

[H2] Source: `/Users/alexlobaito/.agents/tools/unify/hooks/post-commit`; SHA-256: `4fdecb967fa19de78cbe412c9c4152aeda5fd251727d9c264b4cba8dd4873c46`; 2869 bytes; full source read on 2026-10-07.

Asynchronous publication/check dispatcher. Skill and route changes invoke local lifecycle acceptance; cards/instructions/server changes additionally invoke the existing notes sync, instruction build and workbook pipeline only after preceding stages pass. Writes logs/receipts under the runtime path with temporary-directory fallback. A successful commit is not publication proof.

### herdr-agent-state.sh

[H3] Source: `/Users/alexlobaito/.claude/hooks/herdr-agent-state.sh`; SHA-256: `7f117c303ffc1a66975b76dda8189d70b718fc04af4cf7cb11449e4ee5b4ae86`; 3070 bytes; full source read on 2026-10-07.

Herdr-managed Claude integration v10. Session action reads hook input into a temporary file and publishes agent state over a socket only when the required Herdr environment and Python are available. Managed file warns that reinstall/update replaces it.

### chat_guard.py

[H4] Source: `/Users/alexlobaito/.agents/tools/guards/chat_guard.py`; SHA-256: `e2f0fcc8568d56ef84d22b39e70421b8ce7f4d37c80a63a7133c4e94b4780edc`; 18242 bytes; full source read on 2026-10-07.

Claude memory/chat guard. SessionStart, PostToolUse, prompt and Agent/Task/Workflow pre-hooks track chat growth and Mac memory pressure. Its source describes a chat-size handoff prompt, agent gating near critical memory, and stopping this chat's large command near the limit. It exits 0 and logs errors. Runtime behavior was not exercised.

### composio_guard.py

[H5] Source: `/Users/alexlobaito/.agents/tools/guards/composio_guard.py`; SHA-256: `a582374640be081f9373e7df258333ec3934ce1bd456da76c6e8adf3368d92c0`; 87543 bytes; full source read on 2026-10-07.

Claude PreToolUse guard for CLI, MCP and code-mode calls. Classifies spend, outside sends, delete, DNS, deploy and security actions against typed human approvals and target identity. Also rejects ambiguous multi-login calls, forbidden container access and unreadable payload paths. Catalogue preserves the current chat/card authority; source rules do not independently authorize any action.


Read [HOOKS.md](HOOKS.md) for the remaining details and source evidence.

---

<!-- source: GAPS.md -->

# Gaps and next evidence

Knowledge audit: 2026-10-07. These are known unresolved questions and coverage boundaries, not a statement that no other gap can exist. Each future audit must reconcile this list and its source coverage before advancing [START_HERE.md](START_HERE.md). Follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md); record verified corrections in [LESSONS.md](LESSONS.md).

| ID | Gap / boundary | Evidence and next permitted check | Owner |
|---|---|---|---|
| G01 | Current runtime health and serving identity were not tested | Role documents and Oct5–6 metadata; use a separately scoped read-only runtime check with exact identity and one meaningful acceptance probe | Runtime owner |
| G02 | Current Ops host is unresolved | BUILD_IMPLEMENTATION records the historical Ops host removed Oct5 and replacement SPARE metadata; compare current guest/profile/customer identity and acceptance rather than equating names | Ops owner |
| G03 | CSM and Media spares are not proven serving role hosts | BUILD_IMPLEMENTATION records historical CSM/Media hosts removed Oct5 and replacement SPARE metadata; obtain current guest/role/profile/customer binding and runtime acceptance | CSM / Media owners |
| G04 | Finance is unbound in the examples | Company/host/profile binding requires its maintained accepted configuration; no company assignment inferred here | Finance owner |
| G05 | Javante version observations differ by date | Maintained setup mentions 0.21.4; later Oct5 installed observation says 0.21.5. Read current installed and serving version before deployment/recovery | Javante owner |
| G06 | Earlier role-read timeouts resolved in build-context extension | Earlier snapshot had two timeouts. Extension now fully reads all34 maintained role sources, including both files; see BUILD_IMPLEMENTATION_SOURCES and BUILD_SOURCE_COVERAGE. This closes source-read availability only, not actual deployed customer/Finance bindings | Knowledge auditor |
| G07 | Linked build source coverage is expanded but remote/private/mutable state remains partial | The extension reads selected linked plans/code/receipts and the registered Javar Gameplan/Notes; see BUILD_IMPLEMENTATION and BUILD_SOURCE_COVERAGE for exact read/exclusion records. Remote evolving state and safety-excluded/private originals remain uninspected; never assume a full installation backup | Role owner |
| G08 | Skill supporting-resource contents/behavior were not generally audited | Original complete SKILL.md catalogue remains an entry-file audit. The extension adds selected full safe supporting-source snapshots and a dependency closure register in PROCEDURES_AND_DEPENDENCIES. Uninspected example/literal/support/remote references remain explicit; read and verify the dependencies required by the selected task | Skill owner |
| G09 | Cached/discovered skills do not prove runtime selection or remote delivery | Local canonical/system/pointer/plugin source and path observations; obtain fresh target-runtime discovery/selection and remote delivery receipts before claiming availability | Skill integration owner |
| G10 | Hooks were not executed; hook coverage is scoped | Earlier selected Claude source/config scope retained; extension adds safe Codex/Claude/Cursor declarations and selected startup/maintenance implementations. No hook/scheduler/runtime execution or universal effective-loader trace was performed; managed/state-only/remote surfaces remain unproven | Runtime / repo owner |
| G11 | Plan prices and personal account identities are declarations | Cursor/Claude/Codex-ChatGPT $200/month each declared; Grokbot plan unknown. Billing/login proof requires appropriate read-only account evidence; no new spending authorized | Alex / account owner |
| G12 | “Manus studio 2.09” is ambiguous | Retain exact declared text; product tier, version, currency and billing interval remain unknown | Alex / account owner |
| G13 | Hermes emails are not bound to saved configurations | Declared alex@ and agent@ identities are not proof of active profile ownership; compare accepted principal/profile mapping | Hermes owner |
| G14 | Current disk usage and hidden binding targets remain unknown | Historical disk dates and October6 targetless-binding register retained. One October7 dev-rag settings read exposes specific binding targets in SERVICE_BUILD_CONTEXT; it does not refresh all201 previously target-unexposed fields or current disks | Infrastructure owner |
| G15 | Saved connector ACTIVE status is not provider acceptance |54 saved connector records, including expired Fireworks, retain dates. Extension has exact successful Cloudflare settings and one-location GHL configuration reads only; these do not validate every connection or runtime action. App card overrides historical workbook routes | Connector owner |
| G16 | The Exa card and automatic approval review differed for a public fetch | Exa fetch was categorized as spending by automatic approval review and rejected for no spending approval; no bypass/retry. Resolve the actual approval policy before any paid reference check | Alex / policy owner |
| G17 | Markdown publication does not install these rules into every agent runtime | Drive-readable knowledge and update instructions are the deliverable. Remote agents need approved access and demonstrated use; no startup hook/automation is installed by this audit | Runtime owner |
| G18 | Jev folder contents were outside the role-build snapshot check | Existing Jev folder is visible in the hub; enumerate its source documents and authority for a Jev-specific task before claiming setup coverage | Jev owner |
| G19 | Original target-parent history was not compared before/after | Shortcuts preserve original target IDs; no original-file update/delete call in the inspected grouping script. No broader location-history proof claimed | Knowledge auditor |
| G20 | Exact-content copies and versions need ownership reconciliation before cleanup |353 resolved skill-entry paths contain331 distinct byte hashes;17 repeated-hash groups cover39 source paths. Exact bytes do not establish semantic ownership or redundancy. Compare source owners/lifecycle before proposing removal; no source copies were deleted | Skill integration owner |
| G21 | One robot Markdown read misdecoded UTF-8 text | Published ACCOUNTS bytes and checksum were correct; strict decoding recovery reproduced the exact bytes. Use the checksum-guarded protocol for reads; connector implementation/root-cause/service fix remains outside this audit | Connector owner |

## Build-critical extension gaps

These additions come from the accepted [build-context plan](BUILD_CONTEXT_PLAN.md). The documentation delivery and actual runtime/build acceptance are separate. Read [BUILD_READINESS.md](BUILD_READINESS.md) before proceeding.

| ID | Gap / boundary | Evidence and next permitted check | Owner |
|---|---|---|---|
| G22 | Effective instruction/settings loading remains unproven | Full safe local Codex/Claude/Cursor source snapshots and generator matches are captured in CONFIGURATION_SOURCES. Need credential-blind effective exports or controlled loader traces for each runtime, plus managed/cloud/state-only surface coverage; disk defaults do not override task restrictions | Runtime owner |
| G23 | Accepted materializer baseline disagrees with three current plugin files | Static comparison in PROCEDURES_AND_DEPENDENCIES: __init__.py, tasks.py and plugin.yaml differ; two other guarded files match. Guard source is designed to reject drift. Recover accepted sources or review/reaccept the changed component before changing the baseline; no materializer was executed here | Build component owner |
| G24 | Javar Gameplan mission is paused with blocked gates | Registered Gameplan/Notes are current-file byte matched and read in BUILD_IMPLEMENTATION. Do not treat source packaging as gate acceptance or resume authority. Exact loader/binding/acceptance prerequisites remain in that owning record | Javar / mission owner |
| G25 | GHL build structure/settings remain incomplete | Scoped October7 B2B workflow/calendar/pipeline metadata is in SERVICE_BUILD_CONTEXT. Full affected workflow actions/triggers/settings, calendar scheduling/ownership, sender/field/webhook configuration and exact stage mapping need their own scoped reads and acceptance; no agency-wide configuration audit claimed | GHL owner |
| G26 | Cloudflare source/deployment/dependency parity remains incomplete | Selected Worker/modules/schema source plus one live settings read are captured in SERVICE_SOURCES and SERVICE_BUILD_CONTEXT. Need deployed-code equality, imported JSON/identity mapping, relevant hidden binding targets, index discrepancy reconciliation and meaningful retrieval/source acceptance | Cloudflare owner |
| G27 | Startup/scheduler/recovery proof is incomplete | Full selected local setup-check/maintenance/runtime-update sources are captured, with package/serving-path differences preserved. Need current exact profile, job/last-result/delivery evidence, and reviewed restore/rollback acceptance; no procedure executed here | Runtime / recovery owner |
| G28 | Three documented local procedure/acceptance source paths are missing | Implementation: agents/finance/run_live_acceptance.py and agents/javante/setup/tools/ghl/README.md. Procedure closure: agents/javante/setup/skills/productivity/javante-ghl/SKILL.md. Actual missing-file evidence is retained; confirm owner replacement/deprecation rather than substituting a similarly named source | Source / role owners |

## Enrich without inventing

For each resolved gap, add the exact dated source and state to the owning record; preserve contradictory dated observations where relevant. A partial check cannot close a broader gap. Add new gaps with stable IDs, evidence needed and an owner. Keep this list current even when all local documentation checks pass.

Detailed provider coverage remains in the workbook's `Coverage & Sources` sheet and [INFRASTRUCTURE.md](INFRASTRUCTURE.md); this list does not replace those per-provider limits.

---

<!-- source: AUDIT_PROTOCOL.md -->

# Audit and maintenance protocol

Owner: Alex / Increase ROAS. Procedure version: 2026-10-07.

This is a knowledge-maintenance procedure. It does not authorize spending, customer contact, security changes, runtime deployment, shared-skill installation, or a recurring job.

## Required reading

Read [START_HERE.md](START_HERE.md), [CURRENT_STATE.md](CURRENT_STATE.md), [GAPS.md](GAPS.md), and [LESSONS.md](LESSONS.md). Read the relevant agent, account, skill, and hook records before touching the associated system. Consult the current app card before an app call. Local paths are pointers for agents on Alex's Mac; remote agents must use the published Drive resources or their approved access route.

## Audit workflow

1. Record audit ID, auditor, start time, intended scope, and exact source set. Back up any existing knowledge file before updating it.
2. Enumerate sources before summarizing. Reconcile the enumerated sources against the coverage register. Record every source as read, summarized, linked, excluded with a reason, or inaccessible. Do not silently drop inconvenient sources.
3. Read maintained sources and inspect relevant current metadata through approved routes. Keep observed dates, source-file modification dates, audit dates, and publication dates separate.
4. Enrich records only with source-backed findings or clearly labeled owner declarations. Add exact paths, stable Drive IDs, evidence dates, and the meaning of each status. An account email does not prove a runtime-profile binding; a directory does not prove a skill was selected; a hook definition does not prove it ran.
5. Reconcile contradictions. Retain both dated observations until the current authoritative source resolves them. Track unresolved questions in [GAPS.md](GAPS.md), including owner, evidence needed, and next permitted check.
6. When a problem is fixed, write the verified cause, fix, proof, and prevention in [LESSONS.md](LESSONS.md). A proposed fix stays explicitly unverified. If the lesson belongs in a maintained skill, follow the shared skill lifecycle before changing that skill; this knowledge hub is a pointer, not a second skill source.
7. Check navigation links, source coverage, counts, status labels, secrets exclusions, and publication integrity. Use a separate verifier for a broad multi-source audit. Include a negative check, such as rejecting a changed checksum or a fabricated runtime claim.
8. Update START_HERE's audit ID, auditor, completed date/time, scope, result, coverage, receipt link, and remaining-gap link only after those checks pass. Never advance the completed-audit date for an upload, cosmetic edit, partial scan, failed check, or unverified fix. Record a partial attempt separately.
9. Regenerate [AGENT_BRIEFING.md](AGENT_BRIEFING.md) from the maintained knowledge files; do not hand-edit its copied facts. Update the source/publication register. Publish changed files to their existing Drive IDs and verify their final bytes against saved receipts.
10. Report exactly what was written, published and verified, plus any runtime or access checks that remain unproven. Do not claim that instructions mechanically enforce future compliance; no enforcement hook is installed by this document.

## Required audit record

- Audit ID and auditor
- Started/completed time and timezone
- Scope and exclusions
- Source enumeration and coverage counts
- Verified findings, declared facts and unresolved gaps
- Local verification receipt and Drive publication receipt
- Changed knowledge files and source revision/hash pointers
- Lessons added and source-skill follow-up, if applicable

The entry point must always link this protocol and LESSONS. Future agents are required by this procedure to update them when applicable; current runtime adoption must be proved separately.

## Mandatory final audit against the intended work

Before reporting completion, reread Alex's current request and the accepted plan. Map every promised outcome to an actual delivered source, inspected content, verification result and published file. Have a separate verifier check the matrix for broad work. A helper report, source pointer, configured setting or successful upload cannot substitute for this acceptance check.

For the build-context extension, use [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md) and [BUILD_READINESS.md](BUILD_READINESS.md). Every requirement must end VERIFIED, PARTIAL or BLOCKED with its exact remaining evidence/action. Audit instructions/configuration, accepted plans and implementation, identities/customer bindings, supporting procedures/app cards, startup/hooks/schedulers, service dependencies and acceptance/recovery. Retain the distinction between source presence and actual loading/execution. Fix supported documentation defects, republish the same IDs, and recheck final bytes before marking the delivery complete.

This is an end-of-run reminder and written acceptance requirement, not a scheduled reminder or installed enforcement hook.

## Verify text decoding before using a read

A 2026-10-07 `CUSTOM_GOOGLE_ROBOT_DRIVE_READ` of ACCOUNTS returned UTF-8 content represented as Latin-1 characters. Drive's stored checksum was correct. Strictly re-encoding that returned string as Latin-1, then decoding it as UTF-8, recovered the exact source bytes and checksum. Evidence: local `work/agent-knowledge/readability-receipt.json` and `account-readable-readback.json`.

Use a current Drive SHA-256 or the corresponding verified source-register hash as the expected checksum. First hash the returned text encoded as UTF-8. If it matches, use it unchanged. If it does not match and the text appears incorrectly decoded, try the strict Latin-1-to-UTF-8 recovery once. Accept the recovered text only when its bytes match the expected checksum. Never ignore decoding errors or blindly replace punctuation. If neither candidate matches, record the read as unverified and follow the approved source/access route.

This is a verified read-time recovery for one observed file, not a deployed connector-service fix or proof that all readers have the problem. Record any recurrence and successful fix in [LESSONS.md](LESSONS.md); the connector owner must approve and verify any service change separately.

---

<!-- source: LESSONS.md -->

# Lessons

Maintained knowledge record; created 2026-10-07. Read this before an audit or recovery. Follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) and return to [START_HERE.md](START_HERE.md).

## How to add a lesson

Append a dated entry with: ID, affected system, symptom, verified cause, fix performed, proof/source link, scope/limits, prevention, and follow-up owner. Label proposed fixes UNVERIFIED. Do not store credentials, customer records, raw logs, or speculative causes. Put detailed procedures in their canonical skill and link it here. Do not change global memory merely because this file requests a lesson.


Read [LESSONS.md](LESSONS.md) for the remaining details and source evidence.

<!-- master-operations-sdk:start -->
## Master Agent Operations SDK v1

Implementation: `/Users/alexlobaito/Documents/Codex/master-agent-operations-sdk`. Python and local MCP share the exact-target reviewed repair lifecycle.

- [SDK_USAGE.md](https://drive.google.com/file/d/1CPJ8vT9yBm2YiQWN-V4mcMDaE_Tl5E3a/view)
- [SDK_REPAIR_PACKETS.md](https://drive.google.com/file/d/1N-0DUwscsgdDT7PXjl511SVDRGAtjAX4/view)
- [SDK_REPAIR_PACKETS.json](https://drive.google.com/file/d/1nKUHWYInpIF9tG7Kta0JW6ttQGJlNbqP/view)
- [SDK_RUNTIME_TARGETS.json](https://drive.google.com/file/d/1p0FHztRNdkojAOdLSY8TKJXrmxrfEAkw/view)

Verified scope: SDK-owned stored-response repair, real stored Google Doc response, scoped GHL/Cloudflare configuration reads, local metadata and fixture-tested recovery. Remote installation and current Orgo/Hermes serving/profile acceptance remain NOT_PROVEN. GHL null stages remain BLOCKED; G23 requires reacceptance; G24 remains paused; G28 retains three missing-source owner decisions. Shared connector helper and infrastructure workbook remain unchanged.

Last completed SDK audit: 2026-10-08T04:31:08.841375+00:00; audit ID `master-ops-sdk-v1`. Independent implementation and publication acceptance: VERIFIED; this metadata update receives a separate final readback check. Permitted explicit residuals remain. Earlier build-context audit keeps its original scope/date.

Before a repair, read its owning source, canonical skill/card and LESSONS. After a proven fix, record cause, change, scope, evidence and prevention in LESSONS; refresh the owning record. Before saying done, reread the original request and plan and audit every promised outcome.
<!-- master-operations-sdk:end -->
