# Gaps and next evidence

Knowledge audit: 2026-10-07. These are known unresolved questions and coverage boundaries, not a statement that no other gap can exist. Each future audit must reconcile this list and its source coverage before advancing [START_HERE.md](START_HERE.md). Follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md); record verified corrections in [LESSONS.md](LESSONS.md).

| ID | Gap / boundary | Evidence and next permitted check | Owner |
|---|---|---|---|
| G01 | Current runtime health and serving identity were not tested | Role documents and Oct5–6 metadata; use a separately scoped read-only runtime check with exact identity and one meaningful acceptance probe | Runtime owner |
| G02 | Current Ops host is unresolved | BUILD_IMPLEMENTATION records the historical Ops host removed Oct5 and replacement SPARE metadata; compare current guest/profile/customer identity and acceptance rather than equating names | Ops owner |
| G03 | CSM and Media spares are not proven serving role hosts | BUILD_IMPLEMENTATION records historical CSM/Media hosts removed Oct5 and replacement SPARE metadata; obtain current guest/role/profile/customer binding and runtime acceptance | CSM / Media owners |
| G04 | Finance is unbound in the examples | Company/host/profile binding requires its maintained accepted configuration; no company assignment inferred here | Finance owner |
| G05 | Javante version observations differ by date | Maintained setup mentions 0.21.4; later Oct5 installed observation says 0.21.5. Read current installed and serving version before deployment/recovery | Javante owner |
| G06 | Earlier role-read timeouts resolved in build-context extension | Earlier snapshot had two timeouts. Extension now fully reads all34 maintained role sources, including both files; see BUILD_IMPLEMENTATION_SOURCES and BUILD_SOURCE_COVERAGE. This closes source-read availability only, not actual deployed customer/Finance bindings | Knowledge auditor |
| G07 | Linked build source coverage is expanded but remote/private/mutable state remains partial | The extension reads selected linked plans/code/receipts and the registered Javar Gameplan/Notes; see BUILD_IMPLEMENTATION and BUILD_SOURCE_COVERAGE for exact read/exclusion records. Remote evolving state and safety-excluded/private originals remain uninspected; never assume a full installation backup | Role owner |
| G08 | Skill supporting-resource contents/behavior were not generally audited | Original complete SKILL.md catalogue remains an entry-file audit. The extension adds selected full safe supporting-source snapshots and a dependency closure register in PROCEDURES_AND_DEPENDENCIES. Uninspected example/literal/support/remote references remain explicit; read and verify the dependencies required by the selected task | Skill owner |
| G09 | Cached/discovered skills do not prove runtime selection or remote delivery | Local canonical/system/pointer/plugin source and path observations; obtain fresh target-runtime discovery/selection and remote delivery receipts before claiming availability | Skill integration owner |
| G10 | Hooks were not executed; hook coverage is scoped | Earlier selected Claude source/config scope retained; extension adds safe Codex/Claude/Cursor declarations and selected startup/maintenance implementations. No hook/scheduler/runtime execution or universal effective-loader trace was performed; managed/state-only/remote surfaces remain unproven | Runtime / repo owner |
| G11 | Plan prices and personal account identities are declarations | Cursor/Claude/Codex-ChatGPT $200/month each declared; Grokbot plan unknown. Billing/login proof requires appropriate read-only account evidence; no new spending authorized | Alex / account owner |
| G12 | “Manus studio 2.09” is ambiguous | Retain exact declared text; product tier, version, currency and billing interval remain unknown | Alex / account owner |
| G13 | Hermes emails are not bound to saved configurations | Declared alex@ and agent@ identities are not proof of active profile ownership; compare accepted principal/profile mapping | Hermes owner |
| G14 | Current disk usage and hidden binding targets remain unknown | Historical disk dates and October6 targetless-binding register retained. One October7 dev-rag settings read exposes specific binding targets in SERVICE_BUILD_CONTEXT; it does not refresh all201 previously target-unexposed fields or current disks | Infrastructure owner |
| G15 | Saved connector ACTIVE status is not provider acceptance |54 saved connector records, including expired Fireworks, retain dates. Extension has exact successful Cloudflare settings and one-location GHL configuration reads only; these do not validate every connection or runtime action. App card overrides historical workbook routes | Connector owner |
| G16 | The Exa card and automatic approval review differed for a public fetch | Exa fetch was categorized as spending by automatic approval review and rejected for no spending approval; no bypass/retry. Resolve the actual approval policy before any paid reference check | Alex / policy owner |
| G17 | Markdown publication does not install these rules into every agent runtime | Drive-readable knowledge and update instructions are the deliverable. Remote agents need approved access and demonstrated use; no startup hook/automation is installed by this audit | Runtime owner |
| G18 | Jev folder contents were outside the role-build snapshot check | Existing Jev folder is visible in the hub; enumerate its source documents and authority for a Jev-specific task before claiming setup coverage | Jev owner |
| G19 | Original target-parent history was not compared before/after | Shortcuts preserve original target IDs; no original-file update/delete call in the inspected grouping script. No broader location-history proof claimed | Knowledge auditor |
| G20 | Exact-content copies and versions need ownership reconciliation before cleanup |353 resolved skill-entry paths contain331 distinct byte hashes;17 repeated-hash groups cover39 source paths. Exact bytes do not establish semantic ownership or redundancy. Compare source owners/lifecycle before proposing removal; no source copies were deleted | Skill integration owner |
| G21 | One robot Markdown read misdecoded UTF-8 text | Published ACCOUNTS bytes and checksum were correct; strict decoding recovery reproduced the exact bytes. Use the checksum-guarded protocol for reads; connector implementation/root-cause/service fix remains outside this audit | Connector owner |

## Build-critical extension gaps

These additions come from the accepted [build-context plan](BUILD_CONTEXT_PLAN.md). The documentation delivery and actual runtime/build acceptance are separate. Read [BUILD_READINESS.md](BUILD_READINESS.md) before proceeding.

| ID | Gap / boundary | Evidence and next permitted check | Owner |
|---|---|---|---|
| G22 | Effective instruction/settings loading remains unproven | Full safe local Codex/Claude/Cursor source snapshots and generator matches are captured in CONFIGURATION_SOURCES. Need credential-blind effective exports or controlled loader traces for each runtime, plus managed/cloud/state-only surface coverage; disk defaults do not override task restrictions | Runtime owner |
| G23 | Accepted materializer baseline disagrees with three current plugin files | Static comparison in PROCEDURES_AND_DEPENDENCIES: __init__.py, tasks.py and plugin.yaml differ; two other guarded files match. Guard source is designed to reject drift. Recover accepted sources or review/reaccept the changed component before changing the baseline; no materializer was executed here | Build component owner |
| G24 | Javar Gameplan mission is paused with blocked gates | Registered Gameplan/Notes are current-file byte matched and read in BUILD_IMPLEMENTATION. Do not treat source packaging as gate acceptance or resume authority. Exact loader/binding/acceptance prerequisites remain in that owning record | Javar / mission owner |
| G25 | GHL build structure/settings remain incomplete | Scoped October7 B2B workflow/calendar/pipeline metadata is in SERVICE_BUILD_CONTEXT. Full affected workflow actions/triggers/settings, calendar scheduling/ownership, sender/field/webhook configuration and exact stage mapping need their own scoped reads and acceptance; no agency-wide configuration audit claimed | GHL owner |
| G26 | Cloudflare source/deployment/dependency parity remains incomplete | Selected Worker/modules/schema source plus one live settings read are captured in SERVICE_SOURCES and SERVICE_BUILD_CONTEXT. Need deployed-code equality, imported JSON/identity mapping, relevant hidden binding targets, index discrepancy reconciliation and meaningful retrieval/source acceptance | Cloudflare owner |
| G27 | Startup/scheduler/recovery proof is incomplete | Full selected local setup-check/maintenance/runtime-update sources are captured, with package/serving-path differences preserved. Need current exact profile, job/last-result/delivery evidence, and reviewed restore/rollback acceptance; no procedure executed here | Runtime / recovery owner |
| G28 | Three documented local procedure/acceptance source paths are missing | Implementation: agents/finance/run_live_acceptance.py and agents/javante/setup/tools/ghl/README.md. Procedure closure: agents/javante/setup/skills/productivity/javante-ghl/SKILL.md. Actual missing-file evidence is retained; confirm owner replacement/deprecation rather than substituting a similarly named source | Source / role owners |

## Enrich without inventing

For each resolved gap, add the exact dated source and state to the owning record; preserve contradictory dated observations where relevant. A partial check cannot close a broader gap. Add new gaps with stable IDs, evidence needed and an owner. Keep this list current even when all local documentation checks pass.

Detailed provider coverage remains in the workbook's `Coverage & Sources` sheet and [INFRASTRUCTURE.md](INFRASTRUCTURE.md); this list does not replace those per-provider limits.

<!-- master-operations-sdk:start -->
## SDK response-reader scope

The storedInFile correction is implemented and behaviorally verified inside the new SDK. The real Google Doc stored response is recovered on the approved named route. The shared helper is unchanged; its owner installation remains separate. This does not close G21 (the distinct UTF-8 boundary), G17 remote installation, or any broader runtime gap. All 28 gap records remain source-backed decision packets.

- [SDK_USAGE.md](https://drive.google.com/file/d/1CPJ8vT9yBm2YiQWN-V4mcMDaE_Tl5E3a/view)
- [SDK_REPAIR_PACKETS.md](https://drive.google.com/file/d/1N-0DUwscsgdDT7PXjl511SVDRGAtjAX4/view)
- [SDK_REPAIR_PACKETS.json](https://drive.google.com/file/d/1nKUHWYInpIF9tG7Kta0JW6ttQGJlNbqP/view)
- [SDK_RUNTIME_TARGETS.json](https://drive.google.com/file/d/1p0FHztRNdkojAOdLSY8TKJXrmxrfEAkw/view)
<!-- master-operations-sdk:end -->
