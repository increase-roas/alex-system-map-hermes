# Lessons

Maintained knowledge record; created 2026-10-07. Read this before an audit or recovery. Follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) and return to [START_HERE.md](START_HERE.md).

## How to add a lesson

Append a dated entry with: ID, affected system, symptom, verified cause, fix performed, proof/source link, scope/limits, prevention, and follow-up owner. Label proposed fixes UNVERIFIED. Do not store credentials, customer records, raw logs, or speculative causes. Put detailed procedures in their canonical skill and link it here. Do not change global memory merely because this file requests a lesson.

## L-001 — Count machines separately from containers and observations

- Date: 2026-10-06; recorded here 2026-10-07.
- Symptom: the earlier infrastructure inventory overstated computer ownership by mixing different record types.
- Correction: distinguish actual computers from workspaces, saved Hermes configurations, host observations, directory observations and disks. Retain evidence dates and entity types.
- Proof: [verified inventory workbook](https://docs.google.com/spreadsheets/d/1Jinfgxakdq06FS6IN_QCQcq3TSioFbGn/edit) and [independent inventory audit](https://drive.google.com/file/d/1mpYptx7A492wMpcjxGY3DyaWQL1TT0aq/view).
- Prevention: reconcile entity IDs and counts before every total. Do not treat a role name or workspace name as a computer.
- Limit: inventory metadata is not proof of present runtime health.

## L-002 — Request bounded Google Doc fields for verification

- Date: 2026-10-07.
- Symptom: a full guide read through the Google robot returned an empty result after the document was populated.
- Verified recovery: the same approved route returned the required document text, headings and links when requested with a bounded field mask; exact content and link comparisons passed.
- Cause: NOT_PROVEN; the recovery does not establish why the full response was empty.
- Proof: local `work/agent-build-hub/guide-debug-readback.json` records the empty `{}` response; populated `guide-raw-readback.json`, `guide-readback.json`, and `final-verification.json` in the publication task; source registry will retain their paths.
- Prevention: read only required fields, save the returned structure, and verify content rather than treating a successful connector call as proof.

## L-003 — Claim only what the evidence proves

- Date: 2026-10-07.
- Symptom: the guide said original file locations were preserved, although the independent review had no before-and-after parent comparisons.
- Fix: narrowed the sentence to “Each shortcut opens the original file by its existing ID.” Native document readback and link checks passed.
- Proof: [Start Here guide](https://docs.google.com/document/d/1yYm-VGccTRUTVAtuSkTF9w1kABG9Jha5EyLexfTbOxc/edit) and local `work/agent-build-hub/final-verification.json`.
- Prevention: keep creation-only code evidence, observed file metadata, and runtime proof separate. Record missing evidence in GAPS rather than strengthening the claim.

## L-004 — Preserve source-link meaning when making a catalogue

- Date: 2026-10-07.
- Symptom: copied excerpts retained relative links that resolved against the new catalogue instead of the original skill folder.
- Fix: 29 links were pointed to existing resources under their maintained source folders; one template link was rendered as a non-clickable unresolved pointer. Canonical skill files were unchanged.
- Proof: catalogue repair followed the independent findings in local `work/agent-knowledge/verification-preliminary.json`; the final audit receipt records the fresh link checks.
- Prevention: resolve excerpt links against their source before publication, preserve genuine knowledge navigation links, and keep template placeholders visibly unresolved. An existing Mac target is not proof of remote access.

## L-005 — Recover a misdecoded reader response only with checksum proof

- Date: 2026-10-07.
- Symptom: the approved robot reader returned garbled punctuation from the published ACCOUNTS Markdown, despite matching local/Drive stored checksums.
- Verified correction: strict Latin-1 re-encoding followed by UTF-8 decoding recovered the exact local file bytes and SHA-256. The original published file required no content repair.
- Cause: the returned representation matches UTF-8 bytes interpreted as Latin-1; the service implementation's root cause was not inspected.
- Proof: local `work/agent-knowledge/readability-receipt.json` and `account-readable-readback.json`.
- Prevention: follow the checksum-guarded decoding procedure in [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md). Accept unchanged text when its checksum already matches; never apply the recovery blindly.
- Limit: one file-read recovery was seen working. No connector-service fix was deployed; future files/readers require their own comparison.

## L-006 — Audit the sources needed to continue the build

- Date: 2026-10-07. Status: candidate; source: Alex's correction in this chat, “those are some of the most important files bro. so think in terms of that”.
- Symptom: the inventory/navigation package omitted full Codex configuration/global instructions and had not read several linked build plans or critical supporting files. It could not establish enough context to continue the entire build.
- Correction: define acceptance around actual loaded/source instructions, accepted plans and implementation, identities, procedural dependencies, startup/background behavior, service dependencies and acceptance/recovery. Capture full safe source text or an exact omission; give summaries source/receipt pointers.
- Proof: [BUILD_CONTEXT_PLAN.md](BUILD_CONTEXT_PLAN.md), [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md), [BUILD_IMPLEMENTATION_SOURCES.md](BUILD_IMPLEMENTATION_SOURCES.md), [PROCEDURE_SOURCES.md](PROCEDURE_SOURCES.md), [SERVICE_SOURCES.md](SERVICE_SOURCES.md), and independent requirement-level acceptance in [BUILD_READINESS.md](BUILD_READINESS.md).
- Prevention: before saying done, compare actual delivery with the request and accepted plan. A large source count, pointer list or upload cannot replace the acceptance audit.
- Limit: closing documentation gaps does not deploy runtime fixes or prove live service/role acceptance. Promotion target: knowledge-audit procedure; no global rule or shared skill was changed.

## L-007 — Preserve safe instruction wording during credential removal

- Date: 2026-10-07. Status: candidate; source: independent verifier defect and verified correction.
- Symptom: a broad text sanitizer hid 11 ordinary instruction phrases, including “authorization failure”, while removing potential credentials.
- Verified cause: the capture's prose matching was broader than explicit credential assignments/flags and altered safe source wording.
- Fix: narrowed matching to credential syntax, recaptured the snapshots, and added exact full-safe instruction/code source comparisons alongside parsed config redaction checks.
- Proof: local `work/build-context/verification/config-review-final.json`; all 18 safe instruction/code snapshots match original source bytes, all 13 parsed config trees preserve keys and non-redacted values, and the five generated candidates match. Full safe sources: [CONFIGURATION_SOURCES.md](CONFIGURATION_SOURCES.md).
- Prevention: verify both credential exclusion and safe-text fidelity. Hashing an already altered snapshot alone cannot prove fidelity to its source.
- Limit: this correction concerns documentation capture, not runtime instruction loading or secret-store inspection. Promotion target: source-capture procedure; no owning instruction source was edited.

## L-008 — Verify full source delivery and close cross-lane references

Date:2026-10-07. Status: VERIFIED for this documentation delivery.

Problem: the first implementation bundle indexed147 inspected safe files without publishing their full text, and23 linked references were deferred to the procedure lane. Inspection alone did not make the sources available to a remote reader.

Fix: included all209 selected safe implementation texts in the published bundle and reconciled all23 incoming references:21 full captures, one configuration capture and one actually missing source. The missing exact path remains a gap.

Proof: work/build-context/verification/implementation-review-final.json and procedure-review-final.json reopened original bytes and checked full bundle containment; BUILD_SOURCE_COVERAGE.json publishes the disposition records.

Prevention: before publication, verify every selected source has full safe text in the remote artifact or an explicit exclusion/missing-source disposition. Reconcile cross-lane references by exact source path; never count an index row or an unnamed deferred owner as delivered content.

## L-009 — Recover a spilled Composio response before declaring it empty

Date:2026-10-07. Status: VERIFIED readback recovery; canonical helper change NOT_INSTALLED.

Problem: the detailed post-edit Google Doc response exceeded the CLI inline size and was saved to outputFilePath with storedInFile:true. The helper defaulted an absent data field to an empty object, hiding the valid response.

Fix: read the approved regular JSON output file on the same named Google robot route and unwrap data.result. Do not repeat a write merely because its readback appears empty.

Proof: work/build-context/guide-diagnosis/verification-receipt.json verifies the original text and18prior link targets, the single new heading and all14new targets. This is a response-handling recovery, not a Google Doc or provider service fix.

Prevention: validate the CLI envelope before unwrapping it; distinguish inline data, stored response, actual error and absent result. A separate helper patch proposal is retained for its owner; no shared connector source was changed.

<!-- master-operations-sdk:start -->
## L-010 — Verify current postimage and parser behavior before replay claims

Date: 2026-10-08T04:31:08.841375+00:00. Status: VERIFIED SDK scope; shared helper NOT_MODIFIED; remote installation NOT_PROVEN.

The SDK reproduces the diagnosed empty-data reader with policy version zero, then a digest-bound reviewed proposal changes only its SDK-owned policy to select the corrected parser. Real fixture recovery, backup integrity, stable run replay, Python/MCP parity and a fresh Google stored-file read are checked. Save the run receipt; do not repeat provider writes after an empty response. Keep historical success separate from current postimage proof, and preserve unknown identities and blocked mappings.

Proof: implementation `/Users/alexlobaito/Documents/Codex/master-agent-operations-sdk`; `docs/evidence/repair-demo.json`, live Google receipt and independent acceptance. Final publication verification also caught stale receipt reuse: a cache hit must bind its saved remote checksum to the current expected checksum, not just validate old downloaded bytes against their old hash. A failing-then-passing regression and independent final readback check enforce that boundary. Detailed operations belong in SDK_USAGE; this lesson does not authorize outstanding runtime repairs.

- [SDK_USAGE.md](https://drive.google.com/file/d/1CPJ8vT9yBm2YiQWN-V4mcMDaE_Tl5E3a/view)
- [SDK_REPAIR_PACKETS.md](https://drive.google.com/file/d/1N-0DUwscsgdDT7PXjl511SVDRGAtjAX4/view)
- [SDK_REPAIR_PACKETS.json](https://drive.google.com/file/d/1nKUHWYInpIF9tG7Kta0JW6ttQGJlNbqP/view)
- [SDK_RUNTIME_TARGETS.json](https://drive.google.com/file/d/1p0FHztRNdkojAOdLSY8TKJXrmxrfEAkw/view)
<!-- master-operations-sdk:end -->
