# Service sources and safe provider evidence

Captured 2026-10-07T23:13:32.370345+00:00. Canonical files remain at their listed source paths. This derivative contains only the 19 explicitly allowlisted code/example/schema/historical receipt files; no runtime registry, credentials, customer records, .env or FIFO was read. Runtime loading and deployed-code equivalence are NOT_PROVEN.

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/worker.mjs

SHA-256: `3c83f7e5ab412550e02f892c46aa50f7ae11191315e1f70e8f43389668f39b13`. Canonical mtime: 2026-09-23T22:49:00.069581+00:00. State: SOURCE_ONLY.

```javascript
import {notes,searchNotes} from './approved-notes.mjs';
import { customerQuery, CustomerPolicyError } from './customer-policy.mjs';
import { initializeTeamTasks, operateTeamTask, TeamTaskError } from './team-tasks.mjs';
import sourceRegistry from './source-registry.json';
import {createSourceResolver, SourceServingError} from './source-serving.mjs';
import {publishSource, withdrawSource, restoreSource, markSourceStale, PublicationError} from './source-publication.mjs';
import {sourcePublicationRepository} from './source-publication-store.mjs';
import {authorizeSourceMaintenance, authorizeSourceRestore, SourceMaintenanceError} from './source-maintenance-policy.mjs';
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../../Users/alexlobaito/.codex/worktrees/b276/Build/agents/ea/rag/dev-rag-worker.phase3.mjs
import { DurableObject } from "cloudflare:workers";

// ../../Users/alexlobaito/.codex/worktrees/b276/Build/agents/ea/rag/worker-policy.mjs
var SOURCE_FILE = "03-Playbooks/Agency/Jeremy-Internal/EA-Javar-Operating-Canon.md";
var SOURCE_SHA256 = "4c8408e4e1060f691a7449d61d3d4f71caf4545dc9e5ade27af499fb41e2234f";
var MANIFEST_SHA256 = "dda9dae26f937aa4a57c2d72ef316a0643a19f37ab50577de0fe57721395bd02";
var INGEST_RUN_ID = "b67a08ac4e50ec1c82bfeda0dc69195a4c6bfa1e0fd9be020b6475dc3e6c038b";
var VECTOR_FILTER_SHA256 = "8df3e5b134a7dab00ed85b27df9a59ee2a9012747f426ee784a7914da39d6186";
var REQUIRED_METADATA_SHA256 = "383c0e9e56395616e263bd8438b57e1868d86a98e6320f3c120778a094e368ed";
var EXCLUDED_QUERY_LANES = /\b(?:b2b|clients?|revstead|crm|credentials?|passwords?|tokens?|secrets?)\b|\bcustomer[-_\s]?private\b/i;
var EA_JAVAR_QUERY_KEYS = Object.freeze(/* @__PURE__ */ new Set(["query", "topK", "vector"]));
var EaJavarPolicyError = class extends Error {
  static {
    __name(this, "EaJavarPolicyError");
  }
  constructor(status, message) {
    super(message);
    this.name = "EaJavarPolicyError";
    this.status = status;
  }
};
var EA_JAVAR_FILTER = Object.freeze({
  corpus: "jeremy_internal",
  tenant: "internal_increase_roas",
  approved: true,
  archived: false,
  role: "ea_javar",
  source_class: "jeremy_internal",
  status: "active",
  agent_access: "ea_javar",
  source_file: SOURCE_FILE
});
var EA_JAVAR_VECTOR_FILTER = Object.freeze({
  tenant: "internal_increase_roas",
  approved: true,
  archived: false,
  role: "ea_javar",
  status: "active",
  agent_access: "ea_javar"
});
function requireExact(label, actual, expected) {
  if (actual !== expected) throw new Error(`${label} does not match the frozen receipt`);
}
__name(requireExact, "requireExact");
function validateEaJavarQueryRequest(input = {}) {
  if (Object.hasOwn(input, "filter")) throw new Error("caller filters are forbidden");
  const query = typeof input.query === "string" ? input.query.trim() : "";
  if (query.length < 1 || query.length > 500) throw new Error("query must contain 1 through 500 characters");
  if (EXCLUDED_QUERY_LANES.test(query)) throw new Error("query crosses an excluded lane");
  const topK = input.topK ?? 4;
  if (!Number.isInteger(topK) || topK < 1 || topK > 4) {
    throw new Error("topK must be an integer from 1 through 4");
  }
  return { query, topK };
}
__name(validateEaJavarQueryRequest, "validateEaJavarQueryRequest");
function guardEaJavarRoute(claims, method, path) {
  if (claims?.agent_id !== "ea_javar") return false;
  if (method !== "POST" || path !== "/query") {
    throw new EaJavarPolicyError(403, "EA/Javar is permanently restricted to the query route");
  }
  try {
    assertExactQueryGrant(claims.grants);
  } catch (error) {
    throw new EaJavarPolicyError(403, error.message);
  }
  return true;
}
__name(guardEaJavarRoute, "guardEaJavarRoute");
async function executeEaJavarQuery({ claims, body, vectorIndex }) {
  guardEaJavarRoute(claims, "POST", "/query");
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new EaJavarPolicyError(400, "query body must be an object");
  }
  for (const key of Object.keys(body)) {
    if (!EA_JAVAR_QUERY_KEYS.has(key)) throw new EaJavarPolicyError(400, `query field is forbidden: ${key}`);
  }
  let request;
  let options;
  try {
    request = validateEaJavarQueryRequest(body);
    options = buildEaJavarVectorQuery(request);
  } catch (error) {
    throw new EaJavarPolicyError(400, error.message);
  }
  if (!Array.isArray(body.vector) || body.vector.length !== 384 || !body.vector.every(Number.isFinite)) {
    throw new EaJavarPolicyError(400, "vector must contain 384 finite numbers from the approved all-MiniLM-L6-v2 runtime");
  }
  if (!vectorIndex || typeof vectorIndex.query !== "function") {
    throw new EaJavarPolicyError(503, "Vectorize binding is unavailable");
  }
  const queryResult = await vectorIndex.query(body.vector, options);
  const matches = Array.isArray(queryResult) ? queryResult : queryResult?.matches || [];
  try {
    validateEaJavarQueryMatches(matches);
  } catch (error) {
    throw new EaJavarPolicyError(502, error.message);
  }
  return {
    ok: true,
    query: request.query,
    matches: matches.map((match) => ({
      id: match.id,
      score: match.score,
      source_file: match.metadata.source_file,
      source_sha256: match.metadata.source_sha256,
      manifest_sha256: match.metadata.manifest_sha256,
      ingest_run_id: match.metadata.ingest_run_id,
      chunk_index: match.metadata.chunk_index,
      chunk_sha256: match.metadata.chunk_sha256
    })),
    policy_receipt: {
      namespace: "ea-javar-jeremy-internal-v1",
      vector_filter_sha256: VECTOR_FILTER_SHA256,
      required_metadata_sha256: REQUIRED_METADATA_SHA256
    },
    identity: {
      agent_id: claims.agent_id,
      client_id: claims.client_id,
      grants: claims.grants
    }
  };
}
__name(executeEaJavarQuery, "executeEaJavarQuery");
function buildEaJavarVectorQuery(input = {}) {
  if (Object.hasOwn(input, "filter")) throw new Error("caller filters are forbidden");
  const topK = input.topK ?? 4;
  if (!Number.isInteger(topK) || topK < 1 || topK > 4) {
    throw new Error("topK must be an integer from 1 through 4");
  }
  return {
    topK,
    returnMetadata: "all",
    namespace: "ea-javar-jeremy-internal-v1",
    filter: EA_JAVAR_VECTOR_FILTER
  };
}
__name(buildEaJavarVectorQuery, "buildEaJavarVectorQuery");
function assertExactQueryGrant(grants) {
  if (!Array.isArray(grants) || grants.length !== 1 || grants[0] !== "query") {
    throw new Error("Access grants must be exactly query only");
  }
  return true;
}
__name(assertExactQueryGrant, "assertExactQueryGrant");
function validateEaJavarQueryMatches(matches) {
  if (!Array.isArray(matches)) throw new Error("query matches must be an array");
  for (const match of matches) {
    for (const [key, expected] of Object.entries(EA_JAVAR_FILTER)) {
      if (match?.metadata?.[key] !== expected) throw new Error(`result metadata mismatch: ${key}`);
    }
    requireExact("result source_sha256", match.metadata.source_sha256, SOURCE_SHA256);
    requireExact("result manifest_sha256", match.metadata.manifest_sha256, MANIFEST_SHA256);
    requireExact("result ingest_run_id", match.metadata.ingest_run_id, INGEST_RUN_ID);
    if (!Number.isInteger(match.metadata.chunk_index) || match.metadata.chunk_index < 0 || match.metadata.chunk_index > 5) {
      throw new Error("result metadata mismatch: chunk_index");
    }
    if (typeof match.metadata.chunk_sha256 !== "string" || !/^[a-f0-9]{6,64}$/.test(match.metadata.chunk_sha256)) {
      throw new Error("result metadata mismatch: chunk_sha256");
    }
  }
  return true;
}
__name(validateEaJavarQueryMatches, "validateEaJavarQueryMatches");

// ../../Users/alexlobaito/.codex/worktrees/b276/Build/agents/ea/rag/dev-rag-worker.phase3.mjs
var JSON_HEADERS = { "content-type": "application/json; charset=utf-8" };
var ALLOWLISTED_ROOTS = [
  "03-Playbooks/Marketing",
  "ads/campaigns",
  "ads/creatives",
  "ads/results",
  "clients",
  "rules",
  "rollups"
];
var CANONICAL_REPO = "increase-roas/agent-knowledge";
var CANONICAL_REF = "main";
var TEXT_EXTENSIONS = /* @__PURE__ */ new Set([".csv", ".html", ".json", ".md", ".mdx", ".txt", ".yaml", ".yml"]);
var FORBIDDEN_SEGMENTS = /(^|\/)(?:\.git|\.env(?:\..*)?|backups?|staging|recovery|node_modules)(?:\/|$)/i;
var HEX_64 = /^[a-f0-9]{64}$/;
var HttpError = class extends Error {
  static {
    __name(this, "HttpError");
  }
  constructor(status, message, details = void 0) {
    super(message);
    this.status = status;
    this.details = details;
  }
};
function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...JSON_HEADERS, ...headers }
  });
}
__name(json, "json");
function normalizedPath(value) {
  return String(value ?? "").replaceAll("\\", "/").replace(/^\/+/, "").replace(/\/+/g, "/");
}
__name(normalizedPath, "normalizedPath");
function isIngestiblePath(value) {
  const path = normalizedPath(value);
  if (!path || path.includes("..") || FORBIDDEN_SEGMENTS.test(path)) return false;
  if (!ALLOWLISTED_ROOTS.some((root) => path.startsWith(`${root}/`))) return false;
  const name = path.slice(path.lastIndexOf("/") + 1);
  const dot = name.lastIndexOf(".");
  return dot > 0 && TEXT_EXTENSIONS.has(name.slice(dot).toLowerCase());
}
__name(isIngestiblePath, "isIngestiblePath");
function canonicalValue(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new HttpError(400, "non-finite number in canonical JSON");
    return Object.is(value, -0) ? 0 : value;
  }
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value).filter((key) => value[key] !== void 0).sort().map((key) => [key, canonicalValue(value[key])])
    );
  }
  throw new HttpError(400, "unsupported canonical JSON value");
}
__name(canonicalValue, "canonicalValue");
function canonicalJson(value) {
  return JSON.stringify(canonicalValue(value));
}
__name(canonicalJson, "canonicalJson");
async function sha256Hex(value) {
  const bytes = typeof value === "string" ? new TextEncoder().encode(value) : value;
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(sha256Hex, "sha256Hex");
function base64urlDecode(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
  const raw = atob(padded);
  return Uint8Array.from(raw, (char) => char.charCodeAt(0));
}
__name(base64urlDecode, "base64urlDecode");
function base64urlEncode(bytes) {
  const raw = String.fromCharCode(...bytes);
  return btoa(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
__name(base64urlEncode, "base64urlEncode");
function decodeJsonPart(value) {
  try {
    return JSON.parse(new TextDecoder().decode(base64urlDecode(value)));
  } catch {
    throw new HttpError(401, "invalid token encoding");
  }
}
__name(decodeJsonPart, "decodeJsonPart");
function splitJwt(token) {
  const parts = String(token).split(".");
  if (parts.length !== 3) throw new HttpError(401, "invalid token");
  return parts;
}
__name(splitJwt, "splitJwt");
function audienceMatches(audience, expected) {
  return Array.isArray(audience) ? audience.includes(expected) : audience === expected;
}
__name(audienceMatches, "audienceMatches");
function makeUlid() {
  const alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
  let time = Date.now();
  let result = "";
  for (let index = 9; index >= 0; index -= 1) {
    result = alphabet[time % 32] + result;
    time = Math.floor(time / 32);
  }
  const random = crypto.getRandomValues(new Uint8Array(16));
  let buffer = 0;
  let bits = 0;
  for (const byte of random) {
    buffer = buffer << 8 | byte;
    bits += 8;
    while (bits >= 5 && result.length < 26) {
      bits -= 5;
      result += alphabet[buffer >> bits & 31];
    }
  }
  while (result.length < 26) result += alphabet[0];
  return result.slice(0, 26);
}
__name(makeUlid, "makeUlid");
async function verifyHmacJwt(token, env) {
  const [encodedHeader, encodedPayload, encodedSignature] = splitJwt(token);
  const header = decodeJsonPart(encodedHeader);
  const claims = decodeJsonPart(encodedPayload);
  if (header.alg !== "HS256" || header.kid !== "dev-v1" || claims.iss !== env.JWT_ISSUER || !audienceMatches(claims.aud, env.JWT_AUDIENCE)) {
    throw new HttpError(401, "invalid token claims");
  }
  if (!claims.exp || claims.exp <= Math.floor(Date.now() / 1e3)) throw new HttpError(401, "expired token");
  if (typeof claims.agent_id !== "string" || typeof claims.client_id !== "string" || !Array.isArray(claims.grants)) {
    throw new HttpError(401, "invalid token scope");
  }
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.DEV_JWT_HMAC_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"]
  );
  const valid = await crypto.subtle.verify(
    "HMAC",
    key,
    base64urlDecode(encodedSignature),
    new TextEncoder().encode(`${encodedHeader}.${encodedPayload}`)
  );
  if (!valid) throw new HttpError(401, "invalid token signature");
  return claims;
}
__name(verifyHmacJwt, "verifyHmacJwt");
async function verifyAccessAssertion(request, env) {
  const assertion = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!assertion) throw new HttpError(401, "missing Cloudflare Access assertion");
  const [encodedHeader, encodedPayload, encodedSignature] = splitJwt(assertion);
  const header = decodeJsonPart(encodedHeader);
  const claims = decodeJsonPart(encodedPayload);
  if (header.alg !== "RS256" || claims.iss !== env.ACCESS_ISSUER || !audienceMatches(claims.aud, env.ACCESS_AUDIENCE)) {
    throw new HttpError(401, "invalid Access assertion claims");
  }
  if (!claims.exp || claims.exp <= Math.floor(Date.now() / 1e3)) throw new HttpError(401, "expired Access assertion");
  const jwksResponse = await fetch(`${env.ACCESS_ISSUER}/cdn-cgi/access/certs`, { headers: { accept: "application/json" } });
  if (!jwksResponse.ok) throw new HttpError(503, "Access key discovery unavailable");
  const jwks = await jwksResponse.json();
  const jwk = jwks.keys?.find((key2) => key2.kid === header.kid);
  if (!jwk) throw new HttpError(401, "unknown Access signing key");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const valid = await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    key,
    base64urlDecode(encodedSignature),
    new TextEncoder().encode(`${encodedHeader}.${encodedPayload}`)
  );
  if (!valid) throw new HttpError(401, "invalid Access assertion signature");
  return claims;
}
__name(verifyAccessAssertion, "verifyAccessAssertion");
function identityFromAccess(claims, env) {
  let mapping;
  try {
    mapping = JSON.parse(env.DEV_ACCESS_IDENTITY_MAP || "{}");
  } catch {
    throw new HttpError(503, "identity mapping unavailable");
  }
  const candidates = [claims.common_name, claims.email, claims.sub, claims.client_id].filter(Boolean);
  const teamMapping = JSON.parse(env.TEAM_TASK_IDENTITIES || "{}");
  const knowledgeMapping = JSON.parse(env.ROLE_KNOWLEDGE_IDENTITIES || "{}");
  const identity = candidates.map((candidate) => mapping[candidate]).find(Boolean)
    || candidates.map((candidate) => teamMapping[candidate]).find(Boolean)
    || candidates.map((candidate) => knowledgeMapping[candidate]).find(Boolean);
  if (!identity || typeof identity.agent_id !== "string" || typeof identity.client_id !== "string" || !Array.isArray(identity.grants)) {
    throw new HttpError(403, "Access identity is not mapped for DEV");
  }
  return {
    agent_id: identity.agent_id,
    client_id: identity.client_id,
    grants: identity.grants,
    session_id: claims.sid || crypto.randomUUID()
  };
}
__name(identityFromAccess, "identityFromAccess");
async function mintAgentJwt(identity, env) {
  const header = { alg: "HS256", typ: "JWT", kid: "dev-v1" };
  const payload = {
    iss: env.JWT_ISSUER,
    aud: env.JWT_AUDIENCE,
    agent_id: identity.agent_id,
    client_id: identity.client_id,
    grants: identity.grants,
    session_id: identity.session_id,
    iat: Math.floor(Date.now() / 1e3),
    exp: Math.floor(Date.now() / 1e3) + 900,
    jti: crypto.randomUUID()
  };
  const encodedHeader = base64urlEncode(new TextEncoder().encode(JSON.stringify(header)));
  const encodedPayload = base64urlEncode(new TextEncoder().encode(JSON.stringify(payload)));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(env.DEV_JWT_HMAC_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${encodedHeader}.${encodedPayload}`));
  return { token: `${encodedHeader}.${encodedPayload}.${base64urlEncode(new Uint8Array(signature))}`, payload };
}
__name(mintAgentJwt, "mintAgentJwt");
async function requireAgent(request, env, grant) {
  const authorization = request.headers.get("authorization") || "";
  if (!authorization.startsWith("Bearer ")) throw new HttpError(401, "missing bearer token");
  const claims = await verifyHmacJwt(authorization.slice(7).trim(), env);
  if (!claims.grants.includes(grant) && !claims.grants.includes("state.admin")) throw new HttpError(403, "grant not permitted");
  return claims;
}
__name(requireAgent, "requireAgent");
function hasGrant(claims, grant) {
  return claims.grants.includes(grant) || claims.grants.includes("state.admin");
}
__name(hasGrant, "hasGrant");
function scopedFilter(claims, requested) {
  const filter = {
    client_id: claims.client_id,
    agent_access: { $in: ["all", claims.agent_id] },
    status: "active"
  };
  if (requested && typeof requested === "object") {
    if (typeof requested.doc_type === "string") filter.doc_type = requested.doc_type;
  }
  return filter;
}
__name(scopedFilter, "scopedFilter");
function normalizeEntityPart(value, field) {
  if (typeof value !== "string" || !value.trim() || value.length > 200) throw new HttpError(400, `invalid ${field}`);
  return value.trim().replace(/[^a-zA-Z0-9._:-]/g, "_");
}
__name(normalizeEntityPart, "normalizeEntityPart");
async function manifestStub(env, claims, sourceFile) {
  const key = await sha256Hex(`manifest|${claims.client_id}|${sourceFile}`);
  return env.STATE.getByName(`manifest:${key}`);
}
__name(manifestStub, "manifestStub");
function requireSourceVersion(value) {
  if (typeof value !== "string" || !HEX_64.test(value)) throw new HttpError(400, "source_version must be a lowercase SHA-256 hex digest");
  return value;
}
__name(requireSourceVersion, "requireSourceVersion");
function prepareVector(vector, index, body, claims, now) {
  if (!vector || typeof vector !== "object" || !Array.isArray(vector.values) || vector.values.length !== 384) {
    throw new HttpError(400, `invalid vector at index ${index}`);
  }
  if (!vector.values.every((value) => typeof value === "number" && Number.isFinite(value))) throw new HttpError(400, `invalid vector values at index ${index}`);
  const metadata = vector.metadata && typeof vector.metadata === "object" ? vector.metadata : {};
  const sourceFile = normalizedPath(metadata.source_file || body.source_file);
  if (!isIngestiblePath(sourceFile)) throw new HttpError(400, "source_file is outside the DEV allowlist");
  const sourceVersion = requireSourceVersion(metadata.source_version || body.source_version);
  const chunkIndex = Number(metadata.chunk_index ?? vector.chunk_index);
  if (!Number.isInteger(chunkIndex) || chunkIndex < 0) throw new HttpError(400, `invalid chunk_index at index ${index}`);
  const id = String(vector.id || "");
  if (!HEX_64.test(id)) throw new HttpError(400, `vector id must be a SHA-256 chunk id at index ${index}`);
  const agentAccess = metadata.agent_access === claims.agent_id ? claims.agent_id : "all";
  const chunkerVersion = String(metadata.chunker_version || body.chunker_version || "dev-v1");
  const embeddingModelVersion = String(metadata.embedding_model_version || body.embedding_model_version || "all-MiniLM-L6-v2");
  const docType = String(metadata.doc_type || body.doc_type || "markdown");
  const preparedMetadata = {
    source_file: sourceFile,
    source_version: sourceVersion,
    chunk_index: chunkIndex,
    doc_type: docType,
    client_id: claims.client_id,
    agent_access: agentAccess,
    status: "active",
    last_verified: String(metadata.last_verified || now),
    chunker_version: chunkerVersion,
    embedding_model_version: embeddingModelVersion,
    ingest_run_id: String(body.ingest_run_id || crypto.randomUUID())
  };
  return { id, values: vector.values, metadata: preparedMetadata };
}
__name(prepareVector, "prepareVector");
async function handleIngest(request, env, claims) {
  const body = await request.json();
  if (!body || typeof body !== "object" || !Array.isArray(body.vectors) || body.vectors.length === 0 || body.vectors.length > 1e3) {
    throw new HttpError(400, "vectors must contain between 1 and 1000 items");
  }
  const sourceFile = normalizedPath(body.source_file);
  if (!isIngestiblePath(sourceFile)) throw new HttpError(400, "source_file is outside the DEV allowlist");
  if ((body.source_repo || CANONICAL_REPO) !== CANONICAL_REPO || (body.source_ref || CANONICAL_REF) !== CANONICAL_REF) {
    throw new HttpError(403, "source must be the canonical GitHub agent-knowledge repository at main");
  }
  const sourceVersion = requireSourceVersion(body.source_version);
  if (typeof body.content === "string" && await sha256Hex(new TextEncoder().encode(body.content)) !== sourceVersion) {
    throw new HttpError(409, "source_version does not match content bytes");
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const vectors = [];
  for (let index = 0; index < body.vectors.length; index += 1) vectors.push(prepareVector(body.vectors[index], index, body, claims, now));
  const uniqueIds = new Set(vectors.map((vector) => vector.id));
  if (uniqueIds.size !== vectors.length) throw new HttpError(400, "duplicate vector ids in ingest request");
  const ingestRunId = vectors[0].metadata.ingest_run_id;
  const manifest = await manifestStub(env, claims, sourceFile);
  const previous = await manifest.getManifest(sourceFile);
  const upsertResult = await env.VECTOR_INDEX.upsert(vectors);
  const staleIds = (previous?.chunk_ids || []).filter((id) => !uniqueIds.has(id));
  let deleteResult = null;
  if (staleIds.length) deleteResult = await env.VECTOR_INDEX.deleteByIds(staleIds);
  const recorded = await manifest.recordManifest({
    source_file: sourceFile,
    source_version: sourceVersion,
    chunk_ids: [...uniqueIds],
    status: "active",
    source_repo: CANONICAL_REPO,
    source_ref: CANONICAL_REF,
    ingest_run_id: ingestRunId,
    updated_at: now
  });
  return json({
    ok: true,
    source_file: sourceFile,
    source_version: sourceVersion,
    ingest_run_id: ingestRunId,
    count: vectors.length,
    stale_deleted: staleIds.length,
    idempotent_source: previous?.source_version === sourceVersion && staleIds.length === 0,
    upsert: upsertResult,
    delete: deleteResult,
    manifest: recorded
  });
}
__name(handleIngest, "handleIngest");
async function handleDelete(request, env, claims) {
  const body = await request.json();
  if (body.source_file) {
    if (!hasGrant(claims, "ingest")) throw new HttpError(403, "grant not permitted");
    const sourceFile = normalizedPath(body.source_file);
    if (!isIngestiblePath(sourceFile)) throw new HttpError(400, "source_file is outside the DEV allowlist");
    const manifest = await manifestStub(env, claims, sourceFile);
    const previous = await manifest.getManifest(sourceFile);
    const ids = previous?.chunk_ids || [];
    const deleted = ids.length ? await env.VECTOR_INDEX.deleteByIds(ids) : null;
    const recorded = await manifest.recordManifest({
      source_file: sourceFile,
      source_version: previous?.source_version || "0".repeat(64),
      chunk_ids: [],
      status: "deleted",
      source_repo: previous?.source_repo || CANONICAL_REPO,
      source_ref: previous?.source_ref || CANONICAL_REF,
      ingest_run_id: body.ingest_run_id || crypto.randomUUID(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    return json({ ok: true, source_file: sourceFile, deleted_count: ids.length, delete: deleted, manifest: recorded });
  }
  if (!hasGrant(claims, "state.admin") || !Array.isArray(body.ids) || body.ids.length === 0 || body.ids.length > 1e3) {
    throw new HttpError(400, "ids are required for admin deletion");
  }
  const result = await env.VECTOR_INDEX.deleteByIds(body.ids.map(String));
  return json({ ok: true, deleted_count: body.ids.length, delete: result });
}
__name(handleDelete, "handleDelete");
async function handleState(request, env, claims) {
  const body = request.method === "GET" ? Object.fromEntries(new URL(request.url).searchParams) : await request.json();
  const operation = body.op || (request.method === "GET" ? "read" : "append");
  if (body.client_id && body.client_id !== claims.client_id) throw new HttpError(403, "client scope mismatch");
  if (body.agent_id && body.agent_id !== claims.agent_id) throw new HttpError(403, "agent scope mismatch");
  const entityType = normalizeEntityPart(body.entity_type, "entity_type");
  const entityId = normalizeEntityPart(body.entity_id, "entity_id");
  const name = `${claims.client_id}:${entityType}:${entityId}`;
  const stub = env.STATE.getByName(name);
  if (operation === "read") {
    if (!hasGrant(claims, "state.read")) throw new HttpError(403, "grant not permitted");
    return json(await stub.read({ limit: Math.min(Math.max(Number(body.limit || 50), 1), 200) }));
  }
  if (operation === "append") {
    if (!hasGrant(claims, "state.append")) throw new HttpError(403, "grant not permitted");
    const result = await stub.append({
      schema_version: 1,
      ts: body.ts || (/* @__PURE__ */ new Date()).toISOString(),
      agent_id: claims.agent_id,
      client_id: claims.client_id,
      session_id: claims.session_id,
      entity_type: entityType,
      entity_id: entityId,
      event_type: normalizeEntityPart(body.event_type, "event_type"),
      payload: body.payload ?? {},
      prev_event_id: body.prev_event_id ?? null
    });
    return json(result, result.status || 200);
  }
  throw new HttpError(400, "op must be read or append");
}
__name(handleState, "handleState");
async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: { allow: "GET,POST,OPTIONS" } });
  if (request.method === "GET" && path === "/health") {
    return json({ ok: true, environment: env.ENVIRONMENT, worker: "dev-rag-worker", vectorize: Boolean(env.VECTOR_INDEX), durable_state: Boolean(env.STATE), canonical_repo: CANONICAL_REPO, canonical_ref: CANONICAL_REF });
  }
  if (request.method === "POST" && path === "/token") {
    const accessClaims = await verifyAccessAssertion(request, env);
    const identity = identityFromAccess(accessClaims, env);
    return json({ token_type: "Bearer", expires_in: 900, ...await mintAgentJwt(identity, env) });
  }
  if (request.method === "POST" && path === "/team/task") {
    const authorization = request.headers.get("authorization") || "";
    if (!authorization.startsWith("Bearer ")) throw new HttpError(401, "missing bearer token");
    const claims = await verifyHmacJwt(authorization.slice(7).trim(), env);
    // Separate, explicit service-side authorization; RAG query grants are unchanged.
    const bindings = JSON.parse(env.TEAM_TASK_IDENTITIES || "{}");
    const binding = bindings[claims.client_id];
    const body = await request.json();
    if (!binding || binding.agent_id !== claims.agent_id || !Array.isArray(binding.grants)
        || JSON.stringify(binding.grants)!==JSON.stringify(claims.grants) || !Array.isArray(binding.customers)
        || !binding.customers.includes(body.customer) || body.customer !== 'increase_roas') {
      throw new HttpError(403, 'Team task identity or customer denied');
    }
    const taskId = normalizeEntityPart(body.task_id, 'task_id');
    const stub = env.STATE.getByName(`team:${body.customer}:${taskId}`);
    const result = await stub.teamTask(body, claims.agent_id);
    return json(result, result.error ? result.status : 200);
  }
  if (request.method === 'POST' && ['/sources/publish','/sources/withdraw','/sources/restore','/sources/status','/sources/stale'].includes(path)) {
    const authorization=request.headers.get('authorization')||'';
    if (!authorization.startsWith('Bearer ')) throw new HttpError(401,'missing bearer token');
    const claims=await verifyHmacJwt(authorization.slice(7).trim(),env);
    const raw=await request.text();
    if (new TextEncoder().encode(raw).length>4*1024*1024) throw new HttpError(413,'Source publication too large');
    const body=JSON.parse(raw);
    const identities=JSON.parse(env.SOURCE_SYNC_IDENTITIES||'{}');
    const source=path==='/sources/restore'
      ? authorizeSourceRestore(claims,body,sourceRegistry,identities)
      : authorizeSourceMaintenance(claims,body,sourceRegistry,identities);
    const stub=env.STATE.getByName(`source:${source.source_id}`);
    if(path==='/sources/status') {
      const state=await stub.sourceState(source.source_id);
      return json({ok:true,source_id:source.source_id,state});
    }
    const result=await stub.maintainSource(source.source_id,path==='/sources/publish'?'publish':path==='/sources/stale'?'stale':path==='/sources/restore'?'restore':'withdraw',body);
    return json(result,result.error?result.status:200);
  }
  if (request.method === 'POST' && path === '/knowledge/notes') {
    const authorization=request.headers.get('authorization')||'';
    if(!authorization.startsWith('Bearer '))throw new HttpError(401,'missing bearer token');
    const claims=await verifyHmacJwt(authorization.slice(7).trim(),env);
    const raw=await request.text();
    if(raw.length>32000)throw new HttpError(413,'Note request too large');
    const body=JSON.parse(raw);
    const binding=JSON.parse(env.RAG_NOTE_IDENTITIES||'{}')[claims.client_id];
    if(!binding || claims.agent_id!=='ea_javar'||binding.agent_id!==claims.agent_id
      ||JSON.stringify(claims.grants)!=='["query"]'||!binding.customers?.includes(body.customer)
      ||!['increase_roas','lone_star_spas'].includes(body.customer))throw new HttpError(403,'Note scope denied');
    const result=await env.STATE.getByName('approved-notes:'+body.customer).approvedNotes(body);
    return json(result,result.status||200);
  }
  if (request.method === "POST" && path === "/query") {
    const claims = await requireAgent(request, env, "query");
    const body = await request.json();
    const sourceResolver=createSourceResolver(sourceRegistry,sourceId=>env.STATE.getByName(`source:${sourceId}`).sourceState(sourceId));
    // Specialist identities must use explicit customer policies; never fall
    // through to the legacy generic vector query when a customer is omitted.
    const knowledgeMapping = JSON.parse(env.ROLE_KNOWLEDGE_IDENTITIES || "{}");
    if (Object.hasOwn(knowledgeMapping, claims.client_id)
        || ['sales_b2b', 'csm', 'media', 'ops_orchestration'].includes(claims.agent_id)) {
      return json(await customerQuery({claims, body, vectorIndex: env.VECTOR_INDEX,
        sourceResolver, identityPolicy: {identities: Object.values(knowledgeMapping)}}));
    }
    if (claims.agent_id === "ea_javar") {
      const result=await customerQuery({claims, body, vectorIndex: env.VECTOR_INDEX, sourceResolver});
      const extra=await env.STATE.getByName('approved-notes:'+body.customer).searchApprovedNotes(body);
      result.matches=[...result.matches,...extra].sort((a,b)=>b.score-a.score).slice(0,body.topK||4);
      return json(result);
    }
    if (!Array.isArray(body.vector) || body.vector.length !== 384 || !body.vector.every((value) => typeof value === "number" && Number.isFinite(value))) {
      throw new HttpError(400, "vector must contain 384 finite numbers; embeddings are generated by the approved all-MiniLM-L6-v2 runtime");
    }
    const topK = Math.max(1, Math.min(Number(body.top_k || 5), 20));
    const queryResult = await env.VECTOR_INDEX.query(body.vector, { topK, returnMetadata: "all", filter: scopedFilter(claims, body.filter) });
    const matches = Array.isArray(queryResult) ? queryResult : queryResult?.matches || [];
    return json({ ok: true, matches, identity: { agent_id: claims.agent_id, client_id: claims.client_id, grants: claims.grants } });
  }
  if (request.method === "POST" && path === "/ingest") {
    const claims = await requireAgent(request, env, "ingest");
    guardEaJavarRoute(claims, request.method, path);
    return handleIngest(request, env, claims);
  }
  if (request.method === "POST" && path === "/delete") {
    const claims = await requireAgent(request, env, "ingest");
    guardEaJavarRoute(claims, request.method, path);
    return handleDelete(request, env, claims);
  }
  if (path === "/state" && (request.method === "GET" || request.method === "POST")) {
    const authorization = request.headers.get("authorization") || "";
    if (!authorization.startsWith("Bearer ")) throw new HttpError(401, "missing bearer token");
    const claims = await verifyHmacJwt(authorization.slice(7).trim(), env);
    guardEaJavarRoute(claims, request.method, path);
    return handleState(request, env, claims);
  }
  throw new HttpError(404, "not found");
}
__name(route, "route");
var StateEntity = class extends DurableObject {
  static {
    __name(this, "StateEntity");
  }
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`
        CREATE TABLE IF NOT EXISTS events (
          server_assigned_seq INTEGER PRIMARY KEY,
          event_id TEXT NOT NULL UNIQUE,
          event_hash TEXT NOT NULL UNIQUE,
          schema_version INTEGER NOT NULL,
          ts TEXT NOT NULL,
          accepted_at TEXT NOT NULL,
          agent_id TEXT NOT NULL,
          client_id TEXT NOT NULL,
          session_id TEXT NOT NULL,
          entity_type TEXT NOT NULL,
          entity_id TEXT NOT NULL,
          event_type TEXT NOT NULL,
          payload TEXT NOT NULL,
          prev_event_id TEXT
        );
        CREATE TABLE IF NOT EXISTS manifests (
          source_file TEXT PRIMARY KEY,
          source_version TEXT NOT NULL,
          chunk_ids TEXT NOT NULL,
          status TEXT NOT NULL,
          source_repo TEXT NOT NULL,
          source_ref TEXT NOT NULL,
          ingest_run_id TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS events_hash_idx ON events(event_hash);
      `);
    });
  }
  getManifest(sourceFile) {
    const row = this.ctx.storage.sql.exec("SELECT * FROM manifests WHERE source_file = ? LIMIT 1", sourceFile).toArray()[0];
    if (!row) return null;
    return { ...row, chunk_ids: JSON.parse(row.chunk_ids) };
  }
  approvedNotes(body) { return notes(this.ctx.storage,body); }
  searchApprovedNotes(body) { return searchNotes(this.ctx.storage,body); }
  sourceState(sourceId) {
    if(!sourceRegistry.sources.some(s=>s.source_id===sourceId)) throw new Error('Unknown registered source');
    return sourcePublicationRepository(this.ctx.storage).read(sourceId);
  }
  async maintainSource(sourceId,action,body) {
    const source=sourceRegistry.sources.find(s=>s.source_id===sourceId);
    if(!source)return {error:'Unknown registered source',status:403};
    const repository=sourcePublicationRepository(this.ctx.storage);
    try {
      const receipt=action==='publish'
        ? await publishSource({source,candidate:body.candidate,runId:body.run_id,repository,index:this.env.VECTOR_INDEX})
        : action==='restore' ? await restoreSource({source,candidate:body.candidate,
          freshOriginal:body.fresh_original, expectedWithdrawal:body.expected_withdrawal,
          runId:body.run_id,repository,index:this.env.VECTOR_INDEX})
        : action==='stale' ? await markSourceStale({sourceId,repository,runId:body.run_id})
        : await withdrawSource({sourceId,repository,reason:body.reason,runId:body.run_id});
      return {ok:true,receipt};
    } catch(error) {
      if(error instanceof PublicationError)return {error:error.code,status:409};
      throw error;
    }
  }
  async teamTask(input, actor) {
    try {
      initializeTeamTasks(this.ctx.storage);
      let dependencies=null;
      if (input.action==='complete' || input.action==='verify') {
        const current=operateTeamTask(this.ctx.storage,{action:'read',customer:input.customer,task_id:input.task_id},actor).task;
        dependencies=await Promise.all((current?.dependencies||[]).map(async dep=>{
          const result=await this.env.STATE.getByName(`team:${input.customer}:${dep.task_id}`)
            .teamTask({action:'read',customer:input.customer,task_id:dep.task_id},actor);
          return {task_id:dep.task_id,revision:result.task?.revision,status:result.task?.status};
        }));
      }
      return operateTeamTask(this.ctx.storage, input, actor, Date.now(), dependencies, JSON.parse(this.env.TEAM_WORKERS || "{}"));
    } catch (error) {
      if (error instanceof TeamTaskError) return {error: error.message, status: error.status};
      throw error;
    }
  }
  recordManifest(input) {
    this.ctx.storage.sql.exec(
      `INSERT INTO manifests (source_file,source_version,chunk_ids,status,source_repo,source_ref,ingest_run_id,updated_at)
       VALUES (?,?,?,?,?,?,?,?)
       ON CONFLICT(source_file) DO UPDATE SET source_version=excluded.source_version,chunk_ids=excluded.chunk_ids,status=excluded.status,source_repo=excluded.source_repo,source_ref=excluded.source_ref,ingest_run_id=excluded.ingest_run_id,updated_at=excluded.updated_at`,
      input.source_file,
      input.source_version,
      JSON.stringify(input.chunk_ids),
      input.status,
      input.source_repo,
      input.source_ref,
      input.ingest_run_id,
      input.updated_at
    );
    return this.getManifest(input.source_file);
  }
  async append(input) {
    const immutable = {
      schema_version: 1,
      ts: input.ts,
      agent_id: input.agent_id,
      client_id: input.client_id,
      session_id: input.session_id,
      entity_type: input.entity_type,
      entity_id: input.entity_id,
      event_type: input.event_type,
      payload: input.payload,
      prev_event_id: input.prev_event_id
    };
    const eventHash = await sha256Hex(canonicalJson(immutable));
    const duplicate = this.ctx.storage.sql.exec("SELECT * FROM events WHERE event_hash = ? LIMIT 1", eventHash).toArray()[0];
    if (duplicate) return { status: 200, idempotent: true, event: this.#decodeEvent(duplicate) };
    // Read and compare after hashing: no asynchronous yield may separate this
    // head read from the synchronous SQLite insert below.
    const head = this.ctx.storage.sql.exec("SELECT server_assigned_seq,event_id,event_hash FROM events ORDER BY server_assigned_seq DESC LIMIT 1").toArray()[0] || null;
    const currentHeadId = head?.event_id || null;
    if (currentHeadId !== input.prev_event_id) return { status: 409, error: "head_conflict", current_head: head ? { server_assigned_seq: head.server_assigned_seq, event_id: head.event_id } : null };
    const eventId = makeUlid();
    const seq = Number(head?.server_assigned_seq || 0) + 1;
    const acceptedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.ctx.storage.sql.exec(
      `INSERT INTO events (server_assigned_seq,event_id,event_hash,schema_version,ts,accepted_at,agent_id,client_id,session_id,entity_type,entity_id,event_type,payload,prev_event_id)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      seq,
      eventId,
      eventHash,
      immutable.schema_version,
      immutable.ts,
      acceptedAt,
      immutable.agent_id,
      immutable.client_id,
      immutable.session_id,
      immutable.entity_type,
      immutable.entity_id,
      immutable.event_type,
      JSON.stringify(immutable.payload),
      immutable.prev_event_id
    );
    return { status: 201, idempotent: false, event: { ...immutable, event_id: eventId, event_hash: eventHash, server_assigned_seq: seq, accepted_at: acceptedAt } };
  }
  read({ limit = 50 } = {}) {
    const rows = this.ctx.storage.sql.exec("SELECT * FROM events ORDER BY server_assigned_seq DESC LIMIT ?", limit).toArray();
    return { events: rows.reverse().map((row) => this.#decodeEvent(row)), head: rows.length ? { server_assigned_seq: rows[0].server_assigned_seq, event_id: rows[0].event_id } : null };
  }
  #decodeEvent(row) {
    return { ...row, payload: JSON.parse(row.payload) };
  }
};
var dev_rag_worker_phase3_default = {
  async fetch(request, env) {
    try {
      return await route(request, env);
    } catch (error) {
      if (error instanceof HttpError || error instanceof EaJavarPolicyError || error instanceof CustomerPolicyError || error instanceof SourceServingError || error instanceof SourceMaintenanceError) return json({ ok: false, error: error.message, details: error.details }, error.status);
      console.error(JSON.stringify({ level: "error", message: error?.message || String(error) }));
      return json({ ok: false, error: "internal_error" }, 500);
    }
  }
};
export {
  StateEntity,
  dev_rag_worker_phase3_default as default
};
//# sourceMappingURL=dev-rag-worker.phase3.js.map

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/wrangler.example.json

SHA-256: `76b7a4265b2fc3e2e55f374d922767c28ce3e20179f9e51a4e80d09e3f274e22`. Canonical mtime: 2026-09-14T18:53:47.719978+00:00. State: SOURCE_ONLY.

```json
{
  "name": "hermes-offline-example",
  "main": "worker.mjs",
  "compatibility_date": "2026-08-25",
  "compatibility_flags": [
    "nodejs_compat"
  ],
  "keep_vars": true,
  "vars": {
    "ENVIRONMENT": "offline-example",
    "JWT_AUDIENCE": "rag-api-dev",
    "JWT_ISSUER": "dev-rag.increaseroas.com"
  },
  "durable_objects": {
    "bindings": [
      {
        "name": "STATE",
        "class_name": "StateEntity"
      }
    ]
  },
  "vectorize": [
    {
      "binding": "VECTOR_INDEX",
      "index_name": "dev-rag-knowledge"
    }
  ],
  "unsafe": {
    "metadata": {
      "exports": {
        "StateEntity": {
          "type": "durable-object",
          "storage": "sqlite"
        }
      }
    }
  },
  "workers_dev": false,
  "preview_urls": false
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/source-registry.schema.json

SHA-256: `eb5d438301967a38d457c26d4d26d35da050f9a469b19cf435481c3bdff0991d`. Canonical mtime: 2026-09-14T18:56:09.290452+00:00. State: SOURCE_ONLY.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Source registry structural contract (no deployment authorization)",
  "type": "object",
  "required": [
    "schema_version",
    "sources",
    "execution_customers"
  ],
  "properties": {
    "schema_version": {
      "type": "integer"
    },
    "sources": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "source_id",
          "canonical_location",
          "customer",
          "permitted_roles",
          "snapshots"
        ],
        "properties": {
          "source_id": {
            "type": "string"
          },
          "canonical_location": {
            "type": "string"
          },
          "customer": {
            "type": "string"
          },
          "permitted_roles": {
            "type": "array",
            "items": {
              "type": "string"
            }
          },
          "snapshots": {
            "type": "array",
            "items": {
              "type": "object",
              "required": [
                "source_file",
                "namespace",
                "permitted_roles"
              ],
              "properties": {
                "source_file": {
                  "type": "string"
                },
                "namespace": {
                  "type": "string"
                },
                "permitted_roles": {
                  "type": "array",
                  "items": {
                    "type": "string"
                  }
                }
              }
            }
          }
        }
      }
    },
    "execution_customers": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "customer",
          "aliases",
          "permitted_roles"
        ],
        "properties": {
          "customer": {
            "type": "string",
            "pattern": "^[a-z][a-z0-9_]{0,63}$"
          },
          "aliases": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "string",
              "minLength": 1
            }
          },
          "permitted_roles": {
            "type": "array",
            "items": {
              "type": "string"
            }
          }
        }
      }
    },
    "execution_jobs": {
      "type": "array"
    },
    "drive_scope": {
      "type": "object"
    }
  },
  "additionalProperties": true
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/team-tasks.mjs

SHA-256: `2a0c8aa2a4b2538d16883324e38ed7c57330425c162f0a01f1f5d05e26878f15`. Canonical mtime: 2026-09-15T05:18:17.676973+00:00. State: SOURCE_ONLY.

```javascript
import { workerActions, transitionWorker, validateDelegationGrant, approveRecovery, consumeRecovery } from './team-workers.mjs';
// Shared task transitions for the existing StateEntity Durable Object.
// This module performs no messaging or business-system writes.
export class TeamTaskError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const fail = (status, message) => { throw new TeamTaskError(status, message); };
const text = (v, max = 2000) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
const id = v => typeof v === 'string' && /^[A-Za-z0-9_-]{1,100}$/.test(v);
const dependencyRefs = (value, selfTaskId) => Array.isArray(value) && value.length <= 10
  && value.every(ref => ref && Object.keys(ref).sort().join(',') === 'revision,task_id'
    && id(ref.task_id) && ref.task_id !== selfTaskId && Number.isInteger(ref.revision) && ref.revision >= 0)
  && new Set(value.map(ref => ref.task_id)).size === value.length;
const dependencyChecks = (task, value) => {
  if (!task.dependencies?.length) return true;
  if (!Array.isArray(value) || value.length !== task.dependencies.length) return false;
  const checks = new Map(value.map(ref => [ref?.task_id, ref]));
  return task.dependencies.every(dep => {
    const check = checks.get(dep.task_id);
    return check && check.status === 'done' && check.revision === dep.revision;
  });
};
const roles = new Set(['ea_javar', 'ops_orchestration']);

export function initializeTeamTasks(storage) {
  storage.sql.exec(`CREATE TABLE IF NOT EXISTS team_task (
    singleton INTEGER PRIMARY KEY CHECK(singleton=1), body TEXT NOT NULL
  ); CREATE TABLE IF NOT EXISTS team_task_receipts (
    request_id TEXT PRIMARY KEY, request_body TEXT NOT NULL, result TEXT NOT NULL
  );`);
}

// trustedDependencies is populated by the StateEntity after it reads each
// referenced task's authoritative DO state. It is intentionally separate from
// the request body so callers cannot self-assert dependency completion.
export function operateTeamTask(storage, input, actor, now = Date.now(), trustedDependencies = null, trustedWorkers = {}) {
  if ((!roles.has(actor) && !trustedWorkers[actor]) || input.customer !== 'increase_roas') fail(403, 'Team scope denied');
  if (!id(input.task_id)) fail(400, 'Invalid task identity');
  const read = () => {
    const row = storage.sql.exec('SELECT body FROM team_task WHERE singleton=1').toArray()[0];
    return row ? JSON.parse(row.body) : null;
  };
  if (!roles.has(actor) && read()?.worker?.id !== actor) fail(403, 'Worker scope denied');
  if (input.action === 'read') return {task: read()};
  if (!roles.has(actor) && !workerActions.has(input.action)) fail(403, 'Worker action denied');
  if (!id(input.request_id)) fail(400, 'Stable request_id required');
  const requestBody = JSON.stringify({actor, input});
  return storage.transactionSync(() => {
    const prior = storage.sql.exec('SELECT request_body,result FROM team_task_receipts WHERE request_id=?', input.request_id).toArray()[0];
    if (prior) {
      if (prior.request_body !== requestBody) fail(409, 'Request identity reused with different content');
      return {...JSON.parse(prior.result), replayed: true};
    }
    let task = read();
    if (input.action === 'create') {
      if (actor !== 'ea_javar') fail(403, 'Only Javar assigns team work');
      if (task) fail(409, 'Task already exists');
      if (!text(input.title, 200) || !text(input.next_action) || !text(input.source, 1000)) fail(400, 'Title, next action and source required');
      if (input.dependencies !== undefined && !dependencyRefs(input.dependencies, input.task_id)) fail(400, 'Dependencies must be unique task references');
      if (input.deadline !== null && !(typeof input.deadline === 'string' && /(?:Z|[+-]\d\d:\d\d)$/.test(input.deadline) && Number.isFinite(Date.parse(input.deadline)))) fail(400, 'Deadline must be null or a timestamp with timezone');
      task = {task_id: input.task_id, customer: input.customer, title: input.title,
        owner: 'ops_orchestration', requested_by: actor, next_action: input.next_action,
        deadline: input.deadline, source: input.source, status: 'assigned',
        revision: 0, fence: 0, lease_until: null, evidence: [], result: null,
        dependencies: input.dependencies || []};
      if (input.delegation_grant !== undefined) {
        task.delegation_grant = validateDelegationGrant(input.delegation_grant, fail);
        const o=input.origin;
        if (!o || o.customer!==task.customer || !id(o.scope_task_id)
            || !((o.platform==='slack'&&o.chat_id==='D0BTZPTU6A0'&&o.user_id==='U0BGPQ2APT7')
              ||(o.platform==='telegram'&&o.chat_id==='5565447574'&&o.user_id==='5565447574'))) fail(403,'Authenticated owner origin required for delegation');
        task.origin=structuredClone(o);
      }
    } else {
      if (!task) fail(404, 'Task not found');
      if (input.revision !== task.revision) fail(409, 'Task changed; read current state');
      if (input.action === 'approve_recovery') {
        approveRecovery(task,input,actor,fail);
      } else if (workerActions.has(input.action)) {
        transitionWorker(task, input, actor, now, trustedWorkers, fail);
      } else if (input.action === 'claim') {
        if (actor !== task.owner || !['assigned','in_progress'].includes(task.status)) fail(403, 'Task cannot be claimed');
        if (task.lease_until && task.lease_until > now) fail(409, 'Task already has an active claim');
        task.fence += 1;
        task.lease_until = now + 15 * 60 * 1000;
        task.status = 'in_progress';
      } else if (input.action === 'takeover') {
        consumeRecovery(task,input,fail);
        if (actor !== 'ea_javar' || !['assigned', 'blocked', 'in_progress'].includes(task.status)
            || task.owner === actor || input.fence !== task.fence) {
          fail(409, 'Only an available task can be taken over');
        }
        if (!text(input.reason, 1000)) fail(400, 'Takeover reason required');
        task.owner = actor; task.fence += 1; task.lease_until = now + 15 * 60 * 1000;
        task.status = 'in_progress';
      } else if (['progress','block','complete'].includes(input.action)) {
        if (actor !== task.owner || task.status !== 'in_progress' || input.fence !== task.fence || task.lease_until <= now) fail(409, 'Current owner claim required');
        if (!text(input.next_action)) fail(400, 'Next action required');
        task.next_action = input.next_action;
        if (input.action === 'progress') task.lease_until = now + 15 * 60 * 1000;
        if (input.action === 'block') {
          if (!text(input.reason)) fail(400, 'Blocker reason required');
          task.status = 'blocked'; task.result = input.reason; task.lease_until = null;
        }
        if (input.action === 'complete') {
          if (task.worker && task.worker.status !== 'submitted') fail(409, 'Worker must submit evidence before Ops completes');
          if (!text(input.result) || !Array.isArray(input.evidence) || input.evidence.length < 1 || input.evidence.length > 10 || !input.evidence.every(v => text(v,1000) && /^https:\/\//.test(v))) fail(400, 'Result and evidence links required');
          if (input.dependency_checks !== undefined) fail(400, 'Dependency checks are server supplied');
          if (!dependencyChecks(task, trustedDependencies)) fail(409, 'Dependencies must be verified at their recorded revisions');
          task.result = input.result; task.evidence = input.evidence;
          task.status = 'awaiting_verification'; task.lease_until = null;
        }
      } else if (input.action === 'verify') {
        if (actor !== 'ea_javar' || task.status !== 'awaiting_verification') fail(403, 'Javar must verify submitted work');
        if (!text(input.verification)) fail(400, 'Verification evidence required');
        if (!dependencyChecks(task, trustedDependencies)) fail(409, 'Dependencies must be verified at their recorded revisions');
        task.verification = input.verification; task.status = 'done'; task.next_action = 'Complete';
      } else if (input.action === 'resume') {
        consumeRecovery(task,input,fail);
        const opsOwns = actor === 'ops_orchestration' && task.owner === actor;
        if (task.status !== 'blocked' || (actor !== 'ea_javar' && !opsOwns)) fail(403, 'Blocked work can be resumed by Ops or Javar');
        if (!text(input.next_action) || !text(input.reason)) fail(400, 'Resolved blocker and next action required');
        task.status = 'assigned'; task.next_action = input.next_action; task.result = input.reason;
        task.lease_until = null;
      } else if (input.action === 'cancel') {
        if (actor !== 'ea_javar' || task.status === 'done') fail(403, 'Cancellation denied');
        if (!text(input.reason)) fail(400, 'Cancellation reason required');
        task.status = 'cancelled'; task.result = input.reason; task.lease_until = null; task.fence += 1;
      } else fail(400, 'Unsupported action');
    }
    // Open and blocked work needs durable evidence before it can be completed.
    if (input.evidence !== undefined) {
      if (!Array.isArray(input.evidence) || input.evidence.length > 10 || !input.evidence.every(v => text(v,1000) && /^https:\/\//.test(v))) fail(400, 'Evidence must be HTTPS source links');
      const evidence = [...new Set([...(task.evidence || []), ...input.evidence])];
      if (evidence.length > 10) fail(400, 'At most ten evidence links per task');
      task.evidence = evidence;
    }
    if (task.worker && ['done','cancelled','blocked','awaiting_verification'].includes(task.status)) task.worker.status = 'ended';
    task.revision += 1; task.updated_at = new Date(now).toISOString();
    const result = {task, receipt: {request_id: input.request_id, actor, action: input.action, revision: task.revision, at: task.updated_at}};
    storage.sql.exec('INSERT INTO team_task(singleton,body) VALUES(1,?) ON CONFLICT(singleton) DO UPDATE SET body=excluded.body', JSON.stringify(task));
    storage.sql.exec('INSERT INTO team_task_receipts(request_id,request_body,result) VALUES(?,?,?)', input.request_id, requestBody, JSON.stringify(result));
    return result;
  });
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/team-workers.mjs

SHA-256: `445e3f2355ffb89a93b05ae56a5187ff6a2d340dc5e7d12fb8cfb2f77f793c76`. Canonical mtime: 2026-09-15T05:18:16.090341+00:00. State: SOURCE_ONLY.

```javascript
// Assignment transitions inside the existing task transaction. Registry input is
// server-owned configuration, never notification text or caller-supplied tools.
const text = (v,n=2000)=>typeof v==='string'&&v.trim()&&v.length<=n;
const equal = (a,b)=>JSON.stringify(a)===JSON.stringify(b);
const links = v=>Array.isArray(v)&&v.length>0&&v.length<=10&&v.every(x=>text(x,1000)&&x.startsWith('https://'));
export const workerActions=new Set(['dispatch','worker_accept','worker_checkpoint','worker_submit','worker_block']);
export function validateDelegationGrant(grant, fail) {
 if(!grant||!Array.isArray(grant.capabilities)||!grant.capabilities.length||grant.capabilities.length>20||!grant.capabilities.every(x=>text(x,100))||!text(grant.constraints)||!Number.isInteger(grant.max_iterations)||grant.max_iterations<1||grant.max_iterations>100)fail(400,'Invalid delegation grant');
 return structuredClone(grant);
}
export function transitionWorker(task,input,actor,now,registry,fail) {
 const w=task.worker;
 if(input.action==='dispatch') {
  if(actor!=='ops_orchestration'||task.owner!==actor||task.status!=='in_progress'||input.fence!==task.fence||task.lease_until<=now)fail(409,'Current Ops claim required');
  if(w&&!['blocked','ended'].includes(w.status))fail(409,'Task already has an active worker');
  const registration=registry[input.worker_id];const cap=registration?.capabilities?.[input.capability];
  if(!task.delegation_grant?.capabilities.includes(input.capability)||!registration?.customers?.includes(task.customer)||!cap)fail(403,'Worker capability is not authorized');
  const policy={provider:input.provider,model:input.model};
  if(!registration.models?.some(m=>equal(m,policy)))fail(403,'Worker model is not approved');
  if(w&&!equal(w.model_policy,policy))fail(403,'Retry must retain assigned model policy');
  if(!text(input.outcome)||!text(input.next_action))fail(400,'Worker outcome and resumable next action required');
  task.worker={id:input.worker_id,assignment_id:input.request_id,capability:input.capability,model_policy:policy,
   tools:[...cap.tools],resources:[...cap.resources],outcome:input.outcome,constraints:task.delegation_grant.constraints,
   max_iterations:task.delegation_grant.max_iterations,next_action:input.next_action,status:'dispatched',
   checkpoint:w?.checkpoint||null,previous_assignment:w?.assignment_id||null,dispatched_at:now};
  return;
 }
 if(!w||w.id!==actor)fail(403,'Worker scope denied');
 if(task.status!=='in_progress'||task.owner!=='ops_orchestration'||input.assignment_id!==w.assignment_id||!['dispatched','accepted','running'].includes(w.status)||task.lease_until<=now)fail(409,'Worker assignment is not active or has ended');
 if(input.action==='worker_accept') {
  if(w.status!=='dispatched')fail(409,'Worker already accepted');
  const check=input.access_check;
  if(!check||!equal(check.tools,w.tools)||!equal(check.resources,w.resources)||!text(check.evidence))fail(403,'Actual tool/resource/checkpoint access check required');
  w.access_check=check;w.status='accepted';w.accepted_at=now;
 } else if(input.action==='worker_block') {
  if(!text(input.reason)||!text(input.next_action))fail(400,'Blocker and resumable next action required');
  w.status='blocked';w.blocker=input.reason;w.next_action=input.next_action;
 } else {
  if(!['accepted','running'].includes(w.status))fail(409,'Worker acceptance required');
  if(!equal(input.observed_model,w.model_policy))fail(403,'Observed worker model does not match assignment');
  w.observed_model=structuredClone(input.observed_model);
  if(input.action==='worker_checkpoint') {
   const c=input.checkpoint;
   if(!c||!text(c.completed)||!text(c.remaining)||!text(c.next_action)||!links(c.evidence))fail(400,'Durable checkpoint requires completed work, evidence, remaining work and next action');
   w.checkpoint={...c,reference:`team:${task.customer}:${task.task_id}:worker:${w.assignment_id}:revision:${task.revision+1}`};
   w.next_action=c.next_action;w.status='running';
  } else if(input.action==='worker_submit') {
   if(!w.checkpoint||!text(input.result))fail(400,'Worker checkpoint and result required');
   w.result=input.result;w.status='submitted';w.submitted_at=now;
   if(input.runtime_evidence!==undefined) {
    if(JSON.stringify(input.runtime_evidence).length>20000)fail(400,'Runtime receipt too large');
    w.runtime_evidence=structuredClone(input.runtime_evidence);
   }
  }
 }
 w.updated_at=now;
}

export function approveRecovery(task,input,actor,fail) {
 // Only the trusted owner-event adapter calls this action. Public team_task
 // schemas and clients deliberately do not expose an approval operation.
 const p=input.intervention;
 if(actor!=='ea_javar')fail(403,'Javar owner approval adapter required');
 if(!task.delegation_grant||task.owner!=='ops_orchestration'||!['assigned','in_progress','blocked'].includes(task.status))fail(409,'Delegation is not recoverable');
 if(!text(input.approval_id,100)||!p||!['takeover','resume'].includes(p.action)||!text(p.reason)||(p.action==='resume'&&!text(p.next_action)))fail(400,'Exact recovery intervention required');
 task.recovery_approval={id:input.approval_id,intervention:{action:p.action,reason:p.reason,...(p.action==='resume'?{next_action:p.next_action}:{})},
  assignment_id:task.worker?.assignment_id||null,grant:structuredClone(task.delegation_grant),consumed:false};
}
export function consumeRecovery(task,input,fail) {
 if(!task.delegation_grant||task.owner!=='ops_orchestration')return;
 if(task.status==='blocked')return;
 const a=task.recovery_approval;
 const p={action:input.action,reason:input.reason,...(input.action==='resume'?{next_action:input.next_action}:{})};
 if(!a||a.consumed||input.recovery_id!==a.id||!equal(a.intervention,p)||a.assignment_id!==(task.worker?.assignment_id||null)||!equal(a.grant,task.delegation_grant))fail(403,'Exact unconsumed owner recovery approval required');
 a.consumed=true;
 if(task.worker)task.worker.status='ended';
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/customer-policy.mjs

SHA-256: `f949184179ce3fe654e137b603a72f482358d51bda71531d28618969f14fe03e`. Canonical mtime: not captured on retry. State: SOURCE_ONLY.

```javascript
import customerSource from './customer-source.json';
import agencySource from './agency-source.json';
import csmSource from './csm-source.json';
import setterSource from './setter-source.json';
import csmRoleSource from './csm-role-source.json';
import mediaWeeklySource from '../../media/rag-candidates/weekly-client-check-in.json';
import mediaBuyerSource from '../../media/rag-candidates/media-buyer-sop.json';
import mediaQualitySource from '../../media/rag-candidates/lead-quality-optimization.json';
const SOURCES = [customerSource, agencySource, csmSource, setterSource, csmRoleSource, mediaWeeklySource, mediaBuyerSource, mediaQualitySource];

export class CustomerPolicyError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
function fail(status, message) { throw new CustomerPolicyError(status, message); }

const DEFAULT_EA_IDENTITY = {
  agent_id: 'ea_javar',
  client_id: '8f6c9735127628ccb57edbfef708a978.access',
  grants: ['query'],
};

function configuredIdentity({claims, identityPolicy}) {
  // Omitting the policy intentionally preserves the accepted Javar contract.
  if (identityPolicy === undefined) return DEFAULT_EA_IDENTITY;
  if (!identityPolicy || typeof identityPolicy !== 'object' || Array.isArray(identityPolicy)
      || !Array.isArray(identityPolicy.identities)) fail(403, 'Customer knowledge identity denied');
  const match = identityPolicy.identities.find(identity => identity
    && identity.agent_id === claims.agent_id && identity.client_id === claims.client_id);
  if (!match || !Array.isArray(match.grants)
      || JSON.stringify(match.grants) !== JSON.stringify(claims.grants)
      || JSON.stringify(match.grants) !== '["query"]'
      || !Array.isArray(match.customers)) fail(403, 'Customer knowledge identity denied');
  return match;
}

export async function customerQuery({claims, body, vectorIndex, identityPolicy, sourceResolver}) {
  const identity = configuredIdentity({claims, identityPolicy});
  if (claims.agent_id !== identity.agent_id || claims.client_id !== identity.client_id
      || JSON.stringify(claims.grants) !== JSON.stringify(identity.grants)) {
    fail(403, 'Customer knowledge identity denied');
  }
  if (!body || typeof body !== 'object' || Array.isArray(body)
      || Object.keys(body).some(k => !['customer', 'query', 'topK', 'vector'].includes(k))) fail(400, 'Invalid query fields');
  if (identityPolicy !== undefined && !identity.customers.includes(body.customer)) {
    fail(403, 'Customer scope unavailable');
  }
  const sources = SOURCES.filter(s => s.customer === body.customer
    && (s.status ?? 'active') === 'active' && s.agents.includes(claims.agent_id));
  if (!sources.length) fail(403, 'Customer scope unavailable');
  const query = typeof body.query === 'string' ? body.query.trim() : '';
  const topK = body.topK ?? 4;
  if (!query || query.length > 500 || !Number.isInteger(topK) || topK < 1 || topK > 4) fail(400, 'Invalid query');
  if (!Array.isArray(body.vector) || body.vector.length !== 384 || !body.vector.every(Number.isFinite)) fail(400, 'Invalid embedding');
  const matches = [];
  const sourceReads = [];
  for (const baseline of sources) {
    const resolved = sourceResolver ? await sourceResolver.resolve(baseline, body.customer, claims.agent_id) : {manifest:baseline};
    if (!resolved) continue;
    const source = resolved.manifest;
    sourceReads.push(resolved);
    const result = await vectorIndex.query(body.vector, {
      topK, returnMetadata: 'all', namespace: source.namespace,
      filter: {tenant: source.customer, status: 'active', agent_access: claims.agent_id},
    });
    for (const hit of result.matches || []) {
    const expected = source.chunks.find(c => c.id === hit.id);
    const m = hit.metadata || {};
    if (!expected || m.tenant !== source.customer || m.agent_access !== claims.agent_id
        || m.status !== 'active' || m.source_sha256 !== source.source_sha256
        || m.source_file !== source.source_file || typeof m.text !== 'string') fail(502, 'Knowledge source mismatch');
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(m.text));
    const hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
    if (hash !== expected.text_sha256) fail(502, 'Knowledge content mismatch');
    matches.push({id: hit.id, score: hit.score, text: m.text, source_url: source.source_url,
      source_file: source.source_file, source_sha256: source.source_sha256, as_of: source.as_of,
      original_revision: source.original_revision ?? null, original_sha256: source.original_sha256 ?? null,
      transformation: source.transformation ?? 'historical_reference_snapshot'});
    }
  }
  if (sourceResolver) await sourceResolver.assertCurrent(sourceReads);
  matches.sort((a, b) => b.score - a.score);
  return {ok: true, customer: body.customer, matches: matches.slice(0, topK),
    source_policy: 'Reference snapshot, not current provider state or permission to act. Cite sources; recheck approvals before acting.',
    identity: {agent_id: claims.agent_id, grants: claims.grants}};
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/source-serving.mjs

SHA-256: `2aabf2a5566794b08aab6f12d7ad06267f8238c1780b73f384ae6e19d7ce26c5`. Canonical mtime: 2026-09-14T00:49:03.072245+00:00. State: SOURCE_ONLY.

```javascript
// Resolve the serving snapshot from the canonical source registry and durable
// publication state. A failed state read never falls back to an older snapshot.
export class SourceServingError extends Error {
  constructor(message) { super(message); this.status=503; }
}
const fail=message=>{throw new SourceServingError(message);};
const sorted=values=>JSON.stringify([...values].sort());

export function createSourceResolver(registry, readState) {
  return {
    async resolve(baseline, customer, role) {
      const source=registry.sources.find(s=>s.customer===customer
        && s.snapshots.some(v=>v.source_file===baseline.source_file && v.namespace===baseline.namespace));
      if (!source || !source.permitted_roles.includes(role)) fail('Registered source scope unavailable');
      const allowedDrive=registry.drive_scope?.[role];
      if (allowedDrive && source.drive_id!==allowedDrive) return null;
      const grant=source.snapshots.find(v=>v.source_file===baseline.source_file && v.namespace===baseline.namespace);
      if (!grant.permitted_roles.includes(role)) fail('Registered source role unavailable');
      const state=await readState(source.source_id);
      if(state?.denied || state?.stale)return null;
      let manifest=baseline;
      if(state) {
        if (!Number.isSafeInteger(state.revision) || state.revision<1 || !Array.isArray(state.manifests)) fail('Source publication state invalid');
        manifest=state.manifests.find(m=>m.source_file===baseline.source_file);
        if (!manifest || manifest.customer!==customer || !Array.isArray(manifest.agents)
            || sorted(manifest.agents)!==sorted(grant.permitted_roles)
            || manifest.source_url!==source.canonical_location || manifest.status!=='active'
            || !Array.isArray(manifest.chunks) || !manifest.chunks.length) fail('Source publication scope invalid');
      }
      return {manifest,sourceId:source.source_id,revision:state?.revision||0};
    },
    async assertCurrent(reads) {
      for(const observed of reads) {
        const state=await readState(observed.sourceId);
        if(state?.denied || state?.stale || (state?.revision||0)!==observed.revision) fail('Source changed during retrieval; retry from current registry');
      }
    },
  };
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/source-publication.mjs

SHA-256: `bb197fe290d388da3dc0c55cd4454c26b4081f5587c11efd242d9b8beebe2b3e`. Canonical mtime: 2026-09-14T11:36:44.888846+00:00. State: SOURCE_ONLY.

```javascript
// Publication core for the existing Worker/StateEntity. The repository adapter
// must implement atomic compareAndSet; authentication belongs to the HTTP route.
import {createHash} from 'node:crypto';

export class PublicationError extends Error {
  constructor(code) { super(code); this.code = code; }
}
const fail = code => { throw new PublicationError(code); };
export const sha256 = value => createHash('sha256').update(value).digest('hex');
export const publicationNamespace = (sourceId, file, snapshotHash) =>
  'sync-' + sha256([sourceId, file, snapshotHash].join('|')).slice(0,48);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const sorted = values => [...values].sort();
const hash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

export function validatePublication(source, candidate) {
  if (!source || candidate.source_id !== source.source_id
      || candidate.customer !== source.customer) fail('source_scope_denied');
  // Registered scope authorizes this reference; file ownership is provenance,
  // not the accountable business owner. Shared Drive files omit owners.
  if (source.drive_id && candidate.original?.drive_id !== source.drive_id) fail('source_drive_scope_denied');
  if (!candidate.original || !hash(candidate.original.sha256)
      || typeof candidate.original.revision !== 'string' || !candidate.original.revision
      || !hash(candidate.original.access_metadata_sha256)
      || candidate.original.access_verified !== true) fail('original_provenance_incomplete');
  const owners=source.file_owners ?? source.owner ?? [];
  if (owners.length && !same(sorted(candidate.original.owner_emails || []), sorted(owners.map(o => o.email)))) {
    fail('source_owner_changed');
  }
  if (typeof candidate.snapshot_text !== 'string' || !candidate.snapshot_text.trim()
      || Buffer.byteLength(candidate.snapshot_text) > 512 * 1024
      || sha256(candidate.snapshot_text) !== candidate.snapshot_sha256) fail('snapshot_hash_mismatch');
  if (!Array.isArray(candidate.variants) || candidate.variants.length !== source.snapshots.length) {
    fail('incomplete_source_variants');
  }
  const seenFiles = new Set(), seenIds = new Set(), namespaces = new Set();
  for (const variant of candidate.variants) {
    const baseline = source.snapshots.find(s => s.source_file === variant.source_file);
    if (!baseline || seenFiles.has(variant.source_file)) fail('variant_identity_invalid');
    seenFiles.add(variant.source_file);
    if (!Array.isArray(variant.agents) || !same(sorted(variant.agents), sorted(baseline.permitted_roles))) {
      fail('variant_role_scope_changed');
    }
    if (typeof variant.namespace !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(variant.namespace)
        || variant.namespace === baseline.namespace || namespaces.has(variant.namespace)) fail('replacement_namespace_invalid');
    if (variant.namespace !== publicationNamespace(source.source_id, variant.source_file, candidate.snapshot_sha256)) fail('namespace_content_identity_mismatch');
    namespaces.add(variant.namespace);
    if (!Array.isArray(variant.chunks) || !variant.chunks.length || variant.chunks.length > 500
        || variant.chunks.map(c => c.text).join('') !== candidate.snapshot_text) fail('snapshot_chunks_incomplete');
    for (let i = 0; i < variant.chunks.length; i++) {
      const c = variant.chunks[i];
      if (typeof c.text !== 'string' || !c.text || c.text.length > 2500
          || c.text_sha256 !== sha256(c.text) || c.chunk_index !== i
          || !hash(c.id) || seenIds.has(c.id)
          || !Array.isArray(c.values) || c.values.length !== 384 || !c.values.every(Number.isFinite)) {
        fail('invalid_chunk');
      }
      const expectedId = sha256([source.source_id, variant.source_file, variant.namespace,
        candidate.snapshot_sha256, String(i)].join('|'));
      if (c.id !== expectedId) fail('chunk_identity_mismatch');
      seenIds.add(c.id);
    }
  }
}

function manifests(source, candidate) {
  return candidate.variants.map(v => ({customer: source.customer, namespace: v.namespace,
    agents: v.agents, source_file: v.source_file, source_sha256: candidate.snapshot_sha256,
    source_url: source.canonical_location, status: 'active',
    original_revision: candidate.original.revision, original_sha256: candidate.original.sha256,
    access_metadata_sha256: candidate.original.access_metadata_sha256,
    transformation: candidate.transformation,
    chunks: v.chunks.map(({values, ...chunk}) => chunk)}));
}

async function verifyVectors({source, candidate, index, skipNamespaces = new Set()}) {
  for (const variant of candidate.variants) {
    if (variant.agents.length !== 1) fail('multi_role_variant_requires_explicit_metadata');
    if (skipNamespaces.has(variant.namespace)) continue;
    const vectors = variant.chunks.map(c => ({id: c.id, values: c.values,
      namespace: variant.namespace, metadata: {tenant: source.customer, status: 'active',
        agent_access: variant.agents[0], source_file: variant.source_file,
        source_sha256: candidate.snapshot_sha256, text: c.text}}));
    const acknowledgment = await index.upsert(vectors);
    if (!acknowledgment?.mutationId) fail('vector_upsert_not_acknowledged');
  }
  // All vectors must be visible and match before the serving pointer changes.
  for (const variant of candidate.variants) {
    const visible = await index.getByIds(variant.chunks.map(c => c.id));
    if (!Array.isArray(visible) || visible.length !== variant.chunks.length) fail('vectors_not_yet_visible');
    const byId = new Map(visible.map(v => [v.id, v]));
    for (const c of variant.chunks) {
      const actual = byId.get(c.id), m = actual?.metadata;
      if (!m || actual.namespace !== variant.namespace || m.tenant !== source.customer
          || m.agent_access !== variant.agents[0] || m.status !== 'active'
          || m.source_file !== variant.source_file || m.source_sha256 !== candidate.snapshot_sha256
          || typeof m.text !== 'string' || sha256(m.text) !== c.text_sha256) fail('vector_readback_mismatch');
    }
    const result = await index.query(variant.chunks[0].values, {namespace: variant.namespace,
      topK: 1, returnMetadata: 'all', filter: {tenant: source.customer, status: 'active', agent_access: variant.agents[0]}});
    const hit = result?.matches?.[0];
    if (!hit || !variant.chunks.some(c => c.id === hit.id)) fail('replacement_retrieval_unverified');
  }
}

export async function publishSource({source, candidate, runId, repository, index, now = new Date().toISOString()}) {
  validatePublication(source, candidate);
  if (typeof runId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(runId)) fail('stable_run_id_required');
  const fingerprint = sha256(JSON.stringify(candidate));
  let state = await repository.read(source.source_id);
  if (state?.denied) fail('source_withdrawn');
  const prior = await repository.readReceipt(source.source_id, runId);
  if (prior) {
    if (prior.fingerprint !== fingerprint) fail('run_id_reused');
    return prior;
  }
  const revision = state?.revision || 0;
  const activeNamespaces = new Set((state?.manifests || []).map(m => m.namespace));
  const prepared = manifests(source, candidate);
  await verifyVectors({source, candidate, index, skipNamespaces: activeNamespaces});
  const receipt = {run_id: runId, fingerprint, source_id: source.source_id,
    original_revision: candidate.original.revision, snapshot_sha256: candidate.snapshot_sha256,
    at: now, revision: revision + 1};
  const next = {revision: revision + 1, denied: false, manifests: prepared, receipt,
    previous_manifests: state?.manifests || null};
  // Withdrawal or concurrent publication wins over this in-flight operation.
  if (!await repository.compareAndSet(source.source_id, revision, next)) fail('source_changed_during_publication');
  // Old vectors are deliberately retained until post-publication acceptance.
  return receipt;
}

function validateFreshOriginal(candidate, freshOriginal, runId, now) {
  const checkedAt = Date.parse(freshOriginal?.checked_at || '');
  const nowAt = Date.parse(now);
  if (!freshOriginal || typeof freshOriginal !== 'object'
      || freshOriginal.access_verified !== true
      || typeof freshOriginal.checked_at !== 'string'
      || Number.isNaN(checkedAt) || Number.isNaN(nowAt)
      || checkedAt > nowAt + 5 * 60 * 1000
      || nowAt - checkedAt > 15 * 60 * 1000
      || freshOriginal.retrieval_run_id !== runId
      || !same(freshOriginal.provenance, candidate.original)) {
    fail('fresh_original_provenance_required');
  }
}

export async function restoreSource({source, candidate, freshOriginal, expectedWithdrawal,
  runId, repository, index, now = new Date().toISOString()}) {
  validatePublication(source, candidate);
  if (typeof runId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(runId)) fail('stable_run_id_required');
  validateFreshOriginal(candidate, freshOriginal, runId, now);
  if (!expectedWithdrawal || !Number.isInteger(expectedWithdrawal.revision)
      || typeof expectedWithdrawal.run_id !== 'string') fail('withdrawal_expectation_required');
  const fingerprint = sha256(JSON.stringify({action:'restore', source_id:source.source_id,
    candidate, expectedWithdrawal, freshOriginal}));
  const prior = await repository.readReceipt(source.source_id, runId);
  if (prior) {
    if (prior.fingerprint !== fingerprint) fail('run_id_reused');
    return prior;
  }
  const state = await repository.read(source.source_id);
  if (!state?.denied || !state.withdrawal
      || state.withdrawal.revision !== expectedWithdrawal.revision
      || state.withdrawal.run_id !== expectedWithdrawal.run_id) fail('withdrawal_expectation_mismatch');
  const revision = state.revision || 0;
  const prepared = manifests(source, candidate);
  // A restore always re-verifies every vector, even if its namespace already
  // exists from the withdrawn publication. The serving denial remains in the
  // state until this completes and the CAS below succeeds.
  await verifyVectors({source, candidate, index});
  const receipt = {source_id:source.source_id, run_id:runId, fingerprint,
    action:'restore', original_revision:candidate.original.revision,
    snapshot_sha256:candidate.snapshot_sha256, at:now, revision:revision+1};
  const next = {...state, revision:revision+1, denied:false, stale:false, manifests:prepared,
    restore:receipt, receipt, previous_manifests:state.manifests || null};
  const restoreCas = repository.compareAndSetRestore || repository.compareAndSet;
  if (!await restoreCas.call(repository, source.source_id, revision, next)) fail('source_changed_during_restore');
  return receipt;
}

export async function withdrawSource({sourceId, repository, reason, runId, now = new Date().toISOString()}) {
  if (!['access_changed', 'source_deleted', 'owner_withdrawn', 'access_unverified'].includes(reason)) fail('withdrawal_reason_required');
  if (typeof runId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(runId)) fail('stable_run_id_required');
  const fingerprint = sha256(JSON.stringify({sourceId, reason, action:'withdraw'}));
  const prior = await repository.readReceipt(sourceId,runId);
  if (prior) {
    if (prior.fingerprint !== fingerprint) fail('run_id_reused');
    return prior;
  }
  const state = await repository.read(sourceId);
  const revision = state?.revision || 0;
  const receipt = {source_id:sourceId, reason, run_id:runId, fingerprint, at:now, revision:revision+1};
  const next = {...state, revision: revision + 1, denied: true,
    withdrawal: receipt, receipt};
  if (!await repository.compareAndSet(sourceId, revision, next)) fail('source_changed_during_withdrawal');
  // Denial is durable before any caller may remove vectors. Republishing can
  // never clear this flag; restoration needs an explicit separate authority.
  return next.withdrawal;
}

export async function markSourceStale({sourceId, repository, runId, now=new Date().toISOString()}) {
  if (typeof runId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(runId)) fail('stable_run_id_required');
  const fingerprint=sha256(JSON.stringify({sourceId,action:'stale'}));
  const prior=await repository.readReceipt(sourceId,runId);
  if(prior){if(prior.fingerprint!==fingerprint)fail('run_id_reused');return prior;}
  const state=await repository.read(sourceId);
  const revision=state?.revision||0;
  const receipt={source_id:sourceId,run_id:runId,fingerprint,revision:revision+1,at:now};
  if(!await repository.compareAndSet(sourceId,revision,{...state,revision:revision+1,stale:true,receipt}))fail('source_changed_during_failure');
  return receipt;
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/source-publication-store.mjs

SHA-256: `7a491e2c93dbdbfeebe742b70c12b2c98ad4979c84511b034a4f011cae17ada5`. Canonical mtime: 2026-09-14T11:36:44.889245+00:00. State: SOURCE_ONLY.

```javascript
// SQLite adapter for the existing StateEntity Durable Object, with durable
// request receipts and an atomic generation check after asynchronous indexing.
export function sourcePublicationRepository(storage) {
  storage.sql.exec(`CREATE TABLE IF NOT EXISTS source_publications (
    source_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, body TEXT NOT NULL
  ); CREATE TABLE IF NOT EXISTS source_publication_receipts (
    source_id TEXT NOT NULL, run_id TEXT NOT NULL, body TEXT NOT NULL,
    PRIMARY KEY(source_id, run_id)
  );`);
  const read = sourceId => {
    const row = storage.sql.exec('SELECT body FROM source_publications WHERE source_id=?',sourceId).toArray()[0];
    return row ? JSON.parse(row.body) : null;
  };
  const readReceipt = (sourceId,runId) => {
    const row = storage.sql.exec('SELECT body FROM source_publication_receipts WHERE source_id=? AND run_id=?',sourceId,runId).toArray()[0];
    return row ? JSON.parse(row.body) : null;
  };
  const cas = (sourceId,revision,next,allowRestore=false) => {
    return storage.transactionSync(()=>{
      const current = read(sourceId);
      if ((current?.revision || 0)!==revision || next.revision!==revision+1
          || (current?.denied && !next.denied && (!allowRestore || next.restore?.action !== 'restore'))) return false;
      if (next.receipt) {
        const prior=readReceipt(sourceId,next.receipt.run_id);
        if (prior && prior.fingerprint!==next.receipt.fingerprint) return false;
      }
      storage.sql.exec('INSERT INTO source_publications(source_id,revision,body) VALUES(?,?,?) ON CONFLICT(source_id) DO UPDATE SET revision=excluded.revision,body=excluded.body',sourceId,next.revision,JSON.stringify(next));
      if (next.receipt) storage.sql.exec('INSERT OR IGNORE INTO source_publication_receipts(source_id,run_id,body) VALUES(?,?,?)',sourceId,next.receipt.run_id,JSON.stringify(next.receipt));
      return true;
    });
  };
  return {read, readReceipt, compareAndSet:(sourceId,revision,next)=>cas(sourceId,revision,next,false),
    compareAndSetRestore:(sourceId,revision,next)=>cas(sourceId,revision,next,true)};
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/source-maintenance-policy.mjs

SHA-256: `1d88693c5e2aa0b3b15a333f42db9790e793bf079d44404437da67b5e902b153`. Canonical mtime: 2026-09-14T11:36:44.889515+00:00. State: SOURCE_ONLY.

```javascript
export class SourceMaintenanceError extends Error {
  constructor(message) { super(message); this.status=403; }
}
function authorize(claims, input, registry, bindings, grants) {
  const binding=bindings?.[claims.client_id];
  const source=registry.sources.find(s=>s.source_id===input.source_id);
  if (!binding || binding.agent_id!==claims.agent_id || !Array.isArray(binding.grants)
      || JSON.stringify(binding.grants)!==JSON.stringify(claims.grants)
      || JSON.stringify(claims.grants)!==JSON.stringify(grants)
      || !Array.isArray(binding.source_ids) || !binding.source_ids.includes(input.source_id)
      || !source || !Array.isArray(binding.customers) || !binding.customers.includes(source.customer)
      || (registry.drive_scope?.[claims.agent_id] && source.drive_id!==registry.drive_scope[claims.agent_id])
      || input.customer!==source.customer) throw new SourceMaintenanceError('Source maintenance identity or scope denied');
  return source;
}
export function authorizeSourceMaintenance(claims, input, registry, bindings) {
  return authorize(claims, input, registry, bindings, ['query']);
}

// Restoration is a separate capability. The source-specific grant is held in
// the server-side binding; a claim alone can never create it. Existing query
// bindings therefore remain unable to clear a withdrawal by default.
export function authorizeSourceRestore(claims, input, registry, bindings, now = new Date()) {
  // Restore uses the same query-only identity token as the existing source
  // routes. The additional capability is granted only by server-side policy.
  const source = authorize(claims, input, registry, bindings, ['query']);
  const grant = bindings?.[claims.client_id]?.source_restore_grants?.[input.source_id];
  const expected = input.expected_withdrawal;
  const expires = Date.parse(grant?.expires_at || '');
  if (!grant || typeof grant !== 'object' || !expected || grant.withdrawal_run_id !== expected.run_id
      || grant.withdrawal_revision !== expected.revision || !Number.isFinite(expires)
      || expires <= new Date(now).getTime()) throw new SourceMaintenanceError('Source restoration grant denied');
  return source;
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/ea/rag/approved-notes.mjs

SHA-256: `9c56f90078e24ee62d0b2ee4287f5ed5d4ff48e41e66526c8c718a9b0b83d175`. Canonical mtime: 2026-09-19T01:56:46.419278+00:00. State: SOURCE_ONLY.

```javascript
// Owner-approved supplemental knowledge; canonical source documents remain authoritative.
export function notes(storage, body) {
  const sql=storage.sql;
  sql.exec('CREATE TABLE IF NOT EXISTS approved_notes (id TEXT PRIMARY KEY, revision INTEGER NOT NULL, payload TEXT NOT NULL)');
  sql.exec('CREATE TABLE IF NOT EXISTS note_receipts (id TEXT PRIMARY KEY, payload TEXT NOT NULL)');
  sql.exec("CREATE INDEX IF NOT EXISTS note_receipt_versions ON note_receipts (json_extract(payload,'$.after.note_id'),json_extract(payload,'$.after.customer'),json_extract(payload,'$.after.revision') DESC)");
  const read=id=>{const row=sql.exec('SELECT payload FROM approved_notes WHERE id=?',id).toArray()[0];return row?JSON.parse(row.payload):null;};
  if(body.action==='list')return {ok:true,notes:sql.exec('SELECT payload FROM approved_notes').toArray().map(r=>JSON.parse(r.payload)).map(({vector,...n})=>n)};
  if(!/^[a-z0-9][a-z0-9_-]{0,79}$/.test(body.note_id||''))return {error:'Invalid note ID',status:400};
  const receiptScope="json_extract(payload,'$.after.note_id')=? AND json_extract(payload,'$.after.customer')=?";
  if(body.action==='history'){
    const limit=body.limit===undefined?20:body.limit;
    const before=body.before_revision===undefined?Number.MAX_SAFE_INTEGER:body.before_revision;
    if(!Number.isSafeInteger(limit)||limit<1||limit>50||!Number.isSafeInteger(before)||before<1)return {error:'Invalid history bounds',status:400};
    const rows=sql.exec("SELECT json_remove(json_extract(payload,'$.after'),'$.vector','$.text') AS payload FROM note_receipts WHERE "+receiptScope+" AND json_extract(payload,'$.after.revision')<? ORDER BY json_extract(payload,'$.after.revision') DESC LIMIT ?",body.note_id,body.customer,before,limit+1).toArray();
    const versions=rows.slice(0,limit).map(r=>JSON.parse(r.payload));
    return {ok:true,versions,next_before_revision:rows.length>limit?versions.at(-1).revision:null};
  }
  if(body.action==='read'){
    if(body.revision===undefined)return {ok:true,note:read(body.note_id)};
    if(!Number.isSafeInteger(body.revision)||body.revision<1)return {error:'Invalid revision',status:400};
    const row=sql.exec("SELECT json_remove(json_extract(payload,'$.after'),'$.vector') AS payload FROM note_receipts WHERE "+receiptScope+" AND json_extract(payload,'$.after.revision')=? LIMIT 1",body.note_id,body.customer,body.revision).toArray()[0];
    if(!row)return {ok:true,note:null};
    return {ok:true,note:JSON.parse(row.payload)};
  }
  if(body.action!=='apply' || !/^[0-9a-f]{32}$/.test(body.approval_id||'')
    || !Number.isInteger(body.expected_revision) || body.expected_revision<0
    || typeof body.title!=='string' || !body.title.trim() || body.title.length>120
    || typeof body.text!=='string' || body.text.length>1800
    || !Array.isArray(body.vector) || body.vector.length!==384 || !body.vector.every(Number.isFinite))return {error:'Invalid approved change',status:400};
  return storage.transactionSync(()=>{
    const oldReceipt=sql.exec('SELECT payload FROM note_receipts WHERE id=?',body.approval_id).toArray()[0];
    if(oldReceipt)return {error:'Approval already used; read current note',status:409};
    const before=read(body.note_id);
    if((before?.revision||0)!==body.expected_revision)return {error:'Note changed; request a new approval',status:409};
    if(!before && sql.exec('SELECT payload FROM approved_notes').toArray().length>=1000)return {error:'Note capacity reached',status:409};
    const note={note_id:body.note_id,customer:body.customer,title:body.title,text:body.text,vector:body.vector,
      revision:body.expected_revision+1,approval_id:body.approval_id,as_of:new Date().toISOString(),deleted:body.text===''};
    sql.exec('INSERT OR REPLACE INTO approved_notes VALUES (?,?,?)',body.note_id,note.revision,JSON.stringify(note));
    sql.exec('INSERT INTO note_receipts VALUES (?,?)',body.approval_id,JSON.stringify({before,after:note}));
    return {ok:true,note};
  });
}
export function searchNotes(storage, body) {
  storage.sql.exec('CREATE TABLE IF NOT EXISTS approved_notes (id TEXT PRIMARY KEY, revision INTEGER NOT NULL, payload TEXT NOT NULL)');
  const cosine=(a,b)=>{let dot=0,aa=0,bb=0;for(let i=0;i<a.length;i++){dot+=a[i]*b[i];aa+=a[i]*a[i];bb+=b[i]*b[i];}return aa&&bb?dot/Math.sqrt(aa*bb):0;};
  return storage.sql.exec('SELECT payload FROM approved_notes').toArray().map(r=>JSON.parse(r.payload))
    .filter(n=>!n.deleted&&n.customer===body.customer).map(n=>({id:'approved-note:'+n.note_id,score:cosine(body.vector,n.vector),
      text:n.text,source_file:n.title,source_url:'https://dev-rag.increaseroas.ai/knowledge/notes#'+encodeURIComponent(n.note_id),
      as_of:n.as_of,revision:n.revision,approval_id:n.approval_id,transformation:'owner_approved_note'})).sort((a,b)=>b.score-a.score).slice(0,body.topK||4);
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/javar_isolation/ghl_adapter.py

SHA-256: `d886faf9a3f7ba2c759ba3a7a784010c47501860aa40ad9a91c2546a96b4eb92`. Canonical mtime: 2026-09-23T03:36:20.961731+00:00. State: SOURCE_ONLY.

```python
"""Small adapter for the existing Increase ROAS GHL gateway.

The adapter deliberately owns no credential.  Gateway bootstrap supplies a
resolver, which returns the existing key only for the lifetime of the call.
It is intentionally mechanical: validate the task's pinned company/location,
make one GET or write, and return a bounded result (including an observed 401).
"""
from __future__ import annotations

import json
import re
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
import threading
from types import MappingProxyType
from collections.abc import Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

from .providers import ProviderDenied

GHL_GATEWAY = "https://increase-roas-oauth-gateway.increase-roas.workers.dev"
GHL_COMPANY = "uVK13CFqZs9TOBENvXSH"
GHL_LOCATION = "AG47jEV5rVUrGLt5FlKO"
GHL_USER_AGENT = "Javar-Capability-Check/1.0"
GHL_READ_PREFIXES = ("/contacts", "/calendars", "/users", "/custom-fields", "/opportunities", "/invoices")
GHL_WRITE_PREFIXES = (
    "/contacts", "/calendars", "/custom-fields", "/opportunities", "/conversations",
    "/workflows", "/campaigns", "/forms", "/businesses", "/locations/customFields",
    "/locations/customValues", "/invoices",
)
GHL_DENIED_PREFIXES = ("/payments", "/oauth", "/saas", "/ad-publishing", "/snapshots")
GHL_READ_DENIED_PREFIXES = ("/oauth",)
GHL_WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


def owner_consent(details):
    from tools.approval_prompt import request_elicitation_consent
    return request_elicitation_consent(
        'Approve this exact GHL change?', details,
        timeout_seconds=120, surface='ghl-change') == 'accept'


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProviderDenied("GHL redirect rejected")


class GHLReadAdapter:
    """Callable provider route registered in the gateway broker."""

    operations = MappingProxyType({
        "GHL_GET_INSTALLED_LOCATIONS": frozenset({"company_id"}),
        "GHL_GET_LOCATION_READONLY": frozenset({"company_id", "location_id", "path"}),
        "GHL_WRITE_LOCATION": frozenset({"company_id", "location_id", "path", "method", "body"}),
    })

    def __init__(self, credential_resolver, *, opener=None, timeout=30,
                 company_id=GHL_COMPANY, location_id=GHL_LOCATION,
                 credential_revision=None, auth_state_path=None, approve=owner_consent):
        if not callable(credential_resolver):
            raise TypeError("GHL credential resolver is required")
        self.credential_resolver = credential_resolver
        self.approve = approve
        self.opener = opener or build_opener(ProxyHandler({}), _NoRedirect())
        self.timeout = timeout
        self.company_id = company_id
        self.location_id = location_id
        self.credential_revision = credential_revision
        self.auth_state_path = Path(auth_state_path) if auth_state_path else None
        self._auth_lock = threading.RLock()
        self._auth_latch = self._load_latch()

    def describe(self, scope):
        # Schema discovery is neutral and must not resolve a credential or
        # require a customer binding. Actual calls still enforce the scope.
        if scope is None or getattr(scope, 'customer', None) == 'neutral' or self._scope_allows(scope):
            return [{"tool": name, "allowed_fields": sorted(fields),
                     "write": name == "GHL_WRITE_LOCATION"}
                    for name, fields in self.operations.items()]
        return []

    def _authorized_locations(self, scope):
        resources = getattr(scope, "provider_resources", {}).get("ghl", {})
        if not isinstance(resources, Mapping):
            return None
        if (getattr(scope, "customer", None) == "increase_roas" and
                getattr(scope, "provider_resources", {}).get("_access_profile") == "manny_business"):
            # Alex granted Manny account discovery and routine connected-tool
            # use inside his separate Increase ROAS lane. Adapter-level write,
            # send, spend, publish and provider approval guards still apply.
            return "*"
        locs = resources.get(self.company_id)
        if locs == "*" or (isinstance(locs, (list, tuple)) and tuple(locs) == ("*",)):
            return "*"
        if isinstance(locs, (list, tuple)) and locs:
            return list(locs)
        return None

    def _scope_allows(self, scope):
        # Company-wide agency grant is "*". Do not enumerate locations here.
        return self._authorized_locations(scope) is not None

    def _load_latch(self):
        if not self.auth_state_path or not self.auth_state_path.exists():
            return {}
        try:
            value = json.loads(self.auth_state_path.read_text())
            return value if isinstance(value, dict) else {"__invalid__": True}
        except (OSError, ValueError, TypeError):
            # A corrupt status file cannot prove that an unchanged 401 is
            # safe to retry. Fail closed until an operator resets it.
            return {"__invalid__": True}

    def _revision(self, scope):
        if self.credential_revision is None:
            return "current"
        value = self.credential_revision(scope)
        return value if isinstance(value, str) and value else "current"

    def _latch_key(self, scope, location_id=None):
        return f"{scope.customer}:{self.company_id}:{location_id or '*'}"

    def _save_latch(self):
        if not self.auth_state_path:
            return
        self.auth_state_path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".ghl-auth-", dir=self.auth_state_path.parent)
        try:
            with os.fdopen(fd, "w") as stream:
                stream.write(json.dumps(self._auth_latch, sort_keys=True))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.auth_state_path)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    @contextmanager
    def _auth_guard(self):
        if not self.auth_state_path:
            with self._auth_lock:
                yield
            return
        import fcntl
        self.auth_state_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = self.auth_state_path.with_name(self.auth_state_path.name + ".lock")
        with lock_path.open("a+") as state_lock:
            fcntl.flock(state_lock.fileno(), fcntl.LOCK_EX)
            try:
                try:
                    raw = self.auth_state_path.read_text() if self.auth_state_path.exists() else ""
                    value = json.loads(raw) if raw.strip() else {}
                    self._auth_latch = value if isinstance(value, dict) else {"__invalid__": True}
                except (ValueError, TypeError):
                    self._auth_latch = {"__invalid__": True}
                yield
            finally:
                fcntl.flock(state_lock.fileno(), fcntl.LOCK_UN)

    def reset_auth_latch(self, *, scope=None):
        """Explicit operator reset; never invoked by a task or retry path."""
        with self._auth_guard():
            # Reload latest state under the same cross-process lock before
            # removing a latch written by another gateway worker.
            if self.auth_state_path:
                self._auth_latch = self._load_latch()
            if scope is None:
                self._auth_latch.clear()
            else:
                self._auth_latch.pop(self._latch_key(scope), None)
            self._save_latch()

    def _location_bound(self, tool):
        return tool in {"GHL_GET_LOCATION_READONLY", "GHL_WRITE_LOCATION"}

    @staticmethod
    def _path_valid(path):
        return isinstance(path, str) and path.startswith("/") and not path.startswith("//")

    @staticmethod
    def _path_denied(path):
        return isinstance(path, str) and any(
            path == prefix or path.startswith(prefix + "/") for prefix in GHL_DENIED_PREFIXES
        )

    @classmethod
    def _read_path_denied(cls, path):
        return not cls._path_valid(path) or any(
            path == prefix or path.startswith(prefix + "/") for prefix in GHL_READ_DENIED_PREFIXES
        )

    @classmethod
    def _write_path_denied(cls, path):
        if not cls._path_valid(path) or cls._path_denied(path):
            return True
        if path == "/users" or path.startswith("/users/"):
            return True
        if path == "/locations" or path.startswith("/locations/"):
            return not (
                path == "/locations/customFields" or path.startswith("/locations/customFields/") or
                path == "/locations/customValues" or path.startswith("/locations/customValues/")
            )
        return False

    def __call__(self, scope, request):
        if not isinstance(request, dict) or set(request) != {"tool", "arguments"}:
            raise ProviderDenied("invalid provider request")
        if not self._scope_allows(scope):
            raise ProviderDenied("GHL company or location is outside this task")
        tool, args = request["tool"], request["arguments"]
        allowed = self.operations.get(tool)
        if allowed is None or not isinstance(args, dict) or set(args) != allowed:
            raise ProviderDenied("GHL operation arguments are not approved")
        if args["company_id"] != self.company_id:
            raise ProviderDenied("GHL company is outside this task")
        allowed = self._authorized_locations(scope)
        location_id = args.get("location_id")
        if self._location_bound(tool):
            if not isinstance(location_id, str) or not re.fullmatch(r"[A-Za-z0-9]{10,32}", location_id):
                raise ProviderDenied("GHL location is outside this task")
            if allowed != "*" and location_id not in allowed:
                raise ProviderDenied("GHL location is outside this task")
        revision = self._revision(scope)
        key = self._latch_key(scope, location_id if self._location_bound(tool) else "*")
        with self._auth_guard():
            if self._auth_latch.get("__invalid__"):
                return {"ok": False, "status": None,
                        "error": "GHL auth status is unreadable; explicit operator reset required"}
            credential = self.credential_resolver(scope)
            if not isinstance(credential, str) or not credential:
                return {"ok": False, "status": None,
                        "error": "GHL credential unavailable in gateway runtime"}
            headers = {
                "Authorization": f"Bearer {credential}",
                "User-Agent": GHL_USER_AGENT,
                "Accept": "application/json",
            }
            data = None
            method = "GET"
            if tool == "GHL_GET_INSTALLED_LOCATIONS":
                url = f"{GHL_GATEWAY}/api/installed-locations?companyId={quote(self.company_id, safe='')}"
            elif tool == "GHL_WRITE_LOCATION":
                if location_id == "WxuBulIfDE7f5hjQjM65" and str(args.get("path", "")).split("?")[0].rstrip("/") == "/conversations/messages":
                    raise ProviderDenied("Safety Switch required: reply to the original Telegram customer alert, review the verified recipient and exact text, then tap Send. A model-selected recipient cannot send through this route.")
                path = args["path"]
                write_method = str(args["method"] or "").upper()
                body = args["body"]
                if write_method not in GHL_WRITE_METHODS:
                    raise ProviderDenied("GHL write method is not approved")
                if self._write_path_denied(path):
                    raise ProviderDenied("GHL path is denied or invalid for write access")
                if not isinstance(body, dict) or isinstance(body, list):
                    raise ProviderDenied("GHL write body is not approved")
                encoded = json.dumps({
                    "companyId": self.company_id,
                    "method": write_method,
                    "path": path,
                    "body": body,
                }).encode("utf-8")
                if len(encoded) > 32_768:
                    raise ProviderDenied("GHL write body exceeds bounded capture")
                # Preview exactly the same immutable bytes that will be sent.
                details = json.dumps({'company_id': self.company_id,
                    'location_id': location_id, 'method': write_method,
                    'path': path, 'body': json.loads(encoded)['body']})
                if not self.approve(details):
                    raise ProviderDenied('GHL change was not approved by Alex; nothing submitted')
                url = f"{GHL_GATEWAY}/api/location/{quote(location_id, safe='')}/write"
                headers["Content-Type"] = "application/json"
                data = encoded
                method = "POST"
            else:
                path = args["path"]
                if self._read_path_denied(path):
                    raise ProviderDenied("GHL path is denied or invalid for read-only access")
                url = (f"{GHL_GATEWAY}/api/location/{quote(location_id, safe='')}"
                       f"/readonly?companyId={quote(self.company_id, safe='')}&path={quote(path, safe='')}")
            request = Request(url, data=data, headers=headers, method=method)
            try:
                with self.opener.open(request, timeout=self.timeout) as response:
                    status = int(response.status)
                    body = response.read(1024 * 1024 + 1)
            except HTTPError as error:
                if error.code == 401:
                    return {"ok": False, "status": 401, "error": "GHL authenticated request returned 401"}
                fail = "GHL write failed" if tool == "GHL_WRITE_LOCATION" else "GHL read failed"
                return {"ok": False, "status": int(error.code), "error": fail}
            except (OSError, URLError, TimeoutError):
                return {"ok": False, "status": None, "error": "GHL gateway unavailable"}
            if len(body) > 1024 * 1024:
                raise ProviderDenied("GHL result exceeds bounded capture")
            try:
                payload = json.loads(body)
            except (TypeError, ValueError):
                payload = body.decode("utf-8", errors="replace")
            if tool == "GHL_GET_INSTALLED_LOCATIONS":
                payload = self._filter_locations(payload)
            else:
                payload = self._scrub_payload(payload)
            return {"ok": status < 400, "status": status, "data": payload}

    def _filter_locations(self, payload):
        """Project installed locations for this company. Do not pin to one sub-account."""
        if isinstance(payload, dict) and isinstance(payload.get("locations"), list):
            rows = payload["locations"]
            return {"locations": [self._project_location(row) for row in rows if isinstance(row, dict)][:2000]}
        if isinstance(payload, list):
            return [self._project_location(row) for row in payload if isinstance(row, dict)][:2000]
        raise ProviderDenied("GHL installed-locations response shape unavailable")

    @staticmethod
    def _project_location(row):
        return {key: row[key] for key in ("id", "locationId", "name", "companyId", "companyName")
                if key in row}

    @classmethod
    def _scrub_payload(cls, value, depth=0):
        if depth > 8:
            return None
        blocked = ("token", "secret", "password", "authorization", "api_key", "access_token", "refresh_token")
        if isinstance(value, dict):
            return {str(k): cls._scrub_payload(v, depth + 1) for k, v in value.items()
                    if not any(part in str(k).casefold() for part in blocked)}
        if isinstance(value, list):
            return [cls._scrub_payload(v, depth + 1) for v in value[:1000]]
        return value


def env_credential_resolver(name="GHL_MCP_INTERNAL_API_KEY"):
    """Build a resolver for a gateway process that already loaded its env."""
    import os
    return lambda scope: os.environ.get(name)

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/ghl-read.mjs

SHA-256: `c8f5ea10559c0b627974309fec83781292f262ea09f5345452e523e7892fa092`. Canonical mtime: 2026-09-13T18:12:43.129427+00:00. State: SOURCE_ONLY.

```javascript
#!/usr/bin/env node

/**
 * Bounded, read-only HighLevel client for CSM customer follow-through.
 *
 * Input (stdin):
 *   {"action":"list_conversations","contact_id":"optional"}
 *   {"action":"read_customer","contact_id":"...","conversation_id":"optional"}
 *
 * The process intentionally has no write method and does not accept arbitrary
 * URLs. Credentials are read from the CSM vault via the approved service-account runtime file. Every call requires location_id.
 */

import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const API_ROOT = 'https://services.leadconnectorhq.com';
const API_VERSION = '2021-07-28';
const SCOPE = JSON.parse(readFileSync(new URL('./ghl-scope.json', import.meta.url), 'utf8'));
const CSM_VAULT = 'cjcp7elruabzwznhvvnvntor4u';
const MAX_INPUT_BYTES = 16 * 1024;

function fail(message) {
  process.stdout.write(JSON.stringify({ error: message }) + '\n');
  process.exitCode = 1;
}

function id(value, name) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,160}$/.test(value)) {
    throw new Error(`${name} has an invalid format`);
  }
  return value;
}

function requiredRuntime(input) {
  const location = id(input.location_id, 'location_id');
  const binding = SCOPE.locations.find(row => row.location_id === location);
  if (!binding || !location) throw new Error('Explicit approved CSM location_id is required');
  const reference = binding.credential_reference;
  if (typeof reference !== 'string' || !reference.startsWith(`op://${CSM_VAULT}/`)) {
    throw new Error('CSM vault binding mismatch');
  }
  if (process.env.HERMES_SECRET_BROKER_SOCKET) {
    const aliases = {
      'op://cjcp7elruabzwznhvvnvntor4u/alqbsbf7zkzwlyspckqrpdkhfe/api_key': 'CSM_GHL_HTL_SUCCESS_TOKEN',
      'op://cjcp7elruabzwznhvvnvntor4u/7afthaofqrsajegwuusrf5scc4/api_key': 'CSM_GHL_IR_SUCCESS_TOKEN',
    };
    const alias = aliases[reference];
    if (!alias) throw new Error('CSM GHL broker binding mismatch');
    try {
      const token = execFileSync('python3', ['-c',
        "import os,sys;from broker_client import request;sys.stdout.write(request(os.environ['HERMES_SECRET_BROKER_SOCKET'],'static',sys.argv[1])['value'])", alias],
        {encoding:'utf8', timeout:40000, stdio:['ignore','pipe','pipe']}).trim();
      if (!token) throw new Error('empty');
      return {token, location};
    } catch { throw new Error('CSM GHL broker unavailable'); }
  }
  const line = readFileSync('/home/csm/.hermes/.op.env', 'utf8').split('\n')
    .find(value => value.startsWith('OP_SERVICE_ACCOUNT_TOKEN='));
  if (!line) throw new Error('CSM vault access unavailable');
  const serviceToken = line.slice('OP_SERVICE_ACCOUNT_TOKEN='.length).trim();
  let token;
  try {
    token = execFileSync('op', ['read', reference], {
      env: {...process.env, OP_SERVICE_ACCOUNT_TOKEN: serviceToken},
      encoding: 'utf8', timeout: 20000, stdio: ['ignore', 'pipe', 'pipe'],
    }).trim();
  } catch { throw new Error('CSM GHL credential unavailable'); }
  if (!token) throw new Error('CSM GHL credential is empty');
  return { token, location };
}

async function getJson(path, runtime) {
  // Every path is assembled below from fixed endpoints and validated IDs.
  const response = await fetch(`${API_ROOT}${path}`, {
    method: 'GET',
    signal: AbortSignal.timeout(15_000),
    headers: {
      Authorization: `Bearer ${runtime.token}`,
      Version: API_VERSION,
      Accept: 'application/json',
    },
  });
  if (!response.ok) throw new Error(`GHL read failed (${response.status})`);
  try {
    return await response.json();
  } catch {
    throw new Error('GHL returned an invalid response');
  }
}

function sourceLink(contactId, location) {
  return `https://app.gohighlevel.com/v2/location/${location}/contacts/detail/${contactId}`;
}

function locationOf(value) {
  return value?.locationId ?? value?.location_id ?? null;
}

function contactOf(value) {
  return value?.contactId ?? value?.contact_id ?? value?.contact?.id ?? null;
}

function conversationIdOf(value) {
  return value?.id ?? value?.conversationId ?? value?.conversation_id ?? null;
}

function related(value, contactId, location) {
  return Boolean(contactId) && locationOf(value) === location && contactOf(value) === contactId;
}

function publicContact(contact, contactId, location) {
  if (!related({ ...contact, contactId }, contactId, location) || (contact?.id && contact.id !== contactId)) {
    throw new Error('GHL contact relationship is outside the approved scope');
  }
  // Select fields instead of redacting a whole provider object, so email,
  // phone, address and future private fields cannot leak accidentally.
  return {
    id: contact?.id ?? contactId,
    name: contact?.name ?? ([contact?.firstName, contact?.lastName].filter(Boolean).join(' ') || null),
    tags: Array.isArray(contact?.tags) ? contact.tags : [],
    dnd: contact?.dnd ?? null,
    source: sourceLink(contactId, location),
    created_at: contact?.dateAdded ?? contact?.createdAt ?? null,
    updated_at: contact?.dateUpdated ?? contact?.updatedAt ?? null,
  };
}

function publicConversation(conversation, contactId, location) {
  if (!related(conversation, contactId, location)) return null;
  return {
    id: conversationIdOf(conversation),
    contact_id: contactId,
    location_id: location,
    status: conversation?.status ?? null,
    last_message_at: conversation?.lastMessageDate ?? conversation?.lastMessageAt ?? null,
    source: sourceLink(contactId, location),
  };
}

function publicMessage(message) {
  return {
    id: message?.id ?? message?.messageId ?? null,
    direction: message?.direction ?? message?.type ?? null,
    timestamp: message?.dateAdded ?? message?.createdAt ?? message?.timestamp ?? null,
    body: message?.body ?? message?.text ?? message?.message ?? null,
  };
}

function assertInputShape(input, allowed) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('input must be a JSON object');
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) throw new Error(`unsupported input field: ${key}`);
  }
}

async function listConversations(input, runtime) {
  assertInputShape(input, new Set(['action', 'location_id', 'contact_id']));
  const contactId = id(input.contact_id, 'contact_id');
  const params = new URLSearchParams({ locationId: runtime.location, limit: '10' });
  if (contactId) params.set('contactId', contactId);
  const data = await getJson(`/conversations/search?${params}`, runtime);
  const rows = Array.isArray(data?.conversations) ? data.conversations :
    Array.isArray(data?.items) ? data.items : [];
  const conversations = rows.map(row => publicConversation(row, contactId ?? contactOf(row), runtime.location)).filter(Boolean);
  return { action: 'list_conversations', location_id: runtime.location, conversations };
}

async function readLead(input, runtime) {
  assertInputShape(input, new Set(['action', 'location_id', 'contact_id', 'conversation_id']));
  const contactId = id(input.contact_id, 'contact_id');
  if (!contactId) throw new Error('contact_id is required');
  const conversationId = id(input.conversation_id, 'conversation_id');
  const contact = await getJson(`/contacts/${contactId}`, runtime);
  const contactPayload = contact?.contact ?? contact;
  const result = { action: 'read_customer', location_id: runtime.location, contact: publicContact(contactPayload, contactId, runtime.location), conversation: null, messages: [] };
  if (!conversationId) return result;

  const searchParams = new URLSearchParams({ locationId: runtime.location, contactId, limit: '100' });
  const search = await getJson(`/conversations/search?${searchParams}`, runtime);
  const matches = Array.isArray(search?.conversations) ? search.conversations :
    Array.isArray(search?.items) ? search.items : [];
  const conversationPayload = matches.find(row => conversationIdOf(row) === conversationId);
  if (!conversationPayload || !related(conversationPayload, contactId, runtime.location)) {
    throw new Error('conversation is not related to the approved contact and location');
  }
  const messageResponse = await getJson(`/conversations/${conversationId}/messages?limit=20`, runtime);
  const messages = Array.isArray(messageResponse?.messages) ? messageResponse.messages :
    Array.isArray(messageResponse?.messages?.messages) ? messageResponse.messages.messages : null;
  if (!messages) throw new Error('GHL returned an invalid messages response');
  for (const message of messages) {
    const messageContact = contactOf(message);
    const messageLocation = locationOf(message);
    const messageConversation = message?.conversationId ?? message?.conversation_id ?? null;
    if ((messageContact && messageContact !== contactId) ||
        (messageLocation && messageLocation !== runtime.location) ||
        (messageConversation && messageConversation !== conversationId)) {
      throw new Error('GHL message relationship is outside the approved scope');
    }
  }
  result.conversation = publicConversation(conversationPayload, contactId, runtime.location);
  result.messages = messages.map(publicMessage);
  return result;
}

async function main() {
  try {
    const raw = await new Promise(resolve => {
      let value = '';
      process.stdin.setEncoding('utf8');
      process.stdin.on('data', chunk => { value += chunk; });
      process.stdin.on('end', () => resolve(value));
    });
    if (Buffer.byteLength(raw, 'utf8') > MAX_INPUT_BYTES) throw new Error('input is too large');
    const input = JSON.parse(raw || '{}');
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('input must be a JSON object');
    const runtime = requiredRuntime(input);
    if (input.action === 'list_conversations') {
      process.stdout.write(JSON.stringify(await listConversations(input, runtime)) + '\n');
    } else if (input.action === 'read_customer') {
      process.stdout.write(JSON.stringify(await readLead(input, runtime)) + '\n');
    } else {
      throw new Error('unsupported action; use list_conversations or read_customer');
    }
  } catch (error) {
    fail(error instanceof Error ? error.message : 'GHL read failed');
  }
}

main();

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/csm/ghl-scope.example.json

SHA-256: `d0bf3fde77b41c46bf4d3caf22d58a5136981a56fee79d8993a31163ff018890`. Canonical mtime: 2026-09-14T18:54:42.583264+00:00. State: SOURCE_ONLY.

```json
{
  "role_id": "csm",
  "status": "EXAMPLE_NOT_LIVE",
  "verified_on": "2026-09-09",
  "company_id": "EXAMPLE_COMPANY_ID",
  "locations": [
    {
      "location_id": "EXAMPLE_LOCATION_ID",
      "name": "Hot Tub Launch Success ",
      "timezone": "America/Los_Angeles",
      "credential_reference": "op://EXAMPLE_VAULT/EXAMPLE_ITEM/api_key"
    },
    {
      "location_id": "EXAMPLE_LOCATION_ID",
      "name": "INCREASE ROAS Customer Sucess",
      "timezone": "US/Eastern",
      "credential_reference": "op://EXAMPLE_VAULT/EXAMPLE_ITEM/api_key"
    }
  ],
  "requirements": [
    "Require explicit location_id on each provider operation; never use a mutable shared default.",
    "Verify each contact, conversation and opportunity belongs to the selected location.",
    "A success subaccount can contain multiple customers; location scope alone does not prove customer isolation.",
    "Preserve source location, record IDs and customer identity on every task and handoff.",
    "Use record-supported deadlines and timezones; do not assume both accounts share Alex's timezone.",
    "External messages require exact recipient and content approval."
  ],
  "evidence": {
    "method": "GHL registry then per-location credential switch and GET location",
    "runtime_access_proven": true,
    "runtime_read": "CSM-owned adapter list_conversations succeeded for both explicit location IDs, 4 and 10 returned respectively; 2026-09-09"
  }
}

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/setter/ghl-read.mjs

SHA-256: `7b68f71ef05f73b3072c89eef02a307202f2353a107a27a5c397cc3b084574e3`. Canonical mtime: 2026-09-09T19:09:45.141255+00:00. State: SOURCE_ONLY.

```javascript
#!/usr/bin/env node

/**
 * Bounded, read-only HighLevel client for Setter lead triage.
 *
 * Input (stdin):
 *   {"action":"list_conversations","contact_id":"optional"}
 *   {"action":"read_lead","contact_id":"...","conversation_id":"optional"}
 *
 * The process intentionally has no write method and does not accept arbitrary
 * URLs. Credentials are read from the owner-approved runtime environment only.
 */

const API_ROOT = 'https://services.leadconnectorhq.com';
const API_VERSION = '2021-07-28';
const APPROVED_LOCATION = 'AG47jEV5rVUrGLt5FlKO';
const MAX_INPUT_BYTES = 16 * 1024;

function fail(message) {
  process.stdout.write(JSON.stringify({ error: message }) + '\n');
  process.exitCode = 1;
}

function id(value, name) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,160}$/.test(value)) {
    throw new Error(`${name} has an invalid format`);
  }
  return value;
}

function requiredRuntime() {
  const token = process.env.GHL_PIT;
  const location = process.env.GHL_LOCATION_ID;
  if (!token || !location) throw new Error('GHL runtime binding is incomplete');
  if (location !== APPROVED_LOCATION) throw new Error('GHL location is outside the approved Setter scope');
  return { token, location };
}

async function getJson(path, runtime) {
  // Every path is assembled below from fixed endpoints and validated IDs.
  const response = await fetch(`${API_ROOT}${path}`, {
    method: 'GET',
    signal: AbortSignal.timeout(15_000),
    headers: {
      Authorization: `Bearer ${runtime.token}`,
      Version: API_VERSION,
      Accept: 'application/json',
    },
  });
  if (!response.ok) throw new Error(`GHL read failed (${response.status})`);
  try {
    return await response.json();
  } catch {
    throw new Error('GHL returned an invalid response');
  }
}

function sourceLink(contactId, location) {
  return `https://app.gohighlevel.com/v2/location/${location}/contacts/detail/${contactId}`;
}

function locationOf(value) {
  return value?.locationId ?? value?.location_id ?? null;
}

function contactOf(value) {
  return value?.contactId ?? value?.contact_id ?? value?.contact?.id ?? null;
}

function conversationIdOf(value) {
  return value?.id ?? value?.conversationId ?? value?.conversation_id ?? null;
}

function related(value, contactId, location) {
  return Boolean(contactId) && locationOf(value) === location && contactOf(value) === contactId;
}

function publicContact(contact, contactId, location) {
  if (!related({ ...contact, contactId }, contactId, location) || (contact?.id && contact.id !== contactId)) {
    throw new Error('GHL contact relationship is outside the approved scope');
  }
  // Select fields instead of redacting a whole provider object, so email,
  // phone, address and future private fields cannot leak accidentally.
  return {
    id: contact?.id ?? contactId,
    name: contact?.name ?? ([contact?.firstName, contact?.lastName].filter(Boolean).join(' ') || null),
    tags: Array.isArray(contact?.tags) ? contact.tags : [],
    dnd: contact?.dnd ?? null,
    source: sourceLink(contactId, location),
    created_at: contact?.dateAdded ?? contact?.createdAt ?? null,
    updated_at: contact?.dateUpdated ?? contact?.updatedAt ?? null,
  };
}

function publicConversation(conversation, contactId, location) {
  if (!related(conversation, contactId, location)) return null;
  return {
    id: conversationIdOf(conversation),
    contact_id: contactId,
    location_id: location,
    status: conversation?.status ?? null,
    last_message_at: conversation?.lastMessageDate ?? conversation?.lastMessageAt ?? null,
    source: sourceLink(contactId, location),
  };
}

function publicMessage(message) {
  return {
    id: message?.id ?? message?.messageId ?? null,
    direction: message?.direction ?? message?.type ?? null,
    timestamp: message?.dateAdded ?? message?.createdAt ?? message?.timestamp ?? null,
    body: message?.body ?? message?.text ?? message?.message ?? null,
  };
}

function assertInputShape(input, allowed) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('input must be a JSON object');
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) throw new Error(`unsupported input field: ${key}`);
  }
}

async function listConversations(input, runtime) {
  assertInputShape(input, new Set(['action', 'contact_id']));
  const contactId = id(input.contact_id, 'contact_id');
  const params = new URLSearchParams({ locationId: runtime.location, limit: '10' });
  if (contactId) params.set('contactId', contactId);
  const data = await getJson(`/conversations/search?${params}`, runtime);
  const rows = Array.isArray(data?.conversations) ? data.conversations :
    Array.isArray(data?.items) ? data.items : [];
  const conversations = rows.map(row => publicConversation(row, contactId ?? contactOf(row), runtime.location)).filter(Boolean);
  return { action: 'list_conversations', location_id: runtime.location, conversations };
}

async function readLead(input, runtime) {
  assertInputShape(input, new Set(['action', 'contact_id', 'conversation_id']));
  const contactId = id(input.contact_id, 'contact_id');
  if (!contactId) throw new Error('contact_id is required');
  const conversationId = id(input.conversation_id, 'conversation_id');
  const contact = await getJson(`/contacts/${contactId}`, runtime);
  const contactPayload = contact?.contact ?? contact;
  const result = { action: 'read_lead', contact: publicContact(contactPayload, contactId, runtime.location), conversation: null, messages: [] };
  if (!conversationId) return result;

  const searchParams = new URLSearchParams({ locationId: runtime.location, contactId, limit: '100' });
  const search = await getJson(`/conversations/search?${searchParams}`, runtime);
  const matches = Array.isArray(search?.conversations) ? search.conversations :
    Array.isArray(search?.items) ? search.items : [];
  const conversationPayload = matches.find(row => conversationIdOf(row) === conversationId);
  if (!conversationPayload || !related(conversationPayload, contactId, runtime.location)) {
    throw new Error('conversation is not related to the approved contact and location');
  }
  const messageResponse = await getJson(`/conversations/${conversationId}/messages?limit=20`, runtime);
  const messages = Array.isArray(messageResponse?.messages) ? messageResponse.messages :
    Array.isArray(messageResponse?.messages?.messages) ? messageResponse.messages.messages : null;
  if (!messages) throw new Error('GHL returned an invalid messages response');
  for (const message of messages) {
    const messageContact = contactOf(message);
    const messageLocation = locationOf(message);
    const messageConversation = message?.conversationId ?? message?.conversation_id ?? null;
    if ((messageContact && messageContact !== contactId) ||
        (messageLocation && messageLocation !== runtime.location) ||
        (messageConversation && messageConversation !== conversationId)) {
      throw new Error('GHL message relationship is outside the approved scope');
    }
  }
  result.conversation = publicConversation(conversationPayload, contactId, runtime.location);
  result.messages = messages.map(publicMessage);
  return result;
}

async function main() {
  try {
    const raw = await new Promise(resolve => {
      let value = '';
      process.stdin.setEncoding('utf8');
      process.stdin.on('data', chunk => { value += chunk; });
      process.stdin.on('end', () => resolve(value));
    });
    if (Buffer.byteLength(raw, 'utf8') > MAX_INPUT_BYTES) throw new Error('input is too large');
    const input = JSON.parse(raw || '{}');
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('input must be a JSON object');
    const runtime = requiredRuntime();
    if (input.action === 'list_conversations') {
      process.stdout.write(JSON.stringify(await listConversations(input, runtime)) + '\n');
    } else if (input.action === 'read_lead') {
      process.stdout.write(JSON.stringify(await readLead(input, runtime)) + '\n');
    } else {
      throw new Error('unsupported action; use list_conversations or read_lead');
    }
  } catch (error) {
    fail(error instanceof Error ? error.message : 'GHL read failed');
  }
}

main();

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/media/read-plugin/ghl_read.py

SHA-256: `35df3074ea04d1102f5fbef722963ae727cd4dfd9ea7844ccbe856a3e5861b30`. Canonical mtime: 2026-09-13T19:25:22.075788+00:00. State: SOURCE_ONLY.

```python
"""Pinned, read-only GHL adapter for one Media customer."""
import json
import os
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path

SCOPE = json.loads((Path(__file__).parent / 'customer-scope.json').read_text())
ROOT = 'https://services.leadconnectorhq.com'
VAULT = SCOPE['credential_refs']['vault_id']
ENV = Path('/home/media/.hermes/.op.env')

def _token():
    ref = SCOPE['credential_refs']['ghl_item']
    if os.environ.get('HERMES_SECRET_BROKER_SOCKET'):
        from broker_media import credential
        return credential(ref)
    if not ref.startswith('op://' + VAULT + '/'):
        raise RuntimeError('GHL credential reference is not bound')
    line = next((x for x in ENV.read_text().splitlines() if x.startswith('OP_SERVICE_ACCOUNT_TOKEN=')), '')
    service = line.split('=', 1)[1].strip() if '=' in line else ''
    if not service: raise RuntimeError('Media vault access unavailable')
    out = subprocess.run(['op', 'read', ref], env={**os.environ, 'OP_SERVICE_ACCOUNT_TOKEN': service}, capture_output=True, text=True, timeout=20)
    if out.returncode or not out.stdout.strip(): raise RuntimeError('GHL credential unavailable')
    return out.stdout.strip()

def _get(path, token):
    req = urllib.request.Request(ROOT + path, headers={'Authorization': 'Bearer ' + token, 'Version': '2021-07-28', 'Accept': 'application/json', 'User-Agent': 'Increase-ROAS-Media/1.0'})
    with urllib.request.urlopen(req, timeout=15) as response: return json.load(response)

def read(args):
    if not isinstance(args, dict) or set(args) - {'action', 'customer'}: raise ValueError('unexpected GHL fields')
    if args.get('customer') != SCOPE['customer']: raise ValueError('customer scope mismatch')
    action = args.get('action'); loc = SCOPE['location_id']; contact = SCOPE['contact_id']; conv = SCOPE['conversation_id']; token = _token()
    if action == 'read_customer':
        payload = _get('/contacts/' + urllib.parse.quote(contact, safe=''), token)
        raw = payload.get('contact', payload)
        if raw.get('id') != contact or raw.get('locationId') not in (None, loc): raise RuntimeError('GHL contact outside approved scope')
        return {'action': action, 'customer': SCOPE['customer'], 'location_id': loc, 'contact_id': contact, 'source': f'https://app.gohighlevel.com/v2/location/{loc}/contacts/detail/{contact}', 'contact': {'id': raw.get('id', contact), 'name': raw.get('name') or ' '.join(x for x in (raw.get('firstName'), raw.get('lastName')) if x) or None, 'tags': raw.get('tags', []), 'dnd': raw.get('dnd'), 'created_at': raw.get('dateAdded') or raw.get('createdAt'), 'updated_at': raw.get('dateUpdated') or raw.get('updatedAt')}}
    if action == 'read_conversation':
        query = urllib.parse.urlencode({'locationId': loc, 'contactId': contact, 'limit': '100'})
        search = _get('/conversations/search?' + query, token)
        rows = search.get('conversations', search.get('items', []))
        def in_scope(row):
            return ((row.get('locationId') in (None, loc)) and
                    (row.get('contactId') in (None, contact)) and
                    (row.get('id') == conv or row.get('conversationId') == conv))
        match = next((x for x in rows if in_scope(x)), None)
        if not match: raise RuntimeError('pinned conversation not found in approved scope')
        messages = _get('/conversations/' + urllib.parse.quote(conv, safe='') + '/messages?limit=20', token)
        rows = messages.get('messages', {}).get('messages', []) if isinstance(messages.get('messages'), dict) else messages.get('messages', messages)
        for message in rows:
            if not isinstance(message, dict): raise RuntimeError('invalid GHL message')
            if message.get('locationId') not in (None, loc) or message.get('contactId') not in (None, contact) or message.get('conversationId') not in (None, conv):
                raise RuntimeError('GHL message relationship is outside approved scope')
        safe = [{'id': m.get('id') or m.get('messageId'), 'direction': m.get('direction') or m.get('type'), 'timestamp': m.get('dateAdded') or m.get('createdAt') or m.get('timestamp'), 'body': m.get('body') or m.get('text') or m.get('message')} for m in rows] if isinstance(rows, list) else []
        return {'action': action, 'customer': SCOPE['customer'], 'location_id': loc, 'contact_id': contact, 'conversation_id': conv, 'conversation': {'id': match.get('id') or conv, 'status': match.get('status'), 'last_message_at': match.get('lastMessageDate') or match.get('lastMessageAt')}, 'messages': safe}
    raise ValueError('unsupported GHL action')

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/tools/ghl-command-cloud/README.md

SHA-256: `57901b9f749f36818ffa5787d1e1576bf538feb41058ca82d1aad7ae7c8c3799`. Canonical mtime: 2026-09-24T00:42:44.443039+00:00. State: SOURCE_ONLY.

```text
# Shared GHL Command cloud connection

Javar and Javante use the same protected GHL Command installation on Javar's EA Orgo computer `d9b475e2-47b2-46d4-b8eb-102564f93283`, with 48 registered subaccounts. The connection forwards the **full installed vendor catalog: 330 tools** at current acceptance. This includes workflow publishing and deletion, contacts, opportunities, calendars, funnels and other GHL operations. Discover the needed tools on demand rather than loading the whole catalog into a prompt.

The earlier eleven-tool subset and added draft-only transport restriction were incorrect limitations introduced during setup. They are superseded. Existing owner approvals, customer-message safeguards and provider permissions still govern each action; exposing a tool does not itself authorize publishing, sending, spending or deletion.

## Hosting and authentication

The root bridge reads the existing root-owned mode-0600 `credentials.json` and `.ghl-tokens.json`, then launches the unchanged vendor package. The 48-account registry and vendor credentials stay on this cloud host. OpenClaw's ChatGPT connector is a separate installation.

- Cloud service: Supervisor `ghl-command-cloud`
- Runtime directory: `/home/orgo/lil-smoove/home/.hermes/mcp-servers/ghl-command-cloud/`
- Supervisor configuration: `/etc/supervisor/conf.d/ghl-command-cloud.conf`
- Javar client: `http://127.0.0.1:18881/mcp`
- Javante client: `http://100.84.107.10:18881/mcp`, over the existing private Tailscale userspace connection

Each existing gateway bootstrap derives `GHL_COMMAND_REMOTE_TOKEN` in memory from its existing GHL company key with context `javante-ghl-command-cloud-v1`. Configurations contain an environment reference, never the token value. Javar's default protected-profile allowlist must preserve this variable; removing it causes unauthorized MCP access despite a correct endpoint and loader. Vendor children receive only the environment required for their GHL work.

## Acceptance and recovery

Current full-catalog acceptance is recorded in `../../receipts/shared-ghl-full-catalog-20260923.md`. The earlier `shared-ghl-command-access-20260923.md` receipt documents the superseded eleven-tool checkpoint. Current acceptance compares both native Hermes tool catalogs to the installed vendor catalog, verifies the same 48 account IDs, and reads a complete existing workflow. Publishing and other write schemas are inspected without invoking writes.

Use the newest receipt's backups. Restore only affected bridge/client files, preserving the existing credential files, secret bootstrap, Javar profile allowlist, and Javante's outer GUI `osascript` LaunchAgent. Restart only the affected existing service and verify the full catalog, the selected account, one existing workflow and the normal messaging platforms. Restoring the superseded eleven-tool bridge does not restore the requested capability.

The existing Supervisor and normal gateway health procedures remain responsible for recovery. No new scheduled monitor was added. Source shipping remains separate from live operation; the existing Git metadata denial prevents creating a PR from this workspace.

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/receipts/shared-ghl-full-catalog-20260923.md

SHA-256: `de188e72fb36756f93c886f1a2f234e766076a75475829eb30c1e5bde07b056c`. Canonical mtime: 2026-09-24T00:50:26.068722+00:00. State: SOURCE_ONLY.

```text
# Full GHL Command catalog — accepted September 23, 2026

## Correction and result

Alex requested Javante match Javar's full GHL Command capability. The earlier eleven-tool bridge and added draft-only enforcement were incorrectly introduced during setup. This receipt supersedes that limited checkpoint and its completion claim.

**Javar and Javante now expose the same complete installed vendor catalog: 330 tools, including `publish_workflow`, across the same 48 registered subaccounts.** Existing customer-action approvals still apply. No workflow, contact or other GHL record was changed during verification.

## Observed acceptance

- Direct discovery from the existing protected `@elitedcs/ghl-mcp` 3.84.2 vendor returned 330 tools.
- Sorted tool-name SHA-256: `20ce557cb1479716b59596a459110b3049b0a148f9b35f8b662f3c0184c6374d`.
- Javar's actual native Hermes test through its installed protected loader connected and discovered 330 tools, matching the vendor catalog.
- Javante's actual GUI-bootstrap/native Hermes test exited successfully and discovered the same 330 tools with the same catalog hash. Its temporary acceptance LaunchAgent and outputs were removed afterward.
- Both clients retained 48 registered locations with sorted-ID SHA-256 `da63a064630a39b99b2e433f2d574934404e5de0ed1b2edd9a0f46d02e30a041`.
- Both verified `Hot Tub Launch B2B` (`AG47jEV5rVUrGLt5FlKO`), listed 37 workflows and read the complete existing workflow `01 · Lead Intake & Speed-to-Lead` (`17d02ad7-23bf-4a0d-92ed-1af6488c32b5`).
- The `publish_workflow` schema is exposed and requires `workflowId`. Its execution was not invoked. Other write tools were likewise inspected without execution.
- After the bridge change, missing and incorrect authentication returned HTTP 401. Independent sessions retained separate location context, and an unknown location was rejected.
- Javar's bridge and gateway are running; Telegram reconnected and no post-restart GHL authorization failure occurred. Existing Slack and webhook configuration was preserved.
- Javante's original outer GUI `osascript` launch context is preserved; its gateway has Telegram and A2A connected.
- Initial deployment caught a corrupted bridge transfer. It was restored from backup and redeployed only after the installed file matched the checked source hash. No residual blocker remains.

## Accepted runtime

- Host: Javar EA Orgo `d9b475e2-47b2-46d4-b8eb-102564f93283`.
- Javar endpoint: `http://127.0.0.1:18881/mcp`.
- Javante endpoint: `http://100.84.107.10:18881/mcp` over the existing private Tailscale route.
- Bridge forwards all installed vendor tools; the eleven-tool allowlist and draft-only override are removed.
- The corresponding `tools.include` restrictions were removed from both clients' `ghl-command` configuration.
- Authentication, protected bootstraps, Javar's profile allowlist, root-owned mode-0600 vendor credentials and registry remain in their established protected locations.

| Owned file | SHA-256 |
|---|---|
| Bridge source and installed bridge | `4ca623a0ce297adc1c494e513c1ed5866d48727a5d00a41acbd6fc74ed0c8599` |
| Acceptance probe source and both installed probes | `5b290dc784917314e454defa261af7bcb587fc60a34eae5aecb0a63c830c9aa0` |
| Javar Hermes config | `621dd256def68b14c57bded0f7391864788ed9dd6c5226c5cdafd5231b2340fb` |
| Javante Hermes config | `0b460284ac1cb94fa5db692b547c4a34a6a0f433d849556548e2088121a68d86` |

## Recovery and source ownership

- EA rollback backup: `/home/orgo/lil-smoove/backups/ghl-command-full-catalog-20260924T004338Z`.
- Javante rollback backup: `/Users/sashairis/.hermes/backups/ghl-command-full-catalog-20260924T004613Z`.
- These backups precede the correction and therefore restore the restricted interim connection. Use them only to recover a failed deployment; they do not satisfy the full-catalog request.
- Current approved source: `tools/ghl-command-cloud/bridge.mjs`, its matching probe, the native client configurations and the full-catalog connection guide.
- Javante's reviewed manifest is updated from version 11/60 files to version 12/61 files, deriving changed expectations from owned source. The earlier receipt remains historical; unrelated expected hashes and live AGENTS drift are preserved.
- The source package and maintained canonical copy carry matching package checksums. No full recovery installer was run against the healthy agents.
- Git shipping remains blocked by the existing managed `HEAD.lock` permission denial. No branch, commit, PR or permission workaround was performed as part of this correction.

```

## /Users/alexlobaito/Documents/ChatGPT/Build/agents/javante/setup/receipts/shared-ghl-command-access-20260923.md

SHA-256: `f0374a6ca2d6469f0ce3908c159ea11c8b8df5951d7e0ef80502302abc582c3b`. Canonical mtime: 2026-09-23T23:49:24.662988+00:00. State: SOURCE_ONLY.

```text
# Shared GHL Command access receipt — 2026-09-23

## Result

Javar and Javante are configured as native Hermes HTTP MCP clients of the protected GHL Command bridge on Javar's existing EA Orgo computer `d9b475e2-47b2-46d4-b8eb-102564f93283`.

- Javar route: `http://127.0.0.1:18881/mcp`
- Javante route: `http://100.84.107.10:18881/mcp` over the existing private Tailscale connection
- Authentication: `HMAC-SHA256(GHL_MCP_INTERNAL_API_KEY, "javante-ghl-command-cloud-v1")`, derived in memory by each existing protected gateway bootstrap
- Vendor: existing `@elitedcs/ghl-mcp` 3.84.2 installation
- Registry: 48 locations, 45 for company `uVK13CFqZs9TOBENvXSH` and 3 for company `8lhv95QH1ieNGTrnac9F`
- Sorted location ID SHA-256: `da63a064630a39b99b2e433f2d574934404e5de0ed1b2edd9a0f46d02e30a041`
- No GHL records or workflows were written during deployment or acceptance.

The bridge exposes exactly these eleven tools:

`get_mcp_version`, `get_current_location`, `switch_location`, `list_registered_locations`, `list_workflows_full`, `get_workflow_full`, `create_workflow`, `update_workflow_actions`, `clone_workflow`, `validate_workflow`, `audit_workflows`.

## Acceptance evidence

- The authenticated bridge probe initialized MCP, listed exactly the eleven allowed tools, listed 48 locations with the expected hash, rejected missing and wrong authentication, rejected an unknown location, rejected a tool outside the allowlist, and proved that two client sessions keep independent selected-location state.
- The configured Javar native Hermes route connected to the loopback HTTP MCP endpoint and discovered eleven tools. Its read-only acceptance listed all 48 locations, produced the expected ID hash, selected `Hot Tub Launch B2B` (`AG47jEV5rVUrGLt5FlKO`), listed 37 workflows, and read the complete existing workflow `01 · Lead Intake & Speed-to-Lead` (`17d02ad7-23bf-4a0d-92ed-1af6488c32b5`).
- Javar's production gateway initially parked the MCP connection as unauthorized because its default in-memory profile allowlist omitted the newly derived token. The live and source-tracked plugin allowlists now include only `GHL_COMMAND_REMOTE_TOKEN` in addition to their previous entries. After the targeted restart, the default profile reported nine protected values applied and no further `ghl-command` authorization failure occurred. The gateway process runs as UID/GID 999; the bridge vendor child runs as UID/GID 0 because the existing vendor credential and registry files remain root owned and mode 0600.
- The configured Javante GUI bootstrap and native Hermes route connected to the private HTTP MCP endpoint, discovered eleven tools, and passed the same 48-location hash and workflow full-read acceptance. Its one-shot GUI acceptance exited successfully. The temporary acceptance LaunchAgent and output files were removed afterward.
- Write capability was checked by catalog/schema only. `create_workflow`, `update_workflow_actions`, and `clone_workflow` are exposed. Static vendor inspection confirms create and clone request draft status; the bridge additionally rejects updates to a non-draft workflow or requests for a non-draft status. No write tool was invoked.
- Javar's `lil-smoove-messaging-gateway` and `ghl-command-cloud` Supervisor services are running. Javar Telegram reconnected in polling mode after restart; the existing Slack and webhook configuration was preserved.
- Javante's `ai.hermes.gateway` GUI LaunchAgent is running with its original outer `osascript` context. Its current startup log confirms healthy Telegram polling, A2A on `127.0.0.1:9900`, both platforms connected, and a two-platform running gateway.
- A final TCP check from Javante reached `100.84.107.10:18881`.
- Existing company303 `increase-roas-ghl` configuration and all unrelated services were left in place.

## Runtime hashes

### Javar EA

- `/home/orgo/lil-smoove/home/.hermes/config.yaml`: `5c27064ffad024ec51b978a976d055788d122d3664611cfe3b891a58311ccfdb`
- `/home/orgo/lil-smoove/home/.hermes/start-with-secrets.py`: `421dbc114586f62a7d9927e6e035c3c2107dd7771520da4bdb31c52f89233809`
- `/home/orgo/lil-smoove/runtime/javar-hermes-update/assets/start-with-secrets.py`: `421dbc114586f62a7d9927e6e035c3c2107dd7771520da4bdb31c52f89233809`
- `/home/orgo/lil-smoove/home/.hermes/plugins/javar-inbox/__init__.py`: `a9b38ac9488c0e30dd8eaef230003715a0b897dcab00a84d2ff013b470810d6e`
- `/home/orgo/lil-smoove/runtime/javar-hermes-update/assets/javar-inbox/__init__.py`: `f341bfe47c7237dabab10f235e22da6ac6e315781034c6b99f873af4e6f4cf57`
- `/home/orgo/lil-smoove/runtime/javar-hermes-update/manifest.json`: `36d28a30dc87d072e6fd2fb01491fac70128f538ebb5193172659873e3967425`
- Manifest entry `assets/start-with-secrets.py`: `421dbc114586f62a7d9927e6e035c3c2107dd7771520da4bdb31c52f89233809`
- Manifest entry `assets/javar-inbox/__init__.py`: `a9b38ac9488c0e30dd8eaef230003715a0b897dcab00a84d2ff013b470810d6e`
- Bridge `bridge.mjs`: `adbc3fc7388de64fcd23978dbb67cef0fee34164baf62311f7ecdfe8a26f2108`
- Bridge `start.sh`: `01bb5529bde4269dd30eb9cd3e8481d7b5299229ecedb1b1985ea8687594536b`
- Bridge `acceptance_probe.py`: `d17ecdffd864d93827c4f117283b9fb0d805bed8864ec2df235e82969325b381`
- Supervisor config: `82770104ec7d801ff067efdc469edf28379206841b58f3568bc9136f66ba3265`

The source and live `javar-inbox` plugin hashes differ because a pre-existing unrelated agent-knowledge path correction exists only in the live file. The GHL token allowlist change is present in both. The installed-file manifest continues to record the live hash.

### Javante Mac

- `/Users/sashairis/.hermes/config.yaml`: `b977c187bf7ca3be1c4885086db00b5bd45efc6d7d9be5890b73864130d60b2d`
- `/Users/sashairis/.hermes/scripts/start_javante_gateway_with_op.sh`: `d2f4a9ffd3f5073f82a2eaed9add1acd99df0e9c0169ee589acff729ae99eb5a`
- `/Users/sashairis/.hermes/tools/ghl-command-cloud/acceptance_probe.py`: `d17ecdffd864d93827c4f117283b9fb0d805bed8864ec2df235e82969325b381`
- `/Users/sashairis/Library/LaunchAgents/ai.hermes.gateway.plist`: unchanged at `a2703a9120e0130a2c2204400ed7d2318803ce38d17ea01f85771024336909e3`

## Recovery

- Javar bridge: `/home/orgo/lil-smoove/backups/ghl-command-cloud-20260923T220630Z`
- Javar shared bridge: `/home/orgo/lil-smoove/backups/ghl-command-shared-20260923T230524Z`
- Javar client config and loaders: `/home/orgo/lil-smoove/backups/ghl-command-client-u2-20260923T233047Z`
- Javar plugin and manifest: `/home/orgo/lil-smoove/backups/ghl-command-plugin-u2-20260923T234424Z`
- Javante config and wrapper: `/Users/sashairis/.hermes/backups/ghl-command-client-u2-20260923T233545Z`

The repository worktree was detached at `662f6e9…`. Creating the requested `codex/` branch was blocked by the managed filesystem denying creation of `.git/worktrees/Build4/HEAD.lock`, so no commit or pull request was created. This did not block runtime activation or acceptance.

```

# Current safe provider projections

These are exact persisted safe projections, not raw provider responses. All credential/plain-text binding values, contacts, messages, events, users and unallowlisted calendar fields were excluded. Returned-list counts have no pagination completeness claim. Metadata is not runtime acceptance.

## cloudflare-dev-rag-settings.json

Evidence SHA-256: `d8ad9e123e6aa88b886919540d502f95a3df663c36b928b4280ea1f01b92d26f`. Capture dates, named account, request scope and provider log IDs are in the record.

```json
{
  "captured_utc": "2026-10-07T23:12:29.892535+00:00",
  "account": "ca_IUuu0MrmsQya",
  "provider_account_id": "a3f549867f040e13df33e5bd18f785f4",
  "method": "GET",
  "path": "/accounts/a3f549867f040e13df33e5bd18f785f4/workers/scripts/dev-rag-worker/settings",
  "successful": true,
  "logId": "log_DlhC6IKukuNz",
  "projection": "only names/types and nonsecret resource targets; all secret and plain_text values excluded on provider side",
  "compatibility_date": "2026-08-25",
  "compatibility_flags": [
    "nodejs_compat"
  ],
  "bindings": [
    {
      "name": "ACCESS_AUDIENCE",
      "type": "plain_text"
    },
    {
      "name": "ACCESS_IDENTITY_MAP",
      "type": "secret_text"
    },
    {
      "name": "ACCESS_ISSUER",
      "type": "plain_text"
    },
    {
      "name": "DEV_ACCESS_IDENTITY_MAP",
      "type": "secret_text"
    },
    {
      "name": "DEV_JWT_HMAC_SECRET",
      "type": "secret_text"
    },
    {
      "name": "ENVIRONMENT",
      "type": "plain_text"
    },
    {
      "name": "JWT_AUDIENCE",
      "type": "plain_text"
    },
    {
      "name": "JWT_HMAC_SECRET",
      "type": "secret_text"
    },
    {
      "name": "JWT_ISSUER",
      "type": "plain_text"
    },
    {
      "name": "RAG_NOTE_IDENTITIES",
      "type": "plain_text"
    },
    {
      "name": "ROLE_KNOWLEDGE_IDENTITIES",
      "type": "plain_text"
    },
    {
      "name": "SOURCE_SYNC_IDENTITIES",
      "type": "plain_text"
    },
    {
      "name": "STATE",
      "type": "durable_object_namespace",
      "class_name": "StateEntity",
      "namespace_id": "d8302b544d8047bd8c63bed5e37c4783"
    },
    {
      "name": "TEAM_TASK_IDENTITIES",
      "type": "plain_text"
    },
    {
      "name": "TEAM_WORKERS",
      "type": "plain_text"
    },
    {
      "name": "VECTOR_INDEX",
      "type": "vectorize",
      "index_name": "dev-rag-knowledge"
    }
  ],
  "live_runtime_executed": false,
  "deployed_code_matches_local": "NOT_PROVEN"
}

```

## ghl-b2b-configuration.json

Evidence SHA-256: `bfe9c3c883816d6370ecbf2739bc521981bce79dd626811b2dcb859c08b1358c`. Capture dates, named account, request scope and provider log IDs are in the record.

```json
{
  "reads": [
    {
      "operation": "workflows.list",
      "account": "ca_OIfo_F6scXwN",
      "locationId": "AG47jEV5rVUrGLt5FlKO",
      "captured_utc": "2026-10-07T23:12:28.642943+00:00",
      "projection": "configuration IDs/name/status/calendar scheduling fields/stage structure only; no contacts/events/messages/users",
      "successful": true,
      "logId": "log_vUeobAin238-",
      "exit_code": 0,
      "wrapper_keys": [
        "data",
        "locationId",
        "operation",
        "status"
      ],
      "data_keys": [
        "traceId",
        "workflows"
      ],
      "records": [
        {
          "id": "64ec1931-202f-4629-bee2-f350f9f94b45",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "10 \u00b7 Alerts \u00b7 New Lead SMS",
          "status": "published"
        },
        {
          "id": "552c22b6-fce1-4f73-8b17-6998ba78595e",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "11 \u00b7 Alerts \u00b7 Booking SMS + Slack",
          "status": "published"
        },
        {
          "id": "906e2d10-f1b9-4901-81a4-430dea59a4a8",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "12 \u00b7 Alerts \u00b7 Slack New Lead",
          "status": "published"
        },
        {
          "id": "29dbda9e-4cd5-4cb8-88da-c073ca1d50cc",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "23 \u00b7 Voice Secretary \u00b7 Message Taken",
          "status": "draft"
        },
        {
          "id": "a4458d18-e71e-4c52-a65b-9b899bf0c1f9",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "24 \u00b7 Voice Secretary \u00b7 Transfer Follow-Up",
          "status": "draft"
        },
        {
          "id": "36e236eb-7baf-4b3e-9b45-29f110448116",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "25 \u00b7 Voice Secretary \u00b7 Spam Stamp",
          "status": "draft"
        },
        {
          "id": "c63c9f74-ef1c-4a2d-8718-64575f0e10cc",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "26 \u00b7 Voice Secretary \u00b7 Spam Entry",
          "status": "draft"
        },
        {
          "id": "0c42b78c-aeef-4f81-9ccb-5904521ad9f1",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "27 \u00b7 SMS AI \u00b7 Activate Assistant",
          "status": "draft"
        },
        {
          "id": "2f847881-0dc2-41de-bdf7-2b7570bdd5cc",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "DRAFT \u00b7 01 Lead Intake \u2014 fix premature goal exit (2026-09-29)",
          "status": "draft"
        },
        {
          "id": "c498e418-f4bd-498e-a8b1-1d314e5dc422",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL | Archive | Empty draft experiment",
          "status": "draft"
        },
        {
          "id": "4a6265f8-9f78-49b6-89b3-2d53dd3b4d4b",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL | Archive | Homeowner nurture v1 (wrong audience)",
          "status": "draft"
        },
        {
          "id": "1c18d7ed-60a4-4824-b528-421a509a09a4",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL | Archive | Untriggered iMessage experiment",
          "status": "draft"
        },
        {
          "id": "5d434f96-94d7-48e3-8222-3930a35519fb",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL | Archive | Voice note test for Manny",
          "status": "draft"
        },
        {
          "id": "fddf3986-3a1d-4505-a7ee-a0084de9bb88",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "TEST \u00b7 HTL intake \u00b7 SMS only \u00b7 2026-09-29",
          "status": "draft"
        },
        {
          "id": "f50e7b3c-fa89-4594-98bd-ea6fa9a88041",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "TEST \u00b7 HTL intake \u00b7 email only \u00b7 2026-09-29",
          "status": "draft"
        },
        {
          "id": "17d02ad7-23bf-4a0d-92ed-1af6488c32b5",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "01 \u00b7 Lead Intake & Speed-to-Lead",
          "status": "published"
        },
        {
          "id": "255b7c23-a474-4cbb-87a7-e2f1ddbf6b3f",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "02 \u00b7 Reply Router",
          "status": "published"
        },
        {
          "id": "ae96a103-ee7c-423c-b0e8-c9330011652f",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "03 \u00b7 Temperature Ladder",
          "status": "published"
        },
        {
          "id": "de7f94f8-fd07-402f-823c-f21b702dc410",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "04 \u00b7 Appointment Lifecycle",
          "status": "published"
        },
        {
          "id": "87f6fb9a-2041-486a-abee-90de8294737e",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "05 \u00b7 Appointment Reminders",
          "status": "published"
        },
        {
          "id": "5640d22d-1c69-4c83-9533-c68358c3bcec",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "06 \u00b7 Cancellation Handler",
          "status": "published"
        },
        {
          "id": "0b5b23d1-ab61-482b-910c-db8a875feb13",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "07 \u00b7 Long-Term Nurture v2",
          "status": "published"
        },
        {
          "id": "7750dfc7-dfbf-4b8b-bf23-fd2b7605f8b8",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "08 \u00b7 Missed Call Text-Back",
          "status": "published"
        },
        {
          "id": "25b95942-a941-46d3-830a-b71ee2480279",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "09 \u00b7 STOP to DND",
          "status": "published"
        },
        {
          "id": "fefdbe50-8786-43a5-91bd-81f131cd21da",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "28 \u00b7 Confirm YES Tagger",
          "status": "published"
        }
      ],
      "count": 25,
      "error": null
    },
    {
      "operation": "calendars.list",
      "account": "ca_OIfo_F6scXwN",
      "locationId": "AG47jEV5rVUrGLt5FlKO",
      "captured_utc": "2026-10-07T23:12:33.500949+00:00",
      "projection": "configuration IDs/name/status/calendar scheduling fields/stage structure only; no contacts/events/messages/users",
      "successful": true,
      "logId": "log_ixjRlVLKmV9E",
      "exit_code": 0,
      "wrapper_keys": [
        "data",
        "locationId",
        "operation",
        "status"
      ],
      "data_keys": [
        "calendars",
        "traceId"
      ],
      "records": [
        {
          "id": "2Cxr8gHsnc6xnMbeRPu9",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL Audit Calendar",
          "openHours": [
            {},
            {},
            {},
            {},
            {}
          ],
          "slotDuration": 15,
          "slotInterval": 30
        },
        {
          "id": "YVnZn8JR9zwwD1P4XjyG",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "HTL Closing Calendar",
          "openHours": [
            {},
            {},
            {},
            {},
            {}
          ],
          "slotDuration": 30,
          "slotInterval": 30
        }
      ],
      "count": 2,
      "error": null
    },
    {
      "operation": "pipelines.list",
      "account": "ca_OIfo_F6scXwN",
      "locationId": "AG47jEV5rVUrGLt5FlKO",
      "captured_utc": "2026-10-07T23:12:40.387109+00:00",
      "projection": "configuration IDs/name/status/calendar scheduling fields/stage structure only; no contacts/events/messages/users",
      "successful": true,
      "logId": "log_WkbvY82ga1xa",
      "exit_code": 0,
      "wrapper_keys": [
        "data",
        "locationId",
        "operation",
        "status"
      ],
      "data_keys": [
        "pipelines",
        "traceId"
      ],
      "records": [
        {
          "id": "9EaXmWHeOk8QcW26PPME",
          "locationId": "AG47jEV5rVUrGLt5FlKO",
          "name": "B2B-HTL | Sales Pipeline",
          "position": "a0pQaqf",
          "stages": [
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            },
            {
              "id": null,
              "name": null,
              "position": null
            }
          ]
        }
      ],
      "count": 1,
      "error": null
    }
  ],
  "scope": "one B2B location; no shared location switch; no runtime action"
}

```

## provider-route-events.json

Evidence SHA-256: `6da3e049ad1f1209d38c8af78ebadf7834c4aa4b0e7e8949ea62cfee69c5a140`. Capture dates, named account, request scope and provider log IDs are in the record.

```json
{
  "date": "2026-10-07",
  "events": [
    {
      "command": "composio execute CUSTOM_CLOUDFLARE_API_SEARCH --account ca_IUuu0MrmsQya --get-schema",
      "result": "sandbox ENOTFOUND backend.composio.dev; approved network escalation succeeded"
    },
    {
      "command": "composio execute CUSTOM_CLOUDFLARE_API_EXECUTE --account ca_IUuu0MrmsQya --get-schema",
      "result": "first returned HTTP 404 Tool_ToolNotFound; approved search returned same slug and repeated schema/read succeeded; no route switch"
    },
    {
      "command": "composio execute CUSTOM_CLOUDFLARE_API_SEARCH --account ca_IUuu0MrmsQya",
      "logId": "log_BgBm3wwUExQ7",
      "result": "official OpenAPI GET settings path discovery succeeded"
    },
    {
      "command": "composio execute CUSTOM_GHL_OAUTH_CRM_GHL_SEARCH_OPERATIONS --account ca_OIfo_F6scXwN -d {}",
      "logId": "log_wcorsTqv7-gf",
      "result": "catalog read succeeds; workflows.list/calendars.list/pipelines.list READ_ALLOWED; generic ghl.request WRITE_ALLOWED classification, not used"
    }
  ]
}

```

## ghl-pipeline-shape.json

Same-route Oct7 verification of all returned stage keys/types before local projection; no alternate ID/name fields were present and all exposed stage fields were null. Underlying API versus connector cause remains unproven. SHA-256: `aa0e498aa8b13cc94b5252363505ef8458244dee3090f765538f09fcdc11e417`.

```json
{
  "captured_utc": "2026-10-07T23:17:17.974705+00:00",
  "account": "ca_OIfo_F6scXwN",
  "locationId": "AG47jEV5rVUrGLt5FlKO",
  "operation": "pipelines.list",
  "successful": true,
  "logId": "log_YQmW5L_IDzKc",
  "exit_code": 0,
  "scope": "safe pipeline configuration key names/types and stage identifier/name alternatives only; no contacts/opportunities/customer records",
  "pipelines": [
    {
      "id": "9EaXmWHeOk8QcW26PPME",
      "name": "B2B-HTL | Sales Pipeline",
      "locationId": "AG47jEV5rVUrGLt5FlKO",
      "pipeline_keys_and_types": {
        "colorRenderMode": "str",
        "dateAdded": "str",
        "dateUpdated": "str",
        "id": "str",
        "locationId": "str",
        "name": "str",
        "position": "str",
        "showInFunnel": "bool",
        "showInPieChart": "bool",
        "stages": "list",
        "useOpportunityProbability": "bool"
      },
      "stages": [
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        },
        {
          "keys_and_types": {
            "id": "NoneType",
            "name": "NoneType",
            "position": "NoneType",
            "showInFunnel": "NoneType",
            "showInPieChart": "NoneType",
            "stageWinProbability": "NoneType"
          },
          "safe_fields": {
            "id": null,
            "name": null,
            "position": null
          },
          "all_values_null": true
        }
      ]
    }
  ]
}

```
