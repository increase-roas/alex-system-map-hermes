# Access and tools

Knowledge audit: 2026-10-07. Start with [START_HERE.md](START_HERE.md), then read [ACCOUNTS.md](ACCOUNTS.md) for saved connection IDs and declared personal plans. Those IDs are an inventory, not a recommendation to use every connection.

## Route selection

Alex's current chat instructions require Composio first. Where a terminal is available, discover tools with `composio search` and execute the returned tool with an explicitly named `--account`. Search does not accept `--account` in the observed CLI; login selection belongs on execution. Where no terminal is available, use the official Composio app's search and execution tools with an explicit principal/account. Read the app card before the first app call. Do not copy a search result's sample call without checking its effect and schema.

The maintained cards live at `/Users/alexlobaito/.agents/tools/cards/<app>.md` on Alex's Mac. Other machines use the approved IR Notes `CUSTOM_IR_NOTES_GET_APP_RULES` route with `app=<card>` when available. A local path is not proof that a remote agent can read it. If the card or route cannot be read, record the limitation rather than inventing permissions.

## Google Workspace

The current card `/Users/alexlobaito/.agents/tools/cards/google-workspace.md` (updated 2026-10-03) selects `custom_google_robot`, connection `ca_vm6rcasgNEIk`, and `user=alex@increaseroas.com` by default. The robot's named-user parameter determines the Google principal. Existing Gmail/Docs/Sheets/Drive connections in ACCOUNTS belong to agents and must not be treated as Alex's default routes.

The knowledge publication task uses this robot as Alex. Registered workbooks remain at their registered IDs; updates use the maintained upload helper and must match the final local bytes. The registry is `/Users/alexlobaito/Projects/master-connector-repo/knowledge/workbook-drive.json`. Helper: `/Users/alexlobaito/.agents/tools/connectors/google_robot/drive_upload_file.py`. Never create a replacement registered workbook to work around a failed update.

## Credentials and identities

Credentials remain outside this knowledge layer. Refer to their approved Composio/1Password route, without copying values into Markdown, a registry, chat, URLs, screenshots, or logs. Claude Code and Codex use the approved op CLI/connectors-sync route where configured; hosted Claude/ChatGPT receive keys only through Composio under Alex's current rule. Saved credential titles in ACCOUNTS are historical pointers, not newly verified retrieval paths.

Declared `alex@increaseroas.com` and `agent@increaseroas.com` Hermes identities have not been bound to specific serving profiles by this audit. Read [GAPS.md](GAPS.md) before making that assignment.

## Actions and maintenance

This document grants no new spend, client contact, deletion, security-setting change, deployment, or recurring automation. Follow current chat authorization and the exact app card. Never change route to bypass a rejected call. A connector marked ACTIVE, a saved login, a hook source or a successful configuration check does not prove live service behavior.

A public-page Exa fetch in this chat was rejected by automatic approval review as spending without approval, although the local Exa card describes ordinary fetches as freely runnable. It was not retried through another route. That policy/approval mismatch is a recorded gap, not evidence that all web access is unavailable.

After a route/account correction, update its maintained card or registry only within authorization, then refresh this reference and follow [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md). Add a verified lesson to [LESSONS.md](LESSONS.md); update START_HERE's completed audit metadata only after verification and publication checks pass.

Route-event evidence: local `work/agent-knowledge/route-events.json` and `search-help.txt`, captured 2026-10-07. The Exa item is a recorded current-chat approval-review response; it is not a fresh policy acceptance test.

For a Markdown read, compare the returned text against the verified stored checksum. One robot read returned incorrectly decoded punctuation; [AUDIT_PROTOCOL.md](AUDIT_PROTOCOL.md) contains the exact checksum-guarded recovery, and [LESSONS.md](LESSONS.md) records the proof. Stored Drive bytes were correct; no service fix was deployed.
