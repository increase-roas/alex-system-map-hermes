# Hooks register

## Build-context extension

The configuration extension captures safe Codex, Claude and Cursor hook declarations; the procedure extension captures selected hook/guard and scheduler support. See [CONFIGURATION_AND_INSTRUCTIONS.md](CONFIGURATION_AND_INSTRUCTIONS.md) and [PROCEDURES_AND_DEPENDENCIES.md](PROCEDURES_AND_DEPENDENCIES.md). The counts below retain the earlier scoped audit; source/configuration capture does not prove hook execution.

Audit date: 2026-10-07. Hook sources were read; no hook was executed, installed or changed. **Configured/source-present** and **seen working** are separate. This audit proves source presence and selected configuration only; observed runtime execution is NOT_PROVEN.

## Safe source inventory

### pre-commit

[H1] Source: `/Users/alexlobaito/.agents/tools/unify/hooks/pre-commit`; SHA-256: `2b4ee2513cf8b2552c571f0153d0f0c21d5a28ac2d4247c8fbff67c73521a48b`; 5776 bytes; full source read on 2026-10-07.

Local commit hygiene gate. Checks non-ignored untracked paths, rejects staged generated/secrets-like artifacts, parses staged Python/JSON/JSONL/YAML/JavaScript/shell blobs when their parsers exist, and invokes vendor integrity checks when locked skill content changes. The untracked acknowledgement does not bypass artifact or parse checks.

### post-commit

[H2] Source: `/Users/alexlobaito/.agents/tools/unify/hooks/post-commit`; SHA-256: `4fdecb967fa19de78cbe412c9c4152aeda5fd251727d9c264b4cba8dd4873c46`; 2869 bytes; full source read on 2026-10-07.

Asynchronous publication/check dispatcher. Skill and route changes invoke local lifecycle acceptance; cards/instructions/server changes additionally invoke the existing notes sync, instruction build and workbook pipeline only after preceding stages pass. Writes logs/receipts under the runtime path with temporary-directory fallback. A successful commit is not publication proof.

### herdr-agent-state.sh

[H3] Source: `/Users/alexlobaito/.claude/hooks/herdr-agent-state.sh`; SHA-256: `7f117c303ffc1a66975b76dda8189d70b718fc04af4cf7cb11449e4ee5b4ae86`; 3070 bytes; full source read on 2026-10-07.

Herdr-managed Claude integration v10. Session action reads hook input into a temporary file and publishes agent state over a socket only when the required Herdr environment and Python are available. Managed file warns that reinstall/update replaces it.

### chat_guard.py

[H4] Source: `/Users/alexlobaito/.agents/tools/guards/chat_guard.py`; SHA-256: `e2f0fcc8568d56ef84d22b39e70421b8ce7f4d37c80a63a7133c4e94b4780edc`; 18242 bytes; full source read on 2026-10-07.

Claude memory/chat guard. SessionStart, PostToolUse, prompt and Agent/Task/Workflow pre-hooks track chat growth and Mac memory pressure. Its source describes a chat-size handoff prompt, agent gating near critical memory, and stopping this chat's large command near the limit. It exits 0 and logs errors. Runtime behavior was not exercised.

### composio_guard.py

[H5] Source: `/Users/alexlobaito/.agents/tools/guards/composio_guard.py`; SHA-256: `a582374640be081f9373e7df258333ec3934ce1bd456da76c6e8adf3368d92c0`; 87543 bytes; full source read on 2026-10-07.

Claude PreToolUse guard for CLI, MCP and code-mode calls. Classifies spend, outside sends, delete, DNS, deploy and security actions against typed human approvals and target identity. Also rejects ambiguous multi-login calls, forbidden container access and unreadable payload paths. Catalogue preserves the current chat/card authority; source rules do not independently authorize any action.

## Claude and Cursor hook configuration

Only the whitelisted `hooks` sections were inspected. All other configuration fields are excluded; commands are represented by path references and hashes rather than exported payloads.

| Source | Event | Command type | Referenced source |
|---|---|---|---|
| `/Users/alexlobaito/.claude/settings.json` | SessionStart | command | `/Users/alexlobaito/.claude/hooks/herdr-agent-state.sh` |
| `/Users/alexlobaito/.claude/settings.json` | SessionStart | command | `/Users/alexlobaito/.agents/tools/guards/chat_guard.py` |
| `/Users/alexlobaito/.claude/settings.json` | PostToolUse | command | `/Users/alexlobaito/.agents/tools/guards/chat_guard.py` |
| `/Users/alexlobaito/.claude/settings.json` | UserPromptSubmit | command | `/Users/alexlobaito/.agents/tools/guards/chat_guard.py` |
| `/Users/alexlobaito/.claude/settings.json` | PreToolUse | command | `/Users/alexlobaito/.agents/tools/guards/chat_guard.py` |
| `/Users/alexlobaito/.claude/settings.json` | PreToolUse | command | `/Users/alexlobaito/.agents/tools/guards/composio_guard.py` |
| `/Users/alexlobaito/.claude/settings.json` | PreToolUse | command | `/Users/alexlobaito/.agents/tools/guards/composio_guard.py` |
| `/Users/alexlobaito/.claude/settings.local.json` | No hooks section entries | — | — |
| `/Users/alexlobaito/.cursor/settings.json` | No hooks section entries | — | — |

Seven Claude hook entries are configured in the main settings file. No hooks-section entries were observed in the inspected Claude local or Cursor settings files. This is a scoped config observation: alternate settings formats, extensions, plugin-managed hooks and other-machine hooks were not enumerated. Matcher conditions remain in the source config and were not tested.

## Build and connector repository hooks

| Repository | core.hooksPath readback | Active non-sample files in default .git/hooks |
|---|---|---|
| `/Users/alexlobaito/Documents/ChatGPT/Build` | Unset (git config exit 1) | 0 |
| `/Users/alexlobaito/Projects/master-connector-repo` | Unset (git config exit 1) | 0 |

Read-only Git config queries and default-hook directory enumeration found no configured override and no active non-sample default hooks for these two repositories. This does not prove hook execution elsewhere, externally invoked automation, or past-hook state.

## Unify tooling source coverage

Sixteen regular top-level source/config files under `/Users/alexlobaito/.agents/tools/unify` were read and hashed. The coverage JSON lists exact paths and function names; supporting Python bytecode/cache folders were excluded. Relevant tooling includes instruction build/plan, local drift checks, Git hook setup, skill dependency/vendor validation, skill lifecycle/route checks, Codex plugin inventory and their test sources. Tests and setup were read, never run.

[L1] `/Users/alexlobaito/.agents/tools/unify/skill-lifecycle.md` (checked 2026-10-07) requires per-target discovery/selection proof and remote publication receipts before delivery claims. Hook source presence and local configuration are not that proof.

## Required future update

After an authorized hook/config change, reread only safe hook sources and hook sections, update hashes and scope in `work/agent-knowledge/skills-hooks-coverage.json`, and record the changed behavior plus receipt pointer in [LESSONS](LESSONS.md). Update [START_HERE](START_HERE.md) with the completed audit date, scope, receipt and exclusions. A claim that a hook ran must cite its execution log/receipt and result; a successful commit alone is insufficient. No global config, shared skill, hook or memory change is authorized by this reference catalogue.
