# Cached plugin skills register

Audit date: 2026-10-07. Complete reads of safe local plugin-cache SKILL.md files, deduplicated by exact resolved path. This is a reference catalogue; the cached sources retain procedure ownership. Supporting files were inventoried as metadata only.

## Scope and evidence limits

154 unique cached SKILL.md sources across 24 provider/plugin groups and 24 version groups. 0 duplicate resolved paths; 0 read errors; 1 excluded symlink/non-regular paths. Exact paths, hashes, dates and source excerpts are in `work/agent-knowledge/plugin-skills-coverage.json`.

70 entries match named skills in the current session's supplied available-skills catalogue. That catalogue is session-exposure evidence only; it does not prove activation, selection, successful execution or remote delivery. Other cache entries are present locally, with enabled configuration and session exposure NOT_PROVEN. No plugin enablement/configuration file was read or changed.

SKILL.md source descriptions are summarized below with contents headings and short procedure cues; cached duplicates/version groups are preserved separately unless their resolved path is identical. No cache version is asserted to be current vendor release.

## Provider and plugin coverage

| Provider/plugin | Cached skills |
|---|---:|
| `claude-cowork/anthropic-skills` | 21 |
| `claude-cowork/cowork-plugin-management` | 2 |
| `claude-cowork/data` | 10 |
| `claude-cowork/design` | 7 |
| `claude-cowork/desktop-commander` | 6 |
| `claude-cowork/engineering` | 10 |
| `claude-cowork/marketing` | 8 |
| `claude-cowork/pdf-viewer` | 1 |
| `openai-bundled/visualize` | 1 |
| `openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e` | 1 |
| `openai-curated-remote/openai-templates` | 20 |
| `openai-curated-remote/pages` | 4 |
| `openai-curated-remote/plugin-management` | 1 |
| `openai-curated-remote/sites` | 1 |
| `openai-curated-remote/superpowers` | 15 |
| `openai-curated-remote/work-pets` | 3 |
| `openai-curated/data-analytics` | 18 |
| `openai-curated/openai-developers` | 5 |
| `openai-curated/superpowers` | 14 |
| `openai-primary-runtime/documents` | 1 |
| `openai-primary-runtime/pdf` | 1 |
| `openai-primary-runtime/presentations` | 1 |
| `openai-primary-runtime/spreadsheets` | 2 |
| `openai-primary-runtime/template-creator` | 1 |

## claude-cowork / anthropic-skills / 1.0.0

### ads-triage

[P127] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/ads-triage/SKILL.md`; modified UTC: 2026-10-07T06:07:03.674683+00:00; SHA-256: `6aef1b71f5db9b726068a129fb9a7fe675491406f0f14d0154e8fb097e8993ae`.

**Purpose:** Diagnose a problem in a client ad account when the cause isn't yet known — bad leads, CPL spikes, delivery falling off, spend anomalies. Trigger on reports like "getting leads outside the area", "CPL doubled", "this account stopped working", "why is X happening in Y's account". Do not trigger for routine reporting or for building new campaigns.

**Contents:** Ad Account Triage; Gate — answer all three before the first tool call; Where facts live; Before asserting any finding; Output shape.

**Opening guidance (source excerpt):** Settings tell you what is **possible**. Outcome data tells you what **happened**.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### alex-director

[P136] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/alex-director/SKILL.md`; modified UTC: 2026-10-07T06:07:03.674341+00:00; SHA-256: `96f603b3f9329c1f5ac9abd7eabac86867fd5b8365d2884617f3c6b7053509c5`.

**Purpose:** Alex's Director, Claude app pointer. Read and follow ~/.agents/skills/alex-director/SKILL.md and ~/Alex-Director/AGENTS.md on Alex's MacBook. Use when acting as Alex's Director.

**Contents:** Alex Director — Claude app pointer; How Claude reads and writes the Mac files; Claude transport (the canonical files cover Codex and Cursor controllers); If the files can't be read.

**Procedure cues (source excerpts):** `~/.agents/skills/alex-director/SKILL.md`, the canonical Director skill. Its "Where things are" table says which; `~/Alex-Director/AGENTS.md`, the role card and read table.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### alex-workflow-conductor

[P143] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/alex-workflow-conductor/SKILL.md`; modified UTC: 2026-10-07T06:07:03.674392+00:00; SHA-256: `1dacca4660fb2b8986b9eb11728a7faf20bfa6582cd853e8a59b658e5b6caac8`.

**Purpose:** Alex's workflow conductor, Claude app pointer. Read and follow ~/.agents/skills/alex-workflow-conductor/SKILL.md on Alex's MacBook. Use only when Alex names the conductor.

**Contents:** Alex Workflow Conductor — Claude app pointer; How Claude reads the Mac files; Claude transport (the canonical file covers Codex and Cursor); If the file can't be read.

**Opening guidance (source excerpt):** This upload carries no policy or routes of its own, so it can't go stale. The canonical skill is `~/.agents/skills/alex-workflow-conductor/SKILL.md` on Alex's MacBook. Read it from disk now and follow it exactly. Its shared policy is in `~/.agents/skills/alex-director/references/`; read the section you need.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### blueprint

[P145] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/blueprint/SKILL.md`; modified UTC: 2026-10-07T06:07:03.654015+00:00; SHA-256: `ce441225660e42c688a0eba524419596f0ae9acdd35b320762d56f5dacb48ab2`.

**Purpose:** Turn a GHL Command client intake into a complete, reviewable GoHighLevel account build plan — the GHL Command Blueprint. Detects Agency OS for a deeper brief (else uses the built-in intake form), selects an industry preset, generates a structured build plan (pipeline, fields, tags, calendar, form, funnel, email/SMS, workflows) with symbolic refs not real IDs, and renders a two-part approval checklist (what GHL Command builds automatically vs. what you must do manually, in order). The plan stops at the human approve gate; GHL-native staging then runs via apply_build_plan. Each funnel can be GHL-native (default) or an external site the user hosts (Cloudflare/Vercel) and wires back to GHL — a power-user, capability-gated lane that generates the site, injects verified field IDs, walks the user through their own deploy, and finishes only when verify_funnel passes on the real URL. Triggers on build my Blueprint, run Blueprint, GHL Command Blueprint, build a client account, watch it build a client, new client account, client onboarding build, build plan, account build spec, external funnel, host my own funnel.

**Contents:** GHL Command Blueprint (plan generation); The pipeline you run; STEP 1 — Detect the brief source (do this first, before any questions); STEP 2 — Source the brief (§4); STEP 3 — Select the preset; STEP 4 — Fill the skeleton (deterministic; see preset-format §"fill algorithm"); STEP 5 — Derive flag-driven handoffs; STEP 6 — Generate copy (gated, grounded, editable); STEP 7 — Assemble the plan (§5); STEP 8 — Quality gate (run on yourself before showing anything); STEP 9 — Render the approval view (§5A); STEP 10 — External funnel lane (only if a funnel is `target: "external"`); Hard rules (do not violate); Files in this skill.

**Procedure cues (source excerpts):** If `brief.preset` is set, match it against each preset's `selectors.aliases`.; Else match `brief.business.type` against `selectors.businessTypes`.; Else use the library `default` preset (`med_spa`). (`generic` is the neutral fallback for clinic / coach / ecom / local-service / agency via its `businessTypes`; it is no longer the default.)

**Resources:** references/: 8 files; examples/: 8 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### clone-site

[P132] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/clone-site/SKILL.md`; modified UTC: 2026-10-07T06:07:03.341883+00:00; SHA-256: `518a1eb72a41a05df27b228764b09623311ce2623629e3b47f59545202ad489b`.

**Purpose:** Clone an existing live website or landing page from its URL and rebrand it for a new client — same layout, images, video and CSS, with new company name, contact details, colors and copy. Starts by asking what rights you have to the page and records your answer; with rights it makes a true byte-for-byte clone, without them it extracts the page's real design system and rebuilds on that. Every run ends with a REVIEW REQUIRED report of everything still belonging to the original owner — lead, booking and payment destinations, other people's names and testimonials, and inherited regulated claims. Triggers on clone this site, clone this page, copy this website, duplicate this funnel, rebuild this landing page for, make this site for my client, mirror this URL, clone URL, copy this landing page, steal this layout, make me one like this.

**Contents:** Clone Site; Hard rules; STEP 0 — Rights (before any bytes are copied); LANE A — Full clone (rights declared); STEP 1 — Scope and ask (one message, defaults offered); STEP 2 — Mirror (deterministic); one page; the whole site — follows the site's own navigation; STEP 3 — Rebrand (substitution, not rewriting); STEP 3b — Render and repair (never skip; a clone that does not render is not a clone); STEP 4 — Pre-launch audit (mandatory, never skipped); STEP 5 — Host; STEP 6 — Verify the deployed URL; LANE B — Style clone (no rights, or "I just want the look"); B1 — Read the extracted artefacts, not your instincts.

**Procedure cues (source excerpts):** **Ask for rights first, record the answer, then proceed.** Step 0 below. You are not a rights verifier; the user's declaration is the user's responsibility, and recording it makes that explicit.; **Coach, never block.** "No rights" routes to the style lane — never to a refusal, and never to a from-memory redraw.; **Copy, never regenerate.** If a fetch fails, say so. Do not reconstruct a page you could not download.

**Resources:** references/: 3 files; scripts/: 7 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### consolidate-memory

[P129] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/consolidate-memory/SKILL.md`; modified UTC: 2026-10-07T06:07:03.313286+00:00; SHA-256: `7edd3cadeefc6461dfc487338bf751ae8f905e7c2dbf0b2eab13000d3659d132`.

**Purpose:** Reflective pass over your memory files — merge duplicates, fix stale facts, prune the index.

**Contents:** Memory Consolidation; Phase 1 — Take stock; Phase 2 — Consolidate; Phase 3 — Tidy the index.

**Opening guidance (source excerpt):** You're doing a reflective pass over what you've learned about this user and their work. The goal: a future session should be able to orient quickly — who they work with, what they're focused on, how they like things done — without re-asking.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### docx

[P144] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/docx/SKILL.md`; modified UTC: 2026-10-07T06:07:03.637382+00:00; SHA-256: `814ddff5a7d38a5e4344040db2a742101e79df17de28613617783262063a757f`.

**Purpose:** Use this skill whenever the user wants to create, read, edit, or manipulate Word documents (.docx files) or Word templates (.dotx files). Triggers include: any mention of 'Word doc', 'word document', '.docx', '.dotx', or requests to produce professional documents with formatting like tables of contents, headings, page numbers, or letterheads. Also use when extracting or reorganizing content from .docx or .dotx files, inserting or replacing images in documents, performing find-and-replace in Word files, working with tracked changes or comments, or converting content into a polished Word document. If the user asks for a 'report', 'memo', 'letter', 'template', or similar deliverable as a Word or .docx file, use this skill. Do NOT use for PDFs, spreadsheets, Google Docs, or general coding tasks unrelated to document generation.

**Contents:** DOCX creation, editing, and analysis; Creating with docx-js — gotchas; Verify the output; Editing existing documents; edit unpacked/word/document.xml in place — do NOT reformat or pretty-print; Comments; Against an already-unpacked directory (preferred when also placing markers); Against a .docx directly; Dependencies.

**Opening guidance (source excerpt):** A `.docx` is a ZIP archive of XML files. Choose your approach by task:

**Resources:** scripts/: 63 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### first-principles-speed-analyzer

[P146] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/first-principles-speed-analyzer/SKILL.md`; modified UTC: 2026-10-07T06:07:03.672663+00:00; SHA-256: `3377e15de5d1bc85f7296f83d33625c94623140a6c6c525a6adec52d0f90c6d3`.

**Purpose:** Select the smallest evidence-backed proof, existing assets to extend, and first blockers. Use before planning a multi-step project where speed and scope control matter.

**Contents:** First-Principles Speed Analyzer; Operating boundaries; Workflow; Required Output; First-Principles Speed Analysis — [Project / Outcome]; Outcome; Evidence Coverage; What Must Be True Once; Fastest First Proof; First-Proof Blockers; KEEP / CUT / SIMPLIFY / LATER; Build Now — One Item Only; Next Action; Quality bar.

**Procedure cues (source excerpts):** **State the actual outcome.** Define the user-visible or operator-visible behavior that matters, not an implementation slogan. Name the actor, trigger, successful result, and success condition.; **Inventory the evidence.** Record the named source set and distinguish:; **Reason from first principles.** Ask what must be true for the desired behavior to occur once; which existing repository, runtime, data store, schema, workflow, or tool already supplies each requirement; what exact link is missing between trigger and observable result; and what smallest safe test distinguishes a real capability from a claim.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### ghl-reports

[P141] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/ghl-reports/SKILL.md`; modified UTC: 2026-10-07T06:07:03.545098+00:00; SHA-256: `f08c15aaafaccab00a37a452b5d4272788b05eaa42549394182a67af5f6839c1`.

**Purpose:** Answer GoHighLevel data questions — counts, lists, and weekly reports — fast, cheap, and verified. Uses get_contact_count for any "how many contacts" question (one call, GHL's own index, exact window echoed), clean pagination recipes for lists with a CSV deliverable, and get_account_health_summary for composed account reports. Never guesses a number, never paginates to count, always states the exact window and source next to every figure. Triggers on how many contacts, new contacts this week, new leads last 7 days, count my contacts, list my new contacts, contacts added since, weekly report, account report, GHL report, export contacts to CSV.

**Contents:** GHL Reports; Shape 1 — "How many …?" → one call; Shape 2 — "List them" → paginate with a destination; Shape 3 — "How is the account doing?" → composed report; When something fails.

**Procedure cues (source excerpts):** **Never guess.** Every number you state comes from a tool response you actually received.; **Count and list are different jobs.** A count is ONE `get_contact_count` call. A list is; **Every figure ships with its window and source.** "163 contacts (dateAdded 2026-07-30T07:00Z

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### hermes-boss-director

[P147] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/hermes-boss-director/SKILL.md`; modified UTC: 2026-10-07T06:07:03.674508+00:00; SHA-256: `7c2858d64521091250785887749a49a8318b33d6be508a80133f864f0866cca6`.

**Purpose:** Hermes controller playbook for Javante/Javar under the Director and Conductor: native-fix research, right-route dispatch, live verification.

**Contents:** Hermes Boss Director; 0. Operating rules (always on); 1. Mission; 2. Root cause from evidence; 3. Parallel research — find the documented fix; Existing skill found? Audit it first; 4. Cross-reference the live setup; 5. Report; 6. Plan; 7. Dispatch — right route per fix; 8. Supervise and verify; 9. Record and improve.

**Procedure cues (source excerpts):** **Hermes docs + changelog** — pull latest docs from GitHub (never the bot's installed copy):; **GitHub issues/PRs** — Exa: "NousResearch hermes-agent github issue <symptom>". Merged PR/maintainer comment = documented fix; open issue = known bug.; **Vendor docs** (GHL, Meta, Google, Cloudflare) — Ref, then Exa; include ideas boards / API-docs issues to learn when an API doesn't exist.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### integration-fit-and-source-of-truth

[P137] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/integration-fit-and-source-of-truth/SKILL.md`; modified UTC: 2026-10-07T06:07:03.419978+00:00; SHA-256: `a4546ffee5907b04e00b2c12520972312ca23d9bd5021c07f99b55ffcc605542`.

**Purpose:** Assess source of truth, data flow, native-vs-custom fit, permissions, and proof needs. Use before APIs, webhooks, CRM connections, or automation.

**Contents:** Integration Fit and Source of Truth; Operating boundaries; Workflow; Required output; Integration Fit — [Workflow Name]; Desired Outcome; Systems and Scope; Capability Matrix; Source-of-Truth and Data Rules; Material Risks and Unknowns; Decision; Proposed Next Step; Quality bar.

**Procedure cues (source excerpts):** **Define the business outcome.** State the trigger, the desired visible result, the actor who needs it, and the smallest success condition. Do not start with an API or tool choice.; **Name the systems and boundaries.** Identify the proposed source system, destination system, relevant client/account/environment, and any current process that already achieves part of the outcome.; **Verify capabilities.** Check official current documentation and any available read-only account evidence. For each needed capability—trigger, read, write, identity mapping, history/context, status/receipt, error handling, and rate/permission requirements—record `Confirmed`, `Unverified`, or `Not supported`. Cite the evidence location.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### mission-intake-and-approval-gate

[P142] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/mission-intake-and-approval-gate/SKILL.md`; modified UTC: 2026-10-07T06:07:03.553449+00:00; SHA-256: `2f7845043b1668a309748886482419ee38ad37e41ed8d290335016e3f0ca39d3`.

**Purpose:** Verify client, mission, sources, environment, scope, evidence, and approval state. Use before consequential, multi-client, source-heavy, or cross-system work.

**Contents:** Mission Intake and Approval Gate; Operating boundaries; Workflow; Required output; Mission Intake Gate — [Mission Name]; Requested Outcome; Verified Identity; Authoritative Source Manifest; Prerequisites and Approval; Excluded or Conflicting Material; Gate Decision; Smallest Next Action; Quality bar.

**Procedure cues (source excerpts):** **State the mission.** Record the requested outcome in one sentence. Name the client/project, repository or workspace, target environment, and requested change or decision. If any is absent, mark it unknown rather than infer it.; **Map the authoritative sources.** Identify the exact source files, links, repository paths, task IDs, or documents that govern this mission. Separate them from reference material, historical material, duplicate copies, and unverified notes.; **Verify accessibility and identity.** Confirm that each required source is reachable, readable, and belongs to the named mission. Record missing, inaccessible, conflicting, or duplicated sources. Never claim a source was reviewed if it was not accessible.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### native-fix-research

[P139] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/native-fix-research/SKILL.md`; modified UTC: 2026-10-07T06:07:03.674456+00:00; SHA-256: `99f5c16ec602bc7b35b445345d019d528a3f962a062b9c2185e6b4461d541550`.

**Purpose:** Find the documented native fix for a bot/tool failure, plan it as a mission, fix it with parallel agents on the right route (Hermes app UI, live view, SSH, API; browser last), and supervise until verified live.

**Contents:** Native fix research → mission plan → parallel fix → verify; 0. Freeze the mission; 1. Root causes from evidence, not memory; 2. Find the documented fix (stop at the first documented answer); 3. Cross-reference the live setup (read-only); 4. Report (brief); 5. Plan: one node per fix; 6. Launch parallel controller agents — right route per fix; 7. Supervise until done; 8. Verify and record.

**Procedure cues (source excerpts):** **Latest Hermes docs from GitHub** (never the bot's installed copy — frozen at install):; **GitHub issues/PRs** via Exa (`web_search_exa`, "NousResearch hermes-agent github issue <symptom>"). Merged PR or maintainer comment = documented fix; open issue = known bug, no fix yet.; **Vendor docs** (GHL, Meta, Google) via Ref (`ref_search_documentation`) then Exa, including ideas boards / API-docs issues — they tell you when an API route doesn't exist.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### pdf

[P135] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/pdf/SKILL.md`; modified UTC: 2026-10-07T06:07:03.414963+00:00; SHA-256: `9f78b8359fbd4943ad260a7a1e436e5a96503406d6c34e99f69223d647d85b9c`.

**Purpose:** Use this skill whenever the user wants to do anything with PDF files. This includes reading or extracting text/tables from PDFs, combining or merging multiple PDFs into one, splitting PDFs apart, rotating pages, adding watermarks, creating new PDFs, filling PDF forms, encrypting/decrypting PDFs, extracting images, and OCR on scanned PDFs to make them searchable. If the user mentions a .pdf file or asks to produce one, use this skill.

**Contents:** PDF Processing Guide; Overview; Quick Start; Read a PDF; Extract text; Python Libraries; pypdf - Basic Operations; Merge PDFs; Split PDF; Extract Metadata; Rotate Pages; pdfplumber - Text and Table Extraction; Extract Text with Layout; Extract Tables; Advanced Table Extraction.

**Opening guidance (source excerpt):** This guide covers essential PDF processing operations using Python libraries and command-line tools. For advanced features, JavaScript libraries, and detailed examples, see REFERENCE.md. If you need to fill out a PDF form, read FORMS.md and follow its instructions.

**Resources:** scripts/: 8 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### plain-english-repo-explainer

[P131] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/plain-english-repo-explainer/SKILL.md`; modified UTC: 2026-10-07T06:07:03.316241+00:00; SHA-256: `a1fd3583ff5758eb5d25e775a616c3e0258271b6729fb49b8cee51c534f9c8cb`.

**Purpose:** Explain a repository in plain English, separate confirmed facts from assumptions, and name one evidence-backed next action. Use before changing an unfamiliar codebase.

**Contents:** Plain-English Repository Explainer; Safety boundary; Inspection workflow; Owner-facing output.

**Procedure cues (source excerpts):** Read the README and existing architecture, setup, handoff, and operational documents.; Identify the stack from manifests, lockfiles, build configuration, and deployment configuration.; Map the top-level directories and identify the main application entry points, routes, APIs, data models, background processes, integrations, tests, and build/deployment surfaces that are relevant to the user's question.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### pptx

[P140] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/pptx/SKILL.md`; modified UTC: 2026-10-07T06:07:03.543890+00:00; SHA-256: `2ea4e7b405c149e06117dbf471a44d6722a64967c4322fdb1041f699d3c13604`.

**Purpose:** Use this skill any time a .pptx or .potx file is involved in any way — as input, output, or both. This includes: creating slide decks, pitch decks, or presentations; reading, parsing, or extracting text from any .pptx or .potx file (even if the extracted content will be used elsewhere, like in an email or summary); editing, modifying, or updating existing presentations; combining or splitting slide files; working with templates (.potx), layouts, speaker notes, or comments. Trigger whenever the user mentions \"deck,\" \"slides,\" \"presentation,\" or references a .pptx or .potx filename, regardless of what they plan to do with the content afterward. If a .pptx or .potx file needs to be opened, created, or touched, use this skill.

**Contents:** PPTX creation, editing, and analysis; Scripts; Creating with pptxgenjs — gotchas; Editing existing decks and templates; reorder / delete slides = edit <p:sldIdLst> in ppt/presentation.xml; edit slide content in ppt/slides/slideN.xml; Design Ideas; Before Starting; Color Palettes; For Each Slide; Typography; Spacing; Avoid (Common Mistakes); QA (Required); Content QA.

**Opening guidance (source excerpt):** A `.pptx` is a ZIP archive of XML files. Choose your approach by task:

**Resources:** scripts/: 58 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### schedule

[P128] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/schedule/SKILL.md`; modified UTC: 2026-10-07T06:07:03.311723+00:00; SHA-256: `f22ae34af4c3a3e87ed1d14669bb285f0556012fcc722e7df3e60cae4557b434`.

**Purpose:** Create or update a scheduled task that runs automatically. Use when the user says things like \"every day\", \"each morning\", \"remind me in an hour\", \"run this at noon\", or wants to reschedule an existing task.

**Contents:** Updating an existing task; Creating a new task; 1. Analyze the session; 2. Draft a prompt; 3. Choose a taskName; 4. Determine scheduling.

**Opening guidance (source excerpt):** First, decide whether the user wants to **create a new** scheduled task or **change an existing** one.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### setup-cowork

[P130] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/setup-cowork/SKILL.md`; modified UTC: 2026-10-07T06:07:03.314726+00:00; SHA-256: `734d7a83fdfa8d9116741f8508338cc061c070756977acd464d82bf7217d933e`.

**Purpose:** Guided Cowork setup — install role-matched plugins, connect your tools, try a skill.

**Contents:** Setup Cowork; Step 0 — Checklist; Step 1 — Role; Step 2 — Suggest plugins; Step 3 — Connectors; Step 4 — Try a skill; Step 5 — Wrap; Ground rules.

**Procedure cues (source excerpts):** Figure out role; Suggest plugins; Suggest connectors

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### skill-creator

[P138] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/skill-creator/SKILL.md`; modified UTC: 2026-10-07T06:07:03.437139+00:00; SHA-256: `42765c880e446a83c85f7852fc77b43ecd46c76ca219d68051799ac7425e6943`.

**Purpose:** Create new skills, modify and improve existing skills, and measure skill performance. Use when users want to create a skill from scratch, edit, or optimize an existing skill, run evals to test a skill, benchmark skill performance with variance analysis, or optimize a skill's description for better triggering accuracy.

**Contents:** Skill Creator; Communicating with the user; Creating a skill; Capture Intent; Interview and Research; Write the SKILL.md; Skill Writing Guide; Anatomy of a Skill; Progressive Disclosure; Principle of Lack of Surprise; Writing Patterns; Report structure; [Title]; Executive summary; Key findings.

**Procedure cues (source excerpts):** What should this skill enable Claude to do?; When should this skill trigger? (what user phrases/contexts); What's the expected output format?

**Resources:** references/: 1 files; scripts/: 9 files; assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### transcript-to-workflow-opportunity-mapper

[P133] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/transcript-to-workflow-opportunity-mapper/SKILL.md`; modified UTC: 2026-10-07T06:07:03.342864+00:00; SHA-256: `80cca29d690e251ae6b4b0a10c66289028217deab38bfee6270a95b5d0e8a540`.

**Purpose:** Identify reusable workflows from transcripts or chats and recommend the smallest prompt, playbook, or skill. Use when deciding what work to systemize.

**Contents:** Transcript-to-Workflow Opportunity Mapper; Operating boundaries; Workflow; Required output; Workflow Opportunity Map — [Scope]; Executive Summary; Review Coverage; Candidate Workflows; External Skills to Evaluate; Build Now — One Item Only; KEEP / CUT / LATER; Next Owner Decision; Quality bar.

**Procedure cues (source excerpts):** **Define the review scope.** State which transcript(s), client/project, time period, and decision the user wants. If client/project ownership is unclear, label the material `AMBIGUOUS` and do not combine it with other sources.; **Extract candidate workflows.** Capture recurring or consequential work in this form:; **Separate one-offs from reusable work.** A workflow is a stronger candidate when it recurs in the transcript or across sources, has clear inputs/outputs, consumes meaningful time, produces consistent value, and can be bounded without broad permissions. Do not create a skill merely because a task is technical or interesting.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### xlsx

[P134] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/anthropic-skills/1.0.0/skills/xlsx/SKILL.md`; modified UTC: 2026-10-07T06:07:03.406984+00:00; SHA-256: `ab889634066161277624f383f8afa8145cbd68281f2785f4dfd3464270501fd7`.

**Purpose:** Use this skill any time a spreadsheet file is the primary input or output. This means any task where the user wants to: open, read, edit, or fix an existing .xlsx, .xlsm, .xltx, .csv, or .tsv file (e.g., adding columns, computing formulas, formatting, charting, cleaning messy data); create a new spreadsheet from scratch or from other data sources; or convert between tabular file formats. Trigger especially when the user references a spreadsheet file by name or path — even casually (like \"the xlsx in my downloads\") — and wants something done to it or produced from it. Also trigger for cleaning or restructuring messy tabular data files (malformed rows, misplaced headers, junk data) into proper spreadsheets. The deliverable must be a spreadsheet file. Do NOT trigger when the primary deliverable is a Word document, HTML report, standalone Python script, database pipeline, or Google Sheets API integration, even if tabular data is involved.

**Contents:** XLSX creation, editing, and analysis; Requirements for every output; Recalculate (mandatory whenever the file contains formulas); Choosing formulas that survive verification; openpyxl gotchas; Financial models; Dependencies.

**Opening guidance (source excerpt):** > Script paths below are relative to this skill's directory.

**Resources:** scripts/: 55 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / cowork-plugin-management / 0.2.2

### cowork-plugin-customizer

[P096] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/cowork-plugin-management/0.2.2/skills/cowork-plugin-customizer/SKILL.md`; modified UTC: 2026-10-07T06:07:03.316110+00:00; SHA-256: `d7a9455692f26479806b837aef09d4711b74f82b6e32ef304a5c33ae8feb441f`.

**Purpose:** Customize a Claude Code plugin for a specific organization's tools and workflows. Use when: customize plugin, set up plugin, configure plugin, tailor plugin, adjust plugin settings, customize plugin connectors, customize plugin skill, tweak plugin, modify plugin configuration.

**Contents:** Cowork Plugin Customization; Determining the Customization Mode; Customization Workflow; Phase 0: Gather User Intent (scoped and general customization only); Phase 1: Gather Context from Knowledge MCPs; Phase 2: Create Todo List; Phase 3: Complete Todo Items; Phase 4: Search for Useful MCPs; Packaging the Plugin; Summary Output; From searching Slack; From searching documents; From your answers; Additional Resources.

**Procedure cues (source excerpts):** **Chat/Slack MCPs** — tool mentions, integrations, workflow discussions; **Document MCPs** — onboarding docs, tool guides, setup instructions; **Email MCPs** — license notifications, admin emails, setup invitations

**Resources:** references/: 2 files; examples/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### create-cowork-plugin

[P097] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/cowork-plugin-management/0.2.2/skills/create-cowork-plugin/SKILL.md`; modified UTC: 2026-10-07T06:07:03.328576+00:00; SHA-256: `4769717426502a5517ae9d512095b49c223cccb0223e20268dfa6a44ef18ab94`.

**Purpose:** Guide users through creating a new plugin from scratch in a cowork session. Use when users want to create a plugin, build a plugin, make a new plugin, develop a plugin, scaffold a plugin, start a plugin from scratch, or design a plugin. This skill requires Cowork mode with access to the outputs directory for delivering the final .plugin file.

**Contents:** Create Cowork Plugin; Overview; Plugin Architecture; Directory Structure; plugin.json Manifest; Component Schemas; Customizable plugins with `~~` placeholders; Connectors; How tool references work; Connectors for this plugin; ${CLAUDE_PLUGIN_ROOT} Variable; Guided Workflow; Phase 1: Discovery; Phase 2: Component Planning; Phase 3: Design & Clarifying Questions.

**Procedure cues (source excerpts):** **Discovery** — understand what the user wants to build; **Component Planning** — determine which component types are needed; **Design & Clarifying Questions** — specify each component in detail

**Resources:** references/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / data / 1.1.0

### analyze

[P116] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/analyze/SKILL.md`; modified UTC: 2026-10-07T06:07:03.344765+00:00; SHA-256: `4ee816363d944c7a959e43384576d979a414f37fff7071c0bfb8935aae10143e`.

**Purpose:** Answer data questions -- from quick lookups to full analyses. Use when looking up a single metric, investigating what's driving a trend or drop, comparing segments over time, or preparing a formal data report for stakeholders.

**Contents:** /analyze - Answer Data Questions; Usage; Workflow; 1. Understand the Question; 2. Gather Data; 3. Analyze; 4. Validate Before Presenting; 5. Present Findings; 6. Visualize Where Helpful; Examples; Tips.

**Procedure cues (source excerpts):** Explore the schema to find relevant tables and columns; Write SQL query(ies) to extract the needed data; Execute the query and retrieve results

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### build-dashboard

[P111] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/build-dashboard/SKILL.md`; modified UTC: 2026-10-07T06:07:03.332536+00:00; SHA-256: `6f23faa0b266820a23096f76df9d83e6b67597af4fc8c3306b4eba7e9f409f99`.

**Purpose:** Build an interactive HTML dashboard with charts, filters, and tables. Use when creating an executive overview with KPI cards, turning query results into a shareable self-contained report, building a team monitoring snapshot, or needing multiple charts with filters in one browser-openable file.

**Contents:** /build-dashboard - Build Interactive Dashboards; Usage; Workflow; 1. Understand the Dashboard Requirements; 2. Gather the Data; 3. Design the Dashboard Layout; 4. Build the HTML Dashboard; 5. Implement Chart Types; 6. Add Interactivity; 7. Save and Open; Base Template; KPI Card Pattern; Chart.js Integration; Chart Container Pattern; Line Chart.

**Procedure cues (source excerpts):** Query the necessary data; Embed the results as JSON within the HTML file; Parse and clean the data

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### create-viz

[P114] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/create-viz/SKILL.md`; modified UTC: 2026-10-07T06:07:03.342969+00:00; SHA-256: `3b13a9c2c9d2b1d36f9c323d952d93f578216f2094bc80d4be6fd4ccbfe9b77d`.

**Purpose:** Create publication-quality visualizations with Python. Use when turning query results or a DataFrame into a chart, selecting the right chart type for a trend or comparison, generating a plot for a report or presentation, or needing an interactive chart with hover and zoom.

**Contents:** /create-viz - Create Visualizations; Usage; Workflow; 1. Understand the Request; 2. Get the Data; 3. Select Chart Type; 4. Generate the Visualization; Set professional style; Create figure with appropriate size; [chart-specific code]; Always include:; Format numbers appropriately; - Percentages: '45.2%' not '0.452'; - Currency: '$1.2M' not '1200000'; - Large numbers: '2.3K' or '1.5M' not '2300' or '1500000'.

**Procedure cues (source excerpts):** Write and execute the query; Load results into a pandas DataFrame; Parse the data into a pandas DataFrame

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### data-context-extractor

[P109] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/data-context-extractor/SKILL.md`; modified UTC: 2026-10-07T06:07:03.328981+00:00; SHA-256: `6d05dec52ac3667b551898b9eb943f5ee08141bc8d2fabb69a8e39bb9ce7c754`.

**Purpose:** Generate or improve a company-specific data analysis skill by extracting tribal knowledge from analysts. BOOTSTRAP MODE - Triggers: "Create a data context skill", "Set up data analysis for our warehouse", "Help me create a skill for our database", "Generate a data skill for [company]" → Discovers schemas, asks key questions, generates initial skill with reference files ITERATION MODE - Triggers: "Add context about [domain]", "The skill needs more info about [topic]", "Update the data skill with [metrics/tables/terminology]", "Improve the [domain] reference" → Loads existing skill, asks targeted questions, appends/updates reference files Use when data analysts want Claude to understand their company's specific data warehouse, terminology, metrics definitions, and common query patterns.

**Contents:** Data Context Extractor; How It Works; Bootstrap Mode; Phase 1: Database Connection & Discovery; Phase 2: Core Questions (Ask These); Phase 3: Generate the Skill; Phase 4: Package and Deliver; Iteration Mode; Step 1: Load Existing Skill; Step 2: Identify the Gap; Step 3: Targeted Discovery; Step 4: Update and Repackage; Reference File Standards; For Table Documentation; For Metrics Documentation.

**Procedure cues (source excerpts):** **Bootstrap Mode**: Create a new data analysis skill from scratch; **Iteration Mode**: Improve an existing skill by adding domain-specific reference files; List available datasets/schemas

**Resources:** references/: 4 files; scripts/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### data-visualization

[P112] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/data-visualization/SKILL.md`; modified UTC: 2026-10-07T06:07:03.340525+00:00; SHA-256: `5811e8b3547cda6bc8af118aaf0d7589e8861cdc9facce6372dc78aea99ab87d`.

**Purpose:** Create effective data visualizations with Python (matplotlib, seaborn, plotly). Use when building charts, choosing the right chart type for a dataset, creating publication-quality figures, or applying design principles like accessibility and color theory.

**Contents:** Data Visualization Skill; Chart Selection Guide; Choose by Data Relationship; When NOT to Use Certain Charts; Python Visualization Code Patterns; Setup and Style; Professional style setup; Colorblind-friendly palettes; Line Chart (Time Series); Format dates on x-axis; Bar Chart (Comparison); Sort by value for easy reading; Add value labels; Histogram (Distribution); Add mean and median lines.

**Opening guidance (source excerpt):** Chart selection guidance, Python visualization code patterns, design principles, and accessibility considerations for creating effective data visualizations.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### explore-data

[P113] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/explore-data/SKILL.md`; modified UTC: 2026-10-07T06:07:03.341834+00:00; SHA-256: `af7590fa616360259da712b5ede5f79b817beb854c47a465f95774354988e8a2`.

**Purpose:** Profile and explore a dataset to understand its shape, quality, and patterns. Use when encountering a new table or file, checking null rates and column distributions, spotting data quality issues like duplicates or suspicious values, or deciding which dimensions and metrics to analyze.

**Contents:** /explore-data - Profile and Explore a Dataset; Usage; Workflow; 1. Access the Data; 2. Understand Structure; 3. Generate Data Profile; 4. Identify Data Quality Issues; 5. Discover Relationships and Patterns; 6. Suggest Interesting Dimensions and Metrics; 7. Recommend Follow-Up Analyses; Output Format; Data Profile: [table_name]; Overview; Column Details; Data Quality Issues.

**Procedure cues (source excerpts):** Resolve the table name (handle schema prefixes, suggest matches if ambiguous); Query table metadata: column names, types, descriptions if available; Run profiling queries against the live data

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### sql-queries

[P110] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/sql-queries/SKILL.md`; modified UTC: 2026-10-07T06:07:03.330956+00:00; SHA-256: `dbd5a5e2d563d83ca6d4d033206f285f503296eabff4a35545cdb4cb5302bd9a`.

**Purpose:** Write correct, performant SQL across all major data warehouse dialects (Snowflake, BigQuery, Databricks, PostgreSQL, etc.). Use when writing queries, optimizing slow SQL, translating between dialects, or building complex analytical queries with CTEs, window functions, or aggregations.

**Contents:** SQL Queries Skill; Dialect-Specific Reference; PostgreSQL (including Aurora, RDS, Supabase, Neon); Snowflake; BigQuery (Google Cloud); Redshift (Amazon); Databricks SQL; Common SQL Patterns; Window Functions; CTEs for Readability; Cohort Retention; Funnel Analysis; Deduplication; Error Handling and Debugging.

**Procedure cues (source excerpts):** **Syntax errors**: Check for dialect-specific syntax (e.g., `ILIKE` not available in BigQuery, `SAFE_DIVIDE` only in BigQuery); **Column not found**: Verify column names against schema -- check for typos, case sensitivity (PostgreSQL is case-sensitive for quoted identifiers); **Type mismatches**: Cast explicitly when comparing different types (`CAST(col AS DATE)`, `col::DATE`)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### statistical-analysis

[P115] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/statistical-analysis/SKILL.md`; modified UTC: 2026-10-07T06:07:03.343881+00:00; SHA-256: `91a15cfc144efffcd622b09827362a73993a3ff30e3a78114801832477c9f8a0`.

**Purpose:** Apply statistical methods including descriptive stats, trend analysis, outlier detection, and hypothesis testing. Use when analyzing distributions, testing for significance, detecting anomalies, computing correlations, or interpreting statistical results.

**Contents:** Statistical Analysis Skill; Descriptive Statistics Methodology; Central Tendency; Spread and Variability; Percentiles for Business Context; Describing Distributions; Trend Analysis and Forecasting; Identifying Trends; 7-day moving average (good for daily data with weekly seasonality); 28-day moving average (smooths weekly AND monthly patterns); Seasonality Detection; Forecasting (Simple Methods); Outlier and Anomaly Detection; Statistical Methods; Handling Outliers.

**Procedure cues (source excerpts):** Plot the raw time series -- visual inspection first; Compute day-of-week averages: is there a clear weekly pattern?; Compute month-of-year averages: is there an annual cycle?

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### validate-data

[P108] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/validate-data/SKILL.md`; modified UTC: 2026-10-07T06:07:03.314630+00:00; SHA-256: `1e424822043480375b80aef9416227b1c8083af749ca536568716265f79ca54b`.

**Purpose:** QA an analysis before sharing -- methodology, accuracy, and bias checks. Use when reviewing an analysis before a stakeholder presentation, spot-checking calculations and aggregation logic, verifying a SQL query's results look right, or assessing whether conclusions are actually supported by the data.

**Contents:** /validate-data - Validate Analysis Before Sharing; Usage; Workflow; 1. Review Methodology and Assumptions; 2. Run the Pre-Delivery QA Checklist; 3. Check for Common Analytical Pitfalls; 4. Verify Calculations and Aggregations; 5. Assess Visualizations; 6. Evaluate Narrative and Conclusions; 7. Suggest Improvements; 8. Generate Confidence Assessment; Output Format; Validation Report; Overall Assessment: [Ready to share \| Share with caveats \| Needs revision]; Methodology Review.

**Procedure cues (source excerpts):** [Severity: High/Medium/Low] [Issue description and impact]; ...; [Improvement and why it matters]

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### write-query

[P107] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/data/1.1.0/skills/write-query/SKILL.md`; modified UTC: 2026-10-07T06:07:03.313138+00:00; SHA-256: `4c7ef791db1f23504c457cc52de0d8855d26f176d5acf037260deb1b98e5e34e`.

**Purpose:** Write optimized SQL for your dialect with best practices. Use when translating a natural-language data need into SQL, building a multi-CTE query with joins and aggregations, optimizing a query against a large partitioned table, or getting dialect-specific syntax for Snowflake, BigQuery, Postgres, etc.

**Contents:** /write-query - Write Optimized SQL; Usage; Workflow; 1. Understand the Request; 2. Determine SQL Dialect; 3. Discover Schema (If Warehouse Connected); 4. Write the Query; 5. Present the Query; 6. Offer to Execute; Examples; Tips.

**Procedure cues (source excerpts):** Search for relevant tables based on the user's description; Inspect column names, types, and relationships; Check for partitioning or clustering keys that affect performance

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / design / 1.2.0

### accessibility-review

[P088] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/accessibility-review/SKILL.md`; modified UTC: 2026-10-07T06:07:03.327663+00:00; SHA-256: `ef42982af0d51238dda2ab16d08626712891bdd41864876c32d1e7b13fb3124f`.

**Purpose:** Run a WCAG 2.1 AA accessibility audit on a design or page. Trigger with "audit accessibility", "check a11y", "is this accessible?", or when reviewing a design for color contrast, keyboard navigation, touch target size, or screen reader behavior before handoff.

**Contents:** /accessibility-review; Usage; WCAG 2.1 AA Quick Reference; Perceivable; Operable; Understandable; Robust; Common Issues; Testing Approach; Output; Accessibility Audit: [Design/Page Name]; Summary; Findings; Perceivable; Operable.

**Procedure cues (source excerpts):** Insufficient color contrast; Missing form labels; No keyboard access to interactive elements

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### design-critique

[P087] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/design-critique/SKILL.md`; modified UTC: 2026-10-07T06:07:03.326059+00:00; SHA-256: `3a4f260eb9f60b431782bf6d90f22afb480c0c67860267a032df58a3e1bd19cd`.

**Purpose:** Get structured design feedback on usability, hierarchy, and consistency. Trigger with "review this design", "critique this mockup", "what do you think of this screen?", or when sharing a Figma link or screenshot for feedback at any stage from exploration to final polish.

**Contents:** /design-critique; Usage; What I Need From You; Critique Framework; 1. First Impression (2 seconds); 2. Usability; 3. Visual Hierarchy; 4. Consistency; 5. Accessibility; How to Give Feedback; Output; Design Critique: [Design Name]; Overall Impression; Usability; Visual Hierarchy.

**Procedure cues (source excerpts):** **[Most impactful change]** — [Why and how]; **[Second priority]** — [Why and how]; **[Third priority]** — [Why and how]

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### design-handoff

[P086] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/design-handoff/SKILL.md`; modified UTC: 2026-10-07T06:07:03.317455+00:00; SHA-256: `38f1efc807928030654218443ad07f6a37ac82de6b4d627a03113a3568d787b7`.

**Purpose:** Generate developer handoff specs from a design. Use when a design is ready for engineering and needs a spec sheet covering layout, design tokens, component props, interaction states, responsive breakpoints, edge cases, and animation details.

**Contents:** /design-handoff; Usage; What to Include; Visual Specifications; Interaction Specifications; Content Specifications; Edge Cases; Accessibility; Principles; Output; Handoff Spec: [Feature/Screen Name]; Overview; Layout; Design Tokens Used; Components.

**Procedure cues (source excerpts):** **Don't assume** — If it's not specified, the developer will guess. Specify everything.; **Use tokens, not values** — Reference `spacing-md` not `16px`.; **Show all states** — Default, hover, active, disabled, loading, error, empty.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### design-system

[P089] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/design-system/SKILL.md`; modified UTC: 2026-10-07T06:07:03.329825+00:00; SHA-256: `fb31bd0144c43955106f01927126ae9fd2d4148be44c8d5887b3391f40c31445`.

**Purpose:** Audit, document, or extend your design system. Use when checking for naming inconsistencies or hardcoded values across components, writing documentation for a component's variants, states, and accessibility notes, or designing a new pattern that fits the existing system.

**Contents:** /design-system; Usage; Components of a Design System; Design Tokens; Components; Patterns; Principles; Output — Audit; Design System Audit; Summary; Naming Consistency; Token Coverage; Component Completeness; Priority Actions; Output — Document.

**Procedure cues (source excerpts):** **Consistency over creativity** — The system exists so teams don't reinvent the wheel; **Flexibility within constraints** — Components should be composable, not rigid; **Document everything** — If it's not documented, it doesn't exist

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### research-synthesis

[P084] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/research-synthesis/SKILL.md`; modified UTC: 2026-10-07T06:07:03.313735+00:00; SHA-256: `40048615dc81fc8b9b06104769498214d61a35ae4518a0995a12bbbd0ab945a1`.

**Purpose:** Synthesize user research into themes, insights, and recommendations. Use when you have interview transcripts, survey results, usability test notes, support tickets, or NPS responses that need to be distilled into patterns, user segments, and prioritized next steps.

**Contents:** /research-synthesis; Usage; What I Accept; Output; Research Synthesis: [Study Name]; Executive Summary; Key Themes; Theme 1: [Name]; Theme 2: [Name]; Insights → Opportunities; User Segments Identified; Recommendations; Questions for Further Research; Methodology Notes; If Connectors Available.

**Procedure cues (source excerpts):** **[High priority]** — [Why, based on which findings]; **[Medium priority]** — [Why]; **[Lower priority]** — [Why]

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### user-research

[P083] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/user-research/SKILL.md`; modified UTC: 2026-10-07T06:07:03.312175+00:00; SHA-256: `fa18fc13d0f44aa869102962ef9466417ade726d659465195a40fbcf08cee156`.

**Purpose:** Plan, conduct, and synthesize user research. Trigger with "user research plan", "interview guide", "usability test", "survey design", "research questions", or when the user needs help with any aspect of understanding their users through research.

**Contents:** User Research; Research Methods; Interview Guide Structure; Analysis Framework; Deliverables.

**Procedure cues (source excerpts):** **Warm-up** (5 min): Build rapport, explain the session; **Context** (10 min): Understand their current workflow; **Deep dive** (20 min): Explore the specific topic

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### ux-copy

[P085] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/design/1.2.0/skills/ux-copy/SKILL.md`; modified UTC: 2026-10-07T06:07:03.315526+00:00; SHA-256: `d46a00a62ec637e9ca9d5f7823ea3e0a4ec26dffc53bb5035f59b48ebfcdcde7`.

**Purpose:** Write or review UX copy — microcopy, error messages, empty states, CTAs. Trigger with "write copy for", "what should this button say?", "review this error message", or when naming a CTA, wording a confirmation dialog, filling an empty state, or writing onboarding text.

**Contents:** /ux-copy; Usage; What I Need From You; Principles; Copy Patterns; CTAs; Error Messages; Empty States; Confirmation Dialogs; Tooltips; Loading States; Onboarding; Voice and Tone; Output; UX Copy: [Context].

**Procedure cues (source excerpts):** **Clear**: Say exactly what you mean. No jargon, no ambiguity.; **Concise**: Use the fewest words that convey the full meaning.; **Consistent**: Same terms for the same things everywhere.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / desktop-commander / 0.2.0

### ai-tools-setup

[P090] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/ai-tools-setup/SKILL.md`; modified UTC: 2026-10-07T06:07:03.314955+00:00; SHA-256: `092d4e9aeb5e74c2c3bb6781d70aa5c59fcc33cbf7d0c19c3d96d6b70b1ad058`.

**Purpose:** Set up, connect, validate, and repair Claude Desktop and MCP servers using Desktop Commander — inspecting and fixing mcp.json / claude_desktop_config.json, getting MCP servers to connect, and diagnosing local AI tooling. Use when a user wants to install, configure, connect, validate, or fix Claude Desktop, an MCP server, an MCP config file, or a local AI agent/gateway. Trigger on the symptoms that actually bring people in: "Claude can''t see my tools", "my MCP server isn''t showing up", "tools aren''t loading in Claude", "add an MCP server", "my MCP isn''t connecting", "fix my Claude Desktop config", "the agent won''t respond", "wire up Ollama / LM Studio", "restart Claude Desktop". Also covers local agent gateways like OpenClaw and Hermes.

**Contents:** AI Tools Setup Assistant; Golden rules (read before doing anything); What this skill covers; General workflow; A generic "my agent isn't responding" diagnostic.

**Procedure cues (source excerpts):** **Detect the OS and shell first.** Read `get_config` and use its `systemInfo`; **Verify the model/API key works before you build.** The most common reason; **Translate errors, don't dump them.** When a tool returns a raw JSON/HTTP

**Resources:** references/: 3 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### computer-health-check

[P092] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/computer-health-check/SKILL.md`; modified UTC: 2026-10-07T06:07:03.328441+00:00; SHA-256: `4549f6b010b662aa671639340b0a974e025d623041f1a5b0f07386ceba850b1b`.

**Purpose:** Run a comprehensive, read-only health check on the user''s computer and return a scored chat summary with prioritized, plain-English recommendations and safe cleanup suggestions. Use this whenever the user wants to check their computer''s health, speed it up, free up / reclaim disk space, find what''s eating CPU / memory / storage, check battery health and wear, audit login & startup items, see pending updates, or asks for a "tune-up", "checkup", "system report", "health check", or "is my Mac/PC/laptop healthy". Trigger even on casual phrasing like "my laptop feels slow", "why is my fan so loud", "my computer is laggy", "running out of space", or "clean up my machine". Works on macOS, Windows, and Linux. This is a Desktop Commander skill: it relies on a real local shell (start_process / interact_with_process) and is strictly read-only by default — it never needs sudo and only performs cleanups the user explicitly approves.

**Contents:** Computer Health Check; What this skill does; The safety contract (read this first); Workflow; Step 1 — Detect the OS; Step 2 — Collect (read-only); Step 3 — Score each area; Step 4 — Report in the chat; Step 5 — Suggest cleanups, execute only on approval; Recommendation rules (findings → advice); Notes & pitfalls.

**Procedure cues (source excerpts):** <highest-impact action> (<expected benefit, e.g. frees ~13 GB>); <next>; <next>

**Resources:** references/: 3 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### desktop-commander-overview

[P094] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/desktop-commander-overview/SKILL.md`; modified UTC: 2026-10-07T06:07:03.331692+00:00; SHA-256: `03db6ea8a72dc9d2c4f75af799fd1da98e99b6edc5b84cfb5e028d12198bbbb0`.

**Purpose:** Use for Desktop Commander MCP capabilities — persistent shells and REPLs, long-running processes, filesystem beyond the workspace, structured files (.xlsx, .docx, .pdf, images) and large local data files such as CSVs, ripgrep search at scale, SSH, or cross-turn state.

**Contents:** Desktop Commander MCP; What this MCP gives the agent; Example workflows; "Debug this production issue"; "Deploy this to staging"; "Run the dev server and iterate on the API"; "Refactor across this monorepo"; "Update the Q3 numbers in this spreadsheet and tweak the summary in the report"; "Generate the Q3 report as a PDF"; "Insert a cover page into this PDF"; "Analyze this 200MB CSV"; "Run a quick Node script"; "Explain this codebase"; "Organize my Downloads folder"; "Onboard me — what was happening last session?".

**Opening guidance (source excerpt):** Desktop Commander gives the agent reach across the user's actual computer — files, folders, terminals, processes, structured documents, and remote machines reachable over SSH. The tools' detailed schemas (parameters, return shapes, format-specific behavior) live in the MCP itself; this skill explains what they enable and how they compose into common workflows.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### knowledge-base

[P095] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/knowledge-base/SKILL.md`; modified UTC: 2026-10-07T06:07:03.332737+00:00; SHA-256: `d2c0bef40b7483e467c3c6fc2d2eab8a53d707528066aec44bc69a0ff4746c36`.

**Purpose:** Create and maintain a Markdown knowledge base that any AI agent can read, search, and update. Use when the user wants to start a knowledge base, add or update notes, organize docs/notes for an agent or LLM to consume, build an index of notes, or run a cleanup/maintenance pass on an existing MD knowledge base. Triggers include "knowledge base", "KB", "notes for the agent", "index of notes", "second brain", "docs for AI context", "add a note", "update the KB".

**Contents:** Knowledge Base (Markdown, agent-readable); Core principles (the "why"); Folder structure (nested by topic); Naming rules; Required frontmatter (every note); Note body shape; Session tokens; Context; Details; Related; INDEX.md (the single source of truth); Knowledge Base — Index; How to use this KB (for agents); How to update this KB (for agents); Controlled tags.

**Procedure cues (source excerpts):** **Index-first navigation.** The index is a map, not a container. An agent; **Atomicity.** One topic per note. If a title needs an "and", it's probably; **Stable IDs.** Every note has a permanent ID that never changes and is never

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### obsidian-vault

[P091] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/obsidian-vault/SKILL.md`; modified UTC: 2026-10-07T06:07:03.316745+00:00; SHA-256: `5fe7475f23fe6ffc2128bd55c78382af025733e1f1befb50be0caa9a61d44532`.

**Purpose:** Organize Obsidian vaults with MOCs, wikilinks, frontmatter/properties, dashboards, orphan-note checks, and cleanup workflows. Use ONLY when the user explicitly refers to Obsidian — by naming "Obsidian", an Obsidian "vault", or an Obsidian-specific feature such as wikilinks ("[[ ]]"), the Dataview or Bases plugins, or Obsidian Properties. Within that Obsidian context it covers creating Maps of Content, adding/fixing wikilinks, finding orphan notes, normalizing YAML frontmatter, generating Dataview/Bases dashboards, organizing folders, deduplicating or renaming notes, and preparing the vault for AI use. Do NOT use this skill for generic note-taking, Markdown, or knowledge-base requests that don't mention Obsidian.

**Contents:** Obsidian Vault Assistant; Wikilinks; Maps of Content (MOCs); Auth — Map of Content; Core; Related MOCs; Frontmatter / Properties; Dashboards; Orphan notes & link hygiene; Folder organization; Deduplicate & rename; Prepare the vault for AI use; Workflows; Checklist before finishing.

**Procedure cues (source excerpts):** **From Desktop Commander** (no app needed, scales to big vaults): `start_search`; **Graph view** (Cmd/Ctrl+G): orphans float as isolated dots at the edges.; **Dataview** query for notes with no links:

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### terminal

[P093] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/desktop-commander/0.2.0/skills/terminal/SKILL.md`; modified UTC: 2026-10-07T06:07:03.330337+00:00; SHA-256: `fbece5325185b6e656f523d1b94ea0aade5ad89f111f366d4dec4525c349d97c`.

**Purpose:** Use Desktop Commander for terminal and command-line work, especially anything that needs a shell whose state persists across turns: Python/Node REPLs, database shells, dev servers and other long-running processes, SSH into remote machines, and Windows PowerShell. Also handles everyday terminal tasks — navigating folders, choosing the right command for the user''s shell (PowerShell, cmd, bash, zsh), running Docker/curl/cloud-CLI commands, inspecting processes and ports, and saving recurring workflows as scripts — even when the user doesn''t say "Desktop Commander" or "terminal." Reach for it on pasted errors like "command not found", "permission denied", "EADDRINUSE", "address already in use", "npm ERR!", "ModuleNotFoundError", or "ENOENT", and on intents like "what''s using port 3000", "kill that process", "ssh into my server", or "why won''t my dev server start". Works on Windows, macOS, and Linux. Never run destructive commands without explicit confirmation.

**Contents:** Terminal Command Assistant; 1. Detect the environment first (do this before suggesting commands); 2. Choosing the right command for the shell; 3. Running commands with Desktop Commander; Interactive REPL pattern (the workhorse); 4. Running specific CLIs; 5. Inspecting processes and ports; 6. Explaining errors in plain English; 7. Safety: destructive commands and chaining; 8. Turning repeated workflows into scripts; Operating etiquette.

**Procedure cues (source excerpts):** Read the **actual** error text from the process output — the real cause is; Name the cause in one plain sentence (e.g. "the port's already taken",; Give the concrete fix command for *their* shell, and explain what it does.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / engineering / 1.2.0

### architecture

[P122] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/architecture/SKILL.md`; modified UTC: 2026-10-07T06:07:03.328693+00:00; SHA-256: `de7db3170a3ae1a894c70ef6cb555fe15618ed9b9674d20895eda3d2a0a5f9a2`.

**Purpose:** Create or evaluate an architecture decision record (ADR). Use when choosing between technologies (e.g., Kafka vs SQS), documenting a design decision with trade-offs and consequences, reviewing a system design proposal, or designing a new component from requirements and constraints.

**Contents:** /architecture; Usage; Modes; Output — ADR Format; ADR-[number]: [Title]; Context; Decision; Options Considered; Option A: [Name]; Option B: [Name]; Trade-off Analysis; Consequences; Action Items; If Connectors Available; Tips.

**Procedure cues (source excerpts):** [ ] [Implementation step]; [ ] [Follow-up]; **State constraints upfront** — "We need to ship in 2 weeks" or "Must handle 10K rps" shapes the answer.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### code-review

[P119] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/code-review/SKILL.md`; modified UTC: 2026-10-07T06:07:03.316155+00:00; SHA-256: `6303932f1b301c614a6f5a0099cd87a19e1cd1b7cbfa1a1e11e996edbca6426b`.

**Purpose:** Review code changes for security, performance, and correctness. Trigger with a PR URL or diff, "review this before I merge", "is this code safe?", or when checking a change for N+1 queries, injection risks, missing edge cases, or error handling gaps.

**Contents:** /code-review; Usage; How It Works; Review Dimensions; Security; Performance; Correctness; Maintainability; Output; Code Review: [PR title or file]; Summary; Critical Issues; Suggestions; What Looks Good; Verdict.

**Procedure cues (source excerpts):** **Provide context** — "This is a hot path" or "This handles PII" helps me focus.; **Specify concerns** — "Focus on security" narrows the review.; **Include tests** — I'll check test coverage and quality too.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### debug

[P126] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/debug/SKILL.md`; modified UTC: 2026-10-07T06:07:03.340486+00:00; SHA-256: `e50bb92cbcb2715139f3a3cb9ff282a8f0f9ae794f8f35d81338654e2601d32a`.

**Purpose:** Structured debugging session — reproduce, isolate, diagnose, and fix. Trigger with an error message or stack trace, "this works in staging but not prod", "something broke after the deploy", or when behavior diverges from expected and the cause isn't obvious.

**Contents:** /debug; Usage; How It Works; What I Need From You; Output; Debug Report: [Issue Summary]; Reproduction; Root Cause; Fix; Prevention; If Connectors Available; Tips.

**Procedure cues (source excerpts):** **Share error messages exactly** — Don't paraphrase. The exact text matters.; **Mention what changed** — Recent deploys, dependency updates, and config changes are top suspects.; **Include context** — "This works in staging but not prod" or "Only affects large payloads" narrows things fast.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### deploy-checklist

[P124] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/deploy-checklist/SKILL.md`; modified UTC: 2026-10-07T06:07:03.331665+00:00; SHA-256: `85ca53dc471970e3e12c36ec814ebf5f6cb9419016c55adb05ff34789bae3be9`.

**Purpose:** Pre-deployment verification checklist. Use when about to ship a release, deploying a change with database migrations or feature flags, verifying CI status and approvals before going to production, or documenting rollback triggers ahead of time.

**Contents:** /deploy-checklist; Usage; Output; Deploy Checklist: [Service/Release]; Pre-Deploy; Deploy; Post-Deploy; Rollback Triggers; Customization; If Connectors Available; Tips.

**Procedure cues (source excerpts):** **Run before every deploy** — Even routine ones. Checklists prevent "I forgot to..."; **Customize once, reuse** — Tell me your stack and I'll remember your deploy process.; **Include rollback criteria** — Decide when to roll back before you deploy, not during.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### documentation

[P117] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/documentation/SKILL.md`; modified UTC: 2026-10-07T06:07:03.313030+00:00; SHA-256: `1d469418f786a05be83d2a05f04d68788aeed584d13863a650f5ad73c6c4cf50`.

**Purpose:** Write and maintain technical documentation. Trigger with "write docs for", "document this", "create a README", "write a runbook", "onboarding guide", or when the user needs help with any form of technical writing — API docs, architecture docs, or operational runbooks.

**Contents:** Technical Documentation; Document Types; README; API Documentation; Runbook; Architecture Doc; Onboarding Guide; Principles.

**Procedure cues (source excerpts):** **Write for the reader** — Who is reading this and what do they need?; **Start with the most useful information** — Don't bury the lede; **Show, don't tell** — Code examples, commands, screenshots

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### incident-response

[P118] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/incident-response/SKILL.md`; modified UTC: 2026-10-07T06:07:03.314542+00:00; SHA-256: `9eaa7a974c90395ac7116e82710f74546f38e69f735d78f684ee13fd79646e9a`.

**Purpose:** Run an incident response workflow — triage, communicate, and write postmortem. Trigger with "we have an incident", "production is down", an alert that needs severity assessment, a status update mid-incident, or when writing a blameless postmortem after resolution.

**Contents:** /incident-response; Usage; Modes; How It Works; Severity Classification; Communication Guidance; Output — Status Update; Incident Update: [Title]; Current Status; Actions Taken; Next Steps; Timeline; Output — Postmortem; Postmortem: [Incident Title]; Summary.

**Procedure cues (source excerpts):** Why did [symptom]? → [Because...]; Why did [cause 1]? → [Because...]; Why did [cause 2]? → [Because...]

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### standup

[P121] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/standup/SKILL.md`; modified UTC: 2026-10-07T06:07:03.326759+00:00; SHA-256: `598d9082631326ee810056c787188ee021c6325f990989732ba178ea111adf45`.

**Purpose:** Generate a standup update from recent activity. Use when preparing for daily standup, summarizing yesterday's commits and PRs and ticket moves, formatting work into yesterday/today/blockers, or structuring a few rough notes into a shareable update.

**Contents:** /standup; How It Works; What I Need From You; Output; Standup — [Date]; Yesterday; Today; Blockers; If Connectors Available; Tips.

**Procedure cues (source excerpts):** **Run it every morning** — Build a habit and never scramble for standup notes.; **Add context** — After I generate, add any nuance about blockers or priorities.; **Share format** — Ask me to format for Slack, email, or your team's standup tool.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### system-design

[P125] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/system-design/SKILL.md`; modified UTC: 2026-10-07T06:07:03.332586+00:00; SHA-256: `8f28eca99f2208872fc2483fcc93326b628f4f73116e91309a95e05da86a0ab5`.

**Purpose:** Design systems, services, and architectures. Trigger with "design a system for", "how should we architect", "system design for", "what's the right architecture for", or when the user needs help with API design, data modeling, or service boundaries.

**Contents:** System Design; Framework; 1. Requirements Gathering; 2. High-Level Design; 3. Deep Dive; 4. Scale and Reliability; 5. Trade-off Analysis; Output.

**Opening guidance (source excerpt):** Help design systems and evaluate architectural decisions.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### tech-debt

[P120] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/tech-debt/SKILL.md`; modified UTC: 2026-10-07T06:07:03.318072+00:00; SHA-256: `ed3b4b1450c0fd9b8dad17313b5a4fafd8e6947d380b79b36a2e8259f3b1df0f`.

**Purpose:** Identify, categorize, and prioritize technical debt. Trigger with "tech debt", "technical debt audit", "what should we refactor", "code health", or when the user asks about code quality, refactoring priorities, or maintenance backlog.

**Contents:** Tech Debt Management; Categories; Prioritization Framework; Output.

**Opening guidance (source excerpt):** Systematically identify, categorize, and prioritize technical debt.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### testing-strategy

[P123] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/engineering/1.2.0/skills/testing-strategy/SKILL.md`; modified UTC: 2026-10-07T06:07:03.330386+00:00; SHA-256: `5c5e95830754bbdd838213fa05fc8f07523f591fd558fd3c86031ffd479f7a9e`.

**Purpose:** Design test strategies and test plans. Trigger with "how should we test", "test strategy for", "write tests for", "test plan", "what tests do we need", or when the user needs help with testing approaches, coverage, or test architecture.

**Contents:** Testing Strategy; Testing Pyramid; Strategy by Component Type; What to Cover; Output.

**Opening guidance (source excerpt):** Design effective testing strategies balancing coverage, speed, and maintenance.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / marketing / 1.2.0

### brand-review

[P103] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/brand-review/SKILL.md`; modified UTC: 2026-10-07T06:07:03.328289+00:00; SHA-256: `759f29397a908c32521080247292a4e1c52ac01643bea70ccd6e807e86c1fa4b`.

**Purpose:** Review content against your brand voice, style guide, and messaging pillars, flagging deviations by severity with specific before/after fixes. Use when checking a draft before it ships, when auditing copy for voice consistency and terminology, or when screening for unsubstantiated claims, missing disclaimers, and other legal flags.

**Contents:** Brand Review; Trigger; Inputs; Review Process; With Brand Guidelines Configured; Voice and Tone; Terminology and Language; Messaging Pillars; Style Guide Compliance; Without Brand Guidelines (Generic Review); Clarity; Consistency; Professionalism; Legal and Compliance Flags (Always Checked); Brand Voice Reference.

**Procedure cues (source excerpts):** **Content to review** — accept content in any of these forms:; **Brand guidelines source** (determined automatically):; **Brand Personality** — Define the brand as if it were a person. Example: "If our brand were a person, they would be a knowledgeable colleague who explains complex things simply, celebrates your wins genuinely, and never talks down to you."

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### campaign-plan

[P105] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/campaign-plan/SKILL.md`; modified UTC: 2026-10-07T06:07:03.332016+00:00; SHA-256: `f0b146074b64ee0fd52f7864e30191eab83878c8c1e3e7cf24754e13c7dbfad3`.

**Purpose:** Generate a full campaign brief with objectives, audience, messaging, channel strategy, content calendar, and success metrics. Use when planning a product launch, lead-gen push, or awareness campaign, when you need a week-by-week content calendar with dependencies, or when translating a marketing goal into a structured, executable plan.

**Contents:** Campaign Plan; Trigger; Inputs; Campaign Brief Structure; 1. Campaign Overview; 2. Target Audience; 3. Key Messages; 4. Channel Strategy; 5. Content Calendar; 6. Content Pieces Needed; 7. Success Metrics; 8. Budget Allocation (if budget provided); 9. Risks and Mitigations; 10. Next Steps; Planning Reference.

**Procedure cues (source excerpts):** **Campaign goal** — the primary objective (e.g., drive signups, increase awareness, launch a product, generate leads, re-engage churned users); **Target audience** — who the campaign is aimed at (demographics, roles, industries, pain points, buying stage); **Timeline** — campaign duration and any fixed dates (launch date, event date, seasonal deadline)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### competitive-brief

[P104] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/competitive-brief/SKILL.md`; modified UTC: 2026-10-07T06:07:03.330453+00:00; SHA-256: `c1e5442facbc3206ac6a77392bef009fe9aff4ba7c2678e2f4118be2f6be82b3`.

**Purpose:** Research competitors and generate a positioning and messaging comparison with content gaps, opportunities, and threats. Use when building sales battlecards, when finding positioning gaps and messaging angles competitors haven't claimed, or when a competitor makes a move and you need to assess the impact.

**Contents:** Competitive Brief; Trigger; Inputs; Research Process; Research Sources; Primary Sources (Direct from Competitor); Secondary Sources (Third-Party); Research Cadence; Competitive Brief Structure; 1. Executive Summary; 2. Competitor Profiles; Company Overview; Messaging Analysis; Product/Solution Positioning; Content Strategy.

**Procedure cues (source excerpts):** **Competitor name(s)** — one or more competitors to analyze (required); **Your company/product context** (optional but recommended):; **Focus areas** (optional — if not specified, cover all):

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### content-creation

[P099] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/content-creation/SKILL.md`; modified UTC: 2026-10-07T06:07:03.313907+00:00; SHA-256: `17f0bfd536502a91c760accaa1ae6c0c76c3812973571729664133e282c5dded`.

**Purpose:** Draft marketing content across channels — blog posts, social media, email newsletters, landing pages, press releases, and case studies. Use when writing any marketing content, when you need channel-specific formatting, SEO-optimized copy, headline options, or calls to action.

**Contents:** Content Creation Skill; Content Type Templates; Blog Post Structure; Social Media Post Structure; Email Newsletter Structure; Landing Page Structure; Press Release Structure; Case Study Structure; Writing Best Practices by Channel; Blog; Social Media; Email; Web (Landing Pages, Product Pages); SEO Fundamentals for Content; Keyword Strategy.

**Procedure cues (source excerpts):** **Headline** — clear, benefit-driven, includes primary keyword (aim for 60 characters or less for SEO); **Introduction** (100-150 words) — hook the reader with a question, statistic, bold claim, or relatable scenario. State what the post will cover. Include primary keyword.; **Body sections** (3-5 sections) — each with a descriptive subheading (H2). Use H3 for subsections. One core idea per section with supporting evidence, examples, or data.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### draft-content

[P100] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/draft-content/SKILL.md`; modified UTC: 2026-10-07T06:07:03.315867+00:00; SHA-256: `0bfe029dcc039ff71a76b0fec3c5d900fba0e447eb9dcd505ab25b14be3577fd`.

**Purpose:** Draft blog posts, social media, email newsletters, landing pages, press releases, and case studies with channel-specific formatting and SEO recommendations. Use when writing any marketing content, when you need headline or subject line options, or when adapting a message for a specific platform, audience, and brand voice.

**Contents:** Draft Content; Trigger; Inputs; Brand Voice; Content Generation by Type; Blog Post; Social Media Post; Email Newsletter; Landing Page Copy; Press Release; Case Study; SEO Considerations (for web content); Output.

**Procedure cues (source excerpts):** **Content type** — one of:; **Topic** — the subject or theme of the content; **Target audience** — who this content is for (role, industry, seniority, pain points)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### email-sequence

[P106] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/email-sequence/SKILL.md`; modified UTC: 2026-10-07T06:07:03.339860+00:00; SHA-256: `4303252cbe340b19945b3e58d46430fdf42ea47b3e26d985e3ef1d6da5e36021`.

**Purpose:** Design and draft multi-email sequences with full copy, timing, branching logic, exit conditions, and performance benchmarks. Use when building onboarding, lead nurture, re-engagement, win-back, or product launch flows, when you need a complete drip campaign with A/B test suggestions, or when mapping a sequence end-to-end with a flow diagram.

**Contents:** Email Sequence; Trigger; Inputs; Process; 1. Sequence Strategy; 2. Individual Email Design; Subject Line; Preview Text; Email Purpose; Body Copy; Primary CTA; Timing; Segment/Condition Notes; 3. Sequence Logic; 4. Performance Benchmarks.

**Procedure cues (source excerpts):** **Sequence type** — one of:; **Goal** — what the sequence should achieve (e.g., activate new users, convert leads to customers, reduce churn, drive event attendance, upsell to a higher tier); **Audience** — who receives this sequence, what stage they are at, and any relevant segmentation details (role, industry, behavior triggers, lifecycle stage)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### performance-report

[P102] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/performance-report/SKILL.md`; modified UTC: 2026-10-07T06:07:03.326505+00:00; SHA-256: `997397e23ba5124cdcbbf17e4be9f5cb36f2a2145b5648e02b2852c91c3cc140`.

**Purpose:** Build a marketing performance report with key metrics, trend analysis, wins and misses, and prioritized optimization recommendations. Use when wrapping a campaign, when preparing weekly, monthly, or quarterly channel summaries for stakeholders, or when you need data translated into an executive summary with next-period priorities.

**Contents:** Performance Report; Trigger; Inputs; Report Structure; 1. Executive Summary; 2. Key Metrics Dashboard; Metrics by Report Type; 3. Trend Analysis; 4. What Worked; 5. What Needs Improvement; 6. Insights and Observations; 7. Recommendations; 8. Next Period Focus; Metric Definitions and Benchmarks; Email Marketing.

**Procedure cues (source excerpts):** **Report type** — determine which type of report the user needs:; **Time period** — the reporting window (last week, last month, last quarter, custom date range); **Data source**:

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### seo-audit

[P101] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/marketing/1.2.0/skills/seo-audit/SKILL.md`; modified UTC: 2026-10-07T06:07:03.317651+00:00; SHA-256: `25008ccdda6f4d9b7ba05f11120d0b9cc976c2d0b04f3d86605e63b1a54a8c40`.

**Purpose:** Run a comprehensive SEO audit — keyword research, on-page analysis, content gaps, technical checks, and competitor comparison. Use when assessing a site's SEO health, when finding keyword opportunities and content gaps competitors own, or when you need a prioritized action plan split into quick wins and strategic investments.

**Contents:** /seo-audit; Trigger; Inputs; Process; 1. Keyword Research; 2. On-Page SEO Audit; 3. Content Gap Analysis; 4. Technical SEO Checklist; 5. Competitor SEO Comparison; Output; Executive Summary; Keyword Opportunity Table; On-Page Issues Table; Content Gap Recommendations; Technical SEO Checklist.

**Procedure cues (source excerpts):** **URL or domain** — the site to audit, or a topic/keyword if running in keyword research mode; **Audit type** — one of:; **Target keywords or topics** (optional) — specific keywords the user is already targeting or wants to rank for

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## claude-cowork / pdf-viewer / 0.2.0

### view-pdf

[P098] Source: `/Users/alexlobaito/.codex/plugins/cache/claude-cowork/pdf-viewer/0.2.0/skills/view-pdf/SKILL.md`; modified UTC: 2026-10-07T06:07:03.316880+00:00; SHA-256: `8635c2ca95e740ea3794f96b2d0f59bea7ab0380bb6af893536f0e02ea5208ab`.

**Purpose:** Interactive PDF viewer. Use when the user wants to open, show, or view a PDF and collaborate on it visually — annotate, highlight, stamp, fill form fields, place signature/initials, or review markup together. Not for summarization or text extraction (use native Read instead).

**Contents:** PDF Viewer — Interactive Document Workflows; When to use this skill; Tools; `list_pdfs`; `display_pdf`; `interact`; Annotation Types; Interactive Workflows; Collaborative annotation (AI-driven); Form filling (visual, not programmatic); Signing (visual, not certified); Supported Sources; Out of Scope.

**Procedure cues (source excerpts):** `display_pdf` to open the document; `interact` → `get_text` on relevant page range to understand content; Propose a batch of annotations to the user (describe what you'll mark)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## openai-bundled / visualize / 1.0.46

### visualize

[P154] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-bundled/visualize/1.0.46/skills/visualize/SKILL.md`; modified UTC: 2026-10-02T16:45:34.234684+00:00; SHA-256: `37a648f231b3716956e5b534bff1eef36195b5f7261ccd78e913a9ad5c961f0f`.

**Purpose:** Create visualizations and interactive tools directly in conversation. Proactively use to show how something works; explore 'what happens when', 'what changes', or 'help me understand'; compare or inspect; create simulations, maps, charts, graphs, and mockups. Use standard tools for static scientific figures.

**Contents:** Visualize; Read the complete skill; Inline HTML output contract; File; Fragment; Content and response; External resources; Exporting an existing visualization; Runtime styles; Color; Typography; Composition; Remembering inline interaction state; UI mockups; Calendar.

**Opening guidance (source excerpt):** - A request for a new standalone file, website, app page, component, or other project change is not an in-conversation visualization request, even when the deliverable contains charts or interactive content. - A request to preview, explain, or explore a proposed interface in the conversation is an in-conversation visualization request. - Create a visual only when the user needs to see or explore i

**Resources:** scripts/: 1 files; examples/: 1 files; assets/: 5 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated / data-analytics / 1dc19589

### analyze-data-quality

[P051] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/analyze-data-quality/SKILL.md`; modified UTC: 2026-09-12T03:37:57.279850+00:00; SHA-256: `9a3c994f87da0c7a8c5ce37bbf08a59fc6f5b4f368475d3d7438f622b753d5f0`.

**Purpose:** Assess whether structured data, query results, dashboards, or analytical evidence are trustworthy enough to use. Use when the task is to check data quality, reconcile conflicting sources or metric definitions, or decide whether evidence is safe to cite.

**Contents:** Related Skills; Analyze Data Quality; Workflow; Standards; Core Checks; Specific Check Guidance; Severity; Automated Test Guidance; Output Standards; Defaults.

**Procedure cues (source excerpts):** Clarify the quality question and operating context.; Choose an inspectable analysis path.; Build a compact profile.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### build-dashboard

[P049] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/build-dashboard/SKILL.md`; modified UTC: 2026-09-12T03:37:57.280368+00:00; SHA-256: `c453ef3e1187477f696aae9a68b116d0e7e0bd6f665ab03a9d1634d13482aaaa`.

**Purpose:** Build source-backed dashboards for monitoring performance, exploring drivers, or acting on product and business metrics. Use when the task needs a dashboard, scorecard, or monitoring view with clear metrics, filters, source definitions, and QA.

**Contents:** Related Skills; Dashboard Building; Skill Configuration; Runtime Delivery Routing; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Define The Dashboard Brief; 2. Select The Delivery Surface; 3. Gather And Validate The Data; 4. Define The Metric Model; 5. Design The Dashboard Layout; 6. Choose The Right Charts; 7. Build And Validate In The Selected Surface; 8. Hand Off The Dashboard.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.; Use a connected BI tool when the user explicitly selected it.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### build-report

[P056] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/build-report/SKILL.md`; modified UTC: 2026-09-12T03:37:57.282666+00:00; SHA-256: `03db47974dc400b026d9268730de1ef317b5446a7a6bc9906ad471bfb117fd22`.

**Purpose:** Build polished analytical reports for executive, product, business, or technical audiences. Use when the task needs a durable answer-first narrative with evidence-backed findings, visuals or tables, caveats, and source context.

**Contents:** Related Skills; Report Building; Skill Configuration; Workflow; Report Standards; PDF Export Specifications; MCP App And Sites Report Specifications; HTML Report Specifications; Narrative; Evidence And Sources; Visuals And Tables; Metrics And Language; Quality Bar.

**Procedure cues (source excerpts):** Define the reporting job.; Read the matching audience specification.; Gather and bound the evidence.

**Resources:** scripts/: 6 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### create-data-context

[P054] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/create-data-context/SKILL.md`; modified UTC: 2026-09-12T03:37:57.290837+00:00; SHA-256: `b004f792fa63e639dbce197562c97230eb58250e639b6bbe926085e3a44b0c2b`.

**Purpose:** Create, update, inspect, or repair Data Analytics semantic layers. Use when the user asks to save data context or create a semantic layer that future Data Analytics work can inspect and cite.

**Contents:** Create Data Context; Runtime Routing; Skill Configuration; Audience And Language; Source Links; Semantic Layer Setup; Creating Or Updating The Layer; Output Contract.

**Opening guidance (source excerpt):** This skill creates and maintains semantic-layer skills for Data Analytics. A semantic-layer skill is an explicit artifact the user can inspect and cite later. It captures how future analyses should interpret the data, for example which metric definition is canonical, which dashboard or table is the best source of truth, and what caveats should be checked before answering.

**Resources:** references/: 5 files; scripts/: 3 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### design-kpis

[P046] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/design-kpis/SKILL.md`; modified UTC: 2026-09-12T03:37:57.293141+00:00; SHA-256: `fcefdecacd1d64f847fbb7c45e93a6bd49c679dff66b8966ebc74c4dc39b8f21`.

**Purpose:** Design KPI frameworks, metric definitions, targets, guardrails, and measurement plans for product or business decisions. Use when success metrics, drivers, guardrails, targets, or the measurement approach need to be defined or improved.

**Contents:** Design KPIs; When To Use Data Quality First; Skill Configuration; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Clarify The Decision And Operating Context; 2. Gather Evidence Before Recommending Metrics; 3. Generate A Wider Candidate Set; 4. Compare And Select Metrics; 5. Set Targets When Needed; 6. Deliver The Recommendation; Example Metric Shapes.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.; initiative summary

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### gather-business-context

[P050] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/gather-business-context/SKILL.md`; modified UTC: 2026-09-12T03:37:57.293478+00:00; SHA-256: `e8a1e917b8c4d03248987f33ca49fb7b1d6ed533328c39a02cafcc5b88b4577c`.

**Purpose:** Gather business context from connected or provided sources so downstream analysis starts with the right framing. Use when an analytical question depends on missing context, such as what a metric means, what changed recently, or which sources should be checked. If the same prompt asks for diagnosis, recommendation, or a deliverable, gather context first and continue to the focused skill.

**Contents:** Boundary; Gather Business Context; Workflow; 1. Identify The Retrieval Target; 2. Build Search Anchors; 3. Search From Discovery Points Toward Authoritative Artifacts; 4. Extract Only Decision-Shaping Context; 5. Keep Source Notes Compact And Attributable; 6. Reconcile Conflicts Explicitly; 7. Stop Once The Framing Is Sound; 8. Return A Lightweight Context Note When Useful; Standards.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every enabled or provided source family that could contain useful context or task-relevant data. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. User-named sources, known tables, dashboards, and semantic-layer anchors are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare authority, freshness, definition, scope, and directness. Prefer artifacts closest to what was decided, defined, implemented, or measured; follow linked evidence when useful. Note material conflicts and explain which source or combination should guide downstream analysis.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### index

[P061] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/index/SKILL.md`; modified UTC: 2026-09-12T03:37:57.293814+00:00; SHA-256: `2239188d6ac667a9e4b546ffb441f17ac3cfe90fe7683ac68506789ef8dabeb3`.

**Purpose:** Route Data Analytics plugin-level requests and broad analytics work to the right focused workflow. Use when Data Analytics is at-mentioned, or for analytics requests involving data, metrics, dashboards, reports, charts, notebooks, spreadsheets, KPIs, market sizing, or semantic layers.

**Contents:** ChatGPT web Chat mode stop gate (read first); Eligibility gate (read before routing); Launch/segment decision cue; Metric definition/source-of-truth disputes; Staged analytics workflow follow-through; Skill Purpose; Skill Configuration; Runtime Routing; Saved Data Context And Semantic Layers; Guided Flow And Source Setup; First-task intake; Selection handling; Custom-question access; No-source completion invariant; Connected-source option copy.

**Procedure cues (source excerpts):** If the user supplied a concrete task, skip intake and continue at `Custom-question access`.; Otherwise inspect only the runtime-provided installed Apps and Plugins inventory plus callable tools already visible in the session, including custom MCP servers and other callable tools that can read the needed source. Do not read connector records, call `functions.list_available_plugins_to_install`, or treat `.app.json` declarations as installed. If tools are deferred, use `tool_search` when available; otherwise use the runtime's callable-tool registry, such as `ALL_TOOLS`. Query by the name, source type, or task-relevant capability of an already-visible or user-named connector, custom MCP server, or other callable tool to verify callability; do not search only a fixed provider catalog.; If at least one useful connected source exists, invoke `request_user_input` on ChatGPT Desktop or `$answers-ask-user-input` elsewhere once with exactly three options: two distinct tasks backed by existing installed connectors or callable tools, followed by `Upload your own`. Prefer distinct source families; if fewer than two are useful, derive multiple non-duplicative tasks from the same connected source's capabilities. Never include sample, installation, or unsupported options.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### jupyter-notebooks

[P060] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/jupyter-notebooks/SKILL.md`; modified UTC: 2026-09-12T03:37:57.294158+00:00; SHA-256: `8303d33041a5d5ccbfbb5addbb60bd8b0559027f01a586f98b7728e58c4127ed`.

**Purpose:** Create, edit, or validate reproducible SQL or Python notebooks. Use for notebooks, SQL/Python scratchpads, reproducible exploration, audit trails, or runnable companions where the analysis should be reviewable or rerunnable.

**Contents:** Related Skills; Jupyter Notebooks; Workflow; Standards; Notebook Structure; Reproducibility; Code And Data Hygiene; Analysis Quality; Validation Checklist.

**Procedure cues (source excerpts):** Lock the notebook mode and scope.; Inspect or scaffold with notebook-safe tooling.; Structure the notebook for the chosen mode.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### kpi-reporting

[P063] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/kpi-reporting/SKILL.md`; modified UTC: 2026-09-12T03:37:57.294473+00:00; SHA-256: `a4ee918f3c87af4db8bb007cf8fefec444cd47b96b76de711349f11d7232861a`.

**Purpose:** Prepare KPI readouts, scorecards, WBR/MBR/QBR updates, and executive summaries from quantitative business or product metrics; use when the task is to report status, compare against targets, explain validated drivers, and state operating implications.

**Contents:** KPI Reporting; Skill Configuration; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Clarify The Readout Purpose; 2. Define The Metric Framework; 3. Lock Metric Definitions And Sources; 4. Pull The Topline Actuals; 5. Put The Numbers In Context; 6. Explain Validated Drivers; 7. Add Business Context And Operating Implications; 8. Validate The Readout; 9. Hand Off The Readout; Standards.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.

**Resources:** references/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### market-sizing

[P062] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/market-sizing/SKILL.md`; modified UTC: 2026-09-12T03:37:57.295007+00:00; SHA-256: `dd353ab8c7229d3bc831234725db7d02ceeb1a889ee781103f90997879ac1951`.

**Purpose:** Estimate market, segment, or opportunity size with transparent assumptions and uncertainty. Use for TAM/SAM/SOM, sizing scenarios, or comparing the scale of possible opportunities.

**Contents:** Related Skills; Market Sizing; Skill Configuration; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Frame The Market Or Opportunity; 2. Choose A Starting Sizing Approach And Inputs; 3. Gather Sources For The Inputs; 4. Separate Facts From Assumptions; 5. Build The Model; 6. Test Sensitivity; 7. State The Estimate And Validation Priorities.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### metric-diagnostics

[P052] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/metric-diagnostics/SKILL.md`; modified UTC: 2026-09-12T03:37:57.295309+00:00; SHA-256: `c9293227b592328c06cb9f6a2f23c0114ddcd1ca456a42f1ceebfe5981007314`.

**Purpose:** Diagnose why a metric changed or differs from expectation. Use when the task is to identify likely drivers of a metric movement, anomaly, gap, or discrepancy.

**Contents:** Related Skills; Metric Diagnostics; Skill Configuration; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Define The Diagnostic Question; 2. Validate The Metric Definition And Source; 3. Establish The Metric Pattern; 4. Choose The Diagnostic Plan; 5. Decompose And Validate Drivers; 6. State Implications And Follow-Up.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### product-business-analysis

[P048] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/product-business-analysis/SKILL.md`; modified UTC: 2026-09-12T03:37:57.295650+00:00; SHA-256: `3e6b684ace151bbf777afd88fe34758b337ac0d6ff2bf332958d7a495d624a4b`.

**Purpose:** Analyze product or business data to support a decision or recommendation. Use when a decision depends on metric-backed evidence, such as choosing a direction, prioritizing an opportunity, evaluating a change, segmenting users, sizing tradeoffs, or deciding what to do next.

**Contents:** Related Skills; Product And Business Analysis; Skill Configuration; Source Discovery And Verification; Source Access Guardrail; Workflow; 1. Start From The Decision; 2. Gather Decision-Relevant Context; 3. Frame The Analysis; 4. Run Focused Quantitative Analysis; 5. Translate Evidence Into Decision Implications; 6. Hand Off The Recommendation.

**Procedure cues (source excerpts):** **Explore all possible sources.** Search every connected or provided source that could contain task-relevant data or change the interpretation. Within each structured-data source, run fresh catalog or metadata discovery for relevant schemas, datasets, tables, views, models, and metrics. Known sources, tables, dashboards, and semantic mappings are starting points, not stopping points.; **Compare duplicates and conflicts.** When sources overlap or disagree, compare ownership, freshness, definition, grain, coverage, and directness. Use the best authoritative source, or combine complementary sources when needed. Note material conflicts, explain why the selected source or sources control the answer, and verify selected data through live reads before concluding.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### publish-artifact-to-sites

[P053] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/publish-artifact-to-sites/SKILL.md`; modified UTC: 2026-09-12T03:37:57.295962+00:00; SHA-256: `26b3846191d1c5237262a26da61694aa67bef38c4ed03eb3167e39f39c6f07a3`.

**Purpose:** Publish a validated Data Analytics report or dashboard artifact through Sites. Use automatically for durable artifacts in any positively identified Work Mode when the full Sites lifecycle is callable, or in ChatGPT Desktop outside Work Mode only after an explicit Sites request or acceptance of the optional post-handoff sharing offer.

**Contents:** Publish Artifact To Sites; Routing Contract; Workflow; Fallbacks And Failures.

**Procedure cues (source excerpts):** Confirm that `$sites-building` and `$sites-hosting` are both callable for the full Sites create, checkpoint, and deployment lifecycle.; Invoke `$sites-building` to create or reopen one worker-starter checkout per logical report or dashboard. For a new Site, select the worker starter (`--starter worker`). Reuse that Site for later versions.; Read the Site's current access policy with the Sites connector. Treat a workspace Site as verifiably owner-only only when it is `custom`, has exactly one `allowed_account_user_id`, its sole `allowed_users` entry has the same account-user id and a non-empty email, and it has no allowed groups. If the user asked to widen reader access, defer that access change until after the package is exported so the verified creator seed is not lost. Do not infer a creator from an already-shared reader allowlist.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### report-to-google-doc

[P057] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/build-report/report-to-google-doc/SKILL.md`; modified UTC: 2026-09-12T03:37:57.283454+00:00; SHA-256: `0fac3acf39e180a8ee398c837cd40289c5e0f72473ef3788be623cb68e703a1f`.

**Purpose:** Narrow conversion skill. Invoke only when the user explicitly asks to convert an existing local or blob-hosted HTML analytics report into a Google Doc, DOCX, or shareable document.

**Contents:** Report To Google Doc; Workflow; Standards; Repairs; Local Checks.

**Procedure cues (source excerpts):** Resolve the HTML report.; Run the bundled helper.; Inspect helper outputs.

**Resources:** scripts/: 13 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### report-to-google-slides

[P058] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/build-report/report-to-google-slides/SKILL.md`; modified UTC: 2026-09-12T03:37:57.287340+00:00; SHA-256: `4dd1c74a3fc5284c3bf69500ff82213c0849663d15b79579e1e950cfa2558d2d`.

**Purpose:** Narrow conversion skill. Invoke only when the user explicitly asks to convert an existing HTML analytics report into a native Google Slides deck.

**Contents:** Report To Google Slides; Workflow; Standards; Visual System.

**Procedure cues (source excerpts):** Resolve the local HTML report.; Run the helper.; Inspect local outputs.

**Resources:** scripts/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### report-to-pdf

[P059] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/build-report/report-to-pdf/SKILL.md`; modified UTC: 2026-09-12T03:37:57.288411+00:00; SHA-256: `ef65a78de9ca425698b529cbdaea7e6323ec6a704cbc10f070920ee6e8d11d57`.

**Purpose:** Narrow conversion skill. Invoke only when the user explicitly asks to convert an existing Data Analytics report, dashboard, or inline chart export into a PDF artifact.

**Contents:** Report To PDF; Workflow; Standards; Verification Guidance.

**Procedure cues (source excerpts):** Resolve the static source.; Generate the PDF with Chrome CLI headless print-to-PDF.; If Chrome is unavailable or cannot produce a valid PDF, use a renderer-backed fallback.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### validate-data

[P047] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/validate-data/SKILL.md`; modified UTC: 2026-09-12T03:37:57.296152+00:00; SHA-256: `7aa5c77b22b9e5bf1b054e4ab6320a12dfd5342aa6cb18f8e497b46c713be20e`.

**Purpose:** Validate whether an analysis is accurate, well-supported, and ready to share or use for a decision. Use when reviewing methodology, calculations, comparisons, visuals, caveats, or conclusions.

**Contents:** Related Skills; Validate Data Analysis; Workflow; Standards; Validation Stance; Methodology Checks; Data Quality Checks; Calculation Checks; Reasonableness Checks; Common Pitfalls; Spot-Check Recipes; Visualization Checks; Confidence Ratings; Output Standards; Validation Report.

**Procedure cues (source excerpts):** Inventory the artifact and claims.; Validate the question, methodology, and assumptions.; Validate data selection and quality risks.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### visualize-data

[P055] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/data-analytics/1dc19589/skills/visualize-data/SKILL.md`; modified UTC: 2026-09-12T03:37:57.296408+00:00; SHA-256: `ff2601669022a2ef43524e0225eb4833acc03260db90b996a2d6f74fbbce7b12`.

**Purpose:** Design, build, revise, or QA quantitative charts and figures. Use when an analytical answer needs visual judgment, whether for an inline answer, report, dashboard, notebook, or artifact.

**Contents:** Related Skills; Data Visualization; Runtime Delivery Routing; Chart Selection; Workflow; Standards; Selection Rules; Surface And Implementation; Visual Design; Quality Bar.

**Procedure cues (source excerpts):** Define the analytical question and one-sentence takeaway before choosing a chart. Identify the final surface, the intended comparison, and the context needed to make the visual honest.; Choose the simplest defensible family and variant from `Chart Selection`. Coordinate with `$build-dashboard` or `$build-report` when the visual belongs to those artifacts, and use `$validate-data` when the supporting analysis needs validation.; Write a compact chart contract before plot code, dashboard configuration, or renderer-specific implementation work. Include:

**Resources:** references/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated / openai-developers / 1dc19589

### agents-sdk

[P065] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/openai-developers/1dc19589/skills/agents-sdk/SKILL.md`; modified UTC: 2026-09-12T03:37:58.397856+00:00; SHA-256: `61830dccd552307bc714b961acae80b1c9c9c30b5d2faaa9e6043b6fb0414760`.

**Purpose:** Build, run, deploy, and evaluate OpenAI Agents SDK apps from Codex. Use when the user asks to create or adapt an Agents SDK app, build from a prompt or Codex thread, prepare a runnable agent prototype, add a focused eval harness, or deploy locally through the Agents SDK Deployment Manager.

**Contents:** Agents SDK; References; Rules; Intake; API Access; Build Workflow; Build From Codex; Eval Workflow; Deploy Workflow; Done Criteria.

**Procedure cues (source excerpts):** Inspect the target repo.; Define the app contract.; Set up dependencies using the repo's existing package manager.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### build-chatgpt-app

[P068] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/openai-developers/1dc19589/skills/build-chatgpt-app/SKILL.md`; modified UTC: 2026-09-12T03:37:58.407505+00:00; SHA-256: `b4ba5e0847e9b56b327da4e7546f5f0bf3325f54d6d21fc119b320bc2c898a53`.

**Purpose:** Build, scaffold, refactor, and troubleshoot ChatGPT Apps SDK applications that combine an MCP server and widget UI. Use when Codex needs to design tools, register UI resources, wire the MCP Apps bridge or ChatGPT compatibility APIs, apply Apps SDK metadata or CSP or domain settings, or produce a docs-aligned project scaffold. Prefer a docs-first workflow by invoking the openai-docs skill or OpenAI developer docs MCP tools before generating code.

**Contents:** Build ChatGPT App; Overview; Mandatory Docs-First Workflow; Prompt Guidance; Classify The App Before Choosing Code; Default Starting-Point Order; Build Workflow; 0. Classify The App Archetype; 1. Plan Tools Before Code; 2. Choose an App Architecture; 2a. Start From An Upstream Example When One Fits; 2b. Use the Starter Script When a Low-Dependency Fallback Helps; 3. Scaffold the MCP Server; 4. Scaffold the Widget UI; API Surface Guardrails.

**Procedure cues (source excerpts):** Invoke `$openai-docs` (preferred) or call the OpenAI docs MCP server directly.; Fetch current Apps SDK docs before writing code, especially (baseline pages):; Fetch `apps-sdk/quickstart` when scaffolding a new app or generating a first-pass implementation, and check the official examples repo/page before inventing a scaffold from scratch.

**Resources:** references/: 7 files; scripts/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### chatgpt-app-submission

[P064] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/openai-developers/1dc19589/skills/chatgpt-app-submission/SKILL.md`; modified UTC: 2026-09-12T03:37:58.424459+00:00; SHA-256: `c9b43ca8fe60189e541afa30ea32a86f1bd7ab58a353faac777192a282b796cf`.

**Purpose:** Inspect a ChatGPT Apps MCP server codebase and generate chatgpt-app-submission.json with app info suggestions, tool hint justifications, test cases, and negative test cases, then report review-check findings and outputSchema warnings for submission review.

**Contents:** ChatGPT App Submission; Workflow; App Info Rules; Hint Rules; Output Schema Warnings; Tool Descriptor and CSP Rules; Test Case Rules; Output Contract; Writing Justifications; Reporting Review Checks; Final Response.

**Procedure cues (source excerpts):** Inspect the MCP server codebase from the current working directory.; Read repo metadata, package metadata, README files, app manifests, tool descriptors, resource templates, and widget metadata needed to understand the app.; Find every exposed MCP tool, its declared `readOnlyHint`, `openWorldHint`, and `destructiveHint` annotations, and whether it declares `outputSchema`.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### openai-api-troubleshooting

[P067] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/openai-developers/1dc19589/skills/openai-api-troubleshooting/SKILL.md`; modified UTC: 2026-09-12T03:37:58.424603+00:00; SHA-256: `9fb4e152430c2f0475d1d14ce61b413267d322af9c032f2affb64698ca562662`.

**Purpose:** Use when an OpenAI API request fails and Codex needs to classify the likely cause, explain the next step, and route to the right follow-up. Covers common runtime failures such as blocked outbound network access, invalid credentials, exhausted API quota or credits, rate limits, and model, project, or organization access issues; delegate key provisioning to openai-platform-api-key and current documentation lookups to openai-docs.

**Contents:** OpenAI API Troubleshooting; Routing; Rules; References.

**Procedure cues (source excerpts):** **Sandboxed or blocked outbound network access**; **Authentication or missing-key errors**; **Quota or credit exhaustion**

**Resources:** references/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### openai-platform-api-key

[P066] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/openai-developers/1dc19589/skills/openai-platform-api-key/SKILL.md`; modified UTC: 2026-09-12T03:37:58.425108+00:00; SHA-256: `780670286fb0acf32660abafc1bc34d7a25ff7a74af59e02db8fb62bbdd21ac2`.

**Purpose:** Use when Codex is asked to build, run, test, debug, or configure an OpenAI-backed or provider-unspecified AI app, UI, script, CLI, generator, or tool, especially requests phrased only as "using AI" or generators driven by forms/user input; also use for OPENAI_API_KEY or sk-proj setup. Treat this as the credential gate: inspect safely, ask reuse-vs-new before API work, and never expose plaintext.

**Contents:** OpenAI API Key; When To Use; Coordination With Implementation Skills; Safety Rules; Mandatory First Step; Credential Decision Messages; Workflow; Helper; References.

**Procedure cues (source excerpts):** Inspect for a usable `OPENAI_API_KEY` without printing it.; Unless the user explicitly asked for a new key, ask whether to reuse an existing key or create a new one. If none exists, ask whether to create one.; Stop until the user answers.

**Resources:** references/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated / superpowers / 1dc19589

### brainstorming

[P076] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/brainstorming/SKILL.md`; modified UTC: 2026-09-12T03:37:58.973737+00:00; SHA-256: `74edf03ea6d24ef53db48677b93558d14a979bdf052ca3f57ecdca0c66791608`.

**Purpose:** You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.

**Contents:** Brainstorming Ideas Into Designs; Three Paths; Anti-Pattern: "Too Simple To Need Approval"; Red Flags; Checklist; Process Flow; The Process; After the Design (architectural path); Visual Companion.

**Procedure cues (source excerpts):** **Explore project context** — enough to frame the probe; **Present question + probe plan** — 2-3 sentences; **Get approval** — a nod is enough

**Resources:** scripts/: 5 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### dispatching-parallel-agents

[P073] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/dispatching-parallel-agents/SKILL.md`; modified UTC: 2026-09-12T03:37:58.975606+00:00; SHA-256: `1968923066f3b707eb01d1992cdf4c42284c3855f70253b9cd5000ff45fca13c`.

**Purpose:** Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies

**Contents:** Dispatching Parallel Agents; Overview; When to Use; The Pattern; 1. Identify Independent Domains; 2. Create Focused Agent Tasks; 3. Dispatch in Parallel; All three run concurrently.; 4. Review and Integrate; Agent Prompt Structure; Common Mistakes; When NOT to Use; Real Example from Session; Verification.

**Procedure cues (source excerpts):** **Focused** - One clear problem domain; **Self-contained** - All context needed to understand the problem; **Specific about output** - What should the agent return?

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### executing-plans

[P074] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/executing-plans/SKILL.md`; modified UTC: 2026-09-12T03:37:58.976049+00:00; SHA-256: `c4c3d8b628c51114cd165fb8246fe02744cd8be180032328391252e653028d9b`.

**Purpose:** Use when you have a written implementation plan to execute in a separate session with review checkpoints

**Contents:** Executing Plans; Overview; The Process; Step 1: Load and Review Plan; Step 2: Execute Tasks; Step 3: Complete Development; When to Stop and Ask for Help; When to Revisit Earlier Steps; Remember.

**Procedure cues (source excerpts):** Ensure an isolated workspace: use superpowers:using-git-worktrees to create one or verify the existing one; Read plan file; Review critically - identify any questions or concerns about the plan

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### finishing-a-development-branch

[P075] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/finishing-a-development-branch/SKILL.md`; modified UTC: 2026-09-12T03:37:58.976526+00:00; SHA-256: `8db5a922b242dd4e1bf824cb91c13b3e8d8e8a86d6ceaf7f0774eb9cce909d65`.

**Purpose:** Use when implementation is complete, all tests pass, and you need to decide how to integrate the work

**Contents:** Finishing a Development Branch; Overview; Step 1: Verify Tests; Step 2: Detect Environment; Capture now, while still inside the workspace — Step 5 changes directory; before cleanup (Step 6) needs this value; Step 3: Determine Base Branch; Step 4: Present Options; Step 5: Execute Choice; Option 1: Merge Locally; Get main repo root for CWD safety; Merge first — verify success before removing anything; Verify tests on merged result; Option 2: Push and Create PR; From a detached HEAD, name the new branch on the remote:.

**Procedure cues (source excerpts):** Merge back to <base-branch> locally; Push and create a Pull Request; Keep the branch as-is (I'll handle it later)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### receiving-code-review

[P079] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/receiving-code-review/SKILL.md`; modified UTC: 2026-09-12T03:37:58.977055+00:00; SHA-256: `091df1629510af1b92fc4abd6f96732ebedb4cb2c0f3457e8f2740b0504a2438`.

**Purpose:** Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires technical rigor and verification, not performative agreement or blind implementation

**Contents:** Code Review Reception; Overview; The Response Pattern; Forbidden Responses; Handling Unclear Feedback; Source-Specific Handling; From your human partner; From External Reviewers; YAGNI Check for "Professional" Features; Implementation Order; When To Push Back; Acknowledging Correct Feedback; Gracefully Correcting Your Pushback; Common Mistakes; Real Examples.

**Procedure cues (source excerpts):** READ: Complete feedback without reacting; UNDERSTAND: Restate requirement in own words (or ask); VERIFY: Check against codebase reality

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### requesting-code-review

[P078] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/requesting-code-review/SKILL.md`; modified UTC: 2026-09-12T03:37:58.977396+00:00; SHA-256: `d71cc01ba56d2325cf8af5f7c11837819b63ecd57de0bfdb812f7f3ff7751df8`.

**Purpose:** Use when completing tasks, implementing major features, or before merging to verify work meets requirements

**Contents:** Requesting Code Review; When to Request Review; How to Request; Example; Common Rationalizations; Red Flags.

**Opening guidance (source excerpt):** Dispatch a code reviewer subagent to catch issues before they cascade. The reviewer gets precisely crafted context for evaluation — never your session's history.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### subagent-driven-development

[P082] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/subagent-driven-development/SKILL.md`; modified UTC: 2026-09-12T03:37:58.978007+00:00; SHA-256: `8dd1b8e698edec3700c6d89517dbe96febd3bacd3f6ea21c1a3569c62ea104b5`.

**Purpose:** Use when executing implementation plans with independent tasks in the current session

**Contents:** Subagent-Driven Development; When to Use; The Process; Setup; Model Selection; The Task Loop; 1. Dispatch the implementer; 2. Handle the report; 3. Review the task; 4. The fix loop; 5. Complete the task; Final Review; Finish; Common Rationalizations; Example Workflow.

**Procedure cues (source excerpts):** If it's a context problem, provide more context and re-dispatch with the same model; If the task requires more reasoning, re-dispatch with a more capable model; If the task is too large, break it into smaller pieces

**Resources:** scripts/: 3 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### systematic-debugging

[P071] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/systematic-debugging/SKILL.md`; modified UTC: 2026-09-12T03:37:58.979561+00:00; SHA-256: `808fc5717aa88ad65efff312b11c186294d3e6ee301afb584e2f86599b137787`.

**Purpose:** Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes

**Contents:** Systematic Debugging; Overview; The Iron Law; When to Use; The Four Phases; Phase 1: Root Cause Investigation; Phase 2: Pattern Analysis; Phase 3: Hypothesis and Testing; Phase 4: Implementation; Red Flags - STOP and Follow Process; your human partner's Signals You're Doing It Wrong; Common Rationalizations; Quick Reference; When Process Reveals "No Root Cause"; Supporting Techniques.

**Procedure cues (source excerpts):** **Read Error Messages Carefully**; **Reproduce Consistently**; **Check Recent Changes**

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### test-driven-development

[P070] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/test-driven-development/SKILL.md`; modified UTC: 2026-09-12T03:37:58.981280+00:00; SHA-256: `bf1b8216e523851a411e91d429a7c1c2a173e79d88957bc78e348218d50edd54`.

**Purpose:** Use when implementing any feature or bugfix, before writing implementation code

**Contents:** Test-Driven Development (TDD); Overview; When to Use; The Iron Law; Red-Green-Refactor; RED - Write Failing Test; Verify RED - Watch It Fail; GREEN - Minimal Code; Verify GREEN - Watch It Pass; REFACTOR - Clean Up; Repeat; Good Tests; Common Rationalizations; Red Flags - STOP and Start Over; Example: Bug Fix.

**Opening guidance (source excerpt):** Write the test first. Watch it fail. Write minimal code to pass.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### using-git-worktrees

[P069] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/using-git-worktrees/SKILL.md`; modified UTC: 2026-09-12T03:37:58.981784+00:00; SHA-256: `8cfb86f121269e8f7f12361e6795c4f6738828340e28964c9229d365666c9edd`.

**Purpose:** Use when starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace exists via native tools or git worktree fallback

**Contents:** Using Git Worktrees; Overview; Step 0: Detect Existing Isolation; If this returns a path, you're in a submodule, not a worktree — treat as normal repo; Step 1: Create Isolated Workspace; 1a. Native Worktree Tools (preferred); 1b. Git Worktree Fallback; Directory Selection; Safety Verification (project-local directories only); Create the Worktree; Determine path based on chosen location; Step 2: Project Setup; Node.js; Rust; Python.

**Procedure cues (source excerpts):** **Check your instructions for a declared worktree directory preference.** If the user has already specified one, use it without asking.; **Check for an existing project-local worktree directory:**; **If there is no other guidance available**, default to `.worktrees/` at the project root.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### using-superpowers

[P072] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/using-superpowers/SKILL.md`; modified UTC: 2026-09-12T03:37:58.982119+00:00; SHA-256: `30f2ab78e20ddc27ee7158ae8d4a2abe161c360981c7cc3548070913142d3dc3`.

**Purpose:** Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying questions

**Contents:** The Rule; Skill Priority; Red Flags; Platform Adaptation; User Instructions.

**Opening guidance (source excerpt):** IF A SKILL APPLIES TO YOUR TASK, YOU DO NOT HAVE A CHOICE. YOU MUST USE IT.

**Resources:** references/: 5 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### verification-before-completion

[P081] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/verification-before-completion/SKILL.md`; modified UTC: 2026-09-12T03:37:58.983578+00:00; SHA-256: `2befe7fc55bcadaa3d97dd9e8efeb633d2561c0ebe74c5a8b17c4d9e7e4520b3`.

**Purpose:** Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always

**Contents:** Verification Before Completion; Overview; The Iron Law; The Gate Function; Common Failures; Red Flags - STOP; Rationalization Prevention; Key Patterns; When To Apply.

**Procedure cues (source excerpts):** IDENTIFY: What command proves this claim?; RUN: Execute the FULL command (fresh, complete); READ: Full output, check exit code, count failures

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### writing-plans

[P077] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/writing-plans/SKILL.md`; modified UTC: 2026-09-12T03:37:58.983993+00:00; SHA-256: `48508f44bbfd7d24b029fbf3a314f3cd14c9615599059366e922f47b8dc08cf2`.

**Purpose:** Use when you have a spec or requirements for a multi-step task, before touching code

**Contents:** Writing Plans; Overview; Scope Check; File Structure; Task Right-Sizing; Bite-Sized Task Granularity; Plan Document Header; [Feature Name] Implementation Plan; Global Constraints; Task Structure; Task N: [Component Name]; No Placeholders; Self-Review; Execution Handoff.

**Opening guidance (source excerpt):** Write comprehensive implementation plans assuming the engineer has zero context for our codebase and questionable taste. Document everything they need to know: which files to touch for each task, code, testing, docs they might need to check, how to test it. Give them the whole plan as bite-sized tasks. DRY. YAGNI. TDD. Frequent commits.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### writing-skills

[P080] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated/superpowers/1dc19589/skills/writing-skills/SKILL.md`; modified UTC: 2026-09-12T03:37:58.984450+00:00; SHA-256: `d34db5c8aed6a4e0440132bd0613aace70a693ec7819d5637ad77481d8e10d1b`.

**Purpose:** Use when creating new skills, editing existing skills, or verifying skills work before deployment

**Contents:** Writing Skills; Overview; What is a Skill?; TDD Mapping for Skills; When to Create a Skill; Skill Types; Technique; Pattern; Reference; Directory Structure; SKILL.md Structure; Skill Name; Overview; When to Use; Core Pattern (for techniques/patterns).

**Procedure cues (source excerpts):** **Heavy reference** (100+ lines) - API docs, comprehensive syntax; **Reusable tools** - Scripts, utilities, templates; **One fresh-context sample per call** — a raw API call, or a single-shot subagent if you don't have API access. System prompt = the realistic context the guidance will live in (the full skill or prompt template, not the guidance in isolation); user message = a task that tempts the failure.

**Resources:** examples/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated-remote / app-6a58503580c08191b78cc5bdaf4eba6e / 1.0.1

### composio

[P022] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e/1.0.1/skills/composio/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `c892641be499b4e535332daaab681c2bdbdf181ef8f840f4ca706820b4079ce2`.

**Purpose:** Route Composio work between the hosted MCP-backed app and the local Composio CLI. Use when a user wants to read or act on external services such as email, calendars, GitHub, Slack, Notion, Linear, Jira, or CRMs; discover an integration or tool; recover a missing connection; combine multiple apps; or automate those actions with local files and scripts.

**Contents:** Composio; Choose the surface; Execute safely.

**Procedure cues (source excerpts):** In a terminal or Codex environment, prefer the local Composio CLI for Composio work. If `composio` is missing, explain how to install and sign in before choosing it; do not install software without user approval. Read [references/cli.md](/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e/1.0.1/skills/composio/references/cli.md) before using that surface.; In ChatGPT web/app or another environment without a usable terminal, use callable, authorized hosted Composio app tools. Read [references/mcp.md](/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/app-6a58503580c08191b78cc5bdaf4eba6e/1.0.1/skills/composio/references/mcp.md) before using that surface.; If both surfaces are available in a terminal or Codex environment, use the CLI unless the user explicitly requests the hosted surface or the required capability exists only there.

**Resources:** references/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated-remote / openai-templates / 0.1.1

### artifact-template-analytics-dashboard

[P018] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-analytics-dashboard/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `cf5360fd8b197673bb237c52c603c97fa319c875c3dfa2cd8efff52d4422f513`.

**Purpose:** Create a spreadsheet using the Analytics Dashboard template and its retained reference file. Use when the user selects or names Analytics Dashboard. Monitor acquisition, engagement, retention, revenue, and conversion funnel KPIs with charts.

**Contents:** Analytics Dashboard; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-business-review

[P016] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-business-review/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `27721fc1d67d1b41949caa75ac8f94f81952ff124406878af6524047929e60d2`.

**Purpose:** Create a presentation using the Business Review template and its retained reference file. Use when the user selects or names Business Review. Review business performance, KPIs, segment results, strategic priorities, decisions, and outlook.

**Contents:** Business Review; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-design-report

[P008] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-design-report/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `563722f53854e606f8a9f87e37e72d7ef70a22d46d5836b8e4d6abfb1b79e9e0`.

**Purpose:** Create a document using the Design Report template and its retained reference file. Use when the user selects or names Design Report. Produce design reports with an executive summary, key findings, implications, recommendations, and appendix.

**Contents:** Design Report; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-experiment-analysis

[P010] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-experiment-analysis/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `0b05effc47df0a14f8e0c3e3597e6722224747435546385d38a2cae279bd20b9`.

**Purpose:** Create a document using the Experiment Analysis template and its retained reference file. Use when the user selects or names Experiment Analysis. Analyze experiments with hypotheses, methodology, results, interpretation, limitations, and next steps.

**Contents:** Experiment Analysis; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-financial-budget

[P004] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-financial-budget/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `c0b6b7a62a15597aaf2b1ec679e21da48f533b756127f0aef957cdfe9f3da738`.

**Purpose:** Create a spreadsheet using the Financial Budget template and its retained reference file. Use when the user selects or names Financial Budget. Model actuals, budget and scenario forecasts, variances, cash runway, and departmental plans.

**Contents:** Financial Budget; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-investment-committee-memo

[P002] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-investment-committee-memo/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `68abd08cfe5e073e3c446a3f675f44c5bf98f57434dba679e8acd8a763379a8b`.

**Purpose:** Create a document using the Investment Committee Memo template and its retained reference file. Use when the user selects or names Investment Committee Memo. Prepare investment committee memos with the thesis, transaction details, financial analysis, risks, and recommendation.

**Contents:** Investment Committee Memo; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-legal-memorandum

[P009] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-legal-memorandum/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `51fb9d21baf6119c4ccb1903638a6bac0e859210de63460fffa7025d52e997e0`.

**Purpose:** Create a document using the Legal Memorandum template and its retained reference file. Use when the user selects or names Legal Memorandum. Draft legal memoranda with the issue, brief answer, relevant facts, analysis, and conclusion.

**Contents:** Legal Memorandum; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-market-trends-report

[P017] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-market-trends-report/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `d58d019b89cb6f292ac3ab991d561489eef477ff53ce05fb024a0c936f5af26a`.

**Purpose:** Create a presentation using the Market Trends Report template and its retained reference file. Use when the user selects or names Market Trends Report. Communicate market or industry trends, supporting evidence, implications, and recommended responses.

**Contents:** Market Trends Report; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-minimal-letterhead

[P020] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-minimal-letterhead/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `880ef094d4d0c89a7bde5ce9bbe4086625c186651e9e6efc8ba8bdd7cc77f9d5`.

**Purpose:** Create a document using the Minimal Letterhead template and its retained reference file. Use when the user selects or names Minimal Letterhead. Write professional business letters with sender, recipient, message, and signature fields in a minimal letterhead layout.

**Contents:** Minimal Letterhead; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-operating-calendar

[P005] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-operating-calendar/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `33bb660791a0b9a21628a42c34934932220203b6aabd84e98cb1b45327d0384c`.

**Purpose:** Create a spreadsheet using the Operating Calendar template and its retained reference file. Use when the user selects or names Operating Calendar. Plan annual and monthly operating milestones, campaigns, launches, deadlines, and recurring events.

**Contents:** Operating Calendar; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-operating-review

[P003] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-operating-review/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `6d63c5cd025ffe936e7bab5db3023672bbaec26af55c2bb8b057d38c202c9c32`.

**Purpose:** Create a presentation using the Operating Review template and its retained reference file. Use when the user selects or names Operating Review. Run weekly operating reviews with scorecards, functional updates, risks, decisions, and action items.

**Contents:** Operating Review; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-project-kickoff

[P006] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-project-kickoff/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `aa893ebd89e7c8d1db4261d01cc2b1add35d78d00785871ccaaa5fc8db783ec9`.

**Purpose:** Create a presentation using the Project Kickoff template and its retained reference file. Use when the user selects or names Project Kickoff. Align teams on project goals, scope, roles, milestones, risks, and the working model.

**Contents:** Project Kickoff; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-project-tracker

[P011] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-project-tracker/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `d97d5be20189b7f53dd269b6e1c5f694eaf53e5a72f6559fcb1578911b7cda82`.

**Purpose:** Create a spreadsheet using the Project Tracker template and its retained reference file. Use when the user selects or names Project Tracker. Manage workstreams, tasks, owners, status, priority, dates, launch pulse, and a Gantt schedule.

**Contents:** Project Tracker; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-sales-pipeline

[P019] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-sales-pipeline/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `15cfeeedf440021f16ed3f3ad8c7c1ef6d48898b9447741e223d2fb41cfc9800`.

**Purpose:** Create a spreadsheet using the Sales Pipeline template and its retained reference file. Use when the user selects or names Sales Pipeline. Track opportunities, stages, owners, deal sizes, probabilities, forecasts, next steps, and risks.

**Contents:** Sales Pipeline; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-simple-dark-mode

[P007] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-simple-dark-mode/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `b7c8d0c05f75878b9bc21e56a57c41ec1aa29700aca0a24822be0f9f1bd53207`.

**Purpose:** Create a presentation using the Simple Dark Mode template and its retained reference file. Use when the user selects or names Simple Dark Mode. Create clean dark-mode presentations with bold typography, simple sections, charts, and imagery.

**Contents:** Simple Dark Mode; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-simple-light-mode

[P014] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-simple-light-mode/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `7c68430c6cf57b55b457d4735dbd1a46b889bef135a32222902dd0848b6e1752`.

**Purpose:** Create a presentation using the Simple Light Mode template and its retained reference file. Use when the user selects or names Simple Light Mode. Create clean light-mode presentations with spacious typography, simple sections, charts, and imagery.

**Contents:** Simple Light Mode; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-strategy-memorandum

[P001] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-strategy-memorandum/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `51d7882ac94e8e57b323394825728c33925af878806e37277217c2dc12a912e5`.

**Purpose:** Create a document using the Strategy Memorandum template and its retained reference file. Use when the user selects or names Strategy Memorandum. Present strategic context, choices, rationale, risks, milestones, and a clear recommendation.

**Contents:** Strategy Memorandum; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-system-design

[P012] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-system-design/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `87f7b7ed1b0d8410f5e5971cd7f7db9a4165e2f37069e97e52dbfb469b75a57c`.

**Purpose:** Create a document using the System Design template and its retained reference file. Use when the user selects or names System Design. Document system architecture, requirements, components, data flows, APIs, tradeoffs, and operational considerations.

**Contents:** System Design; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled document capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-team-alignment

[P015] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-team-alignment/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `26d7cafdcd1899a937b325c5d02ac57c162d45002153be33a934d35f81eb6110`.

**Purpose:** Create a presentation using the Team Alignment template and its retained reference file. Use when the user selects or names Team Alignment. Facilitate team offsites and planning with context, goals, priorities, decisions, and action items.

**Contents:** Team Alignment; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled presentation or slides capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### artifact-template-three-statement-forecast

[P013] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-three-statement-forecast/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `74f4a5cccec0107b861548b157e04c51d9b58ec13a990c86394b4c529b8ecf41`.

**Purpose:** Create a spreadsheet using the Three-Statement Forecast template and its retained reference file. Use when the user selects or names Three-Statement Forecast. Build an integrated income statement, balance sheet, and cash flow forecast with assumptions, checks, and an executive summary.

**Contents:** Three-Statement Forecast; Workflow; Fidelity.

**Procedure cues (source excerpts):** Read `artifact-template.json` and resolve its paths relative to this skill directory.; Identify the prompt-advertised preinstalled spreadsheet capability. Use the available resource or filesystem tool to open its advertised resource, plugin, skill, or file target, then follow its reference/template workflow with the retained file. If no such capability can be identified and read, say it is unavailable and stop; do not recreate or install it.; Treat the user's prompt and available sources as the content input. Do not invent facts merely to fill a template slot.

**Resources:** assets/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated-remote / pages / 0.1.20

### maintain-space

[P029] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/pages/0.1.20/skills/maintain-space/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `334bf85b62e733cf6a392ab8421ef768a9f6e5d74c16db2c4cb3fcbb3f8c496c`.

**Purpose:** Reconcile new evidence into existing ChatGPT Pages or a Space when the user requests upkeep. For a direct text correction, use write-page. Do not use for ordinary chat drafts, writing, or advice, or treat a selected Page as a request to save. Schedule future upkeep only when requested.

**Contents:** Maintain page content; Establish the upkeep scope; Reconcile rather than accumulate; Apply and report accurately; Examples.

**Opening guidance (source excerpt):** Use this workflow only for a request about actual Page or Space content. For self-contained writing or advice that does not refer to that content, answer in chat. When asked to draft, suggest, or review a change, return a proposal; apply it only when requested.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### manage-schedules

[P027] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/pages/0.1.20/skills/manage-schedules/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `e0a464a83f15a6e896c5536cab775f667ebd0dd61eb64fe3c877a41935d64bd9`.

**Purpose:** Review a ChatGPT Space page and its schedules, recommend useful recurring work, and create, update, or remove scheduled automations.

**Contents:** Manage schedules for this page; Page Background; General Schedule Management Workflow; 1. Establish current schedule state and page purpose; 2. Determine the user’s needs; 3. Execution Mechanics.

**Opening guidance (source excerpt):** This skill often starts from a page action with an autofilled prompt such as “Manage the schedules for this page.” Treat this as a request to assess the page's scheduling needs and lead the setup; the user need not describe an automation upfront. Use the page in context. If no page ID is available, use the page tools to find a recent relevant page. If the target is still unclear, ask the user whic

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### organize-space

[P030] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/pages/0.1.20/skills/organize-space/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `dfa8bfae86785a98e43b1ca0af67a9c89b90c658eee7fc7ad4ccfe8cc84a267b`.

**Purpose:** Organize existing ChatGPT Pages and Space structure when the user requests changes to that structure. Do not use for ordinary chat drafts or advice; a selected Page alone does not authorize reorganization. A narrow text edit does not need this workflow.

**Contents:** Organize pages; Find the structure and purpose; Make the hierarchy useful; Apply real changes; Examples.

**Opening guidance (source excerpt):** Use this workflow only for a request about actual Page or Space content. For self-contained writing or advice that does not refer to that content, answer in chat. When asked to draft, suggest, or review a change, return a proposal; apply it only when requested.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.

### write-page

[P028] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/pages/0.1.20/skills/write-page/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `0aeb35e5bd69f7e96a408301aba00937fa606d782a964bf5378aed41cde0a47c`.

**Purpose:** Create or edit requested Page/Space content, or use for prose you have already decided to save as a standalone Markdown file, only if the user did not explicitly request a Markdown file. Honor established formats, destinations, and repository documentation. A selected Page alone does not authorize a write.

**Contents:** Write and edit a page; Titles and opening; Writing quality; Resolve the destination; Small edits; Supported content; Apply and verify.

**Opening guidance (source excerpt):** Follow the user's voice, length, structure, presentation, and applicable Page/Space instructions. For requests to review existing content or draft or suggest changes, return feedback or a proposal; apply changes only when requested.

**Resources:** references/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## openai-curated-remote / plugin-management / 0.1.0

### plugin-management

[P021] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/plugin-management/0.1.0/skills/plugin-management/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `653841cc21205269f08b0ce135891e1518dac616a766bcfb0b57d788d3f68b10`.

**Purpose:** Discover and suggest relevant plugins, inspect app permissions and dependencies, and manage plugin connections or removal. Use when the user asks about plugins or when a task would materially benefit from an external app, account, service, or data source that available tools cannot access.

**Contents:** Plugin Management; Choose the right capability; Find and suggest plugins; Manage existing plugins.

**Procedure cues (source excerpts):** Use an available built-in tool when it already provides the needed; Use an already connected plugin when it can complete the task.; Search for a plugin when an external app, account, service, or data source

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated-remote / sites / 1.0.0-d

### sites

[P023] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/sites/1.0.0-d/skills/sites/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `5a942cda3c1a22a94b71f24ace3e3489b6e5dd72b1ec9da69d17fd400031647a`.

**Purpose:** Use Sites when the user wants a website built for them (including a landing page, portfolio, dashboard, portal, tracker, hub, game, event registration, or tool), requests changes to a website already built with Sites, wants to publish a website with Sites, or wants to manage Sites hosting.

**Contents:** Sites; Workflow; 1. Select and open; 2. Prepare and launch; 3. Implement; 4. Validate and package; Hosting manifest; Source helper; 5. Publish; 6. Finish; Design; Capabilities.

**Opening guidance (source excerpt):** Take the requested website through the supported development and publishing workflow. Publish completed new Sites and edits unless the user requests local-only work or saving without deployment. New Sites start private; preserve an existing Site's audience unless the user requests a change. Native tool approvals apply without an additional conversational publishing gate.

**Resources:** references/: 10 files; scripts/: 2 files; templates/: 123 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; LISTED in current available-skills catalogue; runtime selection NOT_PROVEN; remote delivery NOT_PROVEN.


## openai-curated-remote / superpowers / 6.4.2

### brainstorming

[P038] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/brainstorming/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `a32d2255354775aa124855aa7100cf276bea096fff4ebb3a0edf57be216e6c72`.

**Purpose:** You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.

**Contents:** Brainstorming Ideas Into Designs; Establish Shared Understanding; Three Paths; Anti-Pattern: "Too Simple To Need Approval"; Red Flags; Checklist; Process Flow; The Process; After the Design (architectural path); Visual Companion.

**Procedure cues (source excerpts):** **Discover intent.** Use the request and available context to identify; **Write back your understanding.** Summarize the intended outcome,; **Carry intent into the design.** Preserve the agreed understanding in

**Resources:** scripts/: 5 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### diagnosing-superpowers

[P039] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/diagnosing-superpowers/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `5a652f8132cc901eb5ca61f89157839f87a2f20aed037fc7a2b51051bc37cd19`.

**Purpose:** Use when a superpowers session went wrong and your human partner wants to know why — repeated work, ignored plans, stumbles, poor results, a skill that didn't fire, "it took too long", "why is it so expensive", "what is it doing" — or wants to build a bug report for the superpowers maintainers, for the current session or a past one identified by id or path, on any harness.

**Contents:** Diagnosing Superpowers; Overview; Workflow; Quick reference; Hard rules; Red Flags.

**Procedure cues (source excerpts):** **Problem intake.** Ask one question at a time until you can write a; **Locate.** Resolve each session to verified absolute filesystem paths using; **Triage.** Read the region around the reported problem yourself. Then

**Resources:** references/: 4 files; templates/: 4 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### dispatching-parallel-agents

[P035] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/dispatching-parallel-agents/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `1968923066f3b707eb01d1992cdf4c42284c3855f70253b9cd5000ff45fca13c`.

**Purpose:** Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies

**Contents:** Dispatching Parallel Agents; Overview; When to Use; The Pattern; 1. Identify Independent Domains; 2. Create Focused Agent Tasks; 3. Dispatch in Parallel; All three run concurrently.; 4. Review and Integrate; Agent Prompt Structure; Common Mistakes; When NOT to Use; Real Example from Session; Verification.

**Procedure cues (source excerpts):** **Focused** - One clear problem domain; **Self-contained** - All context needed to understand the problem; **Specific about output** - What should the agent return?

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### executing-plans

[P036] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/executing-plans/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `f38e8f2ddcf079f65493adc713c1fed78421dfaf5f4dbf6b3a6b2b1d95466e71`.

**Purpose:** Use when executing an implementation plan in the current session as the implementer yourself — your human partner chose inline execution, or no subagent tool is available

**Contents:** Executing Plans; When to Use; The Process; Setup; The Task Loop; 1. Take the task; 2. Work the steps; 3. The completion contract; 4. Complete the task; Final Review; Finish; Common Rationalizations; Example Workflow.

**Opening guidance (source excerpt):** Execute the plan yourself, task by task, in this session: no implementer subagent per task, no reviewer per task. One fresh-context review of the whole branch at the end.

**Resources:** scripts/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### finishing-a-development-branch

[P037] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/finishing-a-development-branch/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `8db5a922b242dd4e1bf824cb91c13b3e8d8e8a86d6ceaf7f0774eb9cce909d65`.

**Purpose:** Use when implementation is complete, all tests pass, and you need to decide how to integrate the work

**Contents:** Finishing a Development Branch; Overview; Step 1: Verify Tests; Step 2: Detect Environment; Capture now, while still inside the workspace — Step 5 changes directory; before cleanup (Step 6) needs this value; Step 3: Determine Base Branch; Step 4: Present Options; Step 5: Execute Choice; Option 1: Merge Locally; Get main repo root for CWD safety; Merge first — verify success before removing anything; Verify tests on merged result; Option 2: Push and Create PR; From a detached HEAD, name the new branch on the remote:.

**Procedure cues (source excerpts):** Merge back to <base-branch> locally; Push and create a Pull Request; Keep the branch as-is (I'll handle it later)

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### receiving-code-review

[P042] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/receiving-code-review/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `091df1629510af1b92fc4abd6f96732ebedb4cb2c0f3457e8f2740b0504a2438`.

**Purpose:** Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires technical rigor and verification, not performative agreement or blind implementation

**Contents:** Code Review Reception; Overview; The Response Pattern; Forbidden Responses; Handling Unclear Feedback; Source-Specific Handling; From your human partner; From External Reviewers; YAGNI Check for "Professional" Features; Implementation Order; When To Push Back; Acknowledging Correct Feedback; Gracefully Correcting Your Pushback; Common Mistakes; Real Examples.

**Procedure cues (source excerpts):** READ: Complete feedback without reacting; UNDERSTAND: Restate requirement in own words (or ask); VERIFY: Check against codebase reality

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### requesting-code-review

[P041] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/requesting-code-review/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `cfcee1b06774e7c0517f1e09be1a11f2d5680257072723e709ddbcf7e08b795a`.

**Purpose:** Use when completing tasks, implementing major features, or before merging to verify work meets requirements

**Contents:** Requesting Code Review; When to Request Review; How to Request; Example; Common Rationalizations; Red Flags.

**Opening guidance (source excerpt):** Dispatch a code reviewer subagent to catch issues before they cascade. The reviewer gets precisely crafted context for evaluation — never your session's history.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### subagent-driven-development

[P045] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/subagent-driven-development/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `8dde5589ee083fb4999106d116f01c8fdaf3116a8a9813fdedeb80329de49046`.

**Purpose:** Use when executing implementation plans with independent tasks in the current session

**Contents:** Subagent-Driven Development; When to Use; The Process; Setup; Model Selection; The Task Loop; 1. Dispatch the implementer; 2. Handle the report; 3. Review the task; 4. The fix loop; 5. Complete the task; Final Review; Finish; Common Rationalizations; Example Workflow.

**Procedure cues (source excerpts):** If it's a context problem, provide more context and re-dispatch with the same model; If the task requires more reasoning, re-dispatch with a more capable model; If the task is too large, break it into smaller pieces

**Resources:** scripts/: 3 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### systematic-debugging

[P033] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/systematic-debugging/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `808fc5717aa88ad65efff312b11c186294d3e6ee301afb584e2f86599b137787`.

**Purpose:** Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes

**Contents:** Systematic Debugging; Overview; The Iron Law; When to Use; The Four Phases; Phase 1: Root Cause Investigation; Phase 2: Pattern Analysis; Phase 3: Hypothesis and Testing; Phase 4: Implementation; Red Flags - STOP and Follow Process; your human partner's Signals You're Doing It Wrong; Common Rationalizations; Quick Reference; When Process Reveals "No Root Cause"; Supporting Techniques.

**Procedure cues (source excerpts):** **Read Error Messages Carefully**; **Reproduce Consistently**; **Check Recent Changes**

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### test-driven-development

[P032] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/test-driven-development/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `64b03fce4aee5a97a93160cea8111f3ba13a17b7c001db4bd5836d67fd10705d`.

**Purpose:** Use when implementing any feature or bugfix, before writing implementation code

**Contents:** Test-Driven Development (TDD); Overview; When to Use; The Iron Law; Red-Green-Refactor; RED - Write Failing Test; Verify RED - Watch It Fail; GREEN - Minimal Code; Verify GREEN - Watch It Pass; REFACTOR - Clean Up; Repeat; Good Tests; Common Rationalizations; Red Flags - STOP and Start Over; Example: Bug Fix.

**Opening guidance (source excerpt):** Write the test first. Watch it fail. Write minimal code to pass.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### using-git-worktrees

[P031] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/using-git-worktrees/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `8cfb86f121269e8f7f12361e6795c4f6738828340e28964c9229d365666c9edd`.

**Purpose:** Use when starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace exists via native tools or git worktree fallback

**Contents:** Using Git Worktrees; Overview; Step 0: Detect Existing Isolation; If this returns a path, you're in a submodule, not a worktree — treat as normal repo; Step 1: Create Isolated Workspace; 1a. Native Worktree Tools (preferred); 1b. Git Worktree Fallback; Directory Selection; Safety Verification (project-local directories only); Create the Worktree; Determine path based on chosen location; Step 2: Project Setup; Node.js; Rust; Python.

**Procedure cues (source excerpts):** **Check your instructions for a declared worktree directory preference.** If the user has already specified one, use it without asking.; **Check for an existing project-local worktree directory:**; **If there is no other guidance available**, default to `.worktrees/` at the project root.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### using-superpowers

[P034] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/using-superpowers/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `82c5c8866ad7f5dd4440ce66bd7806ba48a2f13771beae5cf112e53f08fe36ba`.

**Purpose:** Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying questions

**Contents:** The Rule; Skill Priority; Red Flags; Platform Adaptation; User Instructions.

**Opening guidance (source excerpt):** IF A SKILL APPLIES TO YOUR TASK, YOU DO NOT HAVE A CHOICE. YOU MUST USE IT.

**Resources:** references/: 7 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### verification-before-completion

[P044] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/verification-before-completion/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `2befe7fc55bcadaa3d97dd9e8efeb633d2561c0ebe74c5a8b17c4d9e7e4520b3`.

**Purpose:** Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always

**Contents:** Verification Before Completion; Overview; The Iron Law; The Gate Function; Common Failures; Red Flags - STOP; Rationalization Prevention; Key Patterns; When To Apply.

**Procedure cues (source excerpts):** IDENTIFY: What command proves this claim?; RUN: Execute the FULL command (fresh, complete); READ: Full output, check exit code, count failures

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### writing-plans

[P040] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/writing-plans/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `a6c67c1900064347c2a329990dd3c555657c51c3ec53b259a08aa01a2c26139a`.

**Purpose:** Use when you have a spec or requirements for a multi-step task, before touching code

**Contents:** Writing Plans; Overview; Scope Check; File Structure; Task Right-Sizing; Step Granularity; Plan Document Header; [Feature Name] Implementation Plan; Global Constraints; Review Focus; Task Structure; Task N: [Component Name]; What a Step Contains; Self-Review; Execution Handoff.

**Opening guidance (source excerpt):** Write implementation plans for an engineer who has not seen this codebase or this spec. Assume they write idiomatic code in the project's language once they know the exact interface and the exact test, and that they will make a reasonable choice wherever the plan leaves one open. What they cannot know is what you decided: which files, which names and signatures, which values from the spec, which t

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### writing-skills

[P043] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/writing-skills/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `bbdfe742f853562e643a3d40d64476359d47881e39cef80a189283fa26d11ab9`.

**Purpose:** Use when creating new skills, editing existing skills, or verifying skills work before deployment

**Contents:** Writing Skills; Overview; What is a Skill?; TDD Mapping for Skills; When to Create a Skill; Skill Types; Technique; Pattern; Reference; Directory Structure; SKILL.md Structure; Skill Name; Overview; When to Use; Core Pattern (for techniques/patterns).

**Procedure cues (source excerpts):** **Heavy reference** (100+ lines) - API docs, comprehensive syntax; **Reusable tools** - Scripts, utilities, templates; **One fresh-context sample per call** — a raw API call, or a single-shot subagent if you don't have API access. System prompt = the realistic context the guidance will live in (the full skill or prompt template, not the guidance in isolation); user message = a task that tempts the failure.

**Resources:** examples/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-curated-remote / work-pets / 0.1.6

### create-pet

[P026] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `841354fb8116f8fdfd3b643b30828f5180196c594d3fed9b669b948b88892af1`.

**Purpose:** Create, repair, validate, preview, upload, or activate an animated v2 pet in ChatGPT Work mode from a character idea, brand cue, or reference image. Use for new ChatGPT Pets, custom mascots, non-pixel styles, and unattached sprite sheets requiring nine animation states plus sixteen look directions. Preserve Library artifacts and Pets MCP lifecycle behavior. Exclude real pets, standalone images, and other-app pets; clarify before invoking.

**Contents:** Create Pet; Preserve the request and prepare Library; Discover brand cues when needed; Generate the visual jobs; Execute the bundled pipeline; Standard animation rows; Sixteen look directions; Assemble, review, and converge; Create and verify the pet.

**Procedure cues (source excerpts):** Getting `<Pet>` ready.; Imagining `<Pet>`'s main look.; Picturing `<Pet>`'s poses.

**Resources:** references/: 1 files; scripts/: 18 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### pets

[P025] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/pets/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `1bf5d45fd6a6390aab777229293fb05cef7cf898aac882f8955e40c378e52fcd`.

**Purpose:** List, inspect, select, download, or delete animated pets in ChatGPT Work mode. Use for an explicit pet in ChatGPT or established ChatGPT Pets context. Exclude real-world and other-app pets; clarify before invoking.

**Contents:** Pets; Route the request; Resolve a pet; List and inspect pets; Select or turn off a pet; Download a sprite sheet; Delete a custom pet.

**Procedure cues (source excerpts):** Reuse a stable pet ID that has already been resolved unambiguously in the conversation.; Otherwise, call `list_pets`. Follow each returned `cursor` until the target is found or every page has been checked.; For "current" or "active," use `active_pet_id` or the matching `is_active` value. For a name, collect exact matches across all relevant pages because names are not unique.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### update-pet

[P024] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/update-pet/SKILL.md`; modified UTC: 1970-01-01T00:00:01+00:00; SHA-256: `c63c98d67b6ad781a72a8f9837ba1fb5e2d2a8054a2562e4025890a97d8a0e67`.

**Purpose:** Inspect, validate, preview, repair, or update a custom pet in ChatGPT Work mode, including its name, description, or sprite sheet. Use for a pet in ChatGPT or established ChatGPT Pets context. Exclude real-world and other-app pets; clarify before invoking.

**Contents:** Update Pet; Resolve the pet; Choose the update path; Metadata only; Sprite sheet inspection or change, with optional metadata; Verify the update.

**Procedure cues (source excerpts):** Reuse a stable pet ID only when it has already been resolved unambiguously in the conversation. Otherwise, call `list_pets` and follow each returned `cursor` until the target is found or every page has been checked.; For "current" or "active," match `active_pet_id` or `is_active`. For a name, collect exact matches across every relevant page because pet names are not unique.; If no pet matches, tell the user. If multiple pets could match, show the candidates and ask which one to update before making changes.

**Resources:** No standard supporting-resource directories observed. (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-primary-runtime / documents / 26.904.11930

### documents

[P153] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/documents/26.904.11930/skills/documents/SKILL.md`; modified UTC: 2026-09-05T03:51:09+00:00; SHA-256: `3154ace095b79bace582d7dc53c7744a40f835fe762726220708bde2360749aa`.

**Purpose:** Create, edit, redline, and comment on `.docx`, Word, and Google Docs-targeted document artifacts inside the container, with a strict render-and-verify workflow. Use `render_docx.py` to generate page PNGs (and optional PDF) for visual QA, then iterate until layout is flawless before delivering the final document.

**Contents:** DOCX Skill (Read • Create • Edit • Redline • Comment); Titles + Intro to doc; Writing quality; Tools + Contract Requirements; Artifact Template Selection; Google Docs-targeted output; Template Following; Non-negotiable: render → inspect PNGs → iterate; Design standards for document generation; Note on page sizing; Note on font sizing; Editing tasks (DOCX edits) — apply instead of major rewrite behavior; Equations: native Word math vs rendered fallback; Rendered fallback: MathJax to high-resolution PNG; Quick start (common one-liners).

**Procedure cues (source excerpts):** Before you make the DOCX, please first think about the high-level design of the DOCX:; Once you have a working DOCX, continue iterating until the entire document is polished and correct. After every change or edit, render the DOCX and review it carefully to evaluate the result. The plan from (1) should guide you, but it is only a flexible draft; you should update your decisions as needed throughout the revision process. Important: each time you render and reflect, you should check for both:; Design aesthetics: the document should be aesthetically pleasing and easy to skim. Ask yourself: if a human were to look at my document, would they find it aesthetically nice? It should feel natural, smooth, and visually cohesive.

**Resources:** scripts/: 36 files; examples/: 1 files; assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-primary-runtime / pdf / 26.904.11930

### pdf

[P151] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/pdf/26.904.11930/skills/pdf/SKILL.md`; modified UTC: 2026-09-05T03:51:08+00:00; SHA-256: `afc4472ec4d625f703e9f414fe6814ce3cfa0ec51c7a07887fe587264c8b561e`.

**Purpose:** Read, create, inspect, render, and verify PDF files where visual layout matters, including fillable AcroForms. Use Poppler rendering plus Python tools such as reportlab, pdfplumber, and pypdf for generation and extraction.

**Contents:** PDF Skill; When To Use; Tools + Contract Requirements; Workflow; Fill And Validate AcroForms; Restores widgets that are missing from /AcroForm/Fields.; Temp And Output Conventions; Dependencies; macOS (Homebrew); Ubuntu/Debian; Environment; Rendering Command; Quality Expectations; Final Checks; Final response citations.

**Procedure cues (source excerpts):** Prefer visual review: render PDF pages to PNGs and inspect them.; Use `reportlab` to generate PDFs when creating new documents.; Use `pdfplumber` or `pypdf` for text extraction and quick checks; do not rely on text extraction for layout fidelity.

**Resources:** assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-primary-runtime / presentations / 26.904.11930

### Presentations

[P152] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/SKILL.md`; modified UTC: 2026-09-05T03:51:09+00:00; SHA-256: `fd3703aa1f91d386b94806a3a4061f77cdd3ea830fddfb7297243c5c9e53a5a8`.

**Purpose:** Read, create or edit PowerPoint or Google Slides decks. Use for presentation, slide deck, PowerPoint, PPT, PPTX, or Google Slides requests.

**Contents:** Presentations; Artifact Template Selection; Writing Quality Instructions; Taxonomy; 1. Awkward/unnatural wording; 2. Excessive/flowery wording; 3. Vague/empty wording; 4. Unnecessary wording; 5. Illogical wording; AI-isms; 1. Punctuation; 2. “It’s not X, it’s Y” / “Do Y, not X”; 3. Passive Voice; 4. Imperative Title; 5. Slogan-like Phrasing.

**Procedure cues (source excerpts):** Read `references/implementation.md` and the [API quick start](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/artifact_tool_docs/API_QUICK_START.md) before coding. Use JavaScript ES modules with `@oai/artifact-tool`; do not use `python-pptx` or the obsolete Python API.; Follow the user’s requested order; otherwise, choose an order that covers the request without repetition. Give each slide a clear purpose. A factual summary, comparison or explanation is enough when the evidence does not support a recommendation.; Read additional guidance only when needed: [cover design](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/references/cover_art_direction.md) for a new cover; [editable tables and charts](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/references/native_evidence.md); [bullet formatting](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/references/native_bullets.md) for new lists; [finance](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/domain_guidance/finance.md) for financial presentations. Use the [API reference map](/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/presentations/26.904.11930/skills/presentations/artifact_tool_docs/api/API_DOCS.md#reference-map) for other objects.

**Resources:** references/: 6 files; assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-primary-runtime / spreadsheets / 26.904.11930

### Spreadsheets

[P149] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.904.11930/skills/spreadsheets/SKILL.md`; modified UTC: 2026-09-05T03:51:09+00:00; SHA-256: `655af692c745b9aab2fb06b8843b27de0099e9acebf28d67f3916d624c4a0f97`.

**Purpose:** Create, edit, analyze, and verify standalone spreadsheet files or Google Sheets-ready workbooks, including .xlsx, .xls, .csv, and .tsv. Do not use for live controlling Microsoft Excel app or a live Excel session.

**Contents:** Spreadsheets skill; Decision Boundary; Important Instructions; Tools + Contract Requirements; Writing Quality and Authored Content; Workflows; Resources; Domain Requirements; Create and Edits; Formula Correctness; Data Formatting Rules; Verification Rules; Citation Requirements; Completion Criteria; Criteria for Question / Read only requests.

**Procedure cues (source excerpts):** Inspect key ranges:; Scan formula errors:; Render sheets/ranges to verify visual output (skip if already verified and no style changes):

**Resources:** references/: 3 files; assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

### excel-live-control

[P150] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.904.11930/skills/excel-live-control/SKILL.md`; modified UTC: 2026-09-05T03:51:09+00:00; SHA-256: `8eaf019809f570fba2592052522251ff2b5c9b0d3ca7eca9bbf1fe5a6f82c84b`.

**Purpose:** Control an open or active Microsoft Excel workbook through the ChatGPT add-in or connected session. Use when the user tags the Microsoft Excel app in Codex or follows up on an established live Excel task. Do not use for standalone spreadsheet files or Google Sheets.

**Contents:** Excel Live Control; Important Instructions; Hard Routing Rules; Setup State Machine; 1. Open Microsoft Excel And Establish The Target Workbook; 2. Determine Whether The ChatGPT Add-in Is Installed; 3. Open The ChatGPT Add-in Pane; 4. Verify ChatGPT Sign-in; 5. Verify Connected-Document Tool Availability; 6. Verify Workbook Registration; Exact User Guidance For Incomplete Gates; Live Commands; Live Workbook Quality Checklist; Office.js Gate; Out Of Scope.

**Procedure cues (source excerpts):** Open the official Microsoft Marketplace listing: https://marketplace.microsoft.com/en-us/product/office/WA200010215; Or, in Excel, go to **Home > Add-ins**, search for **ChatGPT**, verify that the publisher is **OpenAI, LLC**, and choose **Add** or **Get it now**.; Return to the target workbook and open **ChatGPT** from the ribbon.

**Resources:** references/: 2 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.


## openai-primary-runtime / template-creator / 26.904.11930

### template-creator

[P148] Source: `/Users/alexlobaito/.codex/plugins/cache/openai-primary-runtime/template-creator/26.904.11930/skills/template-creator/SKILL.md`; modified UTC: 2026-09-05T03:51:08+00:00; SHA-256: `f1d14fd2847a2e879611a8b8f872f5dc4676a0607958d015274d2dc61e812deb`.

**Purpose:** Create or update a reusable personal Codex artifact-template skill. Use when the user invokes $template-creator or asks in natural language to create a reusable template from a reference document, presentation, spreadsheet, Google Docs, Slides, or Sheets link, ImageGen or Product Design image, email, Slack message, or Site project, or explicitly asks to edit or update a passed artifact-template skill. Do not use for one-off creation from an existing template.

**Contents:** Template Creator; Routing; Create workflow; Update workflow; Response; How to find templates; How to use a template; Constraints.

**Procedure cues (source excerpts):** Require exactly one supported reference unless the user explicitly requests a batch. For a batch, complete this workflow separately for every reference:; Infer a concise display name and intended-use description from the reference and request. Infer document, presentation, spreadsheet, and image from the file extension. For a Site project directory, use `site`. Infer `google-docs`, `google-slides`, or `google-sheets` from the supplied Workspace URL; for a generic Drive share URL, use Google Drive metadata to identify the native file type and resolve its canonical `docs.google.com` URL. Ask only when the link is inaccessible or does not identify a supported native Workspace artifact. For an image, set its gallery kind to `product-design` when the request includes `@Product Design`; otherwise default to `imagegen`, including when the user provides only the image and this skill. Ask only when the request explicitly includes both Product Design and ImageGen and the intended target remains unclear. For `.txt`, determine whether the user requested `email` or `slack`; ask if the intended type is ambiguous.; For references other than Site projects, create `preview.png` before packaging:

**Resources:** scripts/: 1 files; assets/: 1 files (metadata only).

**Evidence level:** cache present; enabled configuration NOT_PROVEN; NOT_PROVEN; not matched to the supplied available-skills catalogue; remote delivery NOT_PROVEN.

## Required future update

On a cache refresh or enabled-skill change, repeat this safe SKILL.md enumeration and contents/hash audit, separately refresh actual session exposure and any claimed behavior, and record the result in [LESSONS](LESSONS.md). Update [START_HERE](START_HERE.md) with audit date, scope, verification receipt and gaps after acceptance. Catalogue maintenance does not authorize installation, config changes or remote publication.

## Gaps

Supporting-resource contents, enablement configuration, runtime selection/execution, remote delivery and other-machine caches were not audited. Any excluded symlink directories and read errors are individually identified in the coverage JSON. No .env, credential file or FIFO contents were read.
